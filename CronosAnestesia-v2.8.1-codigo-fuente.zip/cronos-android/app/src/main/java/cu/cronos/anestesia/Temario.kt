package cu.cronos.anestesia

import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

// =====================================================================
//  TEMARIO ORIENTATIVO R1–R4 (v2.4.0 — contrato §5.2 «temario R1–R4»)
//  Plan de estudio de la residencia de Anestesiología y Reanimación,
//  organizado por cursos con áreas y temas marcables. Es una guía
//  orientativa de estudio elaborada para la aplicación: no sustituye el
//  programa oficial de la especialidad ni las orientaciones de la
//  cátedra; el residente lo ajusta con su tutor.
//  El progreso se guarda solo en el teléfono (SharedPreferences).
// =====================================================================

data class ResArea(val title: String, val topics: List<String>)
data class ResYear(
    val curso: String,      // "R1".."R4"
    val objetivo: String,
    val areas: List<ResArea>
)

val RESIDENCY: List<ResYear> = listOf(
    ResYear(
        "R1",
        "Fundamentos: seguridad del paciente, técnica básica y supervisión estrecha. El objetivo del primer año es no hacer daño y aprender a trabajar en equipo.",
        listOf(
            ResArea("Introducción y principios", listOf(
                "Historia de la anestesiología y estructura de un quirófano",
                "Roles del equipo: anestesiólogo, instrumentista, circulante, coordinación",
                "Checklist OMS y comunicación (SBAR, briefing, debriefing)",
                "Bioseguridad, higiene de manos y manejo de residuos sanitarios",
                "Ética y confidencialidad de la historia clínica",
                "Registro anestésico: qué se anota, cuándo y por qué"
            )),
            ResArea("Fisiología y farmacología base", listOf(
                "Fisiología respiratoria aplicada (mecánica, V/Q, intercambio gaseoso)",
                "Fisiología cardiovascular aplicada (gasto, presiones, retorno venoso)",
                "Equilibrio ácido-base y gasometría básica",
                "Balance hídrico y electrolitos del perioperatorio",
                "Farmacocinética y farmacodinamia: conceptos y ejemplos anestésicos",
                "Inductores: propofol, tiopental, etomidato, ketamina",
                "Opioides y analgesia básica",
                "Relajantes neuromusculares y monitoreo del bloqueo (TOF)",
                "Halogenados y farmacología de los gases",
                "Vasopresores, inotrópicos y atropina: preparación y uso"
            )),
            ResArea("Vía aérea básica", listOf(
                "Evaluación de la vía aérea (Mallampati, boca, cuello, história)",
                "Preoxigenación y desnitrogenación",
                "Laringoscopia directa: técnica y manejo de la primera falla",
                "Tubos, guías, bujías y fijación",
                "Mascarilla laríngea y dispositivos supraglóticos",
                "Ventilación con mascarilla y vía aérea de dos operadores",
                "Ventilación mecánica básica: modos, parámetros y alarmas",
                "Extubación y criterios de recuperación de la vía aérea"
            )),
            ResArea("Monitoreo y máquinas", listOf(
                "Monitor estándar: ECG, SpO2, PNI, capnografía",
                "Capnografía: formas de onda y problemas frecuentes",
                "Punción arterial y gasometría",
                "Verificación de la máquina de anestesia (8 pasos, leak test)",
                "Circuito circular, cal sodada y gases frescos",
                "Succión, via aérea de rescate y O2 de reserva: la trinidad"
            )),
            ResArea("Anestesia general básica", listOf(
                "Evaluación preoperatoria y clasificación ASA",
                "Ayuno y premedicación",
                "Inducción, mantenimiento y despertar: la secuencia completa",
                "Posicionamiento del paciente y prevención de lesiones",
                "Fluidoterapia básica del adulto sano",
                "Analgesia postoperatoria básica (multimodal)",
                "NVPO: profilaxis y tratamiento",
                "Traslado del paciente a la sala de recuperación"
            )),
            ResArea("Emergencias y primeros meses", listOf(
                "RCP del adulto (ACLS): rol del anestesiólogo en el quirófano",
                "Anafilaxia perioperatoria: reconocimiento y primeros pasos",
                "Hemorragia masiva: llamar, canalizar, reponer",
                "Hipertermia maligna: protocolo y dantroleno",
                "Sala de recuperación: monitoreo, escalas de salida (Aldrete)"
            ))
        )
    ),
    ResYear(
        "R2",
        "Consolidación: mayor autonomía en casos de complejidad media, inicio de la anestesia regional y de las áreas especiales bajo supervisión.",
        listOf(
            ResArea("Anestesia regional inicial", listOf(
                "Anatomía neuroaxial aplicada y ecografía de columna",
                "Anestesia raquídea: técnica y manejo de la hipotensión",
                "Epidural lumbar: pérdida de resistencia y catéter",
                "Bloqueos de la pared: TAP, recto, ilioinguinal",
                "Bloqueo femoral y aductor, fascia ilíaca",
                "Bloqueo interscaleno y supraclavicular básicos",
                "Dosis máximas de anestésicos locales y LAST: prevención",
                "Anticoagulación y bloqueo (ASRA): ventanas básicas"
            )),
            ResArea("Obstetricia", listOf(
                "Cambios fisiológicos del embarazo a término",
                "Analgesia del parto: epidural y espinal combinada",
                "Cesárea electiva: espinal, dosis y vasopresores",
                "Cesárea de urgencia y secuencia rápida en la embarazada",
                "Hemorragia obstétrica: protocolo, hemoderivados y uterotónicos",
                "Preeclampsia y eclampsia: magnesio y control de la presión",
                "Anestesia no obstétrica en la gestante"
            )),
            ResArea("Cirugía y casos frecuentes", listOf(
                "Laparoscopía: neumoperitoneo y fisiología",
                "Ortopedia y traumatología básica (cadera, fémur, torniquete)",
                "Cirugía abdominal media (apendicectomía, colecistectomía, hernias)",
                "Urología: RTU de próstata y síndrome de absorción",
                "Oftalmología y ORL básicas",
                "Cirugía ambulatoria: selección, alta y PADSS",
                "Paciente obeso: ventilación, dosis y posición",
                "Paciente diabético y corticoide-dependiente"
            )),
            ResArea("Cuidados posoperatorios y UCI inicial", listOf(
                "Complicaciones posanestésicas: hipoventilación, hipoxemia, delirio",
                "Analgesia multimodal y PCA",
                "Fluidos y electrolitos en el posoperatorio",
                "Reconocimiento del paciente que se deteriora",
                "Ventilación mecánica en UCI: primeros modos y sedación (RASS)"
            ))
        )
    ),
    ResYear(
        "R3",
        "Alta complejidad: cirugía cardíaca, torácica, neuro y pediátrica avanzada, cuidados intensivos y dolor; inicio de la docencia.",
        listOf(
            ResArea("Anestesia cardiovascular", listOf(
                "Evaluación cardíaca preoperatoria (RCRI, eco, pruebas)",
                "Circulación extracorpórea: circuito, anticoagulación y protamina",
                "Anestesia para cirugía coronaria y valvular",
                "Manejo de la hemodinamia post-CEC: vasopresores e inotrópicos",
                "Ecografía focales y transesofágica básica",
                "Coagulopatía del paciente cardíaco: point of care y hemostasia"
            )),
            ResArea("Torácica y vía aérea avanzada", listOf(
                "Ventilación unipulmonar: aislamiento, CPAP y OLV",
                "Fibrobroncoscopía y técnicas de intercambio de tubo",
                "Vía aérea difícil anticipada: planes A-B-C-D y traqueostomía",
                "Cirugía de mediastino y neumonectomía",
                "Láser de vía aérea y riesgo de incendio quirúrgico"
            )),
            ResArea("Neuroanestesia", listOf(
                "Fisiología intracraneal: PIC, FSC y acoplamiento",
                "Craneotomía electiva: inducción, posicionamiento y despertar",
                "Hipertensión intracraneal aguda y trauma craneoencefálico",
                "Neuroprotección: hipotermia, glucemia y presión de perfusión",
                "Aneurismas y malformaciones vasculares",
                "Monitoreo neurológico intraoperatorio (SSEP, MEP, EEG)"
            )),
            ResArea("Cuidados intensivos", listOf(
                "Shock: clasificación y resucitación guiada por objetivos",
                "Sepsis y disfunción multiorgánica",
                "Ventilación mecánica avanzada: SDRA, pronación, reclutamiento",
                "Monitoreo hemodinámico avanzado y ecografía POOCUS",
                "Trasfusión y coagulopatía en el paciente crítico",
                "Limitación del esfuerzo terapéutico y comunicación de malas noticias"
            )),
            ResArea("Dolor crónico y agudo avanzado", listOf(
                "Servicio de dolor agudo: rondas y ajuste de planes",
                "Bloqueos continuos con catéter: indicación y cuidado",
                "Opioides y rotación en el dolor oncológico",
                "Intervencionismo básico del dolor: radicular y facetario"
            )),
            ResArea("Docencia e investigación", listOf(
                "Enseñar en el quirófano: cómo supervisar a un R1",
                "Lectura crítica de artículos y sesión bibliográfica",
                "Metodología de la investigación: protocolo y ética",
                "Simulación de crisis: organización de un escenario"
            ))
        )
    ),
    ResYear(
        "R4",
        "Perfeccionamiento: jefatura de equipo, gestión, emergencias masivas, trasplantes y preparación del examen estatal. El R4 es el último filtro de calidad de la especialidad.",
        listOf(
            ResArea("Gestión y calidad", listOf(
                "Programación quirúrgica y uso eficiente de salas",
                "Sistemas de reporte de incidentes y cultura justa",
                "Auditoría clínica e indicadores del servicio",
                "Manejo de inventario y presupuesto de medicamentos y dispositivos",
                "Seguridad del paciente: eventos adversos y análisis de causa raíz"
            )),
            ResArea("Anestesia de alta complejidad", listOf(
                "Trasplante renal y hepático: fisiología y manejo",
                "Cirugía de aorta y vascular mayor",
                "Embarazo de alto riesgo: cardiopatía, obesidad mórbida, acreta",
                "Anestesia fuera de quirófano: endoscopía, radiología, electroconvulsivoterapia",
                "Paciente con dispositivo (marcapasos/DAI) y riesgo eléctrico"
            )),
            ResArea("Emergencias, catástrofes y triage", listOf(
                "Plan de emergencias hospitalario: rol del anestesiólogo",
                "Atención masiva de heridos: triage y rotación de recursos",
                "Trauma mayor: secuencia de control de daño",
                "Vía aérea en el paciente quemado y de inhalación",
                "Manejo de la vía aérea en condiciones degradadas"
            )),
            ResArea("Jefatura y docencia", listOf(
                "Coordinación del equipo y resolución de conflictos",
                "Supervisión clínica de R1–R2: delegación y seguridad",
                "Docencia de pregrado y posgrado",
                "Presentación de casos y sesiones de morbilidad"
            )),
            // v2.8.1: Pediatría pasa al 4.º año del programa (pedido del autor
            // clínico: «pediatría se da en cuarto año, ya no en segundo»). Las
            // áreas se trasladan íntegras desde R2/R3 con sus temas.
            ResArea("Pediatria básica", listOf(
                "Diferencias fisiológicas por edad y cálculo de dosis",
                "Vía aérea pediátrica y tamaños de tubos",
                "Inducción inhalatoria y IV en el niño",
                "Bloqueo caudal y regional pediátrico básico",
                "Fluidos, glucemia y temperatura en el niño",
                "RCP pediátrico y neonatal"
            )),
            ResArea("Pediatría avanzada y neonatal", listOf(
                "Anestesia neonatal: prematuridad, ductus y laparotomías",
                "Cirugía pediátrica mayor: oncológica, correctiva y trauma",
                "Analgesia regional pediátrica con ecografía",
                "Dolor y sedación en el niño crítico"
            )),
            ResArea("Preparación del examen estatal", listOf(
                "Temario integrado: repaso por sistemas",
                "Casos clínicos simulados y discusión oral",
                "Habilidades prácticas de evaluación",
                "Estrategia de estudio y cronograma del último semestre"
            ))
        )
    )
)

// ---------------- Progreso (solo en el teléfono) ----------------

/** Identificador estable de un tema: r1.a0.t2, r3.a5.t1, etc. */
fun temaId(yearIdx: Int, areaIdx: Int, temaIdx: Int): String =
    "r${yearIdx + 1}.a${areaIdx}.t${temaIdx}"

object TemarioStore {
    private const val PREFS = "temario"
    private const val KEY_DONE = "done"

    private fun prefs(ctx: android.content.Context) =
        ctx.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)

    fun done(ctx: android.content.Context): Set<String> {
        val arr = org.json.JSONArray(prefs(ctx).getString(KEY_DONE, "[]") ?: "[]")
        return (0 until arr.length()).map { arr.optString(it) }.toSet()
    }

    fun toggle(ctx: android.content.Context, id: String) {
        val cur = done(ctx).toMutableSet()
        if (!cur.add(id)) cur.remove(id)
        val arr = org.json.JSONArray()
        cur.sorted().forEach { arr.put(it) }
        prefs(ctx).edit().putString(KEY_DONE, arr.toString()).apply()
    }

    fun reset(ctx: android.content.Context) {
        prefs(ctx).edit().remove(KEY_DONE).apply()
    }

    /** Porcentaje completado de un curso (0–100). */
    fun percentOf(done: Set<String>, yearIdx: Int): Int {
        val year = RESIDENCY.getOrNull(yearIdx) ?: return 0
        var total = 0
        var ok = 0
        year.areas.forEachIndexed { a, area ->
            area.topics.forEachIndexed { t, _ ->
                total++
                if (temaId(yearIdx, a, t) in done) ok++
            }
        }
        return if (total == 0) 0 else (ok * 100 / total)
    }
}


// ---------------- Pantalla (pestaña Temario) ----------------

private fun isTemaDone(done: Set<String>, year: Int, area: Int, topic: Int): Boolean =
    temaId(year, area, topic) in done

@Composable
fun TemarioTab() {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    var done by remember { mutableStateOf(TemarioStore.done(ctx)) }
    var year by rememberSaveable { mutableStateOf(0) }
    val yearSafe = year.coerceIn(0, RESIDENCY.size - 1)
    val y = residencyL10n()[yearSafe]
    val pct = TemarioStore.percentOf(done, yearSafe)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
    ) {
        Column(Modifier.padding(horizontal = sp.screenHPad.dp)) {
            Spacer(Modifier.height(sp.s.dp))
            Text(
                "Temario orientativo de la residencia · progreso guardado solo en su teléfono".tr(),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(sp.s.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
                RESIDENCY.forEachIndexed { i, r ->
                    AppButton(
                        r.curso,
                        secondary = yearSafe != i,
                        modifier = Modifier.weight(1f),
                        onClick = { year = i }
                    )
                }
            }
            Spacer(Modifier.height(sp.xs.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "%1\$s · %2\$d %% completado".tr().format(y.curso, pct),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )
                AppButton(
                    if (pct == 0) "Sin marcas".tr() else "Limpiar curso".tr(),
                    secondary = true,
                    onClick = {
                        val cur = done.toMutableSet()
                        y.areas.forEachIndexed { a, area ->
                            area.topics.indices.forEach { t -> cur.remove(temaId(yearSafe, a, t)) }
                        }
                        val arr = org.json.JSONArray()
                        cur.sorted().forEach { arr.put(it) }
                        ctx.getSharedPreferences("temario", Context.MODE_PRIVATE)
                            .edit().putString("done", arr.toString()).apply()
                        done = cur
                    }
                )
            }
            LinearProgressIndicator(
                progress = { pct / 100f },
                modifier = Modifier.fillMaxWidth().height(6.dp)
            )
            Spacer(Modifier.height(sp.xs.dp))
            Text(
                y.objetivo,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(sp.s.dp))
        }
        y.areas.forEachIndexed { a, area ->
            val areaDone = area.topics.indices.count { isTemaDone(done, yearSafe, a, it) }
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = sp.screenHPad.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(sp.m.dp)) {
                    Row {
                        Text(
                            area.title,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            "$areaDone/${area.topics.size}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    area.topics.forEachIndexed { t, tema ->
                        TemaRow(
                            tema,
                            isTemaDone(done, yearSafe, a, t)
                        ) {
                            TemarioStore.toggle(ctx, temaId(yearSafe, a, t))
                            done = TemarioStore.done(ctx)
                        }
                    }
                }
            }
            Spacer(Modifier.height(sp.xs.dp))
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun TemaRow(text: String, checked: Boolean, onToggle: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = checked, onCheckedChange = { onToggle() })
        Text(
            text,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
