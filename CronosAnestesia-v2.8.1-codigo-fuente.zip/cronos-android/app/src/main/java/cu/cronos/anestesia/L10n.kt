package cu.cronos.anestesia

/*
 * ============================================================================
 *  Núcleo de internacionalización (v2.6.0) — Español (base), English,
 *  Português (Brasil). 100 % sin conexión: el idioma se resuelve al arrancar.
 *
 *  · Preferencia: "" = seguir el idioma del teléfono; si el sistema está en
 *    un idioma no soportado, la app arranca en ESPAÑOL (idioma base).
 *  · Selector manual en Ajustes → Idioma; al cambiar se guarda la preferencia
 *    y la actividad se recrea (recursos XML + contenido compilado).
 *  · Recursos XML: values/ (es) · values-en/ · values-pt/ — resueltos por el
 *    contexto envuelto en LocaleHelper.wrap().
 *  · Contenido clínico compilado en Kotlin: String.tr() consulta la tabla del
 *    idioma activo (clave = texto original en español). Si una cadena aún no
 *    está traducida en una ola, se muestra el español original (degradación
 *    elegante): ninguna ola parcial puede romper la app.
 * ============================================================================
 */

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import java.util.Locale

/** Idiomas soportados. ES es el idioma base del producto. */
enum class Lang(val code: String, val label: String) {
    ES("es", "Español"),
    EN("en", "English"),
    PT("pt", "Português (Brasil)");

    companion object {
        /** Mapea un código BCP-47 a un idioma soportado (prefijo). */
        fun from(code: String): Lang? = when {
            code.startsWith("en") -> EN
            code.startsWith("pt") -> PT
            code.startsWith("es") -> ES
            else -> null
        }
    }
}

object L10n {

    /** Idioma resuelto y activo para el contenido compilado (nunca "sistema"). */
    @Volatile var current: Lang = Lang.ES

    private val tables = mutableMapOf<Lang, MutableMap<String, String>>()

    fun table(lang: Lang): MutableMap<String, String>? =
        if (lang == Lang.ES) null else tables.getOrPut(lang) { mutableMapOf() }

    /** Registra (o amplía) la tabla de traducciones de un idioma. Idempotente. */
    fun register(lang: Lang, pairs: Map<String, String>) {
        if (lang == Lang.ES) return
        table(lang)?.putAll(pairs)
    }

    /** N.º de cadenas registradas para un idioma (cobertura por olas/tests). */
    fun registered(lang: Lang): Int = tables[lang]?.size ?: 0
}

/** Traduce un literal de contenido al idioma activo; si falta, español. */
fun String.tr(): String {
    val lang = L10n.current
    if (lang == Lang.ES) return this
    return L10n.table(lang)?.get(this) ?: this
}

/** Traduce una lista de literales (p. ej. los puntos de un tema clínico). */
fun List<String>.tr(): List<String> = map { it.tr() }

/** Preferencia de idioma: "" = sistema; "es"/"en"/"pt" = fijado por el usuario. */
object LocalePrefs {
    private const val PREFS = "cronos_locale"
    private const val KEY = "lang"

    fun read(ctx: Context): String =
        prefs(ctx).getString(KEY, "") ?: ""

    fun write(ctx: Context, code: String) {
        prefs(ctx).edit().putString(KEY, code).apply()
    }

    private fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}

/** Envoltura de contexto con el Locale resuelto (recursos XML). */
object LocaleHelper {

    /**
     * Resuelve el idioma (preferencia → sistema → español) y devuelve un
     * contexto cuya configuración usa ese Locale. Debe llamarse desde
     * Activity.attachBaseContext() para que también los recursos XML
     * (stringResource) salgan en el idioma correcto.
     */
    fun wrap(ctx: Context): Context {
        val saved = LocalePrefs.read(ctx)
        val resolved: Lang = Lang.from(saved)
            ?: Lang.from(systemLanguage(ctx))
            ?: Lang.ES                       // idioma base (decisión fijada)
        L10n.current = resolved
        val locale: Locale = when (resolved) {
            Lang.EN -> Locale("en")
            Lang.PT -> Locale("pt", "BR")
            Lang.ES -> Locale("es")
        }
        Locale.setDefault(locale)
        val config = Configuration(ctx.resources.configuration)
        config.setLocale(locale)
        return ctx.createConfigurationContext(config)
    }

    /** Idioma del teléfono; "es" si no se puede leer (fallback del producto). */
    fun systemLanguage(ctx: Context): String = try {
        val loc = if (android.os.Build.VERSION.SDK_INT >= 24)
            ctx.resources.configuration.locales[0]
        else
            @Suppress("DEPRECATION") ctx.resources.configuration.locale
        loc?.language ?: "es"
    } catch (_: Throwable) {
        "es"
    }
}

/**
 * Registro de las olas de traducción del contenido compilado. init() es
 * idempotente y se llama al inicio de MainActivity (y en los tests JVM).
 * Cada objeto I18nXxx añade su tabla sin tocar los datos clínicos originales:
 * el riesgo de regresión es cero y una ola interrumpida degrada a español.
 */
object I18n {
    @Volatile private var done = false

    fun init() {
        if (done) return
        synchronized(this) {
            if (done) return
            I18nUi.register()
            I18nConsent.register()
            I18nClinical.register()
            I18nDeepClin.register()
            I18nDeepDrugs.register()
            I18nDeepScales.register()
            I18nDeepMisc.register()
            I18nV280.register()
            I18nV281.register() // v2.8.1: feedback clínico + buscador + acidobásico
            done = true
        }
    }
}
