package cu.cronos.anestesia

/*
 * ============================================================================
 *  CalcEngine — lógica clínica PURA de las calculadoras (contrato §9.2/§D-3):
 *  sin dependencias de Android ni Compose → testeable con JUnit (vectores
 *  dorados). La UI (Calcs.kt) solo formatea y pinta los resultados.
 *  Identificadores en inglés; los textos de interfaz viven en la UI/es-ES.
 * ============================================================================
 */
import java.util.Locale
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.round

/** Motor de cálculo clínico puro. */
object CalcEngine {

    // ---------- Utilidades numéricas ----------

    fun parseNum(s: String): Double =
        s.replace(',', '.').trim().toDoubleOrNull() ?: 0.0

    /** Formato compacto: ≥100 sin decimales, ≥10 con 1, resto con 2. */
    fun fmt(v: Double): String = when {
        v >= 100 -> String.format(Locale.US, "%.0f", v)
        v >= 10 -> String.format(Locale.US, "%.1f", v)
        else -> String.format(Locale.US, "%.2f", v)
    }

    // ---------- 1. Ayuno preoperatorio (regla 2-4-6-8) ----------

    /** Horas de ayuno requeridas por tipo de ingesta: 0 líquido claro, 1 leche materna, 2 fórmula/ligera, 3 grasosa. */
    val FASTING_REQUIRED_HOURS = listOf(2.0, 4.0, 6.0, 8.0)

    // ---------- 2. Hidratación transoperatoria (Holliday-Segar 4-2-1) ----------

    /** Mantenimiento horario en mL/h según la regla 4-2-1. */
    fun maintenanceMlH(weightKg: Double): Double =
        4.0 * min(weightKg, 10.0) +
            2.0 * (min(weightKg, 20.0) - min(weightKg, 10.0)) +
            1.0 * max(0.0, weightKg - 20.0)

    data class HydrationPlan(
        val maintenanceMlH: Double,
        val deficitMl: Double,
        val hour1Ml: Double,
        val hour2Ml: Double,
        val hour3Ml: Double,
        val total3hMl: Double
    )

    /** Plan de las primeras 3 h: 1.ª hora ½ déficit + mantenimiento, 2.ª y 3.ª ¼ déficit + mantenimiento. */
    fun hydrationPlan(weightKg: Double, fastingHours: Double): HydrationPlan {
        val maint = maintenanceMlH(weightKg)
        val deficit = maint * max(0.0, fastingHours)
        val h1 = maint + deficit / 2.0
        val h2 = maint + deficit / 4.0
        val h3 = maint + deficit / 4.0
        return HydrationPlan(maint, deficit, h1, h2, h3, h1 + h2 + h3)
    }

    // ---------- 3. Dosis por peso ----------

    fun weightDose(perKg: Double, weightKg: Double): Double = perKg * weightKg

    // ---------- 4. Infusión continua ----------

    /** mL/h de bomba: dosis(µg/kg/min) × peso × 60 / concentración(µg/mL). */
    fun infusionMlH(doseUgKgMin: Double, weightKg: Double, concUgMl: Double): Double =
        doseUgKgMin * weightKg * 60.0 / concUgMl

    /** Dosis horaria en mg/h. */
    fun infusionMgH(doseUgKgMin: Double, weightKg: Double): Double =
        doseUgKgMin * weightKg * 60.0 / 1000.0

    // ---------- 5. Peso ideal (Devine) y peso ajustado ----------

    /** Devine: hombre 50 kg + 0,91 × (cm − 152,4); mujer 45,5 kg + … */
    fun idealWeight(male: Boolean, heightCm: Double): Double =
        (if (male) 50.0 else 45.5) + 0.91 * (heightCm - 152.4)

    /** Peso ajustado = PI + 0,4 × (peso real − PI). */
    fun adjustedWeight(idealKg: Double, realKg: Double): Double =
        idealKg + 0.4 * (realKg - idealKg)

    // ---------- 6. Tubo endotraqueal pediátrico (Levi) ----------

    private fun half(v: Double): Double = round(v * 2.0) / 2.0

    fun tubeUncuffedMm(ageYears: Double): Double = half(ageYears / 4.0 + 4.0)

    fun tubeCuffedMm(ageYears: Double): Double = half(ageYears / 4.0 + 3.5)

    /** Profundidad labial en cm: 12 + edad/2 (valor exacto; la UI muestra decimales). */
    fun tubeDepthCm(ageYears: Double): Double = 12.0 + ageYears / 2.0

    // ---------- 7. Volemia y sangrado máximo permitido ----------

    /** Volemia estimada mL/kg: hombre 70, mujer 65, niño 80, lactante 90. */
    val EBV_ML_PER_KG = listOf(70.0, 65.0, 80.0, 90.0)

    fun estimatedBloodVolume(weightKg: Double, categoryIndex: Int): Double =
        weightKg * EBV_ML_PER_KG[categoryIndex.coerceIn(0, 3)]

    /** Pérdida de sangre máxima permitida (fórmula del hematocrito promedio). */
    fun allowableBloodLoss(ebvMl: Double, hctInitial: Double, hctMinimum: Double): Double {
        val avg = (hctInitial + hctMinimum) / 2.0
        if (avg <= 0.0) return 0.0
        return ebvMl * (hctInitial - hctMinimum) / avg
    }

    /**
     * Hematocrito final estimado tras una pérdida dada, sin reposición aún
     * (modelo de serie eritrocitaria inmediata): Htof = Hto0 × (EBV − pérdida)/EBV.
     * Con reposición por cristaloide el Hto real cae más; es una guía orientativa.
     */
    fun hctAfterBloodLoss(ebvMl: Double, hctInitial: Double, bloodLossMl: Double): Double {
        if (ebvMl <= 0.0 || hctInitial <= 0.0) return 0.0
        val loss = bloodLossMl.coerceIn(0.0, ebvMl)
        return hctInitial * (ebvMl - loss) / ebvMl
    }

    /** Conversión rápida Hb (g/dL) → Hto (%): Hto ≈ 3 × Hb. */
    fun hctFromHb(hbGdl: Double): Double = hbGdl * 3.0

    /** Conversión rápida Hto (%) → Hb (g/dL): Hb ≈ Hto / 3. */
    fun hbFromHct(hctPercent: Double): Double = hctPercent / 3.0

    // ---------- 8. Gasometría ----------

    fun pfiIndex(pao2MmHg: Double, fio2Percent: Double): Double =
        pao2MmHg / (fio2Percent / 100.0)

    /** PAO2 a nivel del mar: FiO2 × (760 − 47) − PaCO2 / 0,8. */
    fun alveolarPao2(fio2Percent: Double, paco2MmHg: Double): Double =
        (fio2Percent / 100.0) * (760.0 - 47.0) - paco2MmHg / 0.8

    fun aaGradient(pao2MmHg: Double, fio2Percent: Double, paco2MmHg: Double): Double =
        alveolarPao2(fio2Percent, paco2MmHg) - pao2MmHg

    /** Límite fisiológico del gradiente A–a: 25 mmHg o edad/4 + 4. */
    fun aaNormalLimit(ageYears: Double): Double =
        if (ageYears > 0) ageYears / 4.0 + 4.0 else 25.0

    enum class Berlin { NONE, MILD, MODERATE, SEVERE }

    fun berlinClass(pfi: Double): Berlin = when {
        pfi >= 300 -> Berlin.NONE
        pfi >= 200 -> Berlin.MILD
        pfi >= 100 -> Berlin.MODERATE
        else -> Berlin.SEVERE
    }

    // ---------- 8bis. Equilibrio acidobásico integrado (v2.8.1) ----------

    /** Tipo de trastorno acidobásico detectado. */
    enum class AcidBaseType {
        NORMAL, METABOLIC_ACIDOSIS, METABOLIC_ALKALOSIS,
        RESPIRATORY_ACIDOSIS, RESPIRATORY_ALKALOSIS, MIXED
    }

    /** Grado de compensación del trastorno primario. */
    enum class Compensation { NONE, ADEQUATE, INADEQUATE }

    /**
     * Resultado del análisis acidobásico con las entradas de la gasometría:
     * pH, PaCO2, HCO3⁻ y exceso de bases (EB). Si falta HCO3 se estima desde
     * el EB (HCO3 ≈ 24 + EB) y viceversa (EB ≈ HCO3 − 24).
     */
    data class AcidBase(
        val pH: Double,          // 0 = no aportado
        val paco2: Double,
        val hco3: Double,        // efectivo (aportado o estimado desde EB)
        val be: Double,          // efectivo (aportado o estimado desde HCO3)
        val acidemia: Int,       // -1 acidemia · 0 normal/compensado · +1 alcalemia · 2 pH no aportado
        val primary: AcidBaseType,
        val mixed: Boolean,      // trastorno mixto detectado
        val respComp: Compensation,  // compensación respiratoria del primario metabólico
        val metComp: Compensation,   // compensación metabólica del primario respiratorio
        val respAcute: Boolean?      // primario respiratorio: agudo (true) / crónico (false) / n/d (null)
    )

    /**
     * Análisis integrado del equilibrio acidobásico (v2.8.1, pedido del autor
     * clínico: «decir qué desequilibrio tiene: acidosis, alcalosis, metabólica,
     * respiratoria o trastorno mixto»).
     *
     * Reglas aplicadas:
     *  · Acidemia/alcalemia por pH (< 7.35 / > 7.45).
     *  · Primario: metabólico si HCO3 fuera de 22–26; respiratorio si PaCO2
     *    fuera de 35–45; ambos alterados en la misma dirección → mixto.
     *  · Compensación esperada: Winters (metacid: PaCO2esp = 1,5·HCO3 + 8 ± 2),
     *    alcalosis metabólica (PaCO2esp = 0,7·(HCO3−24) + 40 ± 5), acidosis
     *    respiratoria (HCO3esp = 24 + (PaCO2−40)/10 aguda, ×4 crónica),
     *    alcalosis respiratoria (HCO3esp = 24 − 2·(40−PaCO2)/10 aguda, −5 crónica).
     *  · Fuera de la ventana esperada → trastorno mixto (compensación inadecuada).
     */
    fun acidBaseAnalysis(pHIn: Double, paco2: Double, hco3In: Double, beIn: Double): AcidBase {
        val hasHco3 = hco3In > 0.0
        val hco3 = if (hasHco3) hco3In else (24.0 + beIn).coerceAtLeast(0.0)
        val be = if (beIn != 0.0) beIn else hco3 - 24.0
        val hasPh = pHIn > 0.0

        val acidemia = when {
            !hasPh -> 2
            pHIn < 7.35 -> -1
            pHIn > 7.45 -> 1
            else -> 0
        }

        val metAcid = hco3 in 0.001..21.9
        val metAlk = hco3 > 26.0
        val respAcid = paco2 > 45.0
        val respAlk = paco2 in 0.001..34.9

        // Primario y mixto «de entrada», ponderados por la dirección del pH:
        // en acidemia el primario es el componente ACIDIFICANTE (el contrario
        // es compensación); en alcalemia, el alcalinizante. Con pH normal o
        // sin pH, el primario se deduce del componente alterado.
        val (primary, entryMixed) = when {
            acidemia == -1 && metAcid && respAcid -> AcidBaseType.MIXED to true
            acidemia == -1 && metAcid -> AcidBaseType.METABOLIC_ACIDOSIS to false
            acidemia == -1 && respAcid -> AcidBaseType.RESPIRATORY_ACIDOSIS to false
            acidemia == 1 && metAlk && respAlk -> AcidBaseType.MIXED to true
            acidemia == 1 && metAlk -> AcidBaseType.METABOLIC_ALKALOSIS to false
            acidemia == 1 && respAlk -> AcidBaseType.RESPIRATORY_ALKALOSIS to false
            metAcid && respAcid -> AcidBaseType.MIXED to true   // pH normal: se anulan
            metAlk && respAlk -> AcidBaseType.MIXED to true
            metAcid -> AcidBaseType.METABOLIC_ACIDOSIS to false
            metAlk -> AcidBaseType.METABOLIC_ALKALOSIS to false
            respAcid -> AcidBaseType.RESPIRATORY_ACIDOSIS to false
            respAlk -> AcidBaseType.RESPIRATORY_ALKALOSIS to false
            else -> AcidBaseType.NORMAL to false
        }

        var mixed = entryMixed
        var respComp = Compensation.NONE
        var metComp = Compensation.NONE
        var respAcute: Boolean? = null

        when (primary) {
            AcidBaseType.METABOLIC_ACIDOSIS -> {
                // Winters: PaCO2 esperada = 1,5 × HCO3 + 8 (± 2)
                val esp = 1.5 * hco3 + 8.0
                respComp = if (paco2 in (esp - 2.0)..(esp + 2.0)) Compensation.ADEQUATE
                else Compensation.INADEQUATE
                if (respComp == Compensation.INADEQUATE) mixed = true
            }
            AcidBaseType.METABOLIC_ALKALOSIS -> {
                // PaCO2 esperada = 0,7 × ΔHCO3 + 40 (± 5)
                val esp = 0.7 * (hco3 - 24.0) + 40.0
                respComp = if (paco2 in (esp - 5.0)..(esp + 5.0)) Compensation.ADEQUATE
                else Compensation.INADEQUATE
                if (respComp == Compensation.INADEQUATE) mixed = true
            }
            AcidBaseType.RESPIRATORY_ACIDOSIS -> {
                val delta = (paco2 - 40.0) / 10.0
                val espAcute = 24.0 + delta
                val espChronic = 24.0 + 4.0 * delta
                when {
                    hco3 in (espAcute - 2.0)..(espAcute + 2.0) -> {
                        respAcute = true; metComp = Compensation.ADEQUATE
                    }
                    hco3 in (espChronic - 2.0)..(espChronic + 2.0) -> {
                        respAcute = false; metComp = Compensation.ADEQUATE
                    }
                    hco3 > espChronic + 2.0 -> {
                        respAcute = false; metComp = Compensation.INADEQUATE; mixed = true
                    }
                    else -> {
                        respAcute = true; metComp = Compensation.INADEQUATE; mixed = true
                    }
                }
            }
            AcidBaseType.RESPIRATORY_ALKALOSIS -> {
                val delta = (40.0 - paco2) / 10.0
                val espAcute = 24.0 - 2.0 * delta
                val espChronic = 24.0 - 5.0 * delta
                when {
                    hco3 in (espAcute - 2.0)..(espAcute + 2.0) -> {
                        respAcute = true; metComp = Compensation.ADEQUATE
                    }
                    hco3 in (espChronic - 2.0)..(espChronic + 2.0) -> {
                        respAcute = false; metComp = Compensation.ADEQUATE
                    }
                    hco3 < espChronic - 2.0 -> {
                        respAcute = false; metComp = Compensation.INADEQUATE; mixed = true
                    }
                    else -> {
                        respAcute = true; metComp = Compensation.INADEQUATE; mixed = true
                    }
                }
            }
            AcidBaseType.MIXED, AcidBaseType.NORMAL -> { /* nada extra */ }
        }

        return AcidBase(
            pH = pHIn, paco2 = paco2, hco3 = hco3, be = be,
            acidemia = acidemia, primary = primary, mixed = mixed,
            respComp = respComp, metComp = metComp, respAcute = respAcute
        )
    }

    // ---------- 9. Dosis máxima de anestésicos locales ----------

    /** Especificación clínica de un anestésico local (sin textos de UI). */
    data class LaSpec(
        val name: String,
        val plainMgKg: Double, val plainCapMg: Double,      // adulto sin adrenalina
        val epiMgKg: Double, val epiCapMg: Double,          // adulto con adrenalina
        val pedPlainMgKg: Double, val pedPlainCapMg: Double,
        val pedEpiMgKg: Double, val pedEpiCapMg: Double,
        val typicalConcMgMl: Double                          // concentración habitual, mg/mL
    )

    /** Tabla de referencia estándar (dosis máximas por vía infiltrativa/periférica). */
    val LA_SPECS = listOf(
        LaSpec("Lidocaína", 4.5, 300.0, 7.0, 500.0, 4.5, 300.0, 7.0, 500.0, 10.0),
        LaSpec("Bupivacaína", 2.5, 175.0, 3.0, 225.0, 2.0, 100.0, 2.5, 175.0, 5.0),
        LaSpec("Levobupivacaína", 2.0, 150.0, 2.5, 250.0, 2.0, 100.0, 2.5, 175.0, 5.0),
        LaSpec("Ropivacaína", 3.0, 200.0, 3.0, 225.0, 2.5, 150.0, 2.5, 175.0, 7.5),
        LaSpec("Mepivacaína", 4.4, 400.0, 7.0, 550.0, 4.0, 300.0, 5.4, 400.0, 15.0),
        LaSpec("Prilocaína", 6.0, 400.0, 9.0, 600.0, 6.0, 300.0, 8.0, 500.0, 20.0),
        LaSpec("Articaína", 7.0, 500.0, 7.0, 500.0, 5.0, 250.0, 5.0, 250.0, 40.0),
        LaSpec("2-Cloroprocaina", 11.0, 800.0, 14.0, 1000.0, 8.0, 500.0, 10.0, 600.0, 30.0)
    )

    data class LaMax(
        val mgPerKg: Double,
        val absoluteCapMg: Double,
        val maxMg: Double,       // min(peso × mg/kg, límite absoluto)
        val maxMl: Double        // maxMg / concentración (0 si la concentración no es válida)
    )

    /** Dosis máxima segura (maxLocalAnesthetic, contrato §5.2). */
    fun localAnestheticMax(
        spec: LaSpec,
        weightKg: Double,
        withEpinephrine: Boolean,
        pediatric: Boolean,
        concMgMl: Double
    ): LaMax {
        val mgKg = when {
            pediatric && withEpinephrine -> spec.pedEpiMgKg
            pediatric -> spec.pedPlainMgKg
            withEpinephrine -> spec.epiMgKg
            else -> spec.plainMgKg
        }
        val capMg = when {
            pediatric && withEpinephrine -> spec.pedEpiCapMg
            pediatric -> spec.pedPlainCapMg
            withEpinephrine -> spec.epiCapMg
            else -> spec.plainCapMg
        }
        val valid = weightKg > 0 && mgKg > 0
        val maxMg = if (valid) min(weightKg * mgKg, capMg) else 0.0
        val maxMl = if (valid && concMgMl > 0) maxMg / concMgMl else 0.0
        return LaMax(mgKg, capMg, maxMg, maxMl)
    }
    // ---------- 10. Temas quirúrgicos PRO+ (v2.0.0) ----------

    /** PAM = PAD + (PAS − PAD)/3 (fórmula estándar). */
    fun meanArterial(psMmHg: Double, pdMmHg: Double): Double =
        pdMmHg + (psMmHg - pdMmHg) / 3.0

    /** Presión de perfusión cerebral = PAM − PIC. */
    fun cpp(mapMmHg: Double, icpMmHg: Double): Double = mapMmHg - icpMmHg

    data class AnhResult(
        val ebvMl: Double,
        val anhVolumeMl: Double,      // volumen extraído con sangre entera
        val ablAfterMl: Double,       // pérdida permitida después del ANH
        val hctFinalAfterAbl: Double
    )

    /** Hemodilución aguda normovolémica (ANH): volumen extraíble y sangrado permitido restante. */
    fun anh(ebvMl: Double, hctInitial: Double, hctTarget: Double, hctMinimum: Double): AnhResult {
        val avg1 = (hctInitial + hctTarget) / 2.0
        val anhVol = if (avg1 > 0) ebvMl * (hctInitial - hctTarget) / avg1 else 0.0
        val avg2 = (hctTarget + hctMinimum) / 2.0
        val abl = if (avg2 > 0) ebvMl * (hctTarget - hctMinimum) / avg2 else 0.0
        return AnhResult(ebvMl, max(0.0, anhVol), max(0.0, abl), hctMinimum)
    }

    data class MeldResult(val meld: Double, val meldNa: Double, val mortality90d: String)

    /** MELD-Na (trasplante hepático). Creat 1–4 mg/dL (4 si HD 2×/semana), bilirrubina/INR mín 1, Na 125–137. */
    fun meldNa(
        bilirubinMgDl: Double, inr: Double, creatinineMgDl: Double,
        sodiumMmolL: Double, dialysisTwiceWeek: Boolean
    ): MeldResult {
        val bili = max(bilirubinMgDl, 1.0)
        val cr = if (dialysisTwiceWeek) 4.0 else max(creatinineMgDl, 1.0).coerceAtMost(4.0)
        val na = sodiumMmolL.coerceIn(125.0, 137.0)
        val meld = (3.78 * ln(bili) + 11.2 * ln(max(inr, 1.0)) + 9.57 * ln(cr) + 6.43).coerceIn(6.0, 40.0)
        val meldNaRaw = meld + 1.32 * (137.0 - na) - 0.033 * meld * (137.0 - na)
        val meldNaV = meldNaRaw.coerceIn(6.0, 40.0)
        val mortality = when {
            meldNaV >= 30 -> "Mortalidad 90 días ≥ 50 % — prioridad alta"
            meldNaV >= 20 -> "Mortalidad 90 días ≈ 20–30 %"
            meldNaV >= 15 -> "Mortalidad 90 días ≈ 10–15 %"
            else -> "Mortalidad 90 días < 10 %"
        }
        return MeldResult(round(meld * 10) / 10, round(meldNaV * 10) / 10, mortality)
    }

    /** Shunt Qp/Qs por oximetría: (SaO2 − SvO2)/(SpvO2 − SpaO2) en fracciones. */
    fun qpQs(sao2Aorta: Double, svo2Mixed: Double, spvo2PulmVen: Double, spao2PulmArt: Double): Double {
        val den = spvo2PulmVen - spao2PulmArt
        val num = sao2Aorta - svo2Mixed
        if (den <= 0.0) return 0.0
        return num / den
    }

    /** Contenido arterial de O2 (mL/dL): 1,34 × Hb × SaO2 + 0,0031 × PaO2. */
    fun caO2(hbGdl: Double, sao2Frac: Double, pao2MmHg: Double): Double =
        1.34 * hbGdl * sao2Frac + 0.0031 * pao2MmHg

    /** Entrega de O2 (mL/min): DO2 = CO × CaO2 × 10. */
    fun do2(coLMin: Double, caO2MlDl: Double): Double = coLMin * caO2MlDl * 10.0

    /** CO por Fick: VO2(mL/min) / [10 × (CaO2 − CvO2)]. */
    fun fickCo(vo2MlMin: Double, caO2MlDl: Double, cvO2MlDl: Double): Double {
        val diff = caO2MlDl - cvO2MlDl
        if (diff <= 0.0) return 0.0
        return vo2MlMin / (10.0 * diff)
    }

    /** Resistencia vascular sistémica (dyn·s/cm⁵): (PAM − PVC) × 80 / CO. */
    fun svr(mapMmHg: Double, cvpMmHg: Double, coLMin: Double): Double {
        if (coLMin <= 0.0) return 0.0
        return (mapMmHg - cvpMmHg) * 80.0 / coLMin
    }

    /** Resistencia vascular pulmonar (dyn·s/cm⁵): (PAPm − PAWP) × 80 / CO. */
    fun pvr(mpapMmHg: Double, pawpMmHg: Double, coLMin: Double): Double {
        if (coLMin <= 0.0) return 0.0
        return (mpapMmHg - pawpMmHg) * 80.0 / coLMin
    }

    /** BSA (Mosteller, m²): √(altura × peso / 3600). */
    fun bsa(heightCm: Double, weightKg: Double): Double =
        kotlin.math.sqrt(max(0.0, heightCm * weightKg / 3600.0))

    /** Flujo de bomba CEC (L/min): BSA × IC (2,2–2,8 L/min/m²). */
    fun pumpFlow(bsaM2: Double, ci: Double): Double = bsaM2 * ci

    /** Heparina CEC: UI = mg × 100 (1 mg = 100 UI). */
    fun heparinUnits(mgPerKg: Double, weightKg: Double): Double = mgPerKg * 100.0 * weightKg

    /** Unidades de CGR para subir Hb: ΔHb (g/dL) × peso / 70 (1 U ≈ +1 g/dL en 70 kg). */
    fun rbcUnits(weightKg: Double, hbNow: Double, hbTarget: Double): Double =
        max(0.0, (hbTarget - hbNow) * weightKg / 70.0)

    /** MgSO4 (eclampsia): carga 4 g + mantenimiento 1–2 g/h; devuelve mL/h para ampolla 2 g/10 mL (20 %). */
    fun mgso4InfusionMlH(gramsPerHour: Double, ampollaGrams: Double = 2.0, ampollaMl: Double = 10.0): Double =
        gramsPerHour / ampollaGrams * ampollaMl

    /** RR sugerida en ventilación unipulmonar: MV objetivo (mL/min) / VT (mL). */
    fun suggestedRr(minuteVentilationMlMin: Double, vtMl: Double): Double {
        if (vtMl <= 0.0) return 0.0
        return round(minuteVentilationMlMin / vtMl)
    }

    /** Nueva FR para corregir ETCO2: FR × ETCO2 medida / ETCO2 deseada. */
    fun rrForEtco2(currentRr: Double, etco2Measured: Double, etco2Desired: Double): Double {
        if (etco2Desired <= 0.0) return 0.0
        return round(currentRr * etco2Measured / etco2Desired)
    }

    // ---------- 11. TCI — infusión con diana (bombas / jeringa perfusora) v2.1.0 ----------

    /**
     * Parámetros de un modelo farmacocinético de 3 compartimentos con sitio
     * efecto: volúmenes en LITROS y constantes k en 1/min. El compartimento
     * del sitio efecto comparte el volumen de V1 (Ce = Ae/V1, estándar).
     */
    data class Pk3(
        val v1: Double, val v2: Double, val v3: Double,
        val k10: Double, val k12: Double, val k13: Double,
        val k21: Double, val k31: Double,
        val ke0: Double
    ) {
        val clearanceLMin: Double get() = k10 * v1
    }

    /**
     * Modelo de MARSH (propofol, solo peso): V1/V2/V3 en L/kg y k fijos.
     * Marsh BJ et al., Br J Anaesth 1991;67:41-48 (implementación estándar
     * de las bombas: k10 0,119 · k12 0,112 · k13 0,041 · k21 0,070 · k31 0,0035).
     * ke0 ≈ 0,26 1/min (t½ke0 ≈ 2,6 min).
     */
    fun marshPropofol(weightKg: Double): Pk3 {
        val w = max(1.0, weightKg)
        return Pk3(
            v1 = 0.228 * w, v2 = 0.366 * w, v3 = 2.893 * w,
            k10 = 0.119, k12 = 0.112, k13 = 0.041,
            k21 = 0.070, k31 = 0.0035, ke0 = 0.26
        )
    }

    /**
     * LBM de Janmahasatian 2005 (kg) — covariable de Schnider/Minto.
     * Hombre: 9270·P / (6680 + 216·IMC); Mujer: 9270·P / (8780 + 244·IMC).
     */
    fun leanBodyMass(weightKg: Double, heightCm: Double, male: Boolean): Double {
        val h = max(1.0, heightCm) / 100.0
        val bmi = weightKg / (h * h)
        val denom = if (male) 6680.0 + 216.0 * bmi else 8780.0 + 244.0 * bmi
        return max(20.0, 9270.0 * weightKg / denom)
    }

    /**
     * Modelo de SCHNIDER (propofol, con edad/talla/sexo): V1 4,27 L;
     * V2 18,9 − 0,391·(edad−53); V3 238 L; Cl1 1,89 − 0,0456·(edad−53);
     * Cl2 1,29 − 0,024·(edad−53); Cl3 0,336 L/min; ke0 0,456 1/min.
     * Schnider TW et al., Anesthesiology 1998;88:1170-1182.
     */
    fun schniderPropofol(ageYears: Double, weightKg: Double, heightCm: Double, male: Boolean): Pk3 {
        val age = ageYears.coerceIn(18.0, 100.0)
        val d = age - 53.0
        val v1 = 4.27
        val v2 = max(2.0, 18.9 - 0.391 * d)
        val v3 = 238.0
        val cl1 = max(0.8, 1.89 - 0.0456 * d)
        val cl2 = max(0.3, 1.29 - 0.024 * d)
        val cl3 = 0.336
        val w = max(1.0, weightKg)
        // Nota: la talla y el sexo solo influyen en variantes del modelo que
        // ajustan V1 por LBM; el modelo final 1998 usa edad y peso.
        leanBodyMass(w, heightCm, male)
        return Pk3(
            v1 = v1, v2 = v2, v3 = v3,
            k10 = cl1 / v1, k12 = cl2 / v1, k13 = cl3 / v1,
            k21 = cl2 / v2, k31 = cl3 / v3,
            ke0 = 0.456
        )
    }

    /**
     * Modelo de MINTO (remifentanilo, con edad/talla/sexo por LBM):
     * V1 = 5,1 − 0,0201·(edad−40) + 0,072·(LBM−55);
     * V2 = 9,82 − 0,0811·(edad−40) + 0,108·(LBM−55); V3 = 5,42 L;
     * Cl1 = 2,6 − 0,0162·(edad−40) + 0,0191·(LBM−55);
     * Cl2 = 2,05 − 0,0301·(edad−40); Cl3 = 0,076 − 0,00113·(edad−40);
     * ke0 = 0,595 − 0,007·(edad−40). Minto CF et al., Anesthesiology 1997;86:24-33.
     */
    fun mintoRemifentanil(ageYears: Double, weightKg: Double, heightCm: Double, male: Boolean): Pk3 {
        val age = ageYears.coerceIn(18.0, 90.0)
        val d = age - 40.0
        val lbm = leanBodyMass(max(1.0, weightKg), heightCm, male) - 55.0
        val v1 = max(1.5, 5.1 - 0.0201 * d + 0.072 * lbm)
        val v2 = max(2.0, 9.82 - 0.0811 * d + 0.108 * lbm)
        val v3 = 5.42
        val cl1 = max(0.5, 2.6 - 0.0162 * d + 0.0191 * lbm)
        val cl2 = max(0.3, 2.05 - 0.0301 * d)
        val cl3 = max(0.01, 0.076 - 0.00113 * d)
        val ke0 = max(0.1, 0.595 - 0.007 * d)
        return Pk3(
            v1 = v1, v2 = v2, v3 = v3,
            k10 = cl1 / v1, k12 = cl2 / v1, k13 = cl3 / v1,
            k21 = cl2 / v2, k31 = cl3 / v3,
            ke0 = ke0
        )
    }

    /** Punto de la tabla de velocidad: t (min), velocidad (mL/h y mg/h), Ce acumulada (% del objetivo). */
    data class TciPoint(
        val tMin: Double,
        val rateMlH: Double,
        val rateMgH: Double,
        val cumulativeMl: Double,
        val cePct: Double
    )

    /** Plan BET (Bolus-Elimination-Transfer) para una diana dada. */
    data class TciPlan(
        val bolusMg: Double,        // bolo inicial para Cp = diana
        val bolusMl: Double,        // volumen del bolo con la dilución elegida
        val rate0MlH: Double,       // velocidad inicial (t = 0)
        val rate0MgH: Double,
        val points: List<TciPoint>,
        val t90CeMin: Double,       // tiempo a 90 % de Ce objetivo
        val clLMin: Double,
        val v1L: Double
    )

    /**
     * Esquema BET exacto: con bolo = diana·V1 y velocidad
     * r(t) = diana·V1·(k10 + k12·e^(−k21·t) + k13·e^(−k31·t)) la Cp se
     * mantiene en la diana; la Ce asciende como diana·(1 − e^(−ke0·t)).
     * En diana de EFECTO se usa el mismo plan (Cp no supera el objetivo:
     * estrategia conservadora sin overshoot) y se muestra la Ce estimada.
     *
     * @param targetMgMl diana en mg/mL (µg/mL ÷ 1000 · ng/mL ÷ 1 000 000)
     * @param concMgMl concentración de la jeringa en mg/mL
     */
    fun tciPlan(p: Pk3, targetMgMl: Double, concMgMl: Double): TciPlan {
        if (targetMgMl <= 0.0 || concMgMl <= 0.0) {
            return TciPlan(0.0, 0.0, 0.0, 0.0, emptyList(), 0.0, p.clearanceLMin, p.v1)
        }
        val v1Ml = p.v1 * 1000.0
        val bolusMg = targetMgMl * v1Ml
        fun rateMgMin(tMin: Double): Double =
            targetMgMl * v1Ml * (p.k10 + p.k12 * kotlin.math.exp(-p.k21 * tMin) + p.k13 * kotlin.math.exp(-p.k31 * tMin))
        fun cumulativeMg(tMin: Double): Double {
            // ∫r dt = diana·V1·[k10·t + (k12/k21)(1−e^(−k21 t)) + (k13/k31)(1−e^(−k31 t))]
            val t1 = if (p.k21 > 0) (p.k12 / p.k21) * (1.0 - kotlin.math.exp(-p.k21 * tMin)) else p.k12 * tMin
            val t2 = if (p.k31 > 0) (p.k13 / p.k31) * (1.0 - kotlin.math.exp(-p.k31 * tMin)) else p.k13 * tMin
            return targetMgMl * v1Ml * (p.k10 * tMin + t1 + t2) + bolusMg
        }
        val times = listOf(0.0, 1.0, 2.0, 5.0, 10.0, 15.0, 20.0, 30.0, 45.0, 60.0)
        val pts = times.map { t ->
            val mgH = rateMgMin(t) * 60.0
            TciPoint(
                tMin = t,
                rateMgH = mgH,
                rateMlH = mgH / concMgMl,
                cumulativeMl = cumulativeMg(t) / concMgMl,
                cePct = (1.0 - kotlin.math.exp(-p.ke0 * t)) * 100.0
            )
        }
        return TciPlan(
            bolusMg = bolusMg,
            bolusMl = bolusMg / concMgMl,
            rate0MlH = pts[0].rateMlH,
            rate0MgH = pts[0].rateMgH,
            points = pts,
            t90CeMin = kotlin.math.ln(10.0) / p.ke0,
            clLMin = p.clearanceLMin,
            v1L = p.v1
        )
    }

    // ---------- Jeringa perfusora y dosis neuraxial (v2.6) ----------

    /** Concentración de la jeringa en µg/mL a partir de mg y mL. */
    fun syringeConcUgMl(mg: Double, ml: Double): Double =
        if (ml <= 0.0) 0.0 else mg * 1000.0 / ml

    /** Dosis (en la unidad elegida) → µg/min. Unidades: µg/kg/min, µg/kg/h, mg/kg/h, µg/min, mg/h. */
    fun syringeDoseToUgMin(dose: Double, unit: String, weightKg: Double): Double = when (unit) {
        "µg/kg/min" -> dose * weightKg
        "µg/kg/h" -> dose * weightKg / 60.0
        "mg/kg/h" -> dose * weightKg * 1000.0 / 60.0
        "µg/min" -> dose
        "mg/h" -> dose * 1000.0 / 60.0
        else -> 0.0
    }

    /** mL/h con concentración µg/mL → µg/min. */
    fun syringeMlHToUgMin(mlh: Double, concUgMl: Double): Double =
        if (concUgMl <= 0.0) 0.0 else mlh * concUgMl / 60.0

    /** µg/min → mL/h con concentración µg/mL. */
    fun syringeUgMinToMlH(ugMin: Double, concUgMl: Double): Double =
        if (concUgMl <= 0.0) 0.0 else ugMin * 60.0 / concUgMl

    /** Autonomía de la jeringa (h) con un volumen y una velocidad. */
    fun syringeDurationH(volumeMl: Double, rateMlH: Double): Double =
        if (rateMlH <= 0.0) 0.0 else volumeMl / rateMlH

    /** Dosis espinal de bupivacaína hiperbárica 0,5 %: 0,06 mg × altura (cm). */
    fun spinalBupivacaineMg(heightCm: Double): Double = 0.06 * max(100.0, heightCm)

    /** Volumen de carga epidural: 1,5 mL × dermatomas + 4 mL. */
    fun epiduralLoadMl(segments: Int): Double = 1.5 * max(0, segments) + 4.0

    // ---------- Ventilación ampliada (v2.5: Cst, ΔP, Raw, RSBI, Bohr, P/A, OI) ----------

    /** Pesos predichos y volumen corriente protector ARDSNet (4/6/8 mL/kg PBW). */
    data class VtTargets(val pbwKg: Double, val vt4Ml: Double, val vt6Ml: Double, val vt8Ml: Double)

    fun vtTargets(heightCm: Double, male: Boolean): VtTargets {
        val pbw = (if (male) 50.0 else 45.5) + 0.91 * (heightCm - 152.4)
        return VtTargets(pbw, pbw * 4.0, pbw * 6.0, pbw * 8.0)
    }

    /** Ventilación minuto (mL/min) = VT × FR. */
    fun minuteVentilation(vtMl: Double, rate: Double): Double = vtMl * rate

    /** Fracción de espacio muerto de Bohr: (PaCO2 − ETCO2)/PaCO2. */
    fun bohrDeadSpaceFraction(paco2: Double, etco2: Double): Double =
        if (paco2 <= 0.0) 0.0 else (paco2 - etco2) / paco2

    /** Ventilación alveolar = VT × (1 − Vd/Vt) × FR. */
    fun alveolarVentilation(vtMl: Double, rate: Double, deadSpaceFraction: Double): Double =
        vtMl * (1.0 - deadSpaceFraction) * rate

    /** Compliance estática = VT/(meseta − PEEP); 0 si meseta ≤ PEEP. */
    fun complianceStatic(vtMl: Double, plateau: Double, peep: Double): Double =
        if (plateau <= peep) 0.0 else vtMl / (plateau - peep)

    /** Compliance dinámica = VT/(pico − PEEP); 0 si pico ≤ PEEP. */
    fun complianceDynamic(vtMl: Double, peak: Double, peep: Double): Double =
        if (peak <= peep) 0.0 else vtMl / (peak - peep)

    /** Clasificación de la compliance estática (mL/cmH2O). */
    fun complianceClass(cst: Double): String = when {
        cst <= 0.0 -> "Sin datos suficientes"
        cst < 30.0 -> "Severamente reducida (< 30 mL/cmH2O): revisar reclutamiento, PEEP y sobredistensión"
        cst < 50.0 -> "Reducida (30–49 mL/cmH2O)"
        cst < 60.0 -> "Límite inferior (50–59 mL/cmH2O)"
        else -> "Normal (≥ 60 mL/cmH2O)"
    }

    /** Índice P/A: PaO2 / PAO2 con PAO2 = FiO2·(713) − PaCO2/0,8 (FiO2 en %). */
    fun pao2OverPao2(pao2: Double, fio2Pct: Double, paco2: Double): Double {
        val pao2alv = (fio2Pct / 100.0) * 713.0 - paco2 / 0.8
        return if (pao2alv <= 0.0) 0.0 else pao2 / pao2alv
    }

    /** Clasificación del índice P/A. */
    fun pao2OverPao2Class(ratio: Double): String = when {
        ratio <= 0.0 -> "Sin datos suficientes"
        ratio >= 0.8 -> "Normal (P/A ≥ 0,8)"
        ratio >= 0.6 -> "Levemente reducida (0,6–0,79)"
        ratio >= 0.5 -> "Moderadamente reducida (0,5–0,59)"
        else -> "Alteración grave (P/A < 0,5)"
    }

    /** Índice de oxigenación OI = PAM × FiO2 × 100 / PaO2 (FiO2 en %). */
    fun oxygenationIndex(meanAirwayPressure: Double, fio2Pct: Double, pao2: Double): Double =
        if (pao2 <= 0.0) 0.0 else meanAirwayPressure * (fio2Pct / 100.0) * 100.0 / pao2

    // ---------- Función renal y estómago de riesgo (v2.7.0) ----------

    /** Depuración de creatinina estimada (Cockcroft-Gault, mL/min). */
    fun cockcroftGault(ageYears: Double, weightKg: Double, creatinineMgDl: Double, female: Boolean): Double {
        if (ageYears <= 0.0 || weightKg <= 0.0 || creatinineMgDl <= 0.0) return 0.0
        val v = (140.0 - ageYears) * weightKg / (72.0 * creatinineMgDl)
        return if (female) v * 0.85 else v
    }

    /** Interpretación de la ClCr (mL/min). */
    fun cockcroftGaultClass(clcr: Double): String = when {
        clcr <= 0.0 -> "Sin datos suficientes"
        clcr < 15.0 -> "Falla renal terminal (< 15): ajuste severo, evitar nefrotóxicos"
        clcr < 30.0 -> "Insuficiencia renal grave (15–29): reducir dosis de eliminación renal"
        clcr < 60.0 -> "Insuficiencia renal moderada (30–59): ajustar dosis y vigilar"
        clcr < 90.0 -> "Función levemente disminuida (60–89)"
        else -> "Función renal normal (≥ 90 mL/min)"
    }

    /** Volumen gástrico estimado por ecografía del antro (Perlas 2013, mL). */
    fun gastricVolumePerlas(antrumAreaCm2: Double, ageYears: Double): Double =
        27.0 + 14.6 * antrumAreaCm2 - 1.28 * ageYears

    /** Riesgo de broncoaspiración según el volumen estimado (mL/kg). */
    fun gastricRiskClass(volumeMl: Double, weightKg: Double): String {
        if (weightKg <= 0.0) return "Sin datos suficientes: indique el peso"
        val perKg = volumeMl / weightKg
        return when {
            perKg < 0.8 -> "Volumen bajo (< 0,8 mL/kg): estómago vacío esperado"
            perKg <= 1.5 -> "Volumen moderado (0,8–1,5 mL/kg): estómago de riesgo — tomar precauciones"
            else -> "Volumen alto (> 1,5 mL/kg): estómago lleno — riesgo de broncoaspiración"
        }
    }
}

/** Deep links internos (contrato §11.3): cronos://<sección> → pestaña. */
object DeepLinks {
    const val SCHEME = "cronos"

    /** Devuelve el índice de pestaña para el host del deep link, o null si no se reconoce. */
    fun tabFor(host: String?): Int? = when (host?.lowercase()) {
        "inicio" -> 0
        "emergencias" -> 1
        "farmacos" -> 2
        "gases" -> 3
        "calculadoras" -> 4
        "escalas" -> 5
        "complicaciones" -> 6
        "premedicacion" -> 7
        "soluciones" -> 8
        "clinica" -> 9
        "bibliografia" -> 10
        "expediente" -> 11
        "perlas" -> 12
        "maquina" -> 13
        "checklist" -> 14
        "ajustes" -> 15
        "temario" -> 16
        "imagenes" -> 17
        "escuela" -> 18
        "tutor" -> 19
        "crisis" -> 20        // v2.8.1: deep link del simulador (faltaba en v2.8.0)
        "buscador" -> 21      // v2.8.1: deep link del buscador global
        else -> null
    }
}
