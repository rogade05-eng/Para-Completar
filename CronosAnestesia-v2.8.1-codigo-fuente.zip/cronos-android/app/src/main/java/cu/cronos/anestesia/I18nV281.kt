package cu.cronos.anestesia

/*
 * ============================================================================
 *  OLA v2.8.1 — Revisión del código fuente publicado + feedback clínico del
 *  autor (Neo85 Romy, 5/11/2026). Cubre: perlas nuevas (fibrilación
 *  auricular, transfusiones/hemoderivados, vía aérea en politraumatizados),
 *  diagnóstico acidobásico de la gasometría, calculadora de sangrado/hematocrito,
 *  buscador global de temas y movimiento de Pediatría al 4.º año del temario.
 *  Clave = texto original en español; falta → degradación a ES.
 * ============================================================================
 */

object I18nV281 {

    val EN: Map<String, String> = mapOf(
        // --- Calculadora Sangrado (hematocrito) — v2.8.1 ---
        "Peso" to "Weight",
        "Si solo dispone de Hb: Hto ≈ 3 × Hb (Hb 10 g/dL ≈ Hto 30 %)." to
            "If you only have Hb: Hct ≈ 3 × Hb (Hb 10 g/dL ≈ Hct 30%).",
        "Sangrado estimado (opcional)" to "Estimated blood loss (optional)",
        "Complete peso, Hto inicial y Hto mínimo para calcular." to
            "Enter weight, initial Hct and minimum Hct to calculate.",
        "El Hto mínimo debe ser MENOR que el Hto inicial (revise si los intercambió)." to
            "The minimum Hct must be LOWER than the initial Hct (check whether you swapped them).",
        "Hto final estimado" to "Estimated final Hct",
        "Hb final estimada" to "Estimated final Hb",

        // --- Gasometría: equilibrio acidobásico — v2.8.1 ---
        "HCO3 (bicarbonato)" to "HCO3 (bicarbonate)",
        "EB (exceso de bases)" to "BE (base excess)",
        "Equilibrio acidobásico: introduzca pH, PaCO2 y al menos uno de HCO3 o EB (exceso de bases); la app indica el desequilibrio (acidosis/alcalosis, metabólica/respiratoria o mixto)." to
            "Acid-base balance: enter pH, PaCO2 and at least one of HCO3 or BE (base excess); the app states the disorder (acidosis/alkalosis, metabolic/respiratory or mixed).",
        "Faltan HCO3 y EB: introduzca al menos uno de los dos para clasificar el desequilibrio." to
            "HCO3 and BE are missing: enter at least one of the two to classify the disorder.",
        "Acidemia" to "Acidemia",
        "Alcalemia" to "Alkalemia",
        "pH no aportado" to "pH not provided",
        "pH en rango normal" to "pH within normal range",
        "Estado" to "Status",
        "Acidosis metabólica" to "Metabolic acidosis",
        "Alcalosis metabólica" to "Metabolic alkalosis",
        "Acidosis respiratoria" to "Respiratory acidosis",
        "Alcalosis respiratoria" to "Respiratory alkalosis",
        "Trastorno mixto (metabólico + respiratorio)" to "Mixed disorder (metabolic + respiratory)",
        "Sin trastorno detectado" to "No disorder detected",
        " — aguda" to " — acute",
        " — crónica" to " — chronic",
        "Acidosis respiratoria — aguda" to "Respiratory acidosis — acute",
        "Acidosis respiratoria — crónica" to "Respiratory acidosis — chronic",
        "Alcalosis respiratoria — aguda" to "Respiratory alkalosis — acute",
        "Alcalosis respiratoria — crónica" to "Respiratory alkalosis — chronic",
        "Respiratoria adecuada" to "Respiratory, adequate",
        "Respiratoria inadecuada" to "Respiratory, inadequate",
        "Metabólica adecuada" to "Metabolic, adequate",
        "Metabólica inadecuada" to "Metabolic, inadequate",
        "Equilibrio acidobásico" to "Acid-base balance",
        "HCO3 (efectivo)" to "HCO3 (effective)",
        "EB (efectivo)" to "BE (effective)",
        "Trastorno primario" to "Primary disorder",
        "Compensación" to "Compensation",
        "Sin desequilibrio acidobásico relevante: valores dentro de límites normales." to
            "No relevant acid-base disorder: values within normal limits.",
        "Trastorno mixto: acidosis y alcalosis conviven; analice ambos componentes y su causa." to
            "Mixed disorder: acidosis and alkalosis coexist; analyze both components and their cause.",
        "Acidosis metabólica con compensación respiratoria inadecuada: el cuadro es MIXTO." to
            "Metabolic acidosis with inadequate respiratory compensation: the picture is MIXED.",
        "Alcalosis metabólica con compensación respiratoria inadecuada: el cuadro es MIXTO." to
            "Metabolic alkalosis with inadequate respiratory compensation: the picture is MIXED.",
        "Acidosis respiratoria — aguda con compensación metabólica inadecuada: el cuadro es MIXTO." to
            "Respiratory acidosis — acute with inadequate metabolic compensation: the picture is MIXED.",
        "Acidosis respiratoria — crónica con compensación metabólica inadecuada: el cuadro es MIXTO." to
            "Respiratory acidosis — chronic with inadequate metabolic compensation: the picture is MIXED.",
        "Alcalosis respiratoria — aguda con compensación metabólica inadecuada: el cuadro es MIXTO." to
            "Respiratory alkalosis — acute with inadequate metabolic compensation: the picture is MIXED.",
        "Alcalosis respiratoria — crónica con compensación metabólica inadecuada: el cuadro es MIXTO." to
            "Respiratory alkalosis — chronic with inadequate metabolic compensation: the picture is MIXED.",
        "Acidosis metabólica con compensación respiratoria adecuada." to
            "Metabolic acidosis with adequate respiratory compensation.",
        "Alcalosis metabólica con compensación respiratoria adecuada." to
            "Metabolic alkalosis with adequate respiratory compensation.",
        "Acidosis respiratoria — aguda con compensación metabólica adecuada." to
            "Respiratory acidosis — acute with adequate metabolic compensation.",
        "Acidosis respiratoria — crónica con compensación metabólica adecuada." to
            "Respiratory acidosis — chronic with adequate metabolic compensation.",
        "Alcalosis respiratoria — aguda con compensación metabólica adecuada." to
            "Respiratory alkalosis — acute with adequate metabolic compensation.",
        "Alcalosis respiratoria — crónica con compensación metabólica adecuada." to
            "Respiratory alkalosis — chronic with adequate metabolic compensation.",
        "Reglas del motor: HCO3 normal 22–26 mmol/L, PaCO2 normal 35–45 mmHg. Acidosis metabólica: PaCO2 esperada = 1,5 × HCO3 + 8 (± 2, Winters). Alcalosis metabólica: PaCO2 = 0,7 × ΔHCO3 + 40 (± 5). Respiratoria aguda: ΔHCO3 = +1 (acidosis) o −2 (alcalosis) por cada 10 mmHg; crónica ×4 o −5. EB negativo apoya acidosis metabólica; positivo, alcalosis. Fuera de la ventana esperada = trastorno mixto. Si solo dispone de EB, el HCO3 se estima como 24 + EB (y viceversa)." to
            "Engine rules: normal HCO3 22–26 mmol/L, normal PaCO2 35–45 mmHg. Metabolic acidosis: expected PaCO2 = 1.5 × HCO3 + 8 (± 2, Winters). Metabolic alkalosis: PaCO2 = 0.7 × ΔHCO3 + 40 (± 5). Acute respiratory: ΔHCO3 = +1 (acidosis) or −2 (alkalosis) per 10 mmHg; chronic ×4 or −5. Negative BE supports metabolic acidosis; positive, alkalosis. Outside the expected window = mixed disorder. If only BE is available, HCO3 is estimated as 24 + BE (and vice versa).",

        // --- Buscador global — v2.8.1 ---
        "Buscador de todos los temas" to "Search all topics",
        "Busque en emergencias, fármacos, gases, escalas, complicaciones, premedicación, soluciones, clínica, perlas, temario, escuela, tutor, crisis y calculadoras." to
            "Search emergencies, drugs, gases, scales, complications, premedication, solutions, clinical topics, pearls, residency plan, school, tutor, crisis and calculators.",
        "Buscar tema…" to "Search a topic…",
        "Escriba al menos una letra: la búsqueda ignora tildes y mayúsculas." to
            "Type at least one letter: the search ignores accents and case.",
        "Sin resultados para «%1\$s»." to "No results for “%1\$s”.",
        "%1\$s resultado(s) — toque un resultado para abrir su tema." to
            "%1\$s result(s) — tap a result to open its topic.",
        "Refine la búsqueda: se muestran los primeros 40 resultados." to
            "Refine the search: only the first 40 results are shown.",
        "Emergencias" to "Emergencies",
        "Fármacos" to "Drugs",
        "Gases" to "Gases",
        "Escalas" to "Scales",
        "Complicaciones" to "Complications",
        "Premedicación" to "Premedication",
        "Soluciones" to "Solutions",
        "Clínica · Comorbilidades" to "Clinical · Comorbidities",
        "Clínica · Bloqueos" to "Clinical · Blocks",
        "Clínica · Monitoreo" to "Clinical · Monitoring",
        "Clínica · Preoperatorio" to "Clinical · Preoperative",
        "Clínica · Equipos" to "Clinical · Equipment",
        "Clínica · Quirúrgico" to "Clinical · Surgical",
        "Perlas" to "Pearls",
        "Temario" to "Residency plan",
        "Escuela" to "School",
        "Tutor" to "Tutor",
        "Crisis" to "Crisis",
        "Calculadoras" to "Calculators",
        "Dosis/peso" to "Dose/weight",
        "Peso ideal" to "Ideal weight",
        "Tubo pediátrico" to "Pediatric tube",
        "Sangrado" to "Bleeding",
        "Anestésico local" to "Local anesthetic",
        "Infusión por fármaco (45)" to "Infusion by drug (45)",
        "Bomba TCI" to "TCI pump",
        "Ventilación: Vt y VM" to "Ventilation: Vt and MV",
        "Ventilación mecánica" to "Mechanical ventilation",
        "Función renal (ClCr)" to "Renal function (CrCl)",
        "Ecografía gástrica" to "Gastric ultrasound",

        // --- Perla: Fibrilación auricular perioperatoria ---
        "Fibrilación auricular perioperatoria: tratamiento y manejo" to
            "Perioperative atrial fibrillation: treatment and management",
        "La FA con respuesta ventricular rápida es la arritmia perioperatoria más frecuente: aparece en el postoperatorio de cirugía torácica, cardíaca y abdominal mayor. Tres preguntas ordenan el manejo: ¿estable o inestable?, ¿control de frecuencia o de ritmo?, ¿anticoagular o no? Corrija SIEMPRE los disparadores (electrolitos, dolor, hipovolemia, hipercapnia) antes de culpar al corazón." to
            "AF with rapid ventricular response is the most common perioperative arrhythmia: it appears after thoracic, cardiac and major abdominal surgery. Three questions order management: stable or unstable?, rate or rhythm control?, anticoagulate or not? ALWAYS correct the triggers (electrolytes, pain, hypovolemia, hypercapnia) before blaming the heart.",
        "1. Evaluar estabilidad: hipotensión con hipoperfusión, angina o edema agudo → cardioversión eléctrica sincronizada INMEDIATA (120–200 J bifásico), con sedación si el tiempo lo permite." to
            "1. Assess stability: hypotension with hypoperfusion, angina or acute pulmonary edema → IMMEDIATE synchronized electrical cardioversion (120–200 J biphasic), with sedation if time allows.",
        "2. Estable: control de frecuencia primero — betabloqueante (metoprolol 2,5–5 mg IV lento, repetible) o diltiazem/verapamilo 5–10 mg IV; si hay disfunción del ventrículo izquierdo use amiodarona (los calcioantagonistas deprimen el débito)." to
            "2. Stable: rate control first — beta-blocker (metoprolol 2.5–5 mg IV slowly, repeatable) or diltiazem/verapamil 5–10 mg IV; with left ventricular dysfunction use amiodarone (calcium channel blockers depress cardiac output).",
        "3. Amiodarona: 150–300 mg IV en 20–60 min → 1 mg/min durante 6 h → 0,5 mg/min 18 h; controla la frecuencia y facilita la reversión: es el antiarrítmico de elección con HFrEF." to
            "3. Amiodarone: 150–300 mg IV over 20–60 min → 1 mg/min for 6 h → 0.5 mg/min for 18 h; controls the rate and facilitates conversion: it is the antiarrhythmic of choice with HFrEF.",
        "4. Corregir disparadores: K 4–4,5 mmol/L y Mg ≥ 2 mg/dL (la hipokalemia + hipomagnesemia perpetúan la FA), dolor, hipovolemia, hipercapnia, hipoxia, anemia, fiebre, hipertiroidismo, alcohol y teofilina." to
            "4. Correct triggers: K 4–4.5 mmol/L and Mg ≥ 2 mg/dL (hypokalemia + hypomagnesemia perpetuate AF), pain, hypovolemia, hypercapnia, hypoxia, anemia, fever, hyperthyroidism, alcohol and theophylline.",
        "5. Anticoagulación: FA > 48 h o de duración desconocida → riesgo embólico; la cardioversión electiva exige ≥ 3 semanas de anticoagulación (o ecografía transesofágica que excluya trombo auricular). Postoperatorio: gradúe el riesgo (CHA₂DS₂-VASc) con el equipo tratante." to
            "5. Anticoagulation: AF > 48 h or of unknown duration → embolic risk; elective cardioversion requires ≥ 3 weeks of anticoagulation (or transesophageal echocardiography ruling out atrial thrombus). Postoperatively: stratify risk (CHA₂DS₂-VASc) with the treating team.",
        "6. FA de novo intraoperatoria: ECG de 12 derivaciones y K, Mg, Hb y gases al terminar; la FA postoperatoria de novo suele revertir si los disparadores se corrigen — documente para el seguimiento." to
            "6. New-onset intraoperative AF: 12-lead ECG plus K, Mg, Hb and blood gases at the end; new postoperative AF usually converts once triggers are corrected — document it for follow-up.",
        "Tratar la frecuencia sin buscar disparadores (la hipokalemia es la más común); cardiovertir sin anticoagulación a un paciente en FA de > 48 h; dar verapamilo o diltiazem con HFrEF; confundir el flutter con FA (no responde igual al betabloqueo); esperar efecto inmediato del bolo de amiodarona (actúa en horas)." to
            "Treating the rate without looking for triggers (hypokalemia is the most common); cardioverting without anticoagulation a patient in AF > 48 h; giving verapamil or diltiazem with HFrEF; confusing flutter with AF (it does not respond the same to beta-blockade); expecting an immediate effect from the amiodarone bolus (it acts over hours).",
        "Hipotensión con hipoperfusión, angina, edema agudo o alteración de la conciencia: cardioversión sincronizada inmediata. Frecuencia sostenida > 150/min que no responde a fármacos, o deterioro progresivo: anuncie, pida ayuda y prepare la cardioversión." to
            "Hypotension with hypoperfusion, angina, pulmonary edema or altered consciousness: immediate synchronized cardioversion. Sustained rate > 150/min unresponsive to drugs, or progressive deterioration: announce it, call for help and prepare cardioversion.",
        "En quirófano: FA inestable de nueva aparición → cardioversión sincronizada (sedación profunda si hay conciencia); estable → betabloqueante IV titulado mientras corrige electrolitos, profundidad anestésica y volumen. Vigile la hipotensión del betabloqueante y la potenciación del bloqueo neuromuscular por el magnesio. Tras torácica/cardíaca, la FA multiplica el ACVA: anticoagle según riesgo tras descartar sangrado activo." to
            "In the OR: new-onset unstable AF → synchronized cardioversion (deep sedation if conscious); stable → titrated IV beta-blocker while correcting electrolytes, anesthetic depth and volume. Watch for beta-blocker hypotension and magnesium's potentiation of neuromuscular blockade. After thoracic/cardiac surgery, AF multiplies stroke risk: anticoagulate according to risk after excluding active bleeding.",

        // --- Perla: Transfusiones (plaquetas, plasma, hemoderivados) ---
        "Transfusiones: plaquetas, plasma y hemoderivados" to
            "Transfusions: platelets, plasma and blood products",
        "Transfundir COMPONENTES con objetivo clínico y laboratorio dirigido: glóbulos rojos por Hb y clínica, plaquetas por cifra y sangrado, plasma por déficit de factores con sangrado o procedimiento invasivo, crioprecipitado por fibrinógeno. El «número» no basta: transfundir por protocolo sin sangrado es daño evitable." to
            "Transfuse COMPONENTS with a clinical goal and directed laboratory testing: red cells for Hb and clinical status, platelets for count and bleeding, plasma for factor deficits with bleeding or invasive procedures, cryoprecipitate for fibrinogen. The “number” is not enough: transfusing by protocol without bleeding is avoidable harm.",
        "1. Glóbulos rojos: umbral restrictivo Hb 7–8 g/dL en paciente estable (8–10 con cardiopatía isquémica activa); cada unidad sube la Hb ~1 g/dL (Hto ~3 puntos)." to
            "1. Red blood cells: restrictive threshold Hb 7–8 g/dL in a stable patient (8–10 with active ischemic heart disease); each unit raises Hb ~1 g/dL (Hct ~3 points).",
        "2. Plaquetas: profilácticas si < 10 ×10⁹/L (< 20 con fiebre o riesgo); cirugía invasiva con ≥ 50 ×10⁹/L (≥ 100 en neurocirugía/ocular); 1 pool o aféresis sube ~20–40 ×10⁹/L. Inútiles en TTP y púrpura posttransfusional." to
            "2. Platelets: prophylactic if < 10 ×10⁹/L (< 20 with fever or risk); invasive surgery with ≥ 50 ×10⁹/L (≥ 100 in neuro/ocular surgery); 1 pool or apheresis unit raises ~20–40 ×10⁹/L. Useless in TTP and post-transfusion purpura.",
        "3. Plasma fresco congelado: 10–15 mL/kg; indicado en sangrado con INR > 1,5–2 o TTPa muy prolongado, cirugía urgente con INR > 1,5, sangrado masivo y déficit de un factor sin concentrado específico. NO es expansor de volumen ni «vitamina K líquida»." to
            "3. Fresh frozen plasma: 10–15 mL/kg; indicated in bleeding with INR > 1.5–2 or markedly prolonged aPTT, urgent surgery with INR > 1.5, massive bleeding and single-factor deficit without a specific concentrate. It is NOT a volume expander or “liquid vitamin K”.",
        "4. Crioprecipitado: fibrinógeno < 150 mg/dL (< 200 en sangrado masivo u obstétrico) → 1 pool (5–10 unidades) por cada 10 kg de peso sube el fibrinógeno ~50–100 mg/dL. En obstetricia y trauma es el componente más rentable." to
            "4. Cryoprecipitate: fibrinogen < 150 mg/dL (< 200 in massive or obstetric bleeding) → 1 pool (5–10 units) per 10 kg of body weight raises fibrinogen ~50–100 mg/dL. In obstetrics and trauma it is the most cost-effective component.",
        "5. Sangrado masivo: protocolo MTP con proporciones balanceadas ≈ 1:1:1 (GR:plasma:plaquetas), ácido tranexámico 1 g IV en 10 min, calcio ionizado ≥ 1,1 mmol/L (el citrato lo quela), temperatura ≥ 36 °C y laboratorio o ROTEM/TEG seriado cada 30–60 min." to
            "5. Massive bleeding: MTP protocol with balanced ratios ≈ 1:1:1 (RBC:plasma:platelets), tranexamic acid 1 g IV over 10 min, ionized calcium ≥ 1.1 mmol/L (citrate chelates it), temperature ≥ 36 °C and serial lab or ROTEM/TEG every 30–60 min.",
        "6. Seguridad: confirme ABO/Rh y consentimiento (salvo urgencia vital), línea exclusiva con filtro, y vigile reacciones (urticaria, fiebre, disnea, hipotensión). Ante sospecha de reacción: DETENER la infusión, llamar al banco y tratar según gravedad; la TRALI (disnea + hipoxemia 1–6 h tras plasma/GR) se maneja con soporte respiratorio." to
            "6. Safety: confirm ABO/Rh and consent (unless life-threatening emergency), dedicated line with filter, and watch for reactions (urticaria, fever, dyspnea, hypotension). If a reaction is suspected: STOP the infusion, call the blood bank and treat by severity; TRALI (dyspnea + hypoxemia 1–6 h after plasma/RBC) is managed with respiratory support.",
        "Transfundir por cifra sin síntomas (plaquetas > 10 ×10⁹/L estables sin sangrado); usar PFC como expansor o para «corregir un INR» sin sangrado (también en hepatopatía: coagulopatía rebalanceada); olvidar el fibrinógeno en el sangrado masivo (el crioprecipitado llega tarde); ignorar la hipocalcemia y la hipotermia que perpetúan la coagulopatía; no reevaluar el laboratorio después de cada pool." to
            "Transfusing by number without symptoms (stable platelets > 10 ×10⁹/L without bleeding); using FFP as a volume expander or to “correct an INR” without bleeding (also in liver disease: rebalanced coagulopathy); forgetting fibrinogen in massive bleeding (cryoprecipitate arrives late); ignoring the hypocalcemia and hypothermia that perpetuate coagulopathy; not rechecking the lab after each pool.",
        "Sangrado microvascular difuso (el campo no coagula), oozing persistente, petequias nuevas o hematuria inesperada: sospeche CID/hiperfibrinólisis — pida fibrinógeno, dímero D, ROTEM/TEG y active el MTP. Disnea con hipoxemia 1–6 h después de plasma o GR: TRALI. Urticaria progresiva, broncoespasmo o hipotensión durante la infusión: reacción transfusional — DETENER ya." to
            "Diffuse microvascular bleeding (the field does not clot), persistent ooze, new petechiae or unexpected hematuria: suspect DIC/hyperfibrinolysis — request fibrinogen, D-dimer, ROTEM/TEG and activate the MTP. Dyspnea with hypoxemia 1–6 h after plasma or RBC: TRALI. Progressive urticaria, bronchospasm or hypotension during infusion: transfusion reaction — STOP now.",
        "Antes de la cirugía de riesgo: coordine con el banco (cruce, MTP planificado). Durante el sangrado mayor: corrija en orden — circulación, calcio, temperatura, fibrinógeno, plaquetas, factores — guiado por viscoelástico (ROTEM/TEG). En UCI: evite la «anemia de intensivos» (umbral 7) y reevalúe en cada bolo. Transfunda lo mínimo eficaz: cada componente tiene efectos adversos." to
            "Before high-risk surgery: coordinate with the blood bank (crossmatch, planned MTP). During major bleeding: correct in order — circulation, calcium, temperature, fibrinogen, platelets, factors — guided by viscoelastic testing (ROTEM/TEG). In the ICU: avoid “ICU anemia” (threshold 7) and reassess with each unit. Transfuse the minimum effective dose: every component has adverse effects.",

        // --- Perla: Vía aérea en el paciente politraumatizado ---
        "Vía aérea en el paciente politraumatizado" to
            "Airway management in the polytrauma patient",
        "El politraumatizado tiene estómago lleno, hipovolemia, posible lesión cervical y puede traer sangre o vómito en la vía aérea: la intubación de secuencia rápida con control cervical y plan de rescate quirúrgico definido es el estándar. La hipoxia y la hipotensión de la intubación matan más que el error técnico: optimice ANTES de inducir." to
            "The polytrauma patient has a full stomach, hypovolemia, possible cervical spine injury and may arrive with blood or vomit in the airway: rapid sequence intubation with cervical control and a defined surgical rescue plan is the standard. Hypoxia and hypotension during intubation kill more than technical error: optimize BEFORE inducing.",
        "1. Preparación: succión rígida conectada (2 aspiradores si hay sangre), equipo definido por roles (operador, asistente de inmovilización/fármacos, persona del plan B), monitorización, vía IV de carga y control de la hemorragia en marcha." to
            "1. Preparation: rigid suction connected (2 aspirators if there is blood), team roles defined (operator, immobilization/drugs assistant, plan B person), monitoring, loading IV line and ongoing hemorrhage control.",
        "2. Preoxigenación agresiva: O2 100 % durante 3–5 min + oxígeno nasal apneico durante la laringoscopia (HFNO si disponible): con FRC baja y shunt desatura en segundos." to
            "2. Aggressive preoxygenation: 100% O2 for 3–5 min + apneic nasal oxygen during laryngoscopy (HFNO if available): with low FRC and shunt, desaturation occurs in seconds.",
        "3. Control cervical: collar con pieza frontal ABIERTA + inmovilización manual en línea (MILS) durante la laringoscopia; no fuerce la extensión del cuello. Videolaringoscopio de primera línea si hay sangrado o limitación." to
            "3. Cervical control: collar with the FRONT piece OPEN + manual in-line stabilization (MILS) during laryngoscopy; do not force neck extension. Video laryngoscope as first line if there is bleeding or limitation.",
        "4. Inducción según hemodinamia: etomidato 0,3 mg/kg o ketamina 1–2 mg/kg en hipovolemia (evite propofol a dosis plena); succinilcolina 1–1,5 mg/kg (contraindicada tras 48–72 h de quemadura/denervación/crush; en el trauma agudo es segura) o rocuronio 1,2 mg/kg." to
            "4. Induction according to hemodynamics: etomidate 0.3 mg/kg or ketamine 1–2 mg/kg in hypovolemia (avoid full-dose propofol); succinylcholine 1–1.5 mg/kg (contraindicated after 48–72 h of burns/denervation/crush; in acute trauma it is safe) or rocuronium 1.2 mg/kg.",
        "5. Antes de ventilar con presión positiva: descarte neumotórax a tensión (ausculte y descomprima con aguja 14–16 G en el 2.º espacio intercostal línea medioclavicular) — la ventilación con presión convierte el neumotórax simple en a tensión." to
            "5. Before ventilating with positive pressure: rule out tension pneumothorax (auscultate and decompress with a 14–16 G needle in the 2nd intercostal space, midclavicular line) — positive-pressure ventilation converts a simple pneumothorax into a tension one.",
        "6. Plan B/C definido ANTES de empezar: videolaringoscopio alternativo, fibrobroncoscopio, mascarilla laríngea como puente y vía aérea quirúrgica (cricotiroidotomía) con kit abierto y marcado. CICO (no puede intubar, no puede oxigenar) → rescate quirúrgico inmediato, sin insistir." to
            "6. Plan B/C defined BEFORE starting: alternative video laryngoscope, fiberoptic bronchoscope, laryngeal mask as a bridge and surgical airway (cricothyroidotomy) with the kit open and marked. CICO (cannot intubate, cannot oxygenate) → immediate surgical rescue, without insisting.",
        "Insistir con múltiples intentos de laringoscopia (cada intento añade sangre, edema e hipoxia); laringoscopiar con el collar cerrado; succinilcolina tardía (> 48–72 h de denervación/quemadura: hiperpotasemia letal); ventilar sin descartar neumotórax a tensión; inducir con propofol pleno en hipovolemia; no tener el kit quirúrgico preparado (el CICO se decide en segundos, no en minutos)." to
            "Insisting with multiple laryngoscopy attempts (each attempt adds blood, edema and hypoxia); laryngoscoping with the collar closed; late succinylcholine (> 48–72 h of denervation/burn: lethal hyperkalemia); ventilating without ruling out tension pneumothorax; inducing with full-dose propofol in hypovolemia; not having the surgical kit ready (CICO is decided in seconds, not minutes).",
        "Desaturación progresiva tras un tubo correcto: DOPE y sospeche neumotórax a tensión del lado no ventilado (descomprima de inmediato). Hemorragia creciente por el tubo o dificultad creciente de ventilar: lesión laringotraqueal/vascular — no fuerce, prepare rescate quirúrgico. Enfisema subcutáneo que crece con disnea: vía aérea lesionada o neumotórax." to
            "Progressive desaturation after a correct tube: DOPE and suspect tension pneumothorax on the non-ventilated side (decompress immediately). Increasing bleeding through the tube or increasing difficulty ventilating: laryngotracheal/vascular injury — do not force it, prepare surgical rescue. Growing subcutaneous emphysema with dyspnea: injured airway or pneumothorax.",
        "En urgencias y quirófano: RSI con MILS, el mejor operador al frente en el PRIMER intento, oxígeno apneico mientras, capnografía obligatoria tras el tubo. Con trauma facial o cervical severo (o vía aérea sangrante con TCE): valore intubación despierta con fibro si el paciente colabora y oxigena, o rescate quirúrgico temprano. El segundo intento lo hace el más experto y con cambio de estrategia." to
            "In the ER and OR: RSI with MILS, the best operator in front on the FIRST attempt, apneic oxygen meanwhile, mandatory capnography after the tube. With severe facial or cervical trauma (or a bleeding airway with TBI): consider awake fiberoptic intubation if the patient cooperates and oxygenates, or early surgical rescue. The second attempt is made by the most experienced one and with a change of strategy."
    )

    val PT: Map<String, String> = mapOf(
        // --- Calculadora Sangrado (hematocrito) — v2.8.1 ---
        "Peso" to "Peso",
        "Si solo dispone de Hb: Hto ≈ 3 × Hb (Hb 10 g/dL ≈ Hto 30 %)." to
            "Se só tiver Hb: Hto ≈ 3 × Hb (Hb 10 g/dL ≈ Hto 30 %).",
        "Sangrado estimado (opcional)" to "Sangramento estimado (opcional)",
        "Complete peso, Hto inicial y Hto mínimo para calcular." to
            "Preencha peso, Hto inicial e Hto mínimo para calcular.",
        "El Hto mínimo debe ser MENOR que el Hto inicial (revise si los intercambió)." to
            "O Hto mínimo deve ser MENOR que o Hto inicial (verifique se os inverteu).",
        "Hto final estimado" to "Hto final estimado",
        "Hb final estimada" to "Hb final estimada",

        // --- Gasometría: equilibrio acidobásico — v2.8.1 ---
        "HCO3 (bicarbonato)" to "HCO3 (bicarbonato)",
        "EB (exceso de bases)" to "EB (excesso de bases)",
        "Equilibrio acidobásico: introduzca pH, PaCO2 y al menos uno de HCO3 o EB (exceso de bases); la app indica el desequilibrio (acidosis/alcalosis, metabólica/respiratoria o mixto)." to
            "Equilíbrio acidobásico: insira pH, PaCO2 e pelo menos um de HCO3 ou EB (excesso de bases); o app indica o distúrbio (acidose/alcalose, metabólica/respiratória ou misto).",
        "Faltan HCO3 y EB: introduzca al menos uno de los dos para clasificar el desequilibrio." to
            "Faltam HCO3 e EB: insira pelo menos um dos dois para classificar o distúrbio.",
        "Acidemia" to "Acidemia",
        "Alcalemia" to "Alcalemia",
        "pH no aportado" to "pH não informado",
        "pH en rango normal" to "pH na faixa normal",
        "Estado" to "Estado",
        "Acidosis metabólica" to "Acidose metabólica",
        "Alcalosis metabólica" to "Alcalose metabólica",
        "Acidosis respiratoria" to "Acidose respiratória",
        "Alcalosis respiratoria" to "Alcalose respiratória",
        "Trastorno mixto (metabólico + respiratorio)" to "Distúrbio misto (metabólico + respiratório)",
        "Sin trastorno detectado" to "Nenhum distúrbio detectado",
        " — aguda" to " — aguda",
        " — crónica" to " — crônica",
        "Acidosis respiratoria — aguda" to "Acidose respiratória — aguda",
        "Acidosis respiratoria — crónica" to "Acidose respiratória — crônica",
        "Alcalosis respiratoria — aguda" to "Alcalose respiratória — aguda",
        "Alcalosis respiratoria — crónica" to "Alcalose respiratória — crônica",
        "Respiratoria adecuada" to "Respiratória adequada",
        "Respiratoria inadecuada" to "Respiratória inadequada",
        "Metabólica adecuada" to "Metabólica adequada",
        "Metabólica inadecuada" to "Metabólica inadequada",
        "Equilibrio acidobásico" to "Equilíbrio acidobásico",
        "HCO3 (efectivo)" to "HCO3 (efetivo)",
        "EB (efectivo)" to "EB (efetivo)",
        "Trastorno primario" to "Distúrbio primário",
        "Compensación" to "Compensação",
        "Sin desequilibrio acidobásico relevante: valores dentro de límites normales." to
            "Sem distúrbio acidobásico relevante: valores dentro dos limites normais.",
        "Trastorno mixto: acidosis y alcalosis conviven; analice ambos componentes y su causa." to
            "Distúrbio misto: acidose e alcalose convivem; analise ambos os componentes e sua causa.",
        "Acidosis metabólica con compensación respiratoria inadecuada: el cuadro es MIXTO." to
            "Acidose metabólica com compensação respiratória inadequada: o quadro é MISTO.",
        "Alcalosis metabólica con compensación respiratoria inadecuada: el cuadro es MIXTO." to
            "Alcalose metabólica com compensação respiratória inadequada: o quadro é MISTO.",
        "Acidosis respiratoria — aguda con compensación metabólica inadecuada: el cuadro es MIXTO." to
            "Acidose respiratória — aguda com compensação metabólica inadequada: o quadro é MISTO.",
        "Acidosis respiratoria — crónica con compensación metabólica inadecuada: el cuadro es MIXTO." to
            "Acidose respiratória — crônica com compensação metabólica inadequada: o quadro é MISTO.",
        "Alcalosis respiratoria — aguda con compensación metabólica inadecuada: el cuadro es MIXTO." to
            "Alcalose respiratória — aguda com compensação metabólica inadequada: o quadro é MISTO.",
        "Alcalosis respiratoria — crónica con compensación metabólica inadecuada: el cuadro es MIXTO." to
            "Alcalose respiratória — crônica com compensação metabólica inadequada: o quadro é MISTO.",
        "Acidosis metabólica con compensación respiratoria adecuada." to
            "Acidose metabólica com compensação respiratória adequada.",
        "Alcalosis metabólica con compensación respiratoria adecuada." to
            "Alcalose metabólica com compensação respiratória adequada.",
        "Acidosis respiratoria — aguda con compensación metabólica adecuada." to
            "Acidose respiratória — aguda com compensação metabólica adequada.",
        "Acidosis respiratoria — crónica con compensación metabólica adecuada." to
            "Acidose respiratória — crônica com compensação metabólica adequada.",
        "Alcalosis respiratoria — aguda con compensación metabólica adecuada." to
            "Alcalose respiratória — aguda com compensação metabólica adequada.",
        "Alcalosis respiratoria — crónica con compensación metabólica adecuada." to
            "Alcalose respiratória — crônica com compensação metabólica adequada.",
        "Reglas del motor: HCO3 normal 22–26 mmol/L, PaCO2 normal 35–45 mmHg. Acidosis metabólica: PaCO2 esperada = 1,5 × HCO3 + 8 (± 2, Winters). Alcalosis metabólica: PaCO2 = 0,7 × ΔHCO3 + 40 (± 5). Respiratoria aguda: ΔHCO3 = +1 (acidosis) o −2 (alcalosis) por cada 10 mmHg; crónica ×4 o −5. EB negativo apoya acidosis metabólica; positivo, alcalosis. Fuera de la ventana esperada = trastorno mixto. Si solo dispone de EB, el HCO3 se estima como 24 + EB (y viceversa)." to
            "Regras do motor: HCO3 normal 22–26 mmol/L, PaCO2 normal 35–45 mmHg. Acidose metabólica: PaCO2 esperada = 1,5 × HCO3 + 8 (± 2, Winters). Alcalose metabólica: PaCO2 = 0,7 × ΔHCO3 + 40 (± 5). Respiratória aguda: ΔHCO3 = +1 (acidose) ou −2 (alcalose) por 10 mmHg; crônica ×4 ou −5. EB negativo apoia acidose metabólica; positivo, alcalose. Fora da janela esperada = distúrbio misto. Se só tiver EB, o HCO3 é estimado como 24 + EB (e vice-versa).",

        // --- Buscador global — v2.8.1 ---
        "Buscador de todos los temas" to "Busca de todos os temas",
        "Busque en emergencias, fármacos, gases, escalas, complicaciones, premedicación, soluciones, clínica, perlas, temario, escuela, tutor, crisis y calculadoras." to
            "Busque em emergências, fármacos, gases, escalas, complicações, pré-medicação, soluções, clínica, pérolas, temário, escola, tutor, crise e calculadoras.",
        "Buscar tema…" to "Buscar tema…",
        "Escriba al menos una letra: la búsqueda ignora tildes y mayúsculas." to
            "Digite pelo menos uma letra: a busca ignora acentos e maiúsculas.",
        "Sin resultados para «%1\$s»." to "Sem resultados para «%1\$s».",
        "%1\$s resultado(s) — toque un resultado para abrir su tema." to
            "%1\$s resultado(s) — toque um resultado para abrir seu tema.",
        "Refine la búsqueda: se muestran los primeros 40 resultados." to
            "Refine a busca: são mostrados os primeiros 40 resultados.",
        "Emergencias" to "Emergências",
        "Fármacos" to "Fármacos",
        "Gases" to "Gases",
        "Escalas" to "Escalas",
        "Complicaciones" to "Complicações",
        "Premedicación" to "Pré-medicação",
        "Soluciones" to "Soluções",
        "Clínica · Comorbilidades" to "Clínica · Comorbilidades",
        "Clínica · Bloqueos" to "Clínica · Bloqueios",
        "Clínica · Monitoreo" to "Clínica · Monitorização",
        "Clínica · Preoperatorio" to "Clínica · Pré-operatório",
        "Clínica · Equipos" to "Clínica · Equipamentos",
        "Clínica · Quirúrgico" to "Clínica · Cirúrgico",
        "Perlas" to "Pérolas",
        "Temario" to "Temário",
        "Escuela" to "Escola",
        "Tutor" to "Tutor",
        "Crisis" to "Crise",
        "Calculadoras" to "Calculadoras",
        "Dosis/peso" to "Dose/peso",
        "Peso ideal" to "Peso ideal",
        "Tubo pediátrico" to "Tubo pediátrico",
        "Sangrado" to "Sangramento",
        "Anestésico local" to "Anestésico local",
        "Infusión por fármaco (45)" to "Infusão por fármaco (45)",
        "Bomba TCI" to "Bomba TCI",
        "Ventilación: Vt y VM" to "Ventilação: Vc e VM",
        "Ventilación mecánica" to "Ventilação mecânica",
        "Función renal (ClCr)" to "Função renal (ClCr)",
        "Ecografía gástrica" to "Ultrassonografia gástrica",

        // --- Perla: Fibrilación auricular perioperatoria ---
        "Fibrilación auricular perioperatoria: tratamiento y manejo" to
            "Fibrilação atrial perioperatória: tratamento e manejo",
        "La FA con respuesta ventricular rápida es la arritmia perioperatoria más frecuente: aparece en el postoperatorio de cirugía torácica, cardíaca y abdominal mayor. Tres preguntas ordenan el manejo: ¿estable o inestable?, ¿control de frecuencia o de ritmo?, ¿anticoagular o no? Corrija SIEMPRE los disparadores (electrolitos, dolor, hipovolemia, hipercapnia) antes de culpar al corazón." to
            "A FA com resposta ventricular rápida é a arritmia perioperatória mais frequente: aparece no pós-operatório de cirurgia torácica, cardíaca e abdominal maior. Três perguntas ordenam o manejo: estável ou instável?, controle de frequência ou de ritmo?, anticoagular ou não? Corrija SEMPRE os disparadores (eletrólitos, dor, hipovolemia, hipercapnia) antes de culpar o coração.",
        "1. Evaluar estabilidad: hipotensión con hipoperfusión, angina o edema agudo → cardioversión eléctrica sincronizada INMEDIATA (120–200 J bifásico), con sedación si el tiempo lo permite." to
            "1. Avaliar estabilidade: hipotensão com hipoperfusão, angina ou edema agudo → cardioversão elétrica sincronizada IMEDIATA (120–200 J bifásico), com sedação se o tempo permitir.",
        "2. Estable: control de frecuencia primero — betabloqueante (metoprolol 2,5–5 mg IV lento, repetible) o diltiazem/verapamilo 5–10 mg IV; si hay disfunción del ventrículo izquierdo use amiodarona (los calcioantagonistas deprimen el débito)." to
            "2. Estável: controle de frequência primeiro — betabloqueador (metoprolol 2,5–5 mg IV lento, repetível) ou diltiazem/verapamil 5–10 mg IV; se houver disfunção do ventrículo esquerdo use amiodarona (os bloqueadores de canais de cálcio deprimem o débito).",
        "3. Amiodarona: 150–300 mg IV en 20–60 min → 1 mg/min durante 6 h → 0,5 mg/min 18 h; controla la frecuencia y facilita la reversión: es el antiarrítmico de elección con HFrEF." to
            "3. Amiodarona: 150–300 mg IV em 20–60 min → 1 mg/min por 6 h → 0,5 mg/min por 18 h; controla a frequência e facilita a reversão: é o antiarrítmico de escolha com FE reduzida.",
        "4. Corregir disparadores: K 4–4,5 mmol/L y Mg ≥ 2 mg/dL (la hipokalemia + hipomagnesemia perpetúan la FA), dolor, hipovolemia, hipercapnia, hipoxia, anemia, fiebre, hipertiroidismo, alcohol y teofilina." to
            "4. Corrigir disparadores: K 4–4,5 mmol/L e Mg ≥ 2 mg/dL (a hipocalemia + hipomagnesemia perpetuam a FA), dor, hipovolemia, hipercapnia, hipóxia, anemia, febre, hipertireoidismo, álcool e teofilina.",
        "5. Anticoagulación: FA > 48 h o de duración desconocida → riesgo embólico; la cardioversión electiva exige ≥ 3 semanas de anticoagulación (o ecografía transesofágica que excluya trombo auricular). Postoperatorio: gradúe el riesgo (CHA₂DS₂-VASc) con el equipo tratante." to
            "5. Anticoagulação: FA > 48 h ou de duração desconhecida → risco embólico; a cardioversão eletiva exige ≥ 3 semanas de anticoagulação (ou ecocardiografia transesofágica que exclua trombo atrial). Pós-operatório: estratifique o risco (CHA₂DS₂-VASc) com a equipe assistente.",
        "6. FA de novo intraoperatoria: ECG de 12 derivaciones y K, Mg, Hb y gases al terminar; la FA postoperatoria de novo suele revertir si los disparadores se corrigen — documente para el seguimiento." to
            "6. FA de novo intraoperatória: ECG de 12 derivações e K, Mg, Hb e gases ao terminar; a FA pós-operatória de novo costuma reverter se os disparadores forem corrigidos — documente para o seguimento.",
        "Tratar la frecuencia sin buscar disparadores (la hipokalemia es la más común); cardiovertir sin anticoagulación a un paciente en FA de > 48 h; dar verapamilo o diltiazem con HFrEF; confundir el flutter con FA (no responde igual al betabloqueo); esperar efecto inmediato del bolo de amiodarona (actúa en horas)." to
            "Tratar a frequência sem procurar disparadores (a hipocalemia é a mais comum); cardioverter sem anticoagulação um paciente em FA > 48 h; dar verapamil ou diltiazem com FE reduzida; confundir flutter com FA (não responde igual ao betabloqueio); esperar efeito imediato do bolus de amiodarona (age em horas).",
        "Hipotensión con hipoperfusión, angina, edema agudo o alteración de la conciencia: cardioversión sincronizada inmediata. Frecuencia sostenida > 150/min que no responde a fármacos, o deterioro progresivo: anuncie, pida ayuda y prepare la cardioversión." to
            "Hipotensão com hipoperfusão, angina, edema agudo ou alteração da consciência: cardioversão sincronizada imediata. Frequência sustentada > 150/min que não responde a fármacos, ou deterioro progressivo: anuncie, peça ajuda e prepare a cardioversão.",
        "En quirófano: FA inestable de nueva aparición → cardioversión sincronizada (sedación profunda si hay conciencia); estable → betabloqueante IV titulado mientras corrige electrolitos, profundidad anestésica y volumen. Vigile la hipotensión del betabloqueante y la potenciación del bloqueo neuromuscular por el magnesio. Tras torácica/cardíaca, la FA multiplica el ACVA: anticoagle según riesgo tras descartar sangrado activo." to
            "No centro cirúrgico: FA instável de nova aparição → cardioversão sincronizada (sedação profunda se houver consciência); estável → betabloqueador IV titulado enquanto corrige eletrólitos, profundidade anestésica e volume. Vigie a hipotensão do betabloqueador e a potenciação do bloqueio neuromuscular pelo magnésio. Após torácica/cardíaca, a FA multiplica o AVC: anticoagule conforme o risco após descartar sangramento ativo.",

        // --- Perla: Transfusiones (plaquetas, plasma, hemoderivados) ---
        "Transfusiones: plaquetas, plasma y hemoderivados" to
            "Transfusões: plaquetas, plasma e hemoderivados",
        "Transfundir COMPONENTES con objetivo clínico y laboratorio dirigido: glóbulos rojos por Hb y clínica, plaquetas por cifra y sangrado, plasma por déficit de factores con sangrado o procedimiento invasivo, crioprecipitado por fibrinógeno. El «número» no basta: transfundir por protocolo sin sangrado es daño evitable." to
            "Transfundir COMPONENTES com objetivo clínico e laboratório dirigido: hemácias por Hb e clínica, plaquetas por contagem e sangramento, plasma por déficit de fatores com sangramento ou procedimento invasivo, crioprecipitado por fibrinogênio. O «número» não basta: transfundir por protocolo sem sangramento é dano evitável.",
        "1. Glóbulos rojos: umbral restrictivo Hb 7–8 g/dL en paciente estable (8–10 con cardiopatía isquémica activa); cada unidad sube la Hb ~1 g/dL (Hto ~3 puntos)." to
            "1. Hemácias: limiar restritivo Hb 7–8 g/dL em paciente estável (8–10 com cardiopatia isquêmica ativa); cada unidade eleva a Hb ~1 g/dL (Hto ~3 pontos).",
        "2. Plaquetas: profilácticas si < 10 ×10⁹/L (< 20 con fiebre o riesgo); cirugía invasiva con ≥ 50 ×10⁹/L (≥ 100 en neurocirugía/ocular); 1 pool o aféresis sube ~20–40 ×10⁹/L. Inútiles en TTP y púrpura posttransfusional." to
            "2. Plaquetas: profiláticas se < 10 ×10⁹/L (< 20 com febre ou risco); cirurgia invasiva com ≥ 50 ×10⁹/L (≥ 100 em neurocirurgia/ocular); 1 pool ou aférese eleva ~20–40 ×10⁹/L. Inúteis na PTI e púrpura pós-transfusional.",
        "3. Plasma fresco congelado: 10–15 mL/kg; indicado en sangrado con INR > 1,5–2 o TTPa muy prolongado, cirugía urgente con INR > 1,5, sangrado masivo y déficit de un factor sin concentrado específico. NO es expansor de volumen ni «vitamina K líquida»." to
            "3. Plasma fresco congelado: 10–15 mL/kg; indicado em sangramento com INR > 1,5–2 ou TTPa muito prolongado, cirurgia urgente com INR > 1,5, sangramento maciço e déficit de um fator sem concentrado específico. NÃO é expansor de volume nem «vitamina K líquida».",
        "4. Crioprecipitado: fibrinógeno < 150 mg/dL (< 200 en sangrado masivo u obstétrico) → 1 pool (5–10 unidades) por cada 10 kg de peso sube el fibrinógeno ~50–100 mg/dL. En obstetricia y trauma es el componente más rentable." to
            "4. Crioprecipitado: fibrinogênio < 150 mg/dL (< 200 em sangramento maciço ou obstétrico) → 1 pool (5–10 unidades) por 10 kg de peso eleva o fibrinogênio ~50–100 mg/dL. Na obstetrícia e no trauma é o componente mais rentável.",
        "5. Sangrado masivo: protocolo MTP con proporciones balanceadas ≈ 1:1:1 (GR:plasma:plaquetas), ácido tranexámico 1 g IV en 10 min, calcio ionizado ≥ 1,1 mmol/L (el citrato lo quela), temperatura ≥ 36 °C y laboratorio o ROTEM/TEG seriado cada 30–60 min." to
            "5. Sangramento maciço: protocolo MTP com proporções balanceadas ≈ 1:1:1 (hemácias:plasma:plaquetas), ácido tranexâmico 1 g IV em 10 min, cálcio ionizado ≥ 1,1 mmol/L (o citrato o quelar), temperatura ≥ 36 °C e laboratório ou ROTEM/TEG seriado a cada 30–60 min.",
        "6. Seguridad: confirme ABO/Rh y consentimiento (salvo urgencia vital), línea exclusiva con filtro, y vigile reacciones (urticaria, fiebre, disnea, hipotensión). Ante sospecha de reacción: DETENER la infusión, llamar al banco y tratar según gravedad; la TRALI (disnea + hipoxemia 1–6 h tras plasma/GR) se maneja con soporte respiratorio." to
            "6. Segurança: confirme ABO/Rh e consentimento (salvo urgência vital), linha exclusiva com filtro, e vigie reações (urticária, febre, dispneia, hipotensão). Perante suspeita de reação: PARAR a infusão, chamar o banco de sangue e tratar conforme a gravidade; a TRALI (dispneia + hipóxia 1–6 h após plasma/hemácias) é manejada com suporte respiratório.",
        "Transfundir por cifra sin síntomas (plaquetas > 10 ×10⁹/L estables sin sangrado); usar PFC como expansor o para «corregir un INR» sin sangrado (también en hepatopatía: coagulopatía rebalanceada); olvidar el fibrinógeno en el sangrado masivo (el crioprecipitado llega tarde); ignorar la hipocalcemia y la hipotermia que perpetúan la coagulopatía; no reevaluar el laboratorio después de cada pool." to
            "Transfundir por contagem sem sintomas (plaquetas > 10 ×10⁹/L estáveis sem sangramento); usar PFC como expansor ou para «corrigir um INR» sem sangramento (também na hepatopatia: coagulopatia rebalanceada); esquecer o fibrinogênio no sangramento maciço (o crioprecipitado chega tarde); ignorar a hipocalcemia e a hipotermia que perpetuam a coagulopatia; não reavaliar o laboratório após cada pool.",
        "Sangrado microvascular difuso (el campo no coagula), oozing persistente, petequias nuevas o hematuria inesperada: sospeche CID/hiperfibrinólisis — pida fibrinógeno, dímero D, ROTEM/TEG y active el MTP. Disnea con hipoxemia 1–6 h después de plasma o GR: TRALI. Urticaria progresiva, broncoespasmo o hipotensión durante la infusión: reacción transfusional — DETENER ya." to
            "Sangramento microvascular difuso (o campo não coagula), sangramento persistente, petéquias novas ou hematuria inesperada: suspeite de CID/hiperfibrinólise — solicite fibrinogênio, dímero D, ROTEM/TEG e ative o MTP. Dispneia com hipóxia 1–6 h após plasma ou hemácias: TRALI. Urticária progressiva, broncoespasmo ou hipotensão durante a infusão: reação transfusional — PARAR já.",
        "Antes de la cirugía de riesgo: coordine con el banco (cruce, MTP planificado). Durante el sangrado mayor: corrija en orden — circulación, calcio, temperatura, fibrinógeno, plaquetas, factores — guiado por viscoelástico (ROTEM/TEG). En UCI: evite la «anemia de intensivos» (umbral 7) y reevalúe en cada bolo. Transfunda lo mínimo eficaz: cada componente tiene efectos adversos." to
            "Antes da cirurgia de risco: coordine com o banco de sangue (tipagem, MTP planejado). Durante o sangramento maior: corrija em ordem — circulação, cálcio, temperatura, fibrinogênio, plaquetas, fatores — guiado por teste viscoelástico (ROTEM/TEG). Na UTI: evite a «anemia do intensivo» (limiar 7) e reavalie a cada unidade. Transfunda o mínimo eficaz: cada componente tem efeitos adversos.",

        // --- Perla: Vía aérea en el paciente politraumatizado ---
        "Vía aérea en el paciente politraumatizado" to
            "Via aérea no paciente politraumatizado",
        "El politraumatizado tiene estómago lleno, hipovolemia, posible lesión cervical y puede traer sangre o vómito en la vía aérea: la intubación de secuencia rápida con control cervical y plan de rescate quirúrgico definido es el estándar. La hipoxia y la hipotensión de la intubación matan más que el error técnico: optimice ANTES de inducir." to
            "O politraumatizado tem estômago cheio, hipovolemia, possível lesão cervical e pode chegar com sangue ou vômito na via aérea: a intubação de sequência rápida com controle cervical e plano de resgate cirúrgico definido é o padrão. A hipóxia e a hipotensão da intubação matam mais que o erro técnico: otimize ANTES de induzir.",
        "1. Preparación: succión rígida conectada (2 aspiradores si hay sangre), equipo definido por roles (operador, asistente de inmovilización/fármacos, persona del plan B), monitorización, vía IV de carga y control de la hemorragia en marcha." to
            "1. Preparação: aspiração rígida conectada (2 aspiradores se houver sangue), equipe definida por papéis (operador, assistente de imobilização/fármacos, pessoa do plano B), monitorização, acesso IV de carga e controle da hemorragia em andamento.",
        "2. Preoxigenación agresiva: O2 100 % durante 3–5 min + oxígeno nasal apneico durante la laringoscopia (HFNO si disponible): con FRC baja y shunt desatura en segundos." to
            "2. Pré-oxigenação agressiva: O2 100 % por 3–5 min + oxigênio nasal apneico durante a laringoscopia (VNPFO se disponível): com CFR baixa e shunt, dessatura em segundos.",
        "3. Control cervical: collar con pieza frontal ABIERTA + inmovilización manual en línea (MILS) durante la laringoscopia; no fuerce la extensión del cuello. Videolaringoscopio de primera línea si hay sangrado o limitación." to
            "3. Controle cervical: colar com peça frontal ABERTA + imobilização manual em linha (MILS) durante a laringoscopia; não force a extensão do pescoço. Videolaringoscópio de primeira linha se houver sangramento ou limitação.",
        "4. Inducción según hemodinamia: etomidato 0,3 mg/kg o ketamina 1–2 mg/kg en hipovolemia (evite propofol a dosis plena); succinilcolina 1–1,5 mg/kg (contraindicada tras 48–72 h de quemadura/denervación/crush; en el trauma agudo es segura) o rocuronio 1,2 mg/kg." to
            "4. Indução conforme a hemodinâmica: etomidato 0,3 mg/kg ou ketamina 1–2 mg/kg em hipovolemia (evite propofol em dose plena); succinilcolina 1–1,5 mg/kg (contraindicada após 48–72 h de queimadura/denervação/crush; no trauma agudo é segura) ou rocurônio 1,2 mg/kg.",
        "5. Antes de ventilar con presión positiva: descarte neumotórax a tensión (ausculte y descomprima con aguja 14–16 G en el 2.º espacio intercostal línea medioclavicular) — la ventilación con presión convierte el neumotórax simple en a tensión." to
            "5. Antes de ventilar com pressão positiva: descarte pneumotórax hipertensivo (ausculte e descomprima com agulha 14–16 G no 2.º espaço intercostal, linha hemiclavicular) — a ventilação com pressão transforma o pneumotórax simples em hipertensivo.",
        "6. Plan B/C definido ANTES de empezar: videolaringoscopio alternativo, fibrobroncoscopio, mascarilla laríngea como puente y vía aérea quirúrgica (cricotiroidotomía) con kit abierto y marcado. CICO (no puede intubar, no puede oxigenar) → rescate quirúrgico inmediato, sin insistir." to
            "6. Plano B/C definido ANTES de começar: videolaringoscópio alternativo, fibrobroncoscópio, máscara laríngea como ponte e via aérea cirúrgica (cricotireoidotomia) com kit aberto e marcado. CICO (não consegue intubar, não consegue oxigenar) → resgate cirúrgico imediato, sem insistir.",
        "Insistir con múltiples intentos de laringoscopia (cada intento añade sangre, edema e hipoxia); laringoscopiar con el collar cerrado; succinilcolina tardía (> 48–72 h de denervación/quemadura: hiperpotasemia letal); ventilar sin descartar neumotórax a tensión; inducir con propofol pleno en hipovolemia; no tener el kit quirúrgico preparado (el CICO se decide en segundos, no en minutos)." to
            "Insistir com múltiplas tentativas de laringoscopia (cada tentativa adiciona sangue, edema e hipóxia); laringoscopiar com o colar fechado; succinilcolina tardia (> 48–72 h de denervação/queimadura: hiperpotasemia letal); ventilar sem descartar pneumotórax hipertensivo; induzir com propofol em dose plena na hipovolemia; não ter o kit cirúrgico preparado (o CICO decide-se em segundos, não em minutos).",
        "Desaturación progresiva tras un tubo correcto: DOPE y sospeche neumotórax a tensión del lado no ventilado (descomprima de inmediato). Hemorragia creciente por el tubo o dificultad creciente de ventilar: lesión laringotraqueal/vascular — no fuerce, prepare rescate quirúrgico. Enfisema subcutáneo que crece con disnea: vía aérea lesionada o neumotórax." to
            "Dessaturação progressiva após tubo correto: DOPE e suspeite de pneumotórax hipertensivo do lado não ventilado (descomprima imediatamente). Hemorragia crescente pelo tubo ou dificuldade crescente para ventilar: lesão laringotraqueal/vascular — não force, prepare resgate cirúrgico. Enfisema subcutâneo que cresce com dispneia: via aérea lesionada ou pneumotórax.",
        "En urgencias y quirófano: RSI con MILS, el mejor operador al frente en el PRIMER intento, oxígeno apneico mientras, capnografía obligatoria tras el tubo. Con trauma facial o cervical severo (o vía aérea sangrante con TCE): valore intubación despierta con fibro si el paciente colabora y oxigena, o rescate quirúrgico temprano. El segundo intento lo hace el más experto y con cambio de estrategia." to
            "Na emergência e no centro cirúrgico: ISQ com MILS, o melhor operador à frente na PRIMEIRA tentativa, oxigênio apneico enquanto isso, capnografia obrigatória após o tubo. Com trauma facial ou cervical grave (ou via aérea sangrando com TCE): avalie intubação desperta com fibrobroncoscópio se o paciente colaborar e oxigenar, ou resgate cirúrgico precoce. A segunda tentativa é feita pelo mais experiente e com mudança de estratégia."
    )

    fun register() {
        L10n.register(Lang.EN, EN)
        L10n.register(Lang.PT, PT)
    }
}
