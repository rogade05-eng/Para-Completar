package cu.cronos.anestesia

/*
 * ============================================================================
 *  BUSCADOR GLOBAL (v2.8.1) — pedido del autor clínico:
 *  «Un buscador de todos los temas».
 *
 *  Indexa los catálogos de contenido ya traducidos (emergencias, fármacos,
 *  gases, escalas, complicaciones, premedicación, soluciones, clínica,
 *  perlas, temario R1–R4, Escuela de Residentes, Tutor, simulador de crisis
 *  y calculadoras) y salta a la pestaña — y a la ficha, cuando la pestaña
 *  tiene detalle — con un toque. La indexación ocurre en el teléfono:
 *  100 % offline, sin permisos nuevos.
 * ============================================================================
 */

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

/** Resultado de búsqueda: título/subsección ya traducidos + destino. */
data class SearchHit(
    val title: String,
    val subtitle: String,
    val section: String,
    val tab: Int,
    val detail: Int? = null
)

/** Normaliza para buscar: minúsculas y sin tildes («neumotorax» encuentra «Neumotórax»). */
fun searchNormalize(s: String): String =
    java.text.Normalizer.normalize(s.lowercase(), java.text.Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")

/**
 * Índice global de temas. Se construye una vez por sesión de la pestaña
 * (los accesores de L10nData devuelven el contenido ya traducido).
 */
fun buildSearchIndex(): List<SearchHit> {
    val hits = mutableListOf<SearchHit>()
    fun add(title: String, subtitle: String, section: String, tab: Int, detail: Int? = null) {
        if (title.isNotBlank()) hits += SearchHit(title, subtitle, section, tab, detail)
    }

    // Emergencias (pestaña siempre libre): salta a la ficha
    emergencies().forEachIndexed { i, e -> add(e.name, e.subtitle, "Emergencias", 1, i) }
    // Fármacos y gases: salta a la ficha
    drugs().forEachIndexed { i, d -> add(d.name, d.cls, "Fármacos", 2, i) }
    gases().forEachIndexed { i, g -> add(g.name, g.mac, "Gases", 3, i) }
    // Calculadoras (nombres de la pestaña Calculadoras)
    listOf(
        "Ayuno", "Hidratación", "Dosis/peso", "Infusión", "Peso ideal",
        "Tubo pediátrico", "Sangrado", "Gasometría", "Anestésico local",
        "Infusión por fármaco (45)", "Bomba TCI", "Ventilación: Vt y VM",
        "Ventilación mecánica", "Función renal (ClCr)", "Ecografía gástrica"
    ).forEach { n -> add(n, "Calculadoras", "Calculadoras", 4) }
    // Escalas y complicaciones: salta a la ficha
    scales().forEachIndexed { i, s -> add(s.name, s.category, "Escalas", 5, i) }
    complications().forEachIndexed { i, c -> add(c.name, c.recognition, "Complicaciones", 6, i) }
    // Premedicación y soluciones: salta a la ficha
    premedTopics().forEachIndexed { i, t -> add(t.title, "", "Premedicación", 7, i) }
    solutions().forEachIndexed { i, t -> add(t.title, "", "Soluciones", 8, i) }
    // Clínica (navega a la pestaña; el tema se elige dentro)
    comorbidities().forEach { t -> add(t.title, t.subtitle, "Clínica · Comorbilidades", 9) }
    regionalBlocks().forEach { t -> add(t.title, t.subtitle, "Clínica · Bloqueos", 9) }
    monitoring().forEach { t -> add(t.title, t.subtitle, "Clínica · Monitoreo", 9) }
    preopTopics().forEach { t -> add(t.title, t.subtitle, "Clínica · Preoperatorio", 9) }
    equipmentTopics().forEach { t -> add(t.title, t.subtitle, "Clínica · Equipos", 9) }
    surgicalTopics().forEach { t -> add(t.title, t.subtitle, "Clínica · Quirúrgico", 9) }
    // Perlas: salta a la ficha
    pearls().forEachIndexed { i, p -> add(p.titulo, p.resumen, "Perlas", 12, i) }
    // Temario R1–R4: áreas y temas
    residencyL10n().forEach { y ->
        y.areas.forEach { a ->
            add("${y.curso} · ${a.title}", y.objetivo, "Temario", 16)
            a.topics.forEach { t -> add(t, "${y.curso} · ${a.title}", "Temario", 16) }
        }
    }
    // Escuela de Residentes: áreas y fichas
    studyAreas().forEach { a ->
        add(a.name, a.desc, "Escuela", 18)
        a.cards.forEach { c -> add(c.title, a.name, "Escuela", 18) }
    }
    // Tutor: métodos docentes
    teachingMethods().forEach { m -> add(m.name, m.whenToUse, "Tutor", 19) }
    // Simulador de crisis: escenarios
    CRISIS_SCENARIOS.forEach { sc -> add(sc.title.tr(), sc.subtitle.tr(), "Crisis", 20) }

    return hits
}

@Composable
private fun SearchHitCard(hit: SearchHit, onClick: () -> Unit) {
    val sp = LocalSpacing.current
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(Modifier.padding(sp.m.dp)) {
            Text(
                hit.section,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                hit.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurface
            )
            if (hit.subtitle.isNotBlank()) {
                Spacer(Modifier.height(sp.xs.dp))
                Text(
                    hit.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun SearchTab(onGoTo: (tab: Int, detail: Int?) -> Unit) {
    val sp = LocalSpacing.current
    var query by rememberSaveable { mutableStateOf("") }
    val index = remember { buildSearchIndex() }
    val q = searchNormalize(query.trim())

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = sp.screenHPad.dp)
            .padding(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(sp.s.dp)
    ) {
        Spacer(Modifier.height(sp.xs.dp))
        Text(
            "Buscador de todos los temas".tr(),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            "Busque en emergencias, fármacos, gases, escalas, complicaciones, premedicación, soluciones, clínica, perlas, temario, escuela, tutor, crisis y calculadoras.".tr(),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Buscar tema…".tr()) },
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                cursorColor = MaterialTheme.colorScheme.primary
            )
        )

        if (q.isBlank()) {
            Text(
                "Escriba al menos una letra: la búsqueda ignora tildes y mayúsculas.".tr(),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            return@Column
        }

        val matches = index.filter {
            searchNormalize(it.title).contains(q) || searchNormalize(it.subtitle).contains(q)
        }
        Text(
            ("Sin resultados para «%1\$s».").tr().replace("%1\$s", query.trim()),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            if (matches.isEmpty()) "" else ("%1\$s resultado(s) — toque un resultado para abrir su tema.").tr().replace("%1\$s", matches.size.toString()),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        // Resultados: los más cortos primero (mejor coincidencia aproximada)
        matches.sortedBy { it.title.length }.take(40).forEach { hit ->
            SearchHitCard(hit) {
                onGoTo(hit.tab, hit.detail)
            }
        }
        if (matches.size > 40) {
            Text(
                "Refine la búsqueda: se muestran los primeros 40 resultados.".tr(),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
