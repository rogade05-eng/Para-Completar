package cu.cronos.anestesia

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

/**
 * Pruebas v2.0.0: cobertura de datos y fórmulas nuevas.
 * - DRUG_PREP: preparación + modos de administración para los 45 fármacos
 * - SURGICAL_TOPICS: 14 temas PRO+ con calculadoras válidas
 * - PEARLS: 13 perlas Medik Brain completas
 * - BIBLIO: 24 referencias únicas
 * - Consent: estructura legal completa con riesgos explícitos
 * - Fórmulas nuevas de CalcEngine (CPP, ANH, MELD-Na, Qp/Qs, CaO2, SVR, BSA…)
 */
class V200Test {

    private fun eq(expected: Double, actual: Double, tol: Double = 0.02) =
        assertTrue("esperado $expected, obtenido $actual", abs(expected - actual) <= tol)

    // ---------- DRUG_PREP: preparación + administración ----------

    @Test
    fun `los 45 fármacos tienen preparación y administración`() {
        assertEquals(45, DRUGS.size)
        DRUGS.forEach { d ->
            val p = DRUG_PREP[d.name]
            assertTrue("falta prep de ${d.name}", p != null)
            assertTrue("prep vacía de ${d.name}", p!!.prep.length > 40)
            assertTrue("admin vacía de ${d.name}", p.admin.length > 10)
            assertTrue(
                "admin de ${d.name} debe indicar al menos un modo (BOLO/CONT/JERINGA)",
                p.admin.contains("BOLO") || p.admin.contains("CONT") || p.admin.contains("JERINGA")
            )
        }
    }

    @Test
    fun `DRUG_PREP no tiene claves huérfanas`() {
        val names = DRUGS.map { it.name }.toSet()
        DRUG_PREP.keys.forEach { k ->
            assertTrue("clave $k no corresponde a ningún fármaco", k in names)
        }
        assertEquals(45, DRUG_PREP.size)
    }

    @Test
    fun `buscador por alias encuentra fármacos conocidos`() {
        val q = "diprivan"
        val found = DRUGS.filter { d ->
            d.name.lowercase().contains(q) || d.cls.lowercase().contains(q) ||
                DRUG_PREP[d.name]?.alias?.lowercase()?.contains(q) == true
        }
        assertEquals(listOf("Propofol"), found.map { it.name })
    }

    // ---------- Temas quirúrgicos PRO+ ----------

    @Test
    fun `14 temas quirúrgicos con títulos únicos y secciones ricas`() {
        assertEquals(14, SURGICAL_TOPICS.size)
        assertEquals(SURGICAL_TOPICS.size, SURGICAL_TOPICS.map { it.title }.toSet().size)
        SURGICAL_TOPICS.forEach { t ->
            assertEquals("Quirúrgico", t.category)
            assertTrue("secciones de ${t.title}: ${t.sections.size}", t.sections.size >= 5)
            t.sections.forEach { (h, b) ->
                assertTrue("sección $h de ${t.title} muy corta", b.length > 120)
            }
        }
    }

    @Test
    fun `los temas solicitados por el usuario están presentes`() {
        val titles = SURGICAL_TOPICS.map { it.title }.toSet()
        listOf(
            "Traumatismo craneoencefálico (TCE)",
            "Tumores supratentoriales",
            "Tumores infratentoriales",
            "Hemodilución",
            "Trasplante",
            "Embarazo crítico",
            "Cardiopatía congénita adulta",
            "Fisiología respiratoria aplicada",
            "Fisiología cardiovascular aplicada",
            "Cirugía cardíaca con CEC",
            "Ventilación unipulmonar (OLV)",
            "Videocirugía (laparoscopía)"
        ).forEach { assertTrue("falta el tema $it", it in titles) }
    }

    @Test
    fun `calcIds de temas son válidos`() {
        val valid = setOf("cpp", "anh", "meld", "mgso4", "qpqs", "resp", "cardio", "cec", "trauma", "olv", "lap", "")
        SURGICAL_TOPICS.forEach { t -> assertTrue("calcId inválido: ${t.calcId}", t.calcId in valid) }
        // TCE y neuro con CPP; hemodilución ANH; trasplante MELD; embarazo MgSO4; congénita Qp/Qs
        assertEquals("cpp", SURGICAL_TOPICS.first { "TCE" in it.title }.calcId)
        assertEquals("anh", SURGICAL_TOPICS.first { "Hemodilución" in it.title }.calcId)
        assertEquals("meld", SURGICAL_TOPICS.first { it.title == "Trasplante" }.calcId)
        assertEquals("mgso4", SURGICAL_TOPICS.first { "Embarazo" in it.title }.calcId)
        assertEquals("qpqs", SURGICAL_TOPICS.first { "congénita" in it.title }.calcId)
    }

    // ---------- Perlas Medik Brain ----------

    @Test
    fun `perlas completas y con crédito al canal`() {
        // v2.8.1: 16 perlas (13 Medik Brain + 3 bibliográficas del feedback clínico)
        assertEquals(16, PEARLS.size)
        assertEquals(PEARLS.size, PEARLS.map { it.titulo }.toSet().size)
        PEARLS.forEach { p ->
            assertTrue(p.video.isNotBlank())
            assertTrue("resumen corto en ${p.titulo}", p.resumen.length > 120)
            assertTrue("claves en ${p.titulo}", p.claves.size >= 4)
            assertTrue(p.errores.length > 60)
            assertTrue(p.alarma.length > 60)
            assertTrue(p.aplicacion.length > 80)
        }
    }

    @Test
    fun `la perla del colapso post-intubación incluye las 4 claves del video`() {
        val p = PEARLS.first { "post-intubación" in it.titulo }
        val joined = p.claves.joinToString(" ")
        assertTrue("hemodinamia antes de inductores", "hemodinamia" in joined && "inductores" in joined)
        assertTrue("preoxigenar", "Preoxigenar" in joined)
        assertTrue("primer intento", "primer intento" in joined)
        assertTrue("ajustar inductores", "inducción" in joined.lowercase())
        assertTrue("menciona el caso (SpO2 84 %, PA 85/50)", "84 %" in p.aplicacion && "85/50" in p.aplicacion)
    }

    // ---------- Bibliografía ----------

    @Test
    fun `24 referencias únicas con énfasis cardiológico`() {
        assertEquals(24, BIBLIO.size)
        assertEquals(BIBLIO.size, BIBLIO.map { it.title }.toSet().size)
        val titles = BIBLIO.map { it.title }.joinToString(" ")
        assertTrue("Braunwald", "Braunwald" in titles)
        assertTrue("ESC", "ESC" in titles)
        assertTrue("ACC/AHA", "ACC/AHA" in titles)
        assertTrue("Kaplan", "Kaplan" in titles)
        assertTrue("Chestnut", "Chestnut" in titles)
    }

    // ---------- Consentimiento informado ----------

    @Test
    fun `consentimiento con estructura legal completa`() {
        val p = Patient("p1", "Juan Pérez", "91011223344", "45", "M", "70", "170", "HTA")
        val blocks = Consent.buildBlocks(
            patient = p, anesthesiologist = "Dra. X", institution = "Hospital Y",
            service = "Cirugía", technique = Consent.TYPES[0], procedure = "Colecistectomía",
            risksExtra = "", date = "22 de octubre de 2026", asa = "II"
        )
        val all = blocks.joinToString(" ") { it.first }.lowercase()
        listOf(
            "consentimiento informado", "ley no. 156", "helsinki",
            "1. identificación del paciente", "juan pérez", "91011223344",
            "2. identificación del profesional", "3. descripción del procedimiento",
            "4. riesgos", "5. beneficios", "6. alternativas", "7. derechos",
            "8. declaración y autorización", "9. firmas", "testigo", "anestesiólogo",
            "revocar", "voluntaria"
        ).forEach { assertTrue("falta «$it» en el consentimiento", it in all) }
    }

    @Test
    fun `riesgos por técnica con al menos 17 ítems explícitos`() {
        Consent.TYPES.forEach { t ->
            val risks = Consent.riskSummary(t)
            assertTrue("riesgos de $t: ${risks.size}", risks.size >= 17)
        }
        // anestesia general incluye los riesgos de vía aérea
        val gen = Consent.riskSummary(Consent.TYPES[0]).joinToString(" ")
        assertTrue("intubar", "intubar" in gen || "vía aérea difícil" in gen)
        assertTrue("aspiración", "Aspiración" in gen)
        assertTrue("hipertermia maligna", "Hipertermia maligna" in gen)
    }

    // ---------- Fórmulas nuevas ----------

    @Test
    fun `CPP y PAM`() {
        eq(80.0, CalcEngine.meanArterial(120.0, 60.0))
        eq(70.0, CalcEngine.cpp(80.0, 10.0))
        eq(55.0, CalcEngine.cpp(70.0, 15.0))
    }

    @Test
    fun `ANH con vectores dorados`() {
        // 70 kg hombre → EBV 4900 mL; Hct 42→28: 4900×(42−28)/((42+28)/2) = 1960 mL
        val r = CalcEngine.anh(4900.0, 42.0, 28.0, 24.0)
        eq(1960.0, r.anhVolumeMl, tol = 1.0)
    }

    @Test
    fun `MELD-Na vector estándar`() {
        // Bili 3, INR 1,7, Creat 3 → MELD ≈ 27,0; Na 130 → MELD-Na ≈ 30
        val r = CalcEngine.meldNa(3.0, 1.7, 3.0, 130.0, false)
        eq(27.0, r.meld, tol = 0.3)
        eq(30.0, r.meldNa, tol = 0.3)
        assertTrue(r.mortality90d.contains("≥ 50"))
        // diálisis fija creat 4: MELD = 9,57×ln(4) + 6,43 = 19,70
        val r2 = CalcEngine.meldNa(1.0, 1.0, 0.8, 137.0, true)
        eq(19.7, r2.meld, tol = 0.3)
    }

    @Test
    fun `Qp Qs y CaO2`() {
        // L→R clásico: (98−70)/(97−80) = 28/17 = 1,65
        eq(1.647, CalcEngine.qpQs(98.0, 70.0, 97.0, 80.0), tol = 0.01)
        // CaO2: 1,34×15×1 + 0,0031×100 = 20,1 + 0,31 = 20,41
        eq(20.41, CalcEngine.caO2(15.0, 1.0, 100.0), tol = 0.01)
        eq(1020.5, CalcEngine.do2(5.0, 20.41), tol = 0.5)
        // Fick: VO2 250, Ca 20, Cv 15 → 250/(10×5) = 5 L/min
        eq(5.0, CalcEngine.fickCo(250.0, 20.0, 15.0))
    }

    @Test
    fun `SVR PVR BSA y flujo de bomba`() {
        eq(1360.0, CalcEngine.svr(90.0, 5.0, 5.0))       // (85×80)/5
        eq(200.0, CalcEngine.pvr(20.0, 10.0, 4.0))       // (10×80)/4
        eq(1.818, CalcEngine.bsa(170.0, 70.0), tol = 0.01) // √(11900/3600)
        eq(4.363, CalcEngine.pumpFlow(1.818, 2.4), tol = 0.02)
        eq(24500.0, CalcEngine.heparinUnits(3.5, 70.0))  // 350 UI/kg × 70
        eq(2.0, CalcEngine.rbcUnits(70.0, 8.0, 10.0))    // ΔHb 2 × 70/70
    }

    @Test
    fun `MgSO4 y ajustes ventilatorios`() {
        eq(5.0, CalcEngine.mgso4InfusionMlH(1.0))        // 1 g/h en ampolla 2 g/10 mL → 5 mL/h
        eq(13.0, CalcEngine.suggestedRr(1300.0, 100.0))  // MV 1300 / VT 100
        eq(17.0, CalcEngine.rrForEtco2(14.0, 48.0, 40.0)) // 14×48/40 = 16,8 → redondeo 17
    }
}
