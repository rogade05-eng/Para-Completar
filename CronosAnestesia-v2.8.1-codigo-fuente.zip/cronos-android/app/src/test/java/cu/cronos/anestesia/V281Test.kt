package cu.cronos.anestesia

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v2.8.1 — Revisión del código fuente publicado + feedback clínico del autor:
 *  · Motor acidobásico de la gasometría (pH, PaCO2, HCO3, EB → desequilibrio).
 *  · Calculadora de hematocrito (Hto final tras sangrado, Hb ↔ Hto).
 *  · Pediatría en el 4.º año del temario (ya no en 2.º).
 *  · 3 perlas bibliográficas nuevas (FA, transfusiones, vía aérea politrauma).
 *  · Buscador global de temas.
 */
class V281Test {

    // ------------------------- Acidobásico -------------------------

    private fun ab(pH: Double, pa: Double, hco3: Double, be: Double = 0.0) =
        CalcEngine.acidBaseAnalysis(pH, pa, hco3, be)

    @Test
    fun `acidosis metabolica pura con compensacion de Winters adecuada`() {
        // HCO3 12 → PaCO2 esperada = 1,5 × 12 + 8 = 26 (± 2)
        val r = ab(7.20, 26.0, 12.0, -12.0)
        assertEquals(CalcEngine.AcidBaseType.METABOLIC_ACIDOSIS, r.primary)
        assertFalse(r.mixed)
        assertEquals(CalcEngine.Compensation.ADEQUATE, r.respComp)
        assertEquals(-1, r.acidemia)
    }

    @Test
    fun `acidosis metabolica con compensacion inadecuada es mixta`() {
        // PaCO2 40 ≫ esperada 26 → componente respiratorio añadido
        val r = ab(7.18, 40.0, 12.0)
        assertEquals(CalcEngine.AcidBaseType.METABOLIC_ACIDOSIS, r.primary)
        assertTrue(r.mixed)
        assertEquals(CalcEngine.Compensation.INADEQUATE, r.respComp)
    }

    @Test
    fun `trastorno mixto de entrada (acidemia con ambos componentes alterados)`() {
        val r = ab(7.10, 60.0, 15.0)
        assertEquals(CalcEngine.AcidBaseType.MIXED, r.primary)
        assertTrue(r.mixed)
    }

    @Test
    fun `alcalosis respiratoria aguda compensada`() {
        // PaCO2 30 (Δ = −1) → HCO3 esperada aguda = 22 (± 2)
        val r = ab(7.48, 30.0, 23.0)
        assertEquals(CalcEngine.AcidBaseType.RESPIRATORY_ALKALOSIS, r.primary)
        assertTrue(r.respAcute == true)
        assertEquals(CalcEngine.Compensation.ADEQUATE, r.metComp)
        assertFalse(r.mixed)
    }

    @Test
    fun `acidosis respiratoria cronica compensada`() {
        // PaCO2 60 (Δ = +2) → HCO3 esperada crónica = 32 (± 2)
        val r = ab(7.34, 60.0, 33.0)
        assertEquals(CalcEngine.AcidBaseType.RESPIRATORY_ACIDOSIS, r.primary)
        assertTrue(r.respAcute == false)
        assertEquals(CalcEngine.Compensation.ADEQUATE, r.metComp)
    }

    @Test
    fun `alcalosis metabolica y normalidad`() {
        val alk = ab(7.50, 44.0, 30.0, 6.0)
        assertEquals(CalcEngine.AcidBaseType.METABOLIC_ALKALOSIS, alk.primary)
        val normal = ab(7.40, 40.0, 24.0, 0.0)
        assertEquals(CalcEngine.AcidBaseType.NORMAL, normal.primary)
        assertEquals(0, normal.acidemia)
    }

    @Test
    fun `estimacion cruzada entre HCO3 y EB`() {
        // Solo EB: HCO3 ≈ 24 + EB
        val r = ab(7.28, 30.0, 0.0, -10.0)
        assertEquals(14.0, r.hco3, 0.01)
        assertEquals(-10.0, r.be, 0.01)
        assertEquals(CalcEngine.AcidBaseType.METABOLIC_ACIDOSIS, r.primary)
        // Solo HCO3: EB ≈ HCO3 − 24
        val r2 = ab(7.50, 45.0, 30.0, 0.0)
        assertEquals(6.0, r2.be, 0.01)
    }

    // ------------------------- Hematocrito -------------------------

    @Test
    fun `hto final tras sangrado y conversiones Hb-Hto`() {
        // Hombre 70 kg → EBV 4900 mL; sangra 1000 mL con Hto 40 → 40 × 3900/4900 ≈ 31,8
        val ebv = CalcEngine.estimatedBloodVolume(70.0, 0)
        val hto = CalcEngine.hctAfterBloodLoss(ebv, 40.0, 1000.0)
        assertEquals(40.0 * 3900.0 / 4900.0, hto, 0.01)
        // pérdida ≥ EBV → clampa a EBV: Hto 0 (sin eritrocitos restantes)
        assertEquals(0.0, CalcEngine.hctAfterBloodLoss(4900.0, 40.0, 5000.0), 0.01)
        assertEquals(30.0, CalcEngine.hctFromHb(10.0), 0.001)
        assertEquals(10.0, CalcEngine.hbFromHct(30.0), 0.001)
        assertEquals(0.0, CalcEngine.hctAfterBloodLoss(0.0, 40.0, 500.0), 0.001)
    }

    @Test
    fun `sangrado maximo permitido sigue funcionando`() {
        val ebv = CalcEngine.estimatedBloodVolume(70.0, 0) // 4900
        val abl = CalcEngine.allowableBloodLoss(ebv, 40.0, 30.0)
        assertEquals(4900.0 * 10.0 / 35.0, abl, 0.01)
    }

    // ------------------------- Pediatría en 4.º año -------------------------

    @Test
    fun `pediatria se estudia en R4 y ya no en R2 ni R3`() {
        val r2 = RESIDENCY.first { it.curso == "R2" }
        val r3 = RESIDENCY.first { it.curso == "R3" }
        val r4 = RESIDENCY.first { it.curso == "R4" }
        assertTrue(r2.areas.none { "ediatr" in it.title })
        assertTrue(r3.areas.none { "ediatr" in it.title })
        val basica = r4.areas.firstOrNull { "ediatria b" in it.title }
        val avanzada = r4.areas.firstOrNull { "ediatr" in it.title && "avanzada" in it.title }
        assertNotNull("R4 debe contener «Pediatria básica»", basica)
        assertNotNull("R4 debe contener «Pediatría avanzada y neonatal»", avanzada)
        // Temas intactos en el traslado
        assertEquals(6, basica!!.topics.size)
        assertEquals(4, avanzada!!.topics.size)
        // Orden pedagógico: básica antes de avanzada
        assertTrue(r4.areas.indexOf(basica) < r4.areas.indexOf(avanzada))
    }

    // ------------------------- Perlas nuevas (feedback clínico) -------------------------

    @Test
    fun `tres perlas bibliograficas del feedback clinico`() {
        val titulos = PEARLS.map { it.titulo }
        assertTrue(titulos.any { "Fibrilación auricular" in it })
        assertTrue(titulos.any { "Transfusiones" in it && "hemoderivados" in it })
        assertTrue(titulos.any { "politraumatizado" in it })
        // Las bibliográficas se atribuyen a Cronos (sin video Medik Brain)
        PEARLS.filter { it.video.startsWith("Bibliografía") }.forEach { p ->
            assertTrue(p.video.isNotBlank())
        }
        assertEquals(3, PEARLS.count { it.video.startsWith("Bibliografía") })
    }

    // ------------------------- Buscador global -------------------------

    @Test
    fun `buscador indexa catalogos y normaliza`() {
        val idx = buildSearchIndex()
        assertTrue("Índice amplio", idx.size >= 200)
        assertTrue(idx.all { it.tab in 0..21 })
        assertTrue(idx.any { it.section == "Perlas" })
        assertTrue(idx.any { it.section == "Emergencias" && it.detail != null })
        // la FA nueva aparece en el índice
        assertTrue(idx.any { "Fibrilación auricular" in it.title })
        // normalización sin tildes
        assertEquals("neumotorax a tension", searchNormalize("Neumotórax a Tensión"))
        assertTrue(idx.any { searchNormalize(it.title).contains(searchNormalize("neumotorax")) })
    }

    // ------------------------- Traducciones v2.8.1 -------------------------

    @Test
    fun `ola I18nV281 registrada en EN y PT con claves del feedback`() {
        I18n.init()
        val en = L10n.table(Lang.EN)!!
        val pt = L10n.table(Lang.PT)!!
        assertTrue("EN crece con la ola", L10n.registered(Lang.EN) >= 4400)
        assertTrue("PT crece con la ola", L10n.registered(Lang.PT) >= 4300)

        // Perlas nuevas traducidas
        val faEs = "Fibrilación auricular perioperatoria: tratamiento y manejo"
        assertTrue(en.containsKey(faEs)); assertTrue(pt.containsKey(faEs))
        val trEs = "Transfusiones: plaquetas, plasma y hemoderivados"
        assertTrue(en.containsKey(trEs)); assertTrue(pt.containsKey(trEs))
        val vaEs = "Vía aérea en el paciente politraumatizado"
        assertTrue(en.containsKey(vaEs)); assertTrue(pt.containsKey(vaEs))

        // Acidobásico y buscador
        val claves = listOf(
            "Trastorno primario", "Equilibrio acidobásico", "HCO3 (bicarbonato)",
            "EB (exceso de bases)", "Buscador de todos los temas",
            "Acidosis metabólica con compensación respiratoria adecuada.",
            "Trastorno mixto (metabólico + respiratorio)"
        )
        claves.forEach { k ->
            assertTrue("falta EN: $k", en.containsKey(k))
            assertTrue("falta PT: $k", pt.containsKey(k))
        }
        // Degradación elegante: todo el contenido nuevo de perlas cubierto
        PEARLS_RAW.forEach { p ->
            listOf(p.titulo, p.resumen, p.errores, p.alarma, p.aplicacion).forEach { lit ->
                if (lit.isNotBlank() && !lit.startsWith("Bibliografía")) {
                    assertTrue("perla sin EN: ${lit.take(40)}", en.containsKey(lit))
                    assertTrue("perla sin PT: ${lit.take(40)}", pt.containsKey(lit))
                }
            }
            p.claves.forEach { c ->
                assertTrue("clave sin EN: ${c.take(40)}", en.containsKey(c))
                assertTrue("clave sin PT: ${c.take(40)}", pt.containsKey(c))
            }
        }
    }

    @Test
    fun `deep links de crisis y buscador`() {
        assertEquals(20, DeepLinks.tabFor("crisis"))
        assertEquals(21, DeepLinks.tabFor("buscador"))
        assertEquals(0, DeepLinks.tabFor("inicio"))
    }
}
