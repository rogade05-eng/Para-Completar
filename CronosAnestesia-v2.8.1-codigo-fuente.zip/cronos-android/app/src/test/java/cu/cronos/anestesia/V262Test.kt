package cu.cronos.anestesia

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.io.File

/**
 * Pruebas v2.6.2: créditos de desarrollo ampliados. Contrato:
 *  - El equipo de desarrollo queda acreditado con ambos nombres
 *    (Ronald García Deroncele · Dr. Romay Díaz Deroncele) en la portada
 *    y en Ajustes, en los tres idiomas, sin traducir los nombres propios.
 *  - El contacto de WhatsApp y emisión de licencias sigue siendo Ronald
 *    (DEVELOPER_NAME intacto).
 * Las comprobaciones de recursos (strings.xml / build.gradle.kts) se leen
 * del árbol de fuentes con guardas Assume: si el entorno de pruebas no
 * expone el directorio del módulo, se omiten sin fallar.
 */
class V262Test {

    // ---------------------- 1. Constantes del equipo ----------------------

    @Test
    fun `credits_constante_con_ambos_desarrolladores`() {
        val c = LicenseContact.DEVELOPER_CREDITS
        assertTrue(c.contains("Ronald García Deroncele"))
        assertTrue(c.contains("Dr. Romay Díaz Deroncele"))
        assertTrue("separador neutro «·»", c.contains("·"))
        assertEquals(2, c.split("·").size)
    }

    @Test
    fun `contacto_whatsapp_intacto`() {
        assertEquals("5355301268", LicenseContact.WHATSAPP_PHONE)
        assertEquals("Ronald García Deroncele", LicenseContact.DEVELOPER_NAME)
    }

    // ---------------------- 2. Paridad de recursos ------------------------

    private fun moduleDir(): File? {
        var d = File(".").absoluteFile
        repeat(4) {
            if (File(d, "src/main/res/values/strings.xml").isFile) return d
            d = d.parentFile ?: return null
        }
        return null
    }

    private fun developerLine(dir: String, key: String): String? {
        val f = File(moduleDir() ?: return null, "src/main/res/$dir/strings.xml")
        assumeTrue("strings.xml de $dir disponible", f.isFile)
        val line = f.readLines().firstOrNull { it.contains("name=\"$key\"") }
        assumeTrue("clave $key en $dir", line != null)
        return line
    }

    @Test
    fun `strings_los_tres_idiomas_acreditan_ambos_nombres`() {
        listOf("values", "values-en", "values-pt").forEach { dir ->
            val clave = developerLine(dir, "settings_developer") ?: return
            assertTrue(dir, clave.contains("Ronald García Deroncele"))
            assertTrue(dir, clave.contains("Dr. Romay Díaz Deroncele"))
        }
    }

    @Test
    fun `strings_splash_los_tres_idiomas_acreditan_ambos_nombres`() {
        listOf("values", "values-en", "values-pt").forEach { dir ->
            val clave = developerLine(dir, "splash_developer") ?: return
            assertTrue(dir, clave.contains("Ronald García Deroncele"))
            assertTrue(dir, clave.contains("Dr. Romay Díaz Deroncele"))
        }
    }

    @Test
    fun `verbos_desarrollado_por_idioma_correcto`() {
        // ES/PT comparten raíz latina; EN usa "Developed"
        assertTrue(developerLine("values", "settings_developer")!!.contains("Desarrollado por"))
        assertTrue(developerLine("values-en", "settings_developer")!!.contains("Developed by"))
        assertTrue(developerLine("values-pt", "settings_developer")!!.contains("Desenvolvido por"))
    }

    // ---------------------- 3. Versión ------------------------------------

    @Test
    fun `build_gradle_declara_2_7_0_code_30`() {
        val f = File(moduleDir() ?: return, "build.gradle.kts")
        assumeTrue("build.gradle.kts disponible", f.isFile)
        val txt = f.readText()
        // v2.8.1: la versión avanza (32 / 2.8.1); el test vigila que sea ≥ la
        // de esta ola y que la configuración de tamaño siga presente.
        assertTrue(txt.contains("versionCode = 32"))
        assertTrue(txt.contains("versionName = \"2.8.1\""))
        assertTrue("abiFilters (hotfix de tamaño absorbido)", txt.contains("abiFilters"))
    }
}
