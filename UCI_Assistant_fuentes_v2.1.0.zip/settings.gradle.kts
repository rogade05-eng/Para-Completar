pluginManagement {
    repositories {
        maven("file:///home/z/local-maven") // repositorio local reconstruido desde caché (evita 502/429 de red)
        maven("https://maven.aliyun.com/repository/gradle-plugin") // espejo del portal de plugins
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        gradlePluginPortal()
        mavenCentral()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        maven("file:///home/z/local-maven") // repositorio local reconstruido desde caché
        maven("https://maven.aliyun.com/repository/google") // espejo de Google Maven
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

rootProject.name = "UCIAssistant"
include(":app")
