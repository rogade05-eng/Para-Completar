package com.uciassistant

import com.uciassistant.domain.Sm2
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Pruebas unitarias del algoritmo SM-2 (sección 4.8 del contrato). */
class Sm2Test {

    @Test
    fun primeraRespuestaCorrecta_intervaloUnDia() {
        val r = Sm2.next(4)
        assertEquals(1, r.repetitionNumber)
        assertEquals(1, r.intervalDays)
        assertTrue("EF fuera de rango: ${r.easinessFactor}", r.easinessFactor in 2.4..2.6)
    }

    @Test
    fun segundaRepeticion_intervaloSeisDias() {
        val r1 = Sm2.next(4)
        val r2 = Sm2.next(4, r1.repetitionNumber, r1.easinessFactor, r1.intervalDays)
        assertEquals(2, r2.repetitionNumber)
        assertEquals(6, r2.intervalDays)
    }

    @Test
    fun respuestaIncorrecta_reiniciaYRepiteManana() {
        val r = Sm2.next(1, 3, 2.5, 10)
        assertEquals(0, r.repetitionNumber)
        assertEquals(1, r.intervalDays)
    }

    @Test
    fun factorFacilidad_nuncaPorDebajoDe1_3() {
        var prev = Sm2.next(1)
        repeat(20) {
            prev = Sm2.next(0, prev.repetitionNumber, prev.easinessFactor, prev.intervalDays)
            assertTrue("EF ${prev.easinessFactor} < mínimo", prev.easinessFactor >= Sm2.MIN_EASINESS)
        }
    }

    @Test
    fun secuenciaLarga_creceIntervalo() {
        var r = Sm2.next(5)
        repeat(6) { r = Sm2.next(5, r.repetitionNumber, r.easinessFactor, r.intervalDays) }
        assertTrue("Intervalo no crece: ${r.intervalDays}", r.intervalDays > 6)
    }
}
