package com.uciassistant

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.LaunchedEffect
import com.uciassistant.ui.nav.UciAppRoot
import com.uciassistant.ui.theme.UciTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            // Segunda puerta de la auto-instalación (la primera es UciApp.onCreate):
            // si al abrir la actividad la biblioteca sigue vacía, se valida e instala
            // el paquete incluido en transacción (contrato, paso 10). Idempotente.
            LaunchedEffect(Unit) {
                runCatching { UciApp.instance.importer.tryAutoInstallIfNeeded() }
                    .onFailure { android.util.Log.e(TAG, "Auto-instalación inicial falló", it) }
            }
            UciTheme {
                UciAppRoot()
            }
        }
    }

    companion object {
        private const val TAG = "UciMain"
    }
}
