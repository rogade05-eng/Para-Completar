package com.uciassistant.clinical

/**
 * Calculadora de perfusiones continuas (v1.5.0).
 * Convierte dosis en mcg/kg/min (o mcg/kg/h) a velocidad de bomba en ml/h
 * según la concentración de la solución. Incluye:
 *  · Presentación comercial (ampolla/vial) de cada fármaco.
 *  · Reglas clásicas de preparación pediátrica por peso (regla del 0,6, del 15…).
 *  · Rango habitual de dosis con verificación.
 *  · Contenido educativo: por qué se usan jeringuillas perfusoras, bombas de
 *    perfusión continua e infusiones continuas, y por qué la presentación y
 *    preparación de los vasoactivos es distinta.
 * Concentraciones pediátricas estándar; el usuario puede personalizar la
 * concentración real de su unidad. Verificación final SIEMPRE doble con
 * enfermería. Referencias: Ruza, Nelson, protocolos SECIp.
 */
data class InfusionDrug(
    val id: String,
    val name: String,
    val category: String,               // vasoactivo | inodilatador | vasodilatador | sedoanalgesico
    val concentrationMgPerMl: Double,   // concentración estándar de referencia
    val presentation: String,           // presentación comercial (ampolla/vial)
    val standardText: String,           // cómo se prepara habitualmente
    val typicalDoseText: String,        // rango habitual (texto)
    val minDose: Double,                // mcg/kg/min para verificación
    val maxDose: Double,                // mcg/kg/min para verificación
    val notes: String,
    val ruleMgPerKg: Double? = null,    // regla clásica: mg/kg de peso → TOTAL mg en jeringa de 50 ml
    val prepSteps: List<String> = emptyList(),
    val ampMgPerMl: Double? = null,     // concentración de la ampolla/vial comercial (mg/ml)
    val dosedPerHour: Boolean = false   // rango y cálculo habituales en mcg/kg/h
)

object Infusions {

    val drugs: List<InfusionDrug> = listOf(
        InfusionDrug("adrenalina", "Adrenalina (epinefrina)", "vasoactivo", 0.016,
            "Ampolla 1 mg/1 ml (1 mg/ml); algunas unidades usan jeringa pediátrica diluida 0,1 mg/ml",
            "0,6 × peso mg en 50 ml (= 16 mcg/ml para 8 kg; regla del 0,6)",
            "0,05–1 mcg/kg/min (anafilaxia/shock)", 0.01, 1.0,
            "Doble vigilancia; no mezclar con bicarbonato en la misma línea.",
            ruleMgPerKg = 0.6,
            ampMgPerMl = 1.0,
            prepSteps = listOf(
                "Usar jeringuilla perfusora de 50 ml con etiqueta normalizada (fármaco, concentración, diluyente, fecha y hora).",
                "Extraer 0,6 × peso (kg) mg de adrenalina. Ejemplo: 10 kg → 6 mg = 6 ml de la ampolla de 1 mg/ml.",
                "Completar con SF 0,9 % hasta 50 ml → concentración final 12 × peso mcg/ml.",
                "Resultado de la regla del 0,6: 1 ml/h = 0,2 mcg/kg/min.",
                "Purgar la línea con el propio fármaco sin inyectar bolo accidental; doble comprobación de enfermería.")),
        InfusionDrug("noradrenalina", "Noradrenalina (norepinefrina)", "vasoactivo", 0.016,
            "Ampolla 2 mg/2 ml (1 mg/ml)",
            "0,6 × peso mg en 50 ml (regla del 0,6)",
            "0,02–1 mcg/kg/min (vasoplejía)", 0.01, 1.0,
            "Prefiere vía central; extravasación → fentolamina tópica (5-10 mg en 50 ml SF en compresa).",
            ruleMgPerKg = 0.6,
            ampMgPerMl = 1.0,
            prepSteps = listOf(
                "Jeringuilla perfusora de 50 ml etiquetada.",
                "Extraer 0,6 × peso (kg) mg de noradrenalina. Ejemplo: 10 kg → 6 mg = 3 ml de la ampolla de 2 mg/2 ml (1 mg/ml).",
                "Completar con SF 0,9 % hasta 50 ml → 12 × peso mcg/ml; 1 ml/h = 0,2 mcg/kg/min.",
                "Vía central preferente; si vía periférica, vigilar estrechamente el punto de punción.",
                "Doble comprobación y registro de la velocidad en ml/h Y en mcg/kg/min.")),
        InfusionDrug("dopamina", "Dopamina", "vasoactivo", 0.32,
            "Ampolla 200 mg/5 ml (40 mg/ml)",
            "15 × peso mg en 50 ml (= 300 × peso mcg/ml; regla del 15)",
            "2–20 mcg/kg/min", 2.0, 20.0,
            "Efecto dosis-dependiente: renal → inotrópico → vasopresor. Arritmogénica.",
            ruleMgPerKg = 15.0,
            ampMgPerMl = 40.0,
            prepSteps = listOf(
                "Jeringuilla perfusora de 50 ml etiquetada.",
                "Extraer 15 × peso (kg) mg de dopamina. Ejemplo: 10 kg → 150 mg = 3,75 ml de la ampolla de 40 mg/ml.",
                "Completar con SF 0,9 % o G5 % hasta 50 ml → 300 × peso mcg/ml.",
                "Resultado de la regla del 15: 1 ml/h = 5 mcg/kg/min.",
                "Doble comprobación; valorar vía central por el riesgo de extravasación.")),
        InfusionDrug("dobutamina", "Dobutamina", "vasoactivo", 0.32,
            "Vial 250 mg/20 ml (12,5 mg/ml)",
            "15 × peso mg en 50 ml (= 300 × peso mcg/ml; regla del 15)",
            "2–20 mcg/kg/min (inotrópico)", 2.0, 20.0,
            "Puede provocar taquiarritmias e hipotensión.",
            ruleMgPerKg = 15.0,
            ampMgPerMl = 12.5,
            prepSteps = listOf(
                "Jeringuilla perfusora de 50 ml etiquetada.",
                "Extraer 15 × peso (kg) mg de dobutamina. Ejemplo: 10 kg → 150 mg = 12 ml del vial de 12,5 mg/ml.",
                "Completar a 50 ml con SF 0,9 % o G5 % → 300 × peso mcg/ml; 1 ml/h = 5 mcg/kg/min.",
                "Doble comprobación de enfermería y monitorización de arritmias.")),
        InfusionDrug("milrinona", "Milrinona", "inodilatador", 0.02,
            "Ampolla 10 mg/10 ml (1 mg/ml)",
            "1 mg en 50 ml (= 20 mcg/ml); alternativa por peso: 0,1 × peso mg en 50 ml",
            "0,25–0,75 mcg/kg/min (inodilatador)", 0.25, 0.75,
            "Cuidado en hipotensión y fallo renal (acumula); carga 25-50 mcg/kg lenta si se usa.",
            ruleMgPerKg = null,
            ampMgPerMl = 1.0,
            prepSteps = listOf(
                "Jeringuilla perfusora de 50 ml etiquetada.",
                "Extraer 1 mg (1 ml de la ampolla de 1 mg/ml) y completar a 50 ml con SF 0,9 % → 20 mcg/ml.",
                "Si la unidad usa la regla por peso (0,1 × peso mg en 50 ml), introduzca la concentración real en el campo personalizado.",
                "Verificar hipotensión previa y función renal antes de iniciar; doble comprobación.")),
        InfusionDrug("vasopresina", "Vasopresina", "vasoactivo", 0.008,
            "Ampolla 20 UI/1 ml",
            "0,4 mg en 50 ml (= 8 mcg/ml ≈ 4 UI/ml aprox.; 1 UI ≈ 2 mcg)",
            "0,0005–0,004 mcg/kg/min (≈ 0,03–0,2 U/kg/h)", 0.0002, 0.004,
            "Ahorradora de catecolaminas en shock refractario; preparar en UI según protocolo de unidad.",
            ruleMgPerKg = null,
            ampMgPerMl = 20.0,
            prepSteps = listOf(
                "Jeringuilla perfusora de 50 ml etiquetada EN UNIDADES (UI/ml final).",
                "Dilución de referencia: 0,4 mg (≈ 200 UI) en 50 ml → 8 mcg/ml ≈ 4 UI/ml.",
                "Si el protocolo de la unidad trabaja en UI/kg/h, introducir la concentración real en UI→mg en el campo personalizado.",
                "Doble comprobación: las preparaciones en UI son fuente clásica de errores de 10×.")),
        InfusionDrug("nitroprusiato", "Nitroprusiato de sódico", "vasodilatador", 0.06,
            "Vial 50 mg (polvo liofilizado para reconstituir)",
            "3 × peso mg en 50 ml (= 60 × peso mcg/ml; regla del 3)",
            "0,3–5 mcg/kg/min (vasodilatador)", 0.1, 5.0,
            "Proteger de la luz; riesgo de toxicidad por cianuro con dosis altas o prolongadas y en fallo renal.",
            ruleMgPerKg = 3.0,
            ampMgPerMl = 5.0,
            prepSteps = listOf(
                "Reconstituir el vial de 50 mg con 2-3 ml de G5 % (nunca con electrolitos concentrados).",
                "Extraer 3 × peso (kg) mg. Ejemplo: 10 kg → 30 mg (6 ml del vial reconstituido a 5 mg/ml).",
                "Completar a 50 ml con G5 % → 60 × peso mcg/ml; 1 ml/h = 1 mcg/kg/min.",
                "Proteger la jeringa y la línea de la luz con envoltorio opaco; renovar cada 24 h.",
                "Vigilar cianosis tipo chocolate (metahemoglobinemia) y lactato; dosis máx habitual 5 mcg/kg/min.")),
        InfusionDrug("midazolam", "Midazolam", "sedoanalgesico", 0.1,
            "Ampolla 5 mg/5 ml (1 mg/ml); vial hospitalario 50 mg/10 ml (5 mg/ml)",
            "5 mg en 50 ml (= 0,1 mg/ml = 100 mcg/ml)",
            "1–6 mcg/kg/min (0,06–0,36 mg/kg/h)", 1.0, 6.0,
            "Acumula en fallo renal/obesidad; sedación profunda requiere vigilancia y objetivo RASS/COMFORT.",
            ruleMgPerKg = null,
            ampMgPerMl = 1.0,
            prepSteps = listOf(
                "Jeringuilla perfusora de 50 ml etiquetada.",
                "Extraer 5 mg (5 ml de la ampolla de 1 mg/ml o 1 ml del vial de 5 mg/ml) y completar a 50 ml con SF 0,9 % o G5 % → 100 mcg/ml.",
                "Asociar analgesia (fentanilo/morfina) si hay dolor: el midazolam solo no analgesia.",
                "Titular según objetivo de sedación documentado; vigilar abstinencia al retirar (WAT-1).")),
        InfusionDrug("fentanilo", "Fentanilo", "sedoanalgesico", 0.001,
            "Ampolla 0,1 mg/2 ml (50 mcg/ml); 0,5 mg/10 ml (50 mcg/ml)",
            "Dilución pediátrica/neonatal: 50 mcg en 50 ml (= 1 mcg/ml); alternativa 0,5 mg en 500 ml",
            "1–4 mcg/kg/h → en mcg/kg/min: 0,017–0,067", 0.017, 0.067,
            "Toracorrigidez con dosis altas rápidas; acumulación con infusión prolongada.",
            ruleMgPerKg = null,
            ampMgPerMl = 0.05,
            dosedPerHour = true,
            prepSteps = listOf(
                "Jeringuilla perfusora de 50 ml etiquetada (fentanilo en mcg/ml).",
                "Extraer 50 mcg (1 ml de la ampolla de 50 mcg/ml) y completar a 50 ml con SF 0,9 % → 1 mcg/ml (dilución neonatal/pediátrica).",
                "Para concentraciones mayores (10 mcg/ml), extraer 500 mcg (10 ml) y completar a 50 ml; introducir la concentración real en el campo personalizado.",
                "Infundir con monitorización respiratoria si el paciente no está intubado.",
                "Doble comprobación: errores de concentración (mcg vs mg) son de las más frecuentes y peligrosas.")),
        InfusionDrug("morfina", "Morfina", "sedoanalgesico", 0.02,
            "Ampolla 10 mg/1 ml (solución 1 %)",
            "1 mg/kg en 50 ml (= 20 × peso mcg/ml; 1 ml/h = 10 mcg/kg/h)",
            "10–30 mcg/kg/h → 0,17–0,5 mcg/kg/min", 0.17, 0.5,
            "Histamina: puede hipotensar; evitar en asma severa.",
            ruleMgPerKg = 1.0,
            ampMgPerMl = 10.0,
            dosedPerHour = true,
            prepSteps = listOf(
                "Jeringuilla perfusora de 50 ml etiquetada.",
                "Extraer 1 × peso (kg) mg de morfina. Ejemplo: 10 kg → 10 mg = 1 ml de la ampolla de 10 mg/ml.",
                "Completar a 50 ml con SF 0,9 % o G5 % → 20 × peso mcg/ml.",
                "Resultado: 1 ml/h = 10 mcg/kg/h de morfina.",
                "Doble comprobación; vigilar depresión respiratoria si no intubado, retención urinaria e íleo.")),
        InfusionDrug("propofol", "Propofol", "sedoanalgesico", 10.0,
            "Emulsión 1 %: vial 10 mg/ml (20 y 50 ml)",
            "Solución comercial 1 % (= 10 mg/ml = 10.000 mcg/ml), sin diluir",
            "25–200 mcg/kg/min (0,5–12 mg/kg/h según edad/protocolo)", 25.0, 200.0,
            "Adulto y sedación corta; en niños solo pautas estrictas (riesgo PRIS > 48 h).",
            ruleMgPerKg = null,
            ampMgPerMl = 10.0,
            prepSteps = listOf(
                "No se diluye habitualmente: la emulsión 1 % se carga directa en la jeringa del perfusor.",
                "Usar línea y jeringa EXCLUSIVAS (emulsión lipídica); agitar suavemente antes de usar.",
                "Cambiar jeringa y línea cada 6-12 h por riesgo de crecimiento bacteriano en la emulsión.",
                "En pediatría: solo protocolos estrictos, < 48 h, con vigilancia de lactato/creatinina (PRIS).")),
        InfusionDrug("dexmedetomidina", "Dexmedetomidina", "sedoanalgesico", 0.008,
            "Vial 200 mcg/2 ml (100 mcg/ml)",
            "0,4 mg en 50 ml (= 8 mcg/ml)",
            "0,2–1,4 mcg/kg/h → 0,003–0,023 mcg/kg/min", 0.003, 0.023,
            "Bradicardia; sin depresión respiratoria relevante; sedación ligera.",
            ruleMgPerKg = null,
            ampMgPerMl = 0.1,
            dosedPerHour = true,
            prepSteps = listOf(
                "Jeringuilla perfusora de 50 ml etiquetada.",
                "Extraer 400 mcg (4 ml del vial de 100 mcg/ml) y completar a 50 ml con SF 0,9 % → 8 mcg/ml.",
                "Para la dilución menor (4 mcg/ml): 200 mcg (2 ml) en 50 ml; ajustar el campo personalizado.",
                "Vigilar bradicardia e hipotensión al inicio y en dosis > 1 mcg/kg/h.",
                "No requiere control respiratorio; útil en destete de sedación profunda."))
    )

    /** Calcula ml/h a partir de dosis en mcg/kg/min y concentración en mg/ml. */
    fun rateMlH(doseMcgKgMin: Double, weightKg: Double, concMgPerMl: Double): Double {
        val concMcgMl = concMgPerMl * 1000.0
        return doseMcgKgMin * weightKg * 60.0 / concMcgMl
    }

    /** Variante con dosis en mcg/kg/h (fentanilo, morfina, dexmedetomidina…). */
    fun rateMlHPerHour(doseMcgKgHour: Double, weightKg: Double, concMgPerMl: Double): Double {
        val concMcgMl = concMgPerMl * 1000.0
        return doseMcgKgHour * weightKg / concMcgMl
    }

    /** Recíproco: dosis real (mcg/kg/min) a partir de ml/h programados. */
    fun doseFromRate(mlH: Double, weightKg: Double, concMgPerMl: Double): Double {
        val concMcgMl = concMgPerMl * 1000.0
        return mlH * concMcgMl / (weightKg * 60.0)
    }

    /** Concentración (mg/ml) resultante de la regla clásica por peso en jeringa de 50 ml. */
    fun concForWeight(d: InfusionDrug, weightKg: Double): Double? =
        d.ruleMgPerKg?.let { it * weightKg / 50.0 }

    /** Total de mg a extraer para la jeringa de 50 ml según la regla clásica. */
    fun mgForSyringe(d: InfusionDrug, weightKg: Double): Double? =
        d.ruleMgPerKg?.let { it * weightKg }

    /** Velocidades (ml/h) correspondientes al rango habitual con una concentración dada. */
    fun rangeRates(d: InfusionDrug, weightKg: Double, concMgMl: Double): Pair<Double, Double>? =
        if (weightKg > 0) rateMlH(d.minDose, weightKg, concMgMl) to rateMlH(d.maxDose, weightKg, concMgMl)
        else null

    fun byId(id: String) = drugs.firstOrNull { it.id == id }

    /**
     * Contenido educativo (v1.5.0): por qué los vasoactivos se administran con
     * jeringuillas perfusoras / bombas de perfusión continua y su preparación
     * es distinta a la de otros fármacos.
     */
    val pumpEducation: List<Pair<String, String>> = listOf(
        "¿Por qué jeringuilla perfusora?" to
            "Los vasoactivos y sedantes pediátricos se administran a flujos muy bajos (0,1–10 ml/h). " +
            "El perfusor de jeringa (jeringa de 50 ml) ofrece precisión de décimas de ml/h, " +
            "volumen muerto mínimo y una concentración EXACTA y estable durante horas. " +
            "Una gota más o menos de adrenalina en un lactante cambia la presión arterial: " +
            "por eso la dilución se prepara en jeringa, no en bolsa.",
        "Infusión continua frente a bolos" to
            "Con bolos repetidos la concentración plasmática sube y baja: picos (taquicardia, " +
            "hipertensión, arritmias) y valles (hipotensión, hipoperfusión). La infusión continua " +
            "mantiene un nivel constante, ajustable cada 15-30 min según la respuesta clínica. " +
            "Es la forma de elección para inotrópicos, vasopresores y sedoanalgesia prolongada; " +
            "los bolos se reservan para cargas protocolizadas o rescates.",
        "Perfusor de jeringa vs. bomba volumétrica" to
            "Perfusor de jeringa: drogas concentradas a flujos bajos (vasoactivos, sedantes, " +
            "insulina). Bomba volumétrica: volúmenes grandes (fluidos, nutrición parenteral, " +
            "antibióticos, sangre) a flujos > 10-20 ml/h. En neonatos y lactantes el volumen " +
            "muerto de la línea (1-2 ml) es relevante: al cambiar de jeringa no se purga el " +
            "fármaco hacia el paciente; se cambia en conexión en Y con llave de tres vías " +
            "sin interrumpir la perfusión.",
        "La presentación comercial NO se perfunda directa" to
            "La ampolla (adrenalina 1 mg/ml, dopamina 40 mg/ml…) es una concentración de " +
            "almacenamiento, imposible de titular con seguridad en pediatría. Siempre se DILUYE " +
            "en jeringa de 50 ml con SF 0,9 % o G5 % según la regla de la unidad (0,6 × peso en " +
            "adrenalina/noradrenalina; 15 × peso en dopamina/dobutamina; 3 × peso en " +
            "nitroprusiato; 1 mg/kg en morfina). Etiquetar siempre y usar doble comprobación.",
        "Seguridad en la administración" to
            "Preferir vía central para vasoactivos (extravasación → fentolamina tópica o " +
            "hidrocortisona según protocolo). Nunca mezclar dos drogas en la misma jeringa o " +
            "línea salvo protocolo explícito. Mantener alarmas de oclusión activadas: la " +
            "interrupción de una perfusión de adrenalina seguida de reinicio brusco provoca " +
            "picos peligrosos. Registro en ml/h y en mcg/kg/min, y doble comprobación de " +
            "enfermería en cada cambio de jeringa o de velocidad."
    )
}
