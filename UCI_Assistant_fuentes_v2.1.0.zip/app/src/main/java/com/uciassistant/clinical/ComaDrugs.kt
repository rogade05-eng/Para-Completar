package com.uciassistant.clinical

/**
 * Escala de fármacos del coma en cuidados intensivos pediátricos (v1.5.0).
 * Dosis y presentaciones organizadas por escalones: manejo inicial etiológico,
 * sedoanalgesia del coma inducido, bloqueo neuromuscular, estado epiléptico/
 * coma epiléptico y tratamientos específicos.
 * Bibliografía: Ruza (Tratado de Cuidados Intensivos Pediátricos), Nelson
 * (Textbook of Pediatrics) y protocolos SECIp / SECIp-AEP (estado epiléptico,
 * sedoanalgesia, TCE). Verificación SIEMPRE con protocolo de la unidad.
 */
object ComaDrugs {

    data class Drug(
        val id: String,
        val name: String,
        val presentation: String,
        val dose: String,          // dosis bolo y/o perfusión
        val prep: String           // preparación / puntos clave
    )

    data class Section(
        val id: String,
        val title: String,
        val intro: String,
        val drugs: List<Drug>
    )

    val sections: List<Section> = listOf(

        Section(
            "inicial", "1 · Manejo inicial del coma (ABC + etiológico)",
            "Coma (Glasgow ≤ 8): A-B-C, glucemia capilar inmediata, tratamiento " +
            "etiológico urgente y proteger la vía aérea. Antes de sedar, obtener " +
            "exploración neurológica básica y glucemia.",
            listOf(
                Drug("glucosa", "Glucosa 10 % (hipoglucemia)",
                    "Bolsa/frasco glucosa hidratada 10 % (100 mg/ml); glucosa 50 % para diluir",
                    "2–5 ml/kg IV de D10 (200–500 mg/kg). Neonato: 2 ml/kg de D10.",
                    "Si necesita D50 en pediatría, diluir 1:1 con SF (D25). Recheck glucemia a los 5–10 min; glucagón IM 0,02–0,03 mg/kg (máx 1 mg) si no hay vía."),
                Drug("naloxona", "Naloxona (coma opiáceo)",
                    "Ampolla 0,4 mg/1 ml (algunas: 2 mg/2 ml)",
                    "0,01 mg/kg IV/IM; si no responde, 0,1 mg/kg. Máximo 2 mg/dosis (repetibles; intoxicación masiva hasta 10–15 mg).",
                    "Duración corta (20–60 min): vigilar re-sedación y repetir dosis o perfusión (0,005–0,01 mg/kg/h). Precipita abstinencia en dependientes."),
                Drug("flumazenilo", "Flumazenilo (coma por benzodiacepinas)",
                    "Ampolla 0,5 mg/5 ml (0,1 mg/ml); 1 mg/10 ml",
                    "0,01 mg/kg IV (máx 0,2 mg/dosis); repetir cada 1–2 min, máx total 1 mg.",
                    "Uso selectivo: riesgo de convulsiones si intoxicación mixta/tricíclicos o dependencia a BZD. Re-sedación frecuente: necesita observación prolongada."),
                Drug("tiamina", "Tiamina (coma de causa posible por déficit)",
                    "Ampolla 100 mg/1 ml; 250 mg/1 ml",
                    "5–10 mg/kg IV lento (adolescentes: 100–500 mg).",
                    "Indicada en malnutrición, alcohólicos, dieta prolongada parenteral con glucosa — antes o junto con la glucosa."),
                Drug("piridoxina", "Piridoxina (convulsiones/coma refractarios)",
                    "Ampolla 100 mg/2 ml (50 mg/ml); 300 mg/1 ml",
                    "50–100 mg IV lento (neonato/lactante); repetibles. Prueba diagnóstica+terapéutica en convulsiones dependientes de piridoxina.",
                    "Tras administrarla, continuar con dosis diaria y completar estudio metabólico. La piridoxal-5-fosfato (si disponible) en defectos de PNPO."),
                Drug("mannitol", "Manitol 20 % (HTIC con signos de enclavamiento)",
                    "Frasco 20 %: 20 g/100 ml (200 mg/ml)",
                    "0,25–0,5 g/kg IV en 15–20 min (1,25–2,5 ml/kg); repetible c/4–8 h según presión/oclusión y osmolaridad.",
                    "Vía central recomendada (irritante). Vigilar osmolaridad sérica (objetivo < 320 mOsm/l) y diuresis; colocar sonda vesical. No en hipovolemia/lesión renal."),
                Drug("nacl_ht", "Suero salino hipertónico 3 % (HTIC / hiponatremia sintomática)",
                    "Bolsa 3 %: 3 g/100 ml (30 mg/ml = 0,5 mmol/ml aprox.)",
                    "2–5 ml/kg IV (0,06–0,15 g/kg = 1–2,5 mmol/kg Na) en 10–20 min; repetible; perfusión 0,1–1 ml/kg/h según sodio.",
                    "Alternativa estructurada al manitol en hipovolemia. Controles de sodio cada 2–4 h; corrección máx ≈ 8–10 mmol/l/24 h en hiponatremia crónica.")
            )
        ),

        Section(
            "sedacion", "2 · Sedoanalgesia del coma inducido",
            "El coma inducido (TEC grave, HTIC refractaria, estado mal epiléptico, " +
            "ventilación agresiva) exige analgesia + sedación tituladas con objetivo " +
            "documentado (RASS/COMFORT-B) y vigilancia continua.",
            listOf(
                Drug("midazolam_c", "Midazolam",
                    "Ampolla 1 mg/ml (5 mg/5 ml); vial hospitalario 5 mg/ml (50 mg/10 ml)",
                    "Bolo 0,05–0,2 mg/kg; perfusión 0,05–0,4 mg/kg/h (≈ 1–6 mcg/kg/min).",
                    "Preparación clásica: 5 mg en 50 ml → 100 mcg/ml. Titular con objetivo; asociar analgesia; vigilar abstinencia al retirar (WAT-1)."),
                Drug("fentanilo_c", "Fentanilo",
                    "Ampolla 50 mcg/ml (0,1 mg/2 ml; 0,5 mg/10 ml)",
                    "Bolo 1–2 mcg/kg; perfusión 1–4 mcg/kg/h.",
                    "Dilución pediátrica habitual: 50 mcg en 50 ml → 1 mcg/ml. Toracorrigidez con bolos rápidos; acumulación en infusión prolongada."),
                Drug("morfina_c", "Morfina",
                    "Ampolla 10 mg/1 ml (solución inyectable 1 %)",
                    "Bolo 0,05–0,1 mg/kg; perfusión 10–40 mcg/kg/h.",
                    "Regla por peso: 1 mg/kg en 50 ml → 1 ml/h = 10 mcg/kg/h. Histamina: puede hipotensar; evitar en asma grave."),
                Drug("propofol_c", "Propofol",
                    "Emulsión 1 %: 10 mg/ml (viales 20/50 ml)",
                    "Perfusión 1–4 mg/kg/h (25–66 mcg/kg/min); máx 4 mg/kg/h en pediatría.",
                    "Solo pautas estrictas en niños (riesgo PRIS: > 48 h o > 4 mg/kg/h); cambiar jeringa/línea cada 6–12 h; monitorizar lactato y creatinina."),
                Drug("ketamina_c", "Ketamina",
                    "Vial 50 mg/ml (10 ml); presentación diluida 10 mg/ml",
                    "Bolo 0,5–2 mg/kg; perfusión 0,5–2 mg/kg/h (sedación analgésica); hasta 2–5 mg/kg/h en estado mal epiléptico refractario.",
                    "Mantiene reflejos respiratorios y presión arterial (útil en shock). Sialorrea: asociar atropina/glicopirrolato; efectos de emergencia psíquica en mayores."),
                Drug("dexmedetomidina_c", "Dexmedetomidina",
                    "Vial 100 mcg/ml (200 mcg/2 ml)",
                    "0,2–1,4 mcg/kg/h (sin carga en shock).",
                    "Dilución habitual: 400 mcg en 50 ml → 8 mcg/ml. Sedación ligera sin depresión respiratoria; útil en el destete del coma inducido; vigilar bradicardia."),
                Drug("tiopental_c", "Tiopental sódico (barbitúrico)",
                    "Vial 0,5 g y 1 g — reconstituir a 25 mg/ml (2,5 %)",
                    "Bolo 3–5 mg/kg (inducción/HTIC); perfusión 1–5 mg/kg/h con objetivo EEG (burst-suppression).",
                    "Solo UCI con monitorización EEG continua: depresión miocárdica, ileo, inmunosupresión. Semivida acumulativa: retirada lenta y EEG de control.")
            )
        ),

        Section(
            "bloqueo", "3 · Bloqueo neuromuscular (cuando está indicado)",
            "Solo SIEMPRE con sedación profunda previa garantizada (el paciente " +
            "paralizado no puede manifestar dolor). Indicaciones: sincronía imposible, " +
            "HTIC refractaria, TEC grave, hipoxemia refractaria, transporte/TC.",
            listOf(
                Drug("rocuronio_c", "Rocuronio",
                    "Ampolla 10 mg/ml (50 mg/5 ml; 100 mg/10 ml)",
                    "Bolo 0,6–1 mg/kg; perfusión 0,4–0,7 mg/kg/h (≈ 8–12 mcg/kg/min).",
                    "Duración 30–45 min por bolo. Monitorización con train-of-four si perfusión prolongada; no administrar sin sedación profunda documentada."),
                Drug("vecuronio_c", "Vecuronio",
                    "Vial 4 mg — reconstituir (2 mg/ml aprox.)",
                    "Bolo 0,08–0,1 mg/kg; perfusión 0,05–0,1 mg/kg/h.",
                    "Histamina-libre pero vagolítico leve (bradicardia al revés que pancuronio). Estable menos tiempo: preparar en el momento."),
                Drug("cisatracurio_c", "Cisatracurio",
                    "Ampolla 2 mg/ml; vial 10 mg/ml",
                    "Bolo 0,1 mg/kg; perfusión 0,5–3 mcg/kg/min.",
                    "Degradación de Hoffman: independiente de hígado/riñón (elección en fallo multiorgánico). Laudano (metabólito) en dosis muy prolongadas."),
                Drug("pancuronio_c", "Pancuronio",
                    "Ampolla 2 mg/2 ml (1 mg/ml); 4 mg/2 ml (2 mg/ml)",
                    "Bolo 0,05–0,1 mg/kg; repetible c/30–60 min; perfusión 0,02–0,1 mg/kg/h.",
                    "Vagolítico: taquicardia. Económico y de larga duración; vigilar acumulación en insuficiencia renal.")
            )
        ),

        Section(
            "epileptico", "4 · Estado epiléptico y coma epiléptico (escalones SECIp-AEP)",
            "Convulsión > 5 min o repetidas sin recuperación: escalonar SIN demora. " +
            "Objetivo: control clínico y eléctrico (EEG en refractarios). Cronometrar " +
            "cada escalón.",
            listOf(
                Drug("benzos", "Escalón 1 — Benzodiacepinas",
                    "Diazepam amp 10 mg/2 ml · Midazolam amp 5 mg/5 ml (1 mg/ml) o 5 mg/ml · Lorazepam amp 4 mg/2 ml (si disponible)",
                    "Diazepam IV 0,3–0,5 mg/kg (máx 10 mg) · Midazolam IM/bucal/nasal 0,2 mg/kg (máx 10 mg) · Lorazepam IV 0,05–0,1 mg/kg (máx 4 mg)",
                    "A los 5 min puede repetirse UNA vez. Vigilar depresión respiratoria ( preparación para ventilar: bolsa-mascarilla y aspiración)."),
                Drug("fenitoina", "Escalón 2 — Fenitoína / fosfenitoína",
                    "Fenitoína amp 250 mg/5 ml (50 mg/ml) · Fosfenitoína vial 50 mg/ml EQ fenitoína",
                    "Fenitoína 20 mg/kg IV lento (≤ 1 mg/kg/min en niños; máx 50 mg/min) · Fosfenitoína 30 mg/kg EQ (más rápida y mejor tolerada).",
                    "Fenitoína SOLO en SF 0,9 % (precipita en glucosa); línea exclusiva; vigilancia cardiaca (arritmias/hipotensión). Nivel sérico a las 30–60 min."),
                Drug("fenobarbital", "Escalón 2b — Fenobarbital",
                    "Ampolla 200 mg/ml — diluir 1:10 con SF (20 mg/ml) antes de usar",
                    "Bolo 20 mg/kg IV (máx 1 g); mantenimiento 3–6 mg/kg/día.",
                    "Depresión respiratoria e hipotensión frecuentes a dosis de carga: intubación anticipada si ya sedado. Sedación prolongada: monitorizar niveles (25–40 mcg/ml)."),
                Drug("valproato", "Escalón 2c — Ácido valproico IV",
                    "Vial 400 mg + disolvente (100 mg/ml tras reconstitución)",
                    "Carga 20–25 mg/kg IV en 5–10 min (máx 40 mg/kg/día total); perfusión 1 mg/kg/h si precisa.",
                    "No en hepatopatía/mitocondrial o sospecha de error innato del metabolismo. Excelente perfil hemodinámico."),
                Drug("levetiracetam", "Escalón 2d — Levetiracetam IV",
                    "Vial 500 mg/5 ml (100 mg/ml); 1500 mg/15 ml",
                    "Carga 20 mg/kg IV en 15 min (en refractarios hasta 40–60 mg/kg); mantenimiento 10–20 mg/kg/12 h.",
                    "Buena tolerancia hemodinámica; diluir en SF o G5 a ≤ 15 mg/ml. Nefroprotección: ajustar en fallo renal."),
                Drug("midazolam_ref", "Escalón 3 — Midazolam en perfusión (estado refractario)",
                    "Ampolla 1 mg/ml o 5 mg/ml",
                    "1–2 mcg/kg/min de inicio; titular hasta suprimir crisis (protocolo unidad, dosis altas con EEG).",
                    "En UCI con intubación y monitorización. Si persiste: coma barbitúrico (tiopental 3–5 mg/kg/h, EEG burst-suppression) ± ketamina 2–5 mg/kg/h."),
                Drug("lacosamida", "Adyuvante — Lacosamida",
                    "Ampolla 10 mg/ml (viales 10/20 ml)",
                    "2–6 mg/kg IV (máx 200 mg/dosis) en ≥ 15 min; mantenimiento 2×/día.",
                    "Vigilar intervalo PR. Experiencia creciente en estado epiléptico pediátrico como tercera línea.")
            )
        ),

        Section(
            "especificos", "5 · Tratamientos específicos según etiología",
            "El coma tóxico-metabólico exige antídoto o tratamiento dirigido MIENTRAS " +
            "se estabiliza al paciente.",
            listOf(
                Drug("insulina_cdk", "Insulina rápida (cetoacidosis diabética)",
                    "Frasco insulina regular 100 UI/ml (10 ml)",
                    "0,05–0,1 UI/kg/h IV continuo (empezar tras el inicio de la reposición de volumen; en niños < 5 años considerar 0,03–0,05).",
                    "Preparación: 50 UI en 50 ml SF → 1 UI/ml; purgar la línea (adsorción). Glucosa 5–10 % cuando glicemia < 250–300 mg/dl; potasio según niveles."),
                Drug("nac", "N-acetilcisteína (paracetamol)",
                    "Vial 20 %: 200 mg/ml (10 ml = 2 g)",
                    "Protocolo 21 h: 150 mg/kg en 60 min → 50 mg/kg en 4 h → 100 mg/kg en 16 h (tramo IV). Ajustar si peso > 100 kg.",
                    "Diluir al 0,45–2 % en G5/SF. Náuseas/urticaria: ralentizar, antihistamínico. Eficacia máxima < 8–10 h de la ingestión; no esperar el nivel para empezar si sospecha alta."),
                Drug("hidroxicobalamina", "Hidroxocobalamina (cianuro — incendios/nitroprusiato)",
                    "Vial 2,5 g (polvo) — reconstituir con 100 ml SF",
                    "70 mg/kg IV en 15 min (máx 5 g); repetible a la mitad.",
                    "Rojo intenso en orina y piel (interfiere con pulsioximetría). Combinar con tiosulfato sódico 400 mg/kg IV en intoxicación grave."),
                Drug("etanol_metanol", "Fomepizol (metanol/etilenglicol)",
                    "Vial 1 g/5 ml (150 mg/ml aprox.)",
                    "Carga 15 mg/kg IV; mantenimiento 10 mg/kg c/12 h (aumentar a 15 c/4 h durante hemodiálisis).",
                    "Consultar centro toxicológico; indicar hemodiálisis según niveles/acidosis. Sin fomepizol: etanol IV con niveles — solo si experto disponible."),
                Drug("hemiferida", "Hemodiálisis / depuración extracorporea",
                    "Equipo UCI pediátrico (CVVH/HD)",
                    "Indicaciones en coma tóxico: metanol, etilenglicol, litio, salicilatos con acidosis, teofilina, amonio (errores innatos).",
                    "No retrasar por esperar niveles si la clínica es típica y grave. Consulta precoz a nefrología pediátrica.")
            )
        )
    )

    /** Encabezado docente de la pantalla. */
    val intro: String =
        "Coma = apertura ocular ausente + no obedece + no vocaliza (Glasgow ≤ 8; AVPU «P»/«U»). " +
        "Secuencia: A-B-C con protección de la vía aérea → glucemia capilar inmediata → " +
        "exploración mínima (pupilas, posición, meníngeos, olor) → tratamiento etiológico. " +
        "Toda sedación altera la exploración: documentarla ANTES de sedar."

    val references: String =
        "Bibliografía: Ruza F. Tratado de Cuidados Intensivos Pediátricos · Nelson Textbook " +
        "of Pediatrics (Kliegman) · Protocolos SECIp (Sociedad Española de Cuidados " +
        "Intensivos Pediátricos) y consenso SECIp-AEP de estado epiléptico."
}
