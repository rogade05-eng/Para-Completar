package com.uciassistant.clinical

/**
 * Motor clínico (sección 9 del contrato). Cada algoritmo es independiente de la
 * interfaz y declara: población, propósito, entradas, reglas, interpretación,
 * limitaciones, referencias, versión y estado de validación (9.1).
 * Estados de resultado según 9.2: VALID / INCOMPLETE / INVALID_INPUT / OUT_OF_RANGE / NOT_APPLICABLE.
 */

data class ScaleInput(
    val id: String,
    val label: String,
    val type: String,                 // "choice" | "number"
    val options: List<Pair<Int, String>> = emptyList(), // (valor, etiqueta) para choice
    val min: Double? = null,
    val max: Double? = null,
    val unit: String? = null,
    val required: Boolean = true
)

data class ScaleResult(
    val status: String,               // VALID | INCOMPLETE | INVALID_INPUT | OUT_OF_RANGE | NOT_APPLICABLE
    val score: Int?,
    val band: String?,                // categoría de interpretación
    val detail: String?,              // desglose por variables
    val warnings: List<String>
)

data class Scale(
    val id: String,
    val name: String,
    val population: String,
    val purpose: String,
    val inputs: List<ScaleInput>,
    val version: String,
    val effectiveDate: String,
    val reviewer: String,
    val validationStatus: String,     // VALIDATION_REQUIRED en v1 (sección 9.3)
    val interpretation: String,
    val limitations: String,
    val references: String,
    val compute: (Map<String, String>) -> ScaleResult
)

object ClinicalScales {

    private fun incomplete(msg: String) = ScaleResult("INCOMPLETE", null, null, msg, emptyList())

    /* ---------------- Glasgow pediátrico ---------------- */

    private val glasgowPed = Scale(
        id = "glasgow_pediatrico",
        name = "Escala de Glasgow pediátrica",
        population = "pediatric",
        purpose = "Valorar el nivel de conciencia en niños, con respuesta verbal ajustada a la edad.",
        version = "1.0.0",
        effectiveDate = "2026-11-04",
        reviewer = "Pendiente de validación por especialista pediátrico",
        validationStatus = "VALIDATION_REQUIRED",
        interpretation = "13–15: traumatismo leve · 9–12: moderado · ≤ 8: grave, valorar vía aérea y neuroprotección.",
        limitations = "No sustituye la exploración neurológica completa. La intubación, sedación o parálisis la hacen incalculable (registrar como no valorable).",
        references = "Teasdale G. et al. Lancet 1974; James HE. J Neurosurg Pediatr 1977; adaptaciones pediátricas estándar (PALS/ATLS).",
        inputs = listOf(
            ScaleInput("edad", "Grupo de edad para respuesta verbal", "choice",
                listOf(0 to "< 2 años (preverbal)", 1 to "2–5 años", 2 to "> 5 años"), required = true),
            ScaleInput("ocular", "Apertura ocular", "choice", listOf(
                1 to "1 · Ninguna", 2 to "2 · Al dolor", 3 to "3 · A la voz", 4 to "4 · Espontánea")),
            ScaleInput("verbal", "Respuesta verbal", "choice", listOf(
                1 to "1 · Ninguna", 2 to "2 · Quejidos indiferenciados / llanto", 3 to "3 · Llanto inapropiado / gritos",
                4 to "4 · Llanto consolable / palabras inapropiadas", 5 to "5 · Sonríe, orienta / conversación orientada")),
            ScaleInput("motora", "Respuesta motora", "choice", listOf(
                1 to "1 · Ninguna", 2 to "2 · Extensión al dolor", 3 to "3 · Flexión anormal al dolor",
                4 to "4 · Retirada al dolor", 5 to "5 · Localiza el dolor", 6 to "6 · Obedece órdenes"))
        ),
        compute = { v ->
            val eye = v["ocular"]?.toIntOrNull() ?: return@Scale incomplete("Seleccione apertura ocular.")
            val ver = v["verbal"]?.toIntOrNull() ?: return@Scale incomplete("Seleccione respuesta verbal.")
            val mot = v["motora"]?.toIntOrNull() ?: return@Scale incomplete("Seleccione respuesta motora.")
            val age = v["edad"]?.toIntOrNull() ?: return@Scale incomplete("Seleccione grupo de edad.")
            if (listOf(eye, ver, mot).any { it < 1 || it > 6 } || mot > 6) {
                return@Scale ScaleResult("OUT_OF_RANGE", null, null, null, listOf("Valores fuera de rango permitido."))
            }
            val total = eye + ver + mot
            // Ajuste pediátrico estándar de la componente verbal según edad
            val adjustedVer = when (age) {
                0 -> ver // escala preverbal ya seleccionada por el usuario
                else -> ver
            }
            val band = when {
                total >= 13 && adjustedVer >= 1 -> "Leve (GCS $total)"
                total in 9..12 -> "Moderado (GCS $total)"
                else -> "Grave (GCS $total)"
            }
            val warn = if (total <= 8) listOf("GCS ≤ 8: valore protección de vía aérea (indicación clásica de intubación).") else emptyList()
            ScaleResult("VALID", total, band,
                "Ocular $eye + Verbal $ver + Motora $mot = $total", warn)
        }
    )

    /* ---------------- RASS ---------------- */

    private val rass = Scale(
        id = "rass",
        name = "Escala RASS (agitación-sedación)",
        population = "adult y pediatric (no aplicable en neonatos)",
        purpose = "Cuantificar la sedación y la agitación del paciente crítico y fijar el objetivo de sedación.",
        version = "1.0.0",
        effectiveDate = "2026-11-04",
        reviewer = "Pendiente de validación por especialista",
        validationStatus = "VALIDATION_REQUIRED",
        interpretation = "+4 combativo … 0 despierto y tranquilo … −5 sin respuesta. El objetivo de sedación debe documentarse.",
        limitations = "Requiere paciente no paralizado. En niños preverbales la interpretación de los niveles intermedios puede variar.",
        references = "Sessler CN et al. Am J Respir Crit Care Med 2002; Ely EW et al. JAMA 2003.",
        inputs = listOf(
            ScaleInput("rass", "Nivel RASS observado", "choice", listOf(
                4 to "+4 · Combativo", 3 to "+3 · Muy agitado", 2 to "+2 · Agitado", 1 to "+1 · Intranquilo",
                0 to "0 · Despierto y tranquilo", -1 to "−1 · Somnoliento", -2 to "−2 · Sedación ligera",
                -3 to "−3 · Sedación moderada", -4 to "−4 · Sedación profunda", -5 to "−5 · Sin respuesta"))
        ),
        compute = { v ->
            val r = v["rass"]?.toIntOrNull() ?: return@Scale incomplete("Seleccione el nivel RASS.")
            val band = when {
                r >= 2 -> "Agitación (RASS $r): busque causa (dolor, hipoxia, abstinencia) antes de aumentar sedante."
                r == 1 || r == 0 -> "Despierto/tranquilo (RASS $r)"
                r == -1 -> "Somnoliento (RASS $r)"
                r == -2 || r == -3 -> "Sedación ligera-moderada (RASS $r)"
                else -> "Sedación profunda (RASS $r)"
            }
            val warn = if (r <= -4) listOf("Sedación profunda: valore reducir sedantes si no hay indicación explícita.") else emptyList()
            ScaleResult("VALID", r, band, null, warn)
        }
    )

    /* ---------------- Triángulo de Evaluación Pediátrica ---------------- */

    private val tep = Scale(
        id = "tep",
        name = "Triángulo de Evaluación Pediátrica (TEP)",
        population = "pediatric",
        purpose = "Reconocimiento visual rápido (< 60 s) de la gravedad del niño mediante apariencia, trabajo respiratorio y circulación cutánea.",
        version = "1.0.0",
        effectiveDate = "2026-11-04",
        reviewer = "Pendiente de validación por especialista pediátrico",
        validationStatus = "VALIDATION_REQUIRED",
        interpretation = "Con cualquier dominio alterado el niño se clasifica como GRAVE (o indeterminado si la valoración es dudosa): activar evaluación ABCDE inmediata.",
        limitations = "Herramienta de clasificación inicial; no cuantifica disfunción orgánica ni sustituye la evaluación primaria.",
        references = "American Academy of Pediatrics / AHA, Pediatric Education for Prehospital Professionals (PEPP); PALS 2020.",
        inputs = listOf(
            ScaleInput("apariencia", "Apariencia", "choice", listOf(
                0 to "Normal: interactúa, llanto fuerte, consolable", 1 to "Alterada: hipotonía, llanto débil, interacción mínima")),
            ScaleInput("trabajo", "Trabajo respiratorio", "choice", listOf(
                0 to "Normal: sin tiraje, sin ruidos anormales", 1 to "Alterado: tiraje, aleteo nasal, estridor, quejido, bradipnea")),
            ScaleInput("circulacion", "Circulación cutánea", "choice", listOf(
                0 to "Normal: piel rosada, relleno capilar normal", 1 to "Alterada: palidez, moteado, cianosis, relleno capilar prolongado"))
        ),
        compute = { v ->
            val a = v["apariencia"]?.toIntOrNull() ?: return@Scale incomplete("Valore la apariencia.")
            val t = v["trabajo"]?.toIntOrNull() ?: return@Scale incomplete("Valore el trabajo respiratorio.")
            val c = v["circulacion"]?.toIntOrNull() ?: return@Scale incomplete("Valore la circulación cutánea.")
            val altered = listOf(a, t, c).count { it == 1 }
            val band = when {
                altered == 0 -> "Niño ESTABLE por TEP (3 dominios normales)"
                else -> "Niño GRAVO por TEP ($altered/3 dominios alterados): evaluación ABCDE inmediata"
            }
            val detail = listOfNotNull(
                "Apariencia: " + if (a == 1) "alterada" else "normal",
                "Trabajo respiratorio: " + if (t == 1) "alterado" else "normal",
                "Circulación cutánea: " + if (c == 1) "alterada" else "normal"
            ).joinToString(" · ")
            ScaleResult("VALID", altered, band, detail,
                if (altered > 0) listOf("Prepare equipo de reanimación pediátrico y monitorización.") else emptyList())
        }
    )

    /* ---------------- PaO2/FiO2 (respiratorio, 3.4) ---------------- */

    private val pf = Scale(
        id = "pao2_fio2",
        name = "Relación PaO₂/FiO₂ (índice oxigenación)",
        population = "adult y pediatric (≥ 1 mes); criterio Phoenix pediátrico incluido",
        purpose = "Cuantificar el defecto de oxigenación y orientar la gravedad de la insuficiencia respiratoria.",
        version = "1.0.0",
        effectiveDate = "2026-11-04",
        reviewer = "Pendiente de validación por especialista",
        validationStatus = "VALIDATION_REQUIRED",
        interpretation = "Normal > 400 · 300–400 alteración leve · 200–300 moderada · ≤ 200 grave. Con soporte (VM o CPAP ≥ 5 cmH₂O), PaO₂/FiO₂ ≤ 300 cumple criterio de ARDS pediátrico (Phoenix 2024).",
        limitations = "No aplicable sin gasometría arterial simultánea a la FiO₂ conocida. No interprete sin revisar PEEP y modalidad ventilatoria.",
        references = "Phoenix Consensus, Am J Respir Crit Care Med 2024; ARDS Definition Task Force (Berlin) JAMA 2012.",
        inputs = listOf(
            ScaleInput("pao2", "PaO₂ (gasometría arterial)", "number", min = 20.0, max = 700.0, unit = "mmHg"),
            ScaleInput("fio2", "FiO₂", "number", min = 0.21, max = 1.0, unit = "fracción (0,21–1,0)"),
            ScaleInput("soporte", "Soporte respiratorio actual", "choice", listOf(
                0 to "Ninguno / oxígeno a gafas o mascarilla", 1 to "CPAP ≥ 5 cmH₂O o ventilación mecánica"))
        ),
        compute = { v ->
            val pao2 = v["pao2"]?.toDoubleOrNull() ?: return@Scale incomplete("Introduzca PaO₂.")
            val fio2 = v["fio2"]?.toDoubleOrNull() ?: return@Scale incomplete("Introduzca FiO₂.")
            val soporte = v["soporte"]?.toIntOrNull() ?: return@Scale incomplete("Seleccione el soporte respiratorio.")
            if (fio2 < 0.21 || fio2 > 1.0 || pao2 < 20 || pao2 > 700)
                return@Scale ScaleResult("OUT_OF_RANGE", null, null, null, listOf("Valores fuera de rango fisiológico permitido."))
            val ratio = pao2 / fio2
            val band = when {
                ratio > 400 -> "Normal (P/F %.0f)".format(ratio)
                ratio > 300 -> "Alteración leve (P/F %.0f)".format(ratio)
                ratio > 200 -> "Alteración moderada (P/F %.0f)".format(ratio)
                else -> "Alteración grave (P/F %.0f)".format(ratio)
            }
            val warn = mutableListOf<String>()
            if (soporte == 1 && ratio <= 300) warn.add("Cumple umbral de oxigenación ARDS pediátrico (Phoenix 2024) con soporte activo: valore criterios completos.")
            ScaleResult("VALID", ratio.toInt(), band, "PaO₂ %.0f / FiO₂ %.2f = %.0f mmHg".format(pao2, fio2, ratio), warn)
        }
    )

    /* ==================== Escalas ampliadas v1.1.0 ==================== */

    // Constructores compactos para mantener el catálogo legible
    private fun sc(
        id: String, name: String, population: String, purpose: String,
        interpretation: String, limitations: String, references: String,
        inputs: List<ScaleInput>, compute: (Map<String, String>) -> ScaleResult
    ) = Scale(
        id = id, name = name, population = population, purpose = purpose,
        version = "1.3.0", effectiveDate = "2026-11-05",
        reviewer = "Pendiente de validación por especialista",
        validationStatus = "VALIDATION_REQUIRED",
        interpretation = interpretation, limitations = limitations,
        references = references, inputs = inputs, compute = compute
    )

    private fun ch(id: String, label: String, options: List<Pair<Int, String>>) =
        ScaleInput(id, label, "choice", options)

    private fun nm(id: String, label: String, min: Double, max: Double, unit: String? = null, required: Boolean = true) =
        ScaleInput(id, label, "number", min = min, max = max, unit = unit, required = required)

    private fun sumChoices(v: Map<String, String>, vararg ids: String): Int? {
        var total = 0
        for (id in ids) {
            val n = v[id]?.toIntOrNull() ?: return null
            total += n
        }
        return total
    }

    /* ---------------- PEWS (alerta precoz pediátrica) ---------------- */

    private val pews = sc(
        "pews", "PEWS · Alerta precoz pediátrica", "pediatric",
        "Detectar precozmente el deterioro clínico del niño hospitalizado y desencadenar la respuesta escalonada.",
        "0–1: riesgo bajo · 2–3: vigilancia activa y reevaluar · 4–6: alerta médica urgente · ≥ 7: emergencia, equipo de reanimación. Sume +2 si recibió nebulizaciones en la última hora o cirugía en las últimas 24 h.",
        "Herramienta de cribado: no sustituye la valoración clínica. Un PEWS bajo no excluye deterioro (reevaluar siempre si la impresión clínica lo sugiere).",
        "Monaghan A. et al. Br J Nurs 2005; adaptaciones PALS/hospitalarias estándar.",
        listOf(
            ch("conducta", "Conducta", listOf(
                0 to "0 · Juega apropiadamente / afecto normal", 1 to "1 · Irritable o consolable",
                2 to "2 · Letárgico / agitado, difícil de consolar", 3 to "3 · Estuporoso / hiporreactivo")),
            ch("cardio", "Cardiovascular", listOf(
                0 to "0 · Rosado, relleno capilar < 2 s", 1 to "1 · Pálido, relleno capilar 2–3 s",
                2 to "2 · Moteado, relleno capilar 3–4 s", 3 to "3 · Gris-cianótico, relleno capilar > 4 s o ± 5 ml/kg/h de vasoactivo")),
            ch("resp", "Respiratorio", listOf(
                0 to "0 · Sin tiraje, retenciones normales", 1 to "1 · Tiraje subcostal o aleteo nasal",
                2 to "2 · Tiraje subcostal + intercostal, apnea o taquipnea > 20 sobre lo esperado", 3 to "3 · Tiraje severo, quejido, cianosis por FiO₂ ≥ 0,5, apnea")),
            ch("uplift", "Puntos adicionales", listOf(
                0 to "0 · Ninguno", 2 to "+2 · Nebulización en última hora o cirugía < 24 h"))
        )
    ) { v ->
        val total = sumChoices(v, "conducta", "cardio", "resp", "uplift")
            ?: return@sc incomplete("Valore los tres dominios y los puntos adicionales.")
        val band = when {
            total >= 7 -> "EMERGENCIA (PEWS $total): equipo de reanimación pediátrica"
            total >= 4 -> "ALERTA MÉDICA (PEWS $total): valoración médica urgente"
            total >= 2 -> "Vigilancia activa (PEWS $total): reevaluar y notificar"
            else -> "Riesgo bajo (PEWS $total)"
        }
        ScaleResult("VALID", total, band, "Conducta ${v["conducta"]} + Cardio ${v["cardio"]} + Resp ${v["resp"]} + Extra ${v["uplift"]} = $total",
            if (total >= 4) listOf("Considere activar el equipo de respuesta rápida pediátrica.") else emptyList())
    }

    /* ---------------- APGAR ---------------- */

    private val apgar = sc(
        "apgar", "APGAR al nacer", "neonatal",
        "Valorar la adaptación del recién nacido en el primer minuto y a los 5 minutos de vida.",
        "7–10: adaptación normal · 4–6: depresión moderada, estimulación y soporte · 0–3: reanimación inmediata. El APGAR de los 5 minutos guía la decisión de continuar o intensificar la reanimación.",
        "No indica la causa del distrés ni el pronóstico neurológico por sí solo; interpretar junto a la gasometría de cordón y la evolución.",
        "Apgar V. Curr Res Anesth Analg 1958; AHA/AAP NRP 2020.",
        listOf(
            ch("color", "Coloración", listOf(0 to "0 · Cianótico o pálido", 1 to "1 · Cuerpo rosado, extremidades cianóticas", 2 to "2 · Completamente rosado")),
            ch("fc", "Frecuencia cardíaca", listOf(0 to "0 · Ausente", 1 to "1 · < 100 lpm", 2 to "2 · ≥ 100 lpm")),
            ch("gesto", "Reflexos / gesto", listOf(0 to "0 · Sin respuesta", 1 to "1 · Gesto o mueca", 2 to "2 · Llanto o tos")),
            ch("tono", "Tono muscular", listOf(0 to "0 · Flácido", 1 to "1 · Flexión de extremidades", 2 to "2 · Movimiento activo")),
            ch("resp", "Esfuerzo respiratorio", listOf(0 to "0 · Ausente", 1 to "1 · Irregular o débil", 2 to "2 · Llanto fuerte"))
        )
    ) { v ->
        val total = sumChoices(v, "color", "fc", "gesto", "tono", "resp")
            ?: return@sc incomplete("Valore los cinco signos.")
        val band = when {
            total >= 7 -> "Adaptación normal (APGAR $total)"
            total >= 4 -> "Depresión moderada (APGAR $total): estimulación y soporte respiratorio"
            else -> "Depresión grave (APGAR $total): reanimación inmediata"
        }
        ScaleResult("VALID", total, band, "Suma de los 5 signos = $total",
            if (total <= 6) listOf("Inicie los pasos de reanimación neonatal según NRP y reevalúe a los 5 minutos.") else emptyList())
    }

    /* ---------------- Silverman-Anderson ---------------- */

    private val silverman = sc(
        "silverman", "Silverman-Anderson (distrés respiratorio neonatal)", "neonatal",
        "Cuantificar la dificultad respiratoria del recién nacido mediante retracciones torácicas.",
        "0–3: distrés leve · 4–6: moderado, soporte de oxígeno/CPAP · 7–10: grave, valorar intubación y surfactante.",
        "Puede subestimar el distrés en prematuros extremos o intubados. No aplica con ventilación mecánica activa.",
        "Silverman WA, Andersen DH. Pediatrics 1956.",
        listOf(
            ch("torax", "Movimiento torácico superior", listOf(0 to "0 · Sincrónico", 1 to "1 · Retrasado", 2 to "2 · Balanceo (" + "see-saw" + ")")),
            ch("intercostal", "Retracciones intercostales", listOf(0 to "0 · Ausentes", 1 to "1 · Leves", 2 to "2 · Marcadas")),
            ch("xifoidea", "Retracción xifoidea", listOf(0 to "0 · Ausente", 1 to "1 · Leve", 2 to "2 · Marcada")),
            ch("aleteo", "Aleteo nasal", listOf(0 to "0 · Ausente", 1 to "1 · Leve", 2 to "2 · Marcado")),
            ch("quejido", "Quejido espiratorio", listOf(0 to "0 · Ausente", 1 to "1 · Audible con estetoscopio", 2 to "2 · Audible sin estetoscopio"))
        )
    ) { v ->
        val total = sumChoices(v, "torax", "intercostal", "xifoidea", "aleteo", "quejido")
            ?: return@sc incomplete("Valore los cinco criterios.")
        val band = when {
            total >= 7 -> "Distrés GRAVE (Silverman $total): valorar vía aérea avanzada"
            total >= 4 -> "Distrés moderado (Silverman $total): oxígeno/CPAP y estrecha vigilancia"
            else -> "Distrés leve (Silverman $total)"
        }
        ScaleResult("VALID", total, band, "Suma = $total", emptyList())
    }

    /* ---------------- SOFA (adulto) ---------------- */

    private val sofa = sc(
        "sofa", "SOFA · Disfunción multiorgánica", "adult",
        "Cuantificar de forma secuencial la disfunción de seis órganos en el paciente crítico adulto y seguir su evolución.",
        "0–6: disfunción leve · 7–9: moderada · 10–12: grave · ≥ 13: crítica (mortalidad elevada). El ΔSOFA en 48 h ≥ 2 define disfunción aguda significativa (sepsis-3).",
        "No diseñado para triaje ni para un punto único como predictor absoluto. Requiere el peor valor de cada 24 h. En niños use la versión pSOFA/Phoenix.",
        "Vincent JL et al. Intensive Care Med 1996; Singer M et al. JAMA 2016 (sepsis-3).",
        listOf(
            ch("pf", "PaO₂/FiO₂ (mmHg)", listOf(
                0 to "0 · ≥ 400", 1 to "1 · < 400", 2 to "2 · < 300", 3 to "3 · < 200 con soporte", 4 to "4 · < 100 con soporte")),
            ch("plaquetas", "Plaquetas (×10³/µl)", listOf(
                0 to "0 · ≥ 150", 1 to "1 · < 150", 2 to "2 · < 100", 3 to "3 · < 50", 4 to "4 · < 20")),
            ch("bilirrubina", "Bilirrubina (mg/dl)", listOf(
                0 to "0 · < 1,2", 1 to "1 · 1,2–1,9", 2 to "2 · 2,0–5,9", 3 to "3 · 6,0–11,9", 4 to "4 · ≥ 12")),
            ch("hipotension", "Hipotensión / vasopresores", listOf(
                0 to "0 · PAS ≥ 90 sin soporte", 1 to "1 · MAP < 70", 2 to "2 · Dopamina ≤ 5 o dobutamina (cualquier dosis)",
                3 to "3 · Dopamina > 5 o adrenalina/noradrenalina ≤ 0,1", 4 to "4 · Dopamina > 15 o adrenalina/noradrenalina > 0,1")),
            ch("gcs", "Glasgow", listOf(
                0 to "0 · 15", 1 to "1 · 13–14", 2 to "2 · 10–12", 3 to "3 · 6–9", 4 to "4 · < 6")),
            ch("creatinina", "Creatinina (mg/dl) o diuresis", listOf(
                0 to "0 · < 1,2", 1 to "1 · 1,2–1,9", 2 to "2 · 2,0–3,4", 3 to "3 · 3,5–4,9 o < 500 ml/día", 4 to "4 · ≥ 5,0 o < 200 ml/día"))
        )
    ) { v ->
        val total = sumChoices(v, "pf", "plaquetas", "bilirrubina", "hipotension", "gcs", "creatinina")
            ?: return@sc incomplete("Valore los seis subsistemas.")
        val band = when {
            total >= 13 -> "Disfunción CRÍTICA (SOFA $total)"
            total >= 10 -> "Disfunción grave (SOFA $total)"
            total >= 7 -> "Disfunción moderada (SOFA $total)"
            else -> "Disfunción leve (SOFA $total)"
        }
        ScaleResult("VALID", total, band, "Respir ${v["pf"]} + Plaq ${v["plaquetas"]} + Bili ${v["bilirrubina"]} + Cardio ${v["hipotension"]} + GCS ${v["gcs"]} + Renal ${v["creatinina"]} = $total",
            if (total >= 7) listOf("Busque foco infeccioso y valore toma de cultivos + antimicrobianos en la primera hora si sospecha sepsis.") else emptyList())
    }

    /* ---------------- qSOFA ---------------- */

    private val qsofa = sc(
        "qsofa", "qSOFA · Cribado rápido de sepsis", "adult",
        "Identificar a adultos con sospecha de infección y mayor riesgo de mala evolución fuera de la UCI.",
        "0–1: riesgo bajo · ≥ 2: riesgo elevado de muerte o estancia UCI prolongada; valorar SOFA completo y iniciar el paquete de una hora.",
        "Un qSOFA bajo no excluye sepsis. Es cribado, no criterio diagnóstico.",
        "Singer M et al. JAMA 2016 (sepsis-3).",
        listOf(
            ch("fr", "Frecuencia respiratoria ≥ 22 rpm", listOf(0 to "0 · No", 1 to "1 · Sí")),
            ch("conciencia", "Alteración de la consciencia (GCS < 15)", listOf(0 to "0 · No", 1 to "1 · Sí")),
            ch("pas", "PAS ≤ 100 mmHg", listOf(0 to "0 · No", 1 to "1 · Sí"))
        )
    ) { v ->
        val total = sumChoices(v, "fr", "conciencia", "pas") ?: return@sc incomplete("Valore los tres criterios.")
        val band = if (total >= 2) "Riesgo ELEVADO (qSOFA $total)" else "Riesgo bajo (qSOFA $total)"
        ScaleResult("VALID", total, band, "Criterios positivos: $total/3",
            if (total >= 2) listOf("Complete SOFA, lactato y comience el bundle de sepsis de 1 hora si hay sospecha infecciosa.") else emptyList())
    }

    /* ---------------- CURB-65 ---------------- */

    private val curb65 = sc(
        "curb65", "CURB-65 (neumonía adquirida en la comunidad)", "adult",
        "Estimar la gravedad de la neumonía comunitaria y decidir el lugar de tratamiento.",
        "0–1: ambulatorio · 2: hospitalización · ≥ 3: alto riesgo, valorar UCI.",
        "No sustituye el juicio clínico ni la oximetría. No validado en embarazo o comorbilidad extrema.",
        "Lim WS et al. Thorax 2003.",
        listOf(
            ch("confusion", "Confusión aguda", listOf(0 to "0 · No", 1 to "1 · Sí")),
            ch("urea", "Urea > 7 mmol/l (BUN > 19 mg/dl)", listOf(0 to "0 · No", 1 to "1 · Sí")),
            ch("fr", "Frecuencia respiratoria ≥ 30 rpm", listOf(0 to "0 · No", 1 to "1 · Sí")),
            ch("ta", "PAS < 90 o PAD ≤ 60 mmHg", listOf(0 to "0 · No", 1 to "1 · Sí")),
            ch("edad", "Edad ≥ 65 años", listOf(0 to "0 · No", 1 to "1 · Sí"))
        )
    ) { v ->
        val total = sumChoices(v, "confusion", "urea", "fr", "ta", "edad") ?: return@sc incomplete("Valore los cinco criterios.")
        val band = when {
            total >= 3 -> "Alto riesgo (CURB-65 $total): valorar UCI"
            total == 2 -> "Riesgo moderado (CURB-65 $total): hospitalización"
            else -> "Bajo riesgo (CURB-65 $total): manejo ambulatorio"
        }
        ScaleResult("VALID", total, band, "Criterios positivos: $total/5", emptyList())
    }

    /* ---------------- Wells TVP ---------------- */

    private val wellsTvp = sc(
        "wells_tvp", "Wells · Probabilidad de TVP", "adult",
        "Estimar la probabilidad clínica pretest de trombosis venosa profunda antes de la imagen.",
        "≤ 0: baja (d-dímero razonable) · 1–2: moderada · ≥ 3: alta (ecografía Doppler directa).",
        "Puntuación subjetiva: la «alternativa diagnóstica más probable» requiere criterio clínico. No diagnosticar ni excluir sin d-dímero/Doppler.",
        "Wells PS et al. Lancet 1997; NEJM 2003.",
        listOf(
            ch("cancer", "Cáncer activo (tratamiento en curso o paliativo últimos 6 meses)", listOf(0 to "0 · No", 1 to "+1 · Sí")),
            ch("paralisis", "Parálisis o inmovilización de extremidad", listOf(0 to "0 · No", 1 to "+1 · Sí")),
            ch("inmovilizacion", "Encamado > 3 días o cirugía mayor < 12 semanas", listOf(0 to "0 · No", 1 to "+1 · Sí")),
            ch("dolor", "Dolor localizado por el trayecto venoso profundo", listOf(0 to "0 · No", 1 to "+1 · Sí")),
            ch("tumefaccion", "Tumefacción de toda la pierna", listOf(0 to "0 · No", 1 to "+1 · Sí")),
            ch("edema", "Edema pretibial > 3 cm respecto a la contralateral", listOf(0 to "0 · No", 1 to "+1 · Sí")),
            ch("colaterales", "Venas superficiales colaterales visibles", listOf(0 to "0 · No", 1 to "+1 · Sí")),
            ch("tvp_previa", "TVP previa documentada", listOf(0 to "0 · No", 1 to "+1 · Sí")),
            ch("alternativa", "Diagnóstico alternativo más probable", listOf(0 to "No", -2 to "−2 · Sí"))
        )
    ) { v ->
        val total = sumChoices(v, "cancer", "paralisis", "inmovilizacion", "dolor", "tumefaccion", "edema", "colaterales", "tvp_previa", "alternativa")
            ?: return@sc incomplete("Valore los nueve ítems.")
        val band = when {
            total >= 3 -> "Probabilidad ALTA (Wells $total): Doppler directo"
            total >= 1 -> "Probabilidad moderada (Wells $total)"
            else -> "Probabilidad baja (Wells $total): d-dímero para descartar"
        }
        ScaleResult("VALID", total, band, "Puntuación = $total", emptyList())
    }

    /* ---------------- CHA₂DS₂-VASc ---------------- */

    private val cha2 = sc(
        "cha2ds2_vasc", "CHA₂DS₂-VASc (tromboprofilaxis en FA)", "adult",
        "Estimar el riesgo anual de ictus en fibrilación auricular no valvular y guiar la anticoagulación.",
        "0: riesgo muy bajo (no anticoagular) · 1: bajo-moderado (valorar) · ≥ 2: alto riesgo (anticoagular, salvo contraindicación).",
        "No aplica a FA valvular (prótesis/estenosis mitral) ni a menores de 18 años. Combinar con riesgo hemorrágico (HAS-BLED).",
        "Lip GYH et al. Chest 2010; guías ESC 2024.",
        listOf(
            ch("ic", "Insuficiencia cardíaca congestiva", listOf(0 to "0 · No", 1 to "+1 · Sí")),
            ch("hta", "Hipertensión arterial", listOf(0 to "0 · No", 1 to "+1 · Sí")),
            ch("edad75", "Edad ≥ 75 años", listOf(0 to "0 · No", 2 to "+2 · Sí")),
            ch("dm", "Diabetes mellitus", listOf(0 to "0 · No", 1 to "+1 · Sí")),
            ch("acv", "Ictus / ATE previo", listOf(0 to "0 · No", 2 to "+2 · Sí")),
            ch("ecv", "Enfermedad vascular (IAM, enfermedad arterial periférica o aórtica)", listOf(0 to "0 · No", 1 to "+1 · Sí")),
            ch("edad65", "Edad 65–74 años", listOf(0 to "0 · No", 1 to "+1 · Sí")),
            ch("sexo", "Sexo femenino", listOf(0 to "0 · Varón", 1 to "+1 · Mujer"))
        )
    ) { v ->
        val total = sumChoices(v, "ic", "hta", "edad75", "dm", "acv", "ecv", "edad65", "sexo")
            ?: return@sc incomplete("Valore los ocho ítems.")
        val band = when {
            total >= 2 -> "Riesgo ALTO (CHA₂DS₂-VASc $total): anticoagulación indicada"
            total == 1 -> "Riesgo bajo-moderado ($total): individualizar"
            else -> "Riesgo muy bajo ($total): no anticoagulación"
        }
        ScaleResult("VALID", total, band, "Puntuación = $total", emptyList())
    }

    /* ---------------- Braden ---------------- */

    private val braden = sc(
        "braden", "Braden · Riesgo de úlceras por presión", "adult y pediatric",
        "Detectar pacientes con riesgo de lesiones por presión para planificar medidas preventivas.",
        "≥ 19: riesgo mínimo · 15–18: bajo · 13–14: moderado · 10–12: alto · ≤ 9: muy alto (superficie especializada y cuidados cada 2 h).",
        "En UCI combinar con hipoalbuminemia, hipotensión y soporte vasoactivo. No calcula el daño ya establecido.",
        "Bergstrom N et al. Nurs Res 1987; NPIAP 2019.",
        listOf(
            ch("percepcion", "Percepción sensorial (1 totalmente limitada → 4 sin deterioro)", listOf(1 to "1", 2 to "2", 3 to "3", 4 to "4")),
            ch("humedad", "Humedad de la piel (1 constantemente húmeda → 4 raramente)", listOf(1 to "1", 2 to "2", 3 to "3", 4 to "4")),
            ch("actividad", "Actividad física (1 encamado → 4 deambula con frecuencia)", listOf(1 to "1", 2 to "2", 3 to "3", 4 to "4")),
            ch("movilidad", "Movilidad (1 totalmente inmóvil → 4 sin limitación)", listOf(1 to "1", 2 to "2", 3 to "3", 4 to "4")),
            ch("nutricion", "Nutrición (1 muy pobre → 4 excelente)", listOf(1 to "1", 2 to "2", 3 to "3", 4 to "4")),
            ch("friccion", "Fricción y fuerzas de deslizamiento (1 problema → 3 sin problema aparente)", listOf(1 to "1", 2 to "2", 3 to "3"))
        )
    ) { v ->
        val total = sumChoices(v, "percepcion", "humedad", "actividad", "movilidad", "nutricion", "friccion")
            ?: return@sc incomplete("Valore las seis subescalas.")
        val band = when {
            total <= 9 -> "Riesgo MUY ALTO (Braden $total)"
            total <= 12 -> "Riesgo alto ($total)"
            total <= 14 -> "Riesgo moderado ($total)"
            total <= 18 -> "Riesgo bajo ($total)"
            else -> "Riesgo mínimo ($total)"
        }
        ScaleResult("VALID", total, band, "Suma = $total",
            if (total <= 12) listOf("Cambio postural programado, superficie de distribución de presión y protección de prominencias.") else emptyList())
    }

    /* ---------------- Cockcroft-Gault ---------------- */

    private val cg = sc(
        "clearance_creatinina", "Cockcroft-Gault · Clearance de creatinina", "adult",
        "Estimar el filtrado glomerular para ajustar dosis de fármacos (antibióticos, anticoagulantes).",
        "≥ 90: función normal · 60–89: leve ↓ · 30–59: moderada ↓ · 15–29: grave ↓ · < 15: fallo renal terminal.",
        "Sobrestima el FGe en obesidad y edema (usar peso ideal/ajustado). Para eGFR diagnóstico prefiera CKD-EPI.",
        "Cockcroft DW, Gault MH. Nephron 1976.",
        listOf(
            nm("edad", "Edad", 14.0, 110.0, "años"),
            nm("peso", "Peso real", 25.0, 250.0, "kg"),
            nm("creat", "Creatinina sérica", 0.2, 15.0, "mg/dl"),
            ch("sexo", "Sexo", listOf(1 to "Hombre", 0 to "Mujer (× 0,85)"))
        )
    ) { v ->
        val edad = v["edad"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la edad.")
        val peso = v["peso"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca el peso.")
        val creat = v["creat"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la creatinina.")
        val sexo = v["sexo"]?.toIntOrNull() ?: return@sc incomplete("Seleccione el sexo.")
        if (creat <= 0.0) return@sc ScaleResult("OUT_OF_RANGE", null, null, null, listOf("La creatinina debe ser > 0."))
        val factor = if (sexo == 0) 0.85 else 1.0
        val clcr = (140.0 - edad) * peso / (72.0 * creat) * factor
        val band = when {
            clcr >= 90 -> "Función normal (ClCr %.0f ml/min)".format(clcr)
            clcr >= 60 -> "Disminución leve (%.0f ml/min)".format(clcr)
            clcr >= 30 -> "Disminución moderada (%.0f ml/min)".format(clcr)
            clcr >= 15 -> "Disminución grave (%.0f ml/min)".format(clcr)
            else -> "Fallo renal terminal (%.0f ml/min)".format(clcr)
        }
        ScaleResult("VALID", clcr.toInt(), band,
            "(140 − %.0f) × %.0f / (72 × %.2f) %s = %.0f ml/min".format(edad, peso, creat, if (factor == 0.85) "× 0,85" else "", clcr),
            if (clcr < 30) listOf("Revise dosis de fármacos de eliminación renal y evite nefrotóxicos.") else emptyList())
    }

    /* ---------------- Sodio corregido (hiperglucemia) ---------------- */

    private val naCorr = sc(
        "sodio_corregido", "Sodio corregido por hiperglucemia", "adult y pediatric",
        "Corregir la hiponatremia dilucional de la hiperglucemia antes de decidir fluidoterapia.",
        "El sodio «real» es el corregido: si queda < 135 la hiponatremia es verdadera; si ≥ 135, es dilucional por glucosa.",
        "Use 0,024 (Hillier) si la glucosa es > 400 mg/dl; el coeficiente clásico 1,6 subestima la corrección.",
        "Hillier TA et al. Am J Med 1999.",
        listOf(
            nm("na", "Sodio medido", 100.0, 175.0, "mEq/l"),
            nm("glucosa", "Glucosa", 60.0, 2000.0, "mg/dl")
        )
    ) { v ->
        val na = v["na"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca el sodio medido.")
        val g = v["glucosa"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la glucosa.")
        val corr = na + 0.024 * (g - 100.0)
        val band = when {
            corr < 125 -> "Hiponatremia grave corregida (%.1f mEq/l)".format(corr)
            corr < 135 -> "Hiponatremia corregida (%.1f mEq/l)".format(corr)
            else -> "Natremia normal al corregir (%.1f mEq/l): hiponatremia dilucional".format(corr)
        }
        ScaleResult("VALID", corr.toInt(), band,
            "%.1f + 0,024 × (%.0f − 100) = %.1f mEq/l".format(na, g, corr), emptyList())
    }

    /* ---------------- Anión gap ---------------- */

    private val ag = sc(
        "anion_gap", "Anión gap (brecha aniónica)", "adult y pediatric",
        "Clasificar la acidosis metabólica y orientar su causa (lactato, cetoacidosis, tóxicos, insuficiencia renal).",
        "Normal 8–12 mEq/l (sin K). Elevado: acidosis metabólica con brecha. Normal (hiperclorémica): diarrea, ATC renal. Corrija por albúmina (−2,5 por cada 1 g/dl por debajo de 4).",
        "No interprete sin pH y HCO₃ simultáneos. Calcule el delta ratio en brechas elevadas.",
        "Emmett M, Narins RG. Arch Intern Med 1977.",
        listOf(
            nm("na", "Sodio", 100.0, 175.0, "mEq/l"),
            nm("cl", "Cloro", 60.0, 140.0, "mEq/l"),
            nm("hco3", "Bicarbonato", 2.0, 45.0, "mEq/l")
        )
    ) { v ->
        val na = v["na"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca el sodio.")
        val cl = v["cl"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca el cloro.")
        val hco3 = v["hco3"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca el bicarbonato.")
        val gap = na - cl - hco3
        val band = when {
            gap > 12.0 -> "Brecha elevada (%.1f mEq/l)".format(gap)
            gap >= 8.0 -> "Normal (%.1f mEq/l)".format(gap)
            else -> "Brecha baja (%.1f mEq/l)".format(gap)
        }
        ScaleResult("VALID", gap.toInt(), band,
            "%.1f − (%.1f + %.1f) = %.1f mEq/l".format(na, cl, hco3, gap),
            if (gap > 12.0) listOf("Calcule delta ratio (ΔAG/ΔHCO₃) y lactato: acidosis con brecha.") else emptyList())
    }

    /* ---------------- FLACC (dolor pediátrico) ---------------- */

    private val flacc = sc(
        "flacc", "FLACC · Dolor en el niño no verbal", "pediatric",
        "Cuantificar el dolor en niños de 2 meses a 7 años o no colaboradores mediante conducta observable.",
        "0: relajado y cómodo · 1–3: dolor leve · 4–6: moderado (analgesia) · 7–10: severo (intervención urgente).",
        "Puede sobrevalorar dolor en ansiedad o prurito; valorar antes y después de la intervención.",
        "Merkel SI et al. Pediatr Nurs 1997.",
        listOf(
            ch("cara", "Cara", listOf(0 to "0 · Sin expresión particular o sonríe", 1 to "1 · Fruncida o retreta", 2 to "2 · Ceño, ojos cerrados, boca abierta")),
            ch("piernas", "Piernas", listOf(0 to "0 · Normales o relajadas", 1 to "1 · Inquietas, tensas", 2 to "2 · Patea o contrae")),
            ch("actividad", "Actividad / cuerpo", listOf(0 to "0 · Quieto", 1 to "1 · Se agita, arquea", 2 to "2 · Convulsiona, rígido")),
            ch("llanto", "Llanto", listOf(0 to "0 · No llora", 1 to "1 · Gemidos o quejidos", 2 to "2 · Llanto inconsolable")),
            ch("consola", "Consolabilidad", listOf(0 to "0 · Contento, relajado", 1 to "1 · Se calma con dificultad", 2 to "2 · No se calma"))
        )
    ) { v ->
        val total = sumChoices(v, "cara", "piernas", "actividad", "llanto", "consola")
            ?: return@sc incomplete("Valore los cinco ítems.")
        val band = when {
            total >= 7 -> "Dolor SEVERO (FLACC $total): analgesia urgente"
            total >= 4 -> "Dolor moderado ($total): ajuste analgésico"
            total >= 1 -> "Dolor leve ($total)"
            else -> "Sin dolor ($total)"
        }
        ScaleResult("VALID", total, band, "Suma = $total", emptyList())
    }

    /* ---------------- Fluidos de mantenimiento 4-2-1 ---------------- */

    private val fluidos = sc(
        "fluidos_mantenimiento", "Fluidos de mantenimiento (Holliday-Segar 4-2-1)", "pediatric",
        "Calcular el goteo de mantenimiento horario del niño según el peso (método 4-2-1).",
        "Resultado en ml/h de mantenimiento. En estados hipovolémicos inicie resucitación con cristaloide 10–20 ml/kg y reevalúe; el mantenimiento se ajusta según patología (disminuir en SIADH, mayor en fiebre).",
        "No sirve para reanimación. Reconsiderar el sodio de la solución pediátrica (guías NICE/APA: isotónica de rutina).",
        "Holliday MA, Segar WE. Pediatrics 1957; NICE NG29.",
        listOf(nm("peso", "Peso corporal", 1.0, 100.0, "kg"))
    ) { v ->
        val peso = v["peso"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca el peso.")
        if (peso <= 0.0) return@sc ScaleResult("OUT_OF_RANGE", null, null, null, listOf("El peso debe ser > 0."))
        val (dia, hora) = if (peso <= 10.0) {
            100.0 * peso to 4.0 * peso
        } else if (peso <= 20.0) {
            (1000.0 + 50.0 * (peso - 10.0)) to (40.0 + 2.0 * (peso - 10.0))
        } else {
            (1500.0 + 20.0 * (peso - 20.0)) to (60.0 + (peso - 20.0))
        }
        val detail = "Mantenimiento: %.0f ml/día ≈ %.1f ml/h (4-2-1)".format(dia, hora)
        ScaleResult("VALID", hora.toInt(), "%.1f ml/h de mantenimiento".format(hora), detail,
            listOf("Bolus de resucitación pediátrico habitual: cristaloide 10–20 ml/kg en 10–20 min."))
    }

    /* ---------------- PA mínima por edad ---------------- */

    private val paMin = sc(
        "pa_minima_pediatrica", "Presión arterial mínima esperada (pediátrica)", "pediatric",
        "Determinar el umbral de hipotensión sistólica del niño según su edad (PALS).",
        "PAS mínima aceptable = 70 + (2 × edad en años). Una PAS por debajo indica hipotensión y exige reposición de volumen inmediata.",
        "Aplicable de 1 a 10 años; en neonatos y adolescentes usar tablas específicas. Hipotensión tardía: la hipoperfusión puede existir con TA normal.",
        "AHA PALS 2020-2025.",
        listOf(nm("edad", "Edad", 1.0, 10.0, "años"), nm("pas", "PAS medida", 20.0, 200.0, "mmHg"))
    ) { v ->
        val edad = v["edad"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la edad.")
        val pas = v["pas"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la PAS.")
        val minima = 70.0 + 2.0 * edad
        val band = if (pas < minima) "HIPOTENSIÓN: PAS %.0f < mínimo %.0f mmHg".format(pas, minima)
        else "PAS adecuada para la edad (≥ %.0f mmHg)".format(minima)
        ScaleResult("VALID", minima.toInt(), band, "Umbral = 70 + 2 × %.0f = %.0f mmHg".format(edad, minima),
            if (pas < minima) listOf("Cristaloide 10–20 ml/kg y reevaluación inmediata.") else emptyList())
    }

    /* ---------------- Tamaño ETT pediátrico ---------------- */

    private val ett = sc(
        "ett_pediatrico", "Tubo endotraqueal pediátrico (tamaño y profundidad)", "pediatric",
        "Estimar el diámetro interno del tubo traqueal y su profundidad de inserción por la boca según la edad.",
        "ID sin balón = edad/4 + 4; con balón, +0,5 mm. Profundidad oral ≈ 3 × ID (cm). Compruebe siempre con capnografía y auscultación bilateral.",
        "Para < 1 año usar tabla (3,0–3,5 sin balón; profundidad 9–10 cm). La fórmula asume niño normopeso.",
        "AHA PALS 2020; fórmulas clásicas de Cole / Khine.",
        listOf(nm("edad", "Edad", 1.0, 12.0, "años"))
    ) { v ->
        val edad = v["edad"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la edad.")
        val id = edad / 4.0 + 4.0
        val idBalon = id + 0.5
        val prof = 3.0 * id
        val band = "ID %s (sin balón) · %s (con balón) · profundidad ≈ %.1f cm".format(
            ("%.1f".format(id).replace(".0", "")), ("%.1f".format(idBalon).replace(".0", "")), prof)
        ScaleResult("VALID", id.toInt(), band,
            "ID = %.0f/4 + 4 = %.1f mm; profundidad = 3 × ID".format(edad, id),
            listOf("Prepare medio punto arriba y abajo del estimado y verifique con capnógrafo."))
    }

    /* ---------------- Peso estimado APLS ---------------- */

    private val pesoEst = sc(
        "peso_estimado", "Peso estimado por edad (APLS)", "pediatric",
        "Estimar el peso del niño cuando no puede pesarse, para dosis y material (fórmulas APLS).",
        "< 12 meses: (meses ÷ 2) + 4 · 1–5 años: (2 × edad) + 8 · 6–12 años: (3 × edad) + 7. En obesidad los valores subestiman el peso real.",
        "Alternativas: tarjetas tipo Broselow con talla. Confirmar peso real cuando sea posible.",
        "Advanced Paediatric Life Support (ALSG), 7.ª edición.",
        listOf(
            ch("rango", "Rango de edad", listOf(0 to "< 12 meses", 1 to "1–5 años", 2 to "6–12 años")),
            nm("valor", "Edad (meses si < 1 año; años si ≥ 1)", 0.0, 12.0)
        )
    ) { v ->
        val rango = v["rango"]?.toIntOrNull() ?: return@sc incomplete("Seleccione el rango de edad.")
        val x = v["valor"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la edad.")
        val (peso, texto) = when (rango) {
            0 -> ((x / 2.0) + 4.0) to "(meses ÷ 2) + 4"
            1 -> ((2.0 * x) + 8.0) to "(2 × edad) + 8"
            else -> ((3.0 * x) + 7.0) to "(3 × edad) + 7"
        }
        ScaleResult("VALID", peso.toInt(), "Peso estimado ≈ %.1f kg".format(peso),
            "%.1f %s → %s = %.1f kg".format(x, if (rango == 0) "meses" else "años", texto, peso),
            listOf("Dosis: use este peso solo cuando no haya peso real reciente."))
    }

    /* ---------------- Signos vitales normales por edad ---------------- */

    private val vitales = sc(
        "fc_fr_normales", "FC y FR normales por edad", "pediatric",
        "Consulta rápida de rangos de frecuencia cardíaca y respiratoria esperados por grupo de edad (despierto).",
        "Compare los valores del paciente con el rango del grupo. Bradicardia grave pediátrica: < 60 lpm a cualquier edad con mala perfusión → RCP.",
        "Rangos amplios según sueño, fiebre y dolor; la tendencia importa más que un valor aislado.",
        "AHA PALS 2020; Pediatric Advanced Life Support reference tables.",
        listOf(
            ch("grupo", "Grupo de edad", listOf(
                0 to "Neonato (< 1 mes)", 1 to "Lactante (1–12 meses)", 2 to "1–3 años",
                3 to "4–6 años", 4 to "7–10 años", 5 to "> 10 años / adolescente"))
        )
    ) { v ->
        val g = v["grupo"]?.toIntOrNull() ?: return@sc incomplete("Seleccione el grupo de edad.")
        val (fc, fr) = when (g) {
            0 -> "100–180 lpm" to "30–60 rpm"
            1 -> "100–160 lpm" to "30–53 rpm"
            2 -> "90–150 lpm" to "22–37 rpm"
            3 -> "80–140 lpm" to "20–28 rpm"
            4 -> "70–120 lpm" to "18–25 rpm"
            else -> "60–100 lpm" to "12–20 rpm"
        }
        ScaleResult("VALID", null, "FC $fc · FR $fr",
            "Rangos normales despierto para el grupo seleccionado",
            if (g <= 1) listOf("Bradicardia < 60 lpm con mala perfusión: inicie compresiones.") else emptyList())
    }

    /* ==================== Escalas y calculadoras ampliadas v1.2.0 ==================== */

    /* ---------------- APACHE II ---------------- */

    private val apache2 = sc(
        "apache2", "APACHE II · Gravedad fisiológica aguda", "adult",
        "Cuantificar la gravedad de la enfermedad en las primeras 24 h de ingreso en UCI combinando 12 variables fisiológicas, la edad y la enfermedad crónica.",
        "0–9 riesgo bajo (mortalidad hospitalaria ≈ 8 %) · 10–19 moderado (≈ 15–25 %) · 20–29 alto (≈ 40 %) · ≥ 30 muy alto (≈ 70–80 %). Estimaciones poblacionales de Knaus 1985.",
        "Calcular con el PEOR valor de cada variable en las primeras 24 h. No sustituye el juicio clínico; la creatinina puntúa doble si hay fallo renal agudo.",
        "Knaus WA et al. Crit Care Med 1985;13(10):818-829 (APACHE II original).",
        listOf(
            ch("temp", "Temperatura rectal (°C)", listOf(
                4 to "≥ 41 o ≤ 29,9", 3 to "40–40,9 o 30–31,9", 1 to "38,5–38,9 o 34–35,9",
                0 to "36–38,4", 2 to "32–33,9")),
            ch("map", "Presión arterial media (mmHg)", listOf(
                4 to "≥ 160 o ≤ 49", 3 to "130–159", 2 to "110–129 o 50–69", 0 to "70–109")),
            ch("fc", "Frecuencia cardíaca (lpm)", listOf(
                4 to "≥ 180 o ≤ 39", 3 to "140–179 o 40–54", 2 to "110–139 o 55–69", 0 to "70–109")),
            ch("fr", "Frecuencia respiratoria (rpm)", listOf(
                4 to "≥ 50 o ≤ 5", 3 to "35–49", 2 to "25–34 o 6–9", 0 to "12–24", 1 to "10–11")),
            ch("paLow", "PaO₂ con FiO₂ < 0,5 (puntos)", listOf(
                0 to "> 70 mmHg (0 puntos)", 1 to "61–70 mmHg (1 punto)", 3 to "55–60 mmHg (3 puntos)", 4 to "< 55 mmHg (4 puntos)")),
            ch("aa", "Gradiente A-aDO₂ con FiO₂ ≥ 0,5 (puntos)", listOf(
                0 to "< 200 mmHg (0 puntos)", 2 to "200–349 (2 puntos)", 3 to "350–499 (3 puntos)", 4 to "≥ 500 (4 puntos)")),
            ch("ph", "pH arterial", listOf(
                4 to "≥ 7,7 o < 7,15", 3 to "7,6–7,69 o 7,15–7,24", 1 to "7,5–7,59", 0 to "7,33–7,49", 2 to "7,25–7,32")),
            ch("na", "Sodio sérico (mEq/l)", listOf(
                4 to "≥ 180 o ≤ 110", 3 to "160–179 o 111–119", 2 to "155–159 o 120–129", 1 to "150–154", 0 to "130–149")),
            ch("k", "Potasio sérico (mEq/l)", listOf(
                4 to "≥ 7 o < 2,5", 3 to "6–6,9", 1 to "5,5–5,9 o 3–3,4", 0 to "3,5–5,4", 2 to "2,5–2,9")),
            ch("cr", "Creatinina (mg/dl)", listOf(
                4 to "≥ 3,5", 3 to "2–3,4", 2 to "1,5–1,9 o < 0,6", 0 to "0,6–1,4")),
            ch("hct", "Hematocrito (%)", listOf(
                4 to "≥ 60 o < 20", 2 to "50–59,9 o 20–29,9", 1 to "46–49,9", 0 to "30–45,9")),
            ch("wbc", "Leucocitos (×10³/mm³)", listOf(
                4 to "≥ 40 o < 1", 2 to "20–39,9 o 1–2,9", 1 to "15–19,9", 0 to "3–14,9")),
            ch("gcs", "Puntuación de Glasgow (15 − GCS)", listOf(
                0 to "15 (GCS 15)", 1 to "14–13", 2 to "12–11", 3 to "10–9", 4 to "8–7", 5 to "6–5", 6 to "≤ 4")),
            ch("edad", "Edad", listOf(0 to "≤ 44 años", 2 to "45–54", 3 to "55–64", 5 to "65–74", 6 to "≥ 75")),
            ch("cronica", "Insuficiencia orgánica grave o inmunocompromiso", listOf(
                0 to "Ninguna", 2 to "Sí, postoperatoria", 5 to "Sí, no operatoria"))
        )
    ) { v ->
        val vars = listOf("temp", "map", "fc", "fr", "ph", "na", "k", "cr", "hct", "wbc", "gcs", "edad", "cronica")
        val ox1 = v["paLow"]?.toIntOrNull()
        val ox2 = v["aa"]?.toIntOrNull()
        val ox = ox1 ?: ox2 ?: return@sc incomplete("Rellene la oxigenación: PaO₂ (FiO₂ < 0,5) o gradiente A-a (FiO₂ ≥ 0,5).")
        val parcial = vars.mapNotNull { v[it]?.toIntOrNull() }
        if (parcial.size < vars.size) return@sc incomplete("Complete las 13 variables restantes (peor valor en 24 h).")
        val warnings = mutableListOf<String>()
        if (ox1 != null && ox2 != null) warnings.add("Rellenó oxigenación por ambas vías: se usa PaO₂ (FiO₂ < 0,5).")
        if ((v["cr"]?.toIntOrNull() ?: 0) >= 2) warnings.add("Si la insuficiencia renal es AGUDA, duplique los puntos de creatinina manualmente.")
        val total = parcial.sum() + ox
        val band = when (total) {
            in 0..9 -> "Riesgo bajo (APACHE II $total)"
            in 10..19 -> "Riesgo moderado (APACHE II $total)"
            in 20..29 -> "Riesgo alto (APACHE II $total)"
            else -> "Riesgo muy alto (APACHE II $total)"
        }
        ScaleResult("VALID", total, band, "Suma fisiológica + edad + enfermedad crónica = $total", warnings)
    }

    /* ---------------- NEWS2 ---------------- */

    private val news2 = sc(
        "news2", "NEWS2 · Detección precoz del deterioro agudo", "adult",
        "Estandarizar la alerta temprana en planta, urgencias y UCI con 7 parámetros fisiológicos y activar la respuesta escalonada.",
        "0 monitorización de rutina · 1–4 bajo, reevaluar al menos cada 4–6 h · 5–6 medio, valoración urgente por el equipo · ≥ 7 alto, emergencia: evaluación continua por equipo crítico.",
        "No aplicar a menores de 16 años ni embarazadas. En fallo respiratorio hipercápnico (EPOC) usar la escala NEWS2 opcional de SpO₂ (88–92 %).",
        "Royal College of Physicians, National Early Warning Score (NEWS) 2, 2017.",
        listOf(
            ch("fr", "Frecuencia respiratoria (rpm)", listOf(
                3 to "≤ 8 o ≥ 25", 1 to "9–11", 0 to "12–20", 2 to "21–24")),
            ch("spo2", "SpO₂ (%)", listOf(
                3 to "≤ 91", 2 to "92–93", 1 to "94–95", 0 to "≥ 96")),
            ch("o2sup", "Oxígeno suplementario", listOf(0 to "No (aire ambiente)", 2 to "Sí")),
            ch("pas", "TA sistólica (mmHg)", listOf(
                3 to "≥ 220 o ≤ 90", 2 to "91–100", 1 to "101–110", 0 to "111–219")),
            ch("fc", "Frecuencia cardíaca (lpm)", listOf(
                3 to "≥ 131 o ≤ 40", 2 to "111–130", 1 to "91–110 o 41–50", 0 to "51–90")),
            ch("consciencia", "Nivel de consciencia (AVPU)", listOf(
                0 to "Alerta", 3 to "Responde a voz/dolor o sin respuesta")),
            ch("temp", "Temperatura (°C)", listOf(
                3 to "≤ 35,0", 1 to "35,1–36,0 o 38,1–39,0", 0 to "36,1–38,0", 2 to "≥ 39,1"))
        )
    ) { v ->
        val total = sumChoices(v, "fr", "spo2", "o2sup", "pas", "fc", "consciencia", "temp")
            ?: return@sc incomplete("Valore los 7 parámetros.")
        val band = when {
            total == 0 -> "Riesgo mínimo (NEWS2 $total)"
            total in 1..4 -> "Riesgo bajo (NEWS2 $total)"
            total in 5..6 -> "Riesgo medio (NEWS2 $total): valoración urgente"
            else -> "Riesgo alto (NEWS2 $total): activar respuesta de emergencia"
        }
        val warn = if (total >= 5) listOf("NEWS2 ≥ 5: notificar y aumentar frecuencia de monitorización; NEWS2 ≥ 7 considera traslado a UCI.") else emptyList()
        ScaleResult("VALID", total, band, null, warn)
    }

    /* ---------------- Wells TEP ---------------- */

    private val wellsPe = sc(
        "wells_pe", "Wells · Probabilidad de tromboembolia pulmonar", "adult",
        "Estratificar la probabilidad pretest de TEP antes de decidir D-dímero o angio-TC.",
        "Escala en 3 niveles: 0–1 baja · 2–6 moderada · ≥ 7 alta. Escala en 2 niveles (modificada): ≤ 4 improbable · > 4 probable.",
        "El D-dímero solo descarta si la probabilidad pretest es baja o improbable. En embarazo, UCI y altos índices clínicos el rendimiento del D-dímero cae.",
        "Wells PS et al. Ann Intern Med 2001;135(2):98-106 (revisión de Toronto); ESC 2019 TEP guidelines.",
        listOf(
            ch("tvp", "Signos clínicos de TVP (dolor + edema unilateral)", listOf(0 to "No", 6 to "Sí (+3)")),
            ch("dx1", "La TEP es el diagnóstico más probable", listOf(0 to "No", 6 to "Sí (+3)")),
            ch("fc", "Frecuencia cardíaca > 100 lpm", listOf(0 to "No", 3 to "Sí (+1,5)")),
            ch("inmov", "Inmovilización > 3 días o cirugía < 4 semanas", listOf(0 to "No", 3 to "Sí (+1,5)")),
            ch("previo", "TVP o TEP previa documentada", listOf(0 to "No", 3 to "Sí (+1,5)")),
            ch("hemoptisis", "Hemoptisis", listOf(0 to "No", 2 to "Sí (+1)")),
            ch("cancer", "Malignidad activa (tratamiento, paliativo o diagnósticada < 6 meses)", listOf(0 to "No", 2 to "Sí (+1)"))
        )
    ) { v ->
        val total2 = sumChoices(v, "tvp", "dx1", "fc", "inmov", "previo", "hemoptisis", "cancer")
            ?: return@sc incomplete("Valore los 7 ítems.")
        val total = total2 / 2.0
        val band = when {
            total <= 1.0 -> "Probabilidad BAJA (Wells %.1f): D-dímero puede descartar".format(total)
            total <= 6.0 -> "Probabilidad MODERADA (Wells %.1f): D-dímero o imagen según protocolo".format(total)
            else -> "Probabilidad ALTA (Wells %.1f): imagen directa (angio-TC)".format(total)
        }
        val warn = if (total > 4.0) listOf("«Probable» (> 4): no demore la prueba de imagen; el D-dímero no excluye TEP en este grupo.") else emptyList()
        ScaleResult("VALID", (total * 10).toInt(), band, "Puntuación original %.1f puntos".format(total), warn)
    }

    /* ---------------- Child-Pugh ---------------- */

    private val childPugh = sc(
        "child_pugh", "Child-Pugh · Gravedad de la hepatopatía crónica", "adult",
        "Clasificar la disfunción hepática (A/B/C) para pronóstico, ajuste de fármacos y mortalidad perioperatoria.",
        "A (5–6 puntos): supervivencia 1 año ≈ 80-100 % · B (7–9): ≈ 60-80 % · C (10–15): < 45 %. Ajusta la indicación de técnicas invasivas y trasplante.",
        "No diseñado para hepatopatía aguda (uso de RIFLE/MELD según contexto). La ascitis y la encefalopatía son subjetivas: valorar tras retirada de diuréticos si es posible.",
        "Pugh RN et al. Br J Surg 1973;60(8):646-649; modificación Child-Turcotte-Pugh.",
        listOf(
            ch("bili", "Bilirrubina (mg/dl)", listOf(1 to "< 2", 2 to "2–3", 3 to "> 3")),
            ch("alb", "Albúmina (g/dl)", listOf(1 to "> 3,5", 2 to "2,8–3,5", 3 to "< 2,8")),
            ch("inr", "INR", listOf(1 to "< 1,7", 2 to "1,7–2,3", 3 to "> 2,3")),
            ch("ascitis", "Ascitis", listOf(1 to "Ausente", 2 to "Leve-moderada (responde a diuréticos)", 3 to "Refractaria o grave")),
            ch("encef", "Encefalopatía hepática", listOf(1 to "Ausente", 2 to "Grado I–II", 3 to "Grado III–IV"))
        )
    ) { v ->
        val total = sumChoices(v, "bili", "alb", "inr", "ascitis", "encef")
            ?: return@sc incomplete("Valore los 5 parámetros.")
        val band = when {
            total <= 6 -> "Child-Pugh A ($total puntos)"
            total <= 9 -> "Child-Pugh B ($total puntos)"
            else -> "Child-Pugh C ($total puntos)"
        }
        ScaleResult("VALID", total, band, "Bilirrubina + albúmina + INR + ascitis + encefalopatía = $total", emptyList())
    }

    /* ---------------- HEART ---------------- */

    private val heart = sc(
        "heart_score", "HEART · Riesgo a corto plazo en dolor torácico", "adult",
        "Estratificar el riesgo de eventos cardiacos mayores (MACE) a 6 semanas en el paciente que acude por dolor torácico sin elevación del ST.",
        "0–3 bajo (MACE ≈ 2 %): alta precoz con test provocativo ambulatorio · 4–6 moderado (≈ 12 %): observación y troponinas seriadas · ≥ 7 alto (≈ 50 %): manejo invasivo precoz.",
        "No aplicable con elevación del ST (reperfusión inmediata) ni desestabilización evidente. Combinar siempre con troponina ultrasensible de la unidad local.",
        "Six AJ et al. Am J Emerg Med 2008;26(1):1-7; Backus BE et al. J Am Coll Cardiol 2013 (HEART con troponina de 0/2 h).",
        listOf(
            ch("historia", "Historia clínica", listOf(
                0 to "Sospecha baja", 1 to "Sospecha moderada", 2 to "Sospecha alta")),
            ch("ecg", "ECG", listOf(
                0 to "Normal", 1 to "Cambios inespecíficos de repolarización", 2 to "Desviación significativa del ST")),
            ch("edad", "Edad", listOf(0 to "< 45", 1 to "45–64", 2 to "≥ 65")),
            ch("riesgo", "Factores de riesgo cardiovascular", listOf(
                0 to "0–1 factores", 1 to "2 factores", 2 to "≥ 3 factores o enfermedad ateroesclerótica conocida")),
            ch("tropo", "Troponina", listOf(
                0 to "≤ límite superior normal", 1 to "1–3 × el límite", 2 to "> 3 × el límite"))
        )
    ) { v ->
        val total = sumChoices(v, "historia", "ecg", "edad", "riesgo", "tropo")
            ?: return@sc incomplete("Valore los 5 elementos HEART.")
        val band = when {
            total <= 3 -> "Riesgo BAJO (HEART $total)"
            total <= 6 -> "Riesgo MODERADO (HEART $total)"
            else -> "Riesgo ALTO (HEART $total)"
        }
        val warn = if (total >= 4) listOf("Descartar otras causas de dolor torácico (TEP, disección) antes de atribuirlo a origen coronario.") else emptyList()
        ScaleResult("VALID", total, band, null, warn)
    }

    /* ---------------- STOP-BANG ---------------- */

    private val stopBang = sc(
        "stop_bang", "STOP-BANG · Cribado de apnea obstructiva del sueño", "adult",
        "Identificar el riesgo de AOS antes de la sedación, la intubación o la VNI (paciente difícil, manipulación de vía aérea de alto riesgo).",
        "0–2 riesgo bajo · ≥ 3 riesgo alto de AOS moderada-grave · ≥ 5 riesgo muy alto. Anticipar desaturación más rápida y mayor sensibilidad a opioides/sedantes.",
        "Cribado, no diagnóstico: la poligrafía/Polisomnografía confirma. En UCI la aplicabilidad es mayor al planificar extubación y analgesia.",
        "Chung F et al. Anesthesiology 2008;108(5):812-821; BJA 2012 (STOP-BANG).",
        listOf(
            ch("ronca", "¿Ronca fuerte (se oye cerrando la puerta)?", listOf(0 to "No", 1 to "Sí")),
            ch("cansancio", "¿Se cansa o duerme de día con frecuencia?", listOf(0 to "No", 1 to "Sí")),
            ch("apneas", "¿Alguien le ha visto dejar de respirar al dormir?", listOf(0 to "No", 1 to "Sí")),
            ch("hta", "¿Tiene presión arterial alta tratada?", listOf(0 to "No", 1 to "Sí")),
            ch("imc", "¿IMC > 35 kg/m²?", listOf(0 to "No", 1 to "Sí")),
            ch("edad", "¿Edad > 50 años?", listOf(0 to "No", 1 to "Sí")),
            ch("cuello", "¿Perímetro del cuello > 40 cm?", listOf(0 to "No", 1 to "Sí")),
            ch("sexo", "¿Sexo masculino?", listOf(0 to "No", 1 to "Sí"))
        )
    ) { v ->
        val total = sumChoices(v, "ronca", "cansancio", "apneas", "hta", "imc", "edad", "cuello", "sexo")
            ?: return@sc incomplete("Responda los 8 ítems.")
        val band = when {
            total <= 2 -> "Riesgo bajo de AOS (STOP-BANG $total)"
            total in 3..4 -> "Riesgo alto de AOS (STOP-BANG $total)"
            else -> "Riesgo muy alto de AOS (STOP-BANG $total)"
        }
        val warn = if (total >= 3) listOf("Riesgo alto: anticipar vía aérea difícil, desaturación rápida y mayor sensibilidad a sedantes/opioides.") else emptyList()
        ScaleResult("VALID", total, band, null, warn)
    }

    /* ---------------- Padua ---------------- */

    private val padua = sc(
        "padua", "Padua · Riesgo de TEV en paciente médico encamado", "adult y pediatric (adolescentes > 14 años)",
        "Decidir la tromboprofilaxis farmacológica en el paciente médico inmovilizado (incluye muchos ingresos de UCI en planta o UMI).",
        "≥ 4 puntos: riesgo alto → tromboprofilaxis farmacológica (HBPM) si no hay contraindicación hemorrágica. < 4: riesgo bajo, profilaxis mecánica/fisioterapia.",
        "Validado en pacientes médicos; en críticos con VM y multitrauma use escalas específicas o protocolo institucional. Valorar contraindicaciones antes de anticoagular.",
        "Barbar S et al. J Thromb Haemost 2010;8(11):2450-2457 (Padua Prediction Score).",
        listOf(
            ch("cancer", "Cáncer activo", listOf(0 to "No", 3 to "Sí")),
            ch("tev_previa", "TEV previa (salvo embolismo venoso superficial)", listOf(0 to "No", 3 to "Sí")),
            ch("inmovil", "Movilidad reducida esperada ≥ 3 días (encamado/repaso sanitario, salir del cuarto ≤ 1 vez/día)", listOf(0 to "No", 3 to "Sí")),
            ch("trombofilia", "Trombofilia conocida", listOf(0 to "No", 3 to "Sí")),
            ch("trauma", "Trauma o cirugía reciente ≤ 1 mes", listOf(0 to "No", 2 to "Sí")),
            ch("edad", "Edad ≥ 70 años", listOf(0 to "No", 1 to "Sí")),
            ch("fallo", "Insuficiencia cardíaca y/o respiratoria grave", listOf(0 to "No", 1 to "Sí")),
            ch("iam", "IAM agudo o ictus isquémico agudo", listOf(0 to "No", 1 to "Sí")),
            ch("infeccion", "Infección aguda y/o enfermedad reumática aguda", listOf(0 to "No", 1 to "Sí")),
            ch("obesidad", "Obesidad (IMC ≥ 30)", listOf(0 to "No", 1 to "Sí")),
            ch("hormonal", "Tratamiento hormonal en curso", listOf(0 to "No", 1 to "Sí"))
        )
    ) { v ->
        val total = sumChoices(v, "cancer", "tev_previa", "inmovil", "trombofilia", "trauma", "edad",
            "fallo", "iam", "infeccion", "obesidad", "hormonal")
            ?: return@sc incomplete("Valore los 11 ítems.")
        val band = if (total >= 4) "Riesgo ALTO de TEV (Padua $total)" else "Riesgo BAJO de TEV (Padua $total)"
        val warn = if (total >= 4) listOf("Riesgo alto: prescribir profilaxis farmacológica si no hay contraindicación; revisar recuento plaquetario y sangrado activo.") else emptyList()
        ScaleResult("VALID", total, band, null, warn)
    }

    /* ---------------- Glasgow-Blatchford ---------------- */

    private val blatchford = sc(
        "glasgow_blatchford", "Glasgow-Blatchford · Hemorragia digestiva alta", "adult",
        "Identificar a los pacientes con hemorragia digestiva alta que necesitan tratamiento y endoscopia frente a los que pueden ser estudiados de forma ambulatoria.",
        "0: se puede valorar manejo ambulatorio en pacientes seleccionados · ≥ 1: riesgo alto → admisión, endoscopia precoz (< 24 h) y manejo especializado.",
        "Precisa laboratorio (urea, Hb) y datos clínicos. No es herramienta de prognosis exclusiva del re-sangrado: combinar con Rockall clínico según protocolo.",
        "Stanley AJ et al. Lancet 2009 (simplificado); Blatchford O et al. Lancet 2000;356:1086-1090.",
        listOf(
            ch("sexo", "Sexo (para Hb)", listOf(0 to "Hombre", 1 to "Mujer")),
            nm("urea", "Urea (mmol/l)", 0.0, 60.0, unit = "mmol/l"),
            nm("hb", "Hemoglobina (g/dl)", 3.0, 25.0, unit = "g/dl"),
            nm("pas", "TA sistólica (mmHg)", 50.0, 260.0, unit = "mmHg"),
            ch("fc", "Frecuencia cardíaca ≥ 100 lpm", listOf(0 to "No", 1 to "Sí")),
            ch("melena", "Melena en la admisión", listOf(0 to "No", 1 to "Sí")),
            ch("sincope", "Síncope", listOf(0 to "No", 2 to "Sí")),
            ch("hepatica", "Enfermedad hepática crónica", listOf(0 to "No", 2 to "Sí")),
            ch("cardiaca", "Insuficiencia cardíaca", listOf(0 to "No", 2 to "Sí"))
        )
    ) { v ->
        val urea = v["urea"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la urea.")
        val hb = v["hb"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la hemoglobina.")
        val pas = v["pas"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la TA sistólica.")
        val mujer = (v["sexo"]?.toIntOrNull() ?: 0) == 1
        val pUrea = when {
            urea < 6.5 -> 0; urea < 8.0 -> 2; urea < 10.0 -> 3; urea < 25.0 -> 4; else -> 6
        }
        val pHb = if (mujer) when { hb < 10.0 -> 6; hb < 12.0 -> 3; else -> 0 }
        else when { hb < 10.0 -> 6; hb < 12.0 -> 3; hb < 13.0 -> 1; else -> 0 }
        val pPas = when { pas < 90.0 -> 3; pas < 100.0 -> 2; pas < 110.0 -> 1; else -> 0 }
        val pFc = v["fc"]?.toIntOrNull() ?: 0
        val pMelena = v["melena"]?.toIntOrNull() ?: 0
        val pSincope = v["sincope"]?.toIntOrNull() ?: 0
        val pHep = v["hepatica"]?.toIntOrNull() ?: 0
        val pCard = v["cardiaca"]?.toIntOrNull() ?: 0
        val total = pUrea + pHb + pPas + pFc + pMelena + pSincope + pHep + pCard
        val band = if (total == 0) "Riesgo MUY BAJO (GBS 0)" else "Riesgo ALTO (GBS $total)"
        val warn = if (total >= 1) listOf("GBS ≥ 1: ingreso y endoscopia precoz según protocolo; resucitación inicial simultánea.") else emptyList()
        ScaleResult("VALID", total, band,
            "Urea $pUrea + Hb $pHb + PAS $pPas + clínica/comorbilidad ${pFc + pMelena + pSincope + pHep + pCard} = $total", warn)
    }

    /* ---------------- BISAP ---------------- */

    private val bisap = sc(
        "bisap", "BISAP · Gravedad precoz de la pancreatitis aguda", "adult",
        "Identificar dentro de las 24 h la pancreatitis con mortalidad aumentada, complementando criterios de SIRS y TC según protocolo.",
        "0–2: mortalidad baja (< 2 %) · ≥ 3: mortalidad aumentada (≥ 5-10 %): ingreso en UCI, vigilancia intensiva de órganos.",
        "No sustituye a criterios como SIRS, procalcitonina o Tomografía con contraste en casos dudosos; calcular en las primeras 24 h.",
        "Wu BU et al. Gut 2008;57(12):1696-1700 (BISAP).",
        listOf(
            nm("bun", "BUN (mg/dl)", 0.0, 200.0, unit = "mg/dl"),
            ch("consciencia", "Consciencia alterada (GCS < 15)", listOf(0 to "No", 1 to "Sí")),
            ch("sirs", "≥ 2 criterios SIRS", listOf(0 to "No", 1 to "Sí")),
            ch("edad", "Edad ≥ 60 años", listOf(0 to "No", 1 to "Sí")),
            ch("derrame", "Derrame pleural en la imaginología", listOf(0 to "No", 1 to "Sí"))
        )
    ) { v ->
        val bun = v["bun"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca el BUN.")
        val pBun = if (bun > 25.0) 1 else 0
        val total = pBun + (v["consciencia"]?.toIntOrNull() ?: 0) + (v["sirs"]?.toIntOrNull() ?: 0) +
            (v["edad"]?.toIntOrNull() ?: 0) + (v["derrame"]?.toIntOrNull() ?: 0)
        val band = if (total >= 3) "Gravedad ALTA (BISAP $total)" else "Gravedad baja (BISAP $total)"
        val warn = if (total >= 3) listOf("BISAP ≥ 3: considere UCI; insuficiencia renal, reposición agresiva y control de SIRS en las primeras horas.") else emptyList()
        ScaleResult("VALID", total, band, "BUN > 25 mg/dl aporta ${pBun} punto(s)", warn)
    }

    /* ---------------- Hunt-Hess ---------------- */

    private val huntHess = sc(
        "hunt_hess", "Hunt-Hess · Gravedad clínica de la hemorragia subaracnoidea", "adult",
        "Clasificar la hemorragia subaracnoidea aneurismática para el pronóstico y el momento del tratamiento (precocidad del clip/endovascular).",
        "I–II: buen grado, tratamiento precoz con bajo riesgo · III: deterioro neurológico evidente · IV–V: grave, riesgo operatorio alto, prioridad de estabilización.",
        "La modificación de la Escala Hunt-Hess añade déficits neurológicos focales (grado 1-3 +). No refleja la extensión del sangrado en TC (usar Fisher/modified Fisher).",
        "Hunt WE, Hess RM. J Neurosurg 1968;29(1):14-23; Report of World Federation of Neurological Surgeons Committee. J Neurosurg 1988.",
        listOf(
            ch("grado", "Situación neurológica", listOf(
                1 to "I · Asintomática, cefalea leve y rigidez nucal mínima",
                2 to "II · Cefalea moderada-severa, rigidez nucal, sin déficit salvo parálisis de nervio craneal",
                3 to "III · Somnolencia o confusión, déficit neurológico leve",
                4 to "IV · Estupor, hemiparesia moderada-grave, rigidez y alteraciones vegetativas tempranas",
                5 to "V · Coma, posturas de decerebración, situación moribunda"))
        )
    ) { v ->
        val g = v["grado"]?.toIntOrNull() ?: return@sc incomplete("Seleccione el grado clínico.")
        val band = when {
            g <= 2 -> "Buen grado (Hunt-Hess $g)"
            g == 3 -> "Grado intermedio (Hunt-Hess $g)"
            else -> "Grave (Hunt-Hess $g)"
        }
        val warn = if (g >= 3) listOf("Monitorizar vasospasmo (Doppler/angio), hidroelectrolítico (SIADH) y Cardiopatía por catecolaminas.") else emptyList()
        ScaleResult("VALID", g, band, null, warn)
    }

    /* ---------------- Calculadoras ventilatorias ---------------- */

    private val rsbi = sc(
        "rsbi", "RSBI · Índice respiración rápida y superficial", "adult y pediatric",
        "Predecir el éxito del destete: relación frecuencia respiratoria / volumen corriente (FB/Vt).",
        "≤ 105 resp/min/l: prueba de ventilación espontánea positiva (Vt en litros) · > 105: destete probablemente fallido. Sensibilidad ~70 % y especificidad ~70 % en adultos.",
        "No sustituye a la prueba global de respiración espontánea ni a criterios clínicos/gasométricos; menos validado en niños pequeños (usar como apoyo).",
        "Yang KL, Tobin MJ. N Engl J Med 1991;324(21):1445-1450.",
        listOf(
            nm("fr", "Frecuencia respiratoria (rpm)", 4.0, 80.0, unit = "rpm"),
            nm("vt", "Volumen corriente (ml)", 50.0, 2000.0, unit = "ml")
        )
    ) { v ->
        val fr = v["fr"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la frecuencia respiratoria.")
        val vt = v["vt"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca el volumen corriente.")
        if (vt <= 0) return@sc ScaleResult("OUT_OF_RANGE", null, null, null, listOf("Vt debe ser > 0."))
        val rsbi = fr / (vt / 1000.0)
        val band = if (rsbi <= 105.0) "Favorable al destete (RSBI %.0f)".format(rsbi)
        else "Desfavorable (RSBI %.0f)".format(rsbi)
        val warn = if (rsbi > 105.0) listOf("Revisar causas de taquipnea (dolor, ansiedad, sobrecarga) antes de cancelar el destete.") else emptyList()
        ScaleResult("VALID", rsbi.toInt(), band, "FB %.0f / Vt %.2f l = %.0f resp/min/l".format(fr, vt / 1000.0, rsbi), warn)
    }

    private val compliancia = sc(
        "compliancia", "Compliance del sistema respiratorio", "adult y pediatric",
        "Calcular la compliance estática/dinámica del paciente ventilado y detectar reducciones que obligan a estrategia protectora.",
        "Adulto: ≥ 40 ml/cmH₂O adecuada · 30–39 disminuida · < 30 muy disminuida (SDRA, fibrosis, distensión abdominal). Pediatría: interpretar en ml/kg/cmH₂O (≈ 0,8–1,5).",
        "La compliance dinámica usa PIP (incluye resistencia); la estática requiere presión meseta y pausa espiratoria. En fuga importante el Vt espirado es más fiable.",
        "Marini JJ, Wheeler AP. Critical Care Medicine: The Essentials, 5.ª ed.; ARDS Network NEJM 2000.",
        listOf(
            nm("vt", "Volumen corriente espirado (ml)", 30.0, 1200.0, unit = "ml"),
            nm("pinsp", "Presión inspiratoria (preferir meseta)", 5.0, 70.0, unit = "cmH₂O"),
            nm("peep", "PEEP total", 0.0, 30.0, unit = "cmH₂O"),
            nm("peso", "Peso (opcional, para ml/kg/cmH₂O)", 0.0, 200.0, unit = "kg", required = false)
        )
    ) { v ->
        val vt = v["vt"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca el Vt.")
        val pinsp = v["pinsp"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la presión inspiratoria.")
        val peep = v["peep"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la PEEP.")
        val grad = pinsp - peep
        if (grad <= 0) return@sc ScaleResult("INVALID_INPUT", null, null, null,
            listOf("La presión inspiratoria debe ser mayor que la PEEP."))
        val c = vt / grad
        val peso = v["peso"]?.toDoubleOrNull()
        val band = when {
            c >= 40.0 -> "Adecuada (%.1f ml/cmH₂O)".format(c)
            c >= 30.0 -> "Disminuida (%.1f ml/cmH₂O)".format(c)
            else -> "Muy disminuida (%.1f ml/cmH₂O)".format(c)
        }
        val detalle = if (peso != null && peso > 0)
            "≈ %.2f ml/kg/cmH₂O".format(c / peso) else null
        val warn = if (c < 30.0) listOf("Revisar Vt 6 ml/kg peso ideal, meseta < 30 cmH₂O, PEEP/FiO₂, neumotórax y atelectasias.") else emptyList()
        ScaleResult("VALID", c.toInt(), band, detalle, warn)
    }

    private val oi = sc(
        "ind_oxigenacion", "Índice de oxigenación (OI) pediátrico", "pediatric",
        "Cuantificar el fallo de oxigenación del niño ventilado incorporando la presión media de la vía aérea: OI = MAP × FiO₂ × 100 / PaO₂.",
        "OI < 4 normal/leve · 4–8 moderado · 8–16 grave · > 16 muy grave. En el consenso Phoenix 2024, SDRA pediátrico grave con OI ≥ 16 (sin oxigenación membrana extracorpórea previa).",
        "Requiere gasometría arterial simultánea y MAP real (incluida PEEP). En oxigenación de alta frecuencia (HFOV) se usa el índice OI (OSI).",
        "Phoenix Consensus (Thomas NJ et al. Am J Respir Crit Care Med 2024); PALICC 2015.",
        listOf(
            nm("map", "Presión media de la vía aérea (MAP)", 3.0, 60.0, unit = "cmH₂O"),
            nm("fio2", "FiO₂", 0.21, 1.0, unit = "fracción"),
            nm("pao2", "PaO₂ arterial", 10.0, 700.0, unit = "mmHg")
        )
    ) { v ->
        val map = v["map"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la MAP.")
        val fio2 = v["fio2"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la FiO₂.")
        val pao2 = v["pao2"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la PaO₂.")
        if (pao2 <= 0) return@sc ScaleResult("OUT_OF_RANGE", null, null, null, listOf("La PaO₂ debe ser > 0."))
        val oi = map * fio2 * 100.0 / pao2
        val band = when {
            oi < 4.0 -> "Leve/normal (OI %.1f)".format(oi)
            oi < 8.0 -> "Moderado (OI %.1f)".format(oi)
            oi < 16.0 -> "Grave (OI %.1f)".format(oi)
            else -> "Muy grave (OI %.1f)".format(oi)
        }
        val warn = if (oi >= 16.0) listOf("OI ≥ 16: considere estrategias de rescate (pronación, NO inhalado, valorar ECMO) en un centro con experiencia.") else emptyList()
        ScaleResult("VALID", oi.toInt(), band, "MAP %.1f × FiO₂ %.2f × 100 / PaO₂ %.0f".format(map, fio2, pao2), warn)
    }

    private val gradienteAa = sc(
        "gradiente_aa", "Gradiente alvéolo-arterial de O₂ (A-a)", "adult y pediatric",
        "Distinguir la hipoxemia por hipoventilación/altitud (gradiente normal) de la causada por cortocircuito o alteración V/Q (gradiente aumentado).",
        "Normal ≈ edad/4 + 4 mmHg (a nivel del mar). Mayor de lo esperado para la edad: alteración V/Q, cortocircuito o difusión → buscar patología parenquimatosa o vascular.",
        "Fórmula simplificada a nivel del mar (Patm 760, PH₂O 47). Con FiO₂ altas pierde precisión (mejor PaO₂/FiO₂ o OI).",
        "Fisiología respiratoria estándar (West JB. Respiratory Physiology, 11.ª ed.).",
        listOf(
            nm("fio2", "FiO₂", 0.21, 1.0, unit = "fracción"),
            nm("paco2", "PaCO₂", 5.0, 120.0, unit = "mmHg"),
            nm("pao2", "PaO₂", 10.0, 700.0, unit = "mmHg"),
            nm("edad", "Edad (años)", 0.0, 110.0, unit = "años")
        )
    ) { v ->
        val fio2 = v["fio2"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la FiO₂.")
        val paco2 = v["paco2"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la PaCO₂.")
        val pao2 = v["pao2"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la PaO₂.")
        val edad = v["edad"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la edad.")
        val pao2Alv = 713.0 * fio2 - paco2 / 0.8
        val grad = pao2Alv - pao2
        val esperado = edad / 4.0 + 4.0
        val band = if (grad <= esperado) "Normal para la edad (A-a %.0f, esperado ≤ %.0f)".format(grad, esperado)
        else "Aumentado (A-a %.0f > esperado %.0f)".format(grad, esperado)
        val warn = if (grad > esperado) listOf("Gradiente aumentado: considerar TEP, SDRA, neumonía, atelectasias o cortocircuito intracardíaco.") else emptyList()
        ScaleResult("VALID", grad.toInt(), band, "PAO₂ estimada %.0f mmHg".format(pao2Alv), warn)
    }

    /* ---------------- Calculadoras generales ---------------- */

    private val imc = sc(
        "imc", "Índice de masa corporal (IMC)", "adult y pediatric",
        "Calcular el IMC como base de dosificación, cribado de obesidad y riesgo de AOS.",
        "Adulto (OMS): < 18,5 bajo peso · 18,5–24,9 normal · 25–29,9 sobrepeso · ≥ 30 obesidad. En menores de 18 años interpretar SIEMPRE por percentiles (OMS/gráficas nacionales).",
        "No refleja composición corporal; en críticos con edema o amputaciones pierde validez. Usar el peso habitual seco cuando exista.",
        "OMS 2000 (clasificación adulto); graficas OMS/CDC pediátricas.",
        listOf(
            nm("peso", "Peso (kg)", 1.0, 300.0, unit = "kg"),
            nm("altura", "Talla (cm)", 40.0, 230.0, unit = "cm")
        )
    ) { v ->
        val peso = v["peso"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca el peso.")
        val altura = v["altura"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la talla.")
        if (altura <= 0) return@sc ScaleResult("OUT_OF_RANGE", null, null, null, listOf("La talla debe ser > 0."))
        val imc = peso / Math.pow(altura / 100.0, 2.0)
        val band = when {
            imc < 18.5 -> "Bajo peso (IMC %.1f)".format(imc)
            imc < 25.0 -> "Normal (IMC %.1f)".format(imc)
            imc < 30.0 -> "Sobrepeso (IMC %.1f)".format(imc)
            else -> "Obesidad (IMC %.1f)".format(imc)
        }
        val warn = if (imc >= 30.0) listOf("Obesidad: ajustar dosis según peso ideal/ajustado, STOP-BANG de vía aérea y riesgo de TEV.") else emptyList()
        ScaleResult("VALID", imc.toInt(), band, "Peso %.0f kg, talla %.0f cm".format(peso, altura), warn)
    }

    private val scMosteller = sc(
        "sc_mosteller", "Superficie corporal (Mosteller)", "todas",
        "Calcular la superficie corporal para dosis de quimioterapia, índices cardiacos y superficies de quemado.",
        "Índice cardíaco = gasto cardíaco / SC (normal 2,5–4 l/min/m²). SC adulto típica 1,6–2 m²; neonato ≈ 0,2–0,3 m².",
        "Fórmula de Mosteller simplificada; alternativas Du Bois/Haycock difieren ligeramente. Confirme la fórmula de su protocolo institucional.",
        "Mosteller RD. N Engl J Med 1987;317(17):1098.",
        listOf(
            nm("peso", "Peso (kg)", 0.5, 300.0, unit = "kg"),
            nm("altura", "Talla (cm)", 30.0, 230.0, unit = "cm")
        )
    ) { v ->
        val peso = v["peso"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca el peso.")
        val altura = v["altura"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la talla.")
        val sc = Math.sqrt(altura * peso / 3600.0)
        ScaleResult("VALID", null, "SC ≈ %.2f m²".format(sc),
            "√(talla × peso / 3600) = √(%.0f × %.1f / 3600)".format(altura, peso),
            listOf("Para índice cardíaco: GC (l/min) ÷ SC %.2f = IC l/min/m².".format(sc)))
    }

    private val schwartz = sc(
        "schwartz", "Clearance de creatinina pediátrica (Schwartz)", "pediatric",
        "Estimar el filtrado glomerular del niño para ajustar dosis renales y definir lesión renal (KDIGO pediátrico).",
        "CrCl = k × talla (cm) / creatinina (mg/dl). < 30 ml/min/1,73 m²: ajuste mayor de dosis · KDIGO pediátrico: estadio 1 (↓ ≥ 25 %) … 3 (< 30 ml/min/1,73 m²).",
        "No usar en neonatos con función materna residual ni en pacientes con masa muscular anormal. Con creatinina enzimática se recomienda la versión simplificada (k = 0,413).",
        "Schwartz GJ et al. J Pediatr 1976;88(3):449-455; versión simplificada Schwartz GJ, Work DF. J Pediatr 2009;154(1):25-31.",
        listOf(
            ch("grupo", "Grupo de edad", listOf(
                0 to "Prematuro (< 34 semanas, k = 0,33)", 1 to "Término – 1 año (k = 0,45)",
                2 to "1–13 años o niña 13–18 (k = 0,55)", 3 to "Varón 13–18 años (k = 0,70)")),
            nm("talla", "Talla (cm)", 30.0, 210.0, unit = "cm"),
            nm("cr", "Creatinina sérica (mg/dl)", 0.1, 15.0, unit = "mg/dl")
        )
    ) { v ->
        val k = when (v["grupo"]?.toIntOrNull()) { 0 -> 0.33; 1 -> 0.45; 3 -> 0.70; else -> 0.55 }
        val talla = v["talla"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la talla.")
        val cr = v["cr"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la creatinina.")
        if (cr <= 0) return@sc ScaleResult("OUT_OF_RANGE", null, null, null, listOf("La creatinina debe ser > 0."))
        val crcl = k * talla / cr
        val band = when {
            crcl >= 90.0 -> "Normal/elevada (≈ %.0f ml/min)".format(crcl)
            crcl >= 60.0 -> "Reducción leve (≈ %.0f ml/min)".format(crcl)
            crcl >= 30.0 -> "Reducción moderada (≈ %.0f ml/min)".format(crcl)
            else -> "Reducción grave (≈ %.0f ml/min)".format(crcl)
        }
        val warn = if (crcl < 60.0) listOf("Revisar dosis renales (aminoglucósidos, vancamicina, analgésicos) y nefrotóxicos del catálogo del paciente.") else emptyList()
        ScaleResult("VALID", crcl.toInt(), band, "k = %.2f × talla %.0f / Cr %.2f".format(k, talla, cr), warn)
    }

    private val diuresis = sc(
        "diuresis", "Diuresis horaria (ml/kg/h)", "todas",
        "Cuantificar la diuresis relativa al peso como indicador de perfusión renal y criterio de oliguria.",
        "Adulto: < 0,5 ml/kg/h = oliguria · Pediatría: < 1 ml/kg/h = oliguria · Neonato: < 1 ml/kg/h. > 4-5 ml/kg/h sugiere poliuria (diuresis osmótica, sobrecarga de fluidos).",
        "La diuresis depende de la carga de fluidos y de los diuréticos: interpretar junto con creatinina, FC y perfusión periférica.",
        "KDIGO AKI 2012; definiciones de oliguria pediátrica estándar.",
        listOf(
            nm("volumen", "Volumen total recolectado (ml)", 0.0, 10000.0, unit = "ml"),
            nm("peso", "Peso (kg)", 0.5, 200.0, unit = "kg"),
            nm("horas", "Período de recolección (h)", 0.5, 24.0, unit = "h")
        )
    ) { v ->
        val vol = v["volumen"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca el volumen.")
        val peso = v["peso"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca el peso.")
        val horas = v["horas"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca las horas.")
        if (horas <= 0 || peso <= 0) return@sc ScaleResult("OUT_OF_RANGE", null, null, null, listOf("Peso y horas deben ser > 0."))
        val d = vol / (peso * horas)
        val band = when {
            d < 0.5 -> "Oliguria GRAVE (%.1f ml/kg/h)".format(d)
            d < 1.0 -> "Oliguria (%.1f ml/kg/h)".format(d)
            d <= 4.0 -> "Adecuada (%.1f ml/kg/h)".format(d)
            else -> "Poliuria (%.1f ml/kg/h)".format(d)
        }
        val warn = if (d < 1.0) listOf("En shock: la diuresis baja con FC alta y relleno capilar prolongado sugiere hipoperfusión renal: revise volumen y perfusión antes de diuréticos.") else emptyList()
        ScaleResult("VALID", (d * 10).toInt(), band, "%.0f ml / (%.0f kg × %.1f h)".format(vol, peso, horas), warn)
    }

    private val deficitSodio = sc(
        "deficit_sodio", "Déficit de sodio y corrección segura (hiponatremia)", "todas",
        "Estimar el déficit de sodio corporal y limitar la velocidad de corrección para prevenir el síndrome de desmielinización osmótica (SDO).",
        "Déficit (mEq) = (Na objetivo − Na actual) × 0,6 × peso. NO corregir más de 8–10 mEq/l en 24 h (norma 4–6 en alto riesgo de SDO: alcoholismo, malnutrición, hipoxemia, mujer premenopáusica).",
        "Fórmula de Watson simplificada con 0,6 (0,5 en mujeres/niños pequeños según protocolo). En hiponatremia sintomática (convulsión, coma) el bolo de salino hipertónico 3 % 3-5 ml/kg eleva Na 4-6 mEq/l con vigilancia estricta.",
        "Adrogué HJ, Madias NE. NEJM 2000;342(21):1581-1589; Sterns RH. J Clin Invest 2022 (safe sodium).",
        listOf(
            nm("na_actual", "Na actual (mEq/l)", 90.0, 145.0, unit = "mEq/l"),
            nm("na_objetivo", "Na objetivo (mEq/l)", 120.0, 145.0, unit = "mEq/l"),
            nm("peso", "Peso (kg)", 1.0, 200.0, unit = "kg")
        )
    ) { v ->
        val naAct = v["na_actual"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca el Na actual.")
        val naObj = v["na_objetivo"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca el Na objetivo.")
        val peso = v["peso"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca el peso.")
        if (naObj <= naAct) return@sc ScaleResult("INVALID_INPUT", null, null, null,
            listOf("El Na objetivo debe ser mayor que el actual (corrección de hiponatremia)."))
        val deficit = (naObj - naAct) * 0.6 * peso
        val max24 = (naObj - naAct).let { if (it > 10) naAct + 10.0 else naObj }
        val deficit24 = (max24 - naAct) * 0.6 * peso
        ScaleResult("VALID", deficit.toInt(),
            "Déficit ≈ %.0f mEq (para llegar a %.0f mEq/l)".format(deficit, naObj),
            "Para el límite de 24 h (máx +10 mEq/l): ≈ %.0f mEq de Na".format(deficit24),
            listOf("Corrección máxima 8–10 mEq/l/24 h; en riesgo de SDO 4–6 mEq/l/24 h.",
                "Si la hiponatremia es crónica (> 48 h) o desconocida, corregir con especial precaución y Na sérico cada 4-6 h."))
    }

    private val balanceHidrico = sc(
        "balance_hidrico", "Balance hídrico 24 h", "todas",
        "Sintetizar ingresos y egresos de las últimas 24 h para detectar sobrecarga o déficit de volumen y ajustar la estrategia de fluidos.",
        "Positivo mantenido > 10 % del peso (y/o > 2-3 l en adulto) se asocia a peores resultados en SDRA y fallo renal (fluid overload). Negativo progresivo útil en la fase de desescalada de fluidos.",
        "Registrar TODAS las fuentes (nutrición parenteral, transfusiones, fármacos diluidos, perspiración insensible ≈ 10 ml/kg/día en niño). La balanza es orientativa: el peso diario diario la confirma.",
        "Malbrain MLNG et al. Ann Intensive Care 2018 (POCUS fluid overload); fluid stewardship ICU (Sepsis SSC 2020).",
        listOf(
            nm("ingresos", "Ingresos 24 h (ml)", 0.0, 30000.0, unit = "ml"),
            nm("egresos", "Egresos 24 h (ml)", 0.0, 30000.0, unit = "ml"),
            nm("peso", "Peso (opcional)", 0.0, 200.0, unit = "kg", required = false)
        )
    ) { v ->
        val ing = v["ingresos"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca los ingresos.")
        val egr = v["egresos"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca los egresos.")
        val peso = v["peso"]?.toDoubleOrNull()
        val bal = ing - egr
        val texto = if (bal >= 0) "POSITIVO (+%.0f ml)".format(bal) else "NEGATIVO (%.0f ml)".format(bal)
        val detalle = if (peso != null && peso > 0)
            "≈ %.1f ml/kg/día (%.1f %% del peso corporal)".format(bal / peso, bal * 100.0 / peso) else null
        val warn = if (peso != null && bal > peso * 0.10 * 1000)
            listOf("Balance positivo > 10 % del peso: revise política de fluidos (4D: rescate, optimización, estabilización, desescalada).") else emptyList()
        ScaleResult("VALID", bal.toInt(), texto, detalle, warn)
    }

    /* ==================== Calculadoras ampliadas v1.3.0 ==================== */

    // 1) Calculadora de dosis mg/kg → ml
    private val dosisMgKg = sc(
        "dosis_mg_kg", "Calculadora de dosis (mg/kg → mg y ml)", "todas",
        "Convertir una dosis prescrita en mg/kg en mg totales y en volumen (ml) según la concentración del preparado.",
        "Volumen (ml) = dosis (mg/kg) × peso (kg) ÷ concentración (mg/ml). Verifique siempre mg frente a mcg y la vía (IV directa, perfusión, oral) antes de administrar.",
        "No sustituye la doble comprobación del preparado real. Fármacos con concentraciones distintas por presentación (oral vs IV) exigen cálculo aparte. Dosis máximas por fármaco no incluidas: consultar protocolo.",
        "Práctica clínica estándar de administración de fármacos pediátricos (doble comprobación ISMP).",
        listOf(
            nm("dosis", "Dosis prescrita (mg/kg)", 0.001, 100.0, unit = "mg/kg"),
            nm("peso", "Peso (kg)", 0.5, 200.0, unit = "kg"),
            nm("conc", "Concentración del preparado", 0.01, 100.0, unit = "mg/ml"),
            nm("veces", "Administraciones al día (opcional)", 1.0, 6.0, unit = "veces", required = false)
        )
    ) { v ->
        val dosis = v["dosis"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la dosis en mg/kg.")
        val peso = v["peso"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca el peso.")
        val conc = v["conc"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la concentración (mg/ml).")
        val veces = v["veces"]?.toDoubleOrNull()
        val mg = dosis * peso
        val ml = mg / conc
        val detalle = "Dosis: %.2f mg (%.1f mg/kg × %.1f kg) → %.2f ml (%.2f mg/ml)".format(mg, dosis, peso, ml, conc)
        val banda = "Administrar %.2f ml".format(ml)
        val warn = mutableListOf<String>()
        if (mg < 0.1) warn.add("Volumen/dosis muy pequeños: revise si la dosis debe ser en mcg/kg (factores de 1000 son el error clásico).")
        veces?.let { warn.add("Total diario: %.2f mg/día (%.2f ml × %.0f administraciones).".format(mg * it, ml, it)) }
        ScaleResult("VALID", (ml * 100).toInt(), banda, detalle, warn)
    }

    // 2) QT corregido (Bazett y Fridericia)
    private val qtc = sc(
        "qtc_bazett", "QT corregido (Bazett / Fridericia)", "todas",
        "Calcular el QTc para cribado de arritmogenicidad (torsión de puntas) en pacientes con fármacos QT-prolongadores o electrolitos alterados.",
        "Normal < 460 ms · 460–500 prolongado (revisar fármacos y electrolitos) · > 500 alto riesgo de torsión de puntas: retirar QT-prolongadores, corregir K > 4,0 y Mg, vigilancia con telemetría.",
        "Bazett sobreestima en taquicardia y subestima en bradicardia; Fridericia es preferible con FC extrema. La decisión clínica combina ECG, fármacos, electrolitos e historia de síncopes.",
        "Bazett HC. Heart 1920; Fridericia LS. Acta Med Scand 1920; AHA/ACCF/HRS recommendations, Circulation 2009.",
        listOf(
            nm("qt", "QT medido (ms)", 200.0, 700.0, unit = "ms"),
            nm("fc", "Frecuencia cardíaca (lpm)", 40.0, 250.0, unit = "lpm")
        )
    ) { v ->
        val qt = v["qt"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca el QT medido en ms.")
        val fc = v["fc"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la frecuencia cardíaca.")
        val rr = 60.0 / fc
        val bazett = qt / Math.sqrt(rr)
        val frid = qt / Math.pow(rr, 1.0 / 3.0)
        val band = when {
            bazett < 460 -> "Normal (QTc %.0f ms)".format(bazett)
            bazett <= 500 -> "PROLONGADO (QTc %.0f ms): revisar fármacos y electrolitos".format(bazett)
            else -> "ALTO RIESGO de torsión de puntas (QTc %.0f ms)".format(bazett)
        }
        val warn = mutableListOf(
            "Fridericia: %.0f ms (preferible con FC extrema).".format(frid)
        )
        if (bazett > 500) {
            warn.add("QTc > 500: retirar fármacos QT-prolongadores (macrólidos, ondansetrón, antipsicóticos), corregir K > 4,0-4,5 y Mg, monitorización continua.")
        }
        ScaleResult("VALID", bazett.toInt(), band, "QT %.0f ms · FC %.0f · RR %.2f s".format(qt, fc, rr), warn)
    }

    // 3) Fórmula de Winter (compensación respiratoria de la acidosis metabólica)
    private val winter = sc(
        "winter", "Fórmula de Winter (compensación en acidosis metabólica)", "todas",
        "Comprobar si la respuesta ventilatoria compensa adecuadamente una acidosis metabólica (pCO2 esperada).",
        "pCO2 esperada = 1,5 × HCO3 + 8 (± 2 mmHg). Si la pCO2 medida es mayor: acidosis respiratoria añadida (doble trastorno). Si es menor: alcalosis respiratoria añadida.",
        "Solo aplicable a acidosis metabólica SIN efecto tóxico directo sobre el centro respiratorio (salicilatos cursan con alcalosis respiratoria: no usar aquí).",
        "Albert MS, Dell RB, Winters RW. Ann Intern Med 1967; Winter RW. Acid-base physiology 1973.",
        listOf(
            nm("hco3", "Bicarbonato actual (HCO₃⁻)", 5.0, 45.0, unit = "mmol/l"),
            nm("pco2", "pCO₂ medida (gasometría)", 10.0, 100.0, unit = "mmHg")
        )
    ) { v ->
        val hco3 = v["hco3"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca el HCO₃⁻.")
        val pco2 = v["pco2"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la pCO₂.")
        val esperada = 1.5 * hco3 + 8.0
        val band = when {
            pco2 > esperada + 2 -> "Compensación INSUFICIENTE: acidosis respiratoria añadida (pCO₂ %.0f > esperada %.0f ± 2)".format(pco2, esperada)
            pco2 < esperada - 2 -> "Compensación EXCESIVA: alcalosis respiratoria añadida (pCO₂ %.0f < esperada %.0f ± 2)".format(pco2, esperada)
            else -> "Compensación respiratoria ADECUADA (pCO₂ %.0f dentro de %.0f ± 2)".format(pco2, esperada)
        }
        val warn = mutableListOf("Rango esperado: %.0f–%.0f mmHg.".format(esperada - 2, esperada + 2))
        if (hco3 < 12) warn.add("HCO₃ < 12: acidosis metabólica grave — busque la causa (cetoacidosis, lactato, toxinas con anión gap).")
        ScaleResult("VALID", esperada.toInt(), band, "1,5 × %.1f + 8 = %.0f mmHg".format(hco3, esperada), warn)
    }

    // 4) Brecha osmolar
    private val gapOsmolar = sc(
        "gap_osmolar", "Brecha osmolar (gap osmolar)", "todas",
        "Detectar osmolitos no habituales (alcoholes tóxicos, manitol, etanol) comparando la osmolaridad medida con la calculada.",
        "Gap < 10 normal · 10–20 posible tóxico inicial · > 20 muy sugestivo de intoxicación (metanol, etilenglicol, etanol) o acumulación de manitol/soluciones.",
        "Requiere osmolaridad MEDIDA (crioscopía) para calcular la brecha: sin ella solo se reporta la osmolaridad calculada. Correlacionar con anión gap y clínica.",
        "Hoffman RS et al. Crit Care Med 1993; EXTRIP recommendations Kidney Int 2015.",
        listOf(
            nm("na", "Sodio sérico", 100.0, 170.0, unit = "mEq/l"),
            nm("glu", "Glucosa", 20.0, 1500.0, unit = "mg/dl"),
            nm("urea", "Urea", 5.0, 300.0, unit = "mg/dl"),
            nm("osm", "Osmolaridad medida (opcional)", 200.0, 450.0, unit = "mOsm/kg", required = false)
        )
    ) { v ->
        val na = v["na"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca el sodio.")
        val glu = v["glu"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la glucosa.")
        val urea = v["urea"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la urea.")
        val osmCalc = 2 * na + glu / 18.0 + urea / 6.0
        val osmMed = v["osm"]?.toDoubleOrNull()
        if (osmMed == null) {
            return@sc ScaleResult("VALID", osmCalc.toInt(),
                "Osmolaridad calculada: %.0f mOsm/kg (sin brecha: falta osmolaridad medida)".format(osmCalc),
                "2 × Na + Glu/18 + Urea/6 = %.0f".format(osmCalc),
                listOf("Para calcular la brecha, solicite osmolaridad medida en el laboratorio."))
        }
        val gap = osmMed - osmCalc
        val band = when {
            gap < 10 -> "Brecha normal (%.0f): no sugiere tóxicos osmóticos".format(gap)
            gap < 20 -> "Brecha POSIBLEMENTE elevada (%.0f): sospechar tóxicos en fase inicial".format(gap)
            else -> "Brecha ELEVADA (%.0f): muy sugestivo de alcoholes tóxicos o manitol".format(gap)
        }
        val warn = if (gap >= 10)
            listOf("Con brecha elevada: fomepizol + consulta toxicológica si hay acidosis o sospecha de ingesta; la diálisis se decide según EXTRIP.") else emptyList()
        ScaleResult("VALID", gap.toInt(), band,
            "Medida %.0f − calculada %.0f = %.0f".format(osmMed, osmCalc, gap), warn)
    }

    // 5) Calcio corregido por albúmina
    private val caCorregido = sc(
        "ca_corregido", "Calcio total corregido por albúmina", "todas",
        "Ajustar el calcio total sérico cuando la albúmina está baja (frecuente en el paciente crítico) para estimar el calcio activo.",
        "Ca corregido = Ca medido + 0,8 × (4 − albúmina). < 8 mg/dl hipocalcemia · 8–10,5 normal · > 10,5 hipercalcemia.",
        "El calcio ionizado es el estándar en UCI: si está disponible, úselo directamente. No aplicar la corrección en insuficiencia renal grave o alteraciones del pH marcadas.",
        "Payne RB et al. BMJ 1973; práctica estándar de laboratorio clínico.",
        listOf(
            nm("ca", "Calcio total medido", 4.0, 20.0, unit = "mg/dl"),
            nm("alb", "Albúmina", 0.5, 6.0, unit = "g/dl")
        )
    ) { v ->
        val ca = v["ca"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca el calcio total.")
        val alb = v["alb"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la albúmina.")
        val corr = ca + 0.8 * (4.0 - alb)
        val band = when {
            corr < 8.0 -> "HIPOCALCEMIA corregida (%.2f mg/dl)".format(corr)
            corr <= 10.5 -> "Normal (calcio corregido %.2f mg/dl)".format(corr)
            else -> "HIPERCALCEMIA corregida (%.2f mg/dl)".format(corr)
        }
        val warn = mutableListOf("Ca corregido = %.2f + 0,8 × (4 − %.1f)".format(ca, alb))
        if (corr < 8.0) warn.add("Hipocalcemia: valore calcio ionizado, Mg y síntomas (tetania, QTc largo, hipotensión) antes de reponer.")
        ScaleResult("VALID", (corr * 100).toInt(), band, null, warn)
    }

    // 6) Presión de driving (ARDS)
    private val drivingPressure = sc(
        "driving_pressure", "Presión de driving (Pplato − PEEP)", "todas",
        "Evaluar el estiramiento cíclico pulmonar en ventilación mecánica protectora (umbral clásico ≤ 14-15 cmH₂O en SDRA).",
        "≤ 14 cmH₂O: objetivo aceptable · 15–20: elevado, revisar volumen y compliance · > 20: alto riesgo de volutrauma y mortalidad en SDRA.",
        "Requiere presión de plató medida (pausa inspiratoria). No interpretable con esfuerzo del paciente activo o asincronía sin bloqueo.",
        "Amato MBP et al. NEJM 2015; ARDS Network NEJM 2000.",
        listOf(
            nm("pplat", "Presión de plató", 5.0, 60.0, unit = "cmH₂O"),
            nm("peep", "PEEP total", 0.0, 25.0, unit = "cmH₂O")
        )
    ) { v ->
        val pplat = v["pplat"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la presión de plató.")
        val peep = v["peep"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la PEEP.")
        if (peep >= pplat) return@sc ScaleResult("INVALID_INPUT", null, null, null,
            listOf("La PEEP debe ser menor que la presión de plató."))
        val dp = pplat - peep
        val band = when {
            dp <= 14 -> "Aceptable (ΔP %.0f cmH₂O)".format(dp)
            dp <= 20 -> "ELEVADA (ΔP %.0f cmH₂O): revise volumen tidal y compliance".format(dp)
            else -> "ALTO RIESGO (ΔP %.0f cmH₂O): reduzca volumen tidal o reclute".format(dp)
        }
        val warn = if (dp > 15)
            listOf("ΔP > 15 se asocia a mayor mortalidad en SDRA: reduzca el volumen tidal hasta Pplato ≤ 30 con ΔP ≤ 14-15.") else emptyList()
        ScaleResult("VALID", dp.toInt(), band, "Pplato %.0f − PEEP %.0f = %.0f cmH₂O".format(pplat, peep, dp), warn)
    }

    // 7) Conversión de glucosa mg/dL ↔ mmol/L
    private val glucosaUnidades = sc(
        "glucosa_unidades", "Conversión de glucosa (mg/dL ↔ mmol/L)", "todas",
        "Convertir la glucemia entre mg/dl y mmol/l para protocolos internacionales o bombas de insulina configuradas en otro sistema.",
        "mmol/l = mg/dl ÷ 18 · mg/dl = mmol/l × 18. Objetivos habituales en UCI: 140–180 mg/dl (7,8–10 mmol/l) según protocolos de insulina.",
        "Conversión pura: no sustituye el control glucémico ni los umbrales de tratamiento del protocolo institucional.",
        "Convención internacional SI; NICE-SUGAR, NEJM 2009 (objetivo glucémico en UCI).",
        listOf(
            nm("valor", "Valor de glucosa", 1.0, 2000.0, unit = "mg/dl o mmol/l"),
            ch("unidad", "Unidad introducida", listOf(0 to "mg/dl → convertir a mmol/l", 1 to "mmol/l → convertir a mg/dl"))
        )
    ) { v ->
        val valor = v["valor"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca el valor de glucosa.")
        val unidad = v["unidad"]?.toIntOrNull() ?: return@sc incomplete("Seleccione la unidad de origen.")
        val (mgdl, mmol, origen) = if (unidad == 0) Triple(valor, valor / 18.0, "mg/dl") else Triple(valor * 18.0, valor, "mmol/l")
        val band = when {
            mgdl < 70 -> "HIPOGLUCEMIA (%.0f mg/dl / %.1f mmol/l)".format(mgdl, mmol)
            mgdl <= 180 -> "Objetivo habitual en UCI (%.0f mg/dl / %.1f mmol/l)".format(mgdl, mmol)
            mgdl <= 250 -> "Hiperglucemia leve-moderada (%.0f mg/dl / %.1f mmol/l)".format(mgdl, mmol)
            else -> "HIPERGLUCEMIA (%.0f mg/dl / %.1f mmol/l): revise protocolo de insulina".format(mgdl, mmol)
        }
        ScaleResult("VALID", mgdl.toInt(), band, "%.1f %s = %.0f mg/dl = %.1f mmol/l".format(valor, origen, mgdl, mmol),
            if (mgdl < 70) listOf("Hipoglucemia: glucosa IV u oral según accesos; revaluar en 15 min.") else emptyList())
    }

    // 8) Gasto energético basal (Schofield) con factor de estrés
    private val energiaSchofield = sc(
        "energia_schofield", "Gasto energético basal (Schofield) con factor de estrés", "todas",
        "Estimar las calorías por día del paciente pediátrico para planificar nutrición enteral o parenteral en UCI.",
        "Factor de estrés recomendado en UCI: 1,0 (fase aguda: no sobrealimentar) → 1,2-1,3 según actividad/fase de recuperación. La calorimetría indirecta mide mejor que cualquier fórmula.",
        "Schofield estima el metabolismo basal, no el gasto real. En obesidad usar peso habitual/ideal según protocolo. La fase aguda de UCI no exige cubrir el 100 % el primer día (hiperalimentación nociva).",
        "Schofield WN. Hum Nutr Clin Nutr 1985; Mehta NM et al. Pediatric critical care nutrition guidelines, JPEN 2017.",
        listOf(
            ch("sexo", "Sexo", listOf(0 to "Niña", 1 to "Niño")),
            nm("edad", "Edad (años)", 0.0, 18.0, unit = "años"),
            nm("peso", "Peso (kg)", 1.0, 200.0, unit = "kg"),
            ch("factor", "Factor de estrés/actividad", listOf(
                0 to "× 1,0 · reposo (fase aguda de UCI)",
                1 to "× 1,2 · leve",
                2 to "× 1,3 · moderado",
                3 to "× 1,5 · grave"))
        )
    ) { v ->
        val sexo = v["sexo"]?.toIntOrNull() ?: return@sc incomplete("Seleccione el sexo.")
        val edad = v["edad"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca la edad.")
        val peso = v["peso"]?.toDoubleOrNull() ?: return@sc incomplete("Introduzca el peso.")
        val factor = when (v["factor"]?.toIntOrNull() ?: return@sc incomplete("Seleccione el factor.")) {
            0 -> 1.0; 1 -> 1.2; 2 -> 1.3; 3 -> 1.5; else -> 1.0
        }
        val bmr = when {
            sexo == 1 && edad < 3 -> 59.512 * peso - 30.4
            sexo == 0 && edad < 3 -> 58.317 * peso - 31.1
            sexo == 1 && edad < 10 -> 22.7 * peso + 495.0
            sexo == 0 && edad < 10 -> 22.5 * peso + 499.0
            sexo == 1 -> 17.5 * peso + 651.0
            else -> 12.2 * peso + 746.0
        }.coerceAtLeast(30.0)
        val tde = bmr * factor
        ScaleResult("VALID", tde.toInt(),
            "Objetivo energético ≈ %.0f kcal/día (basal %.0f × %.1f)".format(tde, bmr, factor),
            "Schofield %s %.0f-%.0f años, %.1f kg → BMR %.0f kcal/día".format(if (sexo == 1) "niño" else "niña", if (edad < 3) 0.0 else if (edad < 10) 3.0 else 10.0, if (edad < 3) 3.0 else if (edad < 10) 10.0 else 18.0, peso),
            listOf("En la fase aguda de UCI, inicie con factor 1,0 (bajo riesgo de sobrealimentación) y avance según tolerancia.",
                "Proteínas pediátricas: 1,5-2,5 g/kg/día según edad y estado; verificar con el equipo de nutrición."))
    }

    // 9) Score vasoactivo-inotrópico (VIS)
    private val vis = sc(
        "vis", "VIS · Score vasoactivo-inotrópico", "todas",
        "Cuantificar la intensidad del soporte cardiovascular combinando las dosis de vasoactivos; útil para seguir la evolución y como criterio de escalada (ECMO).",
        "VIS = dopamina + dobutamina + 10 × milrinona + 100 × (adrenalina + noradrenalina) + 10 000 × vasopresina (dosis en mcg/kg/min; vasopresina en U/kg/min). 0 sin soporte · 1–10 bajo · 11–20 moderado · > 20-30 alto soporte, peor pronóstico y candidato a considerar ECMO si es cardiogénico refractario.",
        "Es un índice de carga terapéutica, no un marcador de fallo per se: se interpreta con lactato, ScvO₂ y perfusión. Fórmula clásica en unidades de cirugía cardíaca pediátrica.",
        "Gaies MG et al. Pediatr Crit Care Med 2010 (VIS); Davidson J et al. Pediatr Crit Care Med 2011.",
        listOf(
            nm("dopamina", "Dopamina (mcg/kg/min)", 0.0, 30.0, unit = "mcg/kg/min", required = false),
            nm("dobutamina", "Dobutamina (mcg/kg/min)", 0.0, 30.0, unit = "mcg/kg/min", required = false),
            nm("milrinona", "Milrinona (mcg/kg/min)", 0.0, 1.0, unit = "mcg/kg/min", required = false),
            nm("adrenalina", "Adrenalina (mcg/kg/min)", 0.0, 2.0, unit = "mcg/kg/min", required = false),
            nm("noradrenalina", "Noradrenalina (mcg/kg/min)", 0.0, 2.0, unit = "mcg/kg/min", required = false),
            nm("vasopresina", "Vasopresina (U/kg/min)", 0.0, 0.1, unit = "U/kg/min", required = false)
        )
    ) { v ->
        fun d(id: String) = v[id]?.toDoubleOrNull() ?: 0.0
        val dop = d("dopamina"); val dob = d("dobutamina"); val mil = d("milrinona")
        val adr = d("adrenalina"); val nor = d("noradrenalina"); val vaso = d("vasopresina")
        if (dop + dob + mil + adr + nor + vaso == 0.0)
            return@sc ScaleResult("VALID", 0, "Sin soporte vasoactivo (VIS 0)", null, emptyList())
        val total = dop + dob + 10 * mil + 100 * (adr + nor) + 10000 * vaso
        val band = when {
            total <= 10 -> "Soporte BAJO (VIS %.0f)".format(total)
            total <= 20 -> "Soporte MODERADO (VIS %.0f)".format(total)
            total <= 30 -> "Soporte ALTO (VIS %.0f)".format(total)
            else -> "SOPORTE MUY ALTO (VIS %.0f): evaluar escalada".format(total)
        }
        val warn = mutableListOf<String>()
        if (adr + nor >= 0.3) warn.add("Adrenalina/noradrenalina ≥ 0,3 mcg/kg/min: VIS dominado por catecolaminas — revise perfusión, lactato y efecto hemodinámico real.")
        if (total > 20) warn.add("VIS > 20 se asocia a peor pronóstico: en shock cardiogénico refractario, considerar ECMO temprano con el equipo.")
        val detalle = listOfNotNull(
            if (dop > 0) "dop %.2f".format(dop) else null, if (dob > 0) "dobu %.2f".format(dob) else null,
            if (mil > 0) "milr %.2f".format(mil) else null, if (adr > 0) "adr %.2f".format(adr) else null,
            if (nor > 0) "nor %.2f".format(nor) else null, if (vaso > 0) "vaso %.3f".format(vaso) else null
        ).joinToString(" · ")
        ScaleResult("VALID", total.toInt(), band, detalle.ifBlank { null }, warn)
    }

    /* ---------------- PELOD-2 (v1.4.0) ---------------- */

    private val pelod2 = Scale(
        id = "pelod2",
        name = "PELOD-2 · Disfunción orgánica pediátrica",
        population = "pediatric",
        purpose = "Describir la carga de disfunción orgánica del niño crítico (día 1 y diario). Puntuación descriptiva de 10 variables binarias.",
        version = "1.4.0",
        effectiveDate = "2026-11-05",
        reviewer = "Pendiente de validación por especialista pediátrico",
        validationStatus = "VALIDATION_REQUIRED",
        interpretation = "0–4: disfunción leve (mortalidad observada en cohortes de validación < 2 %) · 5–9: moderada (~15 %) · ≥ 10: grave (≥ 50 %).",
        limitations = "Puntuación descriptiva 0–10 con variables binarias (usar el peor valor de las primeras 24 h). El riesgo de mortalidad exacto y el cálculo oficial se obtienen en la calculadora ESPNIC. Sedación y parálisis invalidan la componente neurológica.",
        references = "Leteurtre S, et al. PELOD-2: an update of the PEdiatric logistic organ dysfunction score. Intensive Care Med. 2013;39:431-43. Calculadora oficial: ESPNIC/PICURe.",
        inputs = listOf(
            ScaleInput("edad", "Banda de edad", "choice", listOf(
                0 to "< 1 mes", 1 to "1–11 meses", 2 to "12–23 meses", 3 to "2–4 años", 4 to "5–11 años", 5 to "≥ 12 años")),
            ScaleInput("leucos", "Leucocitos (×10³/µL)", "number", min = 0.0, max = 200.0),
            ScaleInput("plaq", "Plaquetas (×10³/µL)", "number", min = 1.0, max = 1000.0),
            ScaleInput("gcs", "Glasgow (peor valor 24 h)", "number", min = 3.0, max = 15.0),
            ScaleInput("pupilas", "Reflejo pupilar", "choice", listOf(0 to "Ambos reactivos", 1 to "Una o ambas fijas")),
            ScaleInput("lactato", "Lactato (mmol/L)", "number", min = 0.0, max = 30.0),
            ScaleInput("map", "PAM (mmHg)", "number", min = 10.0, max = 200.0),
            ScaleInput("creat", "Creatinina (µmol/L)", "number", min = 0.0, max = 2000.0),
            ScaleInput("pf", "PaO2/FiO2", "number", min = 20.0, max = 600.0),
            ScaleInput("paco2", "PaCO2 (mmHg)", "number", min = 10.0, max = 150.0),
            ScaleInput("vm", "Ventilación mecánica invasiva (24 h)", "choice", listOf(0 to "No", 1 to "Sí"))
        ),
        compute = { v ->
            val edad = v["edad"]?.toIntOrNull() ?: return@Scale incomplete("Seleccione banda de edad.")
            val leucos = v["leucos"]?.toDoubleOrNull() ?: return@Scale incomplete("Faltan leucocitos.")
            val plaq = v["plaq"]?.toDoubleOrNull() ?: return@Scale incomplete("Faltan plaquetas.")
            val gcs = v["gcs"]?.toIntOrNull() ?: return@Scale incomplete("Falta el Glasgow.")
            val pupilas = v["pupilas"]?.toIntOrNull() ?: return@Scale incomplete("Seleccione reflejo pupilar.")
            val lactato = v["lactato"]?.toDoubleOrNull() ?: return@Scale incomplete("Falta el lactato.")
            val map = v["map"]?.toDoubleOrNull() ?: return@Scale incomplete("Falta la PAM.")
            val creat = v["creat"]?.toDoubleOrNull() ?: return@Scale incomplete("Falta la creatinina.")
            val pf = v["pf"]?.toDoubleOrNull() ?: return@Scale incomplete("Falta PaO2/FiO2.")
            val paco2 = v["paco2"]?.toDoubleOrNull() ?: return@Scale incomplete("Falta la PaCO2.")
            val vm = v["vm"]?.toIntOrNull() ?: return@Scale incomplete("Indique la ventilación mecánica.")
            val mapUmbral = listOf(34.0, 38.0, 42.0, 44.0, 47.0, 52.0)[edad]
            val creatUmbral = listOf(90.0, 53.0, 40.0, 48.0, 56.0, 93.0)[edad]
            val p = mutableListOf<Pair<String, Int>>()
            p.add("leucocitos" to if (leucos < 5.0 || leucos >= 30.0) 1 else 0)
            p.add("plaquetas" to if (plaq < 100.0) 1 else 0)
            p.add("glasgow" to if (gcs <= 10) 1 else 0)
            p.add("pupilas" to if (pupilas == 1) 1 else 0)
            p.add("lactato" to if (lactato >= 2.0) 1 else 0)
            p.add("pam" to if (map < mapUmbral) 1 else 0)
            p.add("creatinina" to if (creat >= creatUmbral) 1 else 0)
            p.add("pao2fio2" to if (pf < 400.0) 1 else 0)
            p.add("paco2" to if (paco2 < 40.0 || paco2 >= 60.0) 1 else 0)
            p.add("ventilacion" to if (vm == 1) 1 else 0)
            val total = p.sumOf { it.second }
            val band = when {
                total >= 10 -> "Grave ($total/10)"
                total >= 5 -> "Moderada ($total/10)"
                else -> "Leve ($total/10)"
            }
            val warn = if (total >= 10) listOf("PELOD-2 ≥ 10: disfunción orgánica grave; valore discusión pronóstica y traslado a centro de referencia.") else emptyList()
            ScaleResult("VALID", total, band, p.joinToString(" · ") { (k, s) -> if (s == 1) "$k ✓" else "$k 0" }, warn)
        }
    )

    /* ---------------- Phoenix sepsis (v1.4.0) ---------------- */

    private val phoenix = Scale(
        id = "phoenix",
        name = "Phoenix · Criterios de sepsis pediátrica 2024",
        population = "pediatric",
        purpose = "Definir sepsis y shock séptico pediátrico por disfunción orgánica (respiratoria, cardiovascular, coagulación y neurológica).",
        version = "1.4.0",
        effectiveDate = "2026-11-05",
        reviewer = "Pendiente de validación por especialista pediátrico",
        validationStatus = "VALIDATION_REQUIRED",
        interpretation = "≥ 2 puntos + infección sospechada = sepsis. Sepsis + ≥ 1 punto cardiovascular = shock séptico. El término «sepsis grave» queda obsoleto.",
        limitations = "No es una herramienta de cribado precoz: clasifica pacientes ya sospechosos de infección. No aplicable a neonatos < 37 semanas de edad postconcepcional. SpO2/FiO2 solo es válida con SpO2 ≤ 97 %. Las variables no medidas puntúan 0.",
        references = "Sanchez-Pinto LN, et al. International Consensus Criteria for Pediatric Sepsis and Septic Shock (Phoenix). JAMA. 2024;331:675-686.",
        inputs = listOf(
            ScaleInput("edad", "Banda de edad", "choice", listOf(
                0 to "< 1 mes", 1 to "1–11 meses", 2 to "1–< 2 años", 3 to "2–< 5 años", 4 to "5–< 12 años", 5 to "12–17 años")),
            ScaleInput("map", "PAM (mmHg)", "number", min = 10.0, max = 200.0),
            ScaleInput("vaso", "N.º de vasoactivos simultáneos", "choice", listOf(
                0 to "Ninguno", 1 to "1 (dobutamina, dopamina, adrenalina, milrinona, noradrenalina, vasopresina)", 2 to "2 o más")),
            ScaleInput("lactato", "Lactato (mmol/L)", "number", min = 0.0, max = 30.0, required = false),
            ScaleInput("soporte", "Soporte respiratorio", "choice", listOf(0 to "Ninguno", 1 to "VNI / HFNC", 2 to "Ventilación mecánica invasiva")),
            ScaleInput("sf", "SpO2/FiO2 (opcional, SpO2 ≤ 97 %)", "number", min = 50.0, max = 500.0, required = false),
            ScaleInput("pf", "PaO2/FiO2 (opcional)", "number", min = 20.0, max = 600.0, required = false),
            ScaleInput("plaq", "Plaquetas (×10³/µL)", "number", min = 1.0, max = 1000.0, required = false),
            ScaleInput("inr", "INR (opcional)", "number", min = 0.5, max = 10.0, required = false),
            ScaleInput("ddimer", "Dímero D (mg/L FEU, opcional)", "number", min = 0.0, max = 50000.0, required = false),
            ScaleInput("fibrinogeno", "Fibrinógeno (mg/dL, opcional)", "number", min = 10.0, max = 1000.0, required = false),
            ScaleInput("gcs", "Glasgow (peor valor)", "number", min = 3.0, max = 15.0, required = false),
            ScaleInput("pupilas", "Pupilas", "choice", listOf(0 to "Reactivas", 1 to "Fijas bilaterales"))
        ),
        compute = { v ->
            val edad = v["edad"]?.toIntOrNull() ?: return@Scale incomplete("Seleccione banda de edad.")
            val map = v["map"]?.toDoubleOrNull() ?: return@Scale incomplete("Falta la PAM.")
            val vaso = v["vaso"]?.toIntOrNull() ?: return@Scale incomplete("Indique los vasoactivos.")
            val soporte = v["soporte"]?.toIntOrNull() ?: return@Scale incomplete("Indique el soporte respiratorio.")
            val plaq = v["plaq"]?.toDoubleOrNull()
            val gcs = v["gcs"]?.toDoubleOrNull()
            val pupilas = v["pupilas"]?.toIntOrNull() ?: return@Scale incomplete("Indique las pupilas.")
            val mapUmbral1 = listOf(30.0, 38.0, 43.0, 44.0, 48.0, 51.0)[edad]
            val mapUmbral2 = listOf(17.0, 25.0, 31.0, 32.0, 36.0, 38.0)[edad]
            val mapPts = if (map < mapUmbral2) 2 else if (map < mapUmbral1) 1 else 0
            val vasoPts = if (vaso == 2) 2 else if (vaso == 1) 1 else 0
            val lactVal = v["lactato"]?.toDoubleOrNull()
            val lactPts = if (lactVal == null) 0 else if (lactVal >= 11.0) 2 else if (lactVal >= 5.0) 1 else 0
            val cardio = mapPts + vasoPts + lactPts
            val resp = if (soporte == 0) 0 else {
                val pfPts = v["pf"]?.toDoubleOrNull()?.let { pf ->
                    if (soporte == 2 && pf < 100.0) 3 else if (soporte == 2 && pf <= 200.0) 2 else if (pf < 400.0) 1 else 0
                } ?: 0
                val sfPts = v["sf"]?.toDoubleOrNull()?.let { sf ->
                    if (soporte == 2 && sf < 148.0) 3 else if (soporte == 2 && sf <= 220.0) 2 else if (sf < 292.0) 1 else 0
                } ?: 0
                maxOf(pfPts, sfPts)
            }
            val coag = (if (plaq != null && plaq < 100.0) 1 else 0) +
                (if ((v["inr"]?.toDoubleOrNull()?.let { it > 1.3 } ?: false) ||
                    (v["ddimer"]?.toDoubleOrNull()?.let { it > 2.0 } ?: false) ||
                    (v["fibrinogeno"]?.toDoubleOrNull()?.let { it < 100.0 } ?: false)) 1 else 0)
            val neuro = (if (gcs != null && gcs <= 10.0) 1 else 0) + (if (pupilas == 1) 1 else 0)
            val total = resp + cardio + coag + neuro
            val band = when {
                total >= 2 && cardio >= 1 -> "Shock séptico (Phoenix $total)"
                total >= 2 -> "Sepsis definida (Phoenix $total)"
                else -> "No cumple criterios de sepsis (Phoenix $total)"
            }
            val warn = if (total >= 2) listOf(
                "Con infección sospechada, Phoenix ≥ 2 define sepsis (mortalidad significativamente mayor).",
                "Sepsis + ≥ 1 punto cardiovascular = shock séptico: bundle de la primera hora y valor de referencia a UCIP.")
            else emptyList()
            ScaleResult("VALID", total, band,
                "Resp $resp + Cardio $cardio (PAM $mapPts · vaso $vasoPts · lactato $lactPts) + Coag $coag + Neuro $neuro = $total/13", warn)
        }
    )

    /* ---------------- CPOT (v1.4.0) ---------------- */

    private val cpot = Scale(
        id = "cpot",
        name = "CPOT · Dolor en el paciente que no puede comunicarse",
        population = "ambas (adulto y pediátrico verbal-incompetente)",
        purpose = "Evaluar el dolor mediante conductas observables (expresión facial, movimientos, tensión muscular y ventilador/vocalización).",
        version = "1.4.0",
        effectiveDate = "2026-11-05",
        reviewer = "Pendiente de validación por especialista",
        validationStatus = "VALIDATION_REQUIRED",
        interpretation = "≤ 2: dolor mínimo o ausente · ≥ 3: dolor probable — revaluar analgesia y observar la respuesta al tratamiento.",
        limitations = "No aplicable en parálisis farmacológica ni en sedación profunda. Valorar antes y después de la manipulación dolorosa. En menores de 5 años considerar además FLACC.",
        references = "Gélinas C, et al. Am J Respir Crit Care Med 2006; Hillman/ICU delirium ePAD guidance. Adaptación pediátrica según centros.",
        inputs = listOf(
            ScaleInput("tipo", "Situación", "choice", listOf(0 to "Paciente ventilado", 1 to "Paciente no ventilado (extubado)")),
            ScaleInput("facial", "Expresión facial", "choice", listOf(
                0 to "0 · Relajada, neutra", 1 to "1 · Tensada, fruncido", 2 to "2 · Muecas/grimaces")),
            ScaleInput("cuerpo", "Movimientos corporales", "choice", listOf(
                0 to "0 · No se mueve o movimiento normal", 1 to "1 · Protege la zona / cauteloso", 2 to "2 · Agitado, retira, se tensa en posiciones rígidas")),
            ScaleInput("tension", "Tensión muscular (pasiva)", "choice", listOf(
                0 to "0 · Relax", 1 to "1 · Tensa, rígida", 2 to "2 · Muy tensa, resistente a la movilización pasiva")),
            ScaleInput("ventilador", "Compatibilidad con el ventilador (si ventilado)", "choice", required = false, options = listOf(
                0 to "0 · Tolerando la VM", 1 to "1 · Tos pero tolera", 2 to "2 · Lucha contra el ventilador")),
            ScaleInput("vocalizacion", "Vocalización (si no ventilado)", "choice", required = false, options = listOf(
                0 to "0 · Habla normal o sin sonido", 1 to "1 · Suspiro, voz ronca o llanto", 2 to "2 · Gemido, quejido o llanto sostenido"))
        ),
        compute = { v ->
            val tipo = v["tipo"]?.toIntOrNull() ?: return@Scale incomplete("Indique si está ventilado.")
            val facial = v["facial"]?.toIntOrNull() ?: return@Scale incomplete("Valor la expresión facial.")
            val cuerpo = v["cuerpo"]?.toIntOrNull() ?: return@Scale incomplete("Valor los movimientos.")
            val tension = v["tension"]?.toIntOrNull() ?: return@Scale incomplete("Valor la tensión muscular.")
            val cuarto = if (tipo == 0) {
                v["ventilador"]?.toIntOrNull() ?: return@Scale incomplete("Valor la compatibilidad con el ventilador.")
            } else {
                v["vocalizacion"]?.toIntOrNull() ?: return@Scale incomplete("Valor la vocalización.")
            }
            val total = facial + cuerpo + tension + cuarto
            val band = if (total >= 3) "Dolor probable (CPOT $total/8)" else "Dolor mínimo o ausente (CPOT $total/8)"
            val warn = if (total >= 3) listOf("CPOT ≥ 3: reevaluar la analgesia (ajustar dosis o añadir coadyuvante) y repetir tras 30-60 min.") else emptyList()
            ScaleResult("VALID", total, band, "Facial $facial + cuerpo $cuerpo + tensión $tension + ${if (tipo == 0) "ventilador" else "vocalización"} $cuarto = $total/8", warn)
        }
    )

    /* ---------------- WAT-1 (v1.4.0) ---------------- */

    private val wat1 = Scale(
        id = "wat1",
        name = "WAT-1 · Abstinencia a opioides/benzodiacepinas en pediatría",
        population = "pediatric",
        purpose = "Cribar la abstinencia clínicamente significativa en el niño expuesto a sedación continua ≥ 5 días.",
        version = "1.4.0",
        effectiveDate = "2026-11-05",
        reviewer = "Pendiente de validación por especialista pediátrico",
        validationStatus = "VALIDATION_REQUIRED",
        interpretation = "0–2: sin abstinencia significativa · ≥ 3: abstinencia clínicamente significativa — activar protocolo de destete escalonado.",
        limitations = "Formulario original de 11 indicadores (rango total del instrumento original 0–12); esta puntuación digital suma 0–11 con el umbral validado ≥ 3. Aplica a pacientes en retirada de sedantes, no a sedados activos.",
        references = "Franck LS, et al. Development and preliminary evaluation of WAT-1. Intensive Care Med. 2008;34:2098-106 (PMC2775493).",
        inputs = listOf(
            ScaleInput("sudoracion", "Sudoración no provocada", "choice", listOf(0 to "No", 1 to "Sí")),
            ScaleInput("sobresalto", "Sobresalto al tocar", "choice", listOf(0 to "No", 1 to "Sí")),
            ScaleInput("temblor", "Temblor alterado/disturbado", "choice", listOf(0 to "No", 1 to "Sí")),
            ScaleInput("tono", "Tono muscular aumentado", "choice", listOf(0 to "No", 1 to "Sí")),
            ScaleInput("heces", "Heces: ≥ 3 no formadas en el día", "choice", listOf(0 to "No", 1 to "Sí")),
            ScaleInput("vomitos", "Vómitos / gagging / retching", "choice", listOf(0 to "No", 1 to "Sí")),
            ScaleInput("temp", "Temperatura > 37,8 °C sin foco", "choice", listOf(0 to "No", 1 to "Sí")),
            ScaleInput("consolar", "Tiempo para consolar > 10 min", "choice", listOf(0 to "No", 1 to "Sí")),
            ScaleInput("despertar", "Estado despierto activo grave", "choice", listOf(0 to "No", 1 to "Sí")),
            ScaleInput("arousal", "Despertar no provocado", "choice", listOf(0 to "No", 1 to "Sí")),
            ScaleInput("rubor", "Rubor facial aumentado", "choice", listOf(0 to "No", 1 to "Sí"))
        ),
        compute = { v ->
            val keys = listOf("sudoracion", "sobresalto", "temblor", "tono", "heces", "vomitos", "temp", "consolar", "despertar", "arousal", "rubor")
            val missing = keys.filter { v[it]?.toIntOrNull() == null }
            if (missing.isNotEmpty()) return@Scale incomplete("Faltan indicadores: $missing")
            val total = keys.sumOf { v[it]?.toIntOrNull() ?: 0 }
            val band = if (total >= 3) "Abstinencia clínicamente significativa (WAT-1 $total)" else "Sin abstinencia significativa (WAT-1 $total)"
            val warn = if (total >= 3) listOf(
                "WAT-1 ≥ 3: activar protocolo de destete escalonado (titular sedante, metadona/clonidina según unidad) y reevaluar diario.",
                "Los pacientes con sedación continua ≥ 5 días tienen mayor riesgo de puntuación ≥ 3.")
            else emptyList()
            ScaleResult("VALID", total, band, "Suma de 11 indicadores = $total", warn)
        }
    )

    /* ---------------- FENa (v1.4.0) ---------------- */

    private val fena = Scale(
        id = "fen_a",
        name = "FENa · Fracción de excreción de sodio",
        population = "ambas (adulto y pediatric)",
        purpose = "Diferenciar fallo renal prerrenal (hipovolemia) del daño tubular intrínseco (ATN) con orina y plasma.",
        version = "1.4.0",
        effectiveDate = "2026-11-05",
        reviewer = "Pendiente de validación por especialista",
        validationStatus = "VALIDATION_REQUIRED",
        interpretation = "< 1 %: prerrenal (hipovolemia) · 1–2 %: indeterminado · > 2 %: daño renal intrínseco (ATN).",
        limitations = "NO válida si se ha administrado diurético en las últimas 24 h (usar FEUrea) ni en glomerulopatías, uropatía obstructiva o TMA. En neonatos y LCR de fuente de contraste la interpretación cambia.",
        references = "Espinel CH. JAMA 1976 (FENa original); KDIGO AKI 2012 para el contexto del fallo renal agudo.",
        inputs = listOf(
            ScaleInput("una", "Sodio urinario (mEq/L)", "number", min = 0.0, max = 400.0),
            ScaleInput("pna", "Sodio plasmático (mEq/L)", "number", min = 90.0, max = 200.0),
            ScaleInput("ucr", "Creatinina urinaria (mg/dL)", "number", min = 1.0, max = 2000.0),
            ScaleInput("pcr", "Creatinina plasmática (mg/dL)", "number", min = 0.1, max = 30.0)
        ),
        compute = { v ->
            val una = v["una"]?.toDoubleOrNull() ?: return@Scale incomplete("Falta el sodio urinario.")
            val pna = v["pna"]?.toDoubleOrNull() ?: return@Scale incomplete("Falta el sodio plasmático.")
            val ucr = v["ucr"]?.toDoubleOrNull() ?: return@Scale incomplete("Falta la creatinina urinaria.")
            val pcr = v["pcr"]?.toDoubleOrNull() ?: return@Scale incomplete("Falta la creatinina plasmática.")
            if (pna <= 0.0 || pcr <= 0.0 || ucr <= 0.0) {
                return@Scale ScaleResult("INVALID_INPUT", null, null, null, listOf("Valores inválidos (0 o negativo)."))
            }
            val fena = (una * pcr) / (ucr * pna) * 100.0
            val band = when {
                fena < 1.0 -> "Prerrenal (FENa %.1f %%)".format(fena)
                fena <= 2.0 -> "Indeterminado (FENa %.1f %%)".format(fena)
                else -> "Daño intrínseco/ATN (FENa %.1f %%)".format(fena)
            }
            val warn = if (fena < 1.0) listOf("FENa < 1 % apoya hipovolemia: valorar bolo de volumen y revisar diurético reciente.") else emptyList()
            ScaleResult("VALID", (fena * 10).toInt(), band, "(Na_u × Cr_p) ÷ (Cr_u × Na_p) × 100 = %.1f %%".format(fena), warn)
        }
    )

    /* ---------------- SBT (v1.4.0) ---------------- */

    private val sbt = Scale(
        id = "sbt",
        name = "SBT · Criterios de paso del test de respiración espontánea",
        population = "ambas (adulto y pediatric)",
        purpose = "Decidir si el paciente pasa el test de respiración espontánea de 30-120 min y es candidato a extubación.",
        version = "1.4.0",
        effectiveDate = "2026-11-05",
        reviewer = "Pendiente de validación por especialista",
        validationStatus = "VALIDATION_REQUIRED",
        interpretation = "PASS: FR < 35 · SpO2 ≥ 90 % · FC < 140 o ± 20 % del basal · RSBI < 105 · sin agitación ni diaforesis. FAIL: suspender el test y reintentar al día siguiente.",
        limitations = "En pediatría el RSBI tiene interpretación limitada y se valora la evolución clínica (tiraje, quejido, tolerancia). Un único FAIL no contraindica el reintento en 24 h.",
        references = "Ely EW, et al. JAMA 2001 (protocolo SBT); Yang KL, Tobin MJ. Ann Intern Med 1991 (RSBI).",
        inputs = listOf(
            ScaleInput("fr", "Frecuencia respiratoria (rpm)", "number", min = 1.0, max = 80.0),
            ScaleInput("spo2", "SpO2 (%)", "number", min = 50.0, max = 100.0),
            ScaleInput("fc", "Frecuencia cardiaca (lpm)", "number", min = 30.0, max = 250.0),
            ScaleInput("fc_basal", "FC basal (lpm)", "number", min = 30.0, max = 250.0, required = false),
            ScaleInput("rsbi", "RSBI (FB/Vt en L), opcional", "number", min = 0.0, max = 400.0, required = false),
            ScaleInput("agitacion", "Agitación / ansiedad marcada", "choice", listOf(0 to "No", 1 to "Sí")),
            ScaleInput("diaforesis", "Diaforesis marcada", "choice", listOf(0 to "No", 1 to "Sí"))
        ),
        compute = { v ->
            val fr = v["fr"]?.toDoubleOrNull() ?: return@Scale incomplete("Falta la FR.")
            val spo2 = v["spo2"]?.toDoubleOrNull() ?: return@Scale incomplete("Falta la SpO2.")
            val fc = v["fc"]?.toDoubleOrNull() ?: return@Scale incomplete("Falta la FC.")
            val fcBasal = v["fc_basal"]?.toDoubleOrNull()
            val rsbi = v["rsbi"]?.toDoubleOrNull()
            val agit = v["agitacion"]?.toIntOrNull() ?: return@Scale incomplete("Indique la agitación.")
            val diaf = v["diaforesis"]?.toIntOrNull() ?: return@Scale incomplete("Indique la diaforesis.")
            val frOk = fr < 35.0
            val spo2Ok = spo2 >= 90.0
            val fcOk = fc < 140.0 && (fcBasal == null || kotlin.math.abs(fc - fcBasal) <= 0.2 * fcBasal)
            val rsbiOk = rsbi == null || rsbi < 105.0
            val pasa = frOk && spo2Ok && fcOk && rsbiOk && agit == 0 && diaf == 0
            val detalle = mutableListOf(
                if (frOk) "FR ok" else "FR alta ($fr)",
                if (spo2Ok) "SpO2 ok" else "SpO2 baja ($spo2)",
                if (fcOk) "FC ok" else "FC fuera de rango",
                if (rsbiOk) "RSBI ok" else "RSBI alto",
                if (agit == 0) "sin agitación" else "agitación",
                if (diaf == 0) "sin diaforesis" else "diaforesis"
            )
            val band = if (pasa) "PASS — candidato a extubación" else "FAIL — suspender y reintentar en 24 h"
            ScaleResult("VALID", if (pasa) 1 else 0, band, detalle.joinToString(" · "),
                if (!pasa) listOf("Fallo del SBT: revisar causa (carga respiratoria, delirium, secreciones) antes del reintento.") else emptyList())
        }
    )

    /* ---------------- Nutrición parenteral (v1.5.0) ---------------- */

    private val nutricionParenteral = Scale(
        id = "nutricion_parenteral",
        name = "Nutrición parenteral (NPT): kcal, GIR y osmolaridad",
        population = "pediatric",
        purpose = "Planificar la prescripción inicial de nutrición parenteral pediátrica: aportes de glucosa, lípidos y proteínas, energía total, GIR (velocidad de infusión de glucosa) y osmolaridad estimada para elegir vía periférica o central.",
        version = "1.0.0",
        effectiveDate = "2026-11-05",
        reviewer = "Pendiente de validación por especialista pediátrico",
        validationStatus = "VALIDATION_REQUIRED",
        interpretation = "Objetivos orientativos: proteínas 1,5–3 g/kg/día (neonato 2,5–3) · lípidos 1–3 g/kg/día (máx 3–4) · GIR 4–14 mg/kg/min según edad · energía 60–90 kcal/kg/día en UCI según estado. Vía periférica: osmolaridad ≤ 900 mOsm/l; central: mayor (lumen exclusivo).",
        limitations = "Herramienta de planificación orientativa. No sustituye la prescripción individualizada de farmacia ni la monitorización (glucemia, triglicéridos, iones, pruebas hepáticas). En sepsis o hipoperfusión iniciar con cautela. Sumar los aportes de la nutrición enteral simultánea.",
        references = "Ruza F. Tratado de Cuidados Intensivos Pediátricos; ESPGHAN/ESICM guidelines (Pediatr Crit Care Med 2018); Nelson Textbook of Pediatrics, 21.ª ed.; protocolos SECIp.",
        inputs = listOf(
            ScaleInput("peso", "Peso actual", "number", min = 1.0, max = 150.0, unit = "kg"),
            ScaleInput("edad", "Grupo de edad", "choice", listOf(
                0 to "Neonato (< 1 mes)", 1 to "Lactante (1-12 meses)", 2 to "Niño (1-6 años)",
                3 to "Niño (7-12 años)", 4 to "Adolescente (> 12 años)")),
            ScaleInput("volumen", "Volumen total previsto de NPT", "number", min = 10.0, max = 300.0, unit = "ml/kg/día"),
            ScaleInput("glucosa", "Glucosa (dextrosa) aportada", "number", min = 0.0, max = 25.0, unit = "g/kg/día"),
            ScaleInput("lipidos", "Lípidos aportados", "number", min = 0.0, max = 4.0, unit = "g/kg/día"),
            ScaleInput("proteinas", "Aminoácidos (proteínas) aportados", "number", min = 0.0, max = 4.0, unit = "g/kg/día"),
            ScaleInput("via", "Vía de administración", "choice", listOf(0 to "Periférica", 1 to "Central"))
        ),
        compute = { v ->
            val peso = v["peso"]?.toDoubleOrNull() ?: return@Scale incomplete("Introduzca el peso.")
            val edad = v["edad"]?.toIntOrNull() ?: return@Scale incomplete("Seleccione el grupo de edad.")
            val vol = v["volumen"]?.toDoubleOrNull() ?: return@Scale incomplete("Introduzca el volumen de NPT.")
            val glu = v["glucosa"]?.toDoubleOrNull() ?: return@Scale incomplete("Introduzca la glucosa (g/kg/día).")
            val lip = v["lipidos"]?.toDoubleOrNull() ?: return@Scale incomplete("Introduzca los lípidos (g/kg/día).")
            val pro = v["proteinas"]?.toDoubleOrNull() ?: return@Scale incomplete("Introduzca las proteínas (g/kg/día).")
            val via = v["via"]?.toIntOrNull() ?: return@Scale incomplete("Seleccione la vía.")
            if (peso <= 0 || vol <= 0) return@Scale ScaleResult("OUT_OF_RANGE", null, null, null,
                listOf("Peso y volumen deben ser mayores que cero."))

            val kcal = pro * 4.0 + glu * 3.4 + lip * 9.0
            val gir = glu / 1.44   // g/kg/día → mg/kg/min

            // Objetivos orientativos por edad (Ruza / ESPGHAN / SECIp):
            // proteína mín-máx, lípidos máx, GIR máx, volumen referencia ml/kg/día
            val (proMin, proMax, lipMax, girMax, volRef) = when (edad) {
                0 -> listOf(2.0, 3.5, 3.0, 12.0, 120.0)
                1 -> listOf(1.5, 3.0, 3.5, 14.0, 100.0)
                2 -> listOf(1.5, 2.5, 3.5, 12.0, 80.0)
                3 -> listOf(1.2, 2.0, 3.0, 12.0, 70.0)
                else -> listOf(1.2, 2.0, 3.0, 10.0, 50.0)
            }

            // Osmolaridad ESTIMADA de la mezcla base glucosa + aminoácidos (mOsm/l):
            // dextrosa ≈ 5 mOsm/g · aminoácidos ≈ 10 mOsm/g (sin electrolitos)
            val osm = ((glu * 5.0 + pro * 10.0) / (vol / 1000.0)).toInt()

            val warn = mutableListOf<String>()
            if (gir > girMax) warn.add("GIR %.1f mg/kg/min supera el máximo orientativo (%.0f) para la edad: riesgo de hiperglucemia; reduzca la glucosa o la velocidad.".format(gir, girMax))
            if (lip > lipMax) warn.add("Lípidos %.1f g/kg/día superan el máximo orientativo (%.1f): vigilar triglicéridos (pausar si > 300-400 mg/dl).".format(lip, lipMax))
            if (pro < proMin) warn.add("Proteínas %.1f g/kg/día por debajo del objetivo orientativo (%.1f-%.1f): iniciar al menos 1-1,5 g/kg/día para evitar catabolismo.".format(pro, proMin, proMax))
            if (via == 0 && osm > 900) warn.add("Osmolaridad estimada $osm mOsm/l: EXCEDE el límite de la vía periférica (≤ 900); necesita vía central o reducir concentración.")
            if (vol < volRef * 0.6) warn.add("Volumen %.0f ml/kg/día muy restrictivo frente a la referencia (%.0f): comprobar aportes totales y balance.".format(vol, volRef))

            val band = "%.0f kcal/kg/día · GIR %.1f mg/kg/min · osmolaridad estimada %d mOsm/l".format(kcal, gir, osm)
            val detalle = "Proteína %.1f × 4 + glucosa %.1f × 3,4 + lípidos %.1f × 9 = %.0f kcal/kg/día · GIR = %.1f/1,44 = %.1f mg/kg/min · osm ≈ (glucosa×5 + AA×10)/litros (sin electrolitos)".format(pro, glu, lip, kcal, glu, gir)
            ScaleResult("VALID", kcal.toInt(), band, detalle, warn)
        }
    )

    /* ---------------- GIR glucosa (v1.5.0) ---------------- */

    private val girGlucosa = Scale(
        id = "gir_glucosa",
        name = "GIR · Velocidad de infusión de glucosa",
        population = "pediatric",
        purpose = "Calcular el GIR (mg/kg/min) que recibe el paciente con una perfusión de glucosado, o la velocidad (ml/h) necesaria para alcanzar un GIR objetivo.",
        version = "1.0.0",
        effectiveDate = "2026-11-05",
        reviewer = "Pendiente de validación por especialista pediátrico",
        validationStatus = "VALIDATION_REQUIRED",
        interpretation = "Inicio habitual: neonato 4-8 · lactante/niño 5-10 mg/kg/min. Máximos orientativos: neonato 10-14 · niño 12-18 según tolerancia. Hiperglucemia > 180-200 mg/dl: reducir GIR antes de insulina.",
        limitations = "El GIR total suma TODAS las fuentes de glucosa (NPT, fármacos diluidos en glucosado, transvases). Verifique siempre la concentración real de la perfusión.",
        references = "Ruza F. Tratado de Cuidados Intensivos Pediátricos; Nelson Textbook of Pediatrics, 21.ª ed.; protocolos SECIp.",
        inputs = listOf(
            ScaleInput("peso", "Peso", "number", min = 0.5, max = 150.0, unit = "kg"),
            ScaleInput("velocidad", "Velocidad de perfusión", "number", min = 0.1, max = 500.0, unit = "ml/h", required = false),
            ScaleInput("concentracion", "Concentración del glucosado", "choice", listOf(
                5 to "D5 % (50 mg/ml)", 10 to "D10 % (100 mg/ml)", 15 to "D15 % (150 mg/ml)",
                20 to "D20 % (200 mg/ml)", 25 to "D25 % (250 mg/ml)", 30 to "D30 % (300 mg/ml)",
                50 to "D50 % (500 mg/ml)")),
            ScaleInput("girObjetivo", "GIR objetivo (si quiere calcular ml/h)", "number", min = 0.0, max = 30.0, unit = "mg/kg/min", required = false)
        ),
        compute = { v ->
            val peso = v["peso"]?.toDoubleOrNull() ?: return@Scale incomplete("Introduzca el peso.")
            val vel = v["velocidad"]?.toDoubleOrNull()
            val conc = v["concentracion"]?.toIntOrNull() ?: return@Scale incomplete("Seleccione la concentración.")
            val obj = v["girObjetivo"]?.toDoubleOrNull()
            if (peso <= 0) return@Scale ScaleResult("OUT_OF_RANGE", null, null, null, listOf("El peso debe ser mayor que cero."))

            val mgMl = conc * 10.0   // % → mg/ml
            val band: String
            val detalle: String
            val warn = mutableListOf<String>()

            if (obj != null && obj > 0) {
                val mlH = obj * peso * 60.0 / mgMl
                band = "Para GIR %.1f mg/kg/min: %.1f ml/h de D%d %%".format(obj, mlH, conc)
                detalle = "ml/h = GIR × peso × 60 / (mg/ml) = %.1f × %.1f × 60 / %d".format(obj, peso, mgMl.toInt())
                if (obj > 14) warn.add("GIR objetivo alto (> 14): vigilancia glucémica estrecha.")
            } else {
                val g = vel ?: return@Scale incomplete("Introduzca la velocidad (ml/h) o un GIR objetivo.")
                val gir = g * mgMl / peso / 60.0
                band = "GIR %.1f mg/kg/min".format(gir)
                detalle = "GIR = ml/h × (mg/ml) / peso / 60 = %.1f × %d / %.1f / 60".format(g, mgMl.toInt(), peso)
                if (gir > 14) warn.add("GIR %.1f: elevado para la mayoría de edades (máx orientativo 10-14); vigilancia de glucemia e iones.".format(gir))
                if (gir < 3) warn.add("GIR %.1f: bajo; en neonatos y niños no debe bajar de 3-4 mg/kg/min salvo protocolo.".format(gir))
            }
            ScaleResult("VALID", null, band, detalle, warn)
        }
    )

    val all: List<Scale> = listOf(
        // Pediátricas
        tep, glasgowPed, pews, flacc, fluidos, paMin, ett, pesoEst, vitales, oi, schwartz,
        pelod2, phoenix, cpot, wat1,
        // Neonatales
        apgar, silverman,
        // Adultas
        sofa, qsofa, curb65, wellsTvp, wellsPe, cha2, cg, naCorr, ag,
        apache2, news2, childPugh, heart, padua, blatchford, bisap, huntHess,
        // Transversales
        rass, braden, pf, rsbi, compliancia, gradienteAa, imc, scMosteller, diuresis,
        deficitSodio, balanceHidrico, stopBang,
        // Calculadoras v1.3.0
        dosisMgKg, qtc, winter, gapOsmolar, caCorregido, drivingPressure,
        glucosaUnidades, energiaSchofield, vis,
        // Calculadoras v1.4.0
        fena, sbt,
        // Calculadoras v1.5.0 (nutrición)
        nutricionParenteral, girGlucosa
    ) + ClinicalScalesV2.all // Escalas PICU v2.0.0 «Profundización»

    fun byId(id: String) = all.firstOrNull { it.id == id }
}
