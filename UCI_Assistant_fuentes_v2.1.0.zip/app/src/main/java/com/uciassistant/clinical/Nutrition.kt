package com.uciassistant.clinical

/**
 * Nutrición parenteral pediátrica (v1.5.0).
 * Calculadora + contenido docente. Bibliografía: Ruza (Tratado de Cuidados
 * Intensivos Pediátricos), Nelson (Textbook of Pediatrics) y protocolos SECIp
 * (Sociedad Española de Cuidados Intensivos Pediátricos).
 *
 * Fórmulas empleadas:
 *  · GIR (mg/kg/min) = %glucosa × ml/día ÷ (144 × peso kg)
 *  · kcal glucosa    = g glucosa × 3,4 (g = %glucosa × ml/día ÷ 100)
 *  · kcal AA         = g/kg/día × peso × 4,0
 *  · kcal lípidos    = g/kg/día × peso × 10 (emulsión 20 % ≈ 2 kcal/ml)
 *  · Volumen lípidos 20 % (ml/día) = g lípidos/día × 5
 *  · Calorías no proteicas (CNP) = kcal glucosa + kcal lípidos
 *  · Relación CNP:N  = CNP × 6,25 ÷ g de aminoácidos (objetivo 150–300:1)
 */
object Nutrition {

    data class AgeGroup(
        val id: String,
        val label: String,
        val fluidMlKg: Double,        // ml/kg/día orientativos de partida
        val girIdeal: ClosedFloatingPointRange<Double>,
        val girMax: Double,
        val aaMax: Double,
        val lipidMax: Double,
        val kcalTarget: ClosedFloatingPointRange<Double>
    )

    val groups = listOf(
        AgeGroup("neonato", "Neonato término (0–28 d)", 120.0, 4.0..8.0, 12.0, 3.5, 3.5, 90.0..110.0),
        AgeGroup("lactante", "Lactante (1–12 m)", 120.0, 4.0..8.0, 12.0, 3.0, 3.0, 80.0..100.0),
        AgeGroup("nino", "Niño (1–10 a)", 90.0, 4.0..8.0, 12.0, 2.5, 3.0, 60.0..80.0),
        AgeGroup("adolescente", "Adolescente (>10 a)", 55.0, 3.0..6.0, 10.0, 2.0, 2.5, 40.0..60.0)
    )

    data class Input(
        val weightKg: Double,
        val groupId: String,
        val fluidMlKgDay: Double,     // ml/kg/día totales de la NPT
        val glucosePercent: Double,   // % glucosa final de la mezcla
        val aaGKgDay: Double,         // aminoácidos g/kg/día
        val lipidGKgDay: Double,      // lípidos g/kg/día (emulsión 20 %)
        val infusionHours: Double = 24.0
    )

    data class Result(
        val totalMlDay: Double,
        val rateMlH: Double,
        val gir: Double,
        val glucoseGramsDay: Double,
        val aaGramsDay: Double,
        val lipidGramsDay: Double,
        val lipidMlDay: Double,
        val kcalGlucose: Double,
        val kcalAa: Double,
        val kcalLipid: Double,
        val kcalTotal: Double,
        val kcalKgDay: Double,
        val kcalNonProtein: Double,
        val npcrRatio: Double,
        val pctGlucosa: Double,
        val pctAa: Double,
        val pctLipidos: Double,
        val warnings: List<String>
    )

    fun calculate(i: Input): Result {
        val g = groups.first { it.id == i.groupId }
        val totalMlDay = i.weightKg * i.fluidMlKgDay
        val rateMlH = if (i.infusionHours > 0) totalMlDay / i.infusionHours else 0.0
        val glucoseGDay = i.glucosePercent * totalMlDay / 100.0
        val aaGDay = i.aaGKgDay * i.weightKg
        val lipidGDay = i.lipidGKgDay * i.weightKg
        val lipidMlDay = lipidGDay * 5.0

        val gir = if (i.weightKg > 0) i.glucosePercent * totalMlDay / (144.0 * i.weightKg) else 0.0
        val kcalGluc = glucoseGDay * 3.4
        val kcalAa = aaGDay * 4.0
        val kcalLip = lipidGDay * 10.0
        val kcalTotal = kcalGluc + kcalAa + kcalLip
        val kcalKg = if (i.weightKg > 0) kcalTotal / i.weightKg else 0.0
        val cnp = kcalGluc + kcalLip
        val npcr = if (aaGDay > 0) cnp * 6.25 / aaGDay else 0.0

        val warnings = mutableListOf<String>()
        if (i.weightKg <= 0) warnings.add("Peso no válido: introduzca un peso en kg.")
        if (gir > g.girMax) warnings.add("GIR ${"%.1f".format(gir)} mg/kg/min supera el máximo orientativo del grupo (${g.girMax}): riesgo de glucosuria/osmolaridad. Reduzca % glucosa o volumen.")
        if (gir < g.girIdeal.start) warnings.add("GIR ${"%.1f".format(gir)} mg/kg/min por debajo del rango habitual (${g.girIdeal.start}–${g.girIdeal.endInclusive}): aporte calórico insuficiente y riesgo de cetosis/hipoglucemia.")
        if (i.aaGKgDay > g.aaMax) warnings.add("Aminoácidos ${"%.1f".format(i.aaGKgDay)} g/kg/día superan el máximo orientativo (${g.aaMax}).")
        if (i.aaGKgDay in 0.01..0.9) warnings.add("Aminoácidos < 1 g/kg/día: iniciar al menos 1–1,5 g/kg/día (neonato desde el primer día) y progresar.")
        if (i.lipidGKgDay > g.lipidMax) warnings.add("Lípidos ${"%.1f".format(i.lipidGKgDay)} g/kg/día superan el máximo orientativo (${g.lipidMax}): controlar triglicéridos.")
        if (i.glucosePercent > 12.5 && i.groupId != "neonato") warnings.add("Glucosa ${"%.1f".format(i.glucosePercent)} %: concentra la mezcla por vía periférica solo hasta ≈ 12,5 %; por encima, requiere vía central.")
        if (i.glucosePercent > 20.0) warnings.add("Glucosa ${"%.1f".format(i.glucosePercent)} %: en pediatría no superar ≈ 20 % incluso por vía central.")
        if (i.infusionHours > 0 && rateMlH < 1.0 && totalMlDay > 0) warnings.add("Velocidad < 1 ml/h: valorar infusión cíclica concentrada o añadir volumen por otra vía.")
        if (kcalKg > 0 && kcalKg < g.kcalTarget.start) warnings.add("Aporte ${"%.0f".format(kcalKg)} kcal/kg/día por debajo del objetivo del grupo (${g.kcalTarget.start}–${g.kcalTarget.endInclusive}).")
        if (npcr > 0 && npcr < 100) warnings.add("Relación CNP:N ${"%.0f".format(npcr)}:1 baja — las calorías no proteicas no cubren la síntesis proteica (ideal 150–300:1); aumente glucosa/lípidos o reduzca AA.")

        return Result(
            totalMlDay, rateMlH, gir, glucoseGDay, aaGDay, lipidGDay, lipidMlDay,
            kcalGluc, kcalAa, kcalLip, kcalTotal, kcalKg, cnp, npcr,
            if (kcalTotal > 0) kcalGluc * 100 / kcalTotal else 0.0,
            if (kcalTotal > 0) kcalAa * 100 / kcalTotal else 0.0,
            if (kcalTotal > 0) kcalLip * 100 / kcalTotal else 0.0,
            warnings
        )
    }

    /** Electrolyte/vitamin additions per kg/day (SECIP/Ruza orientation). */
    val electrolytes: List<List<String>> = listOf(
        listOf("Sodio", "2–4 mmol/kg/día", "Ajustar por pérdidas y nivel sérico"),
        listOf("Potasio", "1–3 mmol/kg/día", "No añadir si oliguria o hiperkalemia"),
        listOf("Cloro", "2–3 mmol/kg/día", "Balancear con acetato si hiperclorémica"),
        listOf("Calcio", "0,5–1,5 mmol/kg/día", "Vigilar precipitación con fosfato (producto Ca×P < 60)"),
        listOf("Fósforo", "0,5–2 mmol/kg/día", "Vigilar también con vitamina D"),
        listOf("Magnesio", "0,1–0,3 mmol/kg/día", ""),
        listOf("Oligoelementos", "1 ml/día preparación pediátrica (Ped-PAED)", "Zn, Cu, Mn, Cr, Se, I"),
        listOf("Vitaminas", "1 ml/día preparación pediátrica", "Hidrosolubles + liposolubles; proteger de la luz")
    )

    /** Tabla orientativa por grupo de edad (Ruza / Nelson / SECIp). */
    val ageTable: List<List<String>> = listOf(
        listOf("Grupo", "Líquidos (ml/kg/d)", "GIR (mg/kg/min)", "AA (g/kg/d)", "Lípidos (g/kg/d)", "kcal/kg/d"),
        listOf("Neonato término", "60→150 (progresivo)", "4–8 (máx 12)", "1,5→3–3,5", "0,5→3–3,5", "90–110"),
        listOf("Lactante", "100–150", "4–8", "1,5→2,5–3", "1→3", "80–100"),
        listOf("Niño", "80–120", "3–8", "1,5→2–2,5", "1→3", "60–80"),
        listOf("Adolescente", "40–60", "3–6", "1→1,5–2", "1→2,5", "40–60")
    )

    val education: List<Pair<String, String>> = listOf(
        "¿Cuándo indicar nutrición parenteral?" to
            "Cuando la vía enteral no es posible ni suficiente: íleo prolongado, obstrucción, " +
            "fístulas intestinales de alto débito, perforación, cirugía mayor gastrointestinal, " +
            "shock hemorrágico/descompensado (fase aguda), intolerance enteral mantenida. " +
            "Regla orientativa: si la nutrición enteral no va a alcanzarse en 3–5 días " +
            "(menos en neonatos: 1–2 días), iniciar NPT. La NPT COMPLEMENTA, nunca sustituye " +
            "de forma automática: mantener enteral en todo lo posible (trophic feeds).",
        "Vía periférica o central" to
            "Periférica: mezcla diluida, osmolaridad ≈ ≤ 900 mOsm/l (glucosa ≈ ≤ 12,5 %, " +
            "aminoácidos ≈ ≤ 2–2,5 %); apropiada para aportes cortos o parciales. Central " +
            "(catéter central de manera dedicada): permite concentraciones mayores (glucosa " +
            "hasta 20 %, más AA y electrolitos) y es la elección si se prevé NPT > 5–7 días " +
            "o requerimientos altos. Catéter dedicado exclusivamente a la NPT; técnica " +
            "estéril máxima y biprobe de enfermería en cada manipulación.",
        "Progresión de macronutrientes" to
            "Glucosa: empezar GIR 4–6 mg/kg/min (neonato) o 3–5 (mayores) y aumentar 1–2 " +
            "mg/kg/min según glucemias. Aminoácidos: neonato desde 1,5–2 g/kg/día el día 1 " +
            "hasta 3–3,5; niños 1–1,5 → 2–2,5. Lípidos: iniciar 0,5–1 g/kg/día y progresar " +
            "hasta 2–3 (máx 3–3,5); infusión continua 20–24 h y triglicéridos para vigilar " +
            "(objetivo < 250–300 mg/dl; evitar > 400–450 mg/dl).",
        "Vigilancia bioquímica (Ruza/SECIp)" to
            "Inicio: glucemia capilar 1–4 h tras cada cambio de GIR; electrolitos, urea, " +
            "creatinina y triglicéridos diarios la primera semana; transaminasas, bilirrubina " +
            "(directa) y fosfatasa alcalina 1–2×/semana (colestasis asociada a NPT); calcio, " +
            "fósforo, magnesio y albúmina 2×/semana; LDH/CPK ante sospecha de intolerance " +
            "lipídica. Ajustar aporte según pérdidas (diuresis, drenajes, diarrea).",
        "Complicaciones principales" to
            "Metabólicas: hiperglucemia/hipoglucemia (retirada brusca), hipertrigliceridemia, " +
            "hiperamoniemia, acidosis, hiperclorémica. Hepáticas: colestasis (asociada a NPT " +
            "prolongada, sobreinfección y ausencia de enteral). Infecciosas: BSI asociada a " +
            "catéter (estafilococo coagulasa-negativo la más frecuente). Mecánicas y " +
            "trombosis central. Ósea: enfermedad metabólica ósea (déficit de fósforo/calcio/" +
            "vitamina D) en prematuros y NPT prolongadas.",
        "Retirada progresiva" to
            "Reducir NPT a medida que la enteral avanza (> 50–60 % de requerimientos por vía " +
            "enteral: empezar a disminuir; > 75 %: retirar). Nunca suspender de golpe una NPT " +
            "con GIR alta: reducir glucosa gradualmente para evitar hipoglucemia reactiva. " +
            "Documentar aporte total (enteral + parenteral) en el balance diario."
    )
}
