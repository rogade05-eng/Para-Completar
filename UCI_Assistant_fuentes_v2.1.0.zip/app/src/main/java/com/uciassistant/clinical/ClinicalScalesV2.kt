package com.uciassistant.clinical

/**
 * Escalas PICU adicionales (v2.0.0 «Profundización»): PRISM III, FOUR Score,
 * KDIGO-AKI pediátrico, Westley (crup), NIPS (dolor neonatal), Fisher (SAH),
 * Pediatric Trauma Score y Parkland/Lund&Browder (quemaduras).
 * Mismo contrato de datos que ClinicalScales (sección 9): población, propósito,
 * entradas, cálculo puro, interpretación, limitaciones y referencias.
 * Todas en estado VALIDATION_REQUIRED (9.3): uso educativo, validar antes de uso clínico.
 */
object ClinicalScalesV2 {

    private fun inc(msg: String) = ScaleResult("INCOMPLETE", null, null, msg, emptyList())

    private fun ch(id: String, label: String, options: List<Pair<Int, String>>) =
        ScaleInput(id, label, "choice", options)

    private fun nm(id: String, label: String, min: Double, max: Double, unit: String? = null, required: Boolean = true) =
        ScaleInput(id, label, "number", min = min, max = max, unit = unit, required = required)

    private fun num(v: Map<String, String>, id: String) = v[id]?.toDoubleOrNull()

    private fun ageGroup(meses: Double): String = when {
        meses < 1 -> "neonato"
        meses < 12 -> "lactante"
        meses < 24 -> "12-23 meses"
        meses < 72 -> "2-5 años"
        meses < 144 -> "6-11 años"
        else -> "12-17 años"
    }

    /* ---------------- PRISM III (simplificado docente) ---------------- */

    private val prism3 = Scale(
        id = "prism3",
        name = "PRISM III (riesgo de mortalidad pediátrico, versión docente)",
        population = "pediatric",
        purpose = "Estimar el riesgo de mortalidad en UCI pediátrica a partir de variables fisiológicas de las primeras 12-24 h.",
        version = "2.0.0",
        effectiveDate = "2026-11-07",
        reviewer = "Pendiente de validación por especialista pediátrico",
        validationStatus = "VALIDATION_REQUIRED",
        interpretation = "Puntuación aproximada: 0-3 bajo · 4-9 intermedio · ≥ 10 alto riesgo de mortalidad. Es un cálculo DOCENTE simplificado (no el score oficial completo con todas las ventanas de puntuación): usar para formación y comparación de gravedad, no como pronóstico formal.",
        limitations = "Versión simplificada con las variables centrales del PRISM III; el score original usa ventanas horarias precisas y constantes adicionales. No aplica en < 1 mes, cardiopatías congénitas en preoperatorio ni estancias < 2 h. No sustituye el cálculo oficial auditado.",
        references = "Pollack MM et al. PRISM III: an updated Pediatric Risk of Mortality score. J Pediatr 1996;128:673-6. Lacroix J et al. PIM2/PELOD comparaciones. Pediatr Crit Care Med 2018.",
        inputs = listOf(
            ch("sistolica_band", "Tensión sistólica (banda según edad)", listOf(
                0 to "Normal para la edad",
                1 to "Hipotensión leve para la edad (1-5 puntos)",
                2 to "Hipotensión grave para la edad (7-10 puntos)")),
            ch("temperatura", "Temperatura más baja registrada", listOf(
                0 to "≥ 33 °C", 1 to "< 33 °C (3 puntos)")),
            ch("mental", "Estado mental (mejor GCS de las primeras 12 h)", listOf(
                0 to "GCS ≥ 8 o despierto", 1 to "GCS < 8 / coma (5 puntos)")),
            ch("pupilas", "Pupilas", listOf(
                0 to "Normorreactivas", 1 to "Unilateral fija midriática (7 puntos)", 2 to "Bilateral fija midriática (11 puntos)")),
            ch("ph", "pH arterial más bajo", listOf(
                0 to "≥ 7,28", 1 to "7,00-7,27 (2 puntos)", 2 to "< 7,00 (6 puntos)")),
            ch("pco2", "PaCO2 más alta", listOf(
                0 to "≤ 50 mmHg", 1 to "50-65 (1 punto)", 2 to "> 65 (5 puntos)")),
            ch("pao2", "PaO2 más baja (si FiO2 ≥ 0,5)", listOf(
                0 to "≥ 50 mmHg o FiO2 < 0,5", 1 to "< 50 con FiO2 ≥ 0,5 (6 puntos)")),
            ch("glucosa", "Glucosa máxima", listOf(
                0 to "≤ 200 mg/dl", 1 to "> 200 (2 puntos)")),
            ch("potasio", "Potasio máximo", listOf(
                0 to "≤ 6,9 mEq/L", 1 to "≥ 7 (5 puntos)")),
            ch("creatinina", "Creatinina máxima (mg/dl)", listOf(
                0 to "Normal para la edad", 1 to "Elevada (≈ 1,5-2 adulto / ajustada por edad) (2 puntos)")),
            ch("bun", "Urea (BUN) máxima", listOf(
                0 to "< 40 mg/dl", 1 to "≥ 40 (3 puntos)")),
            ch("leucocitos", "Leucocitos mínimos", listOf(
                0 to "≥ 3.000/µl", 1 to "< 3.000 (4 puntos)")),
            ch("plaquetas", "Plaquetas mínimas", listOf(
                0 to "≥ 100.000/µl", 1 to "50-100.000 (4 puntos)", 2 to "< 50.000 (6 puntos)")),
            ch("ptptt", "TP/TTPa (no por anticoagulación previa)", listOf(
                0 to "Normales", 1 to "Alargados (3 puntos)"))
        ),
        compute = { v ->
            val sbp = v["sistolica_band"]?.toIntOrNull() ?: return@Scale inc("Seleccione banda de tensión sistólica.")
            val sbpPts = when (sbp) { 0 -> 0; 1 -> 5; else -> 8 }
            var total = 0
            val detalle = mutableListOf<String>()
            fun add(label: String, opt: Int, pts: List<Int>) {
                val p = pts.getOrNull(opt) ?: 0; total += p
                if (p > 0) detalle.add("$label: +$p")
            }
            add("Hipotensión", sbp, listOf(0, 5, 8))
            add("Hipotermia < 33 °C", v["temperatura"]?.toIntOrNull() ?: 0, listOf(0, 3))
            add("GCS < 8", v["mental"]?.toIntOrNull() ?: 0, listOf(0, 5))
            add("Pupilas", v["pupilas"]?.toIntOrNull() ?: 0, listOf(0, 7, 11))
            add("pH", v["ph"]?.toIntOrNull() ?: 0, listOf(0, 2, 6))
            add("PaCO2", v["pco2"]?.toIntOrNull() ?: 0, listOf(0, 1, 5))
            add("PaO2 < 50 (FiO2 ≥ 0,5)", v["pao2"]?.toIntOrNull() ?: 0, listOf(0, 6))
            add("Glucosa > 200", v["glucosa"]?.toIntOrNull() ?: 0, listOf(0, 2))
            add("K ≥ 7", v["potasio"]?.toIntOrNull() ?: 0, listOf(0, 5))
            add("Creatinina", v["creatinina"]?.toIntOrNull() ?: 0, listOf(0, 2))
            add("Urea ≥ 40", v["bun"]?.toIntOrNull() ?: 0, listOf(0, 3))
            add("Leucocitos < 3.000", v["leucocitos"]?.toIntOrNull() ?: 0, listOf(0, 4))
            add("Plaquetas", v["plaquetas"]?.toIntOrNull() ?: 0, listOf(0, 4, 6))
            add("TP/TTPa", v["ptptt"]?.toIntOrNull() ?: 0, listOf(0, 3))
            val banda = when {
                total <= 3 -> "Bajo riesgo (0-3)"
                total <= 9 -> "Riesgo intermedio (4-9)"
                else -> "Alto riesgo (≥ 10)"
            }
            ScaleResult("VALID", total, banda,
                "Total docente simplificado: $total puntos" + (if (detalle.isNotEmpty()) " · " + detalle.joinToString(" · ") else ""),
                listOf("Cálculo docente simplificado, no el score oficial. Usar PIM2/PELOD-2 auditados para investigación o pronóstico formal."))
        }
    )

    /* ---------------- FOUR Score ---------------- */

    private val four = Scale(
        id = "four_score",
        name = "FOUR Score (Full Outline of UnResponsiveness)",
        population = "ambas",
        purpose = "Valorar el nivel de conciencia en pacientes intubados/sedados donde el GCS verbal es incalculable; útil en neurocrítico.",
        version = "2.0.0",
        effectiveDate = "2026-11-07",
        reviewer = "Pendiente de validación por especialista",
        validationStatus = "VALIDATION_REQUIRED",
        interpretation = "Total 0-16 (4 dominios × 0-4): 16 normal · ≤ 8 coma grave · ≤ 4 riesgo de desenlace grave (secuelas o muerte) · el dominio motor y los reflejos de tronco son los de mayor valor pronóstico en encefalopatía hipóxico-isquémica.",
        limitations = "Requiere exploración sin sedación (o con sedación mínima documentada). En bloqueo neuromuscular es incalculable. Validado principalmente en adultos y niños mayores; en lactantes usar con cautela y experiencia neurocrítica.",
        references = "Wijdicks EFM et al. Validation of a new coma scale: The FOUR score. Ann Neurol 2005;58:569-73. Iyer VN et al. FOUR score en neurocrítico. Neurocrit Care 2009.",
        inputs = listOf(
            ch("ocular", "Respuesta ocular", listOf(
                4 to "4 · Pestañas abiertas, seguimiento", 3 to "3 · Abiertos pero no seguimiento",
                2 to "2 · Abiertos al estímulo verbal", 1 to "1 · Abiertos al dolor", 0 to "0 · Permanecen cerrados")),
            ch("motora", "Respuesta motora", listOf(
                4 to "4 · Puñegrambo (alzar puño/dedo al mandato)", 3 to "3 · Localiza el dolor",
                2 to "2 · Retirada flexora al dolor", 1 to "1 · Postura extensora", 0 to "0 · Sin respuesta o espasmo generalizado")),
            ch("tronco", "Reflejos de tronco (pupilar, corneal, tos, oculocéfálico)", listOf(
                4 to "4 · Pupilar y corneal presentes", 3 to "3 · Un pupilar fijo",
                2 to "2 · Pupilar o corneal ausentes", 1 to "1 · Pupilar y corneal ausentes", 0 to "0 · Pupilar, corneal y tos ausentes")),
            ch("respiracion", "Respiración (con ventilador)", listOf(
                4 to "4 · No intubado, patrón regular", 3 to "3 · No intubado, patrón irregular (Cheyne-Stokes)",
                2 to "2 · Intubado, dispara el respirador (> 12/min)", 1 to "1 · Intubado, no dispara o 1 vez/min", 0 to "0 · Apnea (sin respiración)"))
        ),
        compute = { v ->
            val o = v["ocular"]?.toIntOrNull() ?: return@Scale inc("Seleccione respuesta ocular.")
            val m = v["motora"]?.toIntOrNull() ?: return@Scale inc("Seleccione respuesta motora.")
            val t = v["tronco"]?.toIntOrNull() ?: return@Scale inc("Seleccione reflejos de tronco.")
            val r = v["respiracion"]?.toIntOrNull() ?: return@Scale inc("Seleccione respiración.")
            val total = o + m + t + r
            val banda = when {
                total == 16 -> "Normal (16)"
                total > 12 -> "Alteración leve-moderada"
                total > 8 -> "Coma moderado-grave"
                total > 4 -> "Coma grave (> 8 crítico)"
                else -> "Muy grave (≤ 4): alto riesgo de desenlace fatal"
            }
            ScaleResult("VALID", total, banda,
                "Ojos $o + Motor $m + Tronco $t + Respiración $r = $total/16", emptyList())
        }
    )

    /* ---------------- KDIGO-AKI pediátrico ---------------- */

    private val kdigo = Scale(
        id = "kdigo_aki",
        name = "KDIGO-AKI pediátrico (estadiificación)",
        population = "pediatric",
        purpose = "Estadificar la lesión renal aguda con el criterio KDIGO adaptado: relación creatinina/basal y diuresis.",
        version = "2.0.0",
        effectiveDate = "2026-11-07",
        reviewer = "Pendiente de validación por especialista",
        validationStatus = "VALIDATION_REQUIRED",
        interpretation = "Estadio 1: Cr 1,5-1,9× basal (o ↑ ≥ 0,3 mg/dl) o diuresis < 0,5 ml/kg/h por 6-12 h · Estadio 2: Cr 2,0-2,9× o diuresis < 0,5 por ≥ 12 h · Estadio 3: Cr ≥ 3× (o ≥ 4 mg/dl) o FG < 35 ml/min/1,73m² o diuresis < 0,3 por 24 h / anuria 12 h / RRT. La diuresis y la creatinina se clasifican por SEPARADO y prima la mayor.",
        limitations = "Requiere creatinina basal (o estimada por Schwartz con PTA 0,33 si desconocida). La diuresis sola puede sobrestadificar en niños poliúricos con diuréticos: interpretar con contexto de fluidos.",
        references = "KDIGO Clinical Practice Guideline for Acute Kidney Injury. Kidney Int Suppl 2012;2:1-138. Basu RK et al. Assessment of worldwide acute kidney injury, renal angina and epidemiology in children (AWARE). Kidney Int 2017.",
        inputs = listOf(
            nm("ratio_cr", "Creatinina actual / creatinina basal (x)", 0.5, 20.0),
            ch("subida03", "Subida absoluta ≥ 0,3 mg/dl en 48 h", listOf(0 to "No", 1 to "Sí")),
            ch("diuresis", "Diuresis mínima sostenida (ml/kg/h)", listOf(
                0 to "≥ 0,5", 1 to "< 0,5 durante 6-12 h", 2 to "< 0,5 durante ≥ 12 h",
                3 to "< 0,3 durante ≥ 24 h o anuria ≥ 12 h")),
            ch("rrt", "Terapia de sustitución renal", listOf(0 to "No", 1 to "Sí (RRT)")),
            ch("fg", "FG (Schwartz) si conocido", listOf(
                0 to "≥ 35 ml/min/1,73 m² o no calculado", 1 to "< 35 ml/min/1,73 m²"))
        ),
        compute = { v ->
            val ratio = num(v, "ratio_cr") ?: return@Scale inc("Introduzca la relación creatinina/basal.")
            val sub = v["subida03"]?.toIntOrNull() ?: 0
            val diu = v["diuresis"]?.toIntOrNull() ?: return@Scale inc("Seleccione la diuresis.")
            val rrt = v["rrt"]?.toIntOrNull() ?: 0
            val fg = v["fg"]?.toIntOrNull() ?: 0
            val crStage = when {
                rrt == 1 || fg == 1 || ratio >= 3.0 -> 3
                ratio >= 2.0 -> 2
                ratio >= 1.5 || sub == 1 -> 1
                else -> 0
            }
            val diuStage = when (diu) { 3 -> 3; 2 -> 2; 1 -> 1; else -> 0 }
            val stage = maxOf(crStage, diuStage)
            val banda = when (stage) {
                0 -> "Sin AKI (KDIGO 0)"
                1 -> "AKI estadio 1"
                2 -> "AKI estadio 2"
                else -> "AKI estadio 3"
            }
            val detalle = "Creatinina → estadio $crStage${if (rrt == 1 || fg == 1) " (RRT o FG<35 ⇒ 3)" else ""} · Diuresis → estadio $diuStage"
            ScaleResult(if (stage == 0) "VALID" else "VALID", stage, banda, detalle,
                listOf("Revaluar cada 12-24 h; ajustar fármacos y revisar nefrotóxicos desde el estadio 1."))
        }
    )

    /* ---------------- Westley (crup) ---------------- */

    private val westley = Scale(
        id = "westley_crup",
        name = "Escala de Westley (crup / laringotraqueobronquitis)",
        population = "pediatric",
        purpose = "Cuantificar la gravedad del crup y decidir tratamiento (dexametasona, adrenalina nebulizada, ingreso).",
        version = "2.0.0",
        effectiveDate = "2026-11-07",
        reviewer = "Pendiente de validación por especialista",
        validationStatus = "VALIDATION_REQUIRED",
        interpretation = "0-2 leve (no ingreso salvo riesgo) · 3-5 leve-moderada (dexametasona 0,15-0,6 mg/kg; observar 2-4 h) · 6-11 moderada (+ adrenalina nebulizada: epinefrina racémica 0,05 ml/kg máx 0,5 ml de 2,25 % o L-adrenalina 1:1000 0,5 ml/kg máx 5 ml) · ≥ 12 grave: adrenalina + consideración de intubación con tubo 1-2 mm menor.",
        limitations = "Valorar 15-30 min tras el llanto/estrés; la puntuación fluctúa. En < 6 meses o con antecedentes de vía aérea, umbral de ingreso más bajo.",
        references = "Westley CR et al. Ince croup hospitalization. Am J Dis Child 1978. Bjornson C, Johnson DW. Croup in children. CMAJ 2013;185:1307-15. Guía NICE/SECIp crup.",
        inputs = listOf(
            ch("estridor", "Estridor inspiratorio", listOf(
                0 to "0 · Ausente", 1 to "1 · Con agitación", 2 to "2 · En reposo")),
            ch("tiraje", "Tiraje (retracciones)", listOf(
                0 to "0 · Ausente", 1 to "1 · Leve", 2 to "2 · Moderado", 3 to "3 · Grave (esternal + supraclavicular)")),
            ch("entrada_aire", "Entrada de aire", listOf(
                0 to "0 · Normal", 1 to "1 · Disminuida", 2 to "2 · Muy disminuida/audible lejos")),
            ch("cianosis", "Cianosis", listOf(
                0 to "0 · Ausente", 4 to "4 · Con agitación", 5 to "5 · En reposo")),
            ch("conciencia", "Nivel de conciencia", listOf(
                0 to "0 · Normal", 5 to "5 · Alterado/agitado/letárgico"))
        ),
        compute = { v ->
            val items = listOf("estridor", "tiraje", "entrada_aire", "cianosis", "conciencia")
            var total = 0
            for (i in items) total += v[i]?.toIntOrNull() ?: return@Scale inc("Puntúe todos los apartados.")
            val banda = when {
                total <= 2 -> "Leve (0-2)"
                total <= 5 -> "Leve-moderada (3-5): dexametasona"
                total <= 11 -> "Moderada (6-11): dexametasona + adrenalina nebulizada"
                else -> "Grave (≥ 12): adrenalina + vía aérea preparada"
            }
            ScaleResult("VALID", total, banda, "Estridor ${v["estridor"]} + Tiraje ${v["tiraje"]} + Aire ${v["entrada_aire"]} + Cianosis ${v["cianosis"]} + Conciencia ${v["conciencia"]}", emptyList())
        }
    )

    /* ---------------- NIPS (dolor neonatal) ---------------- */

    private val nips = Scale(
        id = "nips_neonatal",
        name = "NIPS (escala de dolor neonatal)",
        population = "neonatal",
        purpose = "Evaluar el dolor en el recién nacido (procedimientos: punción calcanear, venopunción, LP) de 0-7 puntos.",
        version = "2.0.0",
        effectiveDate = "2026-11-07",
        reviewer = "Pendiente de validación por especialista neonatal",
        validationStatus = "VALIDATION_REQUIRED",
        interpretation = "0-2 sin dolor o mínimo · 3-3,9 leve · ≥ 4 dolor significativo: aplicar analgesia (sucrosa 24 % 0,5-2 ml + succión no nutritiva ± analgesia tópica/sistémica según procedimiento) y repetir la escala después.",
        limitations = "Sesgo con sedantes/relajantes (subestima) y con prematuros extremos (respuestas atenuadas). La sucrosa sola no basta para procedimientos dolorosos moderados-graves: completar con analgesia farmacológica.",
        references = "Lawrence J et al. The development of a tool to assess neonatal pain: Neonatal Infant Pain Scale (NIPS). Anesth Analg 1993;77:422-6. Anand KJS. Consensus statement for prevention and management of pain in the newborn. Arch Pediatr Adolesc Med 2001.",
        inputs = listOf(
            ch("cara", "Expresión facial", listOf(0 to "0 · Relajada", 1 to "1 · Gruñido/grimace")),
            ch("llanto", "Llanto", listOf(0 to "0 · No llora", 1 to "1 · Quejido, hiperventilación o llanto inconsolable")),
            ch("respiracion", "Patrón respiratorio", listOf(0 to "0 · Normal", 1 to "1 · Cambios (irregular, rápido, apnea)")),
            ch("brazos", "Brazos", listOf(0 to "0 · Relajados", 1 to "1 · Flexionados/extendidos tensos")),
            ch("piernas", "Piernas", listOf(0 to "0 · Relajadas", 1 to "1 · Flexionadas/extendidas tensas")),
            ch("estado", "Estado de alerta", listOf(0 to "0 · Dormido/tranquilo", 1 to "1 · Intranquilo/agitado"))
        ),
        compute = { v ->
            val items = listOf("cara", "llanto", "respiracion", "brazos", "piernas", "estado")
            var total = 0
            for (i in items) total += v[i]?.toIntOrNull() ?: return@Scale inc("Puntúe todos los apartados.")
            val banda = when {
                total <= 2 -> "Sin dolor / mínimo (0-2)"
                total < 4 -> "Leve (3)"
                else -> "Dolor significativo (≥ 4): analgesia"
            }
            ScaleResult("VALID", total, banda, "Suma de 6 dominios = $total/7", emptyList())
        }
    )

    /* ---------------- Fisher (SAH en TC) ---------------- */

    private val fisher = Scale(
        id = "fisher_sah",
        name = "Escala de Fisher (TC en hemorragia subaracnoidea)",
        population = "ambas",
        purpose = "Clasificar la carga de sangre subaracnoidea en TC y estratificar el riesgo de vasoespasmo sintomático.",
        version = "2.0.0",
        effectiveDate = "2026-11-07",
        reviewer = "Pendiente de validación por especialista",
        validationStatus = "VALIDATION_REQUIRED",
        interpretation = "Grado 1: sin sangre · Grado 2: sangre difusa fina (< 1 mm, sin coágulos) · Grado 3: coágulo localizado o capa gruesa ≥ 1 mm (mayor riesgo de vasoespasmo) · Grado 4: sangre difusa + hemorragia intraventricular/intraparenquimatosa. Grado 3 y 4: vigilancia neurológica intensiva y TCD seriada.",
        limitations = "Escaneo temprano (< 24 h) ideal: la sangre se reabsorbe y la sensibilidad cae. La escala modificada de Claassen añade mayor precisión de riesgo. En pediatría, usar junto a Hunt-Hess y mGCS.",
        references = "Fisher CM et al. Relation of cerebral vasospasm to subarachnoid hemorrhage visualized by computerized tomographic scanning. Neurosurgery 1980;6:1-9. Claassen J et al. Modified Fisher scale. Stroke 2001;32:1348-53.",
        inputs = listOf(
            ch("grado", "Hallazgo en la TC craneal", listOf(
                1 to "Grado 1 · Sin sangre subaracnoidea",
                2 to "Grado 2 · Sangre difusa fina < 1 mm, sin coágulos",
                3 to "Grado 3 · Coágulo localizado o capa ≥ 1 mm",
                4 to "Grado 4 · Difusa + HIC intraventricular o intraparenquimatosa"))
        ),
        compute = { v ->
            val g = v["grado"]?.toIntOrNull() ?: return@Scale inc("Seleccione el hallazgo de TC.")
            val banda = when (g) {
                1 -> "Grado 1: riesgo bajo de vasoespasmo"
                2 -> "Grado 2: riesgo intermedio-bajo"
                3 -> "Grado 3: MAYOR riesgo de vasoespasmo sintomático"
                else -> "Grado 4: riesgo alto + hidrocefalia a vigilar"
            }
            ScaleResult("VALID", g, banda, "Fisher grado $g/4", emptyList())
        }
    )

    /* ---------------- Pediatric Trauma Score ---------------- */

    private val pts = Scale(
        id="pediatric_trauma_score",
        name = "Pediatric Trauma Score (PTS)",
        population = "pediatric",
        purpose = "Estratificar la gravedad del trauma pediátrico y decidir traslado a centro traumático pediátrico.",
        version = "2.0.0",
        effectiveDate = "2026-11-07",
        reviewer = "Pendiente de validación por especialista",
        validationStatus = "VALIDATION_REQUIRED",
        interpretation = "Rango −6 a +12. ≤ 0: ALTO RIESGO → activar protocolo de trauma pediátrico y traslado a centro con UCI pediátrica · 1-8: riesgo intermedio · ≥ 9: bajo riesgo. Cualquier puntuación por debajo del valor máximo exige reevaluación clínica continua.",
        limitations = "No sustituye el mecanismo lesionante ni el juicio del traslado (criterios de fisiología + anatomía + mecanismo). Recalcular en tránsito.",
        references = "Tepas JJ 3rd et al. Pediatric Trauma Score as a predictor of injury severity. J Pediatr Surg 1987;22:14-8. ACS-COT. Resources for Optimal Care of the Injured Patient 2022.",
        inputs = listOf(
            ch("tamano", "Tamaño (peso)", listOf(
                2 to "+2 · ≥ 20 kg", 1 to "+1 · 10-20 kg", -1 to "−1 · < 10 kg")),
            ch("via_aerea", "Vía aérea", listOf(
                2 to "+2 · Normal", 1 to "+1 · Mantenible (posicionamiento/cánulas)",
                -1 to "−1 · No mantenible (intubación/quirúrgica)")),
            ch("pas", "Tensión sistólica", listOf(
                2 to "+2 · ≥ 90 mmHg", 1 to "+1 · 50-90 o llenado capilar 2-5 s", -1 to "−1 · < 50 o > 5 s")),
            ch("conciencia", "Conciencia (AVPU)", listOf(
                2 to "+2 · Despierto", 1 to "+1 · Alterado/responde a estímulos", -1 to "−1 · Coma/no responde")),
            ch("fracturas", "Fracturas abiertas o múltiples", listOf(
                2 to "+2 · Ninguna", 1 to "+1 · Cerrada única", -1 to "−1 · Abierta o múltiple")),
            ch("heridas", "Heridas penetrantes", listOf(
                2 to "+2 · Ninguna", 1 to "+1 · Menores", -1 to "−1 · Mayores/penetrantes"))
        ),
        compute = { v ->
            val items = listOf("tamano", "via_aerea", "pas", "conciencia", "fracturas", "heridas")
            var total = 0
            for (i in items) total += v[i]?.toIntOrNull() ?: return@Scale inc("Puntúe todos los apartados.")
            val banda = when {
                total <= 0 -> "≤ 0: ALTO RIESGO → centro traumático pediátrico"
                total < 9 -> "1-8: riesgo intermedio → vigilancia estrecha"
                else -> "≥ 9: bajo riesgo"
            }
            ScaleResult("VALID", total, banda,
                "Total: $total (rango −6 a +12)", listOf("Recalcular durante el traslado; el mecanismo y la evolución pesan tanto como la cifra."))
        }
    )

    /* ---------------- Parkland (quemaduras) ---------------- */

    private val parkland = Scale(
        id = "parkland_quemaduras",
        name = "Fórmula de Parkland (reanimación hídrica de quemaduras)",
        population = "ambas",
        purpose = "Calcular la reposición de Ringer lactato en las primeras 24 h post-quemadura (déficit, no mantenimiento).",
        version = "2.0.0",
        effectiveDate = "2026-11-07",
        reviewer = "Pendiente de validación por especialista",
        validationStatus = "VALIDATION_REQUIRED",
        interpretation = "Volumen 24 h = 3-4 ml × kg × %TBSA (quemadura II-III, no incluir eritema). La MITAD en las primeras 8 h desde la quemadura (no desde el ingreso); la otra mitad en las 16 h siguientes. Ajustar por diuresis objetivo: 1 ml/kg/h (niño) · 0,5-1 ml/kg/h (adulto); en quemados eléctricos o inhalatorios 2 ml/kg/h.",
        limitations = "Punto de partida, no objetivo: titular por diuresis, lactato y base. Niños < 20-30 kg AÑADEN mantenimiento basal (Holliday-Segar) + glucosa (hipoglucemia del quemado pequeño). %TBSA con tabla de Lund-Browder pediátrica (regla del 9 sobrestima el tórax y subestima la cabeza en el lactante).",
        references = "Baxter CR, Shires T. Physiological response to crystalloid resuscitation of severe burns. Ann N Y Acad Sci 1968. ISBI Practice Guidelines Committee. ISBI Burn Care Guidelines 2016/2018. Protocolo SECIp de quemados graves.",
        inputs = listOf(
            nm("peso", "Peso (kg)", 1.0, 150.0),
            nm("tbsa", "Superficie quemada II-III (%TBSA)", 1.0, 100.0),
            nm("horas_desde", "Horas transcurridas DESDE la quemadura", 0.0, 24.0),
            ch("ml_factor", "Factor de la fórmula", listOf(
                3 to "3 ml/kg/%TBSA (reanimación conservadora, habitual en pediatría)",
                4 to "4 ml/kg/%TBSA (Parkland clásico)"))
        ),
        compute = { v ->
            val kg = num(v, "peso") ?: return@Scale inc("Introduzca el peso.")
            val tbsa = num(v, "tbsa") ?: return@Scale inc("Introduzca el %TBSA quemado (II-III).")
            val hrs = num(v, "horas_desde") ?: return@Scale inc("Introduzca las horas desde la quemadura.")
            val factor = v["ml_factor"]?.toIntOrNull() ?: return@Scale inc("Seleccione el factor.")
            val total24 = factor * kg * tbsa
            val primeraMitad = total24 / 2.0
            val restante = total24 - primeraMitad
            val tasa8h = if (8 - hrs > 0) primeraMitad / (8 - hrs) else null
            val det = buildString {
                append("Volumen 24 h: ${"%.0f".format(total24)} ml de Ringer lactato")
                append(" · 1ª mitad (${primeraMitad.toInt()} ml): en las primeras 8 h DESDE LA QUEMADURA")
                if (tasa8h != null) append(" → ahora: ${"%.0f".format(tasa8h)} ml/h")
                else append(" → las 8 h iniciales ya pasaron: pasar a la 2ª mitad")
                append(" · 2ª mitad (${restante.toInt()} ml) en 16 h → ${"%.0f".format(restante / 16.0)} ml/h")
            }
            val warnings = mutableListOf<String>()
            if (kg < 20) warnings.add("Niño < 20 kg: AÑADIR mantenimiento basal con glucosa (Holliday-Segar) para evitar hipoglucemia.")
            if (tbsa >= 20) warnings.add("≥ 20 %TBSA: quemado grave → UCI, sonda gástrica, catéter central y monitorización horaria.")
            ScaleResult("VALID", total24.toInt(), "Reanimación hídrica de quemaduras", det, warnings)
        }
    )

    val all: List<Scale> = listOf(prism3, four, kdigo, westley, nips, fisher, pts, parkland)

    fun byId(id: String) = all.firstOrNull { it.id == id }
}
