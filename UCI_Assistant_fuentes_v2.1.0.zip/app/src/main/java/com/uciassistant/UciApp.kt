package com.uciassistant

import android.app.Application
import com.uciassistant.data.db.AppDatabase
import com.uciassistant.data.importer.PackageImporter
import com.uciassistant.data.repo.AcademyRepository
import com.uciassistant.data.repo.ClinicRepository
import com.uciassistant.data.repo.PersonalRepository
import com.uciassistant.search.SearchEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Application raíz. Inyección manual de dependencias (el contrato permite
 * prescindir de Hilt si su coste no lo justifica: sección 2.1).
 */
class UciApp : Application() {

    lateinit var db: AppDatabase
        private set
    lateinit var academy: AcademyRepository
        private set
    lateinit var personal: PersonalRepository
        private set
    lateinit var clinic: ClinicRepository
        private set
    lateinit var search: SearchEngine
        private set
    lateinit var importer: PackageImporter
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        db = AppDatabase.build(this)
        academy = AcademyRepository(db)
        personal = PersonalRepository(db)
        clinic = ClinicRepository()
        search = SearchEngine(db)
        importer = PackageImporter(this, db)
        // Auto-instalación del paquete incluido tan pronto arranca el proceso
        // (v1.2.0): idempotente, también se reintenta desde MainActivity y Paquetes.
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            runCatching { importer.tryAutoInstallIfNeeded() }
        }
    }

    companion object {
        lateinit var instance: UciApp
            private set
    }
}
