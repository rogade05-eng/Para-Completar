package com.uciassistant.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Cabecera estándar con botón de retorno (modo consulta: máx. 2-3 interacciones). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UciTopBar(title: String, subtitle: String? = null, onBack: (() -> Unit)? = null) {
    TopAppBar(
        title = {
            Column {
                Text(title, style = MaterialTheme.typography.titleMedium, maxLines = 2)
                if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall)
            }
        },
        navigationIcon = {
            if (onBack != null) {
                TextButton(onClick = onBack) { Text("←") }
            }
        }
    )
}

@Composable
fun StatusBadge(text: String, color: Color = MaterialTheme.colorScheme.secondary) {
    Box(
        Modifier
            .background(color.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(text, style = MaterialTheme.typography.labelMedium, color = color)
    }
}

@Composable
fun DifficultyBadge(difficulty: String) {
    val (label, color) = when (difficulty) {
        "basic" -> "Básico" to MaterialTheme.colorScheme.primary
        "intermediate" -> "Intermedio" to MaterialTheme.colorScheme.tertiary
        "advanced" -> "Avanzado" to MaterialTheme.colorScheme.error
        else -> difficulty to MaterialTheme.colorScheme.onSurfaceVariant
    }
    StatusBadge(label, color)
}

@Composable
fun PopulationBadge(population: String) {
    val label = when {
        population.contains("pediatric") && population.contains("adult") -> "Pediátrica y adulta"
        population.contains("pediatric") -> "Pediátrica"
        population.contains("neonatal") -> "Neonatal"
        population.contains("adult") -> "Adulta"
        population.trim() == "todas" || population.trim() == "all" -> "Todas las poblaciones"
        else -> population
    }
    StatusBadge(label)
}

@Composable
fun UciCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    if (onClick != null) {
        Card(onClick = onClick, modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
            Column(Modifier.padding(14.dp), content = content)
        }
    } else {
        Card(modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
            Column(Modifier.padding(14.dp), content = content)
        }
    }
}

/** Render de cuerpo académico: respeta saltos de párrafo y viñetas «•» / «-». */
@Composable
fun AcademicBody(body: String) {
    val blocks = body.split("\n")
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        blocks.forEach { line0 ->
            val line = line0.trimEnd()
            when {
                line.isBlank() -> {}
                line.trimStart().startsWith("•") || line.trimStart().startsWith("-") -> {
                    Row(Modifier.padding(start = 6.dp)) {
                        Text("• ", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            line.trimStart().removePrefix("•").removePrefix("-").trim(),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
                line.startsWith("#") -> Text(
                    line.removePrefix("#").trim(),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                else -> Text(line, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

/** Tabla docente con desplazamiento horizontal (sección 4.3 / tablas del paquete). */
@Composable
fun DataTable(headers: List<String>, rows: List<List<String>>, note: String? = null) {
    Card(shape = RoundedCornerShape(10.dp)) {
        Column(Modifier.padding(10.dp)) {
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                Column {
                    Row(Modifier.background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(6.dp))) {
                        headers.forEach { h ->
                            Text(
                                h, Modifier.widthIn(min = 110.dp).padding(8.dp),
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                lineHeight = 15.sp
                            )
                        }
                    }
                    rows.forEachIndexed { i, row ->
                        Row(
                            Modifier.background(
                                if (i % 2 == 0) MaterialTheme.colorScheme.surface
                                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                            )
                        ) {
                            row.forEach { cell ->
                                Text(cell, Modifier.widthIn(min = 110.dp).padding(8.dp),
                                    style = MaterialTheme.typography.bodySmall, lineHeight = 15.sp)
                            }
                        }
                    }
                }
            }
            if (note != null) {
                Spacer(Modifier.height(6.dp))
                Text("Nota: $note", style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun EmptyState(message: String) {
    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(message, style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun DisclaimerFooter() {
    Text(
        "Material educativo y de apoyo. No sustituye el juicio clínico ni los sistemas oficiales de documentación. Los casos clínicos son ficticios. Contenido con estado editorial «pending_review».",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(vertical = 16.dp)
    )
}
