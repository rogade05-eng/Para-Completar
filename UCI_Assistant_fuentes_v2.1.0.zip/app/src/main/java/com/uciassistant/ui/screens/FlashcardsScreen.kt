package com.uciassistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.uciassistant.UciApp
import com.uciassistant.data.db.FlashcardEntity
import com.uciassistant.data.db.FlashcardReviewEntity
import com.uciassistant.domain.Sm2
import com.uciassistant.ui.components.*
import kotlinx.coroutines.launch

/**
 * Tarjetas de memoria con repetición espaciada SM-2 local (secciones 4.7 y 4.8).
 * Cuatro valoraciones: no recordada (1), difícil (3), correcta con esfuerzo (4), fácil (5).
 * Las tarjetas oficiales no son editables; las personales se gestionan en el Espacio personal.
 */
@Composable
fun FlashcardsScreen(nav: NavController, topicId: String) {
    val app = UciApp.instance
    val scope = rememberCoroutineScope()
    var cards by remember { mutableStateOf<List<FlashcardEntity>>(emptyList()) }
    var dueMap by remember { mutableStateOf<Map<String, Long>>(emptyMap()) }
    var lastReview by remember { mutableStateOf<FlashcardReviewEntity?>(null) }
    var idx by remember { mutableIntStateOf(0) }
    var flipped by remember { mutableStateOf(false) }
    var reviewedCount by remember { mutableIntStateOf(0) }
    var title by remember { mutableStateOf("Tarjetas") }

    LaunchedEffect(topicId) {
        val loaded = app.academy.cardsOf(topicId)
        val due = mutableMapOf<String, Long>()
        loaded.forEach { c ->
            app.db.academyDao().lastDueFor(c.id)?.let { due[c.id] = it }
        }
        // Priorizar tarjetas vencidas o nunca repasadas
        cards = loaded.sortedBy { due[it.id] ?: 0L }
        dueMap = due
        title = app.academy.topic(topicId)?.title ?: "Tarjetas"
    }

    fun grade(quality: Int) {
        val card = cards.getOrNull(idx) ?: return
        scope.launch {
            val dao = app.db.academyDao()
            val last = dao.lastReview(card.id)
            val res = Sm2.next(
                quality = quality,
                previousRepetition = last?.repetitionNumber ?: 0,
                previousEasiness = last?.easinessFactor ?: 2.5,
                previousInterval = last?.intervalDays ?: 0
            )
            dao.insertReview(
                FlashcardReviewEntity(
                    flashcardId = card.id,
                    reviewDate = System.currentTimeMillis(),
                    quality = quality,
                    repetitionNumber = res.repetitionNumber,
                    easinessFactor = res.easinessFactor,
                    intervalDays = res.intervalDays,
                    nextReviewDate = res.nextReviewDate
                )
            )
            dueMap = dueMap + (card.id to res.nextReviewDate)
            lastReview = dao.lastReview(card.id)
            reviewedCount++
            idx++
            flipped = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        UciTopBar("Repaso con tarjetas", title, onBack = { nav.popBackStack() })
        if (cards.isEmpty()) {
            EmptyState("Este tema no tiene tarjetas oficiales.")
            return@Column
        }
        if (idx >= cards.size) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Sesión de repaso terminada", style = MaterialTheme.typography.headlineMedium)
                Text("Tarjetas repasadas en esta sesión: $reviewedCount", style = MaterialTheme.typography.bodyLarge)
                Text(
                    "Las próximas fechas de repaso se calculan localmente con SM-2, sin conexión (sección 4.8).",
                    style = MaterialTheme.typography.bodyMedium
                )
                Button(onClick = { idx = 0; reviewedCount = 0; flipped = false }) { Text("Otra pasada") }
            }
            return@Column
        }

        val card = cards[idx]
        val due = dueMap[card.id]
        val dueLabel = when {
            due == null -> "Nunca repasada"
            due <= System.currentTimeMillis() -> "Vencida para repaso"
            else -> "Próximo repaso " + Sm2.humanInterval(((due - System.currentTimeMillis()) / 86_400_000L).toInt())
        }

        LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Text("Tarjeta ${idx + 1} de ${cards.size} · $dueLabel", style = MaterialTheme.typography.labelMedium)
            }
            item {
                ElevatedCard(onClick = { flipped = !flipped }, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("PREGUNTA", style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary)
                        Text(card.question, style = MaterialTheme.typography.titleMedium)
                        if (flipped) {
                            HorizontalDivider()
                            Text("RESPUESTA", style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary)
                            Text(card.answer, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                            if (!card.explanation.isNullOrBlank()) {
                                Text("Explicación adicional: ${card.explanation}",
                                    style = MaterialTheme.typography.bodySmall)
                            }
                            Text(
                                "Dificultad: ${card.difficulty} · " +
                                        if (card.isOfficial) "Tarjeta oficial (no editable)" else "Tarjeta personal",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            Text("Toque la tarjeta para ver la respuesta", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            if (flipped) {
                item {
                    Text("¿Cómo de bien la ha recordado?", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { grade(1) }, modifier = Modifier.weight(1f)) { Text("No recordada") }
                        OutlinedButton(onClick = { grade(3) }, modifier = Modifier.weight(1f)) { Text("Difícil") }
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { grade(4) }, modifier = Modifier.weight(1f)) { Text("Con esfuerzo") }
                        OutlinedButton(onClick = { grade(5) }, modifier = Modifier.weight(1f)) { Text("Fácil") }
                    }
                }
            }
            item {
                lastReview?.let { lr ->
                    if (lr.flashcardId == card.id) {
                        Text(
                            "Último repaso: EF ${"%.2f".format(lr.easinessFactor)} · intervalo ${lr.intervalDays} días · repetición nº ${lr.repetitionNumber}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}
