package com.uciassistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.uciassistant.ui.nav.Routes
import com.uciassistant.UciApp
import com.uciassistant.ui.components.*

/**
 * Calculadora interactiva de una escala clínica.
 * Presenta por separado (contrato 3.3/9.1): datos, validación, resultado,
 * interpretación orientativa, limitaciones y referencias.
 */
@Composable
fun ScaleScreen(nav: NavController, scaleId: String) {
    val scale = UciApp.instance.clinic.scale(scaleId) ?: return
    val values = remember { mutableStateMapOf<String, String>() }
    val result = remember(values.keys, values.values.toList()) { scale.compute(values.toMap()) }

    Column(Modifier.fillMaxSize()) {
        UciTopBar(scale.name, "v${scale.version} · ${scale.effectiveDate}", onBack = { nav.popBackStack() })
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PopulationBadge(scale.population)
            }
            Text("Objetivo clínico", style = MaterialTheme.typography.titleMedium)
            Text(scale.purpose, style = MaterialTheme.typography.bodyMedium)

            Text("Datos introducidos", style = MaterialTheme.typography.titleMedium)
            scale.inputs.forEach { input ->
                when (input.type) {
                    "choice" -> {
                        Text(input.label, style = MaterialTheme.typography.labelMedium)
                        input.options.forEach { (value, label) ->
                            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                RadioButton(
                                    selected = values[input.id] == value.toString(),
                                    onClick = { values[input.id] = value.toString() }
                                )
                                Text(label, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                    "number" -> {
                        OutlinedTextField(
                            value = values[input.id] ?: "",
                            onValueChange = { v -> values[input.id] = v.filter { it.isDigit() || it == '.' || it == ',' }.replace(',', '.') },
                            label = { Text("${input.label}${input.unit?.let { " ($it)" } ?: ""}") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
                Spacer(Modifier.height(4.dp))
            }

            Text("Resultado", style = MaterialTheme.typography.titleMedium)
            when (result.status) {
                "VALID" -> {
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(result.band ?: "", style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            if (result.detail != null) Text(result.detail, style = MaterialTheme.typography.bodyMedium)
                            result.warnings.forEach {
                                Text("⚠ $it", style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.tertiary)
                            }
                            Text("Estado: ${result.status}", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                "INCOMPLETE" -> StatusBadge("Datos incompletos: complete las variables obligatorias", MaterialTheme.colorScheme.tertiary)
                "OUT_OF_RANGE" -> StatusBadge("Valores fuera de rango permitido", MaterialTheme.colorScheme.error)
                else -> StatusBadge(result.status, MaterialTheme.colorScheme.error)
            }

            Text("Interpretación orientativa", style = MaterialTheme.typography.titleMedium)
            Text(scale.interpretation, style = MaterialTheme.typography.bodyMedium)

            Text("Limitaciones y advertencias", style = MaterialTheme.typography.titleMedium)
            Text(scale.limitations, style = MaterialTheme.typography.bodyMedium)

            Text("Referencias", style = MaterialTheme.typography.titleMedium)
            Text(scale.references, style = MaterialTheme.typography.bodySmall)

            Text(
                "Validación: ${scale.validationStatus} · Responsable: ${scale.reviewer}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            DisclaimerFooter()
        }
    }
}
