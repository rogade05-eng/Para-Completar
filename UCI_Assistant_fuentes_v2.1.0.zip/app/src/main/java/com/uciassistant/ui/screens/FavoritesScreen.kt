package com.uciassistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.uciassistant.ui.nav.Routes
import com.uciassistant.UciApp
import com.uciassistant.ui.components.*
import kotlinx.coroutines.launch

/** Espacio personal: favoritos y notas (sección 5 del contrato). */
@Composable
fun FavoritesScreen(nav: NavController) {
    val app = UciApp.instance
    val scope = rememberCoroutineScope()
    val favs by app.personal.favorites().collectAsState(initial = emptyList())
    val notes by app.personal.notes().collectAsState(initial = emptyList())
    var tab by remember { mutableIntStateOf(0) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Favoritos", style = MaterialTheme.typography.headlineMedium)
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Favoritos (${favs.size})") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Notas (${notes.size})") })
        }
        Spacer(Modifier.height(12.dp))
        if (tab == 0) {
            if (favs.isEmpty()) {
                EmptyState("Sin favoritos. Marque temas, casos o escalas con la estrella.")
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(favs) { f ->
                    UciCard(onClick = {
                        when (f.itemType) {
                            "topic" -> nav.navigate(Routes.topic(f.itemId))
                            "case" -> nav.navigate(Routes.case(f.itemId))
                            "scale" -> nav.navigate(Routes.scale(f.itemId))
                        }
                    }) {
                        StatusBadge(f.itemType)
                        Spacer(Modifier.height(4.dp))
                        Text(f.label, style = MaterialTheme.typography.titleMedium)
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        } else {
            if (notes.isEmpty()) {
                EmptyState("Sin notas personales. Cree notas desde cualquier tema con el botón «Notas».")
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(notes) { n ->
                    UciCard {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(n.targetLabel, style = MaterialTheme.typography.titleMedium)
                            TextButton(onClick = { scope.launch { app.personal.deleteNote(n.id) } }) {
                                Text("Eliminar")
                            }
                        }
                        Text(n.body, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }
}
