package com.uciassistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.uciassistant.ui.nav.Routes
import com.uciassistant.UciApp
import com.uciassistant.ui.components.*

/**
 * Sección Clínica (v1.1.0): tres pestañas — Escalas y calculadoras,
 * Procedimientos paso a paso y Perfusiones. Filtro por población.
 */
@Composable
fun ClinicScreen(nav: NavController) {
    val clinic = UciApp.instance.clinic
    var tab by remember { mutableIntStateOf(0) }
    var popFilter by remember { mutableStateOf("todas") }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 16.dp)) {
            Text("Clínica", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Herramientas del día a día: escalas, procedimientos y cálculos. Cada herramienta declara población y estado de validación (contrato 9.1).",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(6.dp))
        }

        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Escalas (${clinic.scales.size})") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Procedimientos (${clinic.procedures.size})") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Calculadoras") })
        }

        if (tab != 2) {
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(selected = popFilter == "todas", onClick = { popFilter = "todas" }, label = { Text("Todas") })
                FilterChip(selected = popFilter == "pediatric", onClick = { popFilter = "pediatric" }, label = { Text("Pediatría") })
                FilterChip(selected = popFilter == "adult", onClick = { popFilter = "adult" }, label = { Text("Adulto") })
                FilterChip(selected = popFilter == "neonatal", onClick = { popFilter = "neonatal" }, label = { Text("Neonatal") })
            }
        }

        when (tab) {
            0 -> LazyColumn(
                Modifier.fillMaxSize().padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val list = clinic.scales.filter {
                    popFilter == "todas" || it.population.contains(popFilter)
                }
                items(list.size) { i ->
                    val s = list[i]
                    UciCard(onClick = { nav.navigate(Routes.scale(s.id)) }) {
                        Text(s.name, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            PopulationBadge(s.population)
                            StatusBadge("Validación: " + s.validationStatus, MaterialTheme.colorScheme.tertiary)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(s.purpose, style = MaterialTheme.typography.bodySmall, maxLines = 3)
                    }
                }
                item { DisclaimerFooter() }
            }

            1 -> LazyColumn(
                Modifier.fillMaxSize().padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val list = clinic.procedures.filter {
                    popFilter == "todas" || it.population.contains(popFilter) || it.population == "ambas"
                }
                items(list.size) { i ->
                    val p = list[i]
                    UciCard(onClick = { nav.navigate(Routes.procedure(p.id)) }) {
                        Text(p.title, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            PopulationBadge(p.population)
                            StatusBadge(p.category, MaterialTheme.colorScheme.secondary)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(p.purpose, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                        Text(
                            "${p.steps.size} pasos · ${p.keyPoints.size} puntos clave",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
                item { DisclaimerFooter() }
            }

            else -> LazyColumn(
                Modifier.fillMaxSize().padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    UciCard(onClick = { nav.navigate(Routes.INFUSIONS) }) {
                        Text("Perfusiones continuas (mcg/kg/min → ml/h)", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Dosis + peso + concentración → ml/h, con verificación del rango habitual de ${clinic.infusionDrugs.size} fármacos de UCI y cálculo inverso (ml/h → dosis).",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(Modifier.height(6.dp))
                        StatusBadge("Adrenalina · Noradrenalina · Dopamina · Dobutamina · Milrinona · Vasopresina · Nitroprusiato · Midazolam · Fentanilo · Morfina · Propofol · Dexmedetomidina", MaterialTheme.colorScheme.secondary)
                        Spacer(Modifier.height(6.dp))
                        Button(onClick = { nav.navigate(Routes.INFUSIONS) }) { Text("Abrir calculadora de perfusiones") }
                    }
                }
                item {
                    UciCard(onClick = { nav.navigate(Routes.NUTRITION) }) {
                        Text("Nutrición parenteral pediátrica", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Calculadora de macronutrientes: líquidos, GIR, aminoácidos, lípidos, calorías y relación CNP:N con avisos de seguridad; tabla por edades, electrólitos y contenido esencial.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(Modifier.height(6.dp))
                        StatusBadge("Ruza · Nelson · Protocolos SECIp", MaterialTheme.colorScheme.tertiary)
                        Spacer(Modifier.height(6.dp))
                        Button(onClick = { nav.navigate(Routes.NUTRITION) }) { Text("Abrir calculadora de NPT") }
                    }
                }
                item {
                    UciCard(onClick = { nav.navigate(Routes.COMA) }) {
                        Text("Fármacos del coma: dosis y presentación", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Escalones de manejo: inicial etiológico (glucosa, naloxona, flumazenilo, manitol…), sedación del coma inducido, bloqueo neuromuscular, estado epiléptico (SECIp-AEP) y antídotos específicos.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(Modifier.height(6.dp))
                        StatusBadge("Ruza · Nelson · SECIp-AEP", MaterialTheme.colorScheme.tertiary)
                        Spacer(Modifier.height(6.dp))
                        Button(onClick = { nav.navigate(Routes.COMA) }) { Text("Abrir escala de fármacos del coma") }
                    }
                }
                val calculadoras = listOf(
                    "dosis_mg_kg" to "Calculadora de dosis (mg/kg → mg y ml)",
                    "fluidos_mantenimiento" to "Fluidos de mantenimiento 4-2-1 (Holliday-Segar)",
                    "vis" to "VIS · Score vasoactivo-inotrópico",
                    "schwartz" to "Clearance pediátrico de creatinina (Schwartz)",
                    "clearance_creatinina" to "Cockcroft-Gault (adulto)",
                    "imc" to "Índice de masa corporal (IMC)",
                    "sc_mosteller" to "Superficie corporal (Mosteller)",
                    "energia_schofield" to "Calorías estimadas (Schofield)",
                    "qtc_bazett" to "QT corregido (Bazett / Fridericia)",
                    "winter" to "Fórmula de Winter (compensación acidosis)",
                    "anion_gap" to "Anión gap (brecha aniónica)",
                    "gap_osmolar" to "Brecha osmolar (gap osmolar)",
                    "ca_corregido" to "Calcio corregido por albúmina",
                    "sodio_corregido" to "Sodio corregido por hiperglucemia",
                    "deficit_sodio" to "Déficit de sodio y corrección segura",
                    "glucosa_unidades" to "Conversión de glucosa (mg/dL ↔ mmol/L)",
                    "driving_pressure" to "Presión de driving (Pplato − PEEP)",
                    "rsbi" to "RSBI (FB/Vt) para el destete",
                    "compliancia" to "Compliance del sistema respiratorio",
                    "ind_oxigenacion" to "Índice de oxigenación (OI) pediátrico",
                    "pao2_fio2" to "Relación PaO₂/FiO₂",
                    "gradiente_aa" to "Gradiente alvéolo-arterial (A-a)",
                    "diuresis" to "Diuresis horaria (ml/kg/h)",
                    "balance_hidrico" to "Balance hídrico de 24 h",
                    "peso_estimado" to "Peso estimado por edad (APLS)",
                    "pa_minima_pediatrica" to "PA mínima esperada (pediátrica)",
                    "ett_pediatrico" to "Tubo endotraqueal pediátrico",
                    "fc_fr_normales" to "FC y FR normales por edad",
                    "fen_a" to "FENa · Fracción de excreción de sodio",
                    "sbt" to "Test de respiración espontánea (SBT) para extubar",
                    "pelod2" to "PELOD-2 · Disfunción orgánica pediátrica",
                    "phoenix" to "Phoenix · Criterios de sepsis pediátrica 2024",
                    "cpot" to "CPOT · Dolor en el paciente no comunicativo",
                    "wat1" to "WAT-1 · Abstinencia a sedantes (pediátrico)",
                    "nutricion_parenteral" to "Nutrición parenteral (NPT): kcal, GIR y osmolaridad",
                    "gir_glucosa" to "GIR · Velocidad de infusión de glucosa"
                )
                items(calculadoras.size) { i ->
                    val (id, titulo) = calculadoras[i]
                    val s = clinic.scale(id)
                    UciCard(onClick = { nav.navigate(Routes.scale(id)) }) {
                        Text(titulo, style = MaterialTheme.typography.titleMedium)
                        if (s != null) {
                            Spacer(Modifier.height(4.dp))
                            PopulationBadge(s.population)
                            Spacer(Modifier.height(4.dp))
                            Text(s.purpose, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                        }
                    }
                }
                item { DisclaimerFooter() }
            }
        }
    }
}
