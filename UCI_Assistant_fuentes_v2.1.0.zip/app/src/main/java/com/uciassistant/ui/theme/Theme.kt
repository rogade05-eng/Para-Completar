package com.uciassistant.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** Paleta MC-1 «Medical Blue» coherente con la documentación del paquete. */
val UciBlue = Color(0xFF0E5FA8)
val UciBlueDark = Color(0xFF083D6E)
val UciBlueLight = Color(0xFF5A93C9)
val UciCyan = Color(0xFF14A0A0)
val UciAmber = Color(0xFFB26A00)
val UciRed = Color(0xFFB3261E)
val UciGreen = Color(0xFF1E7B45)
val UciSurfaceWarm = Color(0xFFF6F8FB)

private val LightColors = lightColorScheme(
    primary = UciBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD4E3F7),
    onPrimaryContainer = UciBlueDark,
    secondary = UciCyan,
    secondaryContainer = Color(0xFFCDEDED),
    onSecondaryContainer = Color(0xFF003C3C),
    tertiary = UciAmber,
    background = UciSurfaceWarm,
    onBackground = Color(0xFF16202B),
    surface = Color.White,
    onSurface = Color(0xFF16202B),
    surfaceVariant = Color(0xFFE8EDF4),
    onSurfaceVariant = Color(0xFF43505E),
    error = UciRed
)

private val DarkColors = darkColorScheme(
    primary = UciBlueLight,
    onPrimary = Color(0xFF002F5A),
    primaryContainer = UciBlueDark,
    onPrimaryContainer = Color(0xFFD4E3F7),
    secondary = Color(0xFF6BC4C4),
    secondaryContainer = Color(0xFF0F4A4A),
    onSecondaryContainer = Color(0xFFCDEDED),
    tertiary = Color(0xFFF0B25C),
    background = Color(0xFF0F141B),
    onBackground = Color(0xFFE2E8F0),
    surface = Color(0xFF161C25),
    onSurface = Color(0xFFE2E8F0),
    surfaceVariant = Color(0xFF222B37),
    onSurfaceVariant = Color(0xFFB3BECC),
    error = Color(0xFFF2B8B5)
)

private val UciTypography = Typography(
    headlineMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 26.sp, lineHeight = 32.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 20.sp, lineHeight = 26.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 21.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 17.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
)

/** Modo claro/oscuro (requisito 10.3): «sistema» por defecto, configurable en Perfil. */
@Composable
fun UciTheme(darkThemeOverride: Boolean? = null, content: @Composable () -> Unit) {
    val dark = darkThemeOverride ?: isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = UciTypography,
        content = content
    )
}
