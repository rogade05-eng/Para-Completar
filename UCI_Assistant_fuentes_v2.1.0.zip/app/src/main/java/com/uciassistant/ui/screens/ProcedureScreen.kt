package com.uciassistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.uciassistant.UciApp
import com.uciassistant.ui.components.*

/** Lector de un procedimiento paso a paso (v1.1.0). */
@Composable
fun ProcedureScreen(nav: NavController, procedureId: String) {
    val proc = UciApp.instance.clinic.procedure(procedureId) ?: return

    Column(Modifier.fillMaxSize()) {
        UciTopBar(proc.title, "Procedimiento · v1.1.0", onBack = { nav.popBackStack() })
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PopulationBadge(proc.population)
                StatusBadge("Validación pendiente", MaterialTheme.colorScheme.tertiary)
            }
            Text(proc.purpose, style = MaterialTheme.typography.bodyMedium)

            Section("Indicaciones", proc.indications)
            Section("Contraindicaciones y precauciones", proc.contraindications)
            Section("Material", proc.materials)

            Text("Pasos", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                proc.steps.forEachIndexed { i, step ->
                    Row {
                        Text(
                            "${i + 1}. ",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(step, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            Section("Alarmas · cuándo parar", proc.alarms)
            Section("Puntos clave", proc.keyPoints)

            Text("Referencias", style = MaterialTheme.typography.titleMedium)
            Text(proc.references, style = MaterialTheme.typography.bodySmall)

            Text(
                "Guía educativa de bolsillo: prevalecen los protocolos y checklists de la institución y la supervisión del responsable.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            DisclaimerFooter()
        }
    }
}

@Composable
private fun Section(title: String, items: List<String>) {
    Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        items.forEach {
            Row(Modifier.padding(start = 6.dp)) {
                Text("• ", style = MaterialTheme.typography.bodyMedium)
                Text(it, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
