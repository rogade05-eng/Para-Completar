package com.uciassistant.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.uciassistant.UciApp
import com.uciassistant.data.importer.PackageImporter
import com.uciassistant.ui.components.*
import kotlinx.coroutines.launch

/**
 * Gestión de paquetes académicos (sección 8 del contrato): vista previa de la
 * validación (pasos 1-7), confirmación explícita (9) e instalación en transacción
 * SQLite (10). v1.1.0: instalación del paquete incluido en un paso e
 * importación de paquetes .zip desde el almacenamiento del dispositivo (SAF).
 * Una actualización no sobrescribe notas, favoritos ni progreso.
 */
@Composable
fun PackagesScreen(nav: NavController) {
    val app = UciApp.instance
    val scope = rememberCoroutineScope()
    val installed by app.personal.packages().collectAsState(initial = emptyList())
    var preview by remember { mutableStateOf<PackageImporter.Preview?>(null) }
    var importedDir by remember { mutableStateOf<java.io.File?>(null) }
    var busy by remember { mutableStateOf(false) }
    var resultMsg by remember { mutableStateOf<String?>(null) }

    // Selector de archivos del dispositivo (SAF)
    val zipPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            busy = true
            resultMsg = null
            scope.launch {
                try {
                    val dir = app.importer.extractZipToCache(uri)
                    importedDir = dir
                    preview = app.importer.validateImportedDir(dir)
                } catch (e: Exception) {
                    preview = null
                    importedDir = null
                    resultMsg = "No se pudo leer el archivo como paquete .zip: ${e.message}"
                }
                busy = false
            }
        }
    }

    fun instalar(pv: PackageImporter.Preview, dir: java.io.File?) {
        busy = true
        resultMsg = null
        scope.launch {
            try {
                val ok = if (dir != null) app.importer.installImportedDir(dir, pv)
                else app.importer.install(pv)
                resultMsg = if (ok)
                    "Paquete ${pv.manifest.packageId} v${pv.manifest.packageVersion} instalado correctamente (transacción única). Sus notas, favoritos y progreso se conservan."
                else "La instalación falló: revise los errores de validación."
            } catch (e: Exception) {
                resultMsg = "Error durante la instalación: ${e.message}"
            }
            busy = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        UciTopBar("Paquetes académicos", "ACADEMY_PACKAGE · sección 8 del contrato", onBack = { nav.popBackStack() })
        LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {

            app.importer.lastAutoInstallIssue?.let { issue ->
                item {
                    UciCard {
                        Text("Aviso de la instalación automática inicial", style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.error)
                        Text(issue, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            item {
                UciCard {
                    Text("Paquete incluido en la aplicación", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "uci_academy_fundamentos_pediatria v1.2.0 — 5 áreas de Medicina Intensiva pediátrica: 25 temas de 15 apartados, 95 preguntas con explicación, 77 tarjetas SM-2, 2 casos clínicos simulados progresivos y 29 referencias (incluye infecciones, ética, bronquiolitis, asma, HFOV/ECMO, shock cardiogénico, arritmias, TCE, neuromusculares e intoxicaciones).",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                busy = true
                                resultMsg = null
                                scope.launch {
                                    try {
                                        val pv = app.importer.validateFromAssets()
                                        preview = pv
                                        importedDir = null
                                        if (pv.valid) instalar(pv, null) else busy = false
                                    } catch (e: Exception) {
                                        resultMsg = "Error al validar el paquete incluido: ${e.message}"
                                        busy = false
                                    }
                                }
                            },
                            enabled = !busy
                        ) { Text(if (busy) "Instalando…" else "Validar e instalar (1 paso)") }
                        OutlinedButton(
                            onClick = {
                                busy = true
                                resultMsg = null
                                scope.launch {
                                    try {
                                        preview = app.importer.validateFromAssets()
                                        importedDir = null
                                    } catch (e: Exception) {
                                        resultMsg = "Error al validar: ${e.message}"
                                    }
                                    busy = false
                                }
                            },
                            enabled = !busy
                        ) { Text("Solo vista previa") }
                    }
                }
            }

            item {
                UciCard {
                    Text("Importar paquete desde el dispositivo", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Elija un archivo .zip de paquete académico (estructura academy/ con manifest.json). Se valida antes de instalar.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { zipPicker.launch(arrayOf("application/zip", "application/octet-stream", "application/x-zip-compressed")) },
                        enabled = !busy
                    ) { Text("Elegir archivo .zip…") }
                }
            }

            preview?.let { pv ->
                item {
                    UciCard {
                        Text("Vista previa de validación", style = MaterialTheme.typography.titleMedium)
                        Text("Paquete: ${pv.manifest.packageId} v${pv.manifest.packageVersion}", style = MaterialTheme.typography.bodyMedium)
                        Text("Idioma: ${pv.manifest.language} · Poblaciones: ${pv.manifest.populations.joinToString()}", style = MaterialTheme.typography.bodySmall)
                        Text("Tipo: ${pv.manifest.contentType} · Estado editorial: ${pv.manifest.reviewStatus}", style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(8.dp))
                        pv.counts.forEach { (k, v) -> Text("• $k: $v", style = MaterialTheme.typography.bodySmall) }
                        Spacer(Modifier.height(8.dp))
                        pv.issues.forEach { iss ->
                            val color = if (iss.severity == "error") MaterialTheme.colorScheme.error
                            else MaterialTheme.colorScheme.tertiary
                            Text("〔${iss.severity}〕 ${iss.message}", style = MaterialTheme.typography.bodySmall, color = color)
                        }
                        if (pv.issues.isEmpty()) {
                            Text("Validación sin incidencias.", style = MaterialTheme.typography.bodySmall,
                                color = com.uciassistant.ui.theme.UciGreen)
                        }
                        Spacer(Modifier.height(8.dp))
                        if (pv.valid) {
                            Button(
                                onClick = { instalar(pv, importedDir) },
                                enabled = !busy
                            ) { Text(if (busy) "Instalando…" else "Confirmar e instalar") }
                        } else {
                            Text("Corrija los errores antes de instalar.", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }

            resultMsg?.let { msg ->
                item {
                    Text(msg, style = MaterialTheme.typography.bodyMedium,
                        color = if (msg.startsWith("Paquete") && msg.contains("instalado correctamente"))
                            com.uciassistant.ui.theme.UciGreen else MaterialTheme.colorScheme.error)
                }
            }

            item {
                Text("Paquetes instalados", style = MaterialTheme.typography.titleMedium)
            }
            if (installed.isEmpty()) {
                item { EmptyState("Todavía no hay paquetes instalados.") }
            }
            items(installed.size) { i ->
                val p = installed[i]
                UciCard {
                    Text(p.title, style = MaterialTheme.typography.titleMedium)
                    Text("${p.packageId} v${p.packageVersion} · ${p.contentType} · estado editorial: ${p.reviewStatus}",
                        style = MaterialTheme.typography.bodySmall)
                    Text(java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault())
                        .format(java.util.Date(p.installedAt)) + " · contenido oficial: sus notas, favoritos y progreso se conservan siempre.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}
