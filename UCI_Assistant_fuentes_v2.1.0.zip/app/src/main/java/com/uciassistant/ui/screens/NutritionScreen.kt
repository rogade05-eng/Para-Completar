package com.uciassistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.uciassistant.clinical.Nutrition
import com.uciassistant.ui.components.*

/**
 * Nutrición parenteral pediátrica (v1.5.0): calculadora de macronutrientes,
 * GIR y calorías con avisos de seguridad, tabla por edades, electrólitos y
 * contenido docente. Bibliografía: Ruza, Nelson, protocolos SECIp.
 */
@Composable
fun NutritionScreen(nav: NavController) {
    var groupIdx by remember { mutableIntStateOf(1) } // lactante por defecto
    var peso by remember { mutableStateOf("") }
    val g0 = Nutrition.groups[groupIdx]
    var fluidos by remember(groupIdx) { mutableStateOf(trimN(g0.fluidMlKg)) }
    var glucosa by remember(groupIdx) { mutableStateOf("10") }
    var aa by remember(groupIdx) { mutableStateOf(if (groupIdx == 0) "2,5" else "2") }
    var lipidos by remember(groupIdx) { mutableStateOf("2") }
    var horas by remember { mutableStateOf("24") }

    val pesoVal = peso.replace(',', '.').toDoubleOrNull()
    val input = Nutrition.Input(
        weightKg = pesoVal ?: 0.0,
        groupId = g0.id,
        fluidMlKgDay = fluidos.replace(',', '.').toDoubleOrNull() ?: 0.0,
        glucosePercent = glucosa.replace(',', '.').toDoubleOrNull() ?: 0.0,
        aaGKgDay = aa.replace(',', '.').toDoubleOrNull() ?: 0.0,
        lipidGKgDay = lipidos.replace(',', '.').toDoubleOrNull() ?: 0.0,
        infusionHours = horas.replace(',', '.').toDoubleOrNull() ?: 24.0
    )
    val r = if (pesoVal != null && pesoVal > 0) Nutrition.calculate(input) else null

    Column(Modifier.fillMaxSize()) {
        UciTopBar("Nutrición parenteral pediátrica", "Calculadora + contenido · v1.5.0", onBack = { nav.popBackStack() })
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Grupo de edad", style = MaterialTheme.typography.titleMedium)
            Column {
                Nutrition.groups.forEachIndexed { i, grp ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = groupIdx == i, onClick = { groupIdx = i })
                        Text(grp.label, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            Text("Datos", style = MaterialTheme.typography.titleMedium)
            numField("Peso (kg)", peso, { peso = it })
            numField("Líquidos totales (ml/kg/día)", fluidos, { fluidos = it })
            numField("Glucosa final (%)", glucosa, { glucosa = it })
            numField("Aminoácidos (g/kg/día)", aa, { aa = it })
            numField("Lípidos 20 % (g/kg/día)", lipidos, { lipidos = it })
            numField("Horas de infusión", horas, { horas = it })

            if (r != null) {
                Text("Resultados", style = MaterialTheme.typography.titleMedium)
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        res("Volumen total", "${fmtN(r.totalMlDay)} ml/día")
                        res("Velocidad de bomba", "${fmtN(r.rateMlH)} ml/h (${trimN(input.infusionHours)} h)")
                        res("GIR", "${fmtN(r.gir)} mg/kg/min")
                        res("Glucosa", "${fmtN(r.glucoseGramsDay)} g/día (${fmtN(r.pctGlucosa)} % de kcal)")
                        res("Aminoácidos", "${fmtN(r.aaGramsDay)} g/día (${fmtN(r.pctAa)} % de kcal)")
                        res("Lípidos 20 %", "${fmtN(r.lipidGramsDay)} g/día = ${fmtN(r.lipidMlDay)} ml/día (${fmtN(r.pctLipidos)} % de kcal)")
                        res("Calorías totales", "${fmtN(r.kcalTotal)} kcal/día = ${fmtN(r.kcalKgDay)} kcal/kg/día")
                        res("Calorías no proteicas (CNP)", "${fmtN(r.kcalNonProtein)} kcal/día")
                        res("Relación CNP:N", "${fmtN(r.npcrRatio)}:1 (objetivo 150–300:1)")
                    }
                }

                if (r.warnings.isNotEmpty()) {
                    Text("Avisos de seguridad", style = MaterialTheme.typography.titleMedium)
                    r.warnings.forEach { w ->
                        UciCard {
                            Text("⚠ $w", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            } else {
                StatusBadge("Introduzca el peso para calcular", MaterialTheme.colorScheme.tertiary)
            }

            Text("Referencia por edad (Ruza · Nelson · SECIp)", style = MaterialTheme.typography.titleMedium)
            DataTable(
                headers = Nutrition.ageTable.first(),
                rows = Nutrition.ageTable.drop(1)
            )

            Text("Electrólitos, oligoelementos y vitaminas (por día)", style = MaterialTheme.typography.titleMedium)
            DataTable(
                headers = listOf("Componente", "Aporte habitual", "Notas"),
                rows = Nutrition.electrolytes
            )

            Text("Contenido esencial", style = MaterialTheme.typography.titleMedium)
            Nutrition.education.forEach { (t, body) ->
                UciCard {
                    Text(t, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(4.dp))
                    Text(body, style = MaterialTheme.typography.bodySmall)
                }
            }

            Text(
                "Bibliografía: Ruza F. Tratado de Cuidados Intensivos Pediátricos · Nelson Textbook of Pediatrics · Protocolos SECIp de nutrición artificial pediátrica. Valores orientativos: ajuste SIEMPRE al paciente, al protocolo de la unidad y a la supervisión del especialista.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.tertiary
            )
            DisclaimerFooter()
        }
    }
}

@Composable
private fun numField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter { c -> c.isDigit() || c == '.' || c == ',' }) },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun res(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
    }
}

private fun fmtN(v: Double): String =
    if (kotlin.math.abs(v) >= 100) "%.0f".format(v)
    else if (kotlin.math.abs(v) >= 10) "%.1f".format(v)
    else "%.2f".format(v)

private fun trimN(v: Double): String =
    "%.1f".format(v).trimEnd('0').trimEnd('.')
