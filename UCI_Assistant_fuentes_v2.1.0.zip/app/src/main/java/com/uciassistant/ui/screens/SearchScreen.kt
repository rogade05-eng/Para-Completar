package com.uciassistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.uciassistant.ui.nav.Routes
import com.uciassistant.UciApp
import com.uciassistant.clinical.ClinicalScales
import com.uciassistant.search.SearchEngine
import com.uciassistant.ui.components.*
import kotlinx.coroutines.launch

/** Buscador general único (sección 3.6): herramientas, temas, preguntas, casos y referencias. */
@Composable
fun SearchScreen(nav: NavController, initialQuery: String) {
    val app = UciApp.instance
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf(initialQuery) }
    var hits by remember { mutableStateOf<List<SearchEngine.Hit>>(emptyList()) }
    var searched by remember { mutableStateOf(false) }
    var recents by remember { mutableStateOf<List<String>>(emptyList()) }

    LaunchedEffect(Unit) { recents = app.personal.recentSearches() }

    fun runSearch(q: String) {
        query = q
        if (q.length < 2) { hits = emptyList(); return }
        scope.launch {
            hits = app.search.search(q)
            app.personal.recordSearch(q)
            searched = true
        }
    }

    Column(Modifier.fillMaxSize()) {
        UciTopBar("Buscador clínico general", "Herramientas · Academia · Casos · Referencias", onBack = { nav.popBackStack() })
        Column(Modifier.padding(16.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it; runSearch(it) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Ej.: shock séptico, noradrenalina, Glasgow…") },
                singleLine = true
            )
            if (recents.isNotEmpty() && query.length < 2) {
                Spacer(Modifier.height(10.dp))
                Text("Búsquedas recientes", style = MaterialTheme.typography.labelMedium)
                Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    recents.take(4).forEach { r ->
                        AssistChip(onClick = { runSearch(r) }, label = { Text(r) })
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(hits) { h ->
                UciCard(onClick = {
                    when {
                        h.route.startsWith("topic/") && h.route.contains("?question=") -> {
                            val topicId = h.route.removePrefix("topic/").substringBefore("?")
                            nav.navigate(Routes.topic(topicId))
                        }
                        h.route == "bibliografia" -> nav.navigate("bibliografia")
                        else -> nav.navigate(h.route)
                    }
                }) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatusBadge(h.type)
                        Text(h.title, style = MaterialTheme.typography.titleMedium)
                    }
                    if (h.snippet.isNotBlank()) {
                        Spacer(Modifier.height(4.dp))
                        Text(h.snippet, style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 3)
                    }
                }
            }
            item {
                if (searched && hits.isEmpty()) {
                    EmptyState("Sin resultados locales para «$query». La búsqueda funciona sin conexión sobre la biblioteca instalada.")
                }
                // Escalas clínicas y procedimientos integrados que coinciden con el texto
                val ql = query.lowercase()
                if (ql.length >= 2) {
                    val matched = ClinicalScales.all.filter {
                        ql in it.name.lowercase() || ql in it.purpose.lowercase()
                    }
                    val matchedProcs = com.uciassistant.clinical.Procedures.all.filter {
                        ql in it.title.lowercase() || ql in it.purpose.lowercase()
                    }
                    if (matched.isNotEmpty() || matchedProcs.isNotEmpty()) {
                        Text("Herramientas clínicas", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        matched.forEach { s ->
                            UciCard(onClick = { nav.navigate(Routes.scale(s.id)) }) {
                                StatusBadge("Herramienta", MaterialTheme.colorScheme.tertiary)
                                Text(s.name, style = MaterialTheme.typography.titleMedium)
                                Text(s.populationBadgeText(), style = MaterialTheme.typography.bodySmall)
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                        matchedProcs.forEach { p ->
                            UciCard(onClick = { nav.navigate(Routes.procedure(p.id)) }) {
                                StatusBadge("Procedimiento", MaterialTheme.colorScheme.tertiary)
                                Text(p.title, style = MaterialTheme.typography.titleMedium)
                                Text(p.purpose, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

private fun com.uciassistant.clinical.Scale.populationBadgeText() = "Población: " + when {
    population.contains("pediatric") && population.contains("adult") -> "pediátrica y adulta"
    population.contains("pediatric") -> "pediátrica"
    population.contains("neonatal") -> "neonatal"
    else -> population
}
