package com.uciassistant.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.uciassistant.ui.nav.Routes
import com.uciassistant.UciApp
import com.uciassistant.data.db.AcademicContentEntity
import com.uciassistant.data.db.TopicTableEntity
import com.uciassistant.ui.components.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

/**
 * Lector de temas (sección 4.3): los apartados estructurados, las tablas docentes,
 * las actividades del tema (preguntas, tarjetas), el progreso real, favoritos y notas.
 */
@Composable
fun TopicReaderScreen(nav: NavController, topicId: String) {
    val app = UciApp.instance
    val scope = rememberCoroutineScope()
    var contents by remember { mutableStateOf<List<AcademicContentEntity>>(emptyList()) }
    var tables by remember { mutableStateOf<List<TopicTableEntity>>(emptyList()) }
    var title by remember { mutableStateOf("") }
    var summary by remember { mutableStateOf("") }
    var meta by remember { mutableStateOf("") }
    var isFav by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    var showNoteEditor by remember { mutableStateOf(false) }
    var percent by remember { mutableDoubleStateOf(0.0) }
    var questionCount by remember { mutableIntStateOf(0) }
    var cardCount by remember { mutableIntStateOf(0) }
    var cases by remember { mutableStateOf<List<com.uciassistant.data.db.ClinicalCaseEntity>>(emptyList()) }

    LaunchedEffect(topicId) {
        val t = app.academy.topic(topicId) ?: return@LaunchedEffect
        title = t.title
        summary = t.summary
        meta = "Población: ${t.population} · Dificultad: ${t.difficulty} · ≈ ${t.estimatedMinutes} min · v${t.version} · estado ${t.status}"
        contents = app.academy.contentsOf(topicId)
        tables = app.academy.tablesOf(topicId)
        questionCount = app.academy.questionsOf(topicId).size
        cardCount = app.academy.cardsOf(topicId).size
        isFav = app.personal.isFavorite("topic", topicId)
        app.academy.progressAll().first().firstOrNull { it.topicId == topicId }?.let { percent = it.completionPercent }
        cases = app.academy.cases().first().filter { it.population.contains("pediatric") }
        note = app.personal.noteFor("topic", topicId)?.body ?: ""
        app.academy.recordStudySession(topicId, 60) // registro mínimo de sesión real
    }

    fun markRead(c: AcademicContentEntity) {
        scope.launch {
            app.academy.markSectionRead(topicId, c.id, contents.size)
            percent = app.academy.progressAll().first().firstOrNull { it.topicId == topicId }?.completionPercent ?: 0.0
        }
    }

    Column(Modifier.fillMaxSize()) {
        UciTopBar(title, summary, onBack = { nav.popBackStack() })
        LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Text(meta, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { (percent / 100.0).toFloat() },
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Progreso de lectura: ${percent.toInt()} %", style = MaterialTheme.typography.bodySmall)
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { nav.navigate(Routes.quiz(topicId)) },
                        enabled = questionCount > 0) { Text("Preguntas ($questionCount)") }
                    Button(onClick = { nav.navigate(Routes.cards(topicId)) },
                        enabled = cardCount > 0) { Text("Tarjetas ($cardCount)") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        scope.launch {
                            app.personal.toggleFavorite("topic", topicId, title)
                            isFav = app.personal.isFavorite("topic", topicId)
                        }
                    }) { Text(if (isFav) "★ Quitar de favoritos" else "☆ Añadir a favoritos") }
                    OutlinedButton(onClick = { showNoteEditor = !showNoteEditor }) { Text("Notas") }
                }
                if (showNoteEditor) {
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("Nota personal asociada a este tema") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            scope.launch { app.personal.saveNote("topic", topicId, title, note) }
                        }) { Text("Guardar nota") }
                        if (note.isNotEmpty()) {
                            OutlinedButton(onClick = { note = "" }) { Text("Vaciar") }
                        }
                    }
                }
            }
            items(contents) { c ->
                UciCard {
                    Text(c.title, style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(6.dp))
                    if (c.sectionType == "figure") {
                        // Diagrama de apoyo incrustado en assets/academy/media (v2.1.0)
                        FigureImage(c.body)
                        Spacer(Modifier.height(8.dp))
                    } else {
                        AcademicBody(c.body)
                    }
                    Spacer(Modifier.height(8.dp))
                    // Tabla docente asociada a este apartado
                    tables.filter { it.relatedSection == c.sectionType }.forEach { tb ->
                        DataTable(
                            headers = app.academy.headersOf(tb),
                            rows = app.academy.rowsOf(tb),
                            note = tb.note
                        )
                        Spacer(Modifier.height(8.dp))
                    }
                    OutlinedButton(onClick = { markRead(c) }) { Text("Marcar apartado como leído") }
                }
            }
            item {
                HorizontalDivider()
                TextButton(onClick = {
                    scope.launch { app.academy.markTopicCompleted(topicId) }
                }) { Text("Marcar tema como completado") }
                TextButton(onClick = { nav.navigate("bibliografia") }) { Text("Ver bibliografía del paquete") }
                DisclaimerFooter()
            }
        }
    }
}

/**
 * Apartado tipo "figure": carga el diagrama PNG desde assets/academy/media
 * (paquete académico v2.1.0) y lo muestra a ancho completo.
 */
@Composable
fun FigureImage(fileName: String) {
    val app = UciApp.instance
    var bitmap by remember(fileName) { mutableStateOf<Bitmap?>(null) }
    var failed by remember(fileName) { mutableStateOf(false) }
    LaunchedEffect(fileName) {
        withContext(Dispatchers.IO) {
            runCatching {
                app.assets.open("academy/media/$fileName").use {
                    BitmapFactory.decodeStream(it)
                }
            }.onSuccess { bitmap = it }
                .onFailure { failed = true }
        }
    }
    val bmp = bitmap
    when {
        bmp != null -> Image(
            bitmap = bmp.asImageBitmap(),
            contentDescription = fileName,
            modifier = Modifier.fillMaxWidth(),
            contentScale = ContentScale.FillWidth
        )
        failed -> Text(
            "[Diagrama no disponible: $fileName]",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.error
        )
        else -> LinearProgressIndicator(Modifier.fillMaxWidth())
    }
}
