package com.uciassistant.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.uciassistant.clinical.ComaDrugs
import com.uciassistant.ui.components.*

/**
 * Escala de fármacos del coma (v1.5.0): manejo inicial etiológico, sedación
 * del coma inducido, bloqueo neuromuscular, estado epiléptico y tratamientos
 * específicos — con dosis y presentación de cada fármaco.
 * Bibliografía: Ruza, Nelson, protocolos SECIp / SECIp-AEP.
 */
@Composable
fun ComaScreen(nav: NavController) {
    // Primera sección abierta por defecto
    var open by remember { mutableStateOf(setOf(ComaDrugs.sections.first().id)) }

    Column(Modifier.fillMaxSize()) {
        UciTopBar("Fármacos del coma", "Dosis y presentación por escalones · v1.5.0", onBack = { nav.popBackStack() })
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            UciCard {
                Text("Punto de partida", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(4.dp))
                Text(ComaDrugs.intro, style = MaterialTheme.typography.bodySmall)
            }

            ComaDrugs.sections.forEach { sec ->
                val isOpen = sec.id in open
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    open = if (isOpen) open - sec.id else open + sec.id
                                },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                sec.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.weight(1f)
                            )
                            Text(if (isOpen) "▲" else "▼", color = MaterialTheme.colorScheme.primary)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(sec.intro, style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)

                        AnimatedVisibility(visible = isOpen) {
                            Column(
                                Modifier.padding(top = 10.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                sec.drugs.forEach { d ->
                                    Card(shape = MaterialTheme.shapes.medium) {
                                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text(d.name, fontWeight = FontWeight.SemiBold)
                                            Text("Presentación: ${d.presentation}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Text("Dosis: ${d.dose}", style = MaterialTheme.typography.bodyMedium)
                                            Text("Preparación: ${d.prep}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Text(
                ComaDrugs.references,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.tertiary
            )
            Text(
                "Dosis orientativas de apoyo docente: verificar SIEMPRE con el protocolo de la unidad, peso/edad del paciente y doble comprobación de enfermería.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            DisclaimerFooter()
        }
    }
}
