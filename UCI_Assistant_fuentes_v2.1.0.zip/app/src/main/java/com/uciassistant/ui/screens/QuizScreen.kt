package com.uciassistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.uciassistant.UciApp
import com.uciassistant.data.db.QuizQuestionEntity
import com.uciassistant.ui.components.*
import kotlinx.coroutines.launch
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json

private val qjson = Json { ignoreUnknownKeys = true }

/**
 * Evaluación del tema (sección 4.5): respuesta validada, explicación razonada,
 * referencia bibliográfica, tema asociado y recomendación de repaso.
 * v1.1.0: soporta además preguntas de relación de conceptos (matching).
 */
@Composable
fun QuizScreen(nav: NavController, topicId: String) {
    val app = UciApp.instance
    val scope = rememberCoroutineScope()
    var questions by remember { mutableStateOf<List<QuizQuestionEntity>>(emptyList()) }
    var idx by remember { mutableIntStateOf(0) }
    var selection by remember { mutableStateOf<Set<String>>(emptySet()) }
    var pairSelection by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var checked by remember { mutableStateOf(false) }
    var correctCount by remember { mutableIntStateOf(0) }
    var finished by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("Preguntas") }
    var refsLoaded by remember { mutableStateOf<List<com.uciassistant.data.db.ReferenceEntity>>(emptyList()) }

    LaunchedEffect(topicId) {
        questions = app.academy.questionsOf(topicId)
        title = app.academy.topic(topicId)?.title ?: "Preguntas"
    }

    LaunchedEffect(idx, questions.size) {
        val qq = questions.getOrNull(idx)
        if (qq != null) {
            val ids = qjson.decodeFromString(ListSerializer(String.serializer()), qq.referencesJson)
            refsLoaded = if (ids.isEmpty()) emptyList() else app.academy.referencesByIds(ids)
        }
    }

    Column(Modifier.fillMaxSize()) {
        UciTopBar("Preguntas de comprobación", title, onBack = { nav.popBackStack() })
        if (questions.isEmpty()) {
            EmptyState("No hay preguntas disponibles para este tema.")
            return@Column
        }
        if (finished) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Evaluación terminada", style = MaterialTheme.typography.headlineMedium)
                Text(
                    "Aciertos: $correctCount de ${questions.size} (${if (questions.isEmpty()) 0 else correctCount * 100 / questions.size} %)",
                    style = MaterialTheme.typography.titleLarge
                )
                Text(
                    "Las respuestas quedan registradas para el seguimiento del aprendizaje (sección 4.10).",
                    style = MaterialTheme.typography.bodyMedium
                )
                Button(onClick = {
                    idx = 0; selection = emptySet(); pairSelection = emptyMap(); checked = false
                    correctCount = 0; finished = false
                }) { Text("Repetir evaluación") }
            }
            return@Column
        }

        val q = questions[idx]
        val options = qjson.decodeFromString(
            ListSerializer(com.uciassistant.data.importer.PackageImporter.Option.serializer()), q.optionsJson)
        val correctIds = app.academy.correctOf(q)
        val correctPairs = app.academy.correctPairsOf(q)
        val isMatching = correctPairs.isNotEmpty()

        // Para matching: enunciados (primer elemento) y alternativas ordenadas alfabéticamente
        val prompts = if (isMatching) correctPairs.map { it.first } else emptyList()
        val matchCandidates = if (isMatching) {
            val matchIds = correctPairs.map { it.second }.toSet()
            options.filter { it.id in matchIds }.sortedBy { it.text }
        } else emptyList()
        fun optText(id: String) = options.firstOrNull { it.id == id }?.text ?: id

        val answerIsCorrect = if (isMatching) {
            pairSelection.size == correctPairs.size &&
                correctPairs.all { (p, m) -> pairSelection[p] == m }
        } else {
            selection == correctIds.toSet()
        }

        LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Text("Pregunta ${idx + 1} de ${questions.size}", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    DifficultyBadge(q.difficulty)
                    StatusBadge(when (q.questionType) {
                        "single_choice" -> if (correctIds.size > 1) "Opción múltiple" else "Opción única"
                        "multiple_choice" -> "Opción múltiple"
                        "true_false" -> "Verdadero o falso"
                        "matching" -> "Relación de conceptos"
                        "interpretation" -> "Interpretación"
                        "case_based" -> "Basada en caso"
                        else -> q.questionType
                    })
                }
                Spacer(Modifier.height(4.dp))
                Text(q.statement, style = MaterialTheme.typography.bodyLarge)
            }

            if (isMatching) {
                // Cada enunciado con sus posibles correspondencias
                items(prompts.size) { pi ->
                    val promptId = prompts[pi]
                    Column {
                        Text("• ${optText(promptId)}", style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(bottom = 4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            matchCandidates.forEach { m ->
                                FilterChip(
                                    selected = pairSelection[promptId] == m.id,
                                    onClick = {
                                        if (!checked) {
                                            pairSelection = pairSelection + (promptId to m.id)
                                        }
                                    },
                                    label = { Text(m.text, style = MaterialTheme.typography.bodySmall) }
                                )
                            }
                        }
                    }
                }
            } else {
                items(options) { o ->
                    val selected = o.id in selection
                    val isCorrectOption = o.id in correctIds
                    OutlinedCard(
                        onClick = { if (!checked) selection = setOf(o.id) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = selected, onClick = { if (!checked) selection = setOf(o.id) })
                            Text(o.text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                            if (checked && isCorrectOption) Text(" ✔", color = com.uciassistant.ui.theme.UciGreen)
                            if (checked && selected && !isCorrectOption) Text(" ✘", color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }

            item {
                if (!checked) {
                    Button(
                        onClick = {
                            checked = true
                            if (answerIsCorrect) correctCount++
                            scope.launch {
                                app.academy.recordAttempt(q.questionId, topicId, answerIsCorrect)
                            }
                        },
                        enabled = if (isMatching) pairSelection.size == correctPairs.size else selection.isNotEmpty()
                    ) { Text("Comprobar respuesta") }
                } else {
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                if (answerIsCorrect) "✔ Correcto" else "✘ Incorrecto — respuesta válida: " +
                                        (if (isMatching)
                                            correctPairs.joinToString(" · ") { "${optText(it.first)} → ${optText(it.second)}" }
                                        else correctIds.joinToString { cid -> optText(cid) }),
                                style = MaterialTheme.typography.titleMedium,
                                color = if (answerIsCorrect) com.uciassistant.ui.theme.UciGreen else MaterialTheme.colorScheme.error
                            )
                            Text("Explicación razonada", style = MaterialTheme.typography.labelMedium)
                            Text(q.explanation, style = MaterialTheme.typography.bodyMedium)
                            if (refsLoaded.isNotEmpty()) {
                                Text("Referencia bibliográfica", style = MaterialTheme.typography.labelMedium)
                                refsLoaded.forEach { Text("• ${it.citation} (${it.year})", style = MaterialTheme.typography.bodySmall) }
                            }
                            Text("Tema asociado: $title", style = MaterialTheme.typography.bodySmall)
                            if (!answerIsCorrect) {
                                Text(
                                    "Recomendación de repaso: vuelva a los apartados «Fisiopatología» y «Diagnóstico y evaluación» del tema.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.tertiary
                                )
                            }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            if (idx + 1 < questions.size) {
                                idx++; selection = emptySet(); pairSelection = emptyMap(); checked = false
                            } else finished = true
                        }) { Text(if (idx + 1 < questions.size) "Siguiente pregunta" else "Ver resultado") }
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}
