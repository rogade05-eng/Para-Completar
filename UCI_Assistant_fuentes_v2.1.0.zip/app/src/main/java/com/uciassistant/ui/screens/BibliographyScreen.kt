package com.uciassistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.uciassistant.UciApp
import com.uciassistant.ui.components.*

/** Bibliografía del contenido oficial (tabla content_sources, sección 7.1). */
@Composable
fun BibliographyScreen(nav: NavController) {
    val app = UciApp.instance
    var refs by remember { mutableStateOf<List<com.uciassistant.data.db.ReferenceEntity>>(emptyList()) }

    LaunchedEffect(Unit) { refs = app.academy.references() }

    Column(Modifier.fillMaxSize()) {
        UciTopBar("Bibliografía", "Fuentes bibliográficas del contenido oficial", onBack = { nav.popBackStack() })
        if (refs.isEmpty()) {
            EmptyState("No hay referencias instaladas.")
            return@Column
        }
        LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(refs) { r ->
                UciCard {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        StatusBadge(r.type)
                        StatusBadge(r.year, MaterialTheme.colorScheme.tertiary)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(r.citation, style = MaterialTheme.typography.bodyMedium)
                    if (r.source.isNotBlank()) {
                        Text(r.source, style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}
