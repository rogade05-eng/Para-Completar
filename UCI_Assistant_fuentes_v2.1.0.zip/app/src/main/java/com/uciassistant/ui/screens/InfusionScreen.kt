package com.uciassistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.uciassistant.UciApp
import com.uciassistant.clinical.InfusionDrug
import com.uciassistant.clinical.Infusions
import com.uciassistant.ui.components.*

/**
 * Calculadora de perfusiones continuas (v1.5.0).
 * Rango habitual de dosis + cálculo bidireccional + PREPARACIÓN EXACTA por peso
 * (mg a extraer de la ampolla, dilución a 50 ml y regla resultante ml/h ↔ dosis).
 * Incluye contenido sobre jeringuillas perfusoras, infusión continua y bombas.
 * Referencias: Ruza, Nelson, protocolos SECIp.
 */
@Composable
fun InfusionScreen(nav: NavController) {
    val drugs = UciApp.instance.clinic.infusionDrugs
    var drugIndex by remember { mutableIntStateOf(0) }
    var peso by remember { mutableStateOf("") }
    var dosis by remember { mutableStateOf("") }
    var perHour by remember { mutableStateOf(false) }
    var concCustom by remember { mutableStateOf("") }
    var menuOpen by remember { mutableStateOf(false) }

    LaunchedEffect(drugIndex) {
        perHour = drugs[drugIndex].dosedPerHour
        concCustom = ""
    }

    val drug = drugs[drugIndex]
    val pesoVal = peso.replace(',', '.').toDoubleOrNull()
    val dosisVal = dosis.replace(',', '.').toDoubleOrNull()
    val conc = concCustom.replace(',', '.').toDoubleOrNull() ?: drug.concentrationMgPerMl

    val rate = if (pesoVal != null && dosisVal != null && dosisVal > 0) {
        if (perHour) Infusions.rateMlHPerHour(dosisVal, pesoVal, conc)
        else Infusions.rateMlH(dosisVal, pesoVal, conc)
    } else null

    val inRange: Boolean? = dosisVal?.let { d ->
        val dMin = d * if (perHour) 60.0 else 1.0  // normaliza a mcg/kg/min
        dMin >= drug.minDose * 0.98 && dMin <= drug.maxDose * 1.02
    }

    Column(Modifier.fillMaxSize()) {
        UciTopBar("Calculadora de perfusiones", "Dosis ↔ ml/h · rango y preparación · v1.5.0", onBack = { nav.popBackStack() })
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            /* ---------- Selector de fármaco ---------- */
            Text("Fármaco", style = MaterialTheme.typography.titleMedium)
            Box {
                OutlinedButton(onClick = { menuOpen = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(drug.name, Modifier.weight(1f, fill = false))
                    Text(" ▾")
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    drugs.forEachIndexed { i, d ->
                        DropdownMenuItem(
                            text = { Text(d.name) },
                            onClick = { drugIndex = i; menuOpen = false }
                        )
                    }
                }
            }
            Text(
                "Presentación: ${drug.presentation}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                "Preparación estándar: ${drug.standardText}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            /* ---------- Datos ---------- */
            Text("Datos", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = peso,
                onValueChange = { peso = it.filter { c -> c.isDigit() || c == '.' || c == ',' } },
                label = { Text("Peso (kg)") },
                singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth()
            )

            Text("Rango habitual: ${drug.typicalDoseText}", style = MaterialTheme.typography.bodyMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(
                    onClick = {
                        val v = if (drug.dosedPerHour) drug.minDose * 60 else drug.minDose
                        dosis = trimNum(v)
                    },
                    label = { Text("Usar mínimo") }
                )
                AssistChip(
                    onClick = {
                        val v = if (drug.dosedPerHour) drug.maxDose * 60 else drug.maxDose
                        dosis = trimNum(v)
                    },
                    label = { Text("Usar máximo") }
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = dosis,
                    onValueChange = { dosis = it.filter { c -> c.isDigit() || c == '.' || c == ',' } },
                    label = { Text(if (perHour) "Dosis deseada (mcg/kg/h)" else "Dosis deseada (mcg/kg/min)") },
                    singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.weight(1f)
                )
                FilterChip(
                    selected = perHour,
                    onClick = { perHour = !perHour },
                    label = { Text(if (perHour) "por hora" else "por minuto") },
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
            OutlinedTextField(
                value = concCustom,
                onValueChange = { concCustom = it.filter { c -> c.isDigit() || c == '.' || c == ',' } },
                label = { Text("Concentración real (mg/ml) — opcional") },
                placeholder = { Text("Estándar: ${drug.concentrationMgPerMl}") },
                singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth()
            )

            /* ---------- Resultado ---------- */
            Text("Resultado", style = MaterialTheme.typography.titleMedium)
            if (rate != null && rate > 0) {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            "Programar %.2f ml/h".format(rate),
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold
                        )
                        val realDose = Infusions.doseFromRate(rate, pesoVal!!, conc)
                        Text(
                            "Equivalente real: %.3f mcg/kg/min%s".format(
                                realDose, if (perHour) " (≈ %.2f mcg/kg/h)".format(realDose * 60) else ""),
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            "Concentración usada: ${if (concCustom.isBlank()) "estándar" else "personalizada"} de %.4f mg/ml".format(conc),
                            style = MaterialTheme.typography.bodySmall
                        )
                        if (inRange != null) {
                            Text(
                                if (inRange) "✓ Dentro del rango habitual (${drug.typicalDoseText})"
                                else "⚠ FUERA del rango habitual (${drug.typicalDoseText}) — revise dosis y protocolo",
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (inRange) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                            )
                        }
                        Text("Nota: ${drug.notes}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            } else {
                StatusBadge("Introduzca peso y dosis para calcular", MaterialTheme.colorScheme.tertiary)
            }

            /* ---------- Preparación ---------- */
            Text("Cómo prepararlo", style = MaterialTheme.typography.titleMedium)
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (pesoVal != null && pesoVal > 0) {
                        drug.ruleMgPerKg?.let { rule ->
                            val mgTotal = rule * pesoVal
                            val concSyringeMcgMl = mgTotal * 1000.0 / 50.0
                            val ruleRate = concSyringeMcgMl / (pesoVal * 60.0)
                            val ampMl = drug.ampMgPerMl?.let { mgTotal / it }
                            Text("Jeringa de 50 ml para ${trimNum(pesoVal)} kg:",
                                fontWeight = FontWeight.SemiBold)
                            Text("• Extraer ${fmt(mgTotal)} mg" +
                                (ampMl?.let { " = ${fmt(it)} ml de la ampolla (${fmt(drug.ampMgPerMl!!)} mg/ml)" } ?: ""),
                                style = MaterialTheme.typography.bodyMedium)
                            Text("• Completar a 50 ml con SF 0,9 % o G5 % → ${fmt(concSyringeMcgMl)} mcg/ml",
                                style = MaterialTheme.typography.bodyMedium)
                            Text("• Regla resultante: 1 ml/h = ${fmt(ruleRate)} mcg/kg/min",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(4.dp))
                        }
                        drug.prepSteps.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                    } else {
                        Text("Introduzca el peso para calcular la preparación exacta de la jeringa de 50 ml.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            /* ---------- Contenido: bombas y perfusión continua ---------- */
            Text("¿Por qué jeringuillas perfusoras e infusión continua?", style = MaterialTheme.typography.titleMedium)
            Infusions.pumpEducation.forEach { (t, body) ->
                UciCard {
                    Text(t, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(4.dp))
                    Text(body, style = MaterialTheme.typography.bodySmall)
                }
            }

            Text(
                "Bibliografía: Ruza (Cuidados Intensivos Pediátricos) · Nelson Textbook of Pediatrics · Protocolos SECIp. Verifique SIEMPRE preparación y velocidad con doble comprobación de enfermería; la concentración estándar puede diferir de la de su unidad (use el campo personalizado).",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.tertiary
            )
            DisclaimerFooter()
        }
    }
}

private fun fmt(v: Double): String =
    if (v >= 100) "%.0f".format(v) else if (v >= 10) "%.1f".format(v) else "%.2f".format(v)

private fun trimNum(v: Double): String =
    "%.3f".format(v).trimEnd('0').trimEnd('.')
