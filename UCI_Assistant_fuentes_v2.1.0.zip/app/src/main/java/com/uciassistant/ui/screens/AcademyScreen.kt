package com.uciassistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.uciassistant.ui.nav.Routes
import com.uciassistant.UciApp
import com.uciassistant.ui.components.*
import kotlinx.coroutines.launch

/** Biblioteca integral (sección 4.2): áreas de conocimiento. */
@Composable
fun AcademyScreen(nav: NavController) {
    val app = UciApp.instance
    val scope = rememberCoroutineScope()
    val areas by app.academy.areas().collectAsState(initial = emptyList())
    val cases by app.academy.cases().collectAsState(initial = emptyList())
    var installMsg by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Academia", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Biblioteca integral · Estudio libre y programa curricular. Contenidos oficiales con procedencia identificada.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(6.dp))
        }
        item {
            UciCard(onClick = { nav.navigate(Routes.EXAM) }) {
                Text("Modo Examen", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    "20 preguntas aleatorias de toda la biblioteca, corrección al final con revisión razonada de los fallos y enlace directo al tema para repasar.",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(6.dp))
                Button(onClick = { nav.navigate(Routes.EXAM) }) { Text("Empezar examen") }
            }
        }
        if (areas.isEmpty()) {
            item {
                UciCard {
                    Text("Biblioteca vacía", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Instale ahora mismo el paquete académico incluido (validación + instalación en un paso) o importe un paquete .zip desde el dispositivo.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(
                        enabled = !busy,
                        onClick = {
                            busy = true
                            installMsg = null
                            scope.launch {
                                try {
                                    val pv = app.importer.validateFromAssets()
                                    installMsg = if (pv.valid && app.importer.installFromAssets(pv))
                                        "Paquete instalado: ${pv.counts.entries.joinToString(" · ") { "${it.key}: ${it.value}" }}"
                                    else "La validación devolvió errores: " + pv.issues.joinToString(" · ") { it.message }
                                } catch (e: Exception) {
                                    installMsg = "Error al instalar: ${e.message}"
                                }
                                busy = false
                            }
                        }
                    ) { Text(if (busy) "Instalando…" else "Instalar paquete incluido aquí") }
                    TextButton(onClick = { nav.navigate("packages") }) { Text("Ir a Paquetes académicos") }
                    installMsg?.let {
                        Spacer(Modifier.height(6.dp))
                        Text(it, style = MaterialTheme.typography.bodySmall,
                            color = if (it.startsWith("Paquete")) com.uciassistant.ui.theme.UciGreen
                            else MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
        items(areas) { a ->
            UciCard(onClick = { nav.navigate(Routes.area(a.id)) }) {
                Text(a.name, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                PopulationBadge(a.population)
                Spacer(Modifier.height(6.dp))
                Text(a.description, style = MaterialTheme.typography.bodySmall, maxLines = 3)
            }
        }
        if (cases.isNotEmpty()) {
            item {
                Spacer(Modifier.height(8.dp))
                Text("Casos clínicos simulados", style = MaterialTheme.typography.titleMedium)
            }
            items(cases.filter { true }.map { it }) { c ->
                UciCard(onClick = { nav.navigate(Routes.case(c.caseId)) }) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        StatusBadge("Caso educativo", MaterialTheme.colorScheme.tertiary)
                        PopulationBadge(c.population)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(c.title, style = MaterialTheme.typography.titleMedium)
                    Text("Edad simulada: ${c.simulatedAge} · Dificultad: ${c.difficulty}",
                        style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            TextButton(onClick = { nav.navigate("bibliografia") }) { Text("Bibliografía completa") }
            DisclaimerFooter()
        }
    }
}
