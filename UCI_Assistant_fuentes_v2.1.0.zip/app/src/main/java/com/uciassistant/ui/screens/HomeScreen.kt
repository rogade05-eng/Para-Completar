package com.uciassistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.uciassistant.ui.nav.Routes
import com.uciassistant.UciApp
import com.uciassistant.ui.components.*
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Pantalla de inicio v1.6.0 — panel de control del día a día: estado de la
 * biblioteca, continuar estudio, tarjetas vencidas, accesos rápidos clínicos
 * y selector rápido de tema claro/oscuro (además de Perfil → Preferencias).
 */
@Composable
fun HomeScreen(nav: NavController) {
    val app = UciApp.instance
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val themeMode by com.uciassistant.ui.theme.ThemePrefs.mode(context)
        .collectAsState(initial = "system")
    var topicCount by remember { mutableIntStateOf(0) }
    var areaCount by remember { mutableIntStateOf(0) }
    var dueCards by remember { mutableIntStateOf(0) }
    var topicsCompleted by remember { mutableIntStateOf(0) }
    var attempts by remember { mutableIntStateOf(0) }
    var correctRate by remember { mutableDoubleStateOf(0.0) }
    var lastTopicId by remember { mutableStateOf<String?>(null) }
    var lastTopicTitle by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        try {
            topicCount = app.db.academyDao().topicCount()
            areaCount = app.academy.areas().first().size
            val st = app.academy.stats()
            dueCards = st.dueCards
            topicsCompleted = st.topicsCompleted
            attempts = st.attempts
            correctRate = st.correctRate
            val progress = app.academy.progressAll().first().maxByOrNull { it.updatedAt }
            if (progress != null) {
                lastTopicId = progress.topicId
                lastTopicTitle = app.academy.topic(progress.topicId)?.title ?: ""
            }
        } catch (_: Exception) {
            topicCount = 0
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("UCI Assistant", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Panel del día a día en cuidados intensivos · 100 % sin conexión",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        // Tema claro/oscuro accesible desde Inicio (además de Perfil → Preferencias)
        UciCard {
            Text("Apariencia", style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = themeMode == "system",
                    onClick = { scope.launch { com.uciassistant.ui.theme.ThemePrefs.setMode(context, "system") } },
                    label = { Text("Sistema") }
                )
                FilterChip(
                    selected = themeMode == "light",
                    onClick = { scope.launch { com.uciassistant.ui.theme.ThemePrefs.setMode(context, "light") } },
                    label = { Text("Claro") }
                )
                FilterChip(
                    selected = themeMode == "dark",
                    onClick = { scope.launch { com.uciassistant.ui.theme.ThemePrefs.setMode(context, "dark") } },
                    label = { Text("Oscuro") }
                )
            }
        }

        // Único buscador (sección 3.6): disponible desde Inicio con una interacción
        OutlinedButton(
            onClick = { nav.navigate("search?query=") },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Buscar tema, escala, procedimiento o cálculo…") }

        // Estado de la biblioteca: si está vacía, acción destacada
        if (topicCount == 0) {
            UciCard {
                Text("Biblioteca sin contenido", style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.error)
                Text(
                    "El paquete académico no se ha instalado todavía. Ábralo desde Paquetes académicos: validación + instalación en un paso.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(8.dp))
                Button(onClick = { nav.navigate(Routes.PACKAGES) }) { Text("Instalar paquete académico") }
            }
        } else {
            // Continuar estudio
            UciCard {
                if (lastTopicId != null) {
                    Text("Continuar estudio", style = MaterialTheme.typography.titleMedium)
                    Text(lastTopicTitle, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { nav.navigate(Routes.topic(lastTopicId!!)) }) { Text("Retomar") }
                        TextButton(onClick = { nav.navigate(Routes.ACADEMY) }) { Text("Ver biblioteca") }
                    }
                } else {
                    Text("Empezar a estudiar", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Biblioteca con $topicCount temas disponibles.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(6.dp))
                    Button(onClick = { nav.navigate(Routes.ACADEMY) }) { Text("Abrir Academia") }
                }
            }

            // Resumen de aprendizaje
            UciCard {
                Text("Su progreso de hoy", style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.height(4.dp))
                if (dueCards > 0) {
                    Text("Tarjetas para repasar: $dueCards", style = MaterialTheme.typography.bodyMedium)
                    TextButton(onClick = { nav.navigate(Routes.ACADEMY) }) { Text("Repasar ahora") }
                } else {
                    Text("Sin tarjetas vencidas", style = MaterialTheme.typography.bodyMedium)
                }
                Text("Temas completados: $topicsCompleted", style = MaterialTheme.typography.bodyMedium)
                if (attempts > 0) {
                    Text(
                        "Precisión en preguntas: %.0f %% ($attempts intentos)".format(correctRate),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        HorizontalDivider()

        // Acceso clínico rápido (3 interacciones máximo, 10.4)
        Text("Acceso clínico rápido", style = MaterialTheme.typography.titleMedium)
        UciCard {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = { nav.navigate(Routes.CLINIC) }, label = { Text("Escalas") })
                AssistChip(onClick = { nav.navigate(Routes.CLINIC) }, label = { Text("Procedimientos") })
                AssistChip(onClick = { nav.navigate(Routes.CLINIC) }, label = { Text("Calculadoras") })
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = { nav.navigate(Routes.scale("tep")) }, label = { Text("TEP pediátrico") })
                AssistChip(onClick = { nav.navigate(Routes.scale("pews")) }, label = { Text("PEWS") })
                AssistChip(onClick = { nav.navigate(Routes.INFUSIONS) }, label = { Text("Perfusiones") })
            }
        }

        HorizontalDivider()

        Text("Casos y búsqueda académica", style = MaterialTheme.typography.titleMedium)
        UciCard {
            Text(
                "Academia: biblioteca con $areaCount áreas y $topicCount temas, tests con explicación, tarjetas SM-2, casos clínicos simulados progresivos y Modo Examen global.",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { nav.navigate(Routes.ACADEMY) }) { Text("Abrir Academia") }
                TextButton(onClick = { nav.navigate(Routes.EXAM) }) { Text("Modo Examen") }
            }
        }

        DisclaimerFooter()
    }
}
