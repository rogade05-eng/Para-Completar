package com.uciassistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.uciassistant.UciApp
import com.uciassistant.data.importer.PackageImporter
import com.uciassistant.ui.components.*
import kotlinx.coroutines.launch
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json

private val cjson = Json { ignoreUnknownKeys = true }

/**
 * Caso clínico simulado por etapas (sección 4.6). Material claramente educativo:
 * paciente ficticio, decisiones esperadas revelables y discusión final.
 */
@Composable
fun CaseScreen(nav: NavController, caseId: String) {
    val app = UciApp.instance
    val scope = rememberCoroutineScope()
    var c by remember { mutableStateOf<com.uciassistant.data.db.ClinicalCaseEntity?>(null) }
    var stages by remember { mutableStateOf<List<PackageImporter.CaseStage>>(emptyList()) }
    var currentStage by remember { mutableIntStateOf(1) }
    var revealed by remember { mutableStateOf<Set<Int>>(emptySet()) }
    var isFav by remember { mutableStateOf(false) }

    LaunchedEffect(caseId) {
        val e = app.academy.caseById(caseId) ?: return@LaunchedEffect
        c = e
        stages = app.academy.stagesOf(e)
        isFav = app.personal.isFavorite("case", caseId)
    }

    val case = c ?: return
    Column(Modifier.fillMaxSize()) {
        UciTopBar(case.title, "Paciente ficticio · ${case.simulatedAge} · dificultad ${case.difficulty}",
            onBack = { nav.popBackStack() })
        LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    StatusBadge("Material educativo ficticio", MaterialTheme.colorScheme.tertiary)
                    PopulationBadge(case.population)
                }
                Spacer(Modifier.height(4.dp))
                Text("Contexto clínico: ${case.clinicalContext}", style = MaterialTheme.typography.bodyMedium)
                Text("Motivo de ingreso: ${case.admissionReason}", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(4.dp))
                val objectives = cjson.decodeFromString(ListSerializer(String.serializer()),
                    case.learningObjectivesJson)
                if (objectives.isNotEmpty()) {
                    Text("Objetivos de aprendizaje", style = MaterialTheme.typography.titleMedium)
                    objectives.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                }
            }

            items(stages.filter { it.stageNumber <= currentStage }) { st ->
                UciCard {
                    Text("Etapa ${st.stageNumber}: ${st.stageTitle}", style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(6.dp))
                    Text(st.narrative, style = MaterialTheme.typography.bodyMedium)
                    if (st.data.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Text("Datos", style = MaterialTheme.typography.labelMedium)
                        st.data.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                    }
                    st.progressiveQuestions.forEachIndexed { qIdx, pq ->
                        Spacer(Modifier.height(8.dp))
                        Text("Pregunta: ${pq.question}", style = MaterialTheme.typography.bodyLarge)
                        val key = st.stageNumber * 100 + qIdx
                        if (key in revealed) {
                            Text("Decisiones esperadas", style = MaterialTheme.typography.labelMedium)
                            pq.expectedDecisions.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                            Text("Explicación: ${pq.explanation}", style = MaterialTheme.typography.bodySmall)
                        } else {
                            OutlinedButton(onClick = { revealed = revealed + key }) {
                                Text("Revelar decisiones esperadas")
                            }
                        }
                    }
                }
            }

            item {
                if (currentStage < stages.size) {
                    Button(onClick = { currentStage++ }, modifier = Modifier.fillMaxWidth()) {
                        Text("Avanzar a la etapa ${currentStage + 1}")
                    }
                } else {
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Discusión final y evolución simulada", style = MaterialTheme.typography.titleMedium)
                            val initial = cjson.decodeFromString(ListSerializer(String.serializer()),
                                case.initialDataSummaryJson)
                            if (initial.isNotEmpty()) {
                                Text("Resumen de datos iniciales", style = MaterialTheme.typography.labelMedium)
                                initial.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                            }
                            val comp = cjson.decodeFromString(ListSerializer(String.serializer()),
                                case.complementaryResultsSummaryJson)
                            if (comp.isNotEmpty()) {
                                Text("Resultados complementarios de referencia", style = MaterialTheme.typography.labelMedium)
                                comp.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                            }
                            case.disclaimer?.let {
                                Text(it, style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            scope.launch {
                                app.personal.toggleFavorite("case", case.caseId, case.title)
                                isFav = app.personal.isFavorite("case", case.caseId)
                            }
                        }) { Text(if (isFav) "★ Quitar de favoritos" else "☆ Añadir a favoritos") }
                        Button(onClick = { currentStage = 1; revealed = emptySet() }) { Text("Reiniciar caso") }
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}
