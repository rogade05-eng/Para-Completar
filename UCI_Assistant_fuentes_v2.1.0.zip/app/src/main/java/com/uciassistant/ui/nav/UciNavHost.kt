package com.uciassistant.ui.nav

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.uciassistant.UciApp
import com.uciassistant.ui.screens.*

/** Rutas de navegación de la aplicación. */
object Routes {
    const val HOME = "home"
    const val CLINIC = "clinic"
    const val ACADEMY = "academy"
    const val FAVORITES = "favorites"
    const val PROFILE = "profile"

    const val SEARCH = "search?query={query}"
    const val ACADEMY_AREA = "area/{areaId}"
    const val TOPIC = "topic/{topicId}"
    const val TOPIC_QUIZ = "quiz/{topicId}"
    const val TOPIC_CARDS = "cards/{topicId}"
    const val CASE = "case/{caseId}"
    const val SCALE = "scale/{scaleId}"
    const val PROCEDURE = "procedure/{procedureId}"
    const val INFUSIONS = "infusiones"
    const val NUTRITION = "nutricion_parenteral"
    const val COMA = "coma_farmacos"
    const val BIBLIO = "bibliografia"
    const val PACKAGES = "packages"
    const val EXAM = "exam"

    fun topic(id: String) = "topic/$id"
    fun quiz(id: String) = "quiz/$id"
    fun cards(id: String) = "cards/$id"
    fun case(id: String) = "case/$id"
    fun scale(id: String) = "scale/$id"
    fun procedure(id: String) = "procedure/$id"
    fun area(id: String) = "area/$id"
}

private data class Section(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

/** Navegación principal de cinco secciones (sección 10.1 del contrato). */
@Composable
fun UciAppRoot() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val themeMode by com.uciassistant.ui.theme.ThemePrefs.mode(context)
        .collectAsState(initial = "system")
    val darkOverride = when (themeMode) {
        "light" -> false
        "dark" -> true
        else -> null
    }
    com.uciassistant.ui.theme.UciTheme(darkThemeOverride = darkOverride) {
        Root()
    }
}

@Composable
private fun Root() {
    val nav = rememberNavController()
    val sections = listOf(
        Section(Routes.HOME, "Inicio", Icons.Filled.Home),
        Section(Routes.CLINIC, "Clínica", Icons.Filled.Build),
        Section(Routes.ACADEMY, "Academia", Icons.Filled.List),
        Section(Routes.FAVORITES, "Favoritos", Icons.Filled.Star),
        Section(Routes.PROFILE, "Perfil", Icons.Filled.Person)
    )
    val backStack by nav.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route
    val showBar = currentRoute in sections.map { it.route }

    Scaffold(
        bottomBar = {
            if (showBar) {
                NavigationBar {
                    sections.forEach { s ->
                        NavigationBarItem(
                            selected = currentRoute == s.route,
                            onClick = {
                                nav.navigate(s.route) {
                                    popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(s.icon, contentDescription = s.label) },
                            label = { Text(s.label) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        val app = UciApp.instance
        NavHost(nav, startDestination = Routes.HOME, modifier = Modifier.padding(padding)) {
            composable(Routes.HOME) { HomeScreen(nav) }
            composable(Routes.CLINIC) { ClinicScreen(nav) }
            composable(Routes.ACADEMY) { AcademyScreen(nav) }
            composable(Routes.FAVORITES) { FavoritesScreen(nav) }
            composable(Routes.PROFILE) { ProfileScreen(nav) }

            composable("search?query={query}") { entry ->
                SearchScreen(nav, entry.arguments?.getString("query") ?: "")
            }
            composable("area/{areaId}") { entry ->
                AreaScreen(nav, entry.arguments?.getString("areaId") ?: "")
            }
            composable("topic/{topicId}") { entry ->
                TopicReaderScreen(nav, entry.arguments?.getString("topicId") ?: "")
            }
            composable("quiz/{topicId}") { entry ->
                QuizScreen(nav, entry.arguments?.getString("topicId") ?: "")
            }
            composable("cards/{topicId}") { entry ->
                FlashcardsScreen(nav, entry.arguments?.getString("topicId") ?: "")
            }
            composable("case/{caseId}") { entry ->
                CaseScreen(nav, entry.arguments?.getString("caseId") ?: "")
            }
            composable("scale/{scaleId}") { entry ->
                ScaleScreen(nav, entry.arguments?.getString("scaleId") ?: "")
            }
            composable("procedure/{procedureId}") { entry ->
                ProcedureScreen(nav, entry.arguments?.getString("procedureId") ?: "")
            }
            composable("infusiones") { InfusionScreen(nav) }
            composable("nutricion_parenteral") { NutritionScreen(nav) }
            composable("coma_farmacos") { ComaScreen(nav) }
            composable("bibliografia") { BibliographyScreen(nav) }
            composable("packages") { PackagesScreen(nav) }
            composable("exam") { ExamScreen(nav) }
        }
    }
}
