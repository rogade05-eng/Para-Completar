package com.uciassistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.uciassistant.ui.nav.Routes
import com.uciassistant.UciApp
import com.uciassistant.ui.components.*
import com.uciassistant.ui.theme.ThemePrefs
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/** Perfil: panel de aprendizaje (4.10), paquetes instalados, preferencias y avisos. */
@Composable
fun ProfileScreen(nav: NavController) {
    val app = UciApp.instance
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var stats by remember { mutableStateOf<com.uciassistant.data.repo.AcademyStats?>(null) }
    var seconds by remember { mutableStateOf(0L) }
    var themeMode by remember { mutableStateOf("system") }
    var library by remember { mutableStateOf<IntArray?>(null) }
    val installed by app.personal.packages().collectAsState(initial = emptyList())

    // Se recalcula cada vez que se entra a la pantalla o cambia la biblioteca
    // instalada (evita el panel «todo en cero» tras instalar un paquete).
    LaunchedEffect(Unit, installed.size) {
        stats = app.academy.stats()
        seconds = app.personal.studySeconds().first()
        library = intArrayOf(
            app.db.academyDao().topicCount(),
            app.db.academyDao().topicsWithQuestions(),
            app.db.academyDao().allCards().first().size,
            app.db.academyDao().cases().first().size
        )
        ThemePrefs.mode(context).collect { themeMode = it }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Perfil", style = MaterialTheme.typography.headlineMedium)

        library?.let { lib ->
            UciCard {
                Text("Biblioteca instalada", style = MaterialTheme.typography.titleMedium)
                if (lib[0] == 0) {
                    Text(
                        "Sin paquetes instalados: use Paquetes académicos para instalar el paquete incluido.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error
                    )
                } else {
                    Text("Temas: ${lib[0]} · con preguntas: ${lib[1]}", style = MaterialTheme.typography.bodyMedium)
                    Text("Tarjetas oficiales: ${lib[2]} · casos clínicos: ${lib[3]}", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        UciCard {
            Text("Seguimiento del aprendizaje", style = MaterialTheme.typography.titleMedium)
            val s = stats
            if (s == null) {
                CircularProgressIndicator(Modifier.padding(8.dp))
            } else {
                Text("Temas iniciados: ${s.topicsStarted}", style = MaterialTheme.typography.bodyMedium)
                Text("Temas completados: ${s.topicsCompleted}", style = MaterialTheme.typography.bodyMedium)
                Text("Preguntas respondidas: ${s.attempts}", style = MaterialTheme.typography.bodyMedium)
                Text("Porcentaje de aciertos: ${"%.0f".format(s.correctRate)} %", style = MaterialTheme.typography.bodyMedium)
                Text("Tarjetas pendientes de repaso: ${s.dueCards}", style = MaterialTheme.typography.bodyMedium)
                Text("Tarjetas dominadas (intervalo ≥ 21 días): ${s.masteredCards}", style = MaterialTheme.typography.bodyMedium)
                Text("Tiempo de estudio registrado: ${seconds / 60} min", style = MaterialTheme.typography.bodyMedium)
                Text(
                    "Los porcentajes se calculan a partir de actividades registradas, no de visitas a pantallas.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        UciCard(onClick = { nav.navigate("packages") }) {
            Text("Paquetes académicos", style = MaterialTheme.typography.titleMedium)
            Text("Validar e instalar el paquete incluido, importar un .zip del dispositivo y consultar los instalados.", style = MaterialTheme.typography.bodyMedium)
        }

        UciCard {
            Text("Preferencias", style = MaterialTheme.typography.titleMedium)
            Text("Modo de apariencia", style = MaterialTheme.typography.labelMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = themeMode == "light",
                    onClick = { scope.launch { ThemePrefs.setMode(context, "light") } },
                    label = { Text("Claro") }
                )
                FilterChip(
                    selected = themeMode == "dark",
                    onClick = { scope.launch { ThemePrefs.setMode(context, "dark") } },
                    label = { Text("Oscuro") }
                )
                FilterChip(
                    selected = themeMode == "system",
                    onClick = { scope.launch { ThemePrefs.setMode(context, "system") } },
                    label = { Text("Sistema") }
                )
            }
        }

        UciCard {
            Text("Acerca de", style = MaterialTheme.typography.titleMedium)
            Text("UCI Assistant 1.6.0 · APK Android independiente", style = MaterialTheme.typography.bodyMedium)
            Text("Kotlin · Jetpack Compose · Room · Offline-first · Sin IA · Sin conexión", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(6.dp))
            Text(
                "La aplicación es una herramienta de apoyo personal y no sustituye los sistemas oficiales de documentación clínica. El contenido académico incluido tiene estado editorial «pending_review»: debe ser validado por especialistas de adultos, pediatría y neonatología antes de considerarse definitivo (sección 17 del contrato).",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        DisclaimerFooter()
    }
}
