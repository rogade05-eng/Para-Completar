package com.uciassistant.ui.theme

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "uci_prefs")

/** Preferencias locales mediante DataStore (sección 2.1). Tema: system | light | dark. */
object ThemePrefs {
    private val KEY = stringPreferencesKey("theme_mode")

    fun mode(context: Context): Flow<String> =
        context.dataStore.data.map { it[KEY] ?: "system" }

    suspend fun setMode(context: Context, mode: String) {
        context.dataStore.edit { it[KEY] = mode }
    }
}
