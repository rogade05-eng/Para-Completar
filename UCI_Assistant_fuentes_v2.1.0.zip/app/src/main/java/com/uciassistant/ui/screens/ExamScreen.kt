package com.uciassistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.uciassistant.UciApp
import com.uciassistant.data.db.QuizQuestionEntity
import com.uciassistant.ui.components.*
import com.uciassistant.ui.nav.Routes
import kotlinx.coroutines.launch
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json

private val examJson = Json { ignoreUnknownKeys = true }

/**
 * Modo Examen (v1.4.0): test global de 20 preguntas aleatorias de toda la
 * biblioteca, sin corrección inmediata. Al finalizar muestra la nota, la
 * revisión razonada de cada fallo y registra los intentos (sección 4.10).
 * Complemento del estudio SM-2: evalúa la recuperación del día a día.
 */
private const val EXAM_SIZE = 20

@Composable
fun ExamScreen(nav: NavController) {
    val app = UciApp.instance
    val scope = rememberCoroutineScope()
    var questions by remember { mutableStateOf<List<QuizQuestionEntity>>(emptyList()) }
    var topicTitles by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var answers by remember { mutableStateOf<Map<String, Set<String>>>(emptyMap()) }
    var idx by remember { mutableIntStateOf(0) }
    var finished by remember { mutableStateOf(false) }
    var score by remember { mutableIntStateOf(0) }
    var recordingDone by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val bank = app.academy.allExamQuestions().shuffled()
        questions = bank.take(EXAM_SIZE)
        topicTitles = questions.associate { q ->
            q.topicId to (app.academy.topic(q.topicId)?.title ?: "")
        }
    }

    Column(Modifier.fillMaxSize()) {
        UciTopBar("Modo Examen", "20 preguntas aleatorias de toda la biblioteca", onBack = { nav.popBackStack() })

        if (questions.isEmpty()) {
            EmptyState("La biblioteca está vacía: instale el paquete académico antes de examinarse.")
            return@Column
        }

        if (finished) {
            val percent = score * 100 / questions.size
            val band = when {
                percent >= 90 -> "Excelente — nivel de recuperación alta"
                percent >= 70 -> "Bien — consolidar los fallos con los temas"
                percent >= 50 -> "Regular — repasar los temas fallados antes del siguiente examen"
                else -> "Insuficiente — programar repaso SM-2 de los temas fallados"
            }
            LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Text("Resultado del examen", style = MaterialTheme.typography.headlineMedium)
                    Text(
                        "$score de ${questions.size} correctas · $percent %",
                        style = MaterialTheme.typography.titleLarge
                    )
                    Text(band, style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary)
                    Text(
                        "Los intentos quedan registrados para el seguimiento del aprendizaje (sección 4.10 del contrato).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            answers = emptyMap(); idx = 0; finished = false; score = 0
                            recordingDone = false
                            scope.launch {
                                questions = app.academy.allExamQuestions().shuffled().take(EXAM_SIZE)
                                topicTitles = questions.associate { q ->
                                    q.topicId to (app.academy.topic(q.topicId)?.title ?: "")
                                }
                            }
                        }) { Text("Nuevo examen") }
                    }
                }

                // Revisión de fallos
                val wrong = questions.filter { q -> answers[q.questionId] != app.academy.correctOf(q).toSet() }
                if (wrong.isNotEmpty()) {
                    item { Text("Revisión de fallos (${wrong.size})", style = MaterialTheme.typography.titleMedium) }
                    items(wrong) { q ->
                        val options = examJson.decodeFromString(
                            ListSerializer(com.uciassistant.data.importer.PackageImporter.Option.serializer()), q.optionsJson)
                        fun optText(id: String) = options.firstOrNull { it.id == id }?.text ?: id
                        val correctIds = app.academy.correctOf(q)
                        UciCard {
                            Text(q.statement, style = MaterialTheme.typography.bodyMedium)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "Su respuesta: " + (answers[q.questionId]?.joinToString { optText(it) } ?: "—"),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                            Text("Respuesta válida: " + correctIds.joinToString { optText(it) },
                                style = MaterialTheme.typography.bodySmall,
                                color = com.uciassistant.ui.theme.UciGreen)
                            Text("Explicación: ${q.explanation}", style = MaterialTheme.typography.bodySmall)
                            topicTitles[q.topicId]?.takeIf { it.isNotBlank() }?.let {
                                TextButton(onClick = { nav.navigate(Routes.topic(q.topicId)) }) {
                                    Text("Repasar tema: $it")
                                }
                            }
                        }
                    }
                }
                item { DisclaimerFooter() }
            }
            return@Column
        }

        val q = questions[idx]
        val selected = answers[q.questionId] ?: emptySet()
        val options = examJson.decodeFromString(
            ListSerializer(com.uciassistant.data.importer.PackageImporter.Option.serializer()), q.optionsJson)

        LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Text("Pregunta ${idx + 1} de ${questions.size}", style = MaterialTheme.typography.labelMedium)
                LinearProgressIndicator(
                    progress = { (idx + 1) / questions.size.toFloat() },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    DifficultyBadge(q.difficulty)
                    topicTitles[q.topicId]?.takeIf { it.isNotBlank() }?.let {
                        StatusBadge(it, MaterialTheme.colorScheme.tertiary)
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(q.statement, style = MaterialTheme.typography.bodyLarge)
            }
            items(options) { o ->
                val isSelected = o.id in selected
                OutlinedCard(
                    onClick = {
                        answers = answers + (q.questionId to
                            (if (isSelected) selected - o.id else selected + o.id))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isSelected, onCheckedChange = null)
                        Text(o.text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (idx > 0) {
                        OutlinedButton(onClick = { idx-- }) { Text("Anterior") }
                    }
                    if (idx + 1 < questions.size) {
                        Button(onClick = { idx++ }) { Text("Siguiente") }
                        TextButton(onClick = { idx = questions.size - 1 }) { Text("Ir al final") }
                    } else {
                        Button(onClick = {
                            score = questions.count { q2 -> answers[q2.questionId] == app.academy.correctOf(q2).toSet() }
                            finished = true
                            if (!recordingDone) {
                                recordingDone = true
                                scope.launch {
                                    questions.forEach { q2 ->
                                        app.academy.recordAttempt(
                                            q2.questionId, q2.topicId,
                                            answers[q2.questionId] == app.academy.correctOf(q2).toSet()
                                        )
                                    }
                                }
                            }
                        }) { Text("Finalizar examen") }
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}
