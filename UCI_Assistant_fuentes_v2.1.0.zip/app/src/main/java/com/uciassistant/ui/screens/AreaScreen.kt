package com.uciassistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.uciassistant.ui.nav.Routes
import com.uciassistant.UciApp
import com.uciassistant.ui.components.*
import kotlinx.coroutines.flow.first

/** Temas de un área, con progreso individual (secciones 4.2 y 4.10). */
@Composable
fun AreaScreen(nav: NavController, areaId: String) {
    val app = UciApp.instance
    val topics by app.academy.topicsOfArea(areaId).collectAsState(initial = emptyList())
    val progress by app.academy.progressAll().collectAsState(initial = emptyList())
    var areaName by remember { mutableStateOf("") }

    LaunchedEffect(areaId) {
        // El nombre del área se recupera del primer tema o de la lista completa
        val areas = app.academy.areas().first()
        areaName = areas.firstOrNull { it.id == areaId }?.name ?: "Área"
    }

    Column(Modifier.fillMaxSize()) {
        UciTopBar(areaName.ifEmpty { "Área" }, "${topics.size} temas", onBack = { nav.popBackStack() })
        LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(topics) { t ->
                val p = progress.firstOrNull { it.topicId == t.id }
                UciCard(onClick = { nav.navigate(Routes.topic(t.id)) }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Tema ${t.code}", style = MaterialTheme.typography.labelMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            DifficultyBadge(t.difficulty)
                            if (p?.status == "completed") StatusBadge("Completado", com.uciassistant.ui.theme.UciGreen)
                            else if (p != null) StatusBadge("En curso", MaterialTheme.colorScheme.tertiary)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(t.title, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(4.dp))
                    Text(t.summary, style = MaterialTheme.typography.bodySmall, maxLines = 3)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "≈ ${t.estimatedMinutes} min · versión ${t.version} · estado: ${t.status}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (p != null) {
                        Spacer(Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { (p.completionPercent / 100.0).toFloat() },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}
