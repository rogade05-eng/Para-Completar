package com.uciassistant.search

import com.uciassistant.data.db.AppDatabase

/**
 * Buscador clínico general (sección 3.6 del contrato): localiza herramientas,
 * escalas, temas académicos, preguntas, casos y documentos en un único cuadro.
 * Funciona 100 % local sobre SQLite, sin conexión.
 */
class SearchEngine(private val db: AppDatabase) {

    data class Hit(
        val type: String,      // escala | procedimiento | tema | apartado | pregunta | caso | referencia
        val id: String,
        val title: String,
        val snippet: String,
        val route: String      // ruta de navegación Compose
    )

    suspend fun search(rawQuery: String, limitPerType: Int = 8): List<Hit> {
        val q = rawQuery.trim()
        if (q.length < 2) return emptyList()
        val like = "%$q%"
        val hits = mutableListOf<Hit>()

        // Herramientas clínicas locales (escalas, calculadoras y procedimientos)
        val clinic = com.uciassistant.UciApp.instance.clinic
        val needle = q.lowercase()
        clinic.scales.filter {
            needle in it.name.lowercase() || needle in it.purpose.lowercase()
        }.take(limitPerType).forEach {
            hits.add(Hit("Escala/Calculadora", it.id, it.name, it.purpose, "scale/${it.id}"))
        }
        clinic.procedures.filter {
            needle in it.title.lowercase() || needle in it.purpose.lowercase()
        }.take(limitPerType).forEach {
            hits.add(Hit("Procedimiento", it.id, it.title, it.purpose, "procedure/${it.id}"))
        }

        db.academyDao().searchTopics(like, limitPerType).forEach {
            hits.add(Hit("Tema", it.id, it.title, it.summary, "topic/${it.id}"))
        }
        db.academyDao().searchContents(like, limitPerType).forEach {
            hits.add(Hit("Apartado", "${it.topicId}#${it.id}", it.title, excerpt(it.body, q), "topic/${it.topicId}"))
        }
        db.academyDao().searchQuestions(like, limitPerType).forEach {
            hits.add(Hit("Pregunta", it.questionId, excerpt(it.statement, q, 90), excerpt(it.statement, q), "topic/${it.topicId}?question=${it.questionId}"))
        }
        db.academyDao().searchCases(like, limitPerType).forEach {
            hits.add(Hit("Caso clínico", it.caseId, it.title, it.admissionReason, "case/${it.caseId}"))
        }
        db.academyDao().searchReferences(like, limitPerType).forEach {
            hits.add(Hit("Referencia", it.id, it.citation.take(90), it.source, "bibliografia"))
        }
        return hits
    }

    private fun excerpt(text: String, needle: String, around: Int = 90): String {
        val idx = text.indexOf(needle, ignoreCase = true)
        if (idx < 0) return text.take(around * 2) + if (text.length > around * 2) "…" else ""
        val start = (idx - around).coerceAtLeast(0)
        val end = (idx + needle.length + around).coerceAtMost(text.length)
        return (if (start > 0) "…" else "") + text.substring(start, end) + (if (end < text.length) "…" else "")
    }
}
