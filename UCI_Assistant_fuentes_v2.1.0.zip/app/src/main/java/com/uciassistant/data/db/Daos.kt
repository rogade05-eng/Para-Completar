package com.uciassistant.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface AcademyDao {

    /* Áreas y temas */
    @Query("SELECT * FROM academic_areas ORDER BY sortOrder ASC")
    fun areas(): Flow<List<AcademicAreaEntity>>

    @Query("SELECT * FROM academic_topics WHERE areaId = :areaId ORDER BY code ASC")
    fun topicsOfArea(areaId: String): Flow<List<AcademicTopicEntity>>

    @Query("SELECT * FROM academic_topics ORDER BY code ASC")
    fun allTopics(): Flow<List<AcademicTopicEntity>>

    @Query("SELECT * FROM academic_topics WHERE id = :id")
    suspend fun topic(id: String): AcademicTopicEntity?

    @Query("SELECT COUNT(*) FROM academic_topics")
    suspend fun topicCount(): Int

    /* Búsqueda global (sección 3.6 del contrato) */
    @Query("SELECT * FROM academic_topics WHERE title LIKE :like OR summary LIKE :like ORDER BY code ASC LIMIT :limit")
    suspend fun searchTopics(like: String, limit: Int): List<AcademicTopicEntity>

    @Query("SELECT * FROM academic_contents WHERE title LIKE :like OR body LIKE :like LIMIT :limit")
    suspend fun searchContents(like: String, limit: Int): List<AcademicContentEntity>

    @Query("SELECT * FROM quiz_questions WHERE statement LIKE :like LIMIT :limit")
    suspend fun searchQuestions(like: String, limit: Int): List<QuizQuestionEntity>

    @Query("SELECT * FROM clinical_cases WHERE title LIKE :like OR admissionReason LIKE :like LIMIT :limit")
    suspend fun searchCases(like: String, limit: Int): List<ClinicalCaseEntity>

    @Query("SELECT * FROM content_sources WHERE citation LIKE :like LIMIT :limit")
    suspend fun searchReferences(like: String, limit: Int): List<ReferenceEntity>

    /* Contenidos estructurados (15 apartados, sección 4.3) */
    @Query("SELECT * FROM academic_contents WHERE topicId = :topicId ORDER BY sortIndex ASC")
    suspend fun contentsOfTopic(topicId: String): List<AcademicContentEntity>

    @Query("SELECT * FROM topic_tables WHERE topicId = :topicId")
    suspend fun tablesOfTopic(topicId: String): List<TopicTableEntity>

    /* Preguntas (sección 4.5) */
    @Query("SELECT * FROM quiz_questions WHERE topicId = :topicId ORDER BY questionId ASC")
    suspend fun questionsOfTopic(topicId: String): List<QuizQuestionEntity>

    /** Banco completo de preguntas (Modo Examen global, v1.4.0). */
    @Query("SELECT * FROM quiz_questions WHERE questionType != 'matching' ORDER BY questionId ASC")
    suspend fun allNonMatchingQuestions(): List<QuizQuestionEntity>

    @Query("SELECT * FROM quiz_questions WHERE questionId = :qid")
    suspend fun question(qid: String): QuizQuestionEntity?

    @Query("SELECT COUNT(DISTINCT topicId) FROM quiz_questions")
    suspend fun topicsWithQuestions(): Int

    /* Tarjetas (secciones 4.7 y 4.8) */
    @Query("SELECT * FROM flashcards WHERE topicId = :topicId AND active = 1 ORDER BY id ASC")
    suspend fun cardsOfTopic(topicId: String): List<FlashcardEntity>

    @Query("SELECT * FROM flashcards WHERE id = :id")
    suspend fun card(id: String): FlashcardEntity?

    @Query("SELECT * FROM flashcards WHERE active = 1 ORDER BY id ASC")
    fun allCards(): Flow<List<FlashcardEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReview(review: FlashcardReviewEntity)

    @Query("SELECT MAX(nextReviewDate) FROM flashcard_reviews WHERE flashcardId = :cardId")
    suspend fun lastDueFor(cardId: String): Long?

    @Query("SELECT * FROM flashcard_reviews WHERE flashcardId = :cardId ORDER BY reviewDate DESC LIMIT 1")
    suspend fun lastReview(cardId: String): FlashcardReviewEntity?

    @Query("SELECT COUNT(DISTINCT flashcardId) FROM flashcard_reviews WHERE nextReviewDate <= :now")
    suspend fun dueCards(now: Long): Int

    @Query("SELECT COUNT(DISTINCT r.flashcardId) FROM flashcard_reviews r WHERE r.intervalDays >= 21")
    suspend fun masteredCards(): Int

    /* Casos clínicos (sección 4.6) */
    @Query("SELECT * FROM clinical_cases ORDER BY caseId ASC")
    fun cases(): Flow<List<ClinicalCaseEntity>>

    @Query("SELECT * FROM clinical_cases WHERE caseId = :id")
    suspend fun caseById(id: String): ClinicalCaseEntity?

    /* Referencias */
    @Query("SELECT * FROM content_sources ORDER BY id ASC")
    suspend fun references(): List<ReferenceEntity>

    @Query("SELECT * FROM content_sources WHERE id IN (:ids)")
    suspend fun referencesByIds(ids: List<String>): List<ReferenceEntity>

    /* Progreso (sección 4.10) */
    @Query("SELECT * FROM learning_progress")
    fun progressAll(): Flow<List<LearningProgressEntity>>

    @Query("SELECT * FROM learning_progress WHERE topicId = :topicId")
    suspend fun progressOf(topicId: String): LearningProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProgress(p: LearningProgressEntity)

    @Query("SELECT COUNT(*) FROM learning_progress WHERE status = 'completed'")
    suspend fun completedTopics(): Int

    @Query("SELECT COUNT(*) FROM learning_progress WHERE status = 'in_progress'")
    suspend fun startedTopics(): Int

    /* Intentos de preguntas */
    @Insert
    suspend fun insertAttempt(a: QuizAttemptEntity)

    @Query("SELECT COUNT(*) FROM quiz_attempts")
    suspend fun attemptCount(): Int

    @Query("SELECT COUNT(*) FROM quiz_attempts WHERE correct = 1")
    suspend fun correctCount(): Int

    @Query("SELECT COUNT(*) FROM quiz_attempts WHERE questionId = :qid AND correct = 0")
    suspend fun wrongAttemptsFor(qid: String): Int

    /* Paquete instalado */
    @Query("SELECT * FROM installed_packages ORDER BY installedAt DESC")
    fun packages(): Flow<List<InstalledPackageEntity>>

    @Query("SELECT * FROM installed_packages WHERE packageId = :pid")
    suspend fun installedPackage(pid: String): InstalledPackageEntity?
}

@Dao
interface PersonalDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFavorite(f: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE itemType = :type AND itemId = :itemId")
    suspend fun removeFavorite(type: String, itemId: String)

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE itemType = :type AND itemId = :itemId)")
    suspend fun isFavorite(type: String, itemId: String): Boolean

    @Query("SELECT * FROM favorites ORDER BY createdAt DESC")
    fun favorites(): Flow<List<FavoriteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertNote(n: PersonalNoteEntity): Long

    @Query("DELETE FROM personal_notes WHERE id = :noteId")
    suspend fun deleteNote(noteId: Long)

    @Query("SELECT * FROM personal_notes WHERE targetType = :type AND targetId = :targetId LIMIT 1")
    suspend fun noteFor(type: String, targetId: String): PersonalNoteEntity?

    @Query("SELECT * FROM personal_notes ORDER BY updatedAt DESC")
    fun notes(): Flow<List<PersonalNoteEntity>>

    @Insert
    suspend fun insertSession(s: StudySessionEntity)

    @Query("SELECT COALESCE(SUM(seconds),0) FROM study_sessions")
    fun totalStudySeconds(): Flow<Long>

    @Insert
    suspend fun insertSearch(s: SearchHistoryEntity)

    @Query("SELECT DISTINCT query FROM search_history ORDER BY searchedAt DESC LIMIT :limit")
    suspend fun recentSearches(limit: Int): List<String>
}

/**
 * DAO de importación transaccional (paso 10 de la sección 8 del contrato:
 * «Incorporar los datos mediante transacción SQLite»).
 */
@Dao
interface ImportDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAreas(items: List<AcademicAreaEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTopics(items: List<AcademicTopicEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContents(items: List<AcademicContentEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTables(items: List<TopicTableEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuestions(items: List<QuizQuestionEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFlashcards(items: List<FlashcardEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCases(items: List<ClinicalCaseEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReferences(items: List<ReferenceEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPackage(p: InstalledPackageEntity)

    @Transaction
    suspend fun importAll(
        areas: List<AcademicAreaEntity>,
        topics: List<AcademicTopicEntity>,
        contents: List<AcademicContentEntity>,
        tables: List<TopicTableEntity>,
        questions: List<QuizQuestionEntity>,
        flashcards: List<FlashcardEntity>,
        cases: List<ClinicalCaseEntity>,
        references: List<ReferenceEntity>,
        pkg: InstalledPackageEntity
    ) {
        insertAreas(areas)
        insertTopics(topics)
        insertContents(contents)
        insertTables(tables)
        insertQuestions(questions)
        insertFlashcards(flashcards)
        insertCases(cases)
        insertReferences(references)
        insertPackage(pkg)
    }
}
