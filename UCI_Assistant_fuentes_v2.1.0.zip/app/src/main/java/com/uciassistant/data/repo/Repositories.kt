package com.uciassistant.data.repo

import com.uciassistant.data.db.AppDatabase
import com.uciassistant.data.db.*
import kotlinx.coroutines.flow.Flow
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json

private val json = Json { ignoreUnknownKeys = true; isLenient = true }

/** Repositorio académico: lectura de contenidos, casos, referencias y progreso. */
class AcademyRepository(private val db: AppDatabase) {

    fun areas(): Flow<List<AcademicAreaEntity>> = db.academyDao().areas()
    fun topicsOfArea(areaId: String): Flow<List<AcademicTopicEntity>> = db.academyDao().topicsOfArea(areaId)
    fun allTopics(): Flow<List<AcademicTopicEntity>> = db.academyDao().allTopics()
    suspend fun topic(id: String) = db.academyDao().topic(id)

    suspend fun contentsOf(topicId: String) = db.academyDao().contentsOfTopic(topicId)
    suspend fun tablesOf(topicId: String) = db.academyDao().tablesOfTopic(topicId)
    suspend fun questionsOf(topicId: String) = db.academyDao().questionsOfTopic(topicId)

    /** Banco completo de preguntas sin matching (para el Modo Examen global). */
    suspend fun allExamQuestions(): List<QuizQuestionEntity> = db.academyDao().allNonMatchingQuestions()
    suspend fun cardsOf(topicId: String) = db.academyDao().cardsOfTopic(topicId)
    fun cases(): Flow<List<ClinicalCaseEntity>> = db.academyDao().cases()
    suspend fun caseById(id: String) = db.academyDao().caseById(id)
    suspend fun referencesByIds(ids: List<String>) = db.academyDao().referencesByIds(ids)
    suspend fun references() = db.academyDao().references()

    fun stagesOf(caseEntity: ClinicalCaseEntity): List<com.uciassistant.data.importer.PackageImporter.CaseStage> =
        json.decodeFromString(ListSerializer(com.uciassistant.data.importer.PackageImporter.CaseStage.serializer()), caseEntity.stagesJson)

    fun optionsOf(q: QuizQuestionEntity): List<com.uciassistant.data.importer.PackageImporter.Option> =
        json.decodeFromString(ListSerializer(com.uciassistant.data.importer.PackageImporter.Option.serializer()), q.optionsJson)

    fun correctOf(q: QuizQuestionEntity): List<String> =
        try {
            json.decodeFromString(ListSerializer(String.serializer()), q.correctAnswerJson)
        } catch (_: Exception) {
            emptyList()
        }

    /** Pares [promptId, matchId] para preguntas tipo «matching»; lista vacía si no es de pares. */
    fun correctPairsOf(q: QuizQuestionEntity): List<Pair<String, String>> =
        try {
            json.decodeFromString(
                ListSerializer(ListSerializer(String.serializer())), q.correctAnswerJson
            ).map { it[0] to it[1] }
        } catch (_: Exception) {
            emptyList()
        }

    fun headersOf(t: TopicTableEntity): List<String> =
        json.decodeFromString(ListSerializer(String.serializer()), t.headersJson)

    fun rowsOf(t: TopicTableEntity): List<List<String>> =
        json.decodeFromString(ListSerializer(ListSerializer(String.serializer())), t.rowsJson)

    /* Progreso (sección 4.10): se calcula por actividades reales, no por visitas */
    suspend fun markSectionRead(topicId: String, sectionId: String, totalSections: Int) {
        val existing = db.academyDao().progressOf(topicId)
        val read = existing?.let {
            (json.decodeFromString(ListSerializer(String.serializer()), it.readSectionsJson) + sectionId).distinct()
        } ?: listOf(sectionId)
        val percent = if (totalSections == 0) 0.0 else read.size * 100.0 / totalSections
        val status = if (percent >= 100.0) "completed" else "in_progress"
        db.academyDao().upsertProgress(
            LearningProgressEntity(topicId, status, percent,
                json.encodeToString(ListSerializer(String.serializer()), read),
                System.currentTimeMillis(), System.currentTimeMillis())
        )
    }

    suspend fun markTopicCompleted(topicId: String) {
        val now = System.currentTimeMillis()
        db.academyDao().upsertProgress(
            LearningProgressEntity(topicId, "completed", 100.0,
                json.encodeToString(ListSerializer(String.serializer()),
                    db.academyDao().contentsOfTopic(topicId).map { it.id }),
                now, now)
        )
    }

    fun progressAll(): Flow<List<LearningProgressEntity>> = db.academyDao().progressAll()

    suspend fun recordAttempt(questionId: String, topicId: String, correct: Boolean) {
        db.academyDao().insertAttempt(QuizAttemptEntity(questionId = questionId, topicId = topicId, correct = correct, attemptDate = System.currentTimeMillis()))
    }

    suspend fun recordStudySession(topicId: String, seconds: Long) {
        if (seconds > 0) db.personalDao().insertSession(StudySessionEntity(topicId = topicId, startedAt = System.currentTimeMillis(), seconds = seconds))
    }

    /* Estadísticas del panel académico */
    suspend fun stats(): AcademyStats {
        val attempts = db.academyDao().attemptCount()
        val correct = db.academyDao().correctCount()
        return AcademyStats(
            topicsCompleted = db.academyDao().completedTopics(),
            topicsStarted = db.academyDao().startedTopics(),
            attempts = attempts,
            correctRate = if (attempts == 0) 0.0 else correct * 100.0 / attempts,
            dueCards = db.academyDao().dueCards(System.currentTimeMillis()),
            masteredCards = db.academyDao().masteredCards()
        )
    }
}

data class AcademyStats(
    val topicsCompleted: Int,
    val topicsStarted: Int,
    val attempts: Int,
    val correctRate: Double,
    val dueCards: Int,
    val masteredCards: Int
)

/** Favoritos, notas, historial (sección 5 — Espacio personal). */
class PersonalRepository(private val db: AppDatabase) {
    fun favorites(): Flow<List<FavoriteEntity>> = db.personalDao().favorites()
    fun notes(): Flow<List<PersonalNoteEntity>> = db.personalDao().notes()
    fun studySeconds(): Flow<Long> = db.personalDao().totalStudySeconds()
    fun packages(): Flow<List<InstalledPackageEntity>> = db.academyDao().packages()

    suspend fun toggleFavorite(type: String, itemId: String, label: String) {
        if (db.personalDao().isFavorite(type, itemId)) db.personalDao().removeFavorite(type, itemId)
        else db.personalDao().addFavorite(FavoriteEntity(itemType = type, itemId = itemId, label = label, createdAt = System.currentTimeMillis()))
    }
    suspend fun isFavorite(type: String, itemId: String) = db.personalDao().isFavorite(type, itemId)
    suspend fun noteFor(type: String, targetId: String) = db.personalDao().noteFor(type, targetId)
    suspend fun saveNote(type: String, targetId: String, label: String, body: String) {
        val existing = db.personalDao().noteFor(type, targetId)
        db.personalDao().upsertNote(PersonalNoteEntity(id = existing?.id ?: 0, targetType = type,
            targetId = targetId, targetLabel = label, body = body, updatedAt = System.currentTimeMillis()))
    }
    suspend fun deleteNote(id: Long) = db.personalDao().deleteNote(id)
    suspend fun recordSearch(q: String) {
        if (q.isNotBlank()) db.personalDao().insertSearch(SearchHistoryEntity(query = q.trim(), searchedAt = System.currentTimeMillis()))
    }
    suspend fun recentSearches(limit: Int = 8) = db.personalDao().recentSearches(limit)
}

/** Datos locales de escalas, procedimientos y calculadoras (Fase 4 del contrato). */
class ClinicRepository {
    val scales: List<com.uciassistant.clinical.Scale> = com.uciassistant.clinical.ClinicalScales.all
    val procedures: List<com.uciassistant.clinical.Procedure> = com.uciassistant.clinical.Procedures.all
    val infusionDrugs: List<com.uciassistant.clinical.InfusionDrug> = com.uciassistant.clinical.Infusions.drugs
    fun scale(id: String) = scales.firstOrNull { it.id == id }
    fun procedure(id: String) = procedures.firstOrNull { it.id == id }
    fun infusion(id: String) = infusionDrugs.firstOrNull { it.id == id }
}
