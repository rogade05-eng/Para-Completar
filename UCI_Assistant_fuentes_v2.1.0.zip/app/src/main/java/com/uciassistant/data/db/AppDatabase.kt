package com.uciassistant.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * Base SQLite mediante Room (sección 2.1). Esquema inicial M001_initial_schema +
 * M002_academic_library + M004_quiz_engine + M005_clinical_cases + M006_flashcards
 * fusionados para la primera versión funcional; migraciones futuras numeradas.
 */
@Database(
    entities = [
        AcademicAreaEntity::class,
        AcademicTopicEntity::class,
        AcademicContentEntity::class,
        TopicTableEntity::class,
        QuizQuestionEntity::class,
        FlashcardEntity::class,
        FlashcardReviewEntity::class,
        ClinicalCaseEntity::class,
        ReferenceEntity::class,
        InstalledPackageEntity::class,
        LearningProgressEntity::class,
        QuizAttemptEntity::class,
        FavoriteEntity::class,
        PersonalNoteEntity::class,
        StudySessionEntity::class,
        SearchHistoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun academyDao(): AcademyDao
    abstract fun personalDao(): PersonalDao
    abstract fun importDao(): ImportDao

    companion object {
        fun build(context: Context): AppDatabase =
            Room.databaseBuilder(context, AppDatabase::class.java, "uci_assistant.db")
                .fallbackToDestructiveMigrationOnDowngrade()
                .build()
    }
}
