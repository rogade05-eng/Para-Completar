package com.uciassistant.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Entidades Room — tablas académicas (sección 7.1 del contrato).
 * Claves primarias TEXT (UUID o identificadores estables equivalentes).
 */

@Entity(tableName = "academic_areas")
data class AcademicAreaEntity(
    @PrimaryKey val id: String,
    val packageId: String,
    val name: String,
    val description: String,
    val population: String,
    val sortOrder: Int,
    val active: Boolean = true
)

@Entity(tableName = "academic_topics")
data class AcademicTopicEntity(
    @PrimaryKey val id: String,
    val areaId: String,
    val code: String,
    val title: String,
    val summary: String,
    val difficulty: String,
    val population: String,
    val estimatedMinutes: Int,
    val version: Int,
    val status: String,
    val author: String?,
    val reviewer: String?,
    val lastUpdated: String?
)

@Entity(tableName = "academic_contents")
data class AcademicContentEntity(
    @PrimaryKey val id: String,
    val topicId: String,
    val sectionType: String,
    val title: String,
    val body: String,
    val sortIndex: Int,
    val version: Int,
    val reviewed: Boolean = false
)

@Entity(tableName = "topic_tables")
data class TopicTableEntity(
    @PrimaryKey val id: String,
    val topicId: String,
    val title: String,
    val relatedSection: String,
    val headersJson: String,
    val rowsJson: String,
    val note: String?
)

@Entity(tableName = "quiz_questions")
data class QuizQuestionEntity(
    @PrimaryKey val questionId: String,
    val topicId: String,
    val population: String,
    val difficulty: String,
    val questionType: String,
    val statement: String,
    val optionsJson: String,
    val correctAnswerJson: String,
    val explanation: String,
    val referencesJson: String,
    val author: String?,
    val reviewer: String?,
    val version: Int,
    val status: String
)

@Entity(tableName = "flashcards")
data class FlashcardEntity(
    @PrimaryKey val id: String,
    val topicId: String,
    val question: String,
    val answer: String,
    val explanation: String?,
    val difficulty: String,
    val referenceIdsJson: String,
    val isOfficial: Boolean,
    val ownerId: String?,
    val active: Boolean
)

@Entity(tableName = "flashcard_reviews")
data class FlashcardReviewEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val flashcardId: String,
    val reviewDate: Long,
    val quality: Int,
    val repetitionNumber: Int,
    val easinessFactor: Double,
    val intervalDays: Int,
    val nextReviewDate: Long
)

@Entity(tableName = "clinical_cases")
data class ClinicalCaseEntity(
    @PrimaryKey val caseId: String,
    val packageId: String,
    val title: String,
    val population: String,
    val simulatedAge: String,
    val difficulty: String,
    val estimatedMinutes: Int,
    val learningObjectivesJson: String,
    val clinicalContext: String,
    val admissionReason: String,
    val fictitiousBackgroundJson: String,
    val initialDataSummaryJson: String,
    val complementaryResultsSummaryJson: String,
    val stagesJson: String,
    val referencesJson: String,
    val disclaimer: String?,
    val status: String
)

@Entity(tableName = "content_sources")
data class ReferenceEntity(
    @PrimaryKey val id: String,
    val type: String,
    val year: String,
    val citation: String,
    val source: String,
    val topicsJson: String
)

@Entity(tableName = "installed_packages")
data class InstalledPackageEntity(
    @PrimaryKey val packageId: String,
    val packageVersion: String,
    val applicationMinVersion: String,
    val language: String,
    val populationsJson: String,
    val contentType: String,
    val reviewStatus: String,
    val title: String,
    val description: String,
    val installedAt: Long
)

/* ---------------- Personales (secciones 5 y 7.3) ---------------- */

@Entity(tableName = "learning_progress")
data class LearningProgressEntity(
    @PrimaryKey val topicId: String,
    val status: String,          // in_progress | completed
    val completionPercent: Double,
    val readSectionsJson: String,
    val lastAccess: Long,
    val updatedAt: Long
)

@Entity(tableName = "quiz_attempts")
data class QuizAttemptEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val questionId: String,
    val topicId: String,
    val correct: Boolean,
    val attemptDate: Long
)

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val itemType: String,   // topic | question | flashcard | case | scale | tool
    val itemId: String,
    val label: String,
    val createdAt: Long
)

@Entity(tableName = "personal_notes")
data class PersonalNoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val targetType: String, // topic | case | scale | tool
    val targetId: String,
    val targetLabel: String,
    val body: String,
    val updatedAt: Long
)

@Entity(tableName = "study_sessions")
data class StudySessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val topicId: String,
    val startedAt: Long,
    val seconds: Long
)

@Entity(tableName = "search_history")
data class SearchHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val query: String,
    val searchedAt: Long
)
