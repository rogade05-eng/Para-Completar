package com.uciassistant.data.importer

import android.content.Context
import android.net.Uri
import com.uciassistant.data.db.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.SerialName
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json
import java.io.File

/**
 * Motor de contenidos — ACADEMY_PACKAGE (sección 8 del contrato).
 * Pasos implementados: leer manifiesto → comprobar estructura → verificar
 * integridad → comprobar compatibilidad → validar identificadores → detectar
 * duplicados → comprobar referencias → vista previa → confirmación → transacción.
 *
 * v1.1.0: el origen puede ser el directorio assets (paquete incluido) o un
 * directorio temporal con el contenido de un .zip importado desde el
 * dispositivo (SAF). Corrige además:
 *  · Area.population llega como lista en el paquete v1.0.0.
 *  · El caso clínico puede venir como objeto suelto sin wrapper {"cases":[]}.
 */
class PackageImporter(private val context: Context?, private val db: AppDatabase?) {

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    /** Último incidente de la auto-instalación inicial (para mostrarlo en Paquetes). */
    var lastAutoInstallIssue: String? = null
        private set

    /** Evita lanzar la auto-instalación dos veces en paralelo (App + Activity). */
    private val autoInstallStarted = java.util.concurrent.atomic.AtomicBoolean(false)

    /** Directorio de origen alternativo (importación desde zip); null = assets. */
    private var sourceDir: File? = null

    /* ---------- Lectura de origen (assets o directorio importado) ---------- */

    private fun listJsonFiles(sub: String): List<String> {
        val dir = sourceDir?.let { File(it, "academy/$sub") }
        return if (dir != null) {
            dir.listFiles()?.filter { it.isFile && it.name.endsWith(".json") }?.map { it.name } ?: emptyList()
        } else {
            val ctx = requireNotNull(context) { "Contexto no disponible para leer los assets" }
            (ctx.assets.list("academy/$sub") ?: emptyArray()).filter { it.endsWith(".json") }
        }
    }

    private fun readJson(sub: String): String {
        val dir = sourceDir?.let { File(it, "academy/$sub") }
        return if (dir != null) dir.readText()
        else requireNotNull(context) { "Contexto no disponible para leer los assets" }
            .assets.open("academy/$sub").bufferedReader().use { it.readText() }
    }

    /* ---------- Modelos del paquete (espejo de los JSON) ---------- */

    @Serializable
    data class Manifest(
        @SerialName("package_id") val packageId: String,
        @SerialName("package_version") val packageVersion: String,
        @SerialName("application_min_version") val applicationMinVersion: String = "1.0.0",
        val language: String = "es",
        val populations: List<String> = emptyList(),
        @SerialName("content_type") val contentType: String = "official",
        @SerialName("review_status") val reviewStatus: String = "pending",
        val title: String? = null,
        val description: String? = null,
        @SerialName("created_at") val createdAt: String? = null
    )

    @Serializable
    data class Area(
        val id: String, @SerialName("package_id") val packageId: String,
        val name: String, val description: String,
        // El paquete v1.0.0 trae "population" como lista (["pediatric"]): aceptar ambas formas.
        val population: List<String> = listOf("pediatric"),
        @SerialName("sort_order") val sortOrder: Int = 0, val active: Boolean = true,
        @SerialName("topic_ids") val topicIds: List<String> = emptyList()
    )

    @Serializable
    data class Topic(
        val id: String, @SerialName("area_id") val areaId: String,
        @SerialName("package_id") val packageId: String, val code: String,
        val title: String, val summary: String = "", val difficulty: String,
        val population: List<String> = emptyList(), @SerialName("estimated_minutes") val estimatedMinutes: Int = 30,
        val version: Int = 1, val status: String = "pending_review",
        val author: String? = null, val reviewer: String? = null,
        @SerialName("last_updated") val lastUpdated: String? = null,
        val contents: List<Content> = emptyList(), val tables: List<Table> = emptyList()
    )

    @Serializable
    data class Content(
        @SerialName("section_type") val sectionType: String,
        val title: String, val body: String
    )

    @Serializable
    data class Table(
        val id: String, val title: String,
        @SerialName("related_section") val relatedSection: String = "",
        val headers: List<String> = emptyList(),
        val rows: List<List<String>> = emptyList(),
        val note: String? = null
    )

    @Serializable
    data class Option(val id: String, val text: String)

    @Serializable
    data class Question(
        @SerialName("question_id") val questionId: String, @SerialName("topic_id") val topicId: String,
        val population: String, val difficulty: String, @SerialName("question_type") val questionType: String,
        val statement: String, val options: List<Option> = emptyList(),
        // correct_answer puede ser ["a"] o [["p1","m3"], …] (matching): aceptar ambas formas.
        @SerialName("correct_answer") val correctAnswer: kotlinx.serialization.json.JsonElement =
            kotlinx.serialization.json.JsonArray(emptyList()),
        val explanation: String = "", val references: List<String> = emptyList(),
        val author: String? = null, val reviewer: String? = null, val version: Int = 1,
        val status: String = "pending_review"
    )

    @Serializable
    data class QuestionsFile(
        @SerialName("package_id") val packageId: String? = null,
        val questions: List<Question> = emptyList()
    )

    @Serializable
    data class Flashcard(
        val id: String, @SerialName("topic_id") val topicId: String,
        val question: String, val answer: String, val explanation: String? = null,
        val difficulty: String = "basic", @SerialName("reference_ids") val referenceIds: List<String> = emptyList(),
        @SerialName("is_official") val isOfficial: Boolean = true,
        @SerialName("owner_id") val ownerId: String? = null,
        val active: Boolean = true, val status: String = "pending_review"
    )

    @Serializable
    data class FlashcardsFile(
        @SerialName("package_id") val packageId: String? = null,
        val flashcards: List<Flashcard> = emptyList()
    )

    @Serializable
    data class CaseStage(
        @SerialName("stage_number") val stageNumber: Int,
        @SerialName("stage_title") val stageTitle: String,
        val narrative: String = "",
        val data: List<String> = emptyList(),
        @SerialName("progressive_questions") val progressiveQuestions: List<ProgressiveQuestion> = emptyList()
    )

    @Serializable
    data class ProgressiveQuestion(
        val question: String,
        @SerialName("expected_decisions") val expectedDecisions: List<String> = emptyList(),
        val explanation: String = ""
    )

    @Serializable
    data class Case(
        @SerialName("case_id") val caseId: String, @SerialName("package_id") val packageId: String,
        val title: String, val population: String, @SerialName("simulated_age") val simulatedAge: String = "",
        val difficulty: String = "basic", @SerialName("estimated_minutes") val estimatedMinutes: Int = 25,
        @SerialName("learning_objectives") val learningObjectives: List<String> = emptyList(),
        @SerialName("clinical_context") val clinicalContext: String = "",
        @SerialName("admission_reason") val admissionReason: String = "",
        // El paquete v1.0.0 trae estos tres campos como párrafo string; aceptar string o lista.
        @SerialName("fictitious_background") val fictitiousBackground: kotlinx.serialization.json.JsonElement =
            kotlinx.serialization.json.JsonArray(emptyList()),
        @SerialName("initial_data_summary") val initialDataSummary: kotlinx.serialization.json.JsonElement =
            kotlinx.serialization.json.JsonArray(emptyList()),
        @SerialName("complementary_results_summary") val complementaryResultsSummary: kotlinx.serialization.json.JsonElement =
            kotlinx.serialization.json.JsonArray(emptyList()),
        val stages: List<CaseStage> = emptyList(),
        @SerialName("phoenix_discussion_note") val phoenixDiscussionNote: String? = null,
        val references: List<String> = emptyList(),
        val status: String = "pending_review", val author: String? = null,
        val reviewer: String? = null, val version: Int = 1,
        val disclaimer: String? = null
    )

    /** Normaliza un campo del paquete que puede venir como string o como lista de strings. */
    fun jsonToStringList(e: kotlinx.serialization.json.JsonElement): List<String> = when (e) {
        is kotlinx.serialization.json.JsonArray -> e.mapNotNull { el ->
            (el as? kotlinx.serialization.json.JsonPrimitive)?.content
        }
        is kotlinx.serialization.json.JsonPrimitive -> listOf(e.content)
        else -> emptyList()
    }

    @Serializable
    data class CasesFile(
        @SerialName("package_id") val packageId: String? = null,
        val cases: List<Case> = emptyList()
    )

    @Serializable
    data class Reference(
        val id: String, val type: String, val year: String,
        val citation: String, val source: String = "", val topics: List<String> = emptyList()
    )

    @Serializable
    data class ReferencesFile(val references: List<Reference> = emptyList())

    /* ---------- Resultado de validación (vista previa, pasos 8-9) ---------- */

    data class ValidationIssue(val severity: String, val message: String)

    data class Preview(
        val manifest: Manifest,
        val counts: Map<String, Int>,
        val issues: List<ValidationIssue>,
        val valid: Boolean
    )

    /* ---------- Carga de contenidos desde el origen activo ---------- */

    private fun loadManifest(): Manifest = json.decodeFromString(readJson("manifest.json"))

    private fun loadAreas(): List<Area> = listJsonFiles("areas").map { json.decodeFromString(readJson("areas/$it")) }
    private fun loadTopics(): List<Topic> = listJsonFiles("topics").map { json.decodeFromString(readJson("topics/$it")) }
    private fun loadQuestions(): List<Question> = listJsonFiles("questions").flatMap {
        json.decodeFromString<QuestionsFile>(readJson("questions/$it")).questions
    }
    private fun loadFlashcards(): List<Flashcard> = listJsonFiles("flashcards").flatMap {
        json.decodeFromString<FlashcardsFile>(readJson("flashcards/$it")).flashcards
    }
    private fun loadCases(): List<Case> = listJsonFiles("cases").flatMap {
        val raw = readJson("cases/$it")
        val wrapped = try {
            json.decodeFromString<CasesFile>(raw).cases
        } catch (_: Exception) {
            emptyList()
        }
        // El paquete v1.0.0 guarda el caso como objeto suelto sin wrapper:
        // si el wrapper vino vacío (ignoreUnknownKeys lo acepta), probar el objeto directo.
        if (wrapped.isNotEmpty()) wrapped else listOf(json.decodeFromString<Case>(raw))
    }
    private fun loadReferences(): List<Reference> = listJsonFiles("references").flatMap {
        json.decodeFromString<ReferencesFile>(readJson("references/$it")).references
    }

    suspend fun validateFromAssets(): Preview {
        val issues = mutableListOf<ValidationIssue>()
        val m = try {
            loadManifest()
        } catch (e: Exception) {
            return Preview(Manifest("desconocido", "?"), emptyMap(),
                listOf(ValidationIssue("error", "Manifiesto ilegible: ${e.message}")), false)
        }
        return validate(m, issues)
    }

    private suspend fun validate(m: Manifest, issues: MutableList<ValidationIssue>): Preview {
        // Paso 5 del contrato: comprobar compatibilidad de versión de aplicación
        if (m.applicationMinVersion > "1.0.0") {
            issues.add(ValidationIssue("error", "El paquete requiere aplicación ≥ ${m.applicationMinVersion}"))
        }
        if (m.contentType != "official") {
            issues.add(ValidationIssue("aviso", "content_type = ${m.contentType} (no oficial)"))
        }
        if (m.reviewStatus == "pending") {
            issues.add(ValidationIssue("aviso",
                "Contenido con estado editorial «pending_review»: requiere validación por especialista (sección 17 del contrato)"))
        }

        val areas = mutableListOf<Area>()
        val topics = mutableListOf<Topic>()
        try {
            areas += loadAreas()
            topics += loadTopics()
        } catch (e: Exception) {
            issues.add(ValidationIssue("error", "Estructura de áreas/temas inválida: ${e.message}"))
        }

        val questions = try { loadQuestions() } catch (e: Exception) {
            issues.add(ValidationIssue("error", "Preguntas ilegibles: ${e.message}")); emptyList() }
        val flashcards = try { loadFlashcards() } catch (e: Exception) {
            issues.add(ValidationIssue("error", "Tarjetas ilegibles: ${e.message}")); emptyList() }
        val cases = try { loadCases() } catch (e: Exception) {
            issues.add(ValidationIssue("error", "Casos ilegibles: ${e.message}")); emptyList() }
        val references = try { loadReferences() } catch (e: Exception) {
            issues.add(ValidationIssue("error", "Referencias ilegibles: ${e.message}")); emptyList() }

        // Paso 5 del contrato: validar identificadores (formato y unicidad)
        val allIds = mutableListOf<Pair<String, String>>()
        fun reg(kind: String, id: String) = allIds.add(kind to id)
        areas.forEach { reg("area", it.id) }
        topics.forEach { reg("topic", it.id) }
        topics.forEach { t -> t.contents.forEach { reg("content", "${t.id}#${it.sectionType}") } }
        questions.forEach { reg("question", it.questionId) }
        flashcards.forEach { reg("flashcard", it.id) }
        cases.forEach { reg("case", it.caseId) }
        references.forEach { reg("reference", it.id) }

        val duplicated = allIds.groupBy { it.second }.filter { it.value.size > 1 }
        duplicated.forEach { (id, kinds) ->
            issues.add(ValidationIssue("error", "Identificador duplicado: $id (${kinds.joinToString { it.first }})"))
        }
        allIds.filter { it.second.isBlank() || it.second.length < 4 }
            .forEach { issues.add(ValidationIssue("error", "Identificador inválido: «${it.second}»")) }

        // Paso 6: comprobar referencias cruzadas
        val topicIds = topics.map { it.id }.toSet()
        val areaIds = areas.map { it.id }.toSet()
        val refIds = references.map { it.id }.toSet()
        topics.filter { it.areaId !in areaIds }.forEach {
            issues.add(ValidationIssue("error", "El tema ${it.id} apunta al área inexistente ${it.areaId}"))
        }
        questions.filter { it.topicId !in topicIds }.forEach {
            issues.add(ValidationIssue("error", "La pregunta ${it.questionId} apunta al tema inexistente ${it.topicId}"))
        }
        flashcards.filter { it.topicId !in topicIds }.forEach {
            issues.add(ValidationIssue("error", "La tarjeta ${it.id} apunta al tema inexistente ${it.topicId}"))
        }
        questions.flatMap { q -> q.references.filter { it !in refIds }.map { q.questionId to it } }
            .forEach { (qid, r) -> issues.add(ValidationIssue("aviso", "Pregunta $qid cita la referencia inexistente $r")) }

        // Paso 7 del contrato (4.5): una pregunta sin respuesta validada no puede publicarse
        questions.filter {
            val ca = it.correctAnswer
            ca !is kotlinx.serialization.json.JsonArray || ca.isEmpty() || it.explanation.isBlank()
        }.forEach { issues.add(ValidationIssue("error", "La pregunta ${it.questionId} no tiene respuesta validada o explicación suficiente")) }

        // Detectar paquetes ya instalados (integridad: no sobrescribir datos personales)
        if (db != null) {
            val installed = db.academyDao().installedPackage(m.packageId)
            if (installed != null && installed.packageVersion >= m.packageVersion) {
                issues.add(ValidationIssue("aviso", "El paquete ${m.packageId} v${installed.packageVersion} ya está instalado (se reinstalará con REPLACE)"))
            }
        }

        val counts = mapOf(
            "areas" to areas.size, "temas" to topics.size,
            "apartados" to topics.sumOf { it.contents.size },
            "tablas" to topics.sumOf { it.tables.size },
            "preguntas" to questions.size, "tarjetas" to flashcards.size,
            "casos" to cases.size, "referencias" to references.size
        )
        val valid = issues.none { it.severity == "error" }
        return Preview(m, counts, issues, valid)
    }

    /* ---------- Paso 10: incorporación mediante transacción SQLite ---------- */

    suspend fun installFromAssets(preview: Preview): Boolean = install(preview)

    suspend fun install(preview: Preview): Boolean {
        if (!preview.valid) return false
        val database = requireNotNull(db) { "Base de datos no disponible en este contexto de prueba" }
        val m = preview.manifest
        val areas = loadAreas()
        val topics = loadTopics()
        val questions = loadQuestions()
        val flashcards = loadFlashcards()
        val cases = loadCases()
        val references = loadReferences()

        val areaEntities = areas.map {
            AcademicAreaEntity(it.id, it.packageId, it.name, it.description,
                it.population.joinToString(",").ifBlank { "pediatric" }, it.sortOrder, it.active)
        }
        val topicEntities = topics.map {
            AcademicTopicEntity(it.id, it.areaId, it.code, it.title, it.summary, it.difficulty,
                it.population.joinToString(","), it.estimatedMinutes, it.version, it.status,
                it.author, it.reviewer, it.lastUpdated)
        }
        val contentEntities = topics.flatMap { t ->
            t.contents.mapIndexed { idx, c ->
                AcademicContentEntity("${t.id}_${c.sectionType}", t.id, c.sectionType, c.title, c.body, idx, t.version,
                    reviewed = t.status == "approved")
            }
        }
        val tableEntities = topics.flatMap { t ->
            t.tables.map { tb ->
                TopicTableEntity(tb.id, t.id, tb.title, tb.relatedSection,
                    json.encodeToString(ListSerializer(String.serializer()), tb.headers),
                    json.encodeToString(ListSerializer(ListSerializer(String.serializer())), tb.rows),
                    tb.note)
            }
        }
        val questionEntities = questions.map {
            QuizQuestionEntity(it.questionId, it.topicId, it.population, it.difficulty, it.questionType,
                it.statement,
                json.encodeToString(ListSerializer(Option.serializer()), it.options),
                it.correctAnswer.toString(),
                it.explanation,
                json.encodeToString(ListSerializer(String.serializer()), it.references),
                it.author, it.reviewer, it.version, it.status)
        }
        val flashcardEntities = flashcards.map {
            FlashcardEntity(it.id, it.topicId, it.question, it.answer, it.explanation, it.difficulty,
                json.encodeToString(ListSerializer(String.serializer()), it.referenceIds),
                it.isOfficial, it.ownerId, it.active)
        }
        val caseEntities = cases.map {
            ClinicalCaseEntity(it.caseId, it.packageId, it.title, it.population, it.simulatedAge, it.difficulty,
                it.estimatedMinutes,
                json.encodeToString(ListSerializer(String.serializer()), it.learningObjectives),
                it.clinicalContext, it.admissionReason,
                json.encodeToString(ListSerializer(String.serializer()), jsonToStringList(it.fictitiousBackground)),
                json.encodeToString(ListSerializer(String.serializer()), jsonToStringList(it.initialDataSummary)),
                json.encodeToString(ListSerializer(String.serializer()), jsonToStringList(it.complementaryResultsSummary)),
                json.encodeToString(stagesSerializer(), it.stages),
                json.encodeToString(ListSerializer(String.serializer()), it.references),
                it.disclaimer, it.status)
        }
        val refEntities = references.map {
            ReferenceEntity(it.id, it.type, it.year, it.citation, it.source,
                json.encodeToString(ListSerializer(String.serializer()), it.topics))
        }
        val pkgEntity = InstalledPackageEntity(m.packageId, m.packageVersion, m.applicationMinVersion,
            m.language, json.encodeToString(ListSerializer(String.serializer()), m.populations),
            m.contentType, m.reviewStatus, m.title ?: m.packageId, m.description ?: "", System.currentTimeMillis())

        database.importDao().importAll(areaEntities, topicEntities, contentEntities, tableEntities,
            questionEntities, flashcardEntities, caseEntities, refEntities, pkgEntity)
        return true
    }

    /* ---------- Auto-instalación idempotente del paquete incluido ---------- */

    /**
     * Instalación/actualización idempotente del paquete incluido.
     *  · Biblioteca vacía → valida e instala (primera apertura).
     *  · Biblioteca con contenido → si la versión del paquete incluido en assets
     *    es MÁS NUEVA que la instalada, actualiza en silencio (REPLACE por fila,
     *    conserva el progreso personal: learning_progress, intentos y notas).
     * Se invoca desde UciApp.onCreate y desde MainActivity; el flag evita carreras.
     * Devuelve true si la biblioteca tiene temas al finalizar.
     */
    suspend fun tryAutoInstallIfNeeded(): Boolean {
        val database = db ?: return false
        if (context == null) return false
        if (database.academyDao().topicCount() > 0) {
            // Nueva puerta v1.3.0: actualizar el paquete incluido si el asset es más reciente.
            return try {
                val m = loadManifest()
                val installed = database.academyDao().installedPackage(m.packageId)
                if (installed == null || installed.packageVersion < m.packageVersion) {
                    val preview = validateFromAssets()
                    if (preview.valid && installFromAssets(preview)) {
                        android.util.Log.i("UciImporter",
                            "Paquete incluido actualizado a v${m.packageVersion}: ${preview.counts}")
                    } else {
                        android.util.Log.w("UciImporter",
                            "Actualización del paquete incluido no aplicada: ${preview.issues}")
                        lastAutoInstallIssue = "Actualización no aplicada: " +
                            preview.issues.joinToString(" · ") { it.message }
                    }
                }
                true
            } catch (e: Exception) {
                android.util.Log.e("UciImporter", "Error al comprobar la actualización del paquete", e)
                true // la biblioteca ya tiene contenido: la app sigue funcionando
            }
        }
        if (!autoInstallStarted.compareAndSet(false, true)) {
            // Otra corrutina ya está instalando: esperar a que existan temas.
            return database.academyDao().topicCount() > 0
        }
        return try {
            if (database.academyDao().topicCount() == 0) {
                val preview = validateFromAssets()
                if (preview.valid) {
                    val ok = installFromAssets(preview)
                    android.util.Log.i("UciImporter", "Auto-instalación del paquete incluido: ok=$ok ${preview.counts}")
                    if (!ok) lastAutoInstallIssue = "La instalación del paquete incluido devolvió ok=false"
                } else {
                    android.util.Log.w("UciImporter", "Validación del paquete incluido con errores: ${preview.issues}")
                    lastAutoInstallIssue = "La validación del paquete incluido devolvió: " +
                        preview.issues.joinToString(" · ") { it.message }
                }
            }
            database.academyDao().topicCount() > 0
        } catch (e: Exception) {
            android.util.Log.e("UciImporter", "Error en la auto-instalación inicial", e)
            lastAutoInstallIssue = "Error de instalación inicial: ${e.message}"
            autoInstallStarted.set(false) // permite reintentarlo desde Paquetes
            false
        }
    }

    /* ---------- Importación desde un .zip del dispositivo (SAF) ---------- */

    /**
     * Copia el zip elegido a caché, extrae el contenido de academy/ a un
     * directorio temporal y valida. Devuelve la vista previa; la instalación
     * se realiza después con installFromImported(preview).
     */
    fun extractZipToCache(uri: Uri): File {
        val ctx = requireNotNull(context) { "Contexto no disponible" }
        val stamp = System.currentTimeMillis()
        val zipFile = File(ctx.cacheDir, "import_$stamp.zip")
        ctx.contentResolver.openInputStream(uri)!!.use { input ->
            zipFile.outputStream().use { output -> input.copyTo(output) }
        }
        val dest = File(ctx.cacheDir, "import_$stamp")
        dest.mkdirs()
        java.util.zip.ZipInputStream(zipFile.inputStream().buffered()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                var name = entry.name
                // Normalizar: ignorar la carpeta raíz del zip si la hay
                val normalized = name.removePrefix("./")
                val rel = when {
                    normalized.startsWith("academy/") -> normalized
                    else -> normalized.substringAfter("academy/", "")
                }
                if (rel.isNotEmpty()) {
                    val outFile = File(dest, "academy/$rel")
                    if (entry.isDirectory) {
                        outFile.mkdirs()
                    } else {
                        outFile.parentFile?.mkdirs()
                        outFile.outputStream().use { zis.copyTo(it) }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        zipFile.delete()
        return dest
    }

    suspend fun validateImportedDir(dir: File): Preview {
        sourceDir = dir
        return try {
            val issues = mutableListOf<ValidationIssue>()
            val m = try {
                loadManifest()
            } catch (e: Exception) {
                return Preview(Manifest("desconocido", "?"), emptyMap(),
                    listOf(ValidationIssue("error", "El .zip no contiene un paquete académico válido (academy/manifest.json): ${e.message}")), false)
            }
            validate(m, issues)
        } finally {
            sourceDir = null
        }
    }

    suspend fun installImportedDir(dir: File, preview: Preview): Boolean {
        sourceDir = dir
        return try {
            install(preview)
        } finally {
            sourceDir = null
        }
    }

    /** Serializador público para etapas del caso (reutilizable al leer el caso). */
    fun stagesSerializer() = ListSerializer(CaseStage.serializer())
}
