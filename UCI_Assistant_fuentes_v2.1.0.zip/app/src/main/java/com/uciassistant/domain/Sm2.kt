package com.uciassistant.domain

/**
 * Repetición espaciada SM-2 (sección 4.8 del contrato).
 * Algoritmo local, configurable y documentado; sin conexión a Internet.
 *
 * Calidad usada por la interfaz (4 botones):
 *  No recordada → 1 · Difícil → 3 · Correcta con esfuerzo → 4 · Fácil → 5
 */
object Sm2 {

    const val MIN_EASINESS = 1.3

    data class Result(
        val repetitionNumber: Int,
        val easinessFactor: Double,
        val intervalDays: Int,
        val nextReviewDate: Long
    )

    fun next(
        quality: Int,
        previousRepetition: Int = 0,
        previousEasiness: Double = 2.5,
        previousInterval: Int = 0,
        now: Long = System.currentTimeMillis()
    ): Result {
        require(quality in 0..5) { "quality fuera de rango 0..5" }
        val day = 86_400_000L

        // EF' = EF + (0.1 − (5 − q) × (0.08 + (5 − q) × 0.02)), mínimo 1.3
        val q = quality.toDouble()
        val ef = (previousEasiness + (0.1 - (5 - q) * (0.08 + (5 - q) * 0.02))).coerceAtLeast(MIN_EASINESS)

        return if (quality < 3) {
            // Respuesta incorrecta: reiniciar secuencia, repetir al día siguiente
            Result(0, ef, 1, now + day)
        } else {
            val (rep, interval) = when (previousRepetition) {
                0 -> 1 to 1
                1 -> 2 to 6
                else -> {
                    val r = previousRepetition + 1
                    val i = Math.round(previousInterval * ef).coerceAtLeast(previousInterval.toLong() + 1).toInt()
                    r to i
                }
            }
            Result(rep, ef, interval, now + interval * day)
        }
    }

    /** Etiquetas legibles del intervalo para la interfaz. */
    fun humanInterval(days: Int): String = when {
        days <= 0 -> "hoy"
        days == 1 -> "mañana"
        days < 30 -> "en $days días"
        days < 365 -> "en ${"%.1f".format(days / 30.0)} meses"
        else -> "en ${"%.1f".format(days / 365.0)} años"
    }
}
