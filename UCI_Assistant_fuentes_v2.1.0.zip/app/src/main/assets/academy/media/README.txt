UCI Assistant - Paquete académico uci_academy_fundamentos_pediatria v2.1.0
===========================================================================

Carpeta media/
---------------
Recursos gráficos de apoyo incrustados en los temas (sección 2.2 y 13.2 del
contrato técnico). Formato PNG de 1080 px de ancho, optimizado para lectura
en dispositivos Android de recursos modestos.

Inventario (archivo · tema ancla · peso · procedencia/licencia):

- diag_area_01_evaluacion.png · topic_fped_001 · 178 KB · Elaboración propia UCI Assistant 2026 · uso educativo interno
- diag_area_02_ventilacion.png · topic_fped_007 · 187 KB · Elaboración propia UCI Assistant 2026 · uso educativo interno
- diag_area_03_shock.png · topic_fped_009 · 193 KB · Elaboración propia UCI Assistant 2026 · uso educativo interno
- diag_area_04_neurocritico.png · topic_fped_012 · 211 KB · Elaboración propia UCI Assistant 2026 · uso educativo interno
- diag_area_05_metabolico.png · topic_fped_014 · 214 KB · Elaboración propia UCI Assistant 2026 · uso educativo interno
- diag_area_06_hemato.png · topic_fped_027 · 212 KB · Elaboración propia UCI Assistant 2026 · uso educativo interno
- diag_area_07_infecciones.png · topic_fped_047 · 221 KB · Elaboración propia UCI Assistant 2026 · uso educativo interno

Los archivos se referencian desde apartados section_type = "figure" de los
temas JSON (body = nombre de archivo). Ningún recurso procede de terceros;
todos son esquemas de elaboración propia sin licencias externas.
