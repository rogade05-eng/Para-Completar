# Reglas R8 — UCI Assistant
# Room
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-dontwarn androidx.room.paging.**

# kotlinx-serialization (modelos del paquete académico)
-keepattributes *Annotation*, InnerClasses, RuntimeVisibleAnnotations
-dontnote kotlinx.serialization.**
-keep,includedescriptorclasses class kotlinx.serialization.** { *; }
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
    kotlinx.serialization.KSerializer serializer(...);
}
-keepclassmembers class com.uciassistant.** {
    *** Companion;
}
-keepclasseswithmembers class com.uciassistant.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.uciassistant.**$$serializer { *; }

# Coroutines
-dontwarn kotlinx.coroutines.**
