# Changelog

## [2.7.0] — 2026-11-05

### Añadido (módulos de estudio y docencia)
- **Escuela de Residentes** (pestaña Escuela): 12 áreas de anestesiología con
  60 fichas de estudio (Definición → Puntos clave → Cifras y dosis → Errores
  frecuentes → Repaso exprés) y 72 preguntas de autoevaluación con respuesta
  inmediata y explicación, filtrables por nivel de residencia (R1–R4) y con
  progreso local por área.
- **Módulo pedagógico del especialista/tutor** (pestaña Tutor): organizador de
  contenidos por área, catálogo de 10 métodos docentes con guía de uso y
  evaluación, bibliografías por área y núcleo del programa, **elaborador de
  exámenes** (banco filtrable por áreas y niveles, exportación a PDF con clave
  de respuestas separada) y **generador de guías de estudio** exportables en
  PDF y Word.
- **Escalas nuevas (20 en 6 grupos)**: Escala de Apfel (riesgo de NVPO 0–4 →
  %), Escala de Fragilidad Clínica (CFS, 9 puntos), NYHA y Capacidad funcional
  (METs) — huecos detectados en la auditoría de contenido.
- **Calculadoras nuevas (15)**: Función renal (Cockcroft-Gault con ajuste por
  sexo e interpretación para ajustar dosis) y Ecografía gástrica (fórmula de
  Perlas con riesgo de broncoaspiración en mL/kg).
- **Tema clínico nuevo**: «Verificación de estudios preoperatorios» (validez
  temporal de 90 días, coherencia clínica, ECG/eco, espirometría, coagulación
  pre-neuraxial, laboratorio, radiografía y cadena de información).
- Licencias: nuevas funciones `school` (Básica+) y `tutor` (Profesional+).

### Reparación de la base (restauración v2.6.2 verificada)
- Fuente v2.6.2 restaurada desde ZIP con SHA-256 verificado
  (`69f199d4…5e21a96f`) y reparada: strings faltantes (101 es / 17 en-pt),
  capa de localización `*_RAW` + accesores dinámicos, modelo ConsentDoc v2.5,
  motor TCI (Marsh/Schnider/Minto) y ventilación ampliada, jeringa perfusora y
  dosis neuraxial, 4 presentaciones de fármacos hasta cubrir los 45, ASA en
  expediente/análisis (CaseStats). Suite: 229 → **238 pruebas en verde**.

### Nota de versionado
- El hotfix de tamaño planificado como 2.6.3 se absorbe aquí: `abiFilters`
  arm64-v8a/armeabi-v7a incluido de serie (APK ~11–12 MB). El simulador de
  crisis y la traducción completa del contenido clínico pasan a **2.8.0**.

## [2.6.2] — 2026-11-02
# CHANGELOG — Cronos Anestesia

Formato basado en [Keep a Changelog](https://keepachangelog.com/es-ES/1.1.0/)
y versionado según [SemVer](https://semver.org/lang/es/). El contenido clínico
se versiona aparte («Contenido clínico vX», visible en Ajustes, contrato §10.1).

## [2.1.0] — 2026-10-24

### Añadido
- **Escalas: 16 en 6 grupos** (antes 6 sin grupos). La pestaña Escalas ahora
  se organiza por grupos con encabezado:
  - *Valoración preoperatoria*: ASA, RCRI (Lee), **ARISCAT** (nueva),
    **STOP-Bang** (nueva).
  - *Vía aérea*: Mallampati modificada, **Cormack-Lehane** (nueva).
  - *Sedación y conciencia*: **RASS** (nueva), Ramsay, Glasgow.
  - *Dolor*: **EVA 0–10** (nueva, paciente que puede comunicarse) y
    **CPOT** (nueva, paciente crítico no comunicable).
  - *Recuperación*: **Aldrete modificada** (nueva), **PADSS** (nueva).
  - *Paciente crítico*: **SOFA** (nueva), **APACHE II** (nueva),
    **CAM-ICU** (nueva).
  - NYHA sale del catálogo (es una clasificación funcional, no una escala
    del grupo pedido); sigue citada en el contenido de cardiopatía.
  - En demostración siguen libres las 2 primeras escalas.
- **Bomba TCI (11.ª calculadora)**: infusión con diana por modelos
  farmacocinéticos de 3 compartimentos con sitio efecto:
  - Propofol: **Marsh** (solo peso) o **Schnider** (edad/talla/sexo);
    Remifentanilo: **Minto** (LBM de Janmahasatian).
  - Diana en **plasma (Cp)** o **sitio efecto (Ce)**; concentraciones de
    jeringa habituales (propofol 1 %/5/20 mg/mL; remi 50/25/20/10 µg/mL).
  - Esquema **BET exacto** (bolo–eliminación–transferencia): bolo inicial
    (mg y mL), velocidad inicial, tabla de decaimiento a 0/1/2/5/10/15/20/
    30/45/60 min, volumen acumulado a 60 min, Ce estimada por ke0 y t90.
  - Guardado en el expediente del paciente activo.
- **Clínica → Equipamiento (6.º apartado, 43 temas clínicos)**: dos temas
  nuevos — «Jeringas perfusoras» (uso seguro, preparación, cambio de jeringa
  sin bolo accidental, alarmas de oclusión, errores frecuentes,
  elastoméricas/PCA) y «Bombas de infusión y TCI» (tipos de bomba,
  funcionamiento TCI, TCI con jeringa manual, seguridad y doble chequeo,
  espacio muerto, fallas).

### Cambiado
- Contadores y manual actualizados (11 calculadoras, 16 escalas en 6 grupos,
  43 temas clínicos); manual: 45 fármacos con buscador y preparación.

## [2.0.1] — 2026-10-24

### Corregido
- **«Solicitar licencia por WhatsApp» no mostraba el botón de envío** (reporte
  de campo): el botón «Enviar por WhatsApp» vivía al final del contenido del
  diálogo, que en pantallas pequeñas se recortaba (sin desplazamiento
  vertical) y solo quedaba visible «Cerrar»; además el botón quedaba
  deshabilitado hasta rellenar el teléfono.
  - El contenido del diálogo ahora **se desplaza verticalmente** en cualquier
    pantalla.
  - **«Enviar por WhatsApp» es un botón fijo del pie del diálogo, siempre
    visible y siempre activo** (al lado de «Cerrar»); si WhatsApp no está
    disponible cae al selector «Compartir» como antes.
  - El teléfono pasa a **opcional** (aviso informativo): el mensaje llega
    igual y el número del cliente viaja con el propio chat de WhatsApp; si se
    escribe, se incluye en la solicitud para identificar la transferencia.
  - «Copiar solicitud» también quedó siempre activo.
- Misma corrección aplicada a «Ya pagué: enviar confirmación por WhatsApp»
  en Tarifas (botones siempre activos, teléfono opcional; si falta, la
  confirmación dice «(no indicado)»).

## [2.0.0] — 2026-10-22

### Añadido
- **Perlas clínicas (13)** — nueva pestaña con lecciones accionables de
  guardia y perioperatorio, elaboradas por Cronos Anestesia a partir de la
  temática de los videos del canal educativo **Medik Brain** (Cristian
  González, médico general; el canal se acredita en cada perla y en Ajustes).
  Incluye la lección del video viral «Intubación exitosa… pero 5 minutos
  después el paciente hace paro cardíaco» (colapso hemodinámico
  post-intubación con sus 4 claves), desaturación post-intubación (DOPE),
  programación del ventilador, TEP agudo, taponamiento cardíaco, disección
  aórtica, hemorragia posparto, hipertensión intracraneal, hemorragia
  subaracnoidea, hiperkalemia, tormenta tiroidea, choque cardiogénico y
  cetoacidosis euglucémica (SGLT2). Estructura por perla: resumen, claves
  de acción, errores comunes, señales de alarma y aplicación en anestesia.
  Abierta a todos los usuarios (con Licencia o en demostración).
- **14 temas quirúrgicos PRO+** en Clínica → «Temas quirúrgicos» (41 temas
  clínicos en total): Paciente neuroquirúrgico, Traumatismo craneoencefálico
  (TCE), Tumores supratentoriales, Tumores infratentoriales, Hemodilución,
  Trasplante, Embarazo crítico, Cardiopatía congénita adulta, Fisiología
  respiratoria aplicada, Fisiología cardiovascular aplicada, Cirugía cardíaca
  con CEC, Trauma en masa, Ventilación unipulmonar (OLV) y Videocirugía
  (laparoscopía). Cada tema con pautas de 6 secciones.
- **11 calculadoras de temas** embebidas en el detalle (con guardado en el
  expediente): CPP (PAM−PIC), ANH (volumen extraíble + sangrado permitido),
  MELD-Na con mortalidad, MgSO4 (carga/mantenimiento/mL/h), Qp/Qs por
  oximetría, fisiología respiratoria (CaO2, gradiente A–a con límite por
  edad, P/F, DO2), fisiología cardiovascular (CO, SVR, PVR, lectura rápida),
  CEC (BSA/flujo de bomba/heparina/protamina), trauma (unidades de CGR +
  MTP 1:1:1 + TXA), OLV (IBW → VT/FR + corrección por EtCO2) y laparoscopía
  (ajuste de FR por EtCO2 + alerta de presión de insuflación >15 mmHg).
- **Infusión por fármaco (45)** — calculadora nueva en Calculadoras:
  - **Buscador** por nombre, alias comercial o clase.
  - **Ficha de preparación** de los 45 fármacos: solvente, dilución,
    concentración final y estabilidad (el «plus» clínico pedido).
  - **Modos de administración** por fármaco: bolo IV, perfusión continua y
    jeringa perfusora, con la técnica de cada modo.
  - Cálculo de velocidad de bomba (mL/h y mg/h) con concentración editable.
- **Expediente del paciente (Básica+)** — nueva pestaña: ficha del paciente
  (nombre, CI, edad, sexo, peso, altura, antecedentes), lista de pacientes
  con paciente activo, guardado de cálculos desde cualquier calculadora
  («Guardar en expediente») y **exportación PDF/Excel (CSV)** local con
  FileProvider (sin permiso de red; se comparte con cualquier app).
- **Consentimiento informado anestésico (Básica+)** — documento oficial y
  explícito: marco legal (Ley No. 156 «De la Salud Pública» de Cuba 2022,
  Declaración de Helsinki), identificación del paciente/profesional,
  descripción del procedimiento, **riesgos generales + específicos por
  técnica (general, neuraxial, sedación, bloqueo periférico) + graves
  excepcionales con frecuencias**, beneficios, alternativas, derechos del
  paciente, declaración de voluntariedad y bloques de firma (paciente,
  anestesiólogo, testigo). Se completa con los datos del expediente y se
  exporta a PDF (A4 multipágina con PdfDocument nativo).
- **Bibliografía ampliada de 6 a 24 referencias** con énfasis cardiológico
  solicitado: Braunwald 12.ª, ESC cirugía no cardíaca 2022, ACC/AHA 2024,
  Kaplan's Cardiac Anesthesia 8.ª, Hurst's the Heart 15.ª, Andropoulos
  (congénitas), Chestnut (obstétrica), Cote & Lerman (pediátrica), MGH
  Pocket, Gaba (crisis), MHAUS, manuales del MINSAP, Revista Cubana y
  revistas internacionales (Anesthesiology, BJA, A&A, REDAR).
- Crédito del canal educativo en Ajustes → Información; contenido clínico
  v3 · octubre 2026.

### Técnico
- `LicenseFeatures` +1 funcionalidad (`expediente`: Básica en adelante).
- `CalcEngine` +18 funciones puras con 17 pruebas nuevas (92 en total, en
  verde): PAM, CPP, ANH, MELD-Na, Qp/Qs, CaO2, DO2, Fick, SVR, PVR, BSA,
  flujo de bomba, heparina, CGR, MgSO4, FR sugerida y corrección por EtCO2.
- Pruebas de cobertura: DRUG_PREP (45/45), SURGICAL_TOPICS (14, con
  calcIds válidos), PEARLS (13), BIBLIO (24), consentimiento (estructura
  legal completa y ≥17 riesgos por técnica), deep links nuevos
  (cronos://expediente, cronos://perlas).
- FileProvider (`cu.cronos.anestesia.fileprovider`) para compartir PDF/CSV
  del caché: el APK sigue **sin permiso INTERNET** (verificado con aapt).

## [1.6.0] — 2026-10-22

### Añadido
- **Tarifas y formas de pago dentro de la app** (diálogo «Tarifas y formas de
  pago», accesible desde Inicio, cada sección bloqueada y Ajustes → Licencia):
  desglose de precios por nivel (Básica / Profesional / Institucional) y
  duración (**Mensual / Trimestral / Anual / Perpetua**), con equivalente
  mensual y % de ahorro de los planes multi-mes. Precios de referencia en USD
  y negociables: estudiantes/residentes/instituciones pueden acordar condiciones
  por WhatsApp.
- **Flujo «pague primero, reciba después»**: el cliente paga, confirma por
  WhatsApp con su **teléfono** (referencia para identificar quién hizo la
  transferencia), el comprobante y el plan; recibe la clave CRONOS1.… y la
  activa en Ajustes. Los mensajes de solicitud y confirmación viajan con el
  teléfono, el ID del dispositivo y la moneda usada.
- **Dos cuentas receptoras** (constantes en `Tariffs.kt`, un solo lugar):
  - CUP — Transfermóvil `9234 0699 9251 1687`, con **calculadora de importe**:
    el cliente introduce la tasa del día y la app multiplica (sin conexión).
    Aviso destacado: **el cambio de dólar a CUP depende de la tasa según
    elTOQUE (eltoque.com) del día de la transferencia**; la app no aplica
    ninguna tasa por sí sola.
  - USD — Tarjeta Clásica `9760 0390 0356 7228`, precio exacto del plan
    **sin conversión**.
- **Formas de pago** en la solicitud (chips): Transfermóvil (CUP), Tarjeta
  Clásica (USD), Efectivo (a conveniar) e Internacional (vía a negociar por
  WhatsApp: transferencia, Zelle, PayPal, criptomonedas u otra disponible).
- Botones «Ya pagué: enviar confirmación por WhatsApp» y «Copiar
  confirmación», con copia de cada cuenta al portapapeles (un toque).
- 12 pruebas unitarias nuevas (TariffsTest + ampliación de LicenseContactTest):
  75 en total.

### Cambiado
- La solicitud de licencia (v1.5.2) ahora exige un teléfono válido (8–15
  dígitos) y añade chips de duración y forma de pago; el mensaje resultante
  llega al desarrollador listo para emitir la clave (--dias 30/90/365 o
  perpetua) y saber qué transferencia buscar.

## [1.5.2] — 2026-10-21

### Añadido
- **Solicitud de licencia por WhatsApp** (+53 5530 1268), sin permisos nuevos:
  la app sigue 100 % offline (R-01); solo lanza un intent hacia WhatsApp y la
  red la maneja la aplicación externa elegida. Diálogo con nombre del titular,
  organismo y nivel deseado (Básica/Profesional/Institucional) que arma el
  mensaje con la versión y el ID del dispositivo (XXXX-XXXX-XXXX-XXXX) para
  emitir claves atadas al equipo. Si WhatsApp no está instalado, ofrece el
  selector «Compartir» (Telegram, SMS, correo) y siempre permite copiar la
  solicitud al portapapeles. Puntos de acceso: Inicio (línea bajo el badge en
  modo demo), cada tarjeta de sección bloqueada y Ajustes → Licencia y
  activación.
- **Crédito del desarrollador**: «Desarrollado por: Ronald García Deroncele»
  con contacto directo por WhatsApp (toque para escribir) en Ajustes →
  Información, y firma en la portada de 3 segundos.
- 7 pruebas unitarias nuevas del módulo de solicitud (63 en total).

## [1.5.1] — 2026-10-21

### Corregido
- **Crash crítico en Android 10–12 al verificar licencias con caracteres
  codificados** (reporte de campo: Xiaomi M2006C3LG, Android 10). El
  decodificador de la carga de licencia usaba
  `ByteArrayOutputStream.toString(Charset)`, método de Java 10 que solo existe
  en Android desde la API 33: en Android 10/11/12 lanzaba `NoSuchMethodError`
  y cerraba la app al activar una clave o abrir contenido cuya licencia lleva
  espacios/acentos (p. ej. «Hospital Universitario Ejemplo» → `%20`).
  Reemplazado por `String(byte[], Charset)`, disponible desde la API 1.
  Sin cambio de formato de licencias ni de claves: las claves ya emitidas
  siguen siendo válidas.
- Auditoría de compatibilidad: barrido de APIs de Java 8–11
  (`readAllBytes`, `String.repeat`, `List.of`, `java.util.Base64`, etc.)
  sin más usos inseguros para minSdk 24; `java.time` sigue cubierto por
  core library desugaring.

## [1.5.0] — 2026-10-20

### Añadido
- **Sistema de licencias offline** (ECDSA P-256, sin INTERNET): la app se
  distribuye en modo demostración y se desbloquea pegando una clave
  `CRONOS1.carga.firma` firmada por el desarrollador en Ajustes → Licencia y
  activación. La firma (SHA256withECDSA) se verifica contra una clave pública
  incrustada; modificar un byte invalida la clave.
- **Cuatro niveles de licencia**: Demostración (muestra gratuita con
  Emergencias y gases siempre disponibles por seguridad), Básica (uso diario
  completo), Profesional (+ clínica avanzada de 27 temas) e Institucional
  (Profesional perpetua con nombre de institución). Gating en todas las
  secciones: fármacos (10 de 45 en demo), dosis calculada por peso/edad,
  9 calculadoras, 6 escalas, 14 complicaciones, premedicación, soluciones,
  clínica y bibliografía, con tarjetas de bloqueo que llevan a la activación.
- **Vinculación opcional a dispositivo**: hash SHA-256 del ANDROID_ID
  (16 hex, sin permisos nuevos); la licencia atada a un equipo no funciona en
  otro. El ID se muestra al cliente en Ajustes.
- **Anti-reempaquetado**: la app compara el SHA-256 de su certificado de firma
  con el original; ante un APK alterado se fuerza modo demostración con aviso
  rojo (fail-open solo si el sistema no permite leer la firma).
- **Herramienta del desarrollador** `scripts/cronos_license_tool.py`
  (keygen/issue/verify/show/list + auditoría CSV) y manual completo
  `docs/LICENCIAS.md`. Licencias de ejemplo emitidas (PRO 1 año, INST
  perpetua, BAS atada a dispositivo de prueba).
- **15 pruebas unitarias nuevas** del verificador de licencias (firma válida,
  caducidad, perpetuidad, vinculación y normalización de dispositivo, carga
  manipulada, firma ajena, claves malformadas, tolerancia al pegado con
  saltos de línea, percent-encoding ida y vuelta, base64url).

## [1.4.0] — 2026-10-20

### Añadido
- **Calculadora de dosis por fármaco (peso + edad)**: cada fármaco muestra ahora
  una sección «Dosis calculada (peso y edad)»: se introduce el peso (kg) y la
  edad (años o meses) una sola vez (se guardan en DataStore y se precargan en
  todos los fármacos) y la app calcula en vivo bolos, infusiones y regímenes de
  sedación/analgesia con velocidad de bomba en mL/h según la dilución elegida.
- **DoseEngine** (motor puro, sin Android/Compose, con pruebas): 13 unidades de
  dosificación (mg/kg, µg/kg/min, mg/kg/h, U/kg, U/min, mg/min, dosis fijas…),
  conversión a caudal horario y mL/h, límites absolutos (topes adulto/pediátrico)
  y selección automática de rangos pediátricos por edad (< 12 años, límite
  configurable por régimen) con filtrado de regímenes por ámbito de edad.
- **6 fármacos vasoactivos nuevos** (39 → 45): Noradrenalina (Norepinefrina),
  Dopamina, Dobutamina, Milrinona, Vasopresina y Nitroglicerina, con ficha
  clínica completa y dosificación calculable (diluciones estándar de bomba:
  noradrenalina 4 mg/250 mL, dopamina 400 mg/250 mL, dobutamina 250 mg/250 mL,
  milrinona 20 mg/100 mL, vasopresina 20 U/50 mL, GTN 10 mg/100 mL…).
- **Perfiles de dosificación de los 45 fármacos** (DoseProfiles.kt): rangos
  referenciales con notas clínicas (titulación, diluyente, extravasación,
  ajuste renal…), diluciones alternativas seleccionables por chips (bolsa vs.
  jeringa) y avisos neonatales para edad < 1 mes.
- **13 pruebas unitarias nuevas** (41 en total): vectores dorados de noradrenalina
  (26,25 mL/h), dopamina, dobutamina, propofol TIVA, remifentanilo, adrenalina
  (tope de anafilaxia), vasopresina no ponderal, heparina, sugammadex, topes
  pediátricos de midazolam, filtrado por edad y cobertura 45/45 de perfiles.

### Cambiado
- Pantalla de detalle de fármaco reordenada: primero la dosis calculada, luego
  la ficha de dosificación, indicaciones y precauciones.
- Contadores actualizados a 45 fármacos en Inicio y Ajustes.

## [1.3.0] — 2026-10-19

### Añadido
- **Portada de bienvenida de 3 s**: motivo «tiempo y latido» (reloj de Cronos
  con manecilla que completa una vuelta en 3 s y trazo ECG animado), degradado
  teal de marca, textos escalonados, barra de progreso y salto con un toque.
- **Registro cifrado de contenido (Room + SQLCipher)**: base `cronos_content.db`
  cifrada en reposo con clave aleatoria protegida por AndroidKeyStore (AES-GCM);
  tablas `content_meta` y `content_history`; registro idempotente de la versión
  de contenido con historial de actualizaciones; estado visible en Ajustes;
  degradación elegante si el dispositivo no soporta el almacén.
- **Deep links internos** (contrato §11.3): `cronos://inicio`, `cronos://emergencias`,
  `cronos://farmacos`, `cronos://gases`, `cronos://calculadoras`, `cronos://escalas`,
  `cronos://complicaciones`, `cronos://premedicacion`, `cronos://soluciones`,
  `cronos://clinica`, `cronos://bibliografia`, `cronos://ajustes`.
- **Pruebas unitarias con vectores dorados** de las 9 calculadoras (28 casos:
  Holliday-Segar, 2-4-6-8, infusión, Devine, tubo pediátrico, volemia/sangrado,
  gasometría + Berlín, dosis máximas de anestésicos locales, deep links).
- **Artefactos de release**: SBOM CycloneDX 1.5, documentación C4, adenda
  técnica, `mapping.txt` y `SHA256SUMS.txt` (contrato §13).
- Repositorio Git con Conventional Commits y `CHANGELOG.md`.

### Cambiado
- **CalcEngine**: toda la lógica numérica de las calculadoras vive ahora en un
  motor puro sin dependencias de Android/Compose (contrato §9.2); la UI solo
  formatea resultados.
- **Cadenas de interfaz** migradas a recursos (`res/values/strings.xml`,
  español por defecto): pestañas, inicio, ajustes, secciones de detalle,
  nombres de calculadoras y escalas (contrato §9.2, capa de navegación).
- **Profundidad del tubo pediátrico**: la profundidad labial muestra ahora el
  valor exacto de la fórmula `12 + edad/2` (p. ej. 12,5 cm a 1 año) en lugar
  de redondear a entero con «half-to-even».
- Repositorio de configuración leído desde `gradle.properties`
  (`org.gradle.java.home`) para builds reproducibles.

### Corregido
- Aserción no nula `detail!!` en la navegación de detalles: ahora se
  desenpaqueta de forma segura (Fase 3 del plan de adecuación).

## [1.2.0] — 2026-10-18

### Añadido
- Fase 1 del plan de adecuación: 6 protocolos de emergencia (ACLS adulto, PALS
  pediátrico, anafilaxia, hipertermia maligna, LAST, vía aérea difícil/CICO)
  con acceso en ≤2 toques (contrato §8.2); calculadora de dosis máxima de
  anestésicos locales (8 fármacos, ±adrenalina, adulto/pediátrico); manual de
  usuario embebido (Ajustes → Manual de usuario).
- Fase 2: 27 temas clínicos nuevos (8 comorbilidades con ajustes de dosis,
  8 bloqueos regionales, 7 de monitorización, 4 del plan preoperatorio).
- Pestañas «Emergencias» y «Clínica»; botón de emergencia destacado en rojo.
- `contentVersion` visible («Contenido clínico v2 · octubre 2026»).

## [1.0.5] — 2026-10-18

### Corregido
- Pestañas y acápites pegados al borde superior: la raíz aplica ahora
  `windowInsetsPadding(WindowInsets.safeDrawing)` con edge-to-edge.

### Añadido
- 5 calculadoras nuevas (infusión continua, peso ideal + VT protegido, tubo
  pediátrico, sangrado máximo permitido, gasometría P/F + gradiente A–a).

## [1.0.4] — 2026-10-18

### Corregido
- Alineación de botones: `AppButton` centralizado, filas con pesos idénticos,
  tarjetas de lista uniformes y barras de detalle centradas.
