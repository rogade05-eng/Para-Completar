package cu.cronos.anestesia

/*
 * ============================================================================
 *  ESTUDIO v2.7.0 — «Escuela de Residentes» + «Módulo Pedagógico del Tutor»
 *  · RoGaDe Software · contenido clínico del Dr. Romay Díaz Deroncele ·
 *  100 % offline: todo el contenido vive en la app, el progreso en el teléfono.
 *
 *  ESCUELA DE RESIDENTES (pestaña Escuela): 12 áreas temáticas con fichas
 *  de estudio (Definición → Puntos clave → Cifras y dosis → Errores
 *  frecuentes → Repaso exprés), autoevaluación con respuesta inmediata y
 *  progreso local. Etiquetas R1–R4 (años de residencia) en cada pregunta.
 *
 *  MÓDULO PEDAGÓGICO DEL TUTOR (pestaña Tutor): herramienta docente para el
 *  especialista que dirige residentes — organizador de contenidos, catálogo
 *  de métodos docentes, bibliografías por área, elaborador de exámenes con
 *  exportación (PDF/Word) y generador de guías de estudio.
 *
 *  El residente estudia y se autoevalúa en la Escuela; el tutor planifica y
 *  evalúa con el mismo banco de contenido. Nada se duplica.
 * ============================================================================
 */

import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.io.File

// ------------------------------ MODELOS ------------------------------

/** Ficha de estudio de la Escuela de Residentes. */
data class StudyCard(
    val title: String,
    val definition: String,      // Definición / qué es
    val keyPoints: List<String>, // Puntos clave
    val figures: List<String>,   // Cifras y dosis
    val mistakes: List<String>,  // Errores frecuentes
    val express: String          // Repaso exprés (memorizable en 10 s)
)

/** Pregunta de autoevaluación / banco del tutor. */
data class StudyQuestion(
    val q: String,
    val options: List<String>,
    val correct: Int,            // índice 0..n-1
    val explanation: String,
    val levels: List<String>     // subconjunto de R1..R4
)

/** Área temática de la Escuela de Residentes. */
data class StudyArea(
    val id: String,
    val name: String,
    val desc: String,
    val cards: List<StudyCard>,
    val questions: List<StudyQuestion>,
    val bibliography: List<String>
) {
    val cardCount: Int get() = cards.size
    val questionCount: Int get() = questions.size
}

/** Método docente del catálogo del tutor. */
data class TeachingMethod(
    val name: String,
    val whenToUse: String,
    val how: List<String>,
    val evaluation: String
)

/** Catálogo completo de áreas (datos en StudyData1/2.kt). */
val STUDY_AREAS: List<StudyArea> = STUDY_AREAS_1 + STUDY_AREAS_2

// ------------------------------ MÉTODOS DOCENTES (catálogo del tutor) ------------------------------

val TEACHING_METHODS: List<TeachingMethod> = listOf(
    TeachingMethod(
        "Clase interactiva",
        "Introducir un tema nuevo a un grupo (R1–R2) con base conceptual.",
        listOf(
            "Objetivo único por sesión (60 min)",
            "Preguntas dirigidas cada 10 min",
            "Cerrar con las fichas «Repaso exprés» del área"
        ),
        "Cuestionario de 5 preguntas del banco al final."
    ),
    TeachingMethod(
        "Discusión de caso real",
        "Integrar decisiones clínicas; ideal para R2–R3 en rotación de quirófano.",
        listOf(
            "Caso del servicio anonimizado (expte. de la app)",
            "El residente expone el plan y las alternativas",
            "El tutor cuestiona con «¿qué haría si…?»",
            "Cierre: puntos clave y errores frecuentes de la ficha"
        ),
        "Rúbrica de decisión clínica (identifica, prioriza, planifica)."
    ),
    TeachingMethod(
        "Demostración técnica y práctica supervisada",
        "Adquisición de destrezas: bloqueos, laringoscopía, manejo de máquina.",
        listOf(
            "Demostración breve (5 min) con los esquemas de la app",
            "Práctica del residente con guía paso a paso",
            "Retroalimentación inmediata, una destreza por sesión"
        ),
        "Checklist de la destreza (la pestaña Checklist sirve de guía)."
    ),
    TeachingMethod(
        "Simulación in situ",
        "Crisis poco frecuentes y de alta severidad: anafilaxia, HM, LAST, CICO.",
        listOf(
            "Escenario breve (10 min) con los protocolos de la pestaña Emergencias",
            "Roles asignados (anestesiólogo, ayuda, enfermería)",
            "Debriefing de 15 min: qué funcionó y qué se retrasó"
        ),
        "Lista de tiempos críticos (adrenalina <5 min, dantroleno <10 min)."
    ),
    TeachingMethod(
        "Tutoría bedside (enseñanza al lecho)",
        "Integrar examen físico y plan anestésico en el paciente real.",
        listOf(
            "Preparación: objetivos del día y consentimiento del paciente",
            "Examen dirigido por el residente",
            "Retroalimentación fuera del box"
        ),
        "Mini-CEX: 4 dominios (anamnesis, examen, plan, comunicación)."
    ),
    TeachingMethod(
        "Journal club",
        "Lectura crítica y actualización bibliográfica (R3–R4).",
        listOf(
            "Artículo central de la bibliografía del área",
            "PICO + validez + aplicabilidad local",
            "Conclusión: ¿cambia la práctica del servicio?"
        ),
        "Presentación con rúbrica de lectura crítica."
    ),
    TeachingMethod(
        "Presentación del residente",
        "Consolidar conocimiento y comunicación (R3–R4).",
        listOf(
            "Tema del programa (Temario R1–R4 de la app)",
            "15 min + 10 min de preguntas del grupo",
            "Apoyo: fichas y esquemas de la aplicación"
        ),
        "Evaluación de contenido y claridad por el grupo."
    ),
    TeachingMethod(
        "Supervisión escalonada (graduated autonomy)",
        "Progresión de la responsabilidad por caso según nivel y complejidad.",
        listOf(
            "R1: observa y hace bajo supervisión directa",
            "R2: ejecuta casos estándar con supervisión cercana",
            "R3: casos complejos con supervisión disponible",
            "R4: supervisa a R1–R2 y lidera la crisis simulada"
        ),
        "Entrevista de rotación: metas, casos logrados y brechas."
    ),
    TeachingMethod(
        "Autoevaluación guiada (Escuela de Residentes)",
        "Refuerzo semanal individual con retroalimentación inmediata.",
        listOf(
            "El residente hace la autoevaluación del área (app)",
            "Tutor revisa el resultado y las explicaciones falladas",
            "Plan de refuerzo: fichas señaladas"
        ),
        "Puntaje del área + registro de progreso en la app."
    ),
    TeachingMethod(
        "Examen formal del módulo del Tutor",
        "Evaluación sumativa de la rotación o del programa.",
        listOf(
            "Generar examen por áreas y niveles (sección Examen)",
            "Aplicar en impreso o en pantalla",
            "Revisar las preguntas falladas con las explicaciones"
        ),
        "Calificación y devolución escrita; guardar en el expediente."
    )
)

// ------------------------------ MOTOR ------------------------------

object StudyEngine {

    /** Niveles de residencia admitidos. */
    val LEVELS = listOf("R1", "R2", "R3", "R4")

    /** Filtra preguntas por niveles: incluye CUALQUIERA de los niveles pedidos (vacío = todos). */
    fun questionsFor(area: StudyArea, levels: List<String>): List<StudyQuestion> =
        if (levels.isEmpty() || levels.size == 4) area.questions
        else area.questions.filter { q -> q.levels.any { it in levels } }

    /** Preguntas de un banco (áreas seleccionadas) filtradas por nivel. */
    fun examPool(areas: List<StudyArea>, levels: List<String>): List<StudyQuestion> =
        areas.flatMap { questionsFor(it, levels) }.distinctBy { it.q }

    /**
     * Selección determinista de n preguntas (barajado con semilla):
     * mismo día + misma selección → mismo examen (reproducible en papel).
     */
    fun pickQuestions(pool: List<StudyQuestion>, n: Int, seed: Long): List<StudyQuestion> {
        if (pool.isEmpty() || n <= 0) return emptyList()
        val rnd = java.util.Random(seed)
        return pool.shuffled(rnd).take(minOf(n, pool.size))
    }

    private fun qBlocks(q: StudyQuestion, i: Int, withAnswers: Boolean): List<Pair<String, Int>> = buildList {
        add("${i + 1}. ${q.q}" to 2)
        q.options.forEachIndexed { j, opt ->
            add("   ${"ABCD"[j.coerceIn(0, 3)]}) $opt" to 2)
        }
        if (withAnswers) {
            add("Respuesta correcta: ${"ABCD"[q.correct.coerceIn(0, 3)]}. ${q.explanation}" to 2)
        }
    }

    /** Bloques del examen: (texto, estilo 0 título / 1 encabezado / 2 cuerpo). */
    fun examBlocks(title: String, header: String, questions: List<StudyQuestion>, withAnswers: Boolean): List<Pair<String, Int>> =
        buildList {
            add(title to 0)
            add(header to 2)
            if (withAnswers) add("CLAVE DEL TUTOR — respuestas y justificación" to 1)
            else add("Marque la opción correcta (una sola respuesta por pregunta)." to 1)
            questions.forEachIndexed { i, q -> addAll(qBlocks(q, i, withAnswers)) }
        }

    /** Bloques de la guía de estudio de un área para un nivel dado. */
    fun guideBlocks(area: StudyArea, levels: List<String>, weeks: Int, tutor: String): List<Pair<String, Int>> {
        val qs = questionsFor(area, levels)
        return buildList {
            add("Guía de estudio — ${area.name}" to 0)
            add(
                "Rotación de anestesiología · ${levels.ifEmpty { LEVELS }.joinToString("/")} · $weeks semana(s) · " +
                    "Tutor: ${tutor.ifBlank { "___________" }}" to 2
            )
            add("1. Objetivos de aprendizaje" to 1)
            area.cards.forEachIndexed { i, c -> add("• ${i + 1}. ${c.title}" to 2) }
            add("2. Contenidos (fichas de la Escuela de Residentes)" to 1)
            area.cards.forEach { c ->
                add(c.title to 2)
                add(c.definition to 2)
                add("Puntos clave: " + c.keyPoints.joinToString(" · ") to 2)
            }
            add("3. Material de la aplicación (offline)" to 1)
            add(
                "Fichas del área (${area.cardCount}) en la pestaña Escuela · temas clínicos relacionados en la " +
                    "pestaña Clínica · calculadoras asociadas para practicar casos · checklist OMS y anestésica " +
                    "para la rotación de quirófano." to 2
            )
            add("4. Método docente sugerido" to 1)
            add(
                "Sesión semanal de 60–90 min: 15 min de repaso exprés (fichas), 30 min de discusión del caso y " +
                    "datos, 20 min de demostración o simulación si aplica, 15 min de preguntas del banco con " +
                    "respuesta inmediata." to 2
            )
            add("5. Autoevaluación (niveles " + levels.ifEmpty { LEVELS }.joinToString("/") + ")" to 1)
            add(
                "Banco del área: ${qs.size} pregunta(s) seleccionables. Recomendado: 5 por sesión y un examen " +
                    "generado en la sección Examen al cierre de la rotación." to 2
            )
            add("6. Bibliografía" to 1)
            area.bibliography.forEach { add("• $it" to 2) }
            add("Documento generado offline por Cronos Anestesia — el tutor puede editarlo al imprimirlo." to 2)
        }
    }

    // ---------------- progreso local (SharedPreferences) ----------------
    private const val PREFS = "estudio_progreso"

    /** Guarda el mejor puntaje de la autoevaluación (área, aciertos, total). */
    fun saveProgress(ctx: Context, areaId: String, correct: Int, total: Int) {
        if (total <= 0) return
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val best = sp.getInt("best_$areaId", -1)      // aciertos ×1000 + total
        val cur = correct * 1000 + total
        if (cur > best) sp.edit().putInt("best_$areaId", cur).apply()
        sp.edit().putLong("last_$areaId", System.currentTimeMillis()).apply()
    }

    /** Mejor resultado (aciertos, total) o null si nunca se hizo. */
    fun bestScore(ctx: Context, areaId: String): Pair<Int, Int>? {
        val v = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("best_$areaId", -1)
        return if (v < 0) null else (v / 1000) to (v % 1000)
    }

    fun lastTs(ctx: Context, areaId: String): Long =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong("last_$areaId", 0L)

    fun areasAttempted(ctx: Context): Int = STUDY_AREAS.count { bestScore(ctx, it.id) != null }
}

// ------------------------------ BIBLIOGRAFÍA NÚCLEO DEL TUTOR ------------------------------

val TUTOR_CORE_BIBLIO = listOf(
    "Morgan GE, Mikhail MS, Murray MJ. Clinical Anesthesiology. 7.ª ed. McGraw-Hill, 2022.",
    "Miller RD et al. (eds.). Miller's Anesthesia. 10.ª ed. Elsevier, 2024.",
    "Smith I, Aitkenhead AR, Thompson J, Rowbottom M. Aitkenhead & Smith's Textbook of Anaesthesia. 8.ª ed. Elsevier, 2024.",
    "Barash PG et al. Clinical Anesthesia. 9.ª ed. Wolters Kluwer, 2021.",
    "Hagberg CA. Benumof & Hagberg's Airway Management. 5.ª ed. Elsevier, 2024.",
    "Longnecker DE et al. Anesthesiology. 3.ª ed. McGraw-Hill, 2023.",
    "Gan TJ et al. Fourth Consensus Guidelines for the Management of Postoperative Nausea and Vomiting. Anesth Analg. 2020;131(2):411-448.",
    "OMS. Lista OMS de verificación de la seguridad quirúrgica. 2009 (manual de implementación)."
)

// ------------------------------ UI: ESCUELA DE RESIDENTES ------------------------------

@Composable
fun StudyTab() {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    var openArea by rememberSaveable { mutableStateOf<String?>(null) }
    var quizArea by rememberSaveable { mutableStateOf<String?>(null) }

    when {
        quizArea != null -> StudyQuizScreen(
            area = STUDY_AREAS.first { it.id == quizArea },
            onBack = { quizArea = null }
        )
        openArea != null -> StudyAreaScreen(
            area = STUDY_AREAS.first { it.id == openArea },
            onQuiz = { quizArea = openArea },
            onBack = { openArea = null }
        )
        else -> {
            val done = StudyEngine.areasAttempted(ctx)
            Column(
                Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = sp.screenHPad.dp)
                    .padding(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(sp.s.dp)
            ) {
                Spacer(Modifier.height(sp.xs.dp))
                Text(
                    "Escuela de Residentes — ${STUDY_AREAS.size} áreas de anestesiología con " +
                        "${STUDY_AREAS.sumOf { it.cardCount }} fichas de estudio y ${STUDY_AREAS.sumOf { it.questionCount }} " +
                        "preguntas de autoevaluación. Progreso: $done/${STUDY_AREAS.size} áreas evaluadas.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                STUDY_AREAS.forEach { a ->
                    val best = StudyEngine.bestScore(ctx, a.id)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { openArea = a.id },
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(Modifier.padding(sp.m.dp)) {
                            Text(a.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(2.dp))
                            Text(
                                "${a.cardCount} fichas · ${a.questionCount} preguntas · " +
                                    if (best != null) "mejor resultado ${best.first}/${best.second}" else "sin autoevaluar",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(a.desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StudyAreaScreen(area: StudyArea, onQuiz: () -> Unit, onBack: () -> Unit) {
    val sp = LocalSpacing.current
    var openCard by rememberSaveable { mutableStateOf(-1) }
    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = sp.screenHPad.dp)
            .padding(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(sp.s.dp)
    ) {
        DetailTopBar(area.name, null, onBack)
        Text(area.desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        AppButton("Autoevaluación (${area.questionCount} preguntas)", onClick = onQuiz)
        Text("Fichas de estudio", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        area.cards.forEachIndexed { i, c ->
            val open = openCard == i
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (open) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
                )
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clickable { openCard = if (open) -1 else i }
                        .padding(sp.m.dp)
                ) {
                    Text("${i + 1}. ${c.title}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text(
                        "Repaso exprés: " + c.express,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    if (open) {
                        Spacer(Modifier.height(6.dp))
                        StudyBlock("Definición", c.definition)
                        StudyBlock("Puntos clave", c.keyPoints.joinToString("\n") { "•  $it" })
                        StudyBlock("Cifras y dosis", c.figures.joinToString("\n") { "•  $it" })
                        StudyBlock("Errores frecuentes", c.mistakes.joinToString("\n") { "•  $it" })
                    }
                }
            }
        }
        Text("Bibliografía del área", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        area.bibliography.forEach {
            Text("•  $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Composable
private fun StudyBlock(header: String, body: String) {
    Text(header, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
    Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
    Spacer(Modifier.height(4.dp))
}

@Composable
private fun StudyQuizScreen(area: StudyArea, onBack: () -> Unit) {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    var levels by rememberSaveable { mutableStateOf(setOf<String>()) }
    var started by rememberSaveable { mutableStateOf(false) }
    var idx by rememberSaveable { mutableStateOf(0) }
    var picked by rememberSaveable { mutableStateOf(-1) }
    var score by rememberSaveable { mutableStateOf(0) }
    var finished by rememberSaveable { mutableStateOf(false) }

    val pool = remember(area.id, levels) { StudyEngine.questionsFor(area, levels.toList()) }
    val q = if (idx < pool.size) pool[idx] else null

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = sp.screenHPad.dp)
            .padding(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(sp.s.dp)
    ) {
        DetailTopBar("Autoevaluación", area.name, onBack)
        if (!started) {
            Text("Elija los niveles de residencia (vacío = todos):", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
                StudyEngine.LEVELS.forEach { lv ->
                    val on = lv in levels
                    AppButton(lv, secondary = !on, modifier = Modifier.weight(1f),
                        onClick = { levels = if (on) levels - lv else levels + lv })
                }
            }
            AppButton("Comenzar (${pool.size} preguntas)", onClick = {
                if (pool.isNotEmpty()) { idx = 0; picked = -1; score = 0; started = true; finished = false }
            })
        } else if (q != null && !finished) {
            Text(
                "Pregunta ${idx + 1} de ${pool.size} · niveles ${q.levels.joinToString("/")}",
                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary
            )
            Text(q.q, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            q.options.forEachIndexed { j, opt ->
                val isCorrect = j == q.correct
                val chosen = picked == j
                val color = when {
                    picked < 0 -> MaterialTheme.colorScheme.surface
                    isCorrect -> MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                    chosen -> MaterialTheme.colorScheme.error.copy(alpha = 0.12f)
                    else -> MaterialTheme.colorScheme.surface
                }
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(enabled = picked < 0) {
                            picked = j
                            if (isCorrect) score++
                        },
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = color)
                ) {
                    Text("${"ABCD"[j]}) $opt", Modifier.padding(sp.m.dp), style = MaterialTheme.typography.bodySmall)
                }
            }
            if (picked >= 0) {
                val ok = picked == q.correct
                Text(
                    (if (ok) "✔ Correcto. " else "✘ Incorrecto — correcta: ${"ABCD"[q.correct]}. ") + q.explanation,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                AppButton(
                    if (idx + 1 < pool.size) "Siguiente" else "Terminar",
                    onClick = {
                        if (idx + 1 < pool.size) { idx++; picked = -1 }
                        else { finished = true; StudyEngine.saveProgress(ctx, area.id, score, pool.size) }
                    }
                )
            }
        } else {
            val pct = if (pool.isEmpty()) 0 else score * 100 / pool.size
            Text(
                "Resultado: $score de ${pool.size} ($pct %). " +
                    (if (pct >= 80) "Excelente." else if (pct >= 60) "Aprobado — revise las fichas señaladas." else "Repase las fichas del área y repita la autoevaluación."),
                style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold
            )
            AppButton("Repetir", secondary = true, onClick = {
                started = false; idx = 0; picked = -1; score = 0; finished = false
            })
        }
    }
}

// ------------------------------ UI: MÓDULO PEDAGÓGICO DEL TUTOR ------------------------------

@Composable
fun TutorTab() {
    val sp = LocalSpacing.current
    var section by rememberSaveable { mutableStateOf(0) }
    val sections = listOf("Contenidos", "Métodos", "Examen", "Guías")
    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = sp.screenHPad.dp)
            .padding(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(sp.s.dp)
    ) {
        Spacer(Modifier.height(sp.xs.dp))
        Text(
            "Módulo pedagógico del especialista: organice contenidos, materiales, métodos y bibliografías; " +
                "elabore exámenes y guías de estudio a partir del mismo banco de contenido de la Escuela.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        SegmentedRow(sections, section) { section = it }
        when (section) {
            0 -> TutorContentsSection()
            1 -> TutorMethodsSection()
            2 -> TutorExamSection()
            else -> TutorGuideSection()
        }
    }
}

@Composable
private fun TutorContentsSection() {
    val sp = LocalSpacing.current
    var openArea by rememberSaveable { mutableStateOf(0) }
    val area = STUDY_AREAS[openArea]
    Column(verticalArrangement = Arrangement.spacedBy(sp.s.dp)) {
        Text("Organizador de contenidos: 12 áreas → fichas y preguntas del banco.", style = MaterialTheme.typography.bodySmall)
        SegmentedRow(STUDY_AREAS.map { it.id.uppercase() }, openArea) { openArea = it }
        Text(area.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        area.cards.forEach { c ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(sp.s.dp)) {
                    Text(c.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text(c.definition, style = MaterialTheme.typography.bodySmall, maxLines = 3)
                    Text(
                        "${c.keyPoints.size} puntos clave · ${c.figures.size} cifras · ${c.mistakes.size} errores frecuentes",
                        style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
        Text(
            "Banco de preguntas: ${area.questionCount}. Use la sección Examen para generar y exportar.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun TutorMethodsSection() {
    val sp = LocalSpacing.current
    Column(verticalArrangement = Arrangement.spacedBy(sp.s.dp)) {
        Text("Métodos docentes aplicables a la especialidad (cuándo y cómo usarlos):", style = MaterialTheme.typography.bodySmall)
        TEACHING_METHODS.forEach { m ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(sp.s.dp)) {
                    Text(m.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text("Cuándo: " + m.whenToUse, style = MaterialTheme.typography.bodySmall)
                    Text("Cómo: " + m.how.joinToString(" → "), style = MaterialTheme.typography.bodySmall)
                    Text("Evaluar: " + m.evaluation, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
        Text("Bibliografía núcleo (consérvela en el programa de la rotación):", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
        TUTOR_CORE_BIBLIO.forEach { Text("•  $it", style = MaterialTheme.typography.bodySmall) }
        Text("Bibliografía por área: disponible en cada área de la Escuela.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun TutorExamSection() {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    var chosen by rememberSaveable { mutableStateOf(setOf<String>()) }
    var levels by rememberSaveable { mutableStateOf(setOf<String>()) }
    var count by rememberSaveable { mutableStateOf(10) }
    var preview by rememberSaveable { mutableStateOf(false) }

    val areas = if (chosen.isEmpty()) STUDY_AREAS else STUDY_AREAS.filter { it.id in chosen }
    val pool = remember(chosen, levels) { StudyEngine.examPool(areas, levels.toList()) }
    val seed = remember { System.currentTimeMillis() / 86_400_000L }
    val picked = remember(chosen, levels, count) { StudyEngine.pickQuestions(pool, count, seed) }

    Column(verticalArrangement = Arrangement.spacedBy(sp.s.dp)) {
        Text("Elabore el examen: áreas (vacío = todas), niveles R1–R4 y cantidad.", style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            StudyEngine.LEVELS.forEach { lv ->
                val on = lv in levels
                AppButton(lv, secondary = !on, modifier = Modifier.weight(1f),
                    onClick = { levels = if (on) levels - lv else levels + lv })
            }
        }
        Text("Áreas (vacío = todas):", style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            listOf(0, 1).forEach { col ->
                Column(Modifier.weight(1f)) {
                    STUDY_AREAS.filterIndexed { i, _ -> i % 2 == col }.forEach { a ->
                        val on = a.id in chosen
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { chosen = if (on) chosen - a.id else chosen + a.id }
                                .padding(vertical = 2.dp)
                        ) {
                            Checkbox(checked = on, onCheckedChange = { chosen = if (on) chosen - a.id else chosen + a.id })
                            Text(a.name, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            listOf(5, 10, 20).forEach { n ->
                AppButton("$n", secondary = count != n, modifier = Modifier.weight(1f), onClick = { count = n })
            }
        }
        Text(
            "Banco disponible: ${pool.size} preguntas → examen de ${picked.size}.",
            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary
        )
        AppButton("Vista previa", secondary = true, onClick = { preview = !preview })
        if (preview) {
            picked.forEachIndexed { i, q -> Text("${i + 1}. ${q.q}", style = MaterialTheme.typography.bodySmall) }
        }
        AppButton("Exportar examen (PDF) para el residente", onClick = {
            val header = "Institución: ____________    Servicio: ____________    Fecha: ____________\n" +
                "Residente: ____________________    Nivel: ${levels.ifEmpty { StudyEngine.LEVELS }.joinToString("/")}    " +
                "Duración sugerida: ${picked.size} min    Calificación: ____ / ${picked.size}"
            val f = File(ctx.cacheDir, "examen_" + System.currentTimeMillis() + ".pdf")
            Expediente.exportPdfBlocks(f, StudyEngine.examBlocks("Cronos Anestesia — Examen de residentes", header, picked, false))
            Expediente.share(ctx, f, "application/pdf")
        })
        AppButton("Exportar clave de respuestas (para el tutor)", secondary = true, onClick = {
            val header = "Clave del tutor — justificación por pregunta"
            val f = File(ctx.cacheDir, "clave_" + System.currentTimeMillis() + ".pdf")
            Expediente.exportPdfBlocks(f, StudyEngine.examBlocks("Cronos Anestesia — Clave del examen", header, picked, true))
            Expediente.share(ctx, f, "application/pdf")
        })
    }
}

@Composable
private fun TutorGuideSection() {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    var areaIdx by rememberSaveable { mutableStateOf(0) }
    var levels by rememberSaveable { mutableStateOf(setOf<String>()) }
    var weeks by rememberSaveable { mutableStateOf(2) }
    var tutor by rememberSaveable { mutableStateOf("") }

    val area = STUDY_AREAS[areaIdx]
    Column(verticalArrangement = Arrangement.spacedBy(sp.s.dp)) {
        Text("Generador de guías de estudio por área y nivel:", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(
            value = tutor, onValueChange = { tutor = it },
            label = { Text("Nombre del tutor") }, singleLine = true,
            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)
        )
        SegmentedRow(STUDY_AREAS.map { it.id.uppercase() }, areaIdx) { areaIdx = it }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            StudyEngine.LEVELS.forEach { lv ->
                val on = lv in levels
                AppButton(lv, secondary = !on, modifier = Modifier.weight(1f),
                    onClick = { levels = if (on) levels - lv else levels + lv })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            listOf(1, 2, 4).forEach { w ->
                AppButton("$w sem", secondary = weeks != w, modifier = Modifier.weight(1f), onClick = { weeks = w })
            }
        }
        Text(
            "Área: ${area.name} · ${area.cardCount} objetivos (fichas) · banco de ${StudyEngine.questionsFor(area, levels.toList()).size} preguntas",
            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary
        )
        AppButton("Exportar guía (PDF)", onClick = {
            val f = File(ctx.cacheDir, "guia_" + area.id + "_" + System.currentTimeMillis() + ".pdf")
            Expediente.exportPdfBlocks(f, StudyEngine.guideBlocks(area, levels.toList(), weeks, tutor))
            Expediente.share(ctx, f, "application/pdf")
        })
        AppButton("Exportar guía (Word)", secondary = true, onClick = {
            val f = File(ctx.cacheDir, "guia_" + area.id + "_" + System.currentTimeMillis() + ".docx")
            OfficeExport.writeDocx(f, StudyEngine.guideBlocks(area, levels.toList(), weeks, tutor))
            Expediente.share(ctx, f, "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
        })
    }
}
