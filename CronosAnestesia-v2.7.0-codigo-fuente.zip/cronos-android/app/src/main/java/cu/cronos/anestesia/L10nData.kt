package cu.cronos.anestesia

/*
 * ============================================================================
 *  L10nData (v2.6.1) — Accesores dinámicos del contenido clínico.
 *
 *  Los datos clínicos originales (DRUGS_RAW, SCALES_RAW, …) permanecen
 *  intactos en español (idioma base). Estos accesores devuelven una copia
 *  con los campos traducidos AL IDIOMA ACTIVO en cada llamada: al cambiar
 *  el idioma desde Ajustes (recreate), el contenido traducido se reevalúa
 *  sin depender de procesos reiniciados.
 *
 *  Reglas de estabilidad:
 *   · Drug.name / GasAnest.name / DrugPrep.alias / claves de mapa /
 *     DrugDoseProfile.name NO se traducen: son claves de búsqueda
 *     (DRUG_PRESENTATION[d.name], rutas, DRUG_DOSE_PROFILES, buscador).
 *   · ClinTopic.calcId es identificador de calculadora: nunca se traduce.
 *   · BIBLIO (citas) permanece en el idioma original de la publicación.
 *   · Pearl.video conserva el título original del video (canal Medik Brain).
 * ============================================================================
 */

// ------------------------------ Fármacos y gases (Data.kt) -----------------

fun drugs(): List<Drug> = DRUGS_RAW.map {
    it.copy(
        cls = it.cls.tr(),
        dose = it.dose.tr(),
        indications = it.indications.tr(),
        cautions = it.cautions.tr()
    )
}

fun gases(): List<GasAnest> = GASES_RAW.map {
    it.copy(
        mac = it.mac.tr(),
        props = it.props.tr(),
        notes = it.notes.tr(),
        warnings = it.warnings.tr()
    )
}

// ------------------------------ Preparación y presentación (Data3.kt) ------

fun drugPrep(): Map<String, DrugPrep> = DRUG_PREP_RAW.mapValues { (_, v) ->
    v.copy(prep = v.prep.tr(), admin = v.admin.tr())
}

fun drugPresentation(): Map<String, String> = DRUG_PRESENTATION_RAW.mapValues { (_, v) -> v.tr() }

// ------------------------------ Escalas y complicaciones (Data2.kt) --------

fun scales(): List<ScaleDef> = SCALES_RAW.map { s ->
    s.copy(
        name = s.name.tr(),
        desc = s.desc.tr(),
        interpretation = s.interpretation.tr(),
        category = s.category.tr(),
        groups = s.groups.map { g ->
            g.copy(title = g.title.tr(), options = g.options.map { o -> o.copy(label = o.label.tr()) })
        },
        fixedOptions = s.fixedOptions.map { o -> o.copy(label = o.label.tr()) }
    )
}

fun complications(): List<Complication> = COMPLICATIONS_RAW.map {
    it.copy(name = it.name.tr(), recognition = it.recognition.tr(), management = it.management.tr())
}

fun premedTopics(): List<Topic> = PREMED_TOPICS_RAW.map { it.copy(title = it.title.tr(), body = it.body.tr()) }

fun solutions(): List<Topic> = SOLUTIONS_RAW.map { it.copy(title = it.title.tr(), body = it.body.tr()) }

// ------------------------------ Temas clínicos (Clinical*.kt) --------------

private fun ClinTopic.translated(): ClinTopic = copy(
    title = title.tr(),
    subtitle = subtitle.tr(),
    category = category.tr(),
    sections = sections.map { (h, b) -> h.tr() to b.tr() }
)

fun clinSections(): List<String> = CLIN_SECTIONS_RAW.map { it.tr() }

fun comorbidities(): List<ClinTopic> = COMORBIDITIES_RAW.map { it.translated() }
fun regionalBlocks(): List<ClinTopic> = REGIONAL_BLOCKS_RAW.map { it.translated() }
fun monitoring(): List<ClinTopic> = MONITORING_RAW.map { it.translated() }
fun preopTopics(): List<ClinTopic> = PREOP_TOPICS_RAW.map { it.translated() }
fun equipmentTopics(): List<ClinTopic> = EQUIPMENT_TOPICS_RAW.map { it.translated() }
fun surgicalTopics(): List<ClinTopic> = SURGICAL_TOPICS_RAW.map { it.translated() }

// ------------------------------ Emergencias (Emergency.kt) -----------------

fun emergencies(): List<Emergency> = EMERGENCIES_RAW.map { e ->
    e.copy(
        name = e.name.tr(),
        subtitle = e.subtitle.tr(),
        category = e.category.tr(),
        recognize = e.recognize.tr(),
        steps = e.steps.tr(),
        doses = e.doses.tr(),
        warnings = e.warnings.tr(),
        refs = e.refs.tr()
    )
}

// ------------------------------ Perlas (Pearls.kt) -------------------------

fun pearls(): List<Pearl> = PEARLS_RAW.map { p ->
    p.copy(
        titulo = p.titulo.tr(),
        resumen = p.resumen.tr(),
        claves = p.claves.tr(),
        errores = p.errores.tr(),
        alarma = p.alarma.tr(),
        aplicacion = p.aplicacion.tr()
    )
}

// ------------------------------ Perfiles de dosificación (DoseProfiles.kt) -

fun drugDoseProfiles(): Map<String, DrugDoseProfile> = DRUG_DOSE_PROFILES_RAW.mapValues { (_, p) ->
    p.copy(
        generalNote = p.generalNote.tr(),
        regimens = p.regimens.map { r ->
            r.copy(
                label = r.label.tr(),
                note = r.note.tr(),
                pedNote = r.pedNote.tr(),
                dilutions = r.dilutions.map { d -> d.copy(label = d.label.tr()) }
            )
        }
    )
}
