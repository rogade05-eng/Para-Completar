package cu.cronos.anestesia

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Pruebas v2.4.0: cálculos ventilatorios (motor Vent), calculadoras del
 * CatTab, presentaciones de fármacos, fisiología (8 temas), bloqueos
 * neuroaxiales ampliados (5), temario R1–R4, esquemas (Arte) y
 * autocompletado de pacientes en el consentimiento (estructura de datos).
 */
class V240Test {

    // ------------------------- Vent: volumen y VM -------------------------

    @Test
    fun pbw_hombre_y_mujer_vectores_dorados() {
        // 170 cm: hombre 50 + 0,91 × 17,6 = 66,0 kg; mujer 45,5 + 16,0 = 61,5 kg
        assertEquals(66.0, Vent.pbwKg(true, 170.0), 0.01)
        assertEquals(61.5, Vent.pbwKg(false, 170.0), 0.01)
        // 152,4 cm → base exacta
        assertEquals(50.0, Vent.pbwKg(true, 152.4), 0.001)
        assertEquals(45.5, Vent.pbwKg(false, 152.4), 0.001)
        // altura inválida → 0
        assertEquals(0.0, Vent.pbwKg(true, 0.0), 0.001)
    }

    @Test
    fun volumen_corriente_y_rango() {
        // PBW 66 kg × 6 = 396 mL; rango 264–528
        assertEquals(396.0, Vent.tidalVolumeMl(66.0, 6.0), 0.01)
        val r = Vent.tidalRangeMl(66.0)
        assertEquals(264.0, r.first, 0.01)
        assertEquals(528.0, r.second, 0.01)
    }

    @Test
    fun ventilacion_minuto_y_frecuencia_necesaria() {
        // 396 mL × 14 = 5544 mL = 5,5 L/min
        assertEquals(5.5, Vent.minuteVentilationL(396.0, 14.0), 0.01)
        // VM 7 L/min con Vt 396 → FR = 17,7
        assertEquals(17.7, Vent.rateForMinuteVentilation(7.0, 396.0), 0.05)
        // Vt 0 → 0 (sin división por cero)
        assertEquals(0.0, Vent.rateForMinuteVentilation(7.0, 0.0), 0.001)
    }

    @Test
    fun ventilacion_alveolar_y_espacio_muerto() {
        // PBW 66 → Vd ≈ 145,2 mL; VA = (396 − 145,2) × 14 / 1000 = 3,5 L/min
        val vd = Vent.deadSpaceMl(66.0)
        assertEquals(145.2, vd, 0.01)
        assertEquals(3.5, Vent.alveolarVentilationL(396.0, 14.0, vd), 0.05)
    }

    // ------------------------- Vent: mecánica -------------------------

    @Test
    fun distensibilidad_presion_motriz_y_resistencia() {
        // Cst = 450 / (25 − 5) = 22,5 mL/cmH2O; ΔP = 20
        assertEquals(22.5, Vent.staticCompliance(450.0, 25.0, 5.0), 0.01)
        assertEquals(20.0, Vent.drivingPressure(25.0, 5.0), 0.01)
        // Raw = (30 − 20) / (30/60 L/s) = 20 cmH2O·s/L
        assertEquals(20.0, Vent.airwayResistance(30.0, 20.0, 30.0), 0.01)
        // divisiones inválidas → 0
        assertEquals(0.0, Vent.staticCompliance(450.0, 5.0, 5.0), 0.001)
        assertEquals(0.0, Vent.airwayResistance(30.0, 20.0, 0.0), 0.001)
    }

    @Test
    fun constante_de_tiempo_y_rsbi() {
        // τ = R × C = 10 × 0,05 = 0,5 s
        assertEquals(0.5, Vent.timeConstantSeconds(10.0, 50.0), 0.001)
        // RSBI = 24 / 0,3 = 80
        assertEquals(80.0, Vent.rsbi(24.0, 300.0), 0.01)
        assertEquals(0.0, Vent.rsbi(24.0, 0.0), 0.001)
    }

    // ------------------------- Vent: oxigenación -------------------------

    @Test
    fun ecuacion_alveolar_gradiente_y_pfr() {
        // PAO2 = 0,21 × 713 − 40/0,8 = 149,73 − 50 = 99,7
        assertEquals(99.7, Vent.alveolarPo2(0.21, 40.0), 0.1)
        // A-a = 99,7 − 95 = 4,7
        assertEquals(4.7, Vent.aAGradient(0.21, 95.0, 40.0), 0.1)
        // esperado por edad (60): 19
        assertEquals(19.0, Vent.expectedAAgradient(60), 0.001)
        // P/F = 95 / 0,21 = 452,4
        assertEquals(452.4, Vent.pfratio(95.0, 0.21), 0.1)
        assertEquals(0.0, Vent.pfratio(95.0, 0.0), 0.001)
        assertTrue(Vent.pfCategory(452.0).contains("normal"))
        assertTrue(Vent.pfCategory(250.0).contains("leve"))
        assertTrue(Vent.pfCategory(150.0).contains("moderado"))
        assertTrue(Vent.pfCategory(80.0).contains("grave"))
    }

    @Test
    fun indice_oxigenacion_y_bohr() {
        // OI = 10 × 0,5 × 100 / 80 = 6,25
        assertEquals(6.3, Vent.oxygenationIndex(10.0, 0.5, 80.0), 0.05)
        assertEquals(0.0, Vent.oxygenationIndex(10.0, 0.5, 0.0), 0.001)
        // Bohr = (40 − 28) / 40 = 0,30
        assertEquals(0.30, Vent.bohrDeadSpaceFraction(40.0, 28.0), 0.001)
        assertEquals(0.0, Vent.bohrDeadSpaceFraction(0.0, 28.0), 0.001)
    }

    @Test
    fun contenido_y_entrega_de_oxigeno() {
        // CaO2 = 1,34 × 15 × 1 + 0,003 × 100 = 20,4 mL/dL
        assertEquals(20.4, Vent.arterialO2Content(15.0, 1.0, 100.0), 0.01)
        // DO2 = 5 × 20,4 × 10 = 1020 mL/min
        assertEquals(1020.0, Vent.oxygenDelivery(5.0, 20.4), 0.1)
    }

    // ------------------------- Calculadoras del CatTab -------------------------

    // ------------------------- Presentaciones -------------------------

    @Test
    fun presentaciones_catalogo_completo_y_enlazado() {
        assertTrue("Mínimo 40 presentaciones", DRUG_PRESENTATIONS.size >= 40)
        val drugNames = DRUGS.map { it.name }.toSet()
        DRUG_PRESENTATIONS.forEach { p ->
            assertTrue("Enlace a fármaco real: ${p.drug}", p.drug in drugNames)
            assertTrue(p.forms.isNotBlank())
            assertTrue(p.draw.isNotBlank())
        }
        // sin duplicados
        assertEquals(DRUG_PRESENTATIONS.size, DRUG_PRESENTATIONS.map { it.drug }.toSet().size)
    }

    @Test
    fun conversor_mg_a_ml() {
        assertEquals(2.0, volumeForMg(100.0, 50.0), 0.001)   // 100 mg de la 50 mg/mL
        assertEquals(0.1, volumeForMg(1.0, 10.0), 0.001)     // 1 mg de la 10 mg/mL
        assertEquals(20.0, volumeForMg(200.0, 10.0), 0.001)
        assertEquals(0.0, volumeForMg(10.0, 0.0), 0.001)     // sin dividir por cero
        assertEquals(2.0, volumeForUg(2000.0, 1000.0), 0.001)
    }

    @Test
    fun presentaciones_claves_con_riesgos_documentados() {
        val byDrug = DRUG_PRESENTATIONS.associateBy { it.drug }
        assertTrue(byDrug["Suxametonio (Succinilcolina)"]!!.forms.contains("2–8 °C"))
        assertTrue(byDrug["Adrenalina (Epinefrina)"]!!.note.contains("1:1000"))
        assertTrue(byDrug["Fentanilo"]!!.draw.contains("10 µg/mL"))
        assertTrue(byDrug["Amiodarona"]!!.draw.contains("SG5 %"))
    }

    // ------------------------- Fisiología -------------------------

    @Test
    fun fisiologia_8_temas_con_secciones() {
        assertEquals(8, FISIOLOGY.size)
        FISIOLOGY.forEach { t ->
            assertEquals("Categoría Fisiología: ${t.title}", "Fisiología", t.category)
            assertTrue("Secciones suficientes: ${t.title}", t.sections.size >= 5)
            t.sections.forEach { (h, b) ->
                assertTrue(h.isNotBlank()); assertTrue(b.length > 80)
            }
        }
    }

    @Test
    fun clinica_ahora_65_temas_con_categoria_fisiologia() {
        assertEquals(65, COMORBIDITIES.size + REGIONAL_BLOCKS.size + MONITORING.size +
            PREOP_TOPICS.size + SURGICAL_TOPICS.size + EQUIPMENT_TOPICS.size + FISIOLOGY.size)
        assertTrue("Fisiología en los apartados", CLIN_SECTIONS.contains("Fisiología"))
        assertEquals(7, CLIN_SECTIONS.size)
    }

    // ------------------------- Neuroaxial -------------------------

    @Test
    fun neuroaxial_5_temas_con_esquemas_y_dosis() {
        assertEquals(5, NEURAXIAL_TOPICS.size)
        val titles = NEURAXIAL_TOPICS.map { it.title }
        assertTrue(titles.any { it.contains("raquídea", ignoreCase = true) })
        assertTrue(titles.any { it.contains("Epidural") })
        assertTrue(titles.any { it.contains("CSE") || it.contains("Combinada") })
        assertTrue(titles.any { it.contains("caudal", ignoreCase = true) })
        assertTrue("Categoría Bloqueos", NEURAXIAL_TOPICS.all { it.category == "Bloqueos" })
        // dosis de referencia presentes
        val raq = NEURAXIAL_TOPICS.first { it.title.contains("raquídea", ignoreCase = true) }
        val all = raq.sections.joinToString("\n") { it.second }
        assertTrue(all.contains("Bupivacaína hiperbárica 0,5 %"))
        assertTrue(all.contains("12–15 mg"))
    }

    @Test
    fun bloqueos_totales_21_y_enlazados_a_regional_blocks() {
        assertEquals(21, REGIONAL_BLOCKS.size)
        // los neuroaxiales están al final de la lista combinada
        NEURAXIAL_TOPICS.forEachIndexed { i, t ->
            assertEquals(t.title, REGIONAL_BLOCKS[REGIONAL_BLOCKS.size - NEURAXIAL_TOPICS.size + i].title)
        }
    }

    // ------------------------- Temario -------------------------

    @Test
    fun temario_4_cursos_con_areas_y_temas() {
        assertEquals(listOf("R1", "R2", "R3", "R4"), RESIDENCY.map { it.curso })
        RESIDENCY.forEach { y ->
            assertTrue("Áreas suficientes en ${y.curso}", y.areas.size >= 5)
            y.areas.forEach { a ->
                assertTrue("Temas suficientes: ${a.title}", a.topics.size >= 4)
                a.topics.forEach { assertTrue(it.isNotBlank()) }
            }
        }
        // volumen total razonable (≥ 100 temas)
        val total = RESIDENCY.sumOf { y -> y.areas.sumOf { it.topics.size } }
        assertTrue("Total de temas: $total", total >= 100)
    }

    @Test
    fun temario_ids_estables_y_progreso() {
        assertEquals("r1.a0.t0", temaId(0, 0, 0))
        assertEquals("r4.a1.t3", temaId(3, 1, 3))
        val done = setOf(temaId(0, 0, 0), temaId(0, 0, 1))
        val pct = TemarioStore.percentOf(done, 0)
        assertTrue("Porcentaje parcial: $pct", pct in 1..99)
        assertEquals(0, TemarioStore.percentOf(emptySet(), 0))
        assertEquals(100, TemarioStore.percentOf(
            RESIDENCY[0].areas.flatMapIndexed { a, area ->
                area.topics.indices.map { t -> temaId(0, a, t) }
            }.toSet(), 0)
        )
        assertEquals(0, TemarioStore.percentOf(emptySet(), 9)) // año inexistente
    }

    // ------------------------- Arte (imágenes) -------------------------

    @Test
    fun arte_5_esquemas_con_ids_unicos_y_tema() {
        assertEquals(5, Arte.ALL.size)
        assertEquals(Arte.ALL.size, ART_IDS.size)
        Arte.ALL.forEach { a ->
            assertTrue(a.id.isNotBlank()); assertTrue(a.title.isNotBlank())
            assertTrue(a.caption.length > 60)
            assertTrue(a.usedIn.contains("Clínica") || a.usedIn.contains("Calculadoras"))
        }
    }

    @Test
    fun artids_de_los_temas_existen_en_la_galeria() {
        (NEURAXIAL_TOPICS + FISIOLOGY).forEach { t ->
            if (t.artId.isNotBlank()) {
                assertTrue("artId desconocido: ${t.artId} (${t.title})", t.artId in ART_IDS)
            }
        }
        // y específicamente los que definimos
        assertEquals("columna_sagital", NEURAXIAL_TOPICS[0].artId)
        assertEquals("espacio_epidural", NEURAXIAL_TOPICS[1].artId)
        assertEquals("dermatomas", NEURAXIAL_TOPICS[4].artId)
        assertEquals("alveolo_capilar", FISIOLOGY[1].artId)
        assertEquals("curva_pv", FISIOLOGY[0].artId)
    }

    // ------------------------- Deep links -------------------------

    @Test
    fun deeplinks_temario_e_imagenes() {
        assertEquals(16, DeepLinks.tabFor("temario"))
        assertEquals(17, DeepLinks.tabFor("imagenes"))
        assertEquals(15, DeepLinks.tabFor("ajustes"))
        assertEquals(null, DeepLinks.tabFor("desconocido"))
    }

    // ------------------------- Consentimiento con autocompletado -------------------------

    @Test
    fun consentimiento_acepta_paciente_con_datos_completos() {
        // El selector alimenta Patient existente; validamos el flujo de datos
        // que rellena el documento (mismo contrato que usa ConsentSection).
        val p = Patient(
            id = "auto1", name = "Romay Díaz D.", ci = "91070612345",
            age = "41", sex = "M", weightKg = "72", heightCm = "178", hx = "HTA controlada"
        )
        val blocks = Consent.buildBlocks(
            patient = p, anesthesiologist = "Dr. R", institution = "H. Clínico",
            service = "Anestesiología", technique = Consent.TYPES[0],
            procedure = "Colecistectomía", risksExtra = "", date = "hoy", asa = "II"
        )
        val all = blocks.joinToString("\n") { it.first }
        assertTrue("Nombre autocompletado", all.contains("Romay Díaz D."))
        assertTrue("CI autocompletado", all.contains("91070612345"))
        assertTrue("Peso/altura autocompletados", all.contains("72") && all.contains("178"))
    }
}
