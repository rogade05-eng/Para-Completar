package cu.cronos.anestesia

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.util.zip.ZipFile

/**
 * Pruebas v2.5.0: cálculos ventilatorios, escala EVA con slider, atribución
 * a paciente (ASA y guardado dirigido), estadísticas (filtro por periodo,
 * distribución ASA, series y tendencia), presentación de fármacos, enlaces
 * externos y exportación Word del consentimiento.
 */
class V250Test {

    private fun eq(expected: Double, actual: Double, tol: Double = 1e-6) =
        assertTrue("Esperado $expected ±$tol, obtenido $actual", kotlin.math.abs(expected - actual) <= tol)

    private fun patient(id: String, name: String, age: String, sex: String, asa: String = "") = Patient(
        id = id, name = name, ci = "", age = age, sex = sex,
        weightKg = "70", heightCm = "170", hx = "", asa = asa
    )

    private fun entry(pid: String, tag: String, ts: Long) = ExpEntry(ts = ts, patientId = pid, tag = tag, text = "x")

    // ---------------------- 1. Cálculos ventilatorios ----------------------

    @Test
    fun peso_predicho_y_vt_protector_ardsnet() {
        // Hombre 170 cm: 50 + 0,91 × (170 − 152,4) = 66,016 kg → VT6 = 396,096 mL
        val h = CalcEngine.vtTargets(170.0, true)
        eq(66.016, h.pbwKg)
        eq(396.096, h.vt6Ml)
        eq(264.064, h.vt4Ml)
        eq(528.128, h.vt8Ml)
        // Mujer 170 cm: 45,5 + 0,91 × 17,6 = 61,516 kg
        val m = CalcEngine.vtTargets(170.0, false)
        eq(61.516, m.pbwKg)
        eq(369.096, m.vt6Ml)
    }

    @Test
    fun ventilacion_minuto_espacio_muerto_y_alveolar() {
        // VE = 500 × 12 = 6000 mL/min
        eq(6000.0, CalcEngine.minuteVentilation(500.0, 12.0))
        // Bohr: (40 − 30)/40 = 0,25
        eq(0.25, CalcEngine.bohrDeadSpaceFraction(40.0, 30.0))
        eq(0.0, CalcEngine.bohrDeadSpaceFraction(30.0, 30.0))
        // VA = 500 × (1 − 0,25) × 12 = 4500 mL/min
        eq(4500.0, CalcEngine.alveolarVentilation(500.0, 12.0, 0.25))
        // PaCO2 inválido → 0 sin explotar
        eq(0.0, CalcEngine.bohrDeadSpaceFraction(0.0, 20.0))
    }

    @Test
    fun compliance_estatica_dinamica_y_clases() {
        // Cst = 400/(25 − 5) = 20 mL/cmH2O
        eq(20.0, CalcEngine.complianceStatic(400.0, 25.0, 5.0))
        // Cdyn = 400/(30 − 5) = 16 mL/cmH2O
        eq(16.0, CalcEngine.complianceDynamic(400.0, 30.0, 5.0))
        // meseta ≤ PEEP → 0 (sin explotar)
        eq(0.0, CalcEngine.complianceStatic(400.0, 5.0, 5.0))
        assertTrue(CalcEngine.complianceClass(20.0).contains("Severamente"))
        assertTrue(CalcEngine.complianceClass(70.0).contains("Normal"))
        assertTrue(CalcEngine.complianceClass(0.0).contains("Sin datos"))
    }

    @Test
    fun indice_p_a_y_oxigenacion_oi() {
        // FiO2 21 %, PaCO2 40 → PAO2 = 0,21 × 713 − 50 = 99,73; PaO2 100 → P/A ≈ 1,0027
        val ratio = CalcEngine.pao2OverPao2(100.0, 21.0, 40.0)
        eq(1.0027, ratio, 1e-3)
        // FiO2 100 %, PaCO2 40 → PAO2 = 663; PaO2 200 → 0,3016…
        eq(200.0 / 663.0, CalcEngine.pao2OverPao2(200.0, 100.0, 40.0), 1e-9)
        // OI = PAM × FiO2 × 100 / PaO2 = 10 × 0,5 × 100 / 100 = 5
        eq(5.0, CalcEngine.oxygenationIndex(10.0, 50.0, 100.0))
        // PaO2 inválido → 0
        eq(0.0, CalcEngine.oxygenationIndex(10.0, 50.0, 0.0))
        assertTrue(CalcEngine.pao2OverPao2Class(0.9).contains("Normal"))
        assertTrue(CalcEngine.pao2OverPao2Class(0.4).contains("grave"))
    }

    // ---------------------- 2. EVA con slider ----------------------

    @Test
    fun eva_responde_con_slider_0_10() {
        val eva = scales().first { it.name.startsWith("EVA") }
        assertTrue("EVA debe usar slider", eva.sliderMax == 10)
        assertEquals(11, eva.fixedOptions.size)
        // los descriptores cubren todos los niveles 0..10
        val scores = eva.fixedOptions.map { it.score }.sorted()
        assertEquals((0..10).toList(), scores)
        // el resto de escalas no cambia de modo
        assertTrue(scales().filter { it.name != eva.name }.all { it.sliderMax <= 0 })
        // 16 escalas intactas en 6 grupos
        assertEquals(16, scales().size)
    }

    // ---------------------- 3. ASA y atribución a paciente ----------------------

    @Test
    fun asa_normalizado_para_estadisticas() {
        assertEquals("II", Expediente.asaNormalized("II"))
        assertEquals("III", Expediente.asaNormalized("iii"))
        assertEquals("III-E", Expediente.asaNormalized("III-E"))
        assertEquals("II-E", Expediente.asaNormalized("II E"))
        assertEquals("IV-E", Expediente.asaNormalized("IV (emergencia)"))
        assertEquals("VI", Expediente.asaNormalized("VI"))
        assertEquals("II", Expediente.asaNormalized("clase II"))
        assertEquals("Sin dato", Expediente.asaNormalized(""))
        assertEquals("Sin dato", Expediente.asaNormalized("desconocida"))
    }

    @Test
    fun distribucion_por_clase_asa() {
        val patients = listOf(
            patient("p1", "Ana", "34", "F", asa = "II"),
            patient("p2", "Beto", "70", "M", asa = "III-E"),
            patient("p3", "Carla", "9", "F", asa = "II"),
            patient("p4", "Días", "85", "M")
        )
        val dist = CaseStats.asaDistribution(patients)
        val map = dist.toMap()
        assertEquals(listOf("I", "II", "III", "IV", "V", "VI", "Sin dato"), dist.map { it.first })
        assertEquals(0, map["I"])
        assertEquals(2, map["II"])
        assertEquals(1, map["III"])
        assertEquals(1, map["Sin dato"])
        // la base ignora el sufijo -E
        assertEquals("III", CaseStats.asaBase("III-E"))
    }

    @Test
    fun filtro_por_periodo() {
        val now = System.currentTimeMillis()
        val day = 86_400_000L
        val entries = listOf(
            entry("p1", "A", now - 2 * day),
            entry("p1", "B", now - 10 * day),
            entry("p2", "C", now - 40 * day),
            entry("p3", "D", now - 400 * day)
        )
        assertEquals(4, CaseStats.filterEntries(entries, null, now).size)
        assertEquals(2, CaseStats.filterEntries(entries, 30L, now).size)
        assertEquals(2, CaseStats.filterEntries(entries, 15L, now).size)
        assertEquals(3, CaseStats.filterEntries(entries, 50L, now).size)
        assertEquals(5, CaseStats.PERIOD_OPTIONS.size)
        assertNull(CaseStats.PERIOD_OPTIONS.last())
    }

    // ---------------------- 4. Series y tendencia ----------------------

    @Test
    fun series_diaria_y_mensual_suma_todos_los_registros() {
        val now = System.currentTimeMillis()
        val day = 86_400_000L
        val entries = listOf(
            entry("p1", "A", now - 2 * day),
            entry("p1", "B", now - 2 * day - 3600_000L),
            entry("p2", "C", now - 40 * day)
        )
        val daily = CaseStats.dailySeries(entries, 7, now)
        assertEquals(7, daily.size)
        assertEquals(2, daily.sumOf { it.second })
        assertTrue(daily.all { it.second >= 0 })
        val monthly = CaseStats.monthlySeries(entries, 12, now)
        assertEquals(12, monthly.size)
        assertEquals(3, monthly.sumOf { it.second })
        assertTrue(monthly.all { it.first.isNotBlank() })
    }

    @Test
    fun tendencia_textual() {
        val up = CaseStats.trendText(listOf("a" to 1, "b" to 1, "c" to 1, "d" to 1, "e" to 3, "f" to 3, "g" to 3, "h" to 3))
        assertNotNull(up)
        assertTrue("debe marcar ascenso: $up", up!!.contains("+") || up.contains("ascenso"))
        val stable = CaseStats.trendText(listOf("a" to 2, "b" to 2, "c" to 2, "d" to 2, "e" to 2, "f" to 2, "g" to 2, "h" to 2))
        assertTrue(stable!!.contains("estable"))
        assertNull(CaseStats.trendText(listOf("a" to 0, "b" to 0, "c" to 0, "d" to 0, "e" to 0, "f" to 0, "g" to 0, "h" to 0)))
        assertNull(CaseStats.trendText(listOf("a" to 1)))
    }

    // ---------------------- 5. Presentación de fármacos ----------------------

    @Test
    fun presentacion_de_los_45_farmacos() {
        assertEquals("Debe cubrir los 45 fármacos", drugs().size, drugPresentation().size)
        assertTrue(drugs().size == 45)
        drugs().forEach { d ->
            val p = drugPresentation()[d.name]
            assertTrue("Falta presentación de ${d.name}", p != null)
            assertTrue("Presentación corta de ${d.name}", (p ?: "").length >= 15)
        }
        // claves exactas (sin sobrantes)
        assertEquals(drugs().map { it.name }.toSet(), drugPresentation().keys)
        // ejemplos concretos
        assertTrue(drugPresentation()["Propofol"]!!.contains("10 mg/mL"))
        assertTrue(drugPresentation()["Suxametonio (Succinilcolina)"]!!.contains("50 mg/mL"))
    }

    // ---------------------- 6. Enlaces externos ----------------------

    @Test
    fun enlaces_externos_bloqueados_por_contrato() {
        assertEquals("https://www.facebook.com/share/v/19FTQBahTb/", ExternalLinks.CRONOS_VIDEO_FB)
        assertEquals("https://www.youtube.com/@MedikBrain", ExternalLinks.MEDIK_BRAIN_YT)
        assertEquals("https://www.facebook.com/MedikBrain", ExternalLinks.MEDIK_BRAIN_FB)
    }

    // ---------------------- 7. Consentimiento en Word ----------------------

    @Test
    fun consentimiento_word_docx_zip_valido() {
        val p = Patient("p1", "Ana Pérez", "123", "45", "F", "70", "165", "Alergia a AINE", "II")
        val blocks = Consent.buildBlocks(
            patient = p, anesthesiologist = "Dr. Prueba", institution = "Hospital X",
            service = "Anestesiología", technique = Consent.TYPES[0], procedure = "Colecistectomía",
            risksExtra = "", date = "26 de octubre de 2026", asa = "II"
        ).map { (t, s) -> t to s }
        assertTrue("Bloques del consentimiento", blocks.size >= 9)
        val f = File(System.getProperty("java.io.tmpdir"), "cronos_consent_${System.nanoTime()}.docx")
        try {
            OfficeExport.writeDocx(f, blocks)
            assertTrue(f.exists() && f.length() > 0)
            ZipFile(f).use { zf ->
                val names = zf.entries().toList().map { it.name }
                assertTrue("word/document.xml" in names)
                val doc = zf.getInputStream(zf.getEntry("word/document.xml")).bufferedReader().readText()
                assertTrue("Título del consentimiento", "CONSENTIMIENTO INFORMADO" in doc)
                assertTrue("Paciente incluido", "Ana Pérez" in doc)
            }
        } finally {
            f.delete()
        }
    }

    // ---------------------- 8. Hoja Excel con ASA ----------------------

    @Test
    fun hoja_excel_incluye_columna_asa() {
        val patients = listOf(patient("p1", "Ana", "34", "F", asa = "II"))
        val rows = AnalysisSheets.patientRows(patients, mapOf("p1" to emptyList()))
        assertTrue("Encabezado de pacientes", rows[0].firstOrNull() == "Caso (paciente)")
        assertTrue("Columna ASA", "ASA" in rows[0])
        val anaRow = rows.first { it.firstOrNull() == "Ana" }
        assertEquals("II", anaRow[rows[0].indexOf("ASA")])
    }

    // ---------------------- 9. Informe con ASA ----------------------

    @Test
    fun informe_de_analisis_incluye_asa_y_detalle() {
        val patients = listOf(
            patient("p1", "Ana", "34", "F", asa = "II"),
            patient("p2", "Beto", "70", "M", asa = "III-E")
        )
        val entries = listOf(entry("p1", "Cálculo: Ventilación", System.currentTimeMillis()))
        val a = CaseAnalysis.analyze(patients, entries)
        val blocks = CaseAnalysis.reportBlocks(a, patients, mapOf("p1" to entries, "p2" to emptyList()))
        val all = blocks.joinToString("\n") { it.first }
        assertTrue("Sección ASA", "clase ASA" in all)
        assertTrue("ASA II contado", "ASA II: 1" in all)
        assertTrue("Detalle de Ana", "Ana" in all)
        assertTrue("Ventilación en top tags", entries[0].tag in a.topTags.map { it.first })
        // el informe NO contiene marcadores de fin artificiales
        assertFalse("Fin del informe" in all)
    }
}
