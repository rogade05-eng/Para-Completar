package cu.cronos.anestesia

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Pruebas v2.6.0: internacionalización (Español base · English · Português
 * do Brasil). Contrato: sistema + selector manual con fallback al español,
 * degradación elegante por cadena (falta de traducción → español), paridad
 * de claves EN/PT y traducción de informes y consentimiento.
 */
class V260Test {

    // ---------------------- 1. Resolución de idioma ----------------------

    @Test
    fun `lang_from_resuelve_prefijos_bcp47`() {
        assertEquals(Lang.EN, Lang.from("en"))
        assertEquals(Lang.EN, Lang.from("en-US"))
        assertEquals(Lang.EN, Lang.from("en_GB"))
        assertEquals(Lang.PT, Lang.from("pt"))
        assertEquals(Lang.PT, Lang.from("pt-BR"))
        assertEquals(Lang.ES, Lang.from("es"))
        assertEquals(Lang.ES, Lang.from("es-CU"))
        assertNull("francés no soportado → null (el llamador aplica fallback ES)", Lang.from("fr"))
        assertNull(Lang.from(""))
    }

    @Test
    fun `idiomas_son_tres_y_con_etiqueta`() {
        assertEquals(3, Lang.values().size)
        Lang.values().forEach { assertTrue(it.label.isNotBlank()) }
        assertEquals("Español", Lang.ES.label)
        assertEquals("English", Lang.EN.label)
        assertTrue(Lang.PT.label.startsWith("Português"))
    }

    // ---------------------- 2. Registro y paridad ----------------------

    @Test
    fun `i18n_init_registra_los_tres_objetos_y_es_idempotente`() {
        I18n.init()
        val en1 = L10n.registered(Lang.EN)
        val pt1 = L10n.registered(Lang.PT)
        assertTrue("ola UI+consentimiento+checklist debe registrar EN", en1 >= 380)
        assertTrue("ola UI+consentimiento+checklist debe registrar PT", pt1 >= 380)
        I18n.init()
        assertEquals("init() no debe duplicar registros", en1, L10n.registered(Lang.EN))
        assertEquals(pt1, L10n.registered(Lang.PT))
    }

    @Test
    fun `paridad_de_claves_entre_english_y_portugues`() {
        I18n.init()
        val en = L10n.table(Lang.EN)?.keys ?: emptySet()
        val pt = L10n.table(Lang.PT)?.keys ?: emptySet()
        assertTrue(en.isNotEmpty())
        assertEquals("claves EN sin PT", emptySet<String>(), en - pt)
        assertEquals("claves PT sin EN", emptySet<String>(), pt - en)
    }

    @Test
    fun `register_con_es_es_no_op_y_tabla_es_es_null`() {
        val antes = L10n.registered(Lang.EN)
        L10n.register(Lang.ES, mapOf("X" to "X"))
        assertEquals(antes, L10n.registered(Lang.EN))
        assertNull("ES usa el original: no hay tabla", L10n.table(Lang.ES))
    }

    // ---------------------- 3. tr() y degradación ----------------------

    @Test
    fun `tr_en_espanol_devuelve_el_original`() {
        I18n.init()
        L10n.current = Lang.ES
        assertEquals("Ayuno requerido", "Ayuno requerido".tr())
        assertEquals(Lang.ES, L10n.current)
    }

    @Test
    fun `tr_en_ingles_traduce_y_en_falta_degrada_a_espanol`() {
        try {
            I18n.init()
            L10n.current = Lang.EN
            assertEquals("Required fasting", "Ayuno requerido".tr())
            assertEquals("Calculation: Ventilation", "Cálculo: Ventilación".tr())
            assertEquals("VAS", "EVA".tr())
            assertEquals(
                "cadena sin traducción → español original",
                "cadena sin traducción".tr(),
                "cadena sin traducción"
            )
        } finally {
            L10n.current = Lang.ES
        }
    }

    @Test
    fun `tr_en_portugues_traduce`() {
        try {
            I18n.init()
            L10n.current = Lang.PT
            assertEquals("Jejum requerido", "Ayuno requerido".tr())
            assertEquals("Cálculo: Ventilação", "Cálculo: Ventilación".tr())
            assertEquals("Manutenção", "Mantenimiento".tr())
        } finally {
            L10n.current = Lang.ES
        }
    }

    @Test
    fun `tr_de_lista_traduce_cada_elemento`() {
        try {
            I18n.init()
            L10n.current = Lang.EN
            val out = listOf("Ayuno requerido", "Mantenimiento", "cadena sin traducción").tr()
            assertEquals(listOf("Required fasting", "Maintenance", "cadena sin traducción"), out)
        } finally {
            L10n.current = Lang.ES
        }
    }

    // ---------------------- 4. Informes y consentimiento ----------------------

    @Test
    fun `consentimiento_se_traduce_a_los_tres_idiomas`() {
        I18n.init()
        // ES: original
        L10n.current = Lang.ES
        assertEquals("CONSENTIMIENTO INFORMADO PARA ANESTESIA", "CONSENTIMIENTO INFORMADO PARA ANESTESIA".tr())
        assertEquals("Anestesia general", "Anestesia general".tr())
        // EN
        try {
            L10n.current = Lang.EN
            assertEquals("INFORMED CONSENT FOR ANESTHESIA", "CONSENTIMIENTO INFORMADO PARA ANESTESIA".tr())
            assertEquals("General anesthesia", "Anestesia general".tr())
            assertEquals("Spinal anesthesia (subarachnoid)", "Raquianestesia (subaracnoidea)".tr())
            assertEquals("9. SIGNATURES", "9. FIRMAS".tr())
            assertTrue("riesgo LAST traducido", "Inyección intravascular con toxicidad de anestésico local (LAST): convulsiones o arritmias, con protocolo de lípidos disponible".tr().startsWith("Intravascular injection"))
        } finally {
            L10n.current = Lang.ES
        }
        // PT
        try {
            L10n.current = Lang.PT
            assertEquals("CONSENTIMENTO INFORMADO PARA ANESTESIA", "CONSENTIMIENTO INFORMADO PARA ANESTESIA".tr())
            assertEquals("Anestesia geral", "Anestesia general".tr())
        } finally {
            L10n.current = Lang.ES
        }
    }

    @Test
    fun `fragmentos_de_informes_pdf_y_csv_traducidos`() {
        I18n.init()
        try {
            L10n.current = Lang.EN
            assertEquals("Name: ", "Nombre: ".tr())
            assertEquals("Age: ", "Edad: ".tr())
            assertEquals("Period: ", "Periodo: ".tr())
            assertEquals("Cases (patients): ", "Casos (pacientes): ".tr())
            assertEquals("ASA physical status: ", "Clasificación física ASA: ".tr())
            assertTrue(
                "cabecera CSV traducida",
                "Paciente;CI;Edad;Sexo;Peso (kg);Altura (cm);Antecedentes\n".tr().startsWith("Patient;ID;")
            )
        } finally {
            L10n.current = Lang.ES
        }
    }

    @Test
    fun `checklist_oms_traducido`() {
        I18n.init()
        try {
            L10n.current = Lang.EN
            assertEquals("Before skin incision", "Antes de la incisión cutánea".tr())
            assertEquals("WHO checklist", "Checklist OMS".tr())
        } finally {
            L10n.current = Lang.ES
        }
        try {
            L10n.current = Lang.PT
            assertEquals("Antes da incisão da pele", "Antes de la incisión cutánea".tr())
        } finally {
            L10n.current = Lang.ES
        }
    }

    @Test
    fun `manual_y_tarifas_traducidos`() {
        I18n.init()
        try {
            L10n.current = Lang.EN
            assertEquals("General navigation", "Navegación general".tr())
            assertEquals("Monthly", "Mensual".tr())
            assertEquals("Basic", "Básica".tr())
            assertEquals("Institutional", "Institucional".tr())
        } finally {
            L10n.current = Lang.ES
        }
        try {
            L10n.current = Lang.PT
            assertEquals("Mensal", "Mensual".tr())
            assertEquals("Perpétua", "Perpetua".tr())
        } finally {
            L10n.current = Lang.ES
        }
    }

    // ---------------------- 5. Contenido no afectado ----------------------

    @Test
    fun `contenido_clinico_espanol_intacto_en_modo_es`() {
        L10n.current = Lang.ES
        assertTrue("45 fármacos", drugs().size == 45)
        assertTrue("16 escalas", scales().size == 16)
        assertEquals("Propofol", drugs().first().name)
    }

    @Test
    fun `licencia_y_enlaces_no_cambian_con_idioma`() {
        I18n.init()
        LicenseTier.values().forEach { tier -> assertTrue(tier.code.isNotBlank()) }
        assertEquals("https://www.facebook.com/share/v/19FTQBahTb/", ExternalLinks.CRONOS_VIDEO_FB)
        assertEquals("https://www.youtube.com/@MedikBrain", ExternalLinks.MEDIK_BRAIN_YT)
    }
}
