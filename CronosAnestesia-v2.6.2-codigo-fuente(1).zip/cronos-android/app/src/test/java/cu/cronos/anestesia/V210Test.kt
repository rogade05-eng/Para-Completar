package cu.cronos.anestesia

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Vectores dorados v2.1.0: TCI (Marsh/Schnider/Minto + esquema BET) y
 * cobertura del catálogo de escalas (16 en 6 grupos). Valores verificados
 * a mano contra los parámetros publicados y la fórmula BET.
 */
class V210Test {

    private val EPS = 1e-9
    private fun eq(expected: Double, actual: Double, delta: Double = EPS) =
        assertEquals(expected, actual, delta)

    // ---------- Modelos farmacocinéticos ----------

    @Test
    fun `Marsh 70 kg - V1 y aclaramiento estándar`() {
        val p = CalcEngine.marshPropofol(70.0)
        eq(15.96, p.v1, 0.01)          // 0,228 × 70
        eq(25.62, p.v2, 0.01)          // 0,366 × 70
        eq(202.51, p.v3, 0.05)         // 2,893 × 70
        eq(1.8993, p.clearanceLMin, 0.01) // k10 × V1 = 0,119 × 15,96
        eq(0.26, p.ke0)
    }

    @Test
    fun `Schnider 40 años - parámetros por edad`() {
        val p = CalcEngine.schniderPropofol(40.0, 70.0, 170.0, true)
        eq(4.27, p.v1)                                   // V1 fijo
        eq(23.98, p.v2, 0.01)                            // 18,9 + 0,391×13
        eq(2.4828, p.clearanceLMin, 0.01)                // 1,89 + 0,0456×13
        eq(0.456, p.ke0)
        // k12 y k21 comparten el mismo aclaramiento intercompartimental
        eq(p.k12 * p.v1, p.k21 * p.v2, 1e-9)
    }

    @Test
    fun `Minto 40 años varón 70 kg 170 cm - LBM y V1`() {
        val p = CalcEngine.mintoRemifentanil(40.0, 70.0, 170.0, true)
        // LBM Janmahasatian varón: 9270×70/(6680+216×24,2215) ≈ 54,49 kg
        eq(54.4752, CalcEngine.leanBodyMass(70.0, 170.0, true), 0.01)
        eq(5.0630, p.v1, 0.01)            // 5,1 + 0,072×(54,49−55)
        eq(2.5902, p.clearanceLMin, 0.02) // 2,6 + 0,0191×(54,49−55)
        eq(0.595, p.ke0, 0.001)
        // Mujer de mismas medidas: LBM menor
        val lbmF = CalcEngine.leanBodyMass(70.0, 170.0, false)
        assertTrue("LBM femenino: $lbmF", lbmF < 54.0 && lbmF > 42.0)
    }

    // ---------- Esquema BET ----------

    @Test
    fun `BET propofol Marsh 70 kg diana 4 mcg por mL con jeringa 1 por ciento`() {
        // diana 4 µg/mL = 0,004 mg/mL; jeringa 10 mg/mL (1 %)
        val p = CalcEngine.marshPropofol(70.0)
        val plan = CalcEngine.tciPlan(p, 0.004, 10.0)
        // Bolo = 0,004 × 15 960 mL = 63,84 mg (≈0,91 mg/kg: coherente con Marsh)
        eq(63.84, plan.bolusMg, 0.05)
        eq(6.384, plan.bolusMl, 0.01)
        // Velocidad inicial = 0,004×15960×(0,119+0,112+0,041) = 17,36 mg/min
        eq(1041.9, plan.rate0MgH, 1.0)
        eq(104.19, plan.rate0MlH, 1.0)
        // A 60 min la velocidad decae hacia el mantenimiento k10: r(60) = 0,004×15960×(0,119+0,112·e^-4,2+0,041·e^-0,21)
        val r60 = plan.points.last()
        eq(60.0, r60.tMin)
        val mgMin60 = 0.004 * 15960.0 * (0.119 + 0.112 * Math.exp(-0.070 * 60.0) + 0.041 * Math.exp(-0.0035 * 60.0))
        eq(mgMin60 * 60.0 / 10.0, r60.rateMlH, 0.01)
        assertTrue(r60.rateMlH in plan.rate0MlH * 0.54..plan.rate0MlH * 0.60) // k13 decae lento: ~57 % a 1 h
        // Volumen acumulado a 60 min: bolo + integral (7,62 mg×10³ / 10 mg/mL ≈ 76 mL)
        assertTrue("total 60 min razonable: ${r60.cumulativeMl}", r60.cumulativeMl in 70.0..82.0)
    }

    @Test
    fun `BET remifentanilo Minto 4 ng por mL con 50 mcg por mL`() {
        val p = CalcEngine.mintoRemifentanil(40.0, 70.0, 170.0, true)
        val plan = CalcEngine.tciPlan(p, 4e-6, 0.05)
        // Bolo ≈ 20,3 µg (≈0,29 µg/kg: razonable)
        eq(0.02025, plan.bolusMg, 0.0005)
        eq(0.405, plan.bolusMl, 0.01)
        // Velocidad inicial ≈ 22,6 mL/h ≈ 0,27 µg/kg/min
        eq(22.64, plan.rate0MlH, 0.6)
        val ugKgMin = plan.rate0MgH * 1000.0 / 60.0 / 70.0
        assertTrue("µg/kg/min inicial razonable: $ugKgMin", ugKgMin in 0.20..0.35)
    }

    @Test
    fun `Ce asciende con ke0 y t90 correcto`() {
        val p = CalcEngine.schniderPropofol(40.0, 70.0, 170.0, true)
        val plan = CalcEngine.tciPlan(p, 0.003, 10.0)
        // Schnider ke0 = 0,456 → a 5 min: 1−e^(−2,28) ≈ 89,8 %
        val p5 = plan.points.first { it.tMin == 5.0 }
        eq((1.0 - Math.exp(-0.456 * 5.0)) * 100.0, p5.cePct, 0.01)
        eq(Math.log(10.0) / 0.456, plan.t90CeMin, 1e-9)
        // Marsh: ke0 0,26 → a 2 min: 1−e^(−0,52) ≈ 40,5 % (t½ke0 ≈ 2,67 min)
        val planM = CalcEngine.tciPlan(CalcEngine.marshPropofol(70.0), 0.003, 10.0)
        eq((1.0 - Math.exp(-0.26 * 2.0)) * 100.0, planM.points.first { it.tMin == 2.0 }.cePct, 0.01)
    }

    @Test
    fun `tciPlan con datos inválidos devuelve plan vacío`() {
        val plan = CalcEngine.tciPlan(CalcEngine.marshPropofol(70.0), 0.0, 10.0)
        assertEquals(0.0, plan.bolusMg, EPS)
        assertTrue(plan.points.isEmpty())
        val plan2 = CalcEngine.tciPlan(CalcEngine.marshPropofol(70.0), 0.004, 0.0)
        assertEquals(0.0, plan2.rate0MlH, EPS)
    }

    @Test
    fun `plan tiene 10 puntos de 0 a 60 min`() {
        val plan = CalcEngine.tciPlan(CalcEngine.marshPropofol(70.0), 0.004, 10.0)
        assertEquals(10, plan.points.size)
        assertEquals(0.0, plan.points.first().tMin, EPS)
        assertEquals(60.0, plan.points.last().tMin, EPS)
    }

    // ---------- Escalas: 16 en 6 grupos ----------

    @Test
    fun `catalogo de 16 escalas en 6 grupos sin intercalado`() {
        assertEquals(16, SCALES.size)
        val cats = SCALES.map { it.category }
        assertEquals(listOf(4, 3, 3, 2, 2, 2), cats.groupingBy { it }.eachCount().values.toList().sortedDescending())
        // Sin intercalado: cada categoría forma un bloque contiguo
        val seen = mutableListOf<String>()
        cats.forEach { if (seen.lastOrNull() != it) seen.add(it) }
        assertEquals(seen.size, seen.toSet().size)
        // Los 6 grupos esperados, en el orden del catálogo
        assertEquals(
            listOf(
                "Valoración preoperatoria", "Vía aérea", "Sedación y conciencia",
                "Dolor", "Recuperación", "Paciente crítico"
            ),
            seen
        )
    }

    @Test
    fun `nombres únicos y contenido no vacío`() {
        assertEquals(SCALES.size, SCALES.map { it.name }.toSet().size)
        SCALES.forEach { s ->
            assertTrue("desc vacía en ${s.name}", s.desc.isNotBlank())
            assertTrue("interpretación vacía en ${s.name}", s.interpretation.isNotBlank())
            val hasOptions = s.fixedOptions.isNotEmpty() || s.groups.any { it.options.isNotEmpty() }
            assertTrue("sin opciones en ${s.name}", hasOptions)
            val nOptions = s.fixedOptions.size + s.groups.sumOf { it.options.size }
            assertTrue("muy pocas opciones en ${s.name}", nOptions >= 3)
        }
        // NYHA fuera del catálogo (16 exactas del contrato de v2.1.0)
        assertFalse(SCALES.any { it.name.contains("NYHA") })
    }

    @Test
    fun `escalas pedidas por el usuario presentes con su grupo`() {
        val eva = SCALES.first { it.name.startsWith("EVA") }
        assertEquals("Dolor", eva.category)
        val cpot = SCALES.first { it.name.startsWith("CPOT") }
        assertEquals("Dolor", cpot.category)
        val aldrete = SCALES.first { it.name.startsWith("Aldrete") }
        assertEquals("Recuperación", aldrete.category)
        val sofa = SCALES.first { it.name.startsWith("SOFA") }
        assertEquals("Paciente crítico", sofa.category)
        // SOFA: 6 sistemas × opciones 0-4; CPOT: 4 grupos; Aldrete: 5 grupos de 3
        assertEquals(6, sofa.groups.size)
        assertEquals(4, cpot.groups.size)
        assertEquals(5, aldrete.groups.size)
        // EVA 0–10: 11 niveles
        assertEquals(11, eva.fixedOptions.size)
    }

    @Test
    fun `rango de puntajes de SOFA 0 a 24 y Glasgow 3 a 15`() {
        val sofa = SCALES.first { it.name.startsWith("SOFA") }
        val minSofa = sofa.groups.sumOf { g -> g.options.minOf { it.score } }
        val maxSofa = sofa.groups.sumOf { g -> g.options.maxOf { it.score } }
        assertEquals(0, minSofa)
        assertEquals(24, maxSofa)
        val glasgow = SCALES.first { it.name.contains("Glasgow") }
        val maxG = glasgow.groups.sumOf { g -> g.options.maxOf { it.score } }
        val minG = glasgow.groups.sumOf { g -> g.options.minOf { it.score } }
        assertEquals(15, maxG)
        assertEquals(3, minG)
        // RASS va de +4 a −5 con valores reales (incluye negativos)
        val rass = SCALES.first { it.name.startsWith("RASS") }
        val rassScores = rass.fixedOptions.map { it.score }
        assertEquals((4 downTo -5).toList(), rassScores.sortedDescending())
    }

    // ---------- Equipamiento (bombas / jeringas perfusoras) ----------

    @Test
    fun `seccion Equipamiento con jeringas perfusoras y bombas TCI`() {
        // v2.4.0: 6 apartados + Fisiología
        assertEquals(7, CLIN_SECTIONS.size)
        assertEquals("Equipamiento", CLIN_SECTIONS[5])
        val topics = EQUIPMENT_TOPICS
        assertEquals(2, topics.size)
        assertTrue(topics.all { it.category == "Equipamiento" })
        val jeringas = topics.first { it.title.contains("Jeringas perfusoras") }
        val bombas = topics.first { it.title.contains("Bombas de infusión y TCI") }
        // Contenido profundo: ≥5 secciones con cuerpo sustancial
        assertTrue(jeringas.sections.size >= 5)
        assertTrue(bombas.sections.size >= 5)
        assertTrue(jeringas.sections.all { it.second.length > 200 })
        assertTrue(bombas.sections.all { it.second.length > 150 })
        assertTrue(bombas.sections.any { it.first.contains("TCI") })
        // Total: 41 + 8 avanzados + 2 + 1 (anemia) + 5 neuroaxiales (v2.4.0) = 57
        // (los 8 de FISIOLOGY se suman aparte en V240Test → 65 en total)
        assertEquals(57, COMORBIDITIES.size + REGIONAL_BLOCKS.size + MONITORING.size + PREOP_TOPICS.size + SURGICAL_TOPICS.size + EQUIPMENT_TOPICS.size)
    }
}
