package cu.cronos.anestesia

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Pruebas v2.6.1: traducción profunda del contenido clínico (olas 1–4).
 * Verifican: accesoires dinámicos sin congelamiento (cambio de idioma en
 * caliente), estabilidad de claves (nombres INN, claves de mapa, calcId),
 * traducción real de cada dominio, preservación de cifras y degradación
 * elegante.
 */
class V270Test {

    private val NUM = Regex("\\d+")

    private fun digits(s: String) = NUM.findAll(s).map { it.value }.sorted().toList()

    private fun withLang(lang: Lang, block: () -> Unit) {
        val prev = L10n.current
        I18n.init()
        L10n.current = lang
        try {
            block()
        } finally {
            L10n.current = prev
        }
    }

    // ---------------------- 1. Registro y cobertura ----------------------

    @Test
    fun `olas_profundas_registradas_y_idempotentes`() {
        I18n.init()
        val en = L10n.registered(Lang.EN)
        val pt = L10n.registered(Lang.PT)
        assertTrue("EN debe superar 2100 claves (UI+consent+checklist+profunda): $en", en >= 2100)
        assertTrue("PT debe superar 2000 claves: $pt", pt >= 2000)
        I18n.init()
        assertEquals("init() idempotente", en, L10n.registered(Lang.EN))
        assertEquals(pt, L10n.registered(Lang.PT))
    }

    // ---------------------- 2. Fármacos (ola 1) ----------------------

    @Test
    fun `drugs_traduce_campos_y_preserva_nombre_inn`() {
        I18n.init()
        val es = drugs().first()
        assertEquals("Propofol", es.name)
        assertEquals("Inductor hipnótico (alquilfenol)", es.cls)
        withLang(Lang.EN) {
            val d = drugs().first()
            assertEquals("nombre INN = clave de DRUG_PRESENTATION: intocable", "Propofol", d.name)
            assertNotEquals(d.cls, es.cls)
            assertNotEquals(d.dose, es.dose)
            assertNotEquals(d.indications, es.indications)
            assertNotEquals(d.cautions, es.cautions)
            assertEquals("Hypnotic inducer (alkylphenol)", d.cls)
        }
        withLang(Lang.PT) {
            val d = drugs().first()
            assertEquals("Propofol", d.name)
            assertTrue(d.cls.contains("Indutor") || d.cls != es.cls)
        }
    }

    @Test
    fun `drugs_preserva_cifras_en_ambos_idiomas`() {
        I18n.init()
        val esDoses = drugs().map { it.dose }
        listOf(Lang.EN, Lang.PT).forEach { lang ->
            withLang(lang) {
                drugs().forEachIndexed { i, d ->
                    assertEquals(
                        "cifras intactas en ${lang.code} fármaco ${d.name}",
                        digits(esDoses[i]), digits(d.dose)
                    )
                }
            }
        }
    }

    @Test
    fun `buscador_y_presentacion_usan_claves_estables`() {
        I18n.init()
        withLang(Lang.EN) {
            // clave estable: presentación y preparación localizables por nombre INN
            val pres = drugPresentation()["Propofol"]
            assertTrue("presentación traducida", pres != null && pres != DRUG_PRESENTATION_RAW["Propofol"])
            val prep = drugPrep()["Propofol"]
            assertTrue("preparación traducida", prep != null && prep!!.prep != DRUG_PREP_RAW["Propofol"]!!.prep)
            // búsqueda por clase traducida funciona sobre drugs()
            assertTrue(drugs().any { it.cls.lowercase().contains("alkylphenol") })
        }
    }

    @Test
    fun `gases_traducidos_con_mac_intacto`() {
        I18n.init()
        val es = GASES_RAW.first()
        assertEquals("Sevoflurano", es.name)
        withLang(Lang.EN) {
            val g = gases().first()
            assertEquals("Sevoflurano", g.name)
            assertTrue(g.props != es.props)
            assertEquals(digits(es.mac), digits(g.mac))
        }
    }

    // ---------------------- 3. Temas clínicos (ola 2) ----------------------

    @Test
    fun `temas_clinicos_traducidos_con_estructura_intacta`() {
        I18n.init()
        val doms = listOf(
            comorbidities(), regionalBlocks(), monitoring(), preopTopics(),
            equipmentTopics(), surgicalTopics()
        )
        assertEquals("51 temas clínicos", 51, doms.sumOf { it.size })
        listOf(Lang.EN, Lang.PT).forEach { lang ->
            withLang(lang) {
                doms.forEachIndexed { di, list ->
                    list.forEachIndexed { ti, t ->
                        val raw = doms[di].size // estabilidad de tamaño
                        assertEquals("secciones de tema ${t.title}", doms[di][ti].sections.size, t.sections.size)
                        assertTrue(t.title.isNotBlank())
                        t.sections.forEach { (h, b) ->
                            assertTrue(h.isNotBlank())
                            assertTrue(b.isNotBlank())
                        }
                    }
                }
            }
        }
        withLang(Lang.EN) {
            assertNotEquals(comorbidities().first().title, COMORBIDITIES_RAW.first().title)
            assertTrue(comorbidities().first().sections.first().second != COMORBIDITIES_RAW.first().sections.first().second)
        }
    }

    @Test
    fun `calcid_nunca_se_traduce`() {
        I18n.init()
        withLang(Lang.EN) {
            (comorbidities() + regionalBlocks() + monitoring() + preopTopics() +
                equipmentTopics() + surgicalTopics())
                .filter { it.calcId.isNotBlank() }
                .forEach { t ->
                    assertTrue(
                        "calcId estable en ${t.title}: ${t.calcId}",
                        t.calcId in setOf("cpp", "anh", "meld", "mgso4", "qpqs", "resp", "cardio", "cec", "trauma", "olv", "lap", "lamax")
                    )
                }
        }
    }

    // ---------------------- 4. Escalas (ola 3) ----------------------

    @Test
    fun `escalas_traducidas_con_opciones_e_interpretacion`() {
        I18n.init()
        assertEquals(16, SCALES_RAW.size)
        val esEva = SCALES_RAW.first { it.sliderMax > 0 }
        assertEquals("EVA", esEva.name.substringBefore(" "))
        withLang(Lang.EN) {
            val eva = scales().first { it.sliderMax > 0 }
            assertTrue("nombre EVA traducido (la detección usa sliderMax, no el nombre)", eva.name != esEva.name)
            assertTrue(eva.interpretation != esEva.interpretation)
            scales().forEachIndexed { i, s ->
                assertEquals("grupos de ${s.name}", SCALES_RAW[i].groups.size, s.groups.size)
                s.groups.forEach { g -> g.options.forEach { o -> assertTrue(o.label.isNotBlank()) } }
            }
        }
        withLang(Lang.PT) {
            assertNotEquals(scales().first().desc, SCALES_RAW.first().desc)
        }
    }

    @Test
    fun `emergencias_traducidas_pasos_y_dosis`() {
        I18n.init()
        assertEquals(6, EMERGENCIES_RAW.size)
        withLang(Lang.EN) {
            val es = EMERGENCIES_RAW.first()
            val a = emergencies().first()
            assertEquals(es.name, "Paro cardíaco (ACLS)")
            assertTrue(a.name != es.name)
            assertEquals("pasos ACLS", es.steps.size, a.steps.size)
            assertEquals("dosis ACLS", es.doses.size, a.doses.size)
            assertTrue(a.steps.first() != es.steps.first())
            assertEquals("cifras preservadas", digits(es.recognize), digits(a.recognize))
        }
        withLang(Lang.PT) {
            assertTrue(emergencies().first().name != EMERGENCIES_RAW.first().name)
        }
    }

    // ---------------------- 5. Complicaciones, premedicación, soluciones (ola 4) ----

    @Test
    fun `complicaciones_premedicacion_y_soluciones_traducidos`() {
        I18n.init()
        assertEquals(14, COMPLICATIONS_RAW.size)
        assertEquals(14, PREMED_TOPICS_RAW.size)
        assertEquals(8, SOLUTIONS_RAW.size)
        withLang(Lang.EN) {
            assertNotEquals(complications().first().name, COMPLICATIONS_RAW.first().name)
            assertNotEquals(premedTopics().first().body, PREMED_TOPICS_RAW.first().body)
            assertNotEquals(solutions().first().body, SOLUTIONS_RAW.first().body)
            assertEquals(digits(COMPLICATIONS_RAW.first().management), digits(complications().first().management))
        }
        withLang(Lang.PT) {
            assertNotEquals(complications().first().name, COMPLICATIONS_RAW.first().name)
            assertNotEquals("cuerpo de solución traducido (el título «NaCl 0,9%» es cognado)", 
                solutions().first().body, SOLUTIONS_RAW.first().body)
        }
    }

    @Test
    fun `perlas_traducidas_y_video_intacto`() {
        I18n.init()
        withLang(Lang.EN) {
            val es = PEARLS_RAW.first()
            val p = pearls().first()
            assertTrue(p.titulo != es.titulo)
            assertEquals("video Medik Brain sin traducir", es.video, p.video)
            assertEquals("claves", es.claves.size, p.claves.size)
            assertTrue(p.aplicacion.isNotBlank() && p.alarma.isNotBlank())
        }
    }

    @Test
    fun `maquina_traducida_por_render`() {
        I18n.init()
        val es = MACHINE_PARTS.first()
        withLang(Lang.EN) {
            assertEquals("los datos RAW no cambian", es.name, MACHINE_PARTS.first().name)
            assertNotEquals("el render traduce vía tr()", es.name, es.name.tr())
            assertNotEquals(es.role, es.role.tr())
        }
    }

    // ---------------------- 6. Perfiles de dosis ----------------------

    @Test
    fun `perfiles_dosis_claves_estables_y_notas_traducidas`() {
        I18n.init()
        val es = DRUG_DOSE_PROFILES_RAW["Propofol"]!!
        withLang(Lang.EN) {
            val p = drugDoseProfiles()["Propofol"]!!
            assertTrue(p.generalNote != es.generalNote)
            assertEquals("regímenes", es.regimens.size, p.regimens.size)
            assertNotEquals(p.regimens.first().label, es.regimens.first().label)
            assertEquals("diluciones", es.regimens[1].dilutions.size, p.regimens[1].dilutions.size)
        }
        withLang(Lang.PT) {
            assertTrue(drugDoseProfiles()["Propofol"]!!.generalNote != es.generalNote)
        }
    }

    // ---------------------- 7. Cambio de idioma en caliente ----------------------

    @Test
    fun `accesores_reevaluan_al_cambiar_idioma_sin_congelar`() {
        I18n.init()
        val esCls = drugs().first().cls
        L10n.current = Lang.EN
        val enCls = drugs().first().cls
        L10n.current = Lang.ES
        val esAgain = drugs().first().cls
        L10n.current = Lang.PT
        val ptCls = drugs().first().cls
        L10n.current = Lang.ES
        assertEquals("vuelta a español sin residuos", esCls, esAgain)
        assertNotEquals(esCls, enCls)
        assertNotEquals(enCls, ptCls)
    }

    @Test
    fun `manual_checklist_y_secciones_reevaluan`() {
        I18n.init()
        withLang(Lang.EN) {
            assertTrue(manualIntro() != "Cronos Anestesia es una referencia rápida de anestesiología que funciona 100% sin conexión: ")
            assertTrue(clinSections().first() != "Comorbilidades")
            assertEquals("momento del checklist traducido", "Before skin incision", "Antes de la incisión cutánea".tr())
        }
        withLang(Lang.PT) {
            assertEquals("Antes da incisão da pele", "Antes de la incisión cutánea".tr())
        }
    }

    // ---------------------- 8. BIBLIO y degradación ----------------------

    @Test
    fun `biblio_citas_permanecen_en_idioma_original`() {
        I18n.init()
        withLang(Lang.EN) {
            assertEquals("citas intactas (24) y sin traducir", 24, BIBLIO.size)
            assertEquals("Miller's Anesthesia", BIBLIO.first().title)
        }
    }

    @Test
    fun `cadena_no_registrada_degrada_a_espanol`() {
        I18n.init()
        withLang(Lang.EN) {
            assertEquals("Texto clínico inexistente en tablas", "Texto clínico inexistente en tablas".tr())
        }
    }
}
