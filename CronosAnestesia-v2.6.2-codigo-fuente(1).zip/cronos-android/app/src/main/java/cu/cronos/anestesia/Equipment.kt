package cu.cronos.anestesia

// =====================================================================
//  EQUIPOS Y MATERIALES DE ANESTESIA (v2.1.0 — requisito «máquina de
//  anestesia: partes y funciones» + «materiales de uso en anestesia»
//  + checklists de verificación de máquina y de seguridad quirúrgica).
//  Contenido didáctico propio: sin fotografías de terceros; el esquema
//  de la máquina es vectorial (Canvas) y animado (EquipmentUI.kt).
// =====================================================================

/** Parte de la máquina de anestesia (ficha didáctica). */
data class MachinePart(
    val id: String,
    val name: String,
    val function: String,
    val verify: String,
    val failures: String,
    val zone: String? = null // zona dibujada en el esquema; null = solo en la lista
)

val MACHINE_PARTS = listOf(
    MachinePart(
        "fuentes_gas", "Fuentes de gases (red de pared)",
        "Suministra O2, aire y N2O desde la red central a ~4 bares (400 kPa) mediante mangueras con sistema de seguridad no intercambiable (NIST/DISS): cada manguera solo conecta con el puerto de su gas.",
        "Manómetros de las tres fuentes en 4 bares antes de empezar; mangueras conectadas sin deformaciones; analizador de O2 calibrado.",
        "Presión baja en la red (fuga o planta apagada), manguera cruzada o dañada, conector forzado que fuga; la única evidencia es el manómetro: mírelo siempre.",
        zone = "fuentes_gas"
    ),
    MachinePart(
        "cilindros", "Cilindros de reserva (tipo E)",
        "Respaldo de O2 y N2O montado detrás de la máquina. Un cilindro E de O2 rinde ~600 L a 137 bares y permite ventilar manualmente si falla la red de pared.",
        "Cilindros con al menos 2/3 de presión (O2 > 90 bares); llaves cerradas cuando se usa la red (evita la descarga silenciosa); empaques en buen estado.",
        "Descarga silenciosa si la llave queda abierta con la red conectada; cilindro vacío descubierto durante una crisis; fuga en la válvula piñón.",
        zone = "cilindros"
    ),
    MachinePart(
        "mesa_flujo", "Mesa de flujo (rotámetros)",
        "Regula el volumen de cada gas (L/min) con tubos verticales de área variable; la mezcla resultante pasa al vaporizador. El mando de O2 es el más grande, estriado y con palanca protectora.",
        "Flotadores estables y centrados; tubos limpios y secos; giro a cero cierra el flujo; la FiO2 medida coincide con la mezcla fijada.",
        "Flotador pegado (lectura falsa), fuga interna que entrega más gas del fijado, giro accidental del mando de O2, error de lectura por ángulo de visión.",
        zone = "mesa_flujo"
    ),
    MachinePart(
        "vaporizadores", "Vaporizadores (variable bypass)",
        "Añaden el agente halogenado a la mezcla fresca en concentración controlada (vol%): una fracción del flujo pasa por la cámara saturada y se vuelve a mezclar; compensados por presión y temperatura.",
        "Nivel de agente entre las marcas (sin sobrellenar), tapa cerrada, bloqueado firmemente en el backbar, un solo vaporizador encendido, concentración marcada confirmada.",
        "Sobrellenado (concentración acumulativa inesperada), fuga residual al apagar, vaporizador vacío sin aviso, bloqueo incompleto con fuga masiva.",
        zone = "vaporizadores"
    ),
    MachinePart(
        "backbar", "Backbar y válvula de alivio",
        "Barra común donde se montan los vaporizadores; lleva la válvula de alivio de exceso de presión del sistema de baja presión y la conexión hacia el circuito respiratorio.",
        "Vaporizadores asentados sin juego; sin agentes derramados; válvula de alivio libre y sin suciedad.",
        "Fuga por vaporizador mal asentado; obstrucción del backbar por suciedad o agentes cristalizados."
    ),
    MachinePart(
        "absorvedor", "Absorvedor de CO2 (cal sodada)",
        "Elimina el CO2 exhalado por reacción química con la cal (o hidróxido de calcio): permite reutilizar el gas economizando agente y gases en circuito semicerrado o cerrado.",
        "Indicador de color fresco (violeta: fresca; blanco/amarillo: agotada), granulado duro sin polvo, canister cerrado sin fugas.",
        "Cal agotada (rebreathing, ETCO2 ascendente), canister mal cerrado (fuga), cal seca (genera monóxido de carbono con los agentes: evite flujos altos estacionarios prolongados).",
        zone = "absorvedor"
    ),
    MachinePart(
        "circuito", "Circuito respiratorio (círculo)",
        "Manguitos inspiratorio y espiratorio con pieza en Y (volumen adulto ~1,5 L). Conduce el gas fresco al paciente y devuelve la exhalación al absorvedor y a la bolsa reservorio.",
        "Circuito y filtro (HME) nuevos por paciente; prueba de presión: ocluida la Y, 30 cmH2O sostenidos sin caída; sin acodamientos ni conexiones flojas.",
        "Desconexión (causa principal de eventos críticos), fuga por mala unión, acodamiento; en pediatría usar circuito de bajo volumen muerto.",
        zone = "circuito"
    ),
    MachinePart(
        "valvulas_uni", "Válvulas unidireccionales",
        "Dos micas (inspiratoria y espiratoria) que obligan al gas a circular en un solo sentido: evitan el rebreathing y garantizan que la exhalación cruce el absorvedor.",
        "Micas visibles y móviles al insuflar con la bolsa; sin condensación excesiva que las pegue.",
        "Mica pegada por humedad → rebreathing con hipercapnia y ETCO2 ascendente; mica rota o mal montada (poco frecuente)."
    ),
    MachinePart(
        "bolsa", "Bolsa reservorio (2–3 L)",
        "Almacena gas entre ciclos, permite ventilar manualmente y amortigua las presiones; su movimiento informa del patrón respiratorio del paciente.",
        "Bolsa íntegra y del tamaño adecuado (adulto 2–3 L); recupera su forma tras la prueba de fuga.",
        "Bolsa rota o mal conectada (fuga total), sobredistensión con presión peligrosa si la APL queda cerrada."
    ),
    MachinePart(
        "apl", "Válvula APL (pop-off)",
        "Válvula ajustable de límite de presión: abierta en ventilación espontánea (exhalación libre); ajustada en ventilación manual para generar presión positiva controlada (15–20 cmH2O típico).",
        "Gira suavemente de abierto a cerrado; presión de alivio verificada durante la prueba de fuga del circuito.",
        "Olvidada cerrada en ventilación espontánea → barotrauma; abierta en ventilación manual → no genera presión; desgaste con fuga."
    ),
    MachinePart(
        "ventilador", "Ventilador (fuelles y modos)",
        "Ventila mecánicamente ciclando el circuito: VCV (volumen) o PCV (presión), con frecuencia, relación I:E y PEEP ajustables. Fuelles ascendentes: si no se llenan en la espiración hay fuga.",
        "Con pulmón de prueba: cicla el volumen fijado, los fuelles se llenan por completo; límites de presión y PAWI ajustados; batería cargada.",
        "No cicla o entrega menos volumen del fijado (fuga), fuelle que no se llena, corte eléctrico sin batería: volver siempre a ventilación manual y evaluar al paciente.",
        zone = "ventilador"
    ),
    MachinePart(
        "alarmas", "Alarmas integradas",
        "Vigilan presión de vías aéreas (PAWI), apnea, FiO2, SpO2, volumen minuto, batería y gas agotado; son la primera línea de detección de desconexiones y fugas.",
        "Alarmas activadas (nunca silenciadas de forma fija) y límites personalizados antes de inducir.",
        "Silenciador crónico (la desconexión llega sin aviso), límites mal ajustados que ocultan eventos reales.",
        zone = "alarmas"
    ),
    MachinePart(
        "monitores", "Monitoreo del paciente",
        "ECG, SpO2, presión no invasiva, capnografía (confirmación de intubación), temperatura y análisis del agente, integrado en la máquina o en torre independiente.",
        "Pantalla encendida, valores basales capturados antes de inducir, capnógrafo calibrado con línea de muestreo nueva.",
        "SpO2 errónea por movimiento o hipoperfusión, línea de capnografía desconectada (trazo plano no es apnea necesariamente), manguito de PANI mal colocado.",
        zone = "monitores"
    ),
    MachinePart(
        "flush", "Botón de O2 (flush)",
        "Entrega O2 directo a alta velocidad (35–75 L/min) al circuito para llenar rápido la bolsa o lavarlo; NO pasa por los rotámetros ni por el vaporizador (no añade agente).",
        "Al presionarlo la bolsa se llena al instante y cesa al soltar; nunca se usa con la Y ocluida.",
        "Uso prolongado con la vía ocluida → barotrauma; confusión con el mando de flujo; diluye la concentración del agente en el circuito.",
        zone = "flush"
    ),
    MachinePart(
        "scavenging", "Evacuación de gases (scavenging)",
        "Recoge el gas exhalado por la APL y el alivio del ventilador y lo saca del quirófano (sistema pasivo por tubería o activo por aspiración), protegiendo al personal de la exposición crónica.",
        "Tubería conectada al puerto de evacuación; sistema activo con presión verificada; bolsa colapsadora sin colapso total (riesgo de presión negativa).",
        "Desconectado (contaminación del aire del quirófano), obstruido (presión en el circuito), aspiración excesiva que vacía la bolsa."
    )
)

/** Material de uso en anestesia (catálogo por categorías). */
data class SupplyItem(
    val category: String,
    val name: String,
    val sizes: String,
    val use: String,
    val keys: String
)

val SUPPLY_CATEGORIES = listOf("Vía aérea", "Accesos vasculares", "Regional", "Consumibles")

val SUPPLIES = listOf(
    // ---------------- VÍA AÉREA ----------------
    SupplyItem(
        "Vía aérea", "Mascarilla facial", "Neonatal 0/1 · infantil 1/2 · adulta 3/4/5",
        "Ventilación con mascarilla, preoxigenación al 100% durante 3–5 min y soporte durante la inducción.",
        "Sello con maniobra E-C y elevación mandibular; la mínima presión efectiva (evitar insuflación gástrica); transparente para detectar vómito o nebulizado."
    ),
    SupplyItem(
        "Vía aérea", "Cánula orofaríngea (Guedel)", "000 a 4 (6–9 cm neonato → 10–13 cm adulto grande)",
        "Mantiene la vía aérea abierta en el paciente inconsciente sin reflejos faríngeos intactos.",
        "Tamaño: de los incisivos al ángulo mandibular; si hay reflejo puede provocar laringoespasmo o vómito; alternativa nasofaríngea si hay trismus."
    ),
    SupplyItem(
        "Vía aérea", "Laringoscopio y hojas", "Macintosh 2–4 (adulto) · Miller 0–2 (pediatría)",
        "Exposición glótica para intubación orotraqueal directa.",
        "Verificar foco y pila antes de cada sesión; hoja acodada al insertar y desplazamiento de la epiglotis (Mac) o levantamiento directo (Miller); tener dos tamaños a mano."
    ),
    SupplyItem(
        "Vía aérea", "Tubo endotraqueal", "ID adulto: 7,0–7,5 (mujer) · 8,0–8,5 (hombre); pediátrico: (edad/4)+4 sin manguito",
        "Vía aérea definitiva: ventilación controlada, protección de la vía aérea y administración de gases.",
        "Balón con presión de sellado < 25–30 cmH2O; marca de profundidad junto a las cuerdas (adulto ~21–23 cm en comisura); auscultación bilateral + capnografía para confirmar."
    ),
    SupplyItem(
        "Vía aérea", "Máscara laríngea (LMA)", "Tamaños 2–5 (≈ peso/10 + 1 en niños)",
        "Vía aérea supraglótica para anestesia general espontánea o ventilación controlada breve; rescatadora en vía aérea difícil.",
        "Insertar desinflada con el índice siguiendo el paladar duro; fugas o distensión gástrica obligan a reposicionar; no protege del vomito (no es vía aérea definitiva)."
    ),
    SupplyItem(
        "Vía aérea", "Guía rígida (bougie) y estilete", "Bougie 15 Fr × 60 cm · estilete con tope",
        "Facilitan la intubación cuando la glotis está parcialmente visible (Cormack II–III) o dan forma al tubo.",
        "Con bougie: pasar bajo la epiglotis, sentir las tráqueas y avanzar el tubo sobre ella (click = en tráquea); el estilete nunca debe sobresalir del tubo."
    ),
    SupplyItem(
        "Vía aérea", "Filtro HME / intercambiador", "Adulto y pediátrico; con puerto de muestreo de CO2",
        "Calienta y humidifica el gas inspirado y filtra microorganismos entre paciente y circuito.",
        "Uno nuevo por paciente; puede añadir volumen muerto y resistencia (cuidado en pediatría y en pacientes con baja reserva); reemplazar si se empapa."
    ),
    SupplyItem(
        "Vía aérea", "Equipo de vía aérea difícil", "Mascarilla, LMA, bougie, tubos alternos, cricotiroidotomía",
        "Rescate según algoritmo (CICO/DAS): ventilación fallida + intubación fallida exige escalonar sin demora.",
        "Tenerlo visible en el quirófano para cada caso; declarar «no puedo ventilar / no puedo intubar» en voz alta para activar al equipo."
    ),
    // ---------------- ACCESOS VASCULARES ----------------
    SupplyItem(
        "Accesos vasculares", "Catéter venoso periférico", "18–20 G adulto (sangrado rápido: 14–16 G) · 22–24 G pediátrico",
        "Vía principal de fármacos, fluidos y transfusión en el perioperatorio.",
        "El calibre manda en el flujo (duplicar el radio cuadruplica el flujo); dos vías si se espera sangrado; fijación con apósito transparente y llave para administración."
    ),
    SupplyItem(
        "Accesos vasculares", "Llave de 3 pasos y extensión", "Extensión 10–25 cm; llave con tapón luer-lock",
        "Distribuyen la línea para administrar fármacos sin restringir el campo quirúrgico.",
        "Cada llave añade un punto de desconexión y fuga: trazarla con orden (línea de vasoactivos separada); purgarla antes de usar."
    ),
    SupplyItem(
        "Accesos vasculares", "Equipo de goteo con filtro", "Macro 10–20 gotas/mL · micro 60 gotas/mL (pediatría)",
        "Fluidoterapia básica y diluciones continuas sin bomba de infusión.",
        "Cuenta de gotas por minuto = velocidad deseada (mL/h) ÷ factor del equipo × 1/60; ventana visible para detectar aire; cambio cada 24–72 h según protocolo."
    ),
    SupplyItem(
        "Accesos vasculares", "Catéter venoso central", "Adulto: triple luz 7 Fr · pediátrico según peso",
        "Vasoactivos concentrados, nutrición, medición de PVC, volumen rápido en cirugía mayor.",
        "Complicaciones: punción arterial, neumotórax, arritmia por avance (retirar si hay); confirmar posición con gasometría/radiografía; técnica estéril máxima."
    ),
    SupplyItem(
        "Accesos vasculares", "Kit arterial (canalización)", "20 G radial adulto · 22–24 G pediátrico",
        "Presión invasiva latido a latido y gasometrías seriadas (cirugía mayor, cardiópatas, UCI).",
        "Test de Allen antes de la radial; transductor a nivel del corazón y cero atmosférico; curva con dicrotismo = arterial (no venosa)."
    ),
    SupplyItem(
        "Accesos vasculares", "Jeringa de gasometría", "1–2 mL con heparina seca",
        "Gasometría arterial o venosa: oxigenación, ventilación, electrolitos, lactato, glucosa.",
        "Llenar sin burbujas y analizar en < 15 min (o en hielo); anotar temperatura del paciente; etiquetar siempre la vía (arterial/venosa)."
    ),
    // ---------------- REGIONAL ----------------
    SupplyItem(
        "Regional", "Aguja espinal (punta de lápiz)", "25–27 G Whitacre/Sprotte · 24–25 G bisel fino",
        "Anestesia subaracnoidea: bloqueo del LCR en un solo pinchazo con mínima cefalea post-punción.",
        "Punta de lápiz reduce la cefalea post-punción dural frente al bisel cortante; introducir con el bisel longitudinal si es de bisel; la salida de líquido cefalorraquídeo claro confirma el espacio."
    ),
    SupplyItem(
        "Regional", "Aguja de Tuohy (epidural)", "16–18 G × 8–9 cm",
        "Canalización del espacio epidural con pérdida de resistencia y colocación de catéter (analgesia de parto, bloqueo continuo).",
        "Bisel introducido longitudinalmente hacia los laterales (reduce perforación dural); perder resistencia con salina; avanzar el catéter ≤ 4–5 cm dentro del espacio."
    ),
    SupplyItem(
        "Regional", "Catéter epidural", "20 G con marca centimetrada y filtro 0,22 µm",
        "Anestesia/analgesia continua epidural: bolos o perfusión de anestésico local + opioide.",
        "Probar aspiración antes de cada dosis (sangre = vascular; líquido claro = dural); dosis de prueba y fraccionada siempre; etiquetar la vía como epidural."
    ),
    SupplyItem(
        "Regional", "Estimulador de nervio y aguja aislada", "Aguja 22–24 G × 5–10 cm · corriente 0,4–1,0 mA",
        "Localización de nervios periféricos por respuesta motora (introducción a la ecografía en bloqueos).",
        "Contracción a 0,4–0,6 mA cerca del nervio; si desaparece al inyectar, retirar (posible intrafascicular); nunca inyectar con alta presión ni dolor."
    ),
    SupplyItem(
        "Regional", "Antiséptico y kit estéril", "Clorhexidina alcohólica 0,5–2% · campos, guantes, gasas",
        "Preparación de la piel para punciones neuraxiales y vasculares: prevención de infección del sitio.",
        "Clorhexidina alcohólica con secado completo (≥ 3 min) antes de punzar; no usar alcohol en recién nacidos (riesgo de quemadura química); dejar secar antes de puncionar el espacio neuraxial."
    ),
    // ---------------- CONSUMIBLES ----------------
    SupplyItem(
        "Consumibles", "Jeringas y agujas", "2, 5, 10, 20 mL · agujas 18–27 G",
        "Preparación y administración de fármacos: inducción, relajantes, vasoactivos, regional.",
        "Etiquetar TODA jeringa preparada (droga + concentración); rotular en el momento de diluir; jeringas de relajantes separadas de las de hipnóticos."
    ),
    SupplyItem(
        "Consumibles", "Circuito del ventilador", "Adulto (1,5–2 m) · pediátrico de bajo volumen",
        "Conduce gases entre máquina y paciente; base del sistema de ventilación del caso.",
        "Nuevo por paciente; prueba de fuga y presión antes del caso; desechable: no reesterilizar los de un solo uso."
    ),
    SupplyItem(
        "Consumibles", "Cal sodada (cartucho)", "Bolsa/cartucho 1,5–2 kg · indicador de color",
        "Consumible del absorvedor: elimina el CO2 del circuito en cada caso.",
        "Cambiar cuando el indicador vire a blanco/amarillo o cuando suba el ETCO2 sin causa clínica; no sacudir (polvo); cerrar el canister sin forzar."
    ),
    SupplyItem(
        "Consumibles", "Sonda de aspiración", "Yankauer (quirófano) · sondas 10–18 Fr (vía aérea)",
        "Aspiración de secreciones, sangre y contenido gástrico; indispensable en toda inducción con riesgo de aspiración.",
        "Presión de succión en vía aérea: aplicar solo al retirar (evita hipoxemia y trauma); aspirar boca estomacal antes de la inducción si hay estómago lleno."
    ),
    SupplyItem(
        "Consumibles", "Sonda de temperatura", "Esófago (adulto) · axilar/rectal (pediatría)",
        "Monitorización de temperatura continua: prevención de hipotermia y detección de hipertermia maligna.",
        "Colocar tras la inducción en esófago distal; mantener normotermia (36 °C+) con manta de aire forzado y fluidos calientes; subida brusca de temperatura + ETCO2 = alarma de HM."
    ),
    SupplyItem(
        "Consumibles", "Manta de aire forzado y fluidos calientes", "Talla adulta/pediátrica · calentador de fluidos",
        "Mantener la normotermia perioperatoria: reduce infección, sangrado, necesidad de transfusión y morbilidad.",
        "Preinducción: abrigo y manta; intraoperatoria: 38–43 °C de aire forzado; monitorear temperatura en cirugías > 30 min."
    ),
    SupplyItem(
        "Consumibles", "Fijaciones y esparadrapo", "Micropore · apósitos transparentes · tiras estériles",
        "Fijación de tubo endotraqueal, catéteres y sondas; protección ocular (cinta suave).",
        "Fijar el tubo tras confirmar profundidad y re-verificar tras la posición definitiva (prono, Trendelenburg); ojos cerrados y protegidos SIEMPRE bajo anestesia general."
    )
)

/** Ítem de lista de verificación. */
data class CheckItem(val id: String, val label: String, val critical: Boolean = false)
data class CheckGroup(val title: String, val items: List<CheckItem>)
data class ChecklistDef(val id: String, val title: String, val subtitle: String, val groups: List<CheckGroup>)

val CHECKLISTS = listOf(
    ChecklistDef(
        "maquina", "Verificación de la máquina de anestesia",
        "Antes de la primera sesión del día y tras cualquier cambio de equipo (inspirada en ASA 2008 y en la lista estandarizada de la WFSA).",
        listOf(
            CheckGroup(
                "1. Energía y fuentes de gases",
                listOf(
                    CheckItem("m1", "Red eléctrica conectada: indicador de energía encendido y batería cargada", true),
                    CheckItem("m2", "Presión de tuberías O2, aire y N2O en 4 bares", true),
                    CheckItem("m3", "Cilindros de reserva con al menos 2/3 y llaves cerradas (si se usa la red)"),
                    CheckItem("m4", "Analizador de O2 calibrado (21% y 100%)")
                )
            ),
            CheckGroup(
                "2. Sistema de baja presión y vaporizadores",
                listOf(
                    CheckItem("m5", "Nivel de agente entre las marcas; tapa cerrada", true),
                    CheckItem("m6", "Vaporizador bloqueado en el backbar; un solo vaporizador activado"),
                    CheckItem("m7", "Prueba de fugas del sistema de baja presión (aguja estable a ~30 cmH2O)", true),
                    CheckItem("m8", "Cal sodada fresca: indicador violeta y granulado duro", true)
                )
            ),
            CheckGroup(
                "3. Circuito y ventilación",
                listOf(
                    CheckItem("m9", "Circuito y filtro (HME) nuevos por paciente, sin defectos", true),
                    CheckItem("m10", "Válvulas unidireccionales montadas y móviles"),
                    CheckItem("m11", "Prueba de fuga del circuito: Y ocluida, 30 cmH2O sostenidos", true),
                    CheckItem("m12", "Ventilador cicla con pulmón de prueba al volumen fijado", true),
                    CheckItem("m13", "PEEP y APL funcionan; bolsa reservorio íntegra")
                )
            ),
            CheckGroup(
                "4. Monitoreo y emergencias",
                listOf(
                    CheckItem("m14", "Alarmas activas: PAWI, apnea, FiO2, SpO2 y batería", true),
                    CheckItem("m15", "Capnografía lista con línea de muestreo nueva"),
                    CheckItem("m16", "Succión de vías aéreas funcionando", true),
                    CheckItem("m17", "Laringoscopio con foco, tubos, guías y equipo de vía aérea difícil a mano"),
                    CheckItem("m18", "Fármacos de emergencia preparados: atropina, adrenalina, efedrina, succinilcolina", true),
                    CheckItem("m19", "Desfibrilador accesible en el área")
                )
            )
        )
    ),
    ChecklistDef(
        "oms", "Seguridad quirúrgica (OMS)",
        "Lista de verificación de la seguridad quirúrgica de la OMS, adaptada al equipo de anestesia.",
        listOf(
            CheckGroup(
                "Entrada (Sign In)",
                listOf(
                    CheckItem("o1", "Paciente identificado, procedimiento y consentimiento confirmados", true),
                    CheckItem("o2", "Sitio quirúrgico marcado y visible", true),
                    CheckItem("o3", "Alergias verificadas en voz alta"),
                    CheckItem("o4", "Vía aérea: riesgo de dificultad o de aspiración evaluado (ayuno)", true),
                    CheckItem("o5", "Riesgo de sangrado > 500 mL (7 mL/kg en niños) evaluado y acceso venoso listo"),
                    CheckItem("o6", "Monitoreo básico conectado y valores basales registrados")
                )
            ),
            CheckGroup(
                "Pausa (Time Out)",
                listOf(
                    CheckItem("o7", "Presentación oral del equipo completo"),
                    CheckItem("o8", "Identidad del paciente, sitio y procedimiento confirmados", true),
                    CheckItem("o9", "Antibioticoprofilaxis administrada ≤ 60 min antes de la incisión"),
                    CheckItem("o10", "Estudios de imagen visibles en el quirófano"),
                    CheckItem("o11", "Plan del anestesiólogo y riesgos revisados (dosis, fluidos, sangre)", true),
                    CheckItem("o12", "Esterilidad del instrumental confirmada por enfermería")
                )
            ),
            CheckGroup(
                "Salida (Sign Out)",
                listOf(
                    CheckItem("o13", "Procedimiento registrado con el nombre correcto"),
                    CheckItem("o14", "Conteo de instrumental, gasas y agujas correcto", true),
                    CheckItem("o15", "Muestras etiquetadas y leídas en voz alta"),
                    CheckItem("o16", "Problemas de equipamiento señalados para su corrección"),
                    CheckItem("o17", "Plan de recuperación revisado: dolor, náuseas/vómitos y destino del paciente", true)
                )
            )
        )
    )
)
