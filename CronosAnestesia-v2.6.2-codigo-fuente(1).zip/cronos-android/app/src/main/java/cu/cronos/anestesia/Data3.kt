package cu.cronos.anestesia

// =====================================================================
//  DATOS v2.0.0 — Parte 1: PREPARACIÓN Y ADMINISTRACIÓN DE FÁRMACOS
//  El «plus» clínico: cómo se prepara cada fármaco (solvente, dilución,
//  concentración final, estabilidad) y cómo se administra (bolo IV,
//  perfusión continua o jeringa perfusora).
//  Formato admin: segmentos "BOLO: … | CONT: … | JERINGA: …" (los que
//  no aplican se omiten). Texto de referencia educativa, es-CU.
// =====================================================================

data class DrugPrep(
    val prep: String,
    val admin: String,
    val alias: String = ""
)

val DRUG_PREP: Map<String, DrugPrep> = mapOf(
    "Propofol" to DrugPrep(
        "Emulsión lipídica blanca 1 % (10 mg/mL) lista para uso. No diluir o diluir solo con SG5 % hasta ≥2 mg/mL. Agitar bien antes de usar. Una vez abierta la ampolla usar antes de 6 h (crecimiento bacteriano); descartar sobras y las emulsiones separadas.",
        "BOLO: inducción 1,5–2,5 mg/kg IV en 30–45 s | JERINGA: TIVA/sedación 25–100 µg/kg/min (jeringa perfusora; concentración 5–10 mg/mL)",
        "Diprivan"
    ),
    "Etomidato" to DrugPrep(
        "Solución transparente 2 mg/mL en propilenglicol; usar directo sin diluir. Estable a temperatura ambiente; no refrigerar (puede precipitar).",
        "BOLO: 0,2–0,3 mg/kg IV en 30–60 s (puede doler en la vía: preceder con lidocaína 1 mg/kg)"
    ),
    "Tiopental" to DrugPrep(
        "Polvo liofilizado 0,5–1 g: reconstituir con agua estéril para inyección o SF 0,9 % a 25 mg/mL (2,5 %). Solución alcalina (pH 10–11): incompatible con fármacos ácidos (relajantes, opioides) en la misma línea; lavar la vía antes y después. Usar en las primeras 24 h.",
        "BOLO: inducción 3–5 mg/kg IV (pediátrico 5–6 mg/kg); status epilepticus 3–5 mg/kg repetible",
        "Pentotal"
    ),
    "Ketamina" to DrugPrep(
        "Ampollas 50 mg/mL (10 mL) y 100 mg/mL (2 mL). Diluir con SF 0,9 % a 10 mg/mL (1 %) para titulación IV; analgesia subanestésica diluir a 1 mg/mL. Proteger de la luz. Conserva 2–8 °C ideal, estable a TA.",
        "BOLO: inducción 1–2 mg/kg IV, 4–8 mg/kg IM | CONT: analgesia 0,1–0,5 mg/kg/h en jeringa perfusora (1 mg/mL) | JERINGA: sedación 0,5–2 mg/kg/h",
        "Ketalar"
    ),
    "Midazolam" to DrugPrep(
        "Ampollas 5 mg/5 mL (1 mg/mL). Diluir con SF 0,9 % o SG5 % a 0,1 mg/mL (1:10) para titulación fina. Estable 24 h a temperatura ambiente y protegido de la luz.",
        "BOLO: sedación 0,02–0,05 mg/kg IV titulado; crisis 0,1–0,2 mg/kg | JERINGA: sedación UCI 0,02–0,1 mg/kg/h",
        "Dormicum"
    ),
    "Diazepam" to DrugPrep(
        "Solución oleosa 5 mg/mL: NO diluir con otros fármacos ni con SF (turbidez); usar directo IV lento por vía gruesa (dolor y flebitis frecuentes). La presentación lipídica (Diazemuls) sí puede diluirse.",
        "BOLO: 2–10 mg IV lento (≤5 mg/min); convulsiones 5–10 mg IV repetible c/10–15 min",
        "Valium"
    ),
    "Dexmedetomidina" to DrugPrep(
        "Ampolla 100 µg/mL (2 mL = 200 µg): diluir 200 µg en 48 mL de SF 0,9 % → 4 µg/mL en jeringa de 50 mL. Estable 24 h. No usar en bolo rápido (bradicardia/hipotensión).",
        "JERINGA: carga 0,5–1 µg/kg en 10–15 min + mantenimiento 0,2–0,7 µg/kg/h",
        "Precedex"
    ),
    "Fentanilo" to DrugPrep(
        "Ampollas 50 µg/mL. Dilución estándar: 500 µg (10 mL) + 40 mL de SF 0,9 % = 10 µg/mL en jeringa de 50 mL. Estable 24 h a temperatura ambiente; vigilar el volumen total (opioide muy potente).",
        "BOLO: inducción 1–3 µg/kg; intraoperatorio 0,5–1 µg/kg | JERINGA: infusión 0,7–2 µg/kg/h (analgesia PCA alternativa 1 µg/mL)",
        "Sublimaze"
    ),
    "Remifentanilo" to DrugPrep(
        "Polvo liofilizado 1–5 mg: reconstituir SOLO con SF 0,9 % o SG5 % a 20–50 µg/mL. Estable 24 h a TA (renovar por prudencia cada 12 h). Línea dedicada: la falta de contexto (efecto en 3–5 min) exige disponibilidad permanente.",
        "JERINGA: 0,05–0,25 µg/kg/min de mantenimiento; intubación 0,5–1 µg/kg/min con propofol (sin bolo en mantenimiento). NO sirve como analgesia postoperatoria: pasar a otro opioide antes de terminar"
    ),
    "Morfina" to DrugPrep(
        "Ampolla 10 mg/mL: diluir 10 mg en 10 mL de SF 0,9 % → 1 mg/mL. Proteger de la luz; estable 24 h. En neonatos/lactantes diluir a 0,1 mg/mL.",
        "BOLO: 0,02–0,05 mg/kg IV titulado (adulto 2–4 mg) | CONT: analgesia 1–2 mg/h IV (PCA 1 mg/mL, bloqueo 10 min) o epidural preservativa 0,05–0,1 mg/mL",
        "Morfina clorhidrato"
    ),
    "Petidina (Meperidina)" to DrugPrep(
        "Ampolla 100 mg/2 mL: diluir en SF 0,9 % a 10 mg/mL. No mezclar con soluciones alcalinas (precipita). Evitar en infusión prolongada y en ERC (acumula noremeperidina convulsivante).",
        "BOLO: 0,5–1 mg/kg IV titulado (adulto 25–100 mg); escalofríos 0,3–0,5 mg/kg IV",
        "Demerol · Meperidina"
    ),
    "Tramadol" to DrugPrep(
        "Ampolla 100 mg/2 mL: diluir en SF 0,9 % o SG5 % a 10 mg/mL; compatible con la mayoría de las líneas. No superar 400–600 mg/día.",
        "BOLO: 1–2 mg/kg IV lento (50–100 mg en 2–3 min) | CONT: 100–300 mg/día en bomba de infusión o PCA",
        "Ultram"
    ),
    "Dipirona (Metamizol)" to DrugPrep(
        "Ampolla 2 g/5 mL: diluir en 10–20 mL de SF 0,9 % e infundir lento (≥1 mg/kg/min ≈ 3–5 min por gramo) para evitar hipotensión y reacción anafiláctica. Proteger de la luz.",
        "BOLO: 1–2 g IV lenta c/6–8 h (máx. 5 g/día; adulto mayor 1 g)",
        "Novalgina · Analgin"
    ),
    "Paracetamol (Acetaminofén)" to DrugPrep(
        "Frasco IV 1 g/100 mL listo para infundir en ≥15 min (no diluir); compatible con SF y SG5 % por línea propia o llave en Y. VO: jarabe 120 mg/5 mL o comprimidos 500 mg.",
        "BOLO: 1 g IV c/6 h (15 mg/kg; máx. 4 g/día; máx. 3 g/día en >75 años, bajo peso o hepatopatía)",
        "Acetaminofén · Tylenol"
    ),
    "Suxametonio (Succinilcolina)" to DrugPrep(
        "Ampolla 100 mg/2 mL (50 mg/mL): usar directo o diluir a 10 mg/mL para titulación. MANTENER REFRIGERADO 2–8 °C: fuera del frío se degrada (pierde potencia y libera histamina); descartar ampollas turbias o vencidas.",
        "BOLO: RSI 1–1,5 mg/kg IV (aparición 45 s, duración 6–10 min); laringoespasmo 0,5–1 mg/kg; IM pediátrico 2–4 mg/kg sin vía IV",
        "Anectine · Escolina"
    ),
    "Rocuronio" to DrugPrep(
        "Ampolla 10 mg/mL: usar directo; para RSI NO diluir (1–1,2 mg/kg). Estable 30 días a TA y 60 días refrigerado (2–8 °C).",
        "BOLO: 0,6 mg/kg (intubación 60–90 s) o 1–1,2 mg/kg RSI | JERINGA: bloqueo continuo 8–12 µg/kg/min guiado por TOF",
        "Esmeron"
    ),
    "Vecuronio" to DrugPrep(
        "Liofilizado 10 mg: reconstituir con 10 mL de agua estéril o SF → 1 mg/mL; usar en las primeras 24 h (sin conservantes: estabilidad limitada).",
        "BOLO: 0,08–0,1 mg/kg | JERINGA: 0,8–1,7 µg/kg/min guiado por TOF (acumula en renal: preferir cisatracurio)"
    ),
    "Atracurio" to DrugPrep(
        "Ampolla 10 mg/mL: conservar 2–8 °C y proteger de la luz. Degradación por Hofmann independiente del riñón e hígado.",
        "BOLO: 0,5 mg/kg | JERINGA: 4–12 µg/kg/min guiado por TOF (histamina a dosis altas: ir lento)"
    ),
    "Cisatracurio" to DrugPrep(
        "Ampolla 2 mg/mL: refrigerar 2–8 °C. Isómero del atracurio sin liberación de histamina: el de elección en el paciente renal/hepático grave.",
        "BOLO: 0,15–0,2 mg/kg (2 × ED95; intubación 2–3 min) | JERINGA: 1–3 µg/kg/min (Hofmann, acumulación mínima)",
        "Nimbex"
    ),
    "Sugammadex" to DrugPrep(
        "Frasco-ampolla 100 mg/mL (2, 5 o 10 mL): usar directo; diluir a 10 mg/mL solo si la vía es muy fina. Caro y escaso: reservar para el rescate documentado.",
        "BOLO: 2 mg/kg con TOF 2–3; 4 mg/kg si reaparece el bloqueo o tras rocuronio de RSI; 16 mg/kg de rescate inmediato («sandwich») tras rocuronio a los 3 min"
    ),
    "Neostigmina + Atropina (reversión)" to DrugPrep(
        "Preparación clásica en la misma jeringa: neostigmina 2,5 mg (1 mL) + atropina 1 mg (1 mL) → relación 1 mg : 0,4 mg. Mezclar en el momento; no almacenar la mezcla.",
        "BOLO: neostigmina 0,04–0,07 mg/kg + atropina 0,015–0,02 mg/kg (o glicopirrolato 0,01 mg/kg) IV lenta en 60 s con TOF vigilado"
    ),
    "Efedrina" to DrugPrep(
        "Ampolla 30 mg/mL: diluir 30 mg (1 mL) en 10 mL de SF 0,9 % → 3 mg/mL para bolos titulados. No necesita protección de la luz.",
        "BOLO: 3–6 mg IV repetible c/2–3 min (hipotensión espinal; obstetricia según protocolo) · IM: 0,5–1 mg/kg"
    ),
    "Fenilefrina" to DrugPrep(
        "Ampolla 10 mg/mL: diluir 1 mg (0,1 mL) en 100 mL de SF → 10 µg/mL para bolos; para bomba 2 mg en 50 mL → 40 µg/mL. Alta concentración sin diluir = errores graves: siempre diluir.",
        "BOLO: 50–100 µg IV (obstetricia profilaxis 100–200 µg según protocolo) | JERINGA: 0,25–1 µg/kg/min",
        "Neosinefrina"
    ),
    "Adrenalina (Epinefrina)" to DrugPrep(
        "Ampolla 1 mg/mL (1:1000). Para IV diluir SIEMPRE: 1 mg en 100 mL de SF → 10 µg/mL (bolos de 50–100 µg) o 1 mg en 250 mL → 4 µg/mL para bomba. La ampolla sin diluir es solo para IM de anafilaxia (0,5 mg) y RCP.",
        "BOLO: anafilaxia 0,5 mg IM (0,5 mL de la 1:1000) repetir c/5 min; RCP 1 mg IV c/3–5 min | CONT: 0,01–0,3 µg/kg/min (anafilaxia refractaria/hipotensión)",
        "Epinefrina"
    ),
    "Labetalol" to DrugPrep(
        "Ampolla 100 mg/20 mL (5 mg/mL): bolos directos de 5–20 mg; para infusión diluir 100 mg en 100 mL de SF o SG5 % → 1 mg/mL.",
        "BOLO: 5–20 mg IV c/5–10 min (máx. 300 mg) | CONT: 0,5–2 mg/min (preeclampsia/crisis hipertensiva)",
        "Trandate"
    ),
    "Amiodarona" to DrugPrep(
        "Ampolla 150 mg/3 mL (50 mg/mL): diluir SIEMPRE en SG5 % (precipita con salino). Bolo: 150 mg en 100 mL de SG5 % (1,5 mg/mL) en 10 min, por vía central si es posible; usar filtro en la infusión.",
        "BOLO: 150–300 mg IV en 10–20 min (arritmias; paro: 300 mg) | CONT: 1 mg/min × 6 h + 0,5 mg/min × 18 h (máx. 2 g/24 h)",
        "Cordarone"
    ),
    "Metoclopramida" to DrugPrep(
        "Ampolla 10 mg/2 mL: usar directo IV lento o diluida en 10 mL de SF. No diluir con fármacos alcalinos.",
        "BOLO: 10 mg IV lento (proquinético preoperatorio; pediátrico 0,1–0,15 mg/kg)"
    ),
    "Ranitidina" to DrugPrep(
        "Ampolla 50 mg/2 mL: diluir en 20 mL de SF e infundir en >2 min (bradicardia con bolo rápido).",
        "BOLO: 50 mg IV c/8 h (protección gástrica en aspiración: con citrato y metoclopramida)"
    ),
    "Cimetidina" to DrugPrep(
        "Ampolla 200 mg/2 mL: diluir en 20 mL de SF. Menos usada que ranitidina por interacciones (inhibidor CYP).",
        "BOLO: 200–300 mg IV c/6 h"
    ),
    "Difenhidramina (Benadrilina)" to DrugPrep(
        "Ampollas 10–50 mg/mL: diluir 50 mg en 10 mL de SF para IV lenta.",
        "BOLO: 25–50 mg IV lento (antihistamínico H1 en reacciones alérgicas leves, extrapiramidales, prurito opioide)",
        "Benadryl"
    ),
    "Hidrocortisona" to DrugPrep(
        "Frasco 100 mg: reconstituir con 2 mL de agua estéril → 50 mg/mL; diluir después en SF o SG5 % según uso (100 mg/100 mL = 1 mg/mL).",
        "BOLO: 100 mg IV c/6–8 h (sustitución de estrés/anafilaxia) | CONT: 200–300 mg/día en infusión (shock séptico)",
        "Solu-Cortef"
    ),
    "Naloxona" to DrugPrep(
        "Ampolla 0,4 mg/mL: diluir 0,4 mg en 10 mL de SF → 40 µg/mL para titulación fina. Duración de la naloxona corta vs. opioide: vigilar resedación.",
        "BOLO: 40–100 µg IV titulado (depresión respiratoria opioide); sobredosis grave 0,4–2 mg | CONT: 2/3 de la dosis total que funcionó por hora"
    ),
    "Flumazenil" to DrugPrep(
        "Ampolla 0,5 mg/5 mL (0,1 mg/mL): usar directo titulado. Riesgo de convulsiones en consumidores crónicos de benzodiacepinas y en intoxicación mixta: usar con criterio.",
        "BOLO: 0,2 mg IV, luego 0,1 mg c/30 s (máx. 1 mg); duración corta: monitorizar ≥2 h"
    ),
    "Atropina" to DrugPrep(
        "Ampolla 1 mg/mL: diluir 1 mg en 10 mL de SF → 100 µg/mL para titulación fina.",
        "BOLO: 0,01–0,02 mg/kg IV (adulto bradicardia 0,5–1 mg; mínimo 0,1 mg — dosis bajas causan bradicardia paradójica); RCP máx. 3 mg"
    ),
    "Ondansetrón" to DrugPrep(
        "Ampolla 8 mg/4 mL: usar directo IV lento (2–5 min) o diluir en 50 mL de SF. No mezclar con fármacos alcalinos (bicarbonato).",
        "BOLO: 4–8 mg IV lento al final de la cirugía (profilaxis NVPO; pediátrico 0,1 mg/kg máx. 4 mg)",
        "Zofran"
    ),
    "Dexametasona" to DrugPrep(
        "Ampolla 8 mg/2 mL (4 mg/mL): IV directo o diluida; compatible con SF/SG5 % y con la mayoría de las líneas. Efecto máximo antiemético/antiedema en 2–4 h: dar temprano.",
        "BOLO: 4–8 mg IV (NVPO, edema postoperatorio) · Peritumoral/neuro: 8–16 mg/día en 2–4 dosis",
        "Decadron"
    ),
    "Droperidol" to DrugPrep(
        "Ampolla 5 mg/2 mL (2,5 mg/mL): diluir a 1 mg/mL para dosis antieméticas pequeñas.",
        "BOLO: 0,625–1,25 mg IV (NVPO; por QT prolongado ECG si se supera 1,25 mg); escalofríos 0,625 mg"
    ),
    "Heparina sódica no fraccionada" to DrugPrep(
        "Frasco 5000 UI/mL: para CEC administrar directo por vía central; para purga y flushing diluir 5000 UI en 500 mL de SF → 10 UI/mL. Alta concentración = alto riesgo de error: etiquetar siempre.",
        "BOLO: CEC 300–400 UI/kg IV (ACT objetivo >480 s); profilaxis SC 5000 UI c/8–12 h · Vascular: 50–100 UI/kg",
        "Heparina no fraccionada"
    ),
    "Protamina" to DrugPrep(
        "Ampolla 10 mg/mL: diluir la dosis en 50 mL de SF → 0,2 mg/mL e infundir lento en 10–15 min (bolo rápido causa hipotensión y hipertensión pulmonar). Antídoto de la heparina: reacción anafiláctica en diabéticos NPH/pescado.",
        "BOLO: 1–1,3 mg por cada 100 UI de heparina residual (reversión de CEC); máximo 50 mg por vía y lento"
    ),
    "Noradrenalina (Norepinefrina)" to DrugPrep(
        "Ampolla 4 mg/4 mL (1 mg/mL): diluir 4 mg en 50 mL de SG5 % o SF → 80 µg/mL (jeringa 50 mL); para bolos diluir además a 4–8 µg/mL. Proteger de la luz. Vía central preferible por encima de 0,2 µg/kg/min.",
        "JERINGA: 0,01–0,5 µg/kg/min titulada a PAM objetivo (vasopresor de primera línea en sepsis y vasoplejía) | BOLO: 4–16 µg en hipotensión puntual",
        "Norepinefrina · Levonor"
    ),
    "Dopamina" to DrugPrep(
        "Ampolla 200 mg/5 mL (40 mg/mL): diluir 200 mg en 50 mL → 4 mg/mL (jeringa) o en 250 mL → 800 µg/mL. Proteger de la luz. Fuera de uso como «dosis renal»: no mejora la función renal.",
        "JERINGA: 2–20 µg/kg/min (2–5 «renal» en desuso, 5–10 inotrópico, >10 vasopresor) | BOLO: no recomendado",
        "Intropin"
    ),
    "Dobutamina" to DrugPrep(
        "Ampolla 250 mg/20 mL (12,5 mg/mL): diluir 250 mg en 50 mL de SG5 % o SF → 5 mg/mL. Taquiarritmias a dosis altas: titular con eco/SC.",
        "JERINGA: 2–20 µg/kg/min (inotrópico de elección en bajo gasto con presión adecuada)",
        "Dobutrex"
    ),
    "Milrinona" to DrugPrep(
        "Ampolla 10 mg/10 mL (1 mg/mL): diluir 20 mg en 100 mL de SF → 200 µg/mL. Carga 50 µg/kg en 10 min SOLO si el paciente está estable; en hipotensión empezar sin carga. Ajustar en ERC (se elimina por riñón).",
        "JERINGA: 0,375–0,75 µg/kg/min (inodilatador: IC, HTAP post-CEC)",
        "Primacor"
    ),
    "Vasopresina" to DrugPrep(
        "Ampolla 20 UI/mL: diluir 100 UI en 100 mL de SF → 1 UI/mL, o 20 UI en 50 mL → 0,4 UI/mL para bomba. No confundir con desmopresina (DDAVP).",
        "JERINGA: 0,01–0,04 UI/min (vasopresor de rescate en vasoplejía refractaria y acidosis) | BOLO: 0,4–1 UI IV puntual",
        "Arginina-vasopresina"
    ),
    "Nitroglicerina (Trinitrato de glicerilo)" to DrugPrep(
        "Ampolla 5 mg/mL (10 mL): diluir 50 mg en 50 mL de SG5 % (NO salino: precipita) → 1 mg/mL. Se adsorbe al PVC: usar filtro de línea o tubo de vidrio/poliuretano.",
        "JERINGA: 0,1–2 µg/kg/min (5–200 µg/min: isquemia, HTA, control de volumen pulmonar) | BOLO: sublingual 0,4 mg en crisis puntual",
        "NTG · Tridil"
    )
)
