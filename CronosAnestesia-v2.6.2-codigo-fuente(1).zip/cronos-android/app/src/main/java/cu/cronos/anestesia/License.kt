package cu.cronos.anestesia

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import java.io.ByteArrayOutputStream
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.X509EncodedKeySpec
import java.time.LocalDate
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/*
 * ============================================================================
 *  LICENCIAS OFFLINE (v1.5.0)
 *  ----------------------------------------------------------------------------
 *  La app no tiene permiso INTERNET (contrato R-01), así que la activación es
 *  100 % offline con claves firmadas criptográficamente:
 *
 *      CRONOS1.<carga b64url>.<firma b64url>
 *
 *  · La carga es texto percent-encoded: s=serial&h=titular&o=organismo&t=tier
 *    &i=emisión(días epoch)&e=expiración(días epoch; 0=perpetua)&d=dispositivo
 *  · Firma: ECDSA P-256 (SHA256withECDSA, DER) emitida por el desarrollador
 *    con scripts/cronos_license_tool.py. La clave pública va incrustada aquí.
 *  · La clave privada NUNCA viaja en la app: sin ella no se pueden forjar
 *    licencias (ni cambiar el nivel ni la fecha de caducidad).
 *  · Vinculación opcional a dispositivo: hash SHA-256 del ANDROID_ID.
 *  · Anti-reempaquetado: se compara el SHA-256 del certificado de firma del
 *    APK con el original; si no coincide (APK alterada) se fuerza modo demo.
 * ============================================================================
 */

// ------------------------------- Base64URL puro -------------------------------

/** Base64URL RFC 4648 §5 sin padding; no depende de android.util (testeable en JVM). */
internal object B64Url {
    private const val ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
    private val INV = IntArray(128) { -1 }.also { t -> ALPHA.forEachIndexed { i, c -> t[c.code] = i } }

    fun encode(bytes: ByteArray): String {
        val sb = StringBuilder(((bytes.size + 2) / 3) * 4)
        var i = 0
        while (i < bytes.size) {
            val b0 = bytes[i].toInt() and 0xFF
            val b1 = if (i + 1 < bytes.size) bytes[i + 1].toInt() and 0xFF else -1
            val b2 = if (i + 2 < bytes.size) bytes[i + 2].toInt() and 0xFF else -1
            sb.append(ALPHA[b0 ushr 2])
            sb.append(ALPHA[((b0 and 0x03) shl 4) or (if (b1 >= 0) b1 ushr 4 else 0)])
            if (b1 < 0) break
            sb.append(ALPHA[((b1 and 0x0F) shl 2) or (if (b2 >= 0) b2 ushr 6 else 0)])
            if (b2 < 0) break
            sb.append(ALPHA[b2 and 0x3F])
            i += 3
        }
        return sb.toString()
    }

    /** Tolera base64 estándar (+/ y padding) además de base64url. */
    fun decode(s: String): ByteArray {
        val vals = ArrayList<Int>(s.length)
        for (ch in s) {
            if (ch == '=' || ch == '\n' || ch == '\r' || ch == ' ') continue
            val norm = when (ch) {
                '+' -> '-'
                '/' -> '_'
                else -> ch
            }
            val v = if (norm.code < 128) INV[norm.code] else -1
            if (v < 0) throw IllegalArgumentException("carácter no válido: '$ch'")
            vals.add(v)
        }
        val out = ByteArray(vals.size * 6 / 8)
        var buf = 0
        var cnt = 0
        var o = 0
        for (v in vals) {
            buf = (buf shl 6) or v
            cnt += 6
            if (cnt >= 8) {
                cnt -= 8
                out[o++] = ((buf ushr cnt) and 0xFF).toByte()
            }
        }
        return out
    }
}

/** percent-encoding compatible con urllib.parse.quote(safe='') de la herramienta. */
internal fun percentEncode(s: String): String {
    val sb = StringBuilder()
    for (b in s.toByteArray(Charsets.UTF_8)) {
        val c = b.toInt() and 0xFF
        val ok = c in 0x41..0x5A || c in 0x61..0x7A || c in 0x30..0x39 ||
            c == '_'.code || c == '.'.code || c == '-'.code || c == '~'.code
        if (ok) sb.append(c.toChar()) else sb.append('%').append("%02X".format(c))
    }
    return sb.toString()
}

internal fun percentDecode(s: String): String {
    if ('%' !in s) return s
    val out = ByteArrayOutputStream()
    var i = 0
    while (i < s.length) {
        val c = s[i]
        if (c == '%' && i + 3 <= s.length) {
            val v = s.substring(i + 1, i + 3).toIntOrNull(16)
            if (v != null) {
                out.write(v)
                i += 3
                continue
            }
        }
        out.write(c.toString().toByteArray(Charsets.UTF_8))
        i += 1
    }
    // NOTA compatibilidad: BAOS.toString(Charset) es API de Java 10 que solo existe
    // en Android desde API 33 (crasheaba con NoSuchMethodError en Android 10).
    // String(byte[], Charset) existe desde API 1 — seguro para minSdk 24.
    return String(out.toByteArray(), Charsets.UTF_8)
}

// ------------------------------- Modelo de licencia -------------------------------

enum class LicenseTier(val code: String, val displayName: String) {
    DEMO("DEMO", "Demostración"),
    BAS("BAS", "Básica"),
    PRO("PRO", "Profesional"),
    INST("INST", "Institucional");

    companion object {
        fun parse(s: String): LicenseTier = when (s.trim().uppercase()) {
            "BAS", "BASICA", "BÁSICA" -> BAS
            "PRO", "PROFESIONAL" -> PRO
            "INST", "INSTITUCIONAL" -> INST
            else -> DEMO
        }
    }
}

/** Funcionalidades desbloqueadas por nivel (control de acceso de la UI). */
data class LicenseFeatures(
    val drugsAll: Boolean,      // 45 fármacos (demo: muestra de 10)
    val doseCalc: Boolean,      // «Dosis calculada» por peso y edad en cada fármaco
    val calcsAll: Boolean,      // calculadoras (demo: 3)
    val scalesAll: Boolean,     // 6 escalas (demo: 2)
    val complAll: Boolean,      // 14 complicaciones (demo: 4)
    val premedAll: Boolean,     // 14 temas de premedicación (demo: sección bloqueada)
    val solAll: Boolean,        // 8 soluciones (demo: 2)
    val clinic: Boolean,        // Clínica avanzada: 27 temas (demo: bloqueada)
    val refsAll: Boolean,       // bibliografía completa (demo: 3)
    val expediente: Boolean,    // expediente del paciente + consentimiento informado (v2.0.0)
    val machine: Boolean,       // apartado de máquina de anestesia con esquemas dinámicos (v2.2.0)
    val checklist: Boolean      // checklist OMS de seguridad quirúrgica interactivo (v2.2.0)
) {
    companion object {
        fun demo() = LicenseFeatures(false, false, false, false, false, false, false, false, false, false, false, false)
        fun basica() = LicenseFeatures(true, true, true, true, true, true, true, false, true, true, true, true)
        fun profesional() = LicenseFeatures(true, true, true, true, true, true, true, true, true, true, true, true)

        fun forTier(t: LicenseTier): LicenseFeatures = when (t) {
            LicenseTier.DEMO -> demo()
            LicenseTier.BAS -> basica()
            LicenseTier.PRO, LicenseTier.INST -> profesional()
        }
    }
}

data class LicenseInfo(
    val serial: String,
    val holder: String,
    val org: String,
    val tier: LicenseTier,
    val issuedEpochDay: Long,
    val expiresEpochDay: Long, // Long.MAX_VALUE → perpetua
    val deviceHash: String,    // vacío → válida en cualquier dispositivo
    val payloadText: String
) {
    val perpetual: Boolean get() = expiresEpochDay == Long.MAX_VALUE
    fun daysLeft(todayEpochDay: Long): Long = if (perpetual) -1 else expiresEpochDay - todayEpochDay
    val features: LicenseFeatures get() = LicenseFeatures.forTier(tier)

    fun expiresText(): String = if (perpetual) "Perpetua" else fmtEpochDay(expiresEpochDay)
    fun issuedText(): String = fmtEpochDay(issuedEpochDay)

    companion object {
        fun fmtEpochDay(d: Long): String = try {
            LocalDate.ofEpochDay(d).toString()
        } catch (_: Throwable) {
            "—"
        }
    }
}

sealed interface LicenseResult {
    data class Ok(val info: LicenseInfo) : LicenseResult
    data class Expired(val info: LicenseInfo) : LicenseResult
    data class WrongDevice(val info: LicenseInfo) : LicenseResult
    data class Invalid(val reason: String) : LicenseResult
}

enum class LicenseStatus { NO_LICENSE, ACTIVE, EXPIRED, WRONG_DEVICE, INVALID, TAMPERED }

data class LicenseState(
    val key: String? = null,
    val status: LicenseStatus = LicenseStatus.NO_LICENSE,
    val info: LicenseInfo? = null,
    val detail: String = "",
    val tampered: Boolean = false
) {
    val features: LicenseFeatures
        get() = if (!tampered && status == LicenseStatus.ACTIVE && info != null) {
            info.features
        } else {
            LicenseFeatures.demo()
        }

    val tier: LicenseTier
        get() = if (!tampered && status == LicenseStatus.ACTIVE && info != null) info.tier else LicenseTier.DEMO

    val active: Boolean get() = status == LicenseStatus.ACTIVE && !tampered
}

val LocalLicense = staticCompositionLocalOf { LicenseState() }

// ------------------------------- Verificador -------------------------------

object LicenseVerifier {

    const val PREFIX = "CRONOS1."

    /**
     * Clave pública EC P-256 (SPKI DER en base64url) del emisor de licencias.
     * Correspondiente a license-keys/cronos_license_public.pem del desarrollador.
     */
    const val PUBLIC_KEY_B64URL =
        "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAExozuFYD5CflYMsG6yLTRunl54Rn0gMi_5UUXCTwdkXTxclAX1stk2CLKUkcI8AOUMFEtcSfK7loaTlYo3vMxqw"

    /** SHA-256 del certificado de firma original del APK (anti-reempaquetado). */
    const val EXPECTED_CERT_SHA256 =
        "628592A31BA1818F37F3DCC51322DECDF8F966E5526F3DE4B8D975D8B4F35BA8"

    /** Quita espacios/saltos de línea pegados de WhatsApp y normaliza el prefijo. */
    fun clean(raw: String): String {
        val noWs = raw.trim()
            .replace("\r", "")
            .replace("\n", "")
            .replace(" ", "")
            .replace("\t", "")
        return if (noWs.startsWith("cronos1.", ignoreCase = true)) {
            PREFIX + noWs.substring(PREFIX.length)
        } else {
            noWs
        }
    }

    fun verify(
        raw: String,
        deviceIdHash: String?,
        publicKeyB64Url: String = PUBLIC_KEY_B64URL,
        todayEpochDay: Long = LocalDate.now().toEpochDay()
    ): LicenseResult {
        val key = clean(raw)
        if (!key.startsWith(PREFIX)) {
            return LicenseResult.Invalid("La clave debe comenzar por $PREFIX")
        }
        val parts = key.substring(PREFIX.length).split('.')
        if (parts.size != 2 || parts.any { it.isEmpty() }) {
            return LicenseResult.Invalid("Estructura esperada: CRONOS1.carga.firma")
        }
        val payload = try {
            B64Url.decode(parts[0])
        } catch (e: Throwable) {
            return LicenseResult.Invalid("Carga ilegible (${e.message})")
        }
        val sig = try {
            B64Url.decode(parts[1])
        } catch (e: Throwable) {
            return LicenseResult.Invalid("Firma ilegible (${e.message})")
        }
        val signatureOk = try {
            val kf = KeyFactory.getInstance("EC")
            val pub = kf.generatePublic(X509EncodedKeySpec(B64Url.decode(publicKeyB64Url)))
            val s = Signature.getInstance("SHA256withECDSA")
            s.initVerify(pub)
            s.update(payload)
            s.verify(sig)
        } catch (e: Throwable) {
            return LicenseResult.Invalid("Firma no verificable (${e.message})")
        }
        if (!signatureOk) {
            return LicenseResult.Invalid("Firma inválida: la clave fue alterada o no corresponde a este emisor")
        }

        val f = parseFields(payload)
        val info = LicenseInfo(
            serial = f["s"] ?: "",
            holder = f["h"] ?: "",
            org = f["o"] ?: "",
            tier = LicenseTier.parse(f["t"] ?: "DEMO"),
            issuedEpochDay = f["i"]?.toLongOrNull() ?: 0L,
            expiresEpochDay = (f["e"]?.toLongOrNull() ?: 0L).let { if (it > 0) it else Long.MAX_VALUE },
            deviceHash = (f["d"] ?: "").uppercase().filter { it.isLetterOrDigit() },
            payloadText = String(payload, Charsets.UTF_8)
        )
        if (!info.perpetual && todayEpochDay > info.expiresEpochDay) {
            return LicenseResult.Expired(info)
        }
        if (info.deviceHash.isNotEmpty()) {
            val mine = (deviceIdHash ?: "").uppercase().filter { it.isLetterOrDigit() }
            if (mine.isEmpty() || mine != info.deviceHash) {
                return LicenseResult.WrongDevice(info)
            }
        }
        return LicenseResult.Ok(info)
    }

    private fun parseFields(payload: ByteArray): Map<String, String> {
        val text = String(payload, Charsets.UTF_8)
        val out = LinkedHashMap<String, String>()
        for (chunk in text.split('&')) {
            val idx = chunk.indexOf('=')
            if (idx > 0) {
                out[chunk.substring(0, idx)] = percentDecode(chunk.substring(idx + 1))
            }
        }
        return out
    }
}

// ------------------------------- Identidad del dispositivo e integridad -------------------------------

/** Hash de dispositivo (16 hex) a partir de ANDROID_ID: sin permisos adicionales. */
fun deviceHash(ctx: Context): String = try {
    val aid = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: return ""
    val digest = MessageDigest.getInstance("SHA-256").digest(aid.toByteArray(Charsets.UTF_8))
    digest.take(8).joinToString("") { "%02X".format(it) }
} catch (_: Throwable) {
    ""
}

/** Presentación del hash: XXXX-XXXX-XXXX-XXXX (se normaliza al comparar). */
fun formatDeviceHash(h: String): String {
    val c = h.filter { it.isLetterOrDigit() }.uppercase()
    if (c.length != 16) return c
    return listOf(c.substring(0, 4), c.substring(4, 8), c.substring(8, 12), c.substring(12, 16)).joinToString("-")
}

/** ¿La firma del APK instalado coincide con el certificado original? null = no determinable. */
fun appCertMatches(ctx: Context): Boolean? = try {
    val pm = ctx.packageManager
    val sigs: Array<android.content.pm.Signature> =
        if (Build.VERSION.SDK_INT >= 28) {
            val info = pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            info.signingInfo?.apkContentsSigners ?: return null
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNATURES).signatures ?: return null
        }
    val md = MessageDigest.getInstance("SHA-256")
    sigs.any { s ->
        val hex = md.digest(s.toByteArray()).joinToString("") { "%02X".format(it) }
        hex == LicenseVerifier.EXPECTED_CERT_SHA256
    }
} catch (_: Throwable) {
    null
}

/** true solo si se pudo leer la firma y NO coincide (fail-open si es indeterminable). */
fun isApkTampered(ctx: Context): Boolean = when (val ok = appCertMatches(ctx)) {
    null -> false
    else -> !ok
}

// ------------------------------- Repositorio (DataStore) -------------------------------

private val Context.licenseDataStore by preferencesDataStore(name = "cronos_license")
private val KEY_LICENSE = stringPreferencesKey("license_key")

object LicenseRepo {

    fun initial() = LicenseState()

    /** Estado observable: re-verifica la clave firmada en cada lectura. */
    fun stateFlow(ctx: Context): Flow<LicenseState> = ctx.licenseDataStore.data
        .catch { emit(emptyPreferences()) }
        .map { p: Preferences -> stateFor(p[KEY_LICENSE], ctx) }

    private fun stateFor(rawKey: String?, ctx: Context): LicenseState {
        val tampered = isApkTampered(ctx)
        if (rawKey.isNullOrBlank()) {
            return LicenseState(null, LicenseStatus.NO_LICENSE, null, "", tampered)
        }
        val res = LicenseVerifier.verify(rawKey, deviceHash(ctx))
        val st = when (res) {
            is LicenseResult.Ok -> LicenseState(rawKey, LicenseStatus.ACTIVE, res.info, "", tampered)
            is LicenseResult.Expired -> LicenseState(rawKey, LicenseStatus.EXPIRED, res.info, "", tampered)
            is LicenseResult.WrongDevice -> LicenseState(rawKey, LicenseStatus.WRONG_DEVICE, res.info, "", tampered)
            is LicenseResult.Invalid -> LicenseState(rawKey, LicenseStatus.INVALID, null, res.reason, tampered)
        }
        return if (tampered) st.copy(status = LicenseStatus.TAMPERED) else st
    }

    /**
     * Valida y, SOLO si la clave es válida, la guarda. Devuelve el estado
     * resultante para que la UI muestre el mensaje inmediato.
     */
    fun activate(ctx: Context, rawKey: String): LicenseState {
        val key = LicenseVerifier.clean(rawKey)
        val tampered = isApkTampered(ctx)
        if (tampered) {
            return LicenseState(key, LicenseStatus.TAMPERED, null, "APK no verificada", true)
        }
        val res = LicenseVerifier.verify(key, deviceHash(ctx))
        val st = when (res) {
            is LicenseResult.Ok -> {
                persist(ctx, key)
                LicenseState(key, LicenseStatus.ACTIVE, res.info)
            }
            is LicenseResult.Expired -> LicenseState(key, LicenseStatus.EXPIRED, res.info)
            is LicenseResult.WrongDevice -> LicenseState(key, LicenseStatus.WRONG_DEVICE, res.info)
            is LicenseResult.Invalid -> LicenseState(key, LicenseStatus.INVALID, null, res.reason)
        }
        return st
    }

    fun deactivate(ctx: Context) = persist(ctx, null)

    private fun persist(ctx: Context, key: String?) {
        CoroutineScope(Dispatchers.IO).launch {
            ctx.licenseDataStore.edit { p ->
                if (key == null) p.remove(KEY_LICENSE) else p[KEY_LICENSE] = key
            }
        }
    }
}
