package cu.cronos.anestesia

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp

// La lógica numérica vive en CalcEngine (pura, con pruebas unitarias).
private fun parseNum(s: String): Double = CalcEngine.parseNum(s)
private fun fmt(v: Double): String = CalcEngine.fmt(v)

// ============================== CALCULADORAS ==============================

@Composable
private fun NumField(value: String, onChange: (String) -> Unit, label: String, suffix: String) {
    OutlinedTextField(
        value = value,
        onValueChange = { raw ->
            val cleaned = raw.filter { it.isDigit() || it == ',' || it == '.' }
            if (cleaned.length <= 6) onChange(cleaned)
        },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        label = { Text(label) },
        suffix = { Text(suffix) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.primary,
            cursorColor = MaterialTheme.colorScheme.primary
        )
    )
}

@Composable
private fun ResultCard(title: String, lines: List<Pair<String, String>>) {
    val sp = LocalSpacing.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(Modifier.padding(sp.m.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
            Spacer(Modifier.height(6.dp))
            lines.forEach { (k, v) ->
                if (v.length <= 22) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            k,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            v,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                } else {
                    Text(
                        k,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        v,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
                Spacer(Modifier.height(3.dp))
            }
        }
    }
}

@Composable
fun CalcTab(onActivate: () -> Unit = {}) {
    val sp = LocalSpacing.current
    var which by rememberSaveable { mutableStateOf(0) }
    val lic = LocalLicense.current
    val names = listOf(
        stringResource(R.string.calc_fasting), stringResource(R.string.calc_hydration),
        stringResource(R.string.calc_weightdose), stringResource(R.string.calc_infusion),
        stringResource(R.string.calc_idealweight), stringResource(R.string.calc_tube),
        stringResource(R.string.calc_bloodloss), stringResource(R.string.calc_gasometria),
        stringResource(R.string.calc_localanest), stringResource(R.string.calc_druginfusion),
        stringResource(R.string.calc_tci), stringResource(R.string.calc_vent_vt),
        stringResource(R.string.calc_vent_mech)
    )
    // Licencia: en demostración solo las 3 primeras calculadoras (v1.5.0)
    val visible = if (lic.features.calcsAll) names.size else 3
    val whichSafe = which.coerceIn(0, visible - 1)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = sp.screenHPad.dp)
            .padding(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(sp.s.dp)
    ) {
        Spacer(Modifier.height(sp.xs.dp))
        // Selector de calculadora: opciones en filas de 2, anchos idénticos
        for (start in 0 until visible step 2) {
            Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
                val count = minOf(2, visible - start)
                for (c in 0 until count) {
                    val idx = start + c
                    AppButton(
                        names[idx],
                        secondary = whichSafe != idx,
                        modifier = Modifier.weight(1f),
                        onClick = { which = idx }
                    )
                }
            }
        }
        when (whichSafe) {
            0 -> FastingCalc()
            1 -> HydrationCalc()
            2 -> WeightDoseCalc()
            3 -> InfusionCalc()
            4 -> IdealWeightCalc()
            5 -> PediatricTubeCalc()
            6 -> BloodLossCalc()
            7 -> GasometryCalc()
            8 -> LocalAnestCalc()
            9 -> DrugInfusionCalc()
            10 -> TciCalc()
            11 -> VentTidalCalc()
            12 -> VentMechCalc()
            else -> TciCalc()
        }
        if (visible < names.size) {
            LockedInlineCard(
                stringResource(R.string.lic_lock_calcs_title),
                stringResource(R.string.lic_lock_calcs_msg),
                onActivate
            )
        }
    }
}

// ---- 1. Ayuno preoperatorio ----

@Composable
private fun FastingCalc() {
    val sp = LocalSpacing.current
    var intake by rememberSaveable { mutableStateOf(-1) }
    var hours by rememberSaveable { mutableStateOf("") }
    val options = listOf("Líquido claro", "Leche materna", "Fórmula/Ligera", "Grasosa/Carnes")
    val required = listOf(2.0, 4.0, 6.0, 8.0)

    Column(verticalArrangement = Arrangement.spacedBy(sp.s.dp)) {
        Text(
            "Seleccione el último tipo de ingesta y las horas transcurridas (regla 2-4-6-8).",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            AppButton(options[0], secondary = intake != 0, modifier = Modifier.weight(1f), onClick = { intake = 0 })
            AppButton(options[1], secondary = intake != 1, modifier = Modifier.weight(1f), onClick = { intake = 1 })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            AppButton(options[2], secondary = intake != 2, modifier = Modifier.weight(1f), onClick = { intake = 2 })
            AppButton(options[3], secondary = intake != 3, modifier = Modifier.weight(1f), onClick = { intake = 3 })
        }
        NumField(hours, { hours = it }, "Horas transcurridas", "h")

        if (intake >= 0) {
            val req = required[intake]
            val h = parseNum(hours)
            val ok = h >= req
            ResultCard(
                title = "Ayunos preoperatorios",
                lines = listOf(
                    "Ingesta" to options[intake],
                    "Ayuno requerido" to "${fmt(req)} h",
                    "Ayuno declarado" to if (h > 0) "${fmt(h)} h" else "—",
                    "Veredicto" to if (h <= 0) "Complete las horas"
                    else if (ok) "APTO para cirugía electiva"
                    else "Faltan ${fmt(req - h)} h — NO apto"
                )
            )
        }
        Text(
            "Los medicamentos se toman con un sorbo pequeño de agua (permitido hasta 1 h). " +
                "El criterio final es del anestesiólogo: emergencias, riesgo de aspiración y " +
                "gastroparesia modifican estas reglas.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// ---- 2. Hidratación transoperatoria (4-2-1) ----

@Composable
private fun HydrationCalc() {
    val sp = LocalSpacing.current
    var weight by rememberSaveable { mutableStateOf("") }
    var fasting by rememberSaveable { mutableStateOf("") }
    val w = parseNum(weight)
    val h = parseNum(fasting)

    Column(verticalArrangement = Arrangement.spacedBy(sp.s.dp)) {
        Text(
            "Regla 4-2-1 (Holliday-Segar) + reposición del déficit por ayuno.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        NumField(weight, { weight = it }, "Peso", "kg")
        NumField(fasting, { fasting = it }, "Horas de ayuno", "h")

        if (w > 0) {
            val plan = CalcEngine.hydrationPlan(w, h)
            val maint = plan.maintenanceMlH
            val h1 = plan.hour1Ml
            val h2 = plan.hour2Ml
            val h3 = plan.hour3Ml
            ResultCard(
                title = "Hidratación transoperatoria",
                lines = listOf(
                    "Mantenimiento" to "${fmt(maint)} mL/h",
                    "Déficit por ayuno" to "${fmt(plan.deficitMl)} mL",
                    "1.ª hora" to "${fmt(h1)} mL (½ déficit + mant.)",
                    "2.ª hora" to "${fmt(h2)} mL (¼ déficit + mant.)",
                    "3.ª hora" to "${fmt(h3)} mL (¼ déficit + mant.)",
                    "Total primeras 3 h" to "${fmt(plan.total3hMl)} mL"
                )
            )
            Text(
                "Cristaloide equilibrado como primera línea. En laparotomías y cirugía " +
                    "con pérdidas, añadir reposición de tercer espacio (2–6 mL/kg/h) y " +
                    "reposición de sangrado (3:1 cristaloide). Vigilar diuresis >0,5 mL/kg/h.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// ---- 3. Dosis por peso ----

private data class DoseRow(val name: String, val perKg: Double, val unit: String)

private val DOSE_TABLE = listOf(
    DoseRow("Propofol (inducción)", 2.0, "mg"),
    DoseRow("Etomidato (inducción)", 0.2, "mg"),
    DoseRow("Ketamina (inducción)", 1.5, "mg"),
    DoseRow("Midazolam (sedación)", 0.03, "mg"),
    DoseRow("Fentanilo (inducción)", 2.0, "µg"),
    DoseRow("Remifentanilo (infusión)", 0.15, "µg/min"),
    DoseRow("Morfina (analgesia)", 0.05, "mg"),
    DoseRow("Rocuronio (intubación)", 0.6, "mg"),
    DoseRow("Vecuronio (intubación)", 0.09, "mg"),
    DoseRow("Atracurio (intubación)", 0.5, "mg"),
    DoseRow("Cisatracurio (intubación)", 0.18, "mg"),
    DoseRow("Suxametonio (RSI)", 1.2, "mg"),
    DoseRow("Adrenalina (paro)", 0.01, "mg"),
    DoseRow("Atropina (bradicardia)", 0.02, "mg")
)

@Composable
private fun WeightDoseCalc() {
    val sp = LocalSpacing.current
    var weight by rememberSaveable { mutableStateOf("") }
    val w = parseNum(weight)

    Column(verticalArrangement = Arrangement.spacedBy(sp.s.dp)) {
        Text(
            "Dosis habituales de inducción e intubación calculadas para el peso indicado. " +
                "Titule siempre según respuesta clínica, edad y comorbilidad.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        NumField(weight, { weight = it }, "Peso", "kg")
        if (w > 0) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(vertical = sp.xs.dp)) {
                    DOSE_TABLE.forEach { r ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(horizontal = sp.m.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                r.name,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            Text(
                                "${fmt(r.perKg * w)} ${r.unit}",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
            Text(
                "Redondee a la ampolla disponible. En el anciano, hepático, renal o hipovolémico: " +
                    "reduzca 30–50% y titule. Las dosis de adrenalina en paro son independientes del peso en el adulto (1 mg).",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// ---- 4. Infusión continua (µg/kg/min → mL/h) ----

@Composable
private fun InfusionCalc() {
    val sp = LocalSpacing.current
    var dose by rememberSaveable { mutableStateOf("") }
    var weight by rememberSaveable { mutableStateOf("") }
    var conc by rememberSaveable { mutableStateOf("") }
    val d = parseNum(dose)
    val w = parseNum(weight)
    val c = parseNum(conc)

    Column(verticalArrangement = Arrangement.spacedBy(sp.s.dp)) {
        Text(
            "Velocidad de la bomba de infusión continua a partir de la dilución preparada.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        NumField(dose, { dose = it }, "Dosis", "µg/kg/min")
        NumField(weight, { weight = it }, "Peso", "kg")
        NumField(conc, { conc = it }, "Concentración de la dilución", "µg/mL")

        if (d > 0 && w > 0 && c > 0) {
            val mlh = CalcEngine.infusionMlH(d, w, c)
            val mgH = CalcEngine.infusionMgH(d, w)
            ResultCard(
                title = "Infusión continua",
                lines = listOf(
                    "Bomba" to "${fmt(mlh)} mL/h",
                    "Dosis horaria" to "${fmt(mgH)} mg/h",
                    "Dosis diaria" to "${fmt(mgH * 24.0)} mg/24 h"
                )
            )
        }
        Text(
            "Diluciones habituales: noradrenalina 4 mg/250 mL = 16 µg/mL · adrenalina " +
                "1 mg/50 mL = 20 µg/mL · dopamina 400 mg/250 mL = 1600 µg/mL · " +
                "nitroglicerina 10 mg/100 mL = 100 µg/mL · remifentanilo 2 mg/50 mL = 40 µg/mL. " +
                "Para dosis en mg/kg/h (propofol): 1 mg/kg/h equivale a 16,7 µg/kg/min.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// ---- 5. Peso ideal (Devine) + volumen corriente protegido ----

@Composable
private fun IdealWeightCalc() {
    val sp = LocalSpacing.current
    var height by rememberSaveable { mutableStateOf("") }
    var realW by rememberSaveable { mutableStateOf("") }
    var male by rememberSaveable { mutableStateOf(true) }
    val h = parseNum(height)
    val rw = parseNum(realW)

    Column(verticalArrangement = Arrangement.spacedBy(sp.s.dp)) {
        Text(
            "Peso ideal por talla (fórmula de Devine). El peso ideal guía el volumen " +
                "corriente de ventilación protectora y varias dosis farmacológicas.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            AppButton("Hombre", secondary = !male, modifier = Modifier.weight(1f), onClick = { male = true })
            AppButton("Mujer", secondary = male, modifier = Modifier.weight(1f), onClick = { male = false })
        }
        NumField(height, { height = it }, "Talla", "cm")
        NumField(realW, { realW = it }, "Peso real (opcional)", "kg")

        if (h >= 120) {
            val ibw = CalcEngine.idealWeight(male, h)
            val lines = mutableListOf<Pair<String, String>>(
                "Peso ideal (Devine)" to "${fmt(ibw)} kg"
            )
            if (rw > 0 && rw > ibw) {
                lines.add("Peso ajustado" to "${fmt(CalcEngine.adjustedWeight(ibw, rw))} kg")
            }
            lines.add("VT 6 mL/kg (protegido)" to "${fmt(6.0 * ibw)} mL")
            lines.add("VT rango 4–8 mL/kg" to "${fmt(4.0 * ibw)}–${fmt(8.0 * ibw)} mL")
            ResultCard(title = "Peso ideal y ventilación", lines = lines)
        }
        Text(
            "El volumen corriente se calcula sobre el peso ideal (no el real). En obesidad, " +
                "dosis de suxametonio por peso real y de rocuronio/propofol por peso ideal o " +
                "ajustado; titule según efecto clínico.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// ---- 6. Tubo endotraqueal pediátrico ----

@Composable
private fun PediatricTubeCalc() {
    val sp = LocalSpacing.current
    var age by rememberSaveable { mutableStateOf("") }
    val a = parseNum(age)

    Column(verticalArrangement = Arrangement.spacedBy(sp.s.dp)) {
        Text(
            "Tamaño y profundidad del tubo endotraqueal pediátrico según la edad " +
                "(admite decimales: 0,5 = 6 meses).",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        NumField(age, { age = it }, "Edad", "años")

        if (a > 0) {
            val uncuffed = CalcEngine.tubeUncuffedMm(a)
            val cuffed = CalcEngine.tubeCuffedMm(a)
            val depth = CalcEngine.tubeDepthCm(a)
            ResultCard(
                title = "Tubo endotraqueal pediátrico",
                lines = listOf(
                    "Tubo sin balón" to "${fmt(uncuffed)} mm",
                    "Tubo con balón" to "${fmt(cuffed)} mm",
                    "Profundidad (labio)" to "${fmt(depth)} cm",
                    "Regla alternativa" to "3 × diámetro interno"
                )
            )
        }
        Text(
            "Recién nacido: 3,0–3,5 mm sin balón a 7–9 cm; lactante <1 año: 3,5–4,0 mm. " +
                "La fórmula de Levi (edad/4 + 4) puede sobrestimar en menores de 2 años. " +
                "Tenga siempre medio punto menos y más disponibles y confirme con test de fuga, " +
                "simetría del murmullo pulmonar y capnografía.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// ---- 7. Volemia y sangrado máximo permitido ----

@Composable
private fun BloodLossCalc() {
    val sp = LocalSpacing.current
    var weight by rememberSaveable { mutableStateOf("") }
    var hct0 by rememberSaveable { mutableStateOf("") }
    var hctMin by rememberSaveable { mutableStateOf("") }
    var cat by rememberSaveable { mutableStateOf(0) }
    val cats = listOf("Hombre", "Mujer", "Niño", "Lactante")
    val w = parseNum(weight)
    val h0 = parseNum(hct0)
    val hm = parseNum(hctMin)

    Column(verticalArrangement = Arrangement.spacedBy(sp.s.dp)) {
        Text(
            "Volemia estimada y pérdida de sangre máxima permitida antes de transfundir.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        NumField(weight, { weight = it }, "Peso", "kg")
        for (r in 0 until 2) {
            Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
                for (c in 0..1) {
                    val idx = r * 2 + c
                    AppButton(
                        cats[idx],
                        secondary = cat != idx,
                        modifier = Modifier.weight(1f),
                        onClick = { cat = idx }
                    )
                }
            }
        }
        NumField(hct0, { hct0 = it }, "Hematocrito inicial", "%")
        NumField(hctMin, { hctMin = it }, "Hematocrito mínimo", "%")

        if (w > 0 && h0 > 0 && hm > 0 && hm < h0) {
            val ebv = CalcEngine.estimatedBloodVolume(w, cat)
            val avg = (h0 + hm) / 2.0
            val abl = CalcEngine.allowableBloodLoss(ebv, h0, hm)
            ResultCard(
                title = "Sangrado máximo permitido",
                lines = listOf(
                    "Volemia estimada" to "${fmt(ebv)} mL",
                    "Hct promedio" to "${fmt(avg)} %",
                    "Pérdida permitida" to "${fmt(abl)} mL"
                )
            )
        }
        Text(
            "Reponga con cristaloide equilibrado 3:1 o coloide 1:1 hasta el umbral " +
                "transfusional (Hb 7–8 g/dL en paciente sano; 8–10 g/dL con cardiopatía o " +
                "isquemia activa). Valor orientativo: considere sangrado activo, hemostasia " +
                "y respuesta clínica.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// ---- 8. Gasometría: índice P/F y gradiente A–a ----

@Composable
private fun GasometryCalc() {
    val sp = LocalSpacing.current
    var pao2 by rememberSaveable { mutableStateOf("") }
    var paco2 by rememberSaveable { mutableStateOf("") }
    var fio2 by rememberSaveable { mutableStateOf("") }
    var age by rememberSaveable { mutableStateOf("") }
    val p = parseNum(pao2)
    val c = parseNum(paco2)
    val f = parseNum(fio2)
    val e = parseNum(age)

    Column(verticalArrangement = Arrangement.spacedBy(sp.s.dp)) {
        Text(
            "Índice PaO2/FiO2 (Berlín) y gradiente alvéolo-arterial a partir de la gasometría.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        NumField(pao2, { pao2 = it }, "PaO2", "mmHg")
        NumField(paco2, { paco2 = it }, "PaCO2", "mmHg")
        NumField(fio2, { fio2 = it }, "FiO2", "%")
        NumField(age, { age = it }, "Edad (opcional)", "años")

        if (p > 0 && c > 0 && f > 0) {
            val pf = CalcEngine.pfiIndex(p, f)
            val aa = CalcEngine.aaGradient(p, f, c)
            val limit = CalcEngine.aaNormalLimit(e)
            val berlin = when (CalcEngine.berlinClass(pf)) {
                CalcEngine.Berlin.NONE -> "Sin criterio de SDRA"
                CalcEngine.Berlin.MILD -> "SDRA leve (200–300)"
                CalcEngine.Berlin.MODERATE -> "SDRA moderada (100–200)"
                CalcEngine.Berlin.SEVERE -> "SDRA grave (<100)"
            }
            ResultCard(
                title = "Oxigenación",
                lines = listOf(
                    "Índice PaO2/FiO2" to fmt(pf),
                    "Clasificación Berlín" to berlin,
                    "Gradiente A–a" to "${fmt(aa)} mmHg",
                    "Límite según edad" to "< ${fmt(limit)} mmHg"
                )
            )
        }
        Text(
            "Cálculo a nivel del mar: PAO2 = FiO2 × (760 − 47) − PaCO2/0,8. El gradiente " +
                "A–a aumenta fisiológicamente con la edad; para clasificar SDRA se requiere " +
                "PEEP ≥ 5 cmH2O. En altitud corrija la presión barométrica.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// ---- 9. Dosis máxima de anestésicos locales (maxLocalAnesthetic) ----
// Datos de dosis en CalcEngine.LA_SPECS; aquí solo las notas clínicas de UI (mismo orden).

private val LA_NOTES = listOf(
    "1% y 2% habituales. Regional IV: máx. 3–4 mg/kg (sin adrenalina).",
    "Cardiotoxicidad alta: no reinyectar; dosis acumulativa.",
    "Menos cardiotoxicidad que la bupivacaína racémica.",
    "Más segura en el sistema cardiovascular; menos bloqueo motor.",
    "Amida de duración media; útil en bloqueos periféricos.",
    "Metahemoglobinemia por encima de ~600 mg en adulto.",
    "Uso dental al 4%; en niños 5–7 mg/kg según peso.",
    "Degradación rápida; útil cuando se necesita margen de dosis."
)

@Composable
internal fun LocalAnestCalc() {
    val sp = LocalSpacing.current
    var peso by rememberSaveable { mutableStateOf("") }
    var drug by rememberSaveable { mutableStateOf(0) }
    var epi by rememberSaveable { mutableStateOf(false) }
    var ped by rememberSaveable { mutableStateOf(false) }
    var conc by rememberSaveable(drug) {
        mutableStateOf(fmt(CalcEngine.LA_SPECS[drug].typicalConcMgMl))
    }

    val d = CalcEngine.LA_SPECS[drug]
    val w = parseNum(peso)
    val c = parseNum(conc)
    val la = CalcEngine.localAnestheticMax(d, w, epi, ped, c)
    val mgKg = la.mgPerKg
    val capMg = la.absoluteCapMg
    val valid = w > 0 && mgKg > 0
    val maxMg = la.maxMg
    val maxMl = la.maxMl

    Column(verticalArrangement = Arrangement.spacedBy(sp.s.dp)) {
        NumField(peso, { peso = it }, "Peso", "kg")
        Text(
            "Fármaco",
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary
        )
        for (start in CalcEngine.LA_SPECS.indices step 2) {
            Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
                val count = minOf(2, CalcEngine.LA_SPECS.size - start)
                for (k in 0 until count) {
                    val idx = start + k
                    AppButton(
                        CalcEngine.LA_SPECS[idx].name,
                        secondary = drug != idx,
                        modifier = Modifier.weight(1f),
                        onClick = { drug = idx }
                    )
                }
            }
        }
        SegmentedRow(
            options = listOf("Sin adrenalina", "Con adrenalina"),
            selected = if (epi) 1 else 0,
            onSelect = { epi = it == 1 }
        )
        SegmentedRow(
            options = listOf("Adulto", "Pediátrico"),
            selected = if (ped) 1 else 0,
            onSelect = { ped = it == 1 }
        )
        NumField(conc, { conc = it }, "Concentración de la solución", "mg/mL")
        if (valid) {
            ResultCard(
                "Dosis máxima segura",
                listOf(
                    "Dosis máxima" to "${fmt(maxMg)} mg",
                    "Cálculo" to "${fmt(mgKg)} mg/kg × ${fmt(w)} kg",
                    "Límite absoluto" to "${capMg.toInt()} mg",
                    if (c > 0) "Volumen máximo" to "${fmt(maxMl)} mL"
                    else "Volumen máximo" to "ingrese concentración"
                )
            )
        }
        Text(
            LA_NOTES[drug] + " Valores orientativos estándar; no aplican a bloqueos neuraxiales " +
                "(dosis menores), embarazo, insuficiencia hepática o cardíaca, ni a pacientes " +
                "de riesgo. Vigile signos de LAST durante 30 min tras inyectar " +
                "(Emergencias → LAST).",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// ============================== ESCALAS ==============================

@Composable
fun ScaleTab(onOpen: (Int) -> Unit, onActivate: () -> Unit = {}) {
    val sp = LocalSpacing.current
    val lic = LocalLicense.current
    // Licencia: en demostración solo las 2 primeras escalas (v1.5.0)
    val count = if (lic.features.scalesAll) SCALES.size else 2
    val locked = count < SCALES.size
    // Filas compuestas: encabezado de grupo + escalas visibles (v2.1.0: 6 grupos)
    val rows: List<Pair<Boolean, Int>> = remember(count) {
        val out = mutableListOf<Pair<Boolean, Int>>()
        var lastCat = ""
        for (i in 0 until count) {
            val s = SCALES[i]
            if (s.category != lastCat) {
                out.add(true to i)
                lastCat = s.category
            }
            out.add(false to i)
        }
        out.toList()
    }
    val total = rows.size + if (locked) 1 else 0
    LazyColumnCompat(
        count = total,
        horizontalPad = sp.screenHPad.dp,
        verticalPad = sp.s.dp
    ) { r ->
        if (locked && r == rows.size) {
            LockedInlineCard(
                stringResource(R.string.lic_lock_scales_title),
                stringResource(R.string.lic_lock_scales_msg),
                onActivate
            )
        } else {
            val (isHeader, idx) = rows[r]
            if (isHeader) {
                val cat = SCALES[idx].category
                val n = SCALES.count { it.category == cat }
                Column {
                    Spacer(Modifier.height(sp.s.dp))
                    Text(
                        "$cat · $n",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            } else {
                ItemCard(title = SCALES[idx].name, subtitle = SCALES[idx].desc, onClick = { onOpen(idx) })
            }
        }
    }
}

@Composable
fun LazyColumnCompat(count: Int, horizontalPad: androidx.compose.ui.unit.Dp, verticalPad: androidx.compose.ui.unit.Dp = 10.dp, itemContent: @Composable (Int) -> Unit) {
    androidx.compose.foundation.lazy.LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = horizontalPad, vertical = verticalPad),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        items(count) { i -> itemContent(i) }
    }
}

@Composable
fun ScaleDetail(index: Int, onBack: () -> Unit) {
    val sp = LocalSpacing.current
    val scale = SCALES[index]
    // selección por grupo (null = sin responder)
    val selections = remember {
        mutableStateListOf<Int?>().apply { addAll(scale.groups.map { null }) }
    }
    var single by remember { mutableStateOf<Int?>(null) }

    Column(Modifier.fillMaxWidth()) {
        DetailTopBar(scale.name, stringResource(R.string.sub_escalas), onBack)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = sp.screenHPad.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(sp.s.dp)
        ) {
            Text(
                scale.desc,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (scale.groups.isNotEmpty()) {
                scale.groups.forEachIndexed { gi, group ->
                    Column(verticalArrangement = Arrangement.spacedBy(sp.xs.dp)) {
                        Text(
                            group.title,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        group.options.forEachIndexed { oi, opt ->
                            AppButton(
                                text = opt.label,
                                secondary = selections[gi] != oi,
                                modifier = Modifier.fillMaxWidth(),
                                onClick = { selections[gi] = oi }
                            )
                        }
                    }
                }
                val allAnswered = selections.all { it != null }
                val total = selections.withIndex().sumOf { (gi, sel) ->
                    if (sel != null) scale.groups[gi].options[sel].score else 0
                }
                if (allAnswered) {
                    ResultCard(
                        title = stringResource(R.string.result_title),
                        lines = listOf(
                            stringResource(R.string.result_score) to "$total puntos",
                            stringResource(R.string.result_interp) to scale.interpretation
                        )
                    )
                }
            } else {
                scale.fixedOptions.forEachIndexed { oi, opt ->
                    AppButton(
                        text = opt.label,
                        secondary = single != oi,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { single = oi }
                    )
                }
                val chosen = single
                if (chosen != null) {
                    ResultCard(
                        title = stringResource(R.string.result_title),
                        lines = listOf(
                            stringResource(R.string.result_selection) to scale.fixedOptions[chosen].label.substringBefore("—").trim(),
                            stringResource(R.string.result_interp) to scale.interpretation
                        )
                    )
                }
            }

            AppButton(
                stringResource(R.string.scales_clear),
                secondary = true,
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    for (i in selections.indices) selections[i] = null
                    single = null
                }
            )
        }
    }
}
