package cu.cronos.anestesia

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.sin

// =====================================================================
//  PESTAÑA EQUIPOS (v2.1.0) — abierta a todos los usuarios.
//  1) Máquina: esquema vectorial ANIMADO (flujo de gases, fuelles, bolsa
//     y traza del monitor) + fichas de cada parte (función / verificación
//     / fallos típicos). Tacto sobre el esquema o sobre los botones.
//  2) Materiales: catálogo por categorías con tamaños y puntos clave.
//  3) Verificación: checklist de máquina + seguridad quirúrgica (OMS)
//     con casillas persistentes (SharedPreferences, sin datos de pacientes).
// =====================================================================

private data class EquipZone(val id: String, val x0: Float, val y0: Float, val x1: Float, val y1: Float)

private val EQUIP_ZONES = listOf(
    EquipZone("fuentes_gas", 0.01f, 0.06f, 0.16f, 0.48f),
    EquipZone("cilindros", 0.01f, 0.54f, 0.16f, 0.94f),
    EquipZone("mesa_flujo", 0.17f, 0.06f, 0.35f, 0.48f),
    EquipZone("flush", 0.17f, 0.54f, 0.35f, 0.94f),
    EquipZone("vaporizadores", 0.36f, 0.06f, 0.56f, 0.48f),
    EquipZone("circuito", 0.36f, 0.54f, 0.56f, 0.94f),
    EquipZone("absorvedor", 0.57f, 0.06f, 0.73f, 0.48f),
    EquipZone("ventilador", 0.74f, 0.06f, 0.99f, 0.45f),
    EquipZone("monitores", 0.74f, 0.51f, 0.99f, 0.72f),
    EquipZone("alarmas", 0.74f, 0.78f, 0.99f, 0.94f)
)

private val ZONE_LABELS = mapOf(
    "fuentes_gas" to "FUENTES\nO2 · AIRE · N2O",
    "cilindros" to "CILINDROS\nE (reserva)",
    "mesa_flujo" to "MESA DE FLUJO",
    "flush" to "O2 FLUSH",
    "vaporizadores" to "VAPORIZADORES\nISO · SEV",
    "circuito" to "CIRCUITO · Y · BOLSA",
    "absorvedor" to "ABSORVEDOR CO2",
    "ventilador" to "VENTILADOR",
    "monitores" to "MONITORES",
    "alarmas" to "ALARMAS"
)

@Composable
fun EquipTab() {
    var sub by rememberSaveable { mutableStateOf(0) }
    val subs = listOf("Máquina", "Materiales", "Verificación")
    Column(Modifier.fillMaxWidth()) {
        TabRow(selectedTabIndex = sub) {
            subs.forEachIndexed { i, t ->
                Tab(selected = sub == i, onClick = { sub = i }, text = { Text(t, maxLines = 1) })
            }
        }
        when (sub) {
            0 -> MachinePane()
            1 -> SuppliesPane()
            else -> ChecklistsPane()
        }
    }
}

// ============================== MÁQUINA ==============================

@Composable
private fun MachinePane() {
    val sp = LocalSpacing.current
    var selected by rememberSaveable { mutableStateOf("absorvedor") }
    val part = MACHINE_PARTS.first { it.id == selected }
    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = sp.screenHPad.dp)
    ) {
        Spacer(Modifier.height(sp.s.dp))
        Text(
            "Esquema interactivo de la máquina de anestesia: toque una parte (en el esquema o en los botones) para ver su función, su verificación y sus fallos típicos. La animación muestra el flujo de gas fresco, el ciclo del fuelle del ventilador, la bolsa reservorio y la traza del monitor.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(sp.s.dp))
        MachineSchematic(selected, onSelect = { selected = it })
        Spacer(Modifier.height(sp.s.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(sp.xs.dp)
        ) {
            MACHINE_PARTS.forEach { p ->
                val on = p.id == selected
                Card(
                    onClick = { selected = p.id },
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
                    )
                ) {
                    Text(
                        p.name,
                        modifier = Modifier.padding(horizontal = sp.s.dp, vertical = 8.dp),
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        color = if (on) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
        Spacer(Modifier.height(sp.s.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(Modifier.padding(sp.m.dp)) {
                Text(
                    part.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                SectionLabel("Función")
                BodyText(part.function)
                SectionLabel("Verificación diaria")
                BodyText(part.verify)
                SectionLabel("Fallos típicos")
                BodyText(part.failures)
            }
        }
        Text(
            "Esquema didáctico propio de Cronos Anestesia (no representa un modelo comercial). Las listas de verificación correspondientes están en la pestaña Verificación.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(vertical = sp.s.dp)
        )
    }
}

/** Esquema vectorial animado de la máquina de anestesia. */
@Composable
private fun MachineSchematic(selected: String, onSelect: (String) -> Unit) {
    val border = MaterialTheme.colorScheme.outline
    val surf = MaterialTheme.colorScheme.surfaceVariant
    val primary = MaterialTheme.colorScheme.primary
    val tertiary = MaterialTheme.colorScheme.tertiary
    val error = MaterialTheme.colorScheme.error
    val onSurf = MaterialTheme.colorScheme.onSurfaceVariant
    val tm = rememberTextMeasurer()
    val phase = rememberInfiniteTransition(label = "maquina").animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(4000, easing = LinearEasing)),
        label = "p"
    )

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(235.dp)
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(14.dp))
            .pointerInput(Unit) {
                detectTapGestures { off ->
                    val x = off.x / size.width
                    val y = off.y / size.height
                    EQUIP_ZONES.firstOrNull { x >= it.x0 && x <= it.x1 && y >= it.y0 && y <= it.y1 }
                        ?.let { z -> onSelect(z.id) }
                }
            }
    ) {
        val w = size.width
        val h = size.height
        val ph = phase.value
        val dash = floatArrayOf(16f, 14f)

        fun label(zone: EquipZone) {
            val txt = ZONE_LABELS[zone.id] ?: return
            val m = tm.measure(txt, TextStyle(fontSize = 10.sp, color = onSurf))
            drawText(
                m,
                topLeft = Offset(
                    (zone.x0 + zone.x1) / 2f * w - m.size.width / 2f,
                    zone.y0 * h + 8f
                )
            )
        }

        // zonas seleccionables
        EQUIP_ZONES.forEach { z ->
            val on = z.id == selected
            drawRoundRect(
                if (on) primary.copy(alpha = 0.16f) else surf.copy(alpha = 0.30f),
                topLeft = Offset(z.x0 * w, z.y0 * h),
                size = Size((z.x1 - z.x0) * w, (z.y1 - z.y0) * h),
                cornerRadius = CornerRadius(14f, 14f)
            )
            if (on) {
                drawRoundRect(
                    primary,
                    topLeft = Offset(z.x0 * w, z.y0 * h),
                    size = Size((z.x1 - z.x0) * w, (z.y1 - z.y0) * h),
                    cornerRadius = CornerRadius(14f, 14f),
                    style = Stroke(width = 4f)
                )
            }
            label(z)
        }

        // flujo de gas fresco (animado: O2/aire → rotámetros → vaporizador → circuito → absorvedor → ventilador)
        val fresh = Path().apply {
            moveTo(0.08f * w, 0.27f * h)
            lineTo(0.26f * w, 0.27f * h)
            lineTo(0.46f * w, 0.27f * h)
            lineTo(0.46f * w, 0.62f * h)
            lineTo(0.65f * w, 0.62f * h)
            lineTo(0.65f * w, 0.27f * h)
            lineTo(0.86f * w, 0.27f * h)
        }
        drawPath(
            fresh, primary,
            style = Stroke(width = 3f, cap = StrokeCap.Round, pathEffect = PathEffect.dashPathEffect(dash, ph * 60f))
        )
        // retorno espiratorio (hacia el absorvedor)
        val exp = Path().apply {
            moveTo(0.86f * w, 0.38f * h)
            lineTo(0.69f * w, 0.38f * h)
            lineTo(0.69f * w, 0.75f * h)
        }
        drawPath(
            exp, tertiary,
            style = Stroke(width = 3f, cap = StrokeCap.Round, pathEffect = PathEffect.dashPathEffect(dash, -ph * 60f))
        )

        // rotámetros: dos tubos con flotadores
        listOf(0.23f, 0.29f).forEach { x ->
            drawLine(onSurf, Offset(x * w, 0.14f * h), Offset(x * w, 0.44f * h), 6f)
            drawCircle(primary, radius = 6f, center = Offset(x * w, (0.22f + 0.08f * sin(ph * 2f * Math.PI).toFloat()) * h))
        }

        // vaporizadores: dos cajas sobre el backbar
        drawLine(border, Offset(0.36f * w, 0.40f * h), Offset(0.56f * w, 0.40f * h), 5f)
        listOf(0.385f, 0.48f).forEach { x ->
            drawRoundRect(
                tertiary.copy(alpha = 0.35f),
                topLeft = Offset(x * w, 0.22f * h),
                size = Size(0.075f * w, 0.17f * h),
                cornerRadius = CornerRadius(8f, 8f)
            )
        }

        // absorvedor: canister con indicador de color
        drawRoundRect(
            border,
            topLeft = Offset(0.60f * w, 0.22f * h),
            size = Size(0.10f * w, 0.20f * h),
            cornerRadius = CornerRadius(10f, 10f),
            style = Stroke(3f)
        )
        drawCircle(Color(0xFF8E4FD0), radius = 6f, center = Offset(0.65f * w, 0.32f * h))

        // fuelle del ventilador (sube y baja)
        val bellTop = (0.22f + (0.5f + 0.5f * sin(ph * 2f * Math.PI).toFloat()) * 0.16f)
        drawRoundRect(
            error.copy(alpha = 0.55f),
            topLeft = Offset(0.80f * w, bellTop * h),
            size = Size(0.12f * w, (0.40f - bellTop) * h),
            cornerRadius = CornerRadius(8f, 8f)
        )

        // bolsa reservorio pulsante (ciclo respiratorio)
        val bagR = 0.055f * h * (1f + 0.14f * sin(ph * 2f * Math.PI).toFloat())
        drawCircle(tertiary.copy(alpha = 0.75f), radius = bagR, center = Offset(0.46f * w, 0.80f * h))
        // pieza en Y y APL esquemáticas
        drawLine(border, Offset(0.41f * w, 0.72f * h), Offset(0.46f * w, 0.76f * h), 4f)
        drawLine(border, Offset(0.51f * w, 0.72f * h), Offset(0.46f * w, 0.76f * h), 4f)
        drawCircle(border, radius = 5f, center = Offset(0.53f * w, 0.66f * h))

        // traza del monitor (onda animada)
        val wave = Path()
        var i = 0f
        while (i <= 1f) {
            val xx = 0.76f * w + i * 0.21f * w
            val yy = 0.60f * h + sin(i * 6f * Math.PI + ph * 2f * Math.PI).toFloat() * 0.05f * h
            if (i == 0f) wave.moveTo(xx, yy) else wave.lineTo(xx, yy)
            i += 0.02f
        }
        drawPath(wave, primary, style = Stroke(width = 2.5f))

        // botón de flush
        drawCircle(primary, radius = 0.035f * h, center = Offset(0.26f * w, 0.72f * h))
        drawLine(border, Offset(0.26f * w, 0.76f * h), Offset(0.26f * w, 0.86f * h), 4f)

        // cilindros de reserva
        listOf(0.045f, 0.10f).forEach { x ->
            drawRoundRect(
                border,
                topLeft = Offset(x * w, 0.62f * h),
                size = Size(0.045f * w, 0.26f * h),
                cornerRadius = CornerRadius(10f, 10f),
                style = Stroke(3f)
            )
        }

        // alarma parpadeante
        drawCircle(
            error,
            radius = 5f + 2f * sin(ph * 2f * Math.PI).toFloat(),
            center = Offset(0.80f * w, 0.86f * h)
        )
    }
}

// ============================== MATERIALES ==============================

@Composable
private fun SuppliesPane() {
    val sp = LocalSpacing.current
    var cat by rememberSaveable { mutableStateOf(SUPPLY_CATEGORIES.first()) }
    var expanded by rememberSaveable { mutableStateOf(setOf<String>()) }
    val items = remember(cat) { SUPPLIES.filter { it.category == cat } }
    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = sp.screenHPad.dp, vertical = sp.s.dp),
        verticalArrangement = Arrangement.spacedBy(sp.xs.dp)
    ) {
        item {
            Text(
                "Catálogo de materiales de uso diario en anestesia. Toque un material para ver sus tamaños habituales, su uso y sus puntos clave.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(sp.s.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(sp.xs.dp)
            ) {
                SUPPLY_CATEGORIES.forEach { c ->
                    val on = c == cat
                    Card(
                        onClick = { cat = c },
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Text(
                            c,
                            modifier = Modifier.padding(horizontal = sp.s.dp, vertical = 8.dp),
                            style = MaterialTheme.typography.labelLarge,
                            color = if (on) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
        items(items, key = { it.name }) { s ->
            val isOpen = expanded.contains(s.name)
            Card(
                onClick = {
                    expanded = if (isOpen) expanded - s.name else expanded + s.name
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(sp.m.dp)) {
                    Text(
                        s.name,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        s.sizes,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    if (isOpen) {
                        SectionLabel("Uso")
                        BodyText(s.use)
                        SectionLabel("Puntos clave")
                        BodyText(s.keys)
                    }
                }
            }
        }
    }
}

// ============================== VERIFICACIÓN ==============================

@Composable
private fun ChecklistsPane() {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("cronos_checklists", android.content.Context.MODE_PRIVATE) }
    var idx by rememberSaveable { mutableStateOf(0) }
    val cl = CHECKLISTS[idx]
    var checked by remember(cl.id) {
        mutableStateOf(prefs.getStringSet(cl.id, emptySet())?.toSet() ?: emptySet<String>())
    }
    val total = cl.groups.sumOf { it.items.size }
    val done = cl.groups.sumOf { g -> g.items.count { checked.contains(it.id) } }

    fun toggle(id: String) {
        val next = if (checked.contains(id)) checked - id else checked + id
        checked = next
        prefs.edit().putStringSet(cl.id, next).apply()
    }

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = sp.screenHPad.dp, vertical = sp.s.dp),
        verticalArrangement = Arrangement.spacedBy(sp.xs.dp)
    ) {
        item {
            Text(
                cl.subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(sp.s.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(sp.xs.dp)
            ) {
                CHECKLISTS.forEachIndexed { i, c ->
                    val on = i == idx
                    Card(
                        onClick = { idx = i },
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Text(
                            c.title,
                            modifier = Modifier.padding(horizontal = sp.s.dp, vertical = 8.dp),
                            style = MaterialTheme.typography.labelLarge,
                            color = if (on) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
            Spacer(Modifier.height(sp.s.dp))
            Text(
                "${cl.title} — $done de $total completados",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface
            )
            LinearProgressIndicator(
                progress = { if (total == 0) 0f else done.toFloat() / total },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp)
            )
        }
        cl.groups.forEach { g ->
            item(key = g.title) {
                Column(Modifier.fillMaxWidth()) {
                    SectionLabel(g.title)
                    g.items.forEach { item ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { toggle(item.id) }
                                .padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = checked.contains(item.id),
                                onCheckedChange = { toggle(item.id) }
                            )
                            Column(Modifier.weight(1f)) {
                                Text(
                                    item.label,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                if (item.critical) {
                                    Text(
                                        "Ítem crítico: no debe omitirse",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        item {
            AppButton(
                "Reiniciar lista",
                secondary = true,
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    prefs.edit().remove(cl.id).apply()
                    checked = emptySet()
                }
            )
        }
        item {
            Text(
                "Las casillas se guardan solo en su teléfono (sin datos de pacientes). Verifique también la pestaña Máquina para conocer la función de cada componente.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
