package cu.cronos.anestesia

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

// =====================================================================
//  BOMBA TCI (v2.1.0) — infusión con diana por modelos de 3 compartimentos
//   · Propofol: Marsh (solo peso) o Schnider (edad/talla/sexo)
//   · Remifentanilo: Minto (LBM de Janmahasatian)
//   · Esquema BET exacto: bolo + velocidad de decaimiento (plasma)
//   · Diana en plasma (Cp) o en sitio efecto (Ce, estrategia conservadora)
//   · Tabla de velocidades 0–60 min + volumen acumulado → jeringa perfusora
// =====================================================================

private data class TciConc(val label: String, val mgMl: Double)

@Composable
fun TciCalc() {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    var drug by rememberSaveable { mutableStateOf(0) }      // 0 propofol · 1 remifentanilo
    var model by rememberSaveable { mutableStateOf(0) }     // 0 Marsh · 1 Schnider
    var weight by rememberSaveable { mutableStateOf("70") }
    var age by rememberSaveable { mutableStateOf("40") }
    var height by rememberSaveable { mutableStateOf("170") }
    var male by rememberSaveable { mutableStateOf(true) }
    var target by rememberSaveable { mutableStateOf("4") }
    var concIdx by rememberSaveable { mutableStateOf(0) }
    var effectMode by rememberSaveable { mutableStateOf(false) }

    val propofolConc = listOf(
        TciConc("1 % — 10 mg/mL (pura)", 10.0),
        TciConc("Diluida — 5 mg/mL", 5.0),
        TciConc("2 % — 20 mg/mL", 20.0)
    )
    val remiConc = listOf(
        TciConc("50 µg/mL (2 mg/40 mL)", 0.05),
        TciConc("25 µg/mL (2 mg/80 mL)", 0.025),
        TciConc("20 µg/mL (1 mg/50 mL)", 0.02),
        TciConc("10 µg/mL (1 mg/100 mL)", 0.01)
    )
    val concs = if (drug == 0) propofolConc else remiConc
    if (concIdx >= concs.size) concIdx = 0

    val w = CalcEngine.parseNum(weight)
    val a = CalcEngine.parseNum(age)
    val h = CalcEngine.parseNum(height)
    val tgt = CalcEngine.parseNum(target) / if (drug == 0) 1000.0 else 1000000.0 // µg/mL o ng/mL → mg/mL
    val pk: CalcEngine.Pk3 = when {
        drug == 0 && model == 0 -> CalcEngine.marshPropofol(w)
        drug == 0 -> CalcEngine.schniderPropofol(a, w, h, male)
        else -> CalcEngine.mintoRemifentanil(a, w, h, male)
    }
    val plan = remember(pk, tgt, concs, concIdx) { CalcEngine.tciPlan(pk, tgt, concs[concIdx].mgMl) }
    val valid = w > 0 && tgt > 0
    val unit = if (drug == 0) "µg/mL" else "ng/mL"
    val drugName = if (drug == 0) "Propofol (${if (model == 0) "Marsh" else "Schnider"})" else "Remifentanilo (Minto)"

    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(sp.s.dp)) {
        // --- Fármaco ---
        Text(stringResource(R.string.tci_drug), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface)
        SegmentedRow(
            options = listOf("Propofol", "Remifentanilo"),
            selected = drug,
            onSelect = {
                drug = it
                target = if (it == 0) "4" else "4"
                concIdx = 0
            }
        )

        // --- Modelo ---
        if (drug == 0) {
            Text(stringResource(R.string.tci_model), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface)
            SegmentedRow(options = listOf("Marsh", "Schnider"), selected = model, onSelect = { model = it })
        } else {
            Text(
                stringResource(R.string.tci_model_minto),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (drug == 0 && model == 0) {
            Text(
                stringResource(R.string.tci_model_note_marsh),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // --- Parámetros del paciente ---
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            OutlinedTextField(
                value = weight, onValueChange = { weight = it },
                modifier = Modifier.weight(1f),
                label = { Text(stringResource(R.string.tci_weight)) },
                suffix = { Text("kg") }, singleLine = true, shape = RoundedCornerShape(12.dp)
            )
            OutlinedTextField(
                value = age, onValueChange = { age = it },
                modifier = Modifier.weight(1f),
                label = { Text(stringResource(R.string.tci_age)) },
                suffix = { Text("a") }, singleLine = true, shape = RoundedCornerShape(12.dp)
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            OutlinedTextField(
                value = height, onValueChange = { height = it },
                modifier = Modifier.weight(1f),
                label = { Text(stringResource(R.string.tci_height)) },
                suffix = { Text("cm") }, singleLine = true, shape = RoundedCornerShape(12.dp)
            )
            Column(Modifier.weight(1f)) {
                Text(
                    stringResource(R.string.tci_sex),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                SegmentedRow(
                    options = listOf(stringResource(R.string.tci_sex_m), stringResource(R.string.tci_sex_f)),
                    selected = if (male) 0 else 1,
                    onSelect = { male = it == 0 }
                )
            }
        }

        // --- Diana ---
        OutlinedTextField(
            value = target, onValueChange = { target = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text(stringResource(R.string.tci_target)) },
            suffix = { Text(unit) }, singleLine = true, shape = RoundedCornerShape(12.dp)
        )
        Text(
            if (drug == 0) stringResource(R.string.tci_target_hint_propofol) else stringResource(R.string.tci_target_hint_remi),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        // --- Concentración de la jeringa ---
        Text(stringResource(R.string.tci_conc), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface)
        SegmentedRow(options = concs.map { it.label }, selected = concIdx, onSelect = { concIdx = it })

        // --- Diana plasma o efecto ---
        Text(stringResource(R.string.tci_mode), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface)
        SegmentedRow(
            options = listOf(stringResource(R.string.tci_mode_cp), stringResource(R.string.tci_mode_ce)),
            selected = if (effectMode) 1 else 0,
            onSelect = { effectMode = it == 1 }
        )

        // --- Resultados ---
        if (valid) {
            TciResultCard(plan, drugName, effectMode)
            Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
                AppButton(
                    stringResource(R.string.exp_save_calc),
                    secondary = true,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        val p0 = plan.points.firstOrNull()
                        Expediente.saveCalc(
                            ctx,
                            "TCI $drugName",
                            "Diana ${CalcEngine.fmt(CalcEngine.parseNum(target))} $unit (${if (effectMode) "Ce" else "Cp"}) · jeringa ${concs[concIdx].label} · " +
                                "bolo ${CalcEngine.fmt(plan.bolusMg)} mg (${CalcEngine.fmt(plan.bolusMl)} mL) · " +
                                "velocidad inicial ${if (p0 != null) CalcEngine.fmt(p0.rateMlH) else "—"} mL/h · " +
                                "total 60 min ${if (plan.points.isNotEmpty()) CalcEngine.fmt(plan.points.last().cumulativeMl) else "—"} mL"
                        )
                        Toast.makeText(ctx, ctx.getString(R.string.exp_saved), Toast.LENGTH_SHORT).show()
                    }
                )
            }
        } else {
            Text(
                stringResource(R.string.tci_need_data),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Text(
            stringResource(R.string.tci_disclaimer),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun TciResultCard(plan: CalcEngine.TciPlan, drugName: String, effectMode: Boolean) {
    val sp = LocalSpacing.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(sp.m.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                "$drugName · ${stringResource(if (effectMode) R.string.tci_res_effect else R.string.tci_res_plasma)}",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(2.dp))
            // Bolo inicial
            Text(
                stringResource(R.string.tci_res_bolus),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                "${CalcEngine.fmt(plan.bolusMg)} mg  (${CalcEngine.fmt(plan.bolusMl)} mL)",
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onSurface
            )
            // Velocidad inicial
            Text(
                stringResource(R.string.tci_res_rate0),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                "${CalcEngine.fmt(plan.rate0MlH)} mL/h  (${CalcEngine.fmt(plan.rate0MgH)} mg/h)",
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.height(4.dp))
            // Tabla de decaimiento BET
            Text(
                stringResource(R.string.tci_res_table),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Row(Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.tci_th_time), Modifier.weight(1f), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(stringResource(R.string.tci_th_rate), Modifier.weight(1.4f), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(stringResource(R.string.tci_th_ce), Modifier.weight(1.2f), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(stringResource(R.string.tci_th_total), Modifier.weight(1.2f), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            plan.points.forEach { p ->
                Row(Modifier.fillMaxWidth()) {
                    Text("${CalcEngine.fmt(p.tMin)} min", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                    Text("${CalcEngine.fmt(p.rateMlH)} mL/h", Modifier.weight(1.4f), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                    Text("${CalcEngine.fmt(p.cePct)} %", Modifier.weight(1.2f), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                    Text("${CalcEngine.fmt(p.cumulativeMl)} mL", Modifier.weight(1.2f), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                stringResource(R.string.tci_res_total60, CalcEngine.fmt(plan.points.last().cumulativeMl)),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                stringResource(R.string.tci_res_t90, CalcEngine.fmt(plan.t90CeMin)),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                stringResource(R.string.tci_res_cl, CalcEngine.fmt(plan.clLMin), CalcEngine.fmt(plan.v1L)),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (effectMode) {
                Text(
                    stringResource(R.string.tci_ce_note),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
