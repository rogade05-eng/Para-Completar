package cu.cronos.anestesia

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// =====================================================================
//  ANÁLISIS DE CASOS (v2.2.0)
//  Agrega los datos del expediente (pacientes y registros guardados) en
//  un informe de caso con estadísticas y lo exporta a PDF, Excel (.xlsx
//  real) y Word (.docx real) — todo offline con FileProvider (R-01).
//  La lógica (CaseAnalysis) es pura JVM: testeable en V220Test.
// =====================================================================

data class CaseAnalysis(
    val patients: Int,
    val entries: Int,
    val male: Int,
    val female: Int,
    val sexUnknown: Int,
    val ageGroups: List<Pair<String, Int>>,
    val topTags: List<Pair<String, Int>>,
    val last7: Int,
    val last30: Int,
    val avgEntriesPerPatient: Double,
    val firstTs: Long?,
    val lastTs: Long?
) {
    companion object {
        val AGE_ORDER = listOf("<12 años", "12–17 años", "18–59 años", "60–79 años", "80+ años")

        fun ageGroupOf(ageStr: String): String? {
            val age = ageStr.trim().replace(',', '.').toDoubleOrNull() ?: return null
            return when {
                age < 12 -> AGE_ORDER[0]
                age < 18 -> AGE_ORDER[1]
                age < 60 -> AGE_ORDER[2]
                age < 80 -> AGE_ORDER[3]
                else -> AGE_ORDER[4]
            }
        }

        /** Analiza la lista completa de pacientes y TODAS sus entradas. */
        fun analyze(patients: List<Patient>, allEntries: List<ExpEntry>): CaseAnalysis {
            var male = 0; var female = 0; var sexUnknown = 0
            val ageCounts = AGE_ORDER.associateWith { 0 }.toMutableMap()
            patients.forEach { p ->
                when (p.sex.trim().uppercase(Locale.ROOT)) {
                    "M", "H", "MASCULINO", "HOMBRE" -> male++
                    "F", "FEMENINO", "MUJER" -> female++
                    else -> sexUnknown++
                }
                ageGroupOf(p.age)?.let { ageCounts[it] = ageCounts[it]!! + 1 }
            }
            val byTag = allEntries.groupBy { it.tag.ifBlank { "Sin sección" } }
                .map { (k, v) -> k to v.size }
                .sortedWith(compareByDescending<Pair<String, Int>> { it.second }.thenBy { it.first })
                .take(8)
            val now = System.currentTimeMillis()
            val day = 86_400_000L
            val last7 = allEntries.count { it.ts >= now - 7 * day }
            val last30 = allEntries.count { it.ts >= now - 30 * day }
            val avg = if (patients.isEmpty()) 0.0
            else allEntries.size.toDouble() / patients.size
            return CaseAnalysis(
                patients = patients.size,
                entries = allEntries.size,
                male = male,
                female = female,
                sexUnknown = sexUnknown,
                ageGroups = AGE_ORDER.map { it to (ageCounts[it] ?: 0) },
                topTags = byTag,
                last7 = last7,
                last30 = last30,
                avgEntriesPerPatient = avg,
                firstTs = allEntries.minOfOrNull { it.ts },
                lastTs = allEntries.maxOfOrNull { it.ts }
            )
        }

        private fun fmt(n: Double): String {
            val r = (n * 10).toLong() / 10.0
            return if (r == r.toLong().toDouble()) r.toLong().toString() else r.toString()
        }

        /** Bloques del informe (texto, estilo 0 título / 1 encabezado / 2 cuerpo). */
        fun reportBlocks(a: CaseAnalysis, patients: List<Patient>, entriesByPatient: Map<String, List<ExpEntry>>): List<Pair<String, Int>> {
            val f = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            val out = mutableListOf<Pair<String, Int>>()
            out.add("Cronos Anestesia — Análisis de casos" to 0)
            out.add(
                "Informe generado offline a partir del expediente local. " +
                    "Contiene datos clínicos: custodiar conforme a la confidencialidad de la historia clínica." to 2
            )
            out.add("Resumen general" to 1)
            out.add(
                "Casos (pacientes): ${a.patients}\n" +
                    "Registros guardados: ${a.entries}\n" +
                    "Promedio de registros por caso: ${fmt(a.avgEntriesPerPatient)}\n" +
                    "Registros últimos 7 días: ${a.last7}\n" +
                    "Registros últimos 30 días: ${a.last30}\n" +
                    (if (a.firstTs != null) "Periodo: ${f.format(Date(a.firstTs))} — ${f.format(Date(a.lastTs ?: a.firstTs))}" else "Periodo: sin registros")
                    to 2
            )
            out.add("Distribución por sexo" to 1)
            out.add("Masculino: ${a.male} · Femenino: ${a.female}" + (if (a.sexUnknown > 0) " · Sin dato: ${a.sexUnknown}" else "") to 2)
            out.add("Distribución por grupo de edad" to 1)
            out.add(a.ageGroups.joinToString(" · ") { "${it.first}: ${it.second}" } to 2)
            out.add("Secciones (cálculos) más registradas" to 1)
            out.add(
                (if (a.topTags.isEmpty()) "Sin registros aún."
                else a.topTags.joinToString("\n") { "• ${it.first}: ${it.second}" }) to 2
            )
            out.add("Detalle por caso" to 1)
            if (patients.isEmpty()) {
                out.add("No hay casos guardados en el expediente de este dispositivo." to 2)
            } else {
                patients.forEach { p ->
                    val n = entriesByPatient[p.id]?.size ?: 0
                    out.add(
                        "${p.name.ifBlank { "Sin nombre" }}" +
                            (if (p.ci.isNotBlank()) " (CI ${p.ci})" else "") +
                            " — ${p.age.ifBlank { "s/d" }} años, ${p.sex.ifBlank { "s/d" }}, ${p.weightKg.ifBlank { "s/d" }} kg: $n registro(s)" to 2
                    )
                }
            }
            out.add("Documento generado por Cronos Anestesia (sin conexión). Verifique los datos antes de archivar o compartir." to 2)
            return out
        }
    }
}

/** Filas de la hoja Excel del análisis: encabezado + registros por caso + todos los registros. */
object AnalysisSheets {
    fun header(): List<String> =
        listOf("Cronos Anestesia — Análisis de casos", "", "", "")

    fun patientRows(patients: List<Patient>, entriesByPatient: Map<String, List<ExpEntry>>): List<List<String?>> {
        val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val rows = mutableListOf<List<String?>>()
        rows.add(listOf("Caso (paciente)", "CI", "Edad", "Sexo", "Peso (kg)", "Altura (cm)", "Antecedentes", "Registros"))
        patients.forEach { p ->
            rows.add(
                listOf(
                    p.name.ifBlank { "Sin nombre" }, p.ci, p.age, p.sex,
                    p.weightKg, p.heightCm, p.hx,
                    (entriesByPatient[p.id]?.size ?: 0).toString()
                )
            )
        }
        rows.add(emptyList())
        rows.add(listOf("Fecha", "Paciente", "Sección", "Registro"))
        patients.forEach { p ->
            (entriesByPatient[p.id] ?: emptyList()).forEach { e ->
                rows.add(listOf(fmt.format(Date(e.ts)), p.name.ifBlank { "Sin nombre" }, e.tag, e.text))
            }
        }
        return rows
    }
}

// ------------------------------ UI ------------------------------

@Composable
fun AnalysisSection() {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    val patients = remember { Expediente.patients(ctx) }
    val entriesByPatient = remember(patients) {
        patients.associate { it.id to Expediente.entries(ctx, it.id) }
    }
    val allEntries = entriesByPatient.values.flatten()
    val analysis = remember(patients, allEntries) { CaseAnalysis.analyze(patients, allEntries) }

    if (patients.isEmpty()) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Text(
                stringResource(R.string.analysis_empty),
                modifier = Modifier.padding(sp.m.dp),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
        return
    }

    // tarjetas de resumen (2 x 2)
    val statPairs = listOf(
        stringResource(R.string.analysis_stat_cases) to analysis.patients.toString(),
        stringResource(R.string.analysis_stat_entries) to analysis.entries.toString(),
        stringResource(R.string.analysis_stat_last30) to analysis.last30.toString(),
        stringResource(R.string.analysis_stat_avg) to String.format(Locale.getDefault(), "%.1f", analysis.avgEntriesPerPatient)
    )
    for (start in statPairs.indices step 2) {
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            for (k in 0 until minOf(2, statPairs.size - start)) {
                val (label, value) = statPairs[start + k]
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(Modifier.padding(sp.m.dp)) {
                        Text(
                            value,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            label,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }

    // sexo y edades
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(sp.m.dp)) {
            Text(
                stringResource(R.string.analysis_dist_title),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(sp.xs.dp))
            Text(
                stringResource(R.string.analysis_dist_sex, analysis.male, analysis.female) +
                    if (analysis.sexUnknown > 0) "  ·  ${stringResource(R.string.analysis_dist_unknown, analysis.sexUnknown)}" else "",
                style = MaterialTheme.typography.bodyMedium
            )
            analysis.ageGroups.forEach { (g, n) ->
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(g, style = MaterialTheme.typography.bodyMedium)
                    Text(n.toString(), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }

    // secciones top
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(sp.m.dp)) {
            Text(
                stringResource(R.string.analysis_tags_title),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(sp.xs.dp))
            if (analysis.topTags.isEmpty()) {
                Text(
                    stringResource(R.string.analysis_tags_empty),
                    style = MaterialTheme.typography.bodyMedium
                )
            } else {
                analysis.topTags.forEach { (t, n) ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(t, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                        Text(n.toString(), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }

    // exportación
    SectionLabel(stringResource(R.string.analysis_export_title))
    Text(
        stringResource(R.string.analysis_export_note),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
        AppButton(
            "PDF",
            secondary = true,
            modifier = Modifier.weight(1f),
            onClick = {
                runExport(ctx) {
                    val f = File(exportDir(ctx), "analisis_casos_${stamp()}.pdf")
                    Expediente.exportPdfBlocks(f, CaseAnalysis.reportBlocks(analysis, patients, entriesByPatient))
                    f
                }
            }
        )
        AppButton(
            stringResource(R.string.analysis_export_xlsx),
            secondary = true,
            modifier = Modifier.weight(1f),
            onClick = {
                runExport(ctx) {
                    val f = File(exportDir(ctx), "analisis_casos_${stamp()}.xlsx")
                    OfficeExport.writeXlsx(
                        f, "Análisis de casos",
                        AnalysisSheets.header(),
                        AnalysisSheets.patientRows(patients, entriesByPatient)
                    )
                    f
                }
            }
        )
    }
    AppButton(
        stringResource(R.string.analysis_export_docx),
        secondary = true,
        modifier = Modifier.fillMaxWidth(),
        onClick = {
            runExport(ctx) {
                val f = File(exportDir(ctx), "analisis_casos_${stamp()}.docx")
                OfficeExport.writeDocx(f, CaseAnalysis.reportBlocks(analysis, patients, entriesByPatient))
                f
            }
        }
    )
}

private fun exportDir(ctx: Context): File = File(ctx.cacheDir, "exports").apply { mkdirs() }
private fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())

private fun runExport(ctx: Context, make: () -> File) {
    try {
        val f = make()
        val mime = when {
            f.name.endsWith(".xlsx") -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            f.name.endsWith(".docx") -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            else -> "application/pdf"
        }
        Expediente.share(ctx, f, mime)
    } catch (e: Throwable) {
        Toast.makeText(ctx, e.message ?: "Error", Toast.LENGTH_LONG).show()
    }
}
