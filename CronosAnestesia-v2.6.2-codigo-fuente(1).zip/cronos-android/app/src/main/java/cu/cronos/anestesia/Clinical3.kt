package cu.cronos.anestesia

// =====================================================================
//  MÓDULO CLÍNICO — Parte 3 (v2.0.0): TEMAS QUIRÚRGICOS PRO+
//  14 temas de manejo perioperatorio avanzado con pautas accionables y
//  calculadora asociada (campo calcId → ClinCalcHost en ClinDetail).
//  Contenido: referencia educativa adaptada a es-CU, no protocolo.
// =====================================================================

val SURGICAL_TOPICS = listOf(
    // ------------------------------------------------------------------
    ClinTopic(
        "Paciente neuroquirúrgico",
        "Principios del manejo anestésico en craneotomía",
        "Quirúrgico",
        listOf(
            "Objetivos y fisiología" to "El cerebro es un órgano encerrado y no distensible: su perfusión depende de CPP = PAM − PIC (objetivo 60–70 mmHg). En el craneotomizado la autorregulación está desplazada: la hipertensión aumenta el edema y la hipotensión causa isquemia. El volumen cerebral depende de tres compartimentos (sangre, LCR, tejido): todo lo que los aumente (hipercapnia, hipoxia, venas del cuello comprimidas, hipotónicos) es el enemigo. La dupla CO2 y O2 gobierna el tono vascular: hipercapnia vasodilata y sube la PIC; la hipoxia extrema hace lo mismo.",
            "Inducción y vía aérea" to "La laringoscopia es el momento más peligroso: suprimir la respuesta con fentanilo 1–3 µg/kg, lidocaína 1–1,5 mg/kg o esmolol 0,5 mg/kg antes de manipular. Inducción: propofol (reduce el consumo de O2 cerebral y el flujo) + relajante no despolarizante (rocuronio 0,6 mg/kg: evitar succinilcolina si hay PIC alta o preferir despolarizante con las condiciones controladas en el TCE agudo). Tubo reforzado, fijación firme, cuidado con las lesiones oculares. La hipertensión de la inducción es tan peligrosa como la hipotensión: monitorizar la PA antes de inducir.",
            "Mantenimiento" to "TIVA con propofol + remifentanilo facilita la neuromonitorización y la emergencia limpia; sevoflurano ≤1 MAC también es aceptable. Ventilación: PaCO2 35–40 mmHg (hiperventilación solo si la PIC está alta, nunca de rutina); PEEP la mínima eficaz. Cabeza elevada 30° y cuello neutro. Fluidos: NaCl 0,9 % (evitar hipotónicos y SG5 %); volumen estricto, aceptar la ligera hipovolemia pero sin caer en hipotensión. Glucemia 140–180 mg/dL; normotermia (la hipotermia profiláctica no mejora los resultados).",
            "Osmoterapia y fármacos" to "Manitol 0,25–1 g/kg IV en 20–30 min (vigilar osmolalidad <320 mOsm/kg y reponer el volumen urinario) o NaCl 3 % (2–3 mL/kg o 250 mL): el objetivo es la osmolalidad, no la dosis. Dexametasona 8–16 mg/día para el edema vasogénico (tumores) — no útil en el edema citotóxico del infarto. Anticonvulsivos según el protocolo (fenitoína/levetiracetam). Antieméticos agresivos: el vómito sube la PIC y desgarra el paciente.",
            "Emergencia y postoperatorio" to "La emergencia es la segunda ventana peligrosa: evitar la tos, la tensión y la hipertensión con remifentanilo hasta terminar el vendaje, lidocaína IV y propofol de rescate. Extubar con el paciente tranquilo o programar la sedación en UCI si hay edema, sangrado o curso largo. Vigilar en la primera hora: pupilas, déficit neurológico nuevo, sangrado del drenaje: un deterioro neurológico súbito = CT inmediato (hematoma, hidrocefalia, edema). El dolor post-craneotomía es real pero moderado: paracetamol + tramadol/dipirona; evitar la sedación excesiva.",
            "Calculadora" to "Usa la calculadora de CPP (PAM y PIC) de esta sección para verificar en tiempo real que la perfusión cerebral está por encima de 60 mmHg durante todo el intraoperatorio."
        ),
        "cpp"
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Traumatismo craneoencefálico (TCE)",
        "TCE grave: CPP, osmoterapia y coagulopatía",
        "Quirúrgico",
        listOf(
            "Evaluación inicial" to "GCS define la gravedad (≤8 grave: intubar SIEMPRE), pupilas y CT de ingreso dirigen la cirugía (hematoma epidural/subdural, contusiones, edema, desviación de la línea media >5 mm). Buscar lesiones asociadas (XABCDE: el TCE grave rara vez viene solo): columna cervical, tórax, abdomen, pelvis. Extrapolación: hipotensión (PAM <65) e hipoxia (SpO2 <90 %) DOBLAN la mortalidad del TCE: evitarlas es el objetivo número uno desde la reanimación.",
            "Presión de perfusión cerebral" to "PIC monitorizada en todo GCS ≤8 con CT anormal: protocolo CPP = PAM − PIC con objetivo 60–70 mmHg. La PAM se mantiene con volumen + noradrenalina (el vasopresor de elección); NO con cristaloides hipotónicos. La PIC se controla con posición 30°, sedación/analgesia profunda, osmoterapia (NaCl 3 % 2–3 mL/kg o manitol 0,25–1 g/kg) e hiperventilación TRANSITORIA (PaCO2 30–35) solo en herniación inminente. La «hipertensión compensadora» (Cushing: HTA + bradicardia + respiración irregular) NO se baja con antihipertensivos: es signo de herniación.",
            "Inducción de urgencia" to "Secuencia rápida de intubación: preoxigenación, cricoides, etomidato 0,3 mg/kg o propofol titulado si la PA lo permite, succinilcolina 1,5 mg/kg (el riesgo de hiperpotasemia aparece después de 48–72 h de denervación o inmovilización: en el TCE agudo la succinilcolina es aceptable) o rocuronio 1,2 mg/kg. Cargar la PAM: volumen + fenilefrina/noradrenalina listos. La hipoxia de la intubación (desaturación) es la complicación más frecuente: apneic oxygenation + laringoscopía eficiente.",
            "Coagulopatía del TCE" to "El tejido cerebral libera tromboplastina: 1 de cada 3 TCE graves llega coagulópata y empeora en horas. Protocolo: TXA (ácido tranexámico) 1 g IV en 10 min + 1 g/8 h (CRASH-3: mejora el resultado en el TCE leve-moderado si se da en <3 h), PFC/vitamina K si INR >1,4, plaquetas si hay antiagregantes y sangrado activo, evitar la heparinización innecesaria. La coagulopatía y la anemia (Hb <7–8) son las dos correcciones más rentables en las primeras horas.",
            "Manejo integral" to "Glucemia 140–180 (la hiperglucemia agrava el daño axonal), normotermia (la fiebre multiplica la mortalidad; la hipotermia profiláctica NO ayuda), profilaxis de convulsiones 7 días (fenitoína/levetiracetam) en el TCE cortical, drenaje ventricular si hay hidrocefalia, craniectomía descompresiva según protocolo. Postoperatorio: UCI con PIC + CPP, nutrición temprana, profilaxis de trombosis (heparina de bajo peso molecular a las 24–72 h si el sangrado está controlado).",
            "Calculadora" to "La calculadora de CPP (PAM desde PAS/PAD y PIC) de esta sección permite verificar en segundos si la perfusión cerebral es suficiente durante toda la estabilización y la cirugía."
        ),
        "cpp"
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Tumores supratentoriales",
        "Craneotomía supratentorial: edema, awake y mapeo",
        "Quirúrgico",
        listOf(
            "Edema peritumoral y corticoides" to "El edema vasogénico alrededor del tumor responde a los corticoides: dexametasona 8–16 mg/día VO/IV en 2–4 dosis (efecto pleno en 24–72 h; en la urgencia 10 mg IV). No hay beneficio en dosis >16 mg/día; retirar progresivamente en el postoperatorio. Con corticoides prolongados: glucemia vigilada (140–180), cobertura de estrés y protección gástrica. En el paciente con edema masivo e hipertensión intracraneal, el CT con contraste y la cirugía se programan tras 24–48 h de corticoide cuando sea posible.",
            "Posicionamiento y monitorización" to "Decúbito supino/lateral según la localización; cabeza fijada en pinza, elevada 30°, con libertad de la yugular. Monitorización estándar + PA invasiva (necesaria para el CPP), drenaje urinario si la cirugía es larga, acceso venoso grande. Neuromonitorización: SSEP/MEP si el tumor toca la corteza motora o el tracto piramidal — LIMITA los relajantes (infusión de 1–2 × ED90 o despertar de rocuronio con sugammadex de rescate disponible).",
            "Craneotomía despierta (awake)" to "Para tumores cerca del área del lenguaje o motora: anestesia local + sedación (propofol 25–75 µg/kg/min + dexmedetomidina 0,2–0,7 µg/kg/h sin carga, o remifentanilo bajo) retirada JUSTO antes de la fase de mapeo. Claves del éxito: preoxigenación, oxigenación nasal apneica, analgesia del pin del cráneo (bloqueo del nervio escarpuloso/auriculotemporal), manejo de la tos y de las convulsiones intraoperatorias (propofol bolo, líquido frío sobre la corteza si el cirujano lo solicita, benzodiacepinas al final del mapeo).",
            "Fármacos y convulsiones" to "Anticonvulsivo profiláctico (levetiracetam 500–1000 mg IV o fenitoína 15–20 mg/kg de carga) en tumores corticales. Las convulsiones intraoperatorias: propofol 1–1,5 mg/kg, midazolam de rescate, corregir hiponatremia. Los anticonvulsivos clásicos (fenitoína, carbamazepina) son potentes inductores enzimáticos: reducen el efecto de los relajantes y de los opioides — TOF obligatorio.",
            "Emergencia y postoperatorio" to "Emergencia limpia: evitar la tos y la tensión (remifentanilo hasta el vendaje, lidocaína). Vigilar pupilas y déficit neurológico en la primera hora; el deterioro súbito = CT (hematoma del lecho, edema, hidrocefalia). Dolor: paracetamol + dipirona/tramadol (los opioides sedantes enmascaran el examen neurológico). Corticoide en reducción progresiva; antieméticos agresivos (el vómito sube la PIC y el dolor).",
            "Calculadora" to "Las pautas se apoyan en la calculadora de CPP disponible en «Paciente neuroquirúrgico» y «TCE» de esta misma sección (PAM − PIC con objetivo 60–70 mmHg)."
        ),
        ""
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Tumores infratentoriales",
        "Fosa posterior: posición, VAE y nervios craneales",
        "Quirúrgico",
        listOf(
            "Hidrocefalia y presión intracraneal" to "Los tumores de la fosa posterior obstruyen el acueducto de Silvio: la hidrocefalia obstructiva es común y puede requerir drenaje externo preoperatorio (el alivio de la PIC reduce el riesgo de la craneotomía). Vigilar en el preoperatorio: cefalea matutina, vómitos, papiledema, ataxia, GCS descendente. La intubación con PIC alta exige la misma protección que en el supratentorial (laringoscopia sin hipertensión ni tos).",
            "Posicionamiento" to "Tres opciones: sentada (excelente exposición quirúrgica, máxima tolerancia, pero mayor riesgo de embolia venosa aérea), prono y lateral (menor riesgo de VAE, peor acceso y compresión ocular/abdominal). En la posición sentada: el corazón debe quedar por debajo o al nivel del vértice siempre que se pueda, compresión elástica en los miembros inferiores, colchón de apoyo del cuello, protección ocular OBLIGATORIA con revisión periódica (queratopatía por exposición).",
            "Embolia venosa aérea (VAE)" to "El gradiente venoso negativo de la fosa posterior/sentada aspira aire por las venas del lecho quirúrgico: la VAE es la complicación temida. Detección por sensibilidad: Doppler precordial (el más sensible, detecta ~0,1 mL/kg), capnografía (caída del EtCO2), N2O evitada SIEMPRE en posición sentada (N2O agranda la burbuja) y PA invasiva con caída súbita. Manejo: avisar al cirujano (inundar el campo con SF, oclusión venosa), solicitar maniobra de Valsalva (aumenta la presión venosa y detiene la entrada de aire), aspirar por el catéter central multiorificio si se dispone (posición CVC en unión cavoatrial), O2 100 %, soporte hemodinámico, y en la parada: decúbito lateral izquierdo + RCP.",
            "Neuromonitorización de nervios craneales" to "VII (facial), V (trigémino), X (vago), XI e XII monitoreados con EMG: el relajante se limita a la inducción (sugammadex para el despertar urgente) y se abandona en el mantenimiento. La extubación se planifica con el cirujano: si hay disfunción de X/X (disfagia, laringe), puede requerir extubación diferida o traqueostomía.",
            "Postoperatorio" to "La fosa posterior es territorio de complicaciones únicas: apnea central postoperatoria (síndrome de Ondine: vigilancia respiratoria en UCI si el cirujano manipula el bulbo), disfagia y aspiración, hipertensión intracraneal por hematoma o hidrocefalia, «pseudomeningocele» y fístula de LCR. El dolor postoperatorio es moderado: paracetamol + dipirona/tramadol. El nistagmo y los vértigos pueden retrasar la movilización: profilaxis de trombosis (inmovilización prolongada).",
            "Calculadora" to "El ajuste ventilatorio (PaCO2 35–40, PEEP mínima) y la calculadora de CPP del tema «Paciente neuroquirúrgico» sirven igualmente para la fosa posterior; en posición sentada el CPP se calcula con la PAM medida a nivel del cerebro (corregir la PAM por la altura del campo quirúrgico: −1 mmHg por cada 1,3 cm sobre el nivel del corazón)."
        ),
        ""
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Hemodilución",
        "Estrategias de ahorro de sangre (ANH y aféresis)",
        "Quirúrgico",
        listOf(
            "Concepto y candidatas" to "La hemodilución aguda normovolémica (ANH) consiste en extraer sangre entera en la inducción (bolsas citratadas a temperatura ambiente, hasta 6 h de validez) reponiendo simultáneamente el volumen con cristaloide (3:1) o coloide (1:1), para que el sangrado posterior pierda hematíes (la sangre «diluida» pierde menos O2-capacidad). Candidatas: Hb >13 g/dL, cirugía con sangrado esperado >20 % de la volemia, buena reserva cardíaca y pulmonar. Contraindicaciones: anemia basal, isquemia cardíaca activa, hipotensión no controlada, falta de monitorización.",
            "Cálculo y ejecución" to "Volumen extraíble: V = EBV × (Hct inicial − Hct objetivo)/Hct medio, con Hct objetivo 25–30 % (el «fondo» es individual: isquémico 30 %, sano 25 %). Extraer en bolsas de 250–450 mL con anticoagulante CPD, rotular con el nombre y la hora, mantener a temperatura ambiente (no en nevera: las plaquetas y factores se deterioran) y reinfundir al final de la cirugía (última bolsa primero: la más concentrada se devuelve al final). Reponer el volumen extraído 3:1 con cristaloide o 1:1 con coloide.",
            "Tolerancia a la anemia" to "La anemia aguda normovolémica se tolera mejor de lo que sugiere el instinto: el gasto cardíaco compensa (↓ viscosidad = ↑ flujo) hasta Hct ~20 % en el paciente sano anestesiado con O2 suplementario. Umbrales transfusionales: Hb 7–8 g/dL en el sano, 8–10 en isquemia/CEC/cardiopatía; el criterio final es el balance de entrega (DO2 = CO × CaO2): vigilar el lactato y el SVO2 si están disponibles.",
            "Otras estrategias combinadas" to "Hierro IV preoperatorio (4–6 semanas antes) + eritropoyetina en anemia crónica; célula salvadora (cell salvage) complementaria o alternativa a la ANH; hipotensión controlada (PAM 55–65) en cirugía seleccionada; hemostasia farmacológica: TXA 1 g IV en 10 min + 1 g/8 h, desmopresina en deficiencias específicas; dilución «a medida» en pacientes testigos (Testigos de Jehová): documentar con el paciente qué acepta y qué no (fracciones, célula salvadora en circuito cerrado, hipotensión, eritropoyetina).",
            "Riesgos y errores" to "Sobredilución (Hct <20 sin cobertura de O2), contaminación de las bolsas, extracción sin reposo del volumen (hipovolemia encubierta), olvidar reinfundir TODAS las bolsas (contarlas al inicio y al final), anticoagulante insuficiente (coágulo en la bolsa). La ANH no sustituye la hemostasia quirúrgica: es una de las piezas del programa de ahorro de sangre (patient blood management).",
            "Calculadora" to "La calculadora de ANH de esta sección (volemia por categoría, Hct inicial/objetivo/mínimo) devuelve el volumen extraíble y el sangrado permitido restante: úsala ANTES de inducir y etiqueta las bolsas con el resultado."
        ),
        "anh"
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Trasplante",
        "Hepático, renal y cardíaco: claves anestésicas",
        "Quirúrgico",
        listOf(
            "Trasplante hepático: las tres fases" to "1) Pre-anhepática (disección): sangrado masivo frecuente, hipovolemia, hipocalcemia por transfusión masiva — acceso grande, célula salvadora, protocolo de transfusión masiva listo. 2) Anhepática (clamps): ausencia de producción hepática (glucosa, factores, citrato), acidosis láctica progresiva, posible bypass veno-venoso — corrección activa de coagulación (PFP, crioprecipitado, fibrinógeno) guiada por ROTEM/TEG si hay. 3) Reperfusión (neoreperfusión): síndrome de reperfusión (hipotensión súbita, arritmia, ↓EtCO2 por el K+ y los mediadores fríos del injerto): pre-reperfusión con volumen + Ca + bicarbonato si pH <7,1, adrenalina en bolos pequeños preparada, avisar al cirujano para «abrir lento».",
            "Fisiología y fármacos en el hepático" to "El receptor de trasplante hepático tiene encefalopatía, ascitis, coagulopatía mixta, disfunción renal y cardiopulmonar (síndrome hepatopulmonar, HTAP): propofol bien tolerado en titulación, cisatracurio de elección (Hofmann), remifentanilo sin ajuste; evitar AINE, nefrotóxicos y la sobrecarga. La hiponatremia crónica se corrige LENTO en el postoperatorio (osmotic demyelination). La glucosa se vigila desde la fase anhepática.",
            "Trasplante renal" to "Paciente con ERC 4–5 (± diálisis reciente): PA objetivo alta (PAM ≥65–75 para perfundir el injerto), fluidos equilibrados moderados (el injerto necesita precarga), mannitol/diurético según protocolo al reperfundir, evitar AINE y nefrotóxicos, inmunosupresión de inducción coordinada con el equipo (metilprednisolona), infusión de vasopresor si es necesario (noradrenalina baja dosis segura). La anestesia neuraxial en el trasplante renal requiere el coagulograma del dializado.",
            "Trasplante cardíaco" to "El receptor denervado: no responde a la atropina (usar adrenalina/efedrina) y depende del ritmo intrínseco — marcador «escapes» y tiene inotrópicos preparados. El «síndrome de la precarga»: la reperfusión del injerto requiere volumen + inotrópicos (dobutamina, milrinona, adrenalina) listos ANTES de liberar el clamp. HTAP preoperatoria contraindica el trasplante: manejar con inodilatadores (milrinona, NO inhalado). La anticoagulación y el bypass son el dominio del equipo de CEC.",
            "Donante y logística" to "El anestesiólogo también atiende al DONANTE con muerte encefálica: proteger los órganos (PA objetivo 60–65, euvolemia, diuresis hormonal con vasopresina 0,01–0,04 UI/min para la diabetes insípida, corrección de electrolitos y temperatura). Coordinación con la red de trasplantes: cada minuto de isquemia fría cuenta. Documentar los niveles de inmunosupresión del receptor en el postoperatorio y la cobertura antibiótica según el protocolo del centro.",
            "Calculadora" to "La calculadora MELD-Na de esta sección cuantifica la gravedad del receptor hepático (bilirrubina, INR, creatinina, Na, diálisis) y orienta la prioridad y el riesgo quirúrgico: úsala en la consulta preanestésica."
        ),
        "meld"
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Embarazo crítico",
        "Preeclampsia, eclampsia y emergencias obstétricas",
        "Quirúrgico",
        listOf(
            "Preeclampsia grave / eclampsia" to "Magnesio sulfato: carga 4 g IV en 20–30 min + mantenimiento 1–2 g/h (continuar 24 h postparto); recurrencia: 2 g en bolo. Antídoto: gluconato de calcio 1 g IV lento. Vigilar reflejo patelar, frecuencia respiratoria (>12) y diuresis (>0,5 mL/kg/h) — el MgSO4 potencia el bloqueo neuromuscular: TOF obligatorio. PA controlada con labetalol (10–20 mg IV) o hidralazina (5–10 mg IV); objetivo diastólico 80–100 (hipercontrol daña la perfusión placentaria).",
            "Anestesia en la preeclampsia" to "Raquídea/epidural preferida en la cesárea (evita la vía aérea edematosa): corregir la hipovolemia relativa, fenilefrina en infusión profiláctica (0,25–0,5 µg/kg/min), la hipotensión espinal es más profunda y peligrosa en preeclampsia (menor tolerancia al descenso de la precarga). Anestesia general: evitar la respuesta al laringoscopio (esmolol/lidocaína/fentanilo), la vía aérea edematosa y sangrante es el mayor riesgo: tubo 0,5–1 mm menor, Plan B/D listos. Coagulograma antes de neuraxial si hay HELLP (plaquetas <100 000: contraindicación relativa).",
            "Desprendimiento y HELLP" to "Desprendimiento de placenta: sangrado oculto subestimado, CID temprana (fibrinógeno es el marcador), decidir la vía de parto por el bienestar fetal y la hemodinamia materna: dos vías grandes, sangre/crioprecipitado disponibles, protocolo de hemorragia activado por defecto. HELLP: hemólisis + enzimas + plaquetas — el parto es el tratamiento, el MgSO4 protege de la eclampsia, la HTA se controla, y en el postoperatorio vigilar el edema pulmonar (restricción de fluidos).",
            "Embolia de líquido amniótico" to "Cuadro súbito en trabajo de parto/cesárea: hipoxia + hipotensión + coagulopatía (CID) + convulsiones. Tratamiento de soporte: O2/ventilación, vasopresores (noradrenalina/adrenalina), protocolo de transfusión masiva 1:1:1, parto rápido si está in útero (cesárea de rescate en 5 min). No hay antídoto: la rapidez del equipo salva. Diferencial con eclampsia (PA alta vs shock), anafilaxia (lípidos NO aplican aquí: el tratamiento es soporte + TXA si sangra).",
            "Hemorragia posparto y reanimación materna" to "Protocolo de HPP (ver Perlas clínicas): uterotónicos escalonados, TXA 1 g, transfusión masiva 1:1:1 con fibrinógeno objetivo >200 mg/dL. RCP materna: compresiones estándar SIN inclinación lateral (la «inclinación uterina» se hace con la mano), desfibrilación segura, y CESÁREA PERIMORTEM en 4–5 min si el embarazo ≥20 semanas (salva a la madre y al bebé).",
            "Calculadora" to "La calculadora de MgSO4 de esta sección (carga y mantenimiento, mL/h para ampolla de 2 g/10 mL al 20 %) evita el error de cálculo en la infusión: úsala en toda preeclampsia grave."
        ),
        "mgso4"
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Cardiopatía congénita adulta",
        "Shunts, HTAP y riesgos del adulto operado",
        "Quirúrgico",
        listOf(
            "Fisiología del shunt" to "Shunt izquierda→derecha (CIA, CIV, ductus): recirculación pulmonar (Qp/Qs >1) — el riesgo es la sobrecarga de volumen del VD y la HTAP con el tiempo. Shunt derecha→izquierda (Eisenmenger, Fallot, atresia): cianosis y bypass pulmonar — el riesgo es la embolia paradójica (¡TODA línea IV necesita filtro de burbuja!) y el aumento del shunt con la ↓RVP. La calculadora Qp/Qs de esta sección cuantifica el shunt por oximetría: >1,5 confirma el L→R significativo; <1 apunta al R→L.",
            "Ventilación y hemodinamia por tipo de shunt" to "L→R: MANTENER la PVR baja (hipoxia/hipercapnia/acidosis la suben y aumentan el shunt): normocapnia, O2 suficiente, evitar el PEEP excesivo y la N2O (aumenta la RVP y la embolia). R→L (Eisenmenger): EVITAR la caída de la RVP sistémica — la vasodilatación aumentará el right-to-left shunt y la desaturación; mantener la precarga y el tono (fenilefrina útil); las bolas de presión positiva deben ser mínimas.",
            "Riesgos perioperatorios mayores" to "Endocarditis: profilaxis antibiótica según el protocolo en procedimientos «sucios» (dental, GI, GU). Arritmias: los adultos con congénita tienen cicatrices y suturas — cardioversión temprana ante cualquier inestabilidad. Hemoconcentración cianótica: eritrocitosis (Hb >18–20) con riesgo de trombosis y hemorragia PARADÓJICA (coagulopatía del cianótico): hidratación desde la noche anterior y vigilancia del hematocrito. Embolia paradójica: filtros de burbuja en TODAS las líneas IV y cuidado absoluto con las burbujas.",
            "Casos típicos del adulto" to "Tetralogía de Fallot reparada: insuficiencia pulmonar crónica, arritmias ventriculares — mantener la precarga y evitar los inotrópicos excesivos; spells (crisis de Fallot) con β-bloqueo, fenilefrina y O2 100 %. Coartación aórtica: HTA proximal + hipoperfusión distal — PA invasiva derecha + izquierda si se piensa clamping. Estenosis pulmonar/balón: mantener el llenado del VD. Ebstein: arritmias de reentrada (WPW) — electros disponible. Fontan: DEPENDE de la precarga y de la PVR baja: PEEP mínima, volumen, evitar la hipovolemia (el «pulmón Fontan» no tiene bomba).",
            "Anestesia práctica" to "Monitorización: ECG 5 derivaciones + SpO2 bilateral (preductal/postductal si hay ductus), PA invasiva temprana, eco a la cabecera si está disponible; evitar la N2O SIEMPRE en congénita (shunts, embolia). Inducción: etomidato/ketamina en dosis ajustadas al tipo de shunt; los inductores vasodilatadores (propofol a dosis plena) son peligrosos en el R→L. Analgesia multimodal con bloqueos regionales cuando el tipo de cirugía lo permita (la región neuraxial exige coagulograma y ausencia de HTAP avanzada).",
            "Calculadora" to "La calculadora Qp/Qs de esta sección (SaO2 aórtica, SvO2 mezclada, SpvO2 venosa pulmonar, SpaO2 arteria pulmonar) cuantifica el shunt intraoperatorio o en el cateterismo: >1,5 L→R significativo; caída súbita del cociente = cambio de la fisiología (avisar al cirujano)."
        ),
        "qpqs"
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Fisiología respiratoria aplicada",
        "De la fórmula a la cama: oxigenación y ventilación",
        "Quirúrgico",
        listOf(
            "Volúmenes y la anestesia" to "La FRC (volumen de cierre de los alvéolos) cae ~20 % con la anestesia general: alvéolos colapsados = shunt intrapulmonar = hipoxemia. El obeso pierde aún más (FRC 50 %), y en Trendelenburg + neumoperitoneo más todavía: por eso la PEEP 5–10 y el reclutamiento son sistemáticos. La baja reserva hace que la desaturación post-apnea sea rápida (segundos): preoxigenación (denitrogenación) prolongada en todos, apneic oxygenation en la laringoscopía.",
            "Oxigenación: de la fórmula al paciente" to "Ecuación del gas alveolar: PAO2 = FiO2 × (Patm − PH2O) − PaCO2/0,8. Gradiente A–a normal ≈ edad/4 + 4 (o 25 mmHg): el gradiente ampliado apunta a shunt/desajuste V/Q/difusión; el normal con hipoxemia = hipoventilación. Índice P/F = PaO2/FiO2 (Berlin: <300 leve, <200 moderado, <100 grave). Contenido arterial: CaO2 = 1,34 × Hb × SaO2 + 0,0031 × PaO2 — por eso la ANEMIA mata la entrega más que la PaO2: el O2 disuelto es casi nada.",
            "Entrega de O2 (DO2)" to "DO2 = CO × CaO2 × 10 (mL/min). Normal ≈ 1000 mL/min con consumo ~250: reserva ×4. La hipoxia tisular aparece cuando DO2 < ~400: anemia + bajo gasto + hipoxemia se MULTIPLICAN, no se suman. Estrategia: corregir primero lo más ineficiente (1 g de Hb vale más que 10 puntos de SaO2 ya saturada; subir el CO con volumen/vasopresor/inotrópico según el perfil).",
            "Ventilación y CO2" to "Ventilación alveolar = (VT − espacio muerto) × FR: el espacio muerto aumenta con el énfasis (embolia, HPN) y con la baja PEEP. EtCO2 35–40 mmHg es el objetivo no neurológico; en neuro 35 ± ajuste a la PIC. Hipercapnia permisiva (55–65) en asma/EPOC con meseta <30; el EtCO2 súbitamente bajo = embolia/CEC/taponamiento: nunca ignorarlo. La hiperventilación prolongada isquemiza el cerebro (vasoconstricción) y desplaza el K+.",
            "Ventilación protectora perioperatoria" to "VT 6–8 mL/kg IBW, PEEP 5–10, reclutamientos según el perfil, meseta <30 cmH2O, driving pressure <15, FiO2 mínima eficaz (SpO2 92–96 %). La ventilación «grande y aireada» del siglo pasado aumenta atelectasias, barotrauma y complicaciones postoperatorias: el VILI (lesión inducida por el ventilador) es real también en el quirófano.",
            "Calculadora" to "La calculadora de fisiología respiratoria de esta sección integra CaO2, PAO2, gradiente A–a con su límite por edad, P/F y DO2: introduce Hb, SaO2, PaO2, PaCO2, FiO2 y CO y lee el perfil completo de oxigenación."
        ),
        "resp"
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Fisiología cardiovascular aplicada",
        "CO, resistencias y Starling en el quirófano",
        "Quirúrgico",
        listOf(
            "Gasto cardíaco y sus determinantes" to "CO = FC × VS. El VS depende de precarga (volumen, retorno venoso), contractilidad y postcarga (resistencias). La anestesia golpea los tres: vasodilatación (↓ precarga y postcarga), ↓ contractilidad (halogenados, propofol) y desenmascara el tono simpático. La compensación del paciente despierto (FC, tono) desaparece con la inducción: el «descenso de la PA de la inducción» es fisiología, no accidente.",
            "Curva de Starling y respuesta a volumen" to "La curva de Starling tiene meseta: después de un punto, más volumen NO aumenta el VS (y genera congestión). La respuesta a volumen se predice con la VARIACIÓN DE LA PRESIÓN DE PULSO (PPV): >13 % con ventilación controlada y VT ≥8 mL/kg sugiere respondedor a volumen; 10–13 % zona gris; <10 % no respondedor (más volumen solo congestiona). El eco (VCI, LVOT) es el «gotómetro» moderno en el quirófano.",
            "Resistencias vasculares" to "SVR = (PAM − PVC) × 80/CO (normal 800–1200 dyn·s/cm5); PVR = (PAPm − PAWP) × 80/CO (normal 100–250). SVR baja (sepsis, anafilaxia, neuraxial): vasopresor (noradrenalina de base). SVR alta con bajo gasto: inodilatador (milrinona) o vasodilatador. PVR alta (HTAP, hipoxia, hipercapnia, acidosis, N2O): evitar los factores que la suben; milrinona/NO inhalado si es crítico. Estas fórmulas convierten la PA y el CO en DECISIONES.",
            "Equivalencia Fick y medición" to "CO por Fick: CO = VO2 / [10 × (CaO2 − CvO2)] — VO2 estimado 250 mL/min (o 3,5 mL/kg/min en calorimetría). En la práctica: CO monitor (termodilución, pulso-contorno), eco (VTI × CSA × FC). El SVO2 (mezclada) <60 % = DO2 insuficiente (anemia, hipoxia, bajo CO o ↑ consumo): tratar la causa dominante.",
            "Aplicación práctica por perfil" to "Estenosis aórtica: precarga llena, tono (fenilefrina), ritmo sinusal, evitar la taquicardia. Estenosis mitral: FC LENTA (el llenado depende del tiempo diastólico), evitar la ↑PVR. Insuficiencias: FC rápida relativa + vasodilatación leve tolerada. Miocardiopatía: inotrópicos + evitar el postcarga alto. Hipertrófica: ¡NO inotrópicos!, mantener el llenado y el tono, β-bloqueo. El perfil hemodinámico (frío/cálido, húmedo/seco) guía todo.",
            "Calculadora" to "La calculadora cardiovascular de esta sección calcula CO (FC × VS), SVR y PVR (con PA invasiva y presiones de llenado) y el CO por Fick si introduces VO2 y contenidos de O2: úsala para pasar de «la PA está baja» a «la SVR está en 700 con CO 5,2: es un problema de resistencias, no de bomba»."
        ),
        "cardio"
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Cirugía cardíaca con CEC",
        "Circulación extracorpórea: anticoagulación, flujo y reperfusión",
        "Quirúrgico",
        listOf(
            "Fundamentos de la CEC" to "La bomba reemplaza corazón y pulmones: retorno venoso → reservorio oxigenador → aorta (femoral si es necesario). Flujo no pulsátil 2,2–2,8 L/min/m² (calculadora), PAM 50–70 mmHg, hematocrito en el circuito 20–25 % (hemodilución del priming), temperatura controlada (normotermia/hipotermia leve 32–34 °C en la mayoría; profunda en los arcos). El pulmón se ventila en «bajas presiones» o se deja estático según el centro.",
            "Anticoagulación y reversal" to "Heparina no fraccionada 300–400 UI/kg IV (calculadora) por vía central, ACT >480 s ANTES de canalizar, ACT cada 30 min (añadir heparina si cae). Al terminar: protamina 1–1,3 mg por cada 100 UI de heparina residual (calculadora), lento en 10–15 min (hipotensión/hipertensión pulmonar si es rápida), reacción anafiláctica en diabéticos NPH: preparada. La coagulopatía post-CEC es multifactorial (dilución, plaquetas, hipotermia): corrección guiada por ROTEM/TEG.",
            "Distribución de flujo y protección de órganos" to "La perfusión no pulsátil con presión «adecuada» NO garantiza perfusión regional: la autorregulación está intacta en cerebro y riñón, no en el resto. Vigilar NIRS cerebral si está disponible (caída >20 % del basal = hipoperfusión regional), diuresis ≥0,5 mL/kg/h, glucemia 140–180. La embolia (aire, partículas, calcio del aorta) es la mayor fuente de disfunción cognitiva post-CEC: filtros y manejo cuidadoso de los clamps.",
            "Reperfusión y disfunción miocárdica" to "La apertura del clamp aórtico («reperfusión») es el momento crítico: disfunción del VI/VD transitoria, arritmias, embolia de aire. Preparar inotrópicos (dobutamina, milrinona, adrenalina) y el des aireado (agujas de LV, TEE para el aire intracavitario: no terminar el destete con aire visible). El destete (weaning) es gradual: llenado + ritmo + inotrópicos; VD fallado: milrinona/NO inhalado; bloqueo AV: cables epicárdicos y marcapasos listos.",
            "Post-CEC y hemostasia" to "Hemostasia: plaquetas, PFP, crioprecipitado según el coagulograma (fibrinógeno >200 mg/dL); TXA en la mayoría de los centros; célula salvadora del campo y del circuito (el blood del circuito se reinfunde con protamina PENDIENTE o por el cell saver). Hipotermia residual: recalentar ≥36 °C antes del cierre (la hipotermia bloquea la coagulación y la farmacocinética). El pulmón se recluta ANTES de destetar (atelectasias de CEC).",
            "Calculadora" to "La calculadora de CEC de esta sección: BSA (Mosteller) → flujo de bomba (BSA × IC 2,4), heparina UI (350 UI/kg) y protamina estimada (mg por 100 UI): los tres números que se repiten en cada caso."
        ),
        "cec"
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Trauma en masa",
        "Control de daños, transfusión masiva y triada letal",
        "Quirúrgico",
        listOf(
            "Principios y evaluación" to "XABCDE del trauma: Hemorragia exanguinante PRIMERO (compresión, torniquete, hemostasia), luego Vía aérea (RSI con estabilización cervical), Respiración (neumotórax a tensión: descompresión inmediata), Circulación, Discapacidad (GCS, pupilas), Exposición. La «hora dorada» es el tiempo hasta el control quirúrgico del sangrado. El paciente en shock hemorrágico NO espera: la cirugía es la reanimación definitiva.",
            "Triada letal y control de daños" to "Hipotermia + acidosis + coagulopatía se alimentan mutuamente: romper el círculo es la prioridad. Calentamiento ACTIVO (fluidos calientes, manta, ambiente), evitar la laparotomía larga: «damage control surgery» (control del sangrado + cierre temporal + UCI para estabilizar + volver a operar en 24–48 h). Anestesia de control de daños: ketamina 0,5–1 mg/kg o etomidato reducido, succinilcolina 1–1,5 mg/kg (riesgo de hiperkalemia solo en >48 h de quemado/desnervación), dosis de inductores REDUCIDAS al 30–50 % en el shock (la farmacocinética cambia).",
            "Transfusión masiva y fármacos hemostáticos" to "Protocolo MTP: CGR:PFP:PLT 1:1:1 (el plasma y las plaquetas tan pronto como la sangre); crioprecipitado/fibrinógeno concentrado para fibrinógeno >200 mg/dL objetivo; TXA 1 g IV en 10 min + 1 g/8 h (CRASH-2: en las primeras 3 h salva vidas; después de 3 h puede dañar). Vigilar el calcio ionizado (la citrato de las bolsas lo baja: reponer CaCl 0,5–1 g/h si hay transfusión masiva) y el K+ (la «hiperkalemia del washout» del shock).",
            "Volumen y vasopresores en el trauma" to "Fluidoterapia restringida/moderada («permissive hypotension» PAS 80–90 mmHg) HASTA el control quirúrgico, EXCEPTO TCE (la hipotensión dobla la mortalidad cerebral: en el politrauma con TCE la PAS objetivo ≥100–110). Cristaloides equilibrados, coloides limitados, sangre temprana. Los vasopresores SON PUENTES (noradrenalina diluida lista) mientras llega la sangre, no sustituyen el volumen en el hemorrágico puro.",
            "Anestesia regional en el trauma" to "Los bloqueos regionales son aliados (fracturas de fémur: bloqueo fascia iliaca reduce el dolor y el opioide; costillas: serrato/TPVB), pero en el hipovolémico el simpaticolisis cae la PA: dosis vasopresor profiláctica y nivel de bloqueo mínimo. Neuraxial solo con coagulación demostrada y estabilidad. Documentar la logística del MTP: el anestesiólogo es el director del equipo de transfusión en el quirófano.",
            "Calculadora" to "La calculadora de trauma de esta sección estima las unidades de CGR para el objetivo de Hb (ΔHb × peso/70) y recuerda las proporciones del MTP 1:1:1 y la dosis de TXA: números rápidos cuando el protocolo se activa."
        ),
        "trauma"
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Ventilación unipulmonar (OLV)",
        "Aislamiento pulmonar e hipoxemia en toracoscopía",
        "Quirúrgico",
        listOf(
            "Indicaciones y aislamiento" to "OLV para toracoscopía (la mayoría), toracotomía pulmonar, cirugía aórtica torácica, esofaguectomía. Aislamiento: DLT (doble luz: 35–37 Fr mujer, 37–39 Fr hombre) o tubo bloqueador (vía aérea difícil, pediátrico). Verificación con fibrobroncoscopio OBLIGATORIA tras el decúbito lateral (la posición mueve el tubo: el pulmón «dependiente» es el que ventila).",
            "Fisiología de la OLV" to "El pulmón no dependiente queda colapsado: shunt intrapulmonar del lado no ventilado + desajuste V/Q = hipoxemia esperable (SpO2 90–94 % tolerable con FiO2 alta). La hipoxemia empeora con la dependencia (el pulmón dependiente está comprimido), la cirugía en el pulmón «bueno», la hipovolemia y el lapso del reclutamiento. La HPV (hipoxia pulmonar vasoconstricción) ayuda a desviar el flujo del lado colapsado: LA N2O y los vasodilatadores la inhiben (N2O contraindicada).",
            "Programación ventilatoria" to "Pulmón dependiente: VT 5–7 mL/kg IBW (NO el peso real), FR 12–16, PEEP 5–10 (titulada: mucha PEEP desvía flujo al dependiente y empeora), FiO2 100 % inicial, PaCO2 permisiva (45–55). Reclutamiento del dependiente ANTES de la OLV y periódico. La calculadora de OLV de esta sección (IBW → VT, FR objetivo por MV ~100 mL/kg/min, ajuste por EtCO2) programa la base.",
            "Algoritmo de hipoxemia en OLV" to "1) FiO2 100 % + verificar posición con fibro (el tubo se ha movido). 2) CPAP 2–5 cmH2O al pulmón NO dependiente (el más eficaz: valvular si el cirujano necesita el campo seco). 3) PEEP al dependiente (subir 2–3 cmH2O). 4) Reclutamiento del dependiente. 5) Revisión de la hemodinamia (bajo gasto = peor shunt). 6) Clamp parcial del pulmón operado si el cirujano lo permite. 7) Volver a la ventilación bilateral 5–10 min si la SpO2 no responde. 8) Eco: excluir neumotórax del dependiente/derrame.",
            "Descendimiento y postoperatorio" to "Desclamp: reclutar el pulmón operado GRADUALMENTE (presiones moderadas: el pulmón operado es frágil), ventilación bilateral con VT 6–8 IBW, FiO2 al SpO2. La «triple escalera» postoperatoria: analgesia multimodal con bloqueo regional (paravertebral, serrato, epidural torácica) + paracetamol + opioide de rescate — la analgesia torácica eficaz previene las complicaciones pulmonares. Vigilar neumotórax residual, derrame pleural y fuga aérea.",
            "Calculadora" to "La calculadora de OLV de esta sección: con altura y sexo calcula IBW → VT (6 mL/kg), FR sugerida para MV objetivo y la corrección de FR según el EtCO2 medido/deseado: la «receta» ventilatoria del pulmón dependiente."
        ),
        "olv"
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Videocirugía (laparoscopía)",
        "Neumoperitoneo de CO2: respiración y hemodinamia",
        "Quirúrgico",
        listOf(
            "Fisiología del neumoperitoneo" to "CO2 a 12–15 mmHg intraabdominal: absorción sistémica (hipercapnia), ↑ resistencia pulmonar y ↓ compliance ~30–50 %, ↑ presión intratorácica con ↓ retorno venoso. La respuesta ventilatoria: mantener VT 6–8 mL/kg IBW y SUBIR LA FR (el CO2 se elimina por minuto ventilado, no por volumen); PEEP 8–10 y reclutamiento en Trendelenburg (atelectasias casi garantizadas). El EtCO2 sube 15–25 % de forma esperada: vigilar el gasometría en cirugías largas (el EtCO2 subestima la PaCO2 en el paciente con pulmón enfermo).",
            "Efectos hemodinámicos y posicionamiento" to "Insuflación: ↑ SVR (comprime el lecho esplácnico) y ↓ retorno venoso: en el paciente hipovolémico la PA cae; en el hipervolémico puede subir. Trendelenburg (ginecológica/prostática): ↑ precarga + edema de vía aérea (tubo más fino, vigilancia del edema en cirugías >4 h); decúbito lateral: el pulmón dependiente se recluta con PEEP. Los ancianos y cardiopáticos: insuflación GRADUAL (8 → 12 → 15) con vigilancia del CO.",
            "Complicaciones de la laparoscopía" to "Embolia de CO2 (rara pero letal: caída SÚBITA del EtCO2 + hipotensión + «rueda de molino» en el Doppler): O2 100 %, detener la insuflación, Trendelenburg izquierdo, aspirar el catéter central, RCP si hace falta. Neumotórax/mediastino/subcutáneo (capno-peritoneo): presión de meseta y EtCO2 vigilantes; el subcutáneo masivo retrasa la extubación. Trauma de inserción (vasos, vísceras, vejiga): el primer trocar es el momento más sangrante. Hipotermia por insuflación de gas seco: calentamiento y fluidos calientes.",
            "Ojos, cerebro y nervios" to "Trendelenburg + neumoperitoneo: ↑ presión intraocular y intracraneal (cuidado en glaucoma y neurocirugía), neuropatía óptica posterior isquémica (NION, rara pero ciega): evitar presiones >15 mmHg prolongadas, hipotensión y anemia combinadas; revisión de la presión ocular en cirugías >4 h con el paciente en Trendelenburg profundo. Nervios: braquial (abducción <90°), cúbito (protección), femoral/cutáneo lateral (retractores).",
            "Postoperatorio" to "Dolor de hombro por CO2 residual (irritación diafragmática): analgesia multimodal con paracetamol + dipirona/AINE + bloqueo de la vaina del recto o TAP en la laparoscopía abdominal; el CO2 residual se reabsorbe en horas. Náuseas: profilaxis doble (ondansetrón + dexametasona): la laparoscopía es de las cirugías más eméticas. Reclutamiento al final + aspiración de secreciones antes de extubar reduce las atelectasias.",
            "Calculadora" to "La calculadora de videocirugía de esta sección ajusta la FR según el EtCO2 medido/deseado (FR nueva = FR × EtCO2 medida/EtCO2 deseada) y alerta si la presión de insuflación supera 15 mmHg: dos números que evitan la hipercapnia y la sobrepresión."
        ),
        "lap"
    )
)

