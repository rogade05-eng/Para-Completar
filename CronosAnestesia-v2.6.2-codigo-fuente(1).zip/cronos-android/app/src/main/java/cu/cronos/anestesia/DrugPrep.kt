package cu.cronos.anestesia

// =====================================================================
//  PREPARACIÓN Y VÍAS DE ADMINISTRACIÓN DE LOS 45 FÁRMACOS (v2.0.0)
//  «El plus está en cómo se preparan los medicamentos, no solo las
//  dosis»: para cada fármaco aquí va la preparación típica (presentación,
//  dilución, concentración final y estabilidad) y los modos de
//  administración habituales (bolo, perfusión continua, jeringa perfusora,
//  IM, etc.). Complementa los perfiles calculables de DoseProfiles.kt.
//  Referencia educativa: verifique la presentación disponible en su
//  institución antes de preparar.
// =====================================================================

/** Modos de administración estandarizados (etiquetas de UI). */
object AdminModes {
    const val BOLO = "Bolo IV"
    const val PERFUSION = "Perfusión continua"
    const val JERINGA = "Jeringa perfusora"
    const val IM = "IM"
    const val SC = "Subcutánea"
    const val ORAL = "Oral"
    const val SL = "Sublingual"
    const val INHALADA = "Inhalada"
    const val NEURAXIAL = "Neuraxial"
    const val TOPICA = "Tópica"

    val ALL = listOf(BOLO, PERFUSION, JERINGA, IM, SC, ORAL, SL, INHALADA, NEURAXIAL, TOPICA)
}

/** Preparación típica + modos de administración de un fármaco. */
data class DrugPrep(
    val name: String,          // coincide con Drug.name / perfil de dosis
    val aliases: List<String>, // nombres alternativos para el buscador
    val prep: String,          // presentación, dilución y concentración final
    val stability: String,     // estabilidad de la dilución / conservación
    val modes: List<String>    // modos habituales de administración (AdminModes)
)

/** Normaliza texto para el buscador: minúsculas y sin acentos. */
fun normText(s: String): String = buildString {
    for (c in s.lowercase()) append(
        when (c) {
            'á' -> 'a'; 'é' -> 'e'; 'í' -> 'i'; 'ó' -> 'o'; 'ú' -> 'u'
            'ü' -> 'u'; 'ñ' -> 'n'
            else -> c
        }
    )
}

/** ¿Coincide la consulta con el nombre o alguno de los alias? */
fun prepMatches(p: DrugPrep, query: String): Boolean {
    val q = normText(query.trim())
    if (q.isEmpty()) return true
    if (normText(p.name).contains(q)) return true
    return p.aliases.any { normText(it).contains(q) }
}

/** Preparaciones de los 45 fármacos, en el mismo orden que DRUGS. */
val DRUG_PREPS: List<DrugPrep> = listOf(
    DrugPrep(
        "Propofol", listOf("propofol lipoidal", "diprivan"),
        "Emulsión lipídica blanca al 1 % (10 mg/mL) o 2 % (20 mg/mL). Inducción: inyectar la ampolla TAL CUAL por vena gruesa en 30–45 s. TIVA: diluir a 10 mg/mL (frasco 1 % sin diluir; el 2 % puede pasarse directo: la bomba dosifica mejor concentrada). NO mezclar en la misma jeringa con tiopental (precipita).",
        "Emulsión abierta: usar en 6 h (crecimiento bacteriano por el lípido); agitar antes de cargar; descartar si se separa en fases. Bomba: jeringa protegida de la luz no es imprescindible.",
        listOf(AdminModes.BOLO, AdminModes.JERINGA, AdminModes.PERFUSION)
    ),
    DrugPrep(
        "Etomidato", listOf("etomidato-lipuro", "hypnomidate"),
        "Ampolla 20 mg/10 mL (2 mg/mL) lista para inyectar: TAL CUAL, sin diluir, en 30–60 s por vena gruesa. Descartar el sobrante: el vial abierto no se conserva. Pre-sedación con midazolam 1–2 mg o fentanilo 50–100 µg reduce las mioclonías.",
        "El vial abierto no se conserva: preparar al momento. La presentación lipídica (Lipuro) irrita menos la vena.",
        listOf(AdminModes.BOLO)
    ),
    DrugPrep(
        "Tiopental", listOf("tiopental sódico", "pentotal", "thiopental"),
        "Frasco 0,5–1 g de polvo: reconstituir con SSN 0,9 % a 2,5 % (25 mg/mL: 1 g + 40 mL) para inducción. Solución MUY alcalina (pH 10–11): SOLO vena segura, nunca en la línea de droperidol/verapamilo; extravasación = necrosis (infiltrar con lidocaína y elevar el miembro). Status: 25 mg/mL también.",
        "Reconstituido: usar en 24 h a temperatura ambiente (sin conservantes); turbidez = descartar. Incompatible con la mayoría de los fármacos ácidos: línea exclusiva y lavar después.",
        listOf(AdminModes.BOLO, AdminModes.PERFUSION)
    ),
    DrugPrep(
        "Ketamina", listOf("ketamine", "ketalar"),
        "Ampolla 50 mg/mL (500 mg/10 mL): diluir la dosis a 10 mg/mL (1 mL + 9 mL SSN) para inyectar en ≥60 s; en shock titule desde 0,5 mg/kg con dilución a 1 mg/mL (1 mL + 49 mL SSN). Analgesia subanestésica: 10 mg/mL en bolos finos. IM profundo: 50 mg/mL tal cual.",
        "La dilución de trabajo se prepara al momento; el frasco multidosis cerrado se conserva refrigerado según el envase. Protector de la luz no necesario.",
        listOf(AdminModes.BOLO, AdminModes.JERINGA, AdminModes.IM, AdminModes.PERFUSION)
    ),
    DrugPrep(
        "Midazolam", listOf("midazolam", "dormicum"),
        "Ampolla 5 mg/5 mL (1 mg/mL): para sedación titulada diluir 1 mg + 9 mL SSN → 0,1 mg/mL (bolos de 0,5–1 mg = 5–10 mL); inducción: tal cual (1 mg/mL). VO pediátrica: jarabe o 1 mg/mL con jugo (sabor amargo).",
        "La dilución 0,1 mg/mL es estable 24 h refrigerada; el ampollario abierto se conserva según el envase (multidosis con conservante).",
        listOf(AdminModes.BOLO, AdminModes.PERFUSION, AdminModes.ORAL, AdminModes.IM)
    ),
    DrugPrep(
        "Diazepam", listOf("diazepam", "valium"),
        "Ampolla 10 mg/2 mL en propilenglicol: NO diluir en SSN (precipita con turbidez); inyectar tal cual a 2–5 mg/min por vena gruesa. Si diluir es imprescindible, solo en D5 % y usarla al momento. Lavar la línea después: precipita con otros fármacos.",
        "Ampolla abierta: usar de inmediato (el vehículo oleoso se degrada); la emulsión lipídica (Diazemuls) tolera mejor la vena.",
        listOf(AdminModes.BOLO)
    ),
    DrugPrep(
        "Dexmedetomidina", listOf("dexmedetomidine", "precedex"),
        "Frasco 200 µg/2 mL (100 µg/mL): diluir 200 µg + 48 mL SSN → 4 µg/mL en jeringa/bolsa de 50 mL (el estándar de UCI: 8 µg/mL con 2 frascos). Carga: pasar en ≥10 min. En TIVA adyuvante: 4 µg/mL en bomba.",
        "Dilución estable 24 h a temperatura ambiente; proteger de la luz no es imprescindible. No pasar con bolos rápidos: bradicardia.",
        listOf(AdminModes.JERINGA, AdminModes.PERFUSION)
    ),
    DrugPrep(
        "Fentanilo", listOf("fentanyl", "fentanest"),
        "Ampolla 50 µg/mL tal cual en jeringa de 1–2 mL (adulto 100–200 µg = 2–4 mL); para titulación fina diluir 1 mL (50 µg) + 9 mL SSN → 5 µg/mL. Infusión: 5–10 µg/mL (2–4 ampollas en 50 mL). Ventile tras cada bolus y tenga el ambú en la mesa.",
        "Dilución estable 24 h; ampollas abiertas se descartan. No guardar la jeringa preparada con etiqueta sin fecha.",
        listOf(AdminModes.BOLO, AdminModes.JERINGA, AdminModes.PERFUSION, AdminModes.NEURAXIAL)
    ),
    DrugPrep(
        "Remifentanilo", listOf("remifentanil", "ultiva"),
        "Frasco 1–2 mg de polvo: reconstituir SIEMPRE con SSN 0,9 % o D5 % a 50 µg/mL (1 mg + 20 mL); en bomba: 1 mg + 49 mL = 20 µg/mL (bomba µg/kg/min) o 2 mg + 48 mL = 40 µg/mL. JAMÁS bolos únicos grandes en mantenimiento (apnea + rigidez).",
        "Reconstituido: estable 24 h a temperatura ambiente; usar al momento por la potencia (error de 10× = parada). Vía exclusiva o línea dedicada de la bomba.",
        listOf(AdminModes.JERINGA, AdminModes.PERFUSION)
    ),
    DrugPrep(
        "Morfina", listOf("morphine", "sulfato de morfina"),
        "Ampolla 10 mg/mL: diluir 10 mg + 9 mL SSN → 1 mg/mL para titulación (bolos de 2–4 mg = 2–4 mL); analgesia postoperatoria también 0,5 mg/mL. Infusión: 50 mg en 50 mL SSN = 1 mg/mL (bomba mL/h). Epidural: preservado-free (sin metabisulfito).",
        "Dilución estable 24 h; ampolla abierta según envase. Con radioisótopos/dializadores: línea propia.",
        listOf(AdminModes.BOLO, AdminModes.JERINGA, AdminModes.PERFUSION, AdminModes.IM, AdminModes.NEURAXIAL)
    ),
    DrugPrep(
        "Petidina (Meperidina)", listOf("meperidina", "petidina", "pethidine", "demerol"),
        "Ampolla 50 mg/mL (100 mg/2 mL): diluir la dosis en 10 mL SSN e inyectar en 3–5 min. Serotonina alta con otros serotonérgicos; IMAO: prohibido. No usar en infusión prolongada (noremeperidina convulsivante).",
        "Dilución de trabajo al momento; no conservar. Contraindicada en IRC (acumulación del metabolito).",
        listOf(AdminModes.BOLO, AdminModes.IM)
    ),
    DrugPrep(
        "Tramadol", listOf("tramadol", "adolonta"),
        "Ampolla 50 mg/mL o 100 mg/2 mL: diluir la dosis en 10 mL SSN e inyectar en 3–5 min. Antiemético profiláctico obligatorio (NVPO ≈30 %); máximo 400–600 mg/día.",
        "Dilución al momento; el sobrante no se conserva. Con IMAO/SSRI: riesgo de síndrome serotoninérgico.",
        listOf(AdminModes.BOLO, AdminModes.IM, AdminModes.ORAL)
    ),
    DrugPrep(
        "Dipirona (Metamizol)", listOf("metamizol", "dipyrone", "novalgina", "analgin"),
        "Ampolla 2 g/5 mL: diluir en 20–40 mL SSN/D5 % y pasar en ≥15 min (≥1 mg/kg/min): la inyección rápida produce hipotensión severa por liberación de histamina. Máximo 5 g/día; preparar al momento y no conservar la dilución.",
        "La dilución pierde potencia con la luz: preparar y usar. Agranulocitosis con uso >7 días (comunicar si el paciente la usa crónicamente).",
        listOf(AdminModes.BOLO, AdminModes.ORAL)
    ),
    DrugPrep(
        "Paracetamol (Acetaminofén)", listOf("paracetamol", "acetaminofen", "acetaminophen"),
        "Frasco 10 mg/mL (1 g/100 mL) listo para perfusión: pasar en 15 min por línea propia. Adulto 1 g cada 6 h (máx. 3–4 g/día; hepático/alcoholista: 2 g). La presentación pediátrica 10 mg/mL en vial también es perfundible diluida.",
        "Frasco abierto: usar de una vez (sin conservantes). No mezclar con otros fármacos: la línea se llena solo de paracetamol.",
        listOf(AdminModes.PERFUSION, AdminModes.ORAL)
    ),
    DrugPrep(
        "Suxametonio (Succinilcolina)", listOf("succinilcolina", "suxamethonium", "succinylcholine", "anectine", "cloruro de suxametonio"),
        "Ampolla 100 mg/2 mL (50 mg/mL) TAL CUAL: 70 kg × 1,5 = 105 mg ≈ 2 mL. REFRIGERADA; descartar si se ve turbia o con cristales (degradación). En pediátrico diluir a 10 mg/mL (1 + 4 mL SSN) para dosificar fino: dosis mínima 20 mg. Nunca en la misma jeringa que tiopental: precipita al instante.",
        "Cadena de frío obligatoria (4–8 °C); a temperatura ambiente pierde potencia en semanas. La dilución pediátrica se usa al momento.",
        listOf(AdminModes.BOLO, AdminModes.PERFUSION)
    ),
    DrugPrep(
        "Rocuronio", listOf("rocuronium", "esmeron"),
        "Ampolla 10 mg/mL: RSI 1–1,2 mg/kg = 7–8,4 mL en adulto 70 kg (inyectar en 60 s; a 1,2 mg/kg crea condiciones de intubación a 60 s tipo suxametonio). Mantenimiento con bolos 0,15 mg/kg o infusión 8–12 µg/kg/min con TOF. Sugammadex de rescate disponible.",
        "Refrigerado o a <25 °C; ampolla abierta usar en la sesión. La dilución para infusión (2 mg/mL) es estable 24 h.",
        listOf(AdminModes.BOLO, AdminModes.PERFUSION)
    ),
    DrugPrep(
        "Vecuronio", listOf("vecuronium", "norcuron"),
        "Frasco 10 mg de polvo: reconstituir con 5–10 mL SSN → 1–2 mg/mL; intubación 0,1 mg/kg = 7 mL (1 mg/mL) en 90 s. Mantenimiento: bolos 0,02 mg/kg o infusión 1 µg/kg/min. Sin efecto cardiovascular: ideal en cardiópatas.",
        "Reconstituido: usar en 24 h (sin conservante); el polvo se conserva refrigerado. Estable en línea con opioides y halogenados.",
        listOf(AdminModes.BOLO, AdminModes.PERFUSION)
    ),
    DrugPrep(
        "Atracurio", listOf("atracurium", "tracrium"),
        "Ampolla 10 mg/mL: intubación 0,5–0,6 mg/kg = 3,5–4,2 mL en 70 kg; en 90 s. Mantenimiento: bolos 0,1 mg/kg o infusión 5–10 µg/kg/min (Hofmann: no necesita ajuste renal/hepático). Histamina a dosis >0,6 mg/kg: hipotensión.",
        "Refrigerado (4–8 °C): fuera de la nevera degrada en semanas; descartar si cambia de color. La dilución para infusión se usa al momento.",
        listOf(AdminModes.BOLO, AdminModes.PERFUSION)
    ),
    DrugPrep(
        "Cisatracurio", listOf("cisatracurium", "nimbex"),
        "Ampolla 2 mg/mL (o 10 mg/mL concentrada): intubación 0,15–0,2 mg/kg = 5–7 mL de la de 2 mg/kg en 70 kg; en 2–3 min. Mantenimiento: bolos 0,03 mg/kg o infusión 1–2 µg/kg/min. Sin liberación de histamina: el atracurio del cardiópata.",
        "Refrigerado; la presentación concentrada se diluye a 2 mg/mL (1 + 4 mL) para infusión. Descartar si hay cambio de color.",
        listOf(AdminModes.BOLO, AdminModes.PERFUSION)
    ),
    DrugPrep(
        "Sugammadex", listOf("sugammadex", "bridion"),
        "Frasco 100 mg/mL (o 10 mg/mL para dosificación fina): BLOQUEO MODERADO (TOF 2): 2 mg/kg; REVERSIÓN PROFUNDA (PTC 1–2): 4 mg/kg; rescate inmediato tras rocuronio RSI: 16 mg/kg. Inyectar tal cual en 10 s por vía rápida; el efecto (TOF ≥0,9) aparece en 2–5 min.",
        "Sin diluir; refrigerado o <25 °C. Con hormonas anticonceptivas: interacción puntual (no relevante en anestesia única).",
        listOf(AdminModes.BOLO)
    ),
    DrugPrep(
        "Neostigmina + Atropina (reversión)", listOf("neostigmina", "neostigmine", "prostigmin", "reversión"),
        "Ampolla de 0,5 mg/mL: 70 kg × 0,05 = 3,5 mg = 7 mL; diluir en 10 mL SSN y pasar en 60 s (máximo 5 mg). MEZCLAR SIEMPRE la atropina en la misma jeringa o inyectarla justo antes: nunca neostigmina sola (bradicardia vagal severa). Atropina 1 mg por cada 2–2,5 mg de neostigmina.",
        "Las diluciones de ambos se usan al momento; los ampollarios cerrados se conservan a <25 °C.",
        listOf(AdminModes.BOLO)
    ),
    DrugPrep(
        "Efedrina", listOf("ephedrine", "sulfato de efedrina"),
        "Ampolla 30 mg/mL: diluir 30 mg + 9 mL SSN → 3 mg/mL para bolos finos de 3–6 mg (1–2 mL); en obstetricia/hipotensión del raquídeo es el vasopresor clásico (bradicardia fetal). Titulación: repetir cada 5–10 min; taquifilaxia con dosis repetidas.",
        "La dilución de trabajo se prepara al momento; las ampollas cerradas duran años. Taquifilaxia con dosis repetidas (depleción de catecolaminas).",
        listOf(AdminModes.BOLO)
    ),
    DrugPrep(
        "Fenilefrina", listOf("phenylephrine", "neosinefrina"),
        "Ampolla 10 mg/mL: dilución de trabajo 100 µg/mL (1 mg + 9 mL SSN) para bolos finos de 50–100 µg (0,5–1 mL); en infusión: bolsa 10 mg/100 mL SSN → 100 µg/mL o jeringa 10 mg + 49 mL SSN → 200 µg/mL, titulada 0,25–1 µg/kg/min. Vasopresor α puro de la obstetricia y del cianótico.",
        "La dilución 100 µg/mL es estable 24 h; en infusiones proteger de la luz no imprescindible. Bolos finos en taquicardia refleja.",
        listOf(AdminModes.BOLO, AdminModes.JERINGA, AdminModes.PERFUSION)
    ),
    DrugPrep(
        "Adrenalina (Epinefrina)", listOf("epinefrina", "adrenaline", "epinephrine", "adrenalina clorhidrato"),
        "Ampolla 1 mg/mL (1:1000): para uso IV SIEMPRE diluir — anafilaxia IM: 0,5 mg tal cual IM (0,5 mL 1:1000); paro: 1 mg IV (diluir 1 mL + 9 mL SSN → 0,1 mg/mL, pasar en 1 min); infusión: 1 mg + 49 mL SSN → 20 µg/mL titulada 0,02–0,1 µg/kg/min. Broncoespasmo grave: nebulizada 2–5 mg en 5 mL.",
        "Proteger de la luz (degrada con UV); la dilución 20 µg/mL es estable 24 h. JAMÁS la ampolla 1:1000 directa IV sin diluir: hipertensión + isquemia.",
        listOf(AdminModes.BOLO, AdminModes.IM, AdminModes.JERINGA, AdminModes.PERFUSION, AdminModes.INHALADA)
    ),
    DrugPrep(
        "Labetalol", listOf("labetalol", "trandate"),
        "Ampolla 100 mg/20 mL (5 mg/mL): crisis hipertensiva 10–20 mg IV (2–4 mL) en 2 min, repetible cada 10 min (máx. 300 mg); infusión: 100 mg + 30 mL SSN → 2–3 mg/mL titulada 0,5–2 mg/min. Embarazo: primera línea IV.",
        "La dilución de infusión se usa en 24 h; ampolla abierta: sesión. Asma grave e insuficiencia cardíaca descompensada: contraindicado.",
        listOf(AdminModes.BOLO, AdminModes.JERINGA, AdminModes.ORAL)
    ),
    DrugPrep(
        "Amiodarona", listOf("amiodarone", "cordarone"),
        "Ampolla 150 mg/3 mL (50 mg/mL): carga 300 mg = 3 ampollas + 44 mL D5 % → 50 mL a 15 mg/min; o 150 mg + 100 mL D5 % en 1 h. NO diluir en SSN (precipita); línea exclusiva o lavar después. Infusión de mantenimiento: 900 mg/500 mL D5 % (1,8 mg/mL) 1 mg/min 6 h.",
        "La dilución en D5 % es estable 24 h protegida de la luz; el frasco de infusión debe prepararse al momento. Flebitis periférica: preferir vena central si >2 h.",
        listOf(AdminModes.BOLO, AdminModes.PERFUSION)
    ),
    DrugPrep(
        "Metoclopramida", listOf("metoclopramide", "primperan"),
        "Ampolla 10 mg/2 mL (5 mg/mL): 10 mg tal cual IV lento (2 min) o diluida en 10 mL SSN. NVPO profilaxis/rescate cada 8 h; máximo 30 mg/día (40 con extrapyramidal bajo riesgo). Retrasa el vaciamiento gástrico NO: lo ACELERA (procinético).",
        "Ampolla abierta: sesión. Dilución estable 24 h. Distrofias/niños: riesgo de distonía (vigilar reacción aguda).",
        listOf(AdminModes.BOLO, AdminModes.IM, AdminModes.ORAL)
    ),
    DrugPrep(
        "Ranitidina", listOf("ranitidine", "zantac"),
        "Ampolla 50 mg/2 mL (25 mg/mL): 50 mg IV diluido en 20 mL SSN en 2–3 min cada 8 h; preoperatorio 50 mg IV lento 45–60 min antes. Retirada de algunos mercados: alternativa disponible = omeprazol/pantoprazol IV.",
        "La dilución es estable 24 h; ampolla abierta: sesión. Incompatible con midazolam en la misma jeringa.",
        listOf(AdminModes.BOLO, AdminModes.PERFUSION, AdminModes.ORAL)
    ),
    DrugPrep(
        "Cimetidina", listOf("cimetidine", "tagamet"),
        "Ampolla 200 mg/2 mL (100 mg/mL): 200–300 mg IV diluido en 20 mL SSN en >5 min cada 6–8 h. Interacciones CYP450 (warfarina, benzodiazepinas, lidocaína): reducir dosis de los asociados. Menos usado que los IPP modernos.",
        "Dilución estable 24 h; ampolla abierta: sesión. Bradicardia con administración rápida.",
        listOf(AdminModes.BOLO, AdminModes.PERFUSION, AdminModes.ORAL)
    ),
    DrugPrep(
        "Difenhidramina (Benadrilina)", listOf("difenhidramina", "diphenhydramine", "benadryl"),
        "Ampolla 50 mg/mL: 25–50 mg IV lento (diluir en 10 mL SSN, pasar en ≥2 min) o IM profundo. Antihistamínico H1 de primera línea en reacciones alélicas leves y extrapiramidales (distonía por metoclopramida: 50 mg IV).",
        "Dilución al momento; ampolla abierta: sesión. Sedación marcada: el paciente no firma consentimientos después.",
        listOf(AdminModes.BOLO, AdminModes.IM)
    ),
    DrugPrep(
        "Hidrocortisona", listOf("hydrocortisone", "cortisol"),
        "Frasco 100 mg de polvo: reconstituir con 2 mL de SSN/D5 % (50 mg/mL) y pasar en 2–3 min; sepsis: 50 mg IV cada 6 h o 200 mg/día en infusión; estrés quirúrgico del crónico: 50–100 mg IV preoperatorio. Sustituto rápido del déficit suprarrenal.",
        "Reconstituido: usar en 24 h refrigerado; el polvo se conserva a <25 °C. Con heparina en la misma línea: precipita.",
        listOf(AdminModes.BOLO, AdminModes.PERFUSION)
    ),
    DrugPrep(
        "Naloxona", listOf("naloxone", "narcan"),
        "Ampolla 0,4 mg/mL: titulación IV 0,04–0,1 mg (0,1–0,25 mL diluidos en 10 mL SSN → 0,04 mg/mL) cada 2 min hasta respiración eficaz; reversión total: 0,4–2 mg. Duración 30–90 min: MENOR que la del opioide — infusión 2/3 de la dosis eficaz por hora o vigilancia prolongada.",
        "La dilución de titulación se usa al momento; ampollas cerradas duran años. Precipita abstinencia en el adicto: titule.",
        listOf(AdminModes.BOLO, AdminModes.IM)
    ),
    DrugPrep(
        "Flumazenil", listOf("flumazenil", "anexate"),
        "Ampolla 0,5 mg/5 mL (0,1 mg/mL): titulación IV 0,2 mg (2 mL) cada 60 s hasta despertar; máximo 3 mg. Reversión de benzodiazepinas; convulsiones o ansiolíticos crónicos: NO usar (precipita crisis). Duración 30–60 min: re-sedación posible.",
        "La ampolla lista para usar (0,1 mg/mL) no se diluye más; el sobrante no se conserva.",
        listOf(AdminModes.BOLO)
    ),
    DrugPrep(
        "Atropina", listOf("atropine", "sulfato de atropina"),
        "Ampolla 1 mg/mL: bradicardia 0,5–1 mg IV tal cual (máx. 3 mg); dilución fina 0,1 mg/mL (1 mL + 9 mL SSN) para pediátrico/dosis de 0,02 mg/kg. Antisialagogo premedicación: 0,4–0,6 mg IM/VO. Reversión: 1 mg por cada 2–2,5 mg de neostigmina.",
        "La dilución fina se usa al momento; ampollas cerradas duran años. Dosis <0,5 mg IV en el adulto produce bradicardia paradójica (vagal central).",
        listOf(AdminModes.BOLO, AdminModes.IM)
    ),
    DrugPrep(
        "Ondansetrón", listOf("ondansetron", "zofran"),
        "Ampolla 8 mg/4 mL (2 mg/mL): 4–8 mg IV diluido en 10 mL SSN, pasar en 2–5 min justo antes del final; NVPO profilaxis y rescate cada 8 h. Corrección QT: máximo 16 mg/día; prolongación QTc con dosis altas (evitar >32 mg/día).",
        "Dilución estable 24 h; ampolla abierta: sesión. Compatible con la mayoría de las líneas de anestesia.",
        listOf(AdminModes.BOLO, AdminModes.ORAL)
    ),
    DrugPrep(
        "Dexametasona", listOf("dexamethasone", "decadron"),
        "Ampolla 8 mg/2 mL (4 mg/mL): 4–16 mg/día IV (edema peritumoral: carga 8–10 mg; NVPO: 4–8 mg con el antibiótico; edema de vía aérea tras extubación difícil: 8 mg + 8 mg a las 4 h). Sin necesidad de diluir más: pasar en 1–2 min.",
        "Ampolla abierta: sesión; el ampollario multidosis cerrado se conserva según el envase. Estable con opioides y benzodiazepinas en la misma jeringa (sin precipitación conocida).",
        listOf(AdminModes.BOLO, AdminModes.IM, AdminModes.ORAL)
    ),
    DrugPrep(
        "Droperidol", listOf("droperidol", "dehydrobenzperidol"),
        "Ampolla 5 mg/2 mL (2,5 mg/mL): NVPO profilaxis 0,625–1,25 mg IV (0,25–0,5 mL diluidos en 10 mL SSN); agitación: 2,5–5 mg. QT prolongado: ECG si dosis >2,5 mg; evitación con arritmias basales.",
        "La dilución fina se usa al momento; ampolla abierta: sesión. Sedación prolongada en el anciano.",
        listOf(AdminModes.BOLO, AdminModes.IM)
    ),
    DrugPrep(
        "Heparina sódica no fraccionada", listOf("heparina", "heparin", "heparina sodica", "hbpm"),
        "Frasco 5000 U/mL (o 1000 U/mL): CEC: 300–400 U/kg IV directo (25,000 U clásico en adulto 70 kg); ACT cada 30 min. Profilaxis: 5000 U SC cada 8–12 h. Infusión: 25,000 U (5 mL del frasco 5000 U/mL) + 45 mL SSN → 500 U/mL en bolsa de 50 mL, titulada a TTPa 1,5–2,5×. Reversión: protamina 1–1,3 mg/100 U.",
        "Las diluciones 500 U/mL son estables 24 h; los frascos concentrados se conservan refrigerados o según el envase. NO mezclar con dopamina/lidocaína en la misma línea (inactivación).",
        listOf(AdminModes.BOLO, AdminModes.SC, AdminModes.PERFUSION)
    ),
    DrugPrep(
        "Protamina", listOf("protamine", "sulfato de protamina"),
        "Ampolla 10 mg/mL: dosis = 1–1,3 mg por cada 100 U de heparina activa (25,000 U heparina → 250–325 mg); inyectar SIEMPRE LENTO ≤10 mg/min (≤50 mg en 5 min): la inyección rápida produce hipotensión y colapso pulmonar. Tras descannular, NO antes.",
        "Ampolla abierta: sesión. Alérgicos (NPH, pescado, vasectomizados): riesgo de reacción — protocolo lento + esteroides previos.",
        listOf(AdminModes.BOLO)
    ),
    DrugPrep(
        "Noradrenalina (Norepinefrina)", listOf("norepinefrina", "norepinephrine", "levonor", "noradrenaline"),
        "Ampolla 2 mg/2 mL (1 mg/mL): infusión 4 mg en bolsa de 250 mL SSN/D5 % → 16 µg/mL (la del calculador) o 8 mg + 42 mL SSN → 160 µg/mL en perfusora. Titule a PAM objetivo, no a «números fijos».",
        "La dilución es estable 24 h protegida de la luz; las ampollas degradan con la luz: mantener en la caja hasta el uso. Extravasación: flebitis/isquemia distal (rescate: fentolamina 5–10 mg SC en el sitio).",
        listOf(AdminModes.JERINGA, AdminModes.PERFUSION)
    ),
    DrugPrep(
        "Dopamina", listOf("dopamine", "dopamin"),
        "Frasco 200 mg/5 mL (40 mg/mL) o ampolla 200 mg: infusión 400 mg + 500 mL SSN = 800 µg/mL titulada 2–20 µg/kg/min (adulto 70 kg: 10–105 mL/h); en bomba: 200 mg + 47 mL SSN → 4 mg/mL. Menos usada: arritmogénica; prefiera noradrenalina/dobutamina según el perfil.",
        "La dilución 800 µg/mL es estable 24 h; evitar la luz prolongada. NO con bicarbonato/alcalinos en la misma línea (inactivación).",
        listOf(AdminModes.PERFUSION)
    ),
    DrugPrep(
        "Dobutamina", listOf("dobutamine", "dobutrex"),
        "Frasco 250 mg/20 mL (12,5 mg/mL): infusión 250 mg + 230 mL SSN/D5 % → 500 mL a 500 µg/mL titulada 2–20 µg/kg/min (70 kg: 17–168 mL/h); en bomba: 250 mg + 47 mL SSN → 5 mg/mL. Inotrópico β1 de la IC descompensada y de la baja RVP.",
        "La dilución es estable 24 h; taquicardia y consumo de O2 con dosis altas. Compatible con SSN y D5 %; NO con alcalinos.",
        listOf(AdminModes.PERFUSION)
    ),
    DrugPrep(
        "Milrinona", listOf("milrinone", "primacor"),
        "Ampolla 10 mg/10 mL (1 mg/mL): carga 25–50 µg/kg en 10 min (opcional) + infusión 0,375–0,75 µg/kg/min: 10 mg + 40 mL SSN → 200 µg/mL (70 kg: 8–16 mL/h). Inodilatador (inotrópico + vasodilatador pulmonar) de la HTAP y del fallo derecho.",
        "La dilución 200 µg/mL es estable 24 h; hipotensión con la carga rápida: dar en ≥10 min. Ajuste renal (acumula: hipotensión prolongada).",
        listOf(AdminModes.JERINGA, AdminModes.PERFUSION)
    ),
    DrugPrep(
        "Vasopresina", listOf("vasopressin", "argipresina", "ADH"),
        "Ampolla 20 U/mL: shock vasopléjico refractario: infusión 20 U + 40 mL SSN → 0,4 U/mL titulada 0,01–0,04 U/min (70 kg: 1,5–6 mL/h); paro cardíaco: 40 U IV una vez (diluir 2 mL + 8 mL SSN = 4 U/mL, pasar en 1 min). Ahorra catecolaminas; NO titulable por clínica fina.",
        "La dilución es estable 24 h; ampolla abierta: sesión. Isquemia esplácnica/digital con dosis altas; cuidado en enfermedad coronaria.",
        listOf(AdminModes.PERFUSION, AdminModes.BOLO)
    ),
    DrugPrep(
        "Nitroglicerina (Trinitrato de glicerilo)", listOf("nitroglicerina", "nitroglycerin", "trinitato de glicerilo", "NTG", "tridil"),
        "Ampolla 5 mg/mL: infusión en bolsa 50 mg/250 mL SSN → 200 µg/mL titulada 5–200 µg/min (1,5–60 mL/h); en perfusora 25 mg + 47 mL SSN → 500 µg/mL (0,6–24 mL/h). Bolus espasmo coronario: 50–100 µg con dilución fina 100 µg/mL. Absorbido al PVC: usar tubos no-PVC si prolongada.",
        "La dilución es estable 48 h en vidrio/PVC no-absorbente; ampollas de vidrio sin abrir duran años. NO con inhibidores de PDE-5 (sildenafil <24 h): colapso refractario.",
        listOf(AdminModes.BOLO, AdminModes.SL, AdminModes.JERINGA, AdminModes.PERFUSION)
    )
)

/** Busca la preparación de un fármaco por su nombre exacto (o null). */
fun prepFor(name: String): DrugPrep? = DRUG_PREPS.firstOrNull { it.name == name }
