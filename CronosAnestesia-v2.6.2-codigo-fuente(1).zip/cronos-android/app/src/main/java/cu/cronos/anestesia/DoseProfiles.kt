package cu.cronos.anestesia

/*
 * ============================================================================
 *  DoseProfiles — perfiles de dosificación calculable por fármaco
 *  (petición del usuario: peso + edad → infusión, sedación, analgesia).
 *  Contenido clínico en español (igual que Data.kt/Data2.kt). Las diluciones
 *  se expresan en la base del régimen (mg/mL o U/mL); la nota indica la
 *  preparación habitual. Rangos de referencia estándar (titular siempre).
 * ============================================================================
 */

private fun dil(label: String, concPerMl: Double) = Dilution(label, concPerMl)

private fun prof(name: String, note: String, regimens: List<Regimen>) =
    DrugDoseProfile(name, note, regimens)

val DRUG_DOSE_PROFILES: Map<String, DrugDoseProfile> = listOf(

    // ---------------- INDUCTORES E HIPNÓTICOS ----------------

    prof(
        "Propofol",
        "Titule lento. En el anciano, ASA III–IV, hipovolemia o con opioides previos: reduzca 30–50 %.",
        listOf(
            Regimen("Inducción", false, DoseUnit.MG_KG, 1.5, 2.5,
                note = "Inyectar en 30–45 s hacia vena grande.",
                pedMin = 2.0, pedMax = 3.0, pedNote = "Niños sanos: 2–3 mg/kg."),
            Regimen("Sedación", true, DoseUnit.UG_KG_MIN, 25.0, 75.0,
                note = "Titular a Ramsey 3–4; en UCI prefiera el límite bajo.",
                dilutions = listOf(
                    dil("Frasco 1 % (10 mg/mL)", 10000.0),
                    dil("Frasco 2 % (20 mg/mL)", 20000.0)
                )),
            Regimen("TIVA mantenimiento", true, DoseUnit.MG_KG_H, 4.0, 8.0,
                note = "Con remifentanilo 0,05–0,2 µg/kg/min; use BIS/profundidad clínica.",
                dilutions = listOf(
                    dil("Frasco 1 % (10 mg/mL)", 10.0),
                    dil("Frasco 2 % (20 mg/mL)", 20.0)
                ))
        )
    ),
    prof(
        "Etomidato",
        "Estabilidad cardiovascular máxima: primera elección en el paciente inestable. Sin analgesia.",
        listOf(
            Regimen("Inducción", false, DoseUnit.MG_KG, 0.2, 0.3,
                note = "Inyectar en 30–60 s. Pre-sedación con midazolam/fentanilo 50–100 µg reduce mioclonías.",
                pedMin = 0.2, pedMax = 0.3)
        )
    ),
    prof(
        "Tiopental",
        "Solución muy alcalina: solo vena segura. Trigger de hipertermia maligna y contraindicado en porfiria.",
        listOf(
            Regimen("Inducción", false, DoseUnit.MG_KG, 3.0, 5.0,
                note = "Anciano/hipovolémico: 1–2 mg/kg titulado.",
                pedMin = 5.0, pedMax = 6.0, pedNote = "Niños: 5–6 mg/kg IV."),
            Regimen("Status epilepticus", false, DoseUnit.MG_KG, 3.0, 5.0,
                note = "Bolos titulados con vía aérea protegida; luego infusión 3–5 mg/kg/h (ver abajo)."),
            Regimen("Infusión anticonvulsivante", true, DoseUnit.MG_KG_H, 3.0, 5.0,
                note = "UCI con EEG: suprimir brotes. Monitorización hemodinámica estrecha.",
                dilutions = listOf(dil("Solución 2,5 % (25 mg/mL)", 25.0)))
        )
    ),
    prof(
        "Ketamina",
        "Única con analgesia + soporte hemodinámico. Premedique con midazolam/benzodiazepina y antisialagogo.",
        listOf(
            Regimen("Inducción IV", false, DoseUnit.MG_KG, 1.0, 2.0,
                note = "Inyectar en ≥60 s. Shock: titule desde 0,5 mg/kg.",
                pedMin = 1.0, pedMax = 2.0),
            Regimen("Inducción IM", false, DoseUnit.MG_KG, 4.0, 8.0,
                note = "Sin vía IV; aparición en 3–5 min.",
                pedMin = 4.0, pedMax = 8.0),
            Regimen("Analgesia subanestésica", false, DoseUnit.MG_KG, 0.1, 0.3,
                note = "Bolo lento; opioide-sparing en dolor agudo y hiperestesias."),
            Regimen("Infusión analgésica", true, DoseUnit.MG_KG_H, 0.1, 0.5,
                note = "Multimodal + sedación con benzodiazepina si procedimiento largo.",
                dilutions = listOf(
                    dil("100 mg/100 mL (1 mg/mL)", 1.0),
                    dil("Jeringa 200 mg/20 mL (10 mg/mL)", 10.0)
                ))
        )
    ),

    // ---------------- BENZODIACEPINAS Y ALFA-2 ----------------

    prof(
        "Midazolam",
        "Reduzca 50 % la dosis con opioides o en el anciano. Tenga flumazenil disponible.",
        listOf(
            Regimen("Sedación IV titulada", false, DoseUnit.MG_KG, 0.02, 0.05,
                note = "Bolos lentos cada 2 min hasta objetivo (Ramsey 3 / PASS).",
                pedMin = 0.02, pedMax = 0.05, cap = 5.0, pedCap = 2.0),
            Regimen("Inducción", false, DoseUnit.MG_KG, 0.1, 0.2,
                note = "Sinerjia con propofol: reduzca el propofol 30–50 %."),
            Regimen("Premedicación VO (niños)", false, DoseUnit.MG_KG, 0.5, 0.5,
                ageScope = AgeScope.PEDIATRIC,
                note = "20–30 min antes; vía oral con sospecha de vía aérea difícil: NO usar.",
                cap = 20.0),
            Regimen("Sedación UCI", true, DoseUnit.MG_KG_H, 0.02, 0.1,
                note = "Acumula en el anciano, obeso y hepático; evalúe despertar diario.",
                dilutions = listOf(
                    dil("5 mg/50 mL (0,1 mg/mL)", 0.1),
                    dil("Jeringa 5 mg/5 mL (1 mg/mL)", 1.0)
                ))
        )
    ),
    prof(
        "Diazepam",
        "Vida media 20–50 h con metabolito activo: sedación residual. No mezclar en jeringa.",
        listOf(
            Regimen("Sedación IV lenta", false, DoseUnit.MG, 2.0, 10.0,
                note = "2–5 mg/min; titule a efecto. Vía oleosa: preferir vena gruesa."),
            Regimen("Convulsiones", false, DoseUnit.MG, 5.0, 10.0,
                note = "Repetible cada 10–15 min; prepare vía aérea y benzodiazepina de infusión.")
        )
    ),
    prof(
        "Dexmedetomidina",
        "Sedación cooperativa sin depresión respiratoria. La carga SIEMPRE en ≥10 min.",
        listOf(
            Regimen("Carga (opcional)", false, DoseUnit.UG_KG, 0.5, 1.0,
                note = "En 10–15 min; omitir en hipovolemia, bloqueo AV o bradicardia.",
                cap = 1.0, pedCap = 0.5),
            Regimen("Sedación / adyuvante", true, DoseUnit.UG_KG_H, 0.2, 0.7,
                note = "Título a sedación cooperativa; opioide-sparing real.",
                dilutions = listOf(
                    dil("200 µg/50 mL (4 µg/mL)", 4.0),
                    dil("Jeringa 400 µg/50 mL (8 µg/mL)", 8.0)
                ))
        )
    ),

    // ---------------- OPIOIDES ----------------

    prof(
        "Fentanilo",
        "Ventile tras cada bolus. Contexto-sensible: acumula con infusiones prolongadas.",
        listOf(
            Regimen("Inducción", false, DoseUnit.UG_KG, 1.0, 3.0,
                note = "2–3 µg/kg atenúan la respuesta al laringoscopio (cardiópata).",
                pedMin = 1.0, pedMax = 3.0),
            Regimen("Bolus intraoperatorio", false, DoseUnit.UG_KG, 0.5, 1.0,
                note = "Titular a signos de nocicepción; >2 µg/kg rápido: rigidez torácica."),
            Regimen("Infusión analgésica", true, DoseUnit.UG_KG_H, 0.7, 2.0,
                note = "Planifique analgesia multimodal de rescate antes del cierre.",
                dilutions = listOf(
                    dil("1 mg/100 mL (10 µg/mL)", 10.0),
                    dil("Jeringa 1 mg/20 mL (50 µg/mL)", 50.0)
                ))
        )
    ),
    prof(
        "Remifentanilo",
        "Vida media contextual 3–5 min: NO deja analgesia posterior. Multimodal 20–30 min antes de suspender.",
        listOf(
            Regimen("TIVA (con propofol)", true, DoseUnit.UG_KG_MIN, 0.05, 0.25,
                note = "Inducción sin bolus: 0,5–1 µg/kg/min; anciano: reduzca 30–50 %.",
                pedMin = 0.05, pedMax = 0.25,
                dilutions = listOf(
                    dil("2 mg/50 mL (40 µg/mL)", 40.0),
                    dil("Jeringa 1 mg/20 mL (50 µg/mL)", 50.0)
                ))
        )
    ),
    prof(
        "Morfina",
        "Metabolito M6G acumula en la renal: prefiera fentanilo si eGFR < 30. Histamina: cuidado asmático.",
        listOf(
            Regimen("IV titulada", false, DoseUnit.MG_KG, 0.02, 0.05,
                note = "Pico analgésico IV a los 20–30 min; espere antes de repetir.",
                cap = 10.0, pedCap = 4.0),
            Regimen("Infusión analgésica", true, DoseUnit.MG_KG_H, 0.01, 0.03,
                note = "PCA o infusión lenta; vigilar sedación y FR cada hora.",
                dilutions = listOf(
                    dil("10 mg/10 mL (1 mg/mL)", 1.0),
                    dil("20 mg/100 mL (0,2 mg/mL)", 0.2)
                ))
        )
    ),
    prof(
        "Petidina (Meperidina)",
        "Normeperidina: NO más de 48–72 h y nunca en insuficiencia renal. IMAO: prohibido.",
        listOf(
            Regimen("IV titulada", false, DoseUnit.MG_KG, 0.5, 1.0,
                note = "Inyectar lento en 3–5 min.",
                cap = 100.0, pedCap = 50.0),
            Regimen("IM", false, DoseUnit.MG_KG, 1.0, 2.0,
                note = "Cada 4–6 h; absorción errática si hipoperfusión.",
                cap = 100.0),
            Regimen("Escalofríos postoperatorios", false, DoseUnit.MG_KG, 0.3, 0.5,
                note = "Dosis única IV lenta; vigilar sedación.",
                cap = 50.0)
        )
    ),
    prof(
        "Tramadol",
        "NVPO muy frecuentes: profilaxis antiemética. Menor depresión respiratoria que los agonistas puros.",
        listOf(
            Regimen("IV lenta", false, DoseUnit.MG_KG, 1.0, 2.0,
                note = "En 3–5 min, c/6–8 h. Máximo 400–600 mg/día (adulto).",
                cap = 100.0, pedCap = 75.0)
        )
    ),
    prof(
        "Dipirona (Metamizol)",
        "SIEMPRE lenta y diluida: hipotensión severa si rápida. Máximo 5 g/día.",
        listOf(
            Regimen("IV lenta", false, DoseUnit.MG_KG, 15.0, 25.0,
                note = "≥1 mg/kg/min (1 g en ≥4 min), c/6–8 h. Vigilar agranulocitosis si >7 días.",
                cap = 2000.0, pedCap = 1000.0)
        )
    ),
    prof(
        "Paracetamol (Acetaminofén)",
        "Pilar de la analgesia multimodal. Máximo 60–75 mg/kg/día y nunca >4 g/día (<50 kg: 3 g).",
        listOf(
            Regimen("IV c/6 h", false, DoseUnit.MG_KG, 15.0, 15.0,
                note = "Infundir en 15 min. Espaciado mínimo 4 h. Máximo 3 días IV.",
                cap = 1000.0, pedCap = 1000.0)
        )
    ),

    // ---------------- BLOQUEO NEUROMUSCULAR ----------------

    prof(
        "Suxametonio (Succinilcolina)",
        "TRIGGER de hipertermia maligna y contraindicado en hiperkalemia (quemados, aplastamiento, denervación).",
        listOf(
            Regimen("RSI / intubación IV", false, DoseUnit.MG_KG, 1.0, 1.5,
                note = "Aparición 45 s, duración 6–10 min. Máximo 150–200 mg en adulto.",
                cap = 200.0, pedMin = 1.5, pedMax = 2.0, pedCap = 150.0),
            Regimen("IM (niño, sin vía IV)", false, DoseUnit.MG_KG, 2.0, 4.0,
                ageScope = AgeScope.PEDIATRIC, note = "Aparición en 2–4 min.",
                cap = 150.0),
            Regimen("Infusión (fase I→II)", true, DoseUnit.MG_KG_MIN, 0.05, 0.1,
                note = "Bisbolos o TOF para titular; >2–3 mg/kg total: riesgo de fase II.",
                dilutions = listOf(dil("1 mg/mL (500 mg/500 mL)", 1.0)))
        )
    ),
    prof(
        "Rocuronio",
        "TOF SIEMPRE. Reversible con sugammadex (2–4 mg/kg; 16 mg/kg tras RSI con 1,2 mg/kg).",
        listOf(
            Regimen("Intubación", false, DoseUnit.MG_KG, 0.6, 0.6,
                note = "60–90 s. RSI: 1–1,2 mg/kg.",
                pedMin = 0.6, pedMax = 1.0),
            Regimen("Mantenimiento (bolo)", false, DoseUnit.MG_KG, 0.1, 0.2,
                note = "Al reaparecer T2; hepático/renal: prolongación."),
            Regimen("Infusión", true, DoseUnit.UG_KG_MIN, 8.0, 12.0,
                note = "Titular por TOF (1–2 PTC). Bomba de jeringa preferida.",
                dilutions = listOf(
                    dil("Jeringa 50 mg/50 mL (1 mg/mL)", 1000.0),
                    dil("250 mg/250 mL (1 mg/mL)", 1000.0)
                ))
        )
    ),
    prof(
        "Vecuronio",
        "Sin histamina (cardiópata, asmático). Acumula 3-OH en renal: TOF estricto.",
        listOf(
            Regimen("Intubación", false, DoseUnit.MG_KG, 0.08, 0.1,
                note = "90–120 s; duración 30–45 min.",
                pedMin = 0.08, pedMax = 0.1),
            Regimen("Mantenimiento (bolo)", false, DoseUnit.MG_KG, 0.02, 0.03,
                note = "Al reaparecer T2."),
            Regimen("Infusión", true, DoseUnit.UG_KG_MIN, 1.0, 2.0,
                note = "Bomba de jeringa; potencian magunesio, polimixinas e hipotermia.",
                dilutions = listOf(dil("Jeringa 20 mg/20 mL (1 mg/mL)", 1000.0)))
        )
    ),
    prof(
        "Atracurio",
        "Degradación de Hoffman: independiente de órganos (hepatorrenal, UCI). Histamina a dosis altas.",
        listOf(
            Regimen("Intubación", false, DoseUnit.MG_KG, 0.5, 0.5,
                note = "2,5–3 min; inyectar lento para evitar histamina.",
                pedMin = 0.5, pedMax = 0.6),
            Regimen("Mantenimiento (bolo)", false, DoseUnit.MG_KG, 0.1, 0.2,
                note = "Al reaparecer T2."),
            Regimen("Infusión", true, DoseUnit.UG_KG_MIN, 6.0, 10.0,
                note = "Conservar en refrigeración; laudanosina con dosis muy altas.",
                dilutions = listOf(
                    dil("500 mg/500 mL (1 mg/mL)", 1000.0),
                    dil("Frasco 10 mg/mL (jeringa)", 10000.0)
                ))
        )
    ),
    prof(
        "Cisatracurio",
        "4× más potente que atracurio, SIN histamina: cardíaca, hepatorrenal, asmático.",
        listOf(
            Regimen("Intubación", false, DoseUnit.MG_KG, 0.15, 0.2,
                note = "2–3 min; duración 45–60 min.",
                pedMin = 0.15, pedMax = 0.2),
            Regimen("Mantenimiento (bolo)", false, DoseUnit.MG_KG, 0.03, 0.03,
                note = "Al reaparecer T2."),
            Regimen("Infusión", true, DoseUnit.UG_KG_MIN, 1.0, 3.0,
                note = "Titular por TOF. Conservar en refrigeración.",
                dilutions = listOf(
                    dil("Frasco 2 mg/mL (jeringa)", 2000.0),
                    dil("10 mg/100 mL (0,1 mg/mL)", 100.0)
                ))
        )
    ),
    prof(
        "Sugammadex",
        "Solo revierte rocuronio/vecuronio. Ajuste en renal grave (no en diálisis).",
        listOf(
            Regimen("Reversión rutinaria (T2 visible)", false, DoseUnit.MG_KG, 2.0, 2.0,
                note = "Reversión en 3–5 min; vigilar recurrencia 30 min."),
            Regimen("Bloqueo profundo (1–2 PTC)", false, DoseUnit.MG_KG, 4.0, 4.0,
                note = "Rescate de bloqueo profundo; TOF ≥0,9 en 5–10 min."),
            Regimen("Reversión inmediata tras RSI (1,2 mg/kg)", false, DoseUnit.MG_KG, 16.0, 16.0,
                note = "Vía aérea difícil \"can't intubate\": reanimación completa en ~2 min.")
        )
    ),
    prof(
        "Neostigmina + Atropina (reversión)",
        "NUNCA con TOF <2 (reversión paradójica). Vigilar TOF ≥0,9 a los 10–15 min.",
        listOf(
            Regimen("Neostigmina", false, DoseUnit.MG_KG, 0.04, 0.06,
                note = "IV lenta en 60 s; máximo 5 mg.",
                cap = 5.0),
            Regimen("Atropina acompañante", false, DoseUnit.MG_KG, 0.015, 0.02,
                note = "Simultánea a la neostigmina (o glicopirrolato 0,005–0,01 mg/kg).",
                cap = 2.0)
        )
    ),

    // ---------------- VASOPRESORES E INOTRÓPICOS ----------------

    prof(
        "Efedrina",
        "Primer vasopresor histórico: ↑ FC y gasto. Taquifilaxia rápida por depleción de noradrenalina.",
        listOf(
            Regimen("Bolus IV", false, DoseUnit.MG, 5.0, 10.0,
                note = "Repetible cada 3–5 min. Obstetricia con bradicardia: elección clásica.",
                pedMin = 0.2, pedMax = 0.3, pedNote = "Pediátrico: 0,2–0,3 mg/kg IV."),
            Regimen("Infusión", true, DoseUnit.MG_MIN, 0.5, 2.0,
                note = "Titular a PA objetivo; consume O2 miocárdico.",
                dilutions = listOf(
                    dil("Ampolla 50 mg/10 mL (5 mg/mL)", 5.0),
                    dil("300 mg/500 mL (0,6 mg/mL)", 0.6)
                ))
        )
    ),
    prof(
        "Fenilefrina",
        "Vasopresor α1 puro: primera línea de la hipotensión espinal obstétrica y del HOCM.",
        listOf(
            Regimen("Bolus IV", false, DoseUnit.UG_KG, 0.5, 1.0,
                note = "50–100 µg en el adulto; repetible. Alternar con efedrina si la FC cae.",
                pedMin = 0.5, pedMax = 1.0, cap = 0.2, pedCap = 0.1),
            Regimen("Infusión", true, DoseUnit.UG_KG_MIN, 0.25, 3.0,
                note = "Titular a PA/FC. No mezclar con bicarbonato.",
                dilutions = listOf(
                    dil("10 mg/250 mL (40 µg/mL)", 40.0),
                    dil("Jeringa 10 mg/100 mL (100 µg/mL)", 100.0)
                ))
        )
    ),
    prof(
        "Adrenalina (Epinefrina)",
        "Las infusiones van SIEMPRE en bomba y con doble control de la dilución (1:1000 vs 1:10 000).",
        listOf(
            Regimen("Anafilaxia IM", false, DoseUnit.MG_KG, 0.01, 0.01,
                note = "Adulto 0,5 mg (0,5 mL 1:1000) cara anteroexterna del muslo; repetir cada 5 min.",
                cap = 0.5, pedCap = 0.3, pedNote = "Niño: 0,01 mg/kg IM (máx. 0,3 mg)."),
            Regimen("Paro cardíaco IV", false, DoseUnit.MG, 1.0, 1.0,
                note = "Adulto: 1 mg cada 3–5 min. Pediátrico 0,01 mg/kg (ver Emergencias → PALS)."),
            Regimen("Infusión (titulada)", true, DoseUnit.UG_KG_MIN, 0.05, 0.1,
                note = "Con vía IV y monitoría; shock/anafilaxia refractaria hasta 0,3–0,5.",
                pedMin = 0.05, pedMax = 0.3, pedNote = "Neonato: 0,01–0,03 µg/kg/min.",
                dilutions = listOf(
                    dil("1 mg/50 mL (20 µg/mL)", 20.0),
                    dil("1 mg/250 mL (4 µg/mL)", 4.0),
                    dil("Jeringa 1 mg/10 mL (100 µg/mL)", 100.0)
                ))
        )
    ),
    prof(
        "Noradrenalina (Norepinefrina)",
        "Vasopresor de primera línea en sepsis e hipotensión refractaria. Vía central recomendada >0,1 µg/kg/min; si va periférica: vena gruesa, valorarla cada 2–4 h. Diluir en D5 %.",
        listOf(
            Regimen("Bolus de rescate IV", false, DoseUnit.UG, 4.0, 8.0,
                note = "Diluidos a 16 µg/mL (0,25–0,5 mL); mientras se arma la infusión."),
            Regimen("Infusión vasopresora", true, DoseUnit.UG_KG_MIN, 0.02, 0.5,
                note = "Iniciar 0,05 µg/kg/min y titular a PA media ≥65 mmHg. Shock refractario: hasta 1.",
                pedMin = 0.01, pedMax = 0.3, pedNote = "Neonato/pediátrico: 0,01–0,3 µg/kg/min.",
                dilutions = listOf(
                    dil("4 mg/250 mL D5% (16 µg/mL)", 16.0),
                    dil("8 mg/250 mL D5% (32 µg/mL)", 32.0),
                    dil("Jeringa 4 mg/50 mL (80 µg/mL)", 80.0)
                ))
        )
    ),
    prof(
        "Dopamina",
        "Efecto dosis-dependiente: 2–5 µg/kg/min (histórico \"renal\"), 5–10 inotrópico β1, >10 α vasoconstrictor. Más arritmogénica que noradrenalina en el shock séptico.",
        listOf(
            Regimen("Infusión inotrópica/vasopresora", true, DoseUnit.UG_KG_MIN, 2.0, 20.0,
                note = "Titular a PA/UGC. Bradicardia sintomática refractaria: 5–20 µg/kg/min (alternativa ACLS).",
                pedMin = 2.0, pedMax = 20.0, pedNote = "Neonato: 2–20 µg/kg/min (dosis media 5–8).",
                dilutions = listOf(
                    dil("400 mg/250 mL (1600 µg/mL)", 1600.0),
                    dil("200 mg/250 mL (800 µg/mL)", 800.0),
                    dil("Jeringa 200 mg/50 mL (4000 µg/mL)", 4000.0)
                ))
        )
    ),
    prof(
        "Dobutamina",
        "Inotrópico β1 > β2: ↑ gasto con vasodilatación leve. Si baja la PA, combine con noradrenalina.",
        listOf(
            Regimen("Infusión inotrópica", true, DoseUnit.UG_KG_MIN, 2.0, 20.0,
                note = "Típico 5–10 µg/kg/min. Bajo gasto post-CEX, sepsis con disfunción miocárdica.",
                pedMin = 2.0, pedMax = 20.0, pedNote = "Lactantes: taquicardia frecuente; titular por perfusión.",
                dilutions = listOf(
                    dil("250 mg/250 mL (1000 µg/mL)", 1000.0),
                    dil("Jeringa 250 mg/50 mL (5000 µg/mL)", 5000.0)
                ))
        )
    ),
    prof(
        "Milrinona",
        "Inhibidor PDE-3: inodilatador (↑ inotropismo + vasodilatación + lusitropía). Ideal con hipertensión pulmonar y diástole rígida. Ajuste en renal.",
        listOf(
            Regimen("Carga (opcional)", false, DoseUnit.UG_KG, 25.0, 50.0,
                note = "En ≥10 min; omitir en hipovolemia o PA límite.",
                pedMin = 25.0, pedMax = 50.0),
            Regimen("Infusión", true, DoseUnit.UG_KG_MIN, 0.375, 0.75,
                note = "ClCr < 50: reducir ~50 % (acumula; hipotensión prolongada).",
                pedMin = 0.25, pedMax = 0.75, pedNote = "Pediátrico post-CEX: 0,25–0,75 µg/kg/min.",
                dilutions = listOf(
                    dil("20 mg/100 mL (200 µg/mL)", 200.0),
                    dil("10 mg/100 mL (100 µg/mL)", 100.0)
                ))
        )
    ),
    prof(
        "Vasopresina",
        "Dosis fija NO ponderal en el adulto: ahorra catecolaminas en el shock vasopléjico refractario. Vigilar isquemia esplácnica y digital.",
        listOf(
            Regimen("Infusión shock vasopléjico", true, DoseUnit.U_MIN, 0.01, 0.04,
                note = "Adulto: 0,01–0,04 U/min (iniciar 0,03; refractario hasta 0,06).",
                dilutions = listOf(
                    dil("20 U/50 mL (0,4 U/mL)", 0.4),
                    dil("Jeringa 20 U/20 mL (1 U/mL)", 1.0)
                )),
            Regimen("Paro cardíaco (coadyuvante)", false, DoseUnit.U, 40.0, 40.0,
                note = "1 dosis de 40 U IV puede sustituir el 1.º o 2.º mg de adrenalina."),
            Regimen("Infusión pediátrica", true, DoseUnit.U_KG_MIN, 0.0002, 0.002,
                ageScope = AgeScope.PEDIATRIC,
                note = "Catecolaminorresistencia en UCI pediátrica (cateterismos/shock).",
                dilutions = listOf(dil("20 U/50 mL (0,4 U/mL)", 0.4)))
        )
    ),
    prof(
        "Nitroglicerina (Trinitrato de glicerilo)",
        "Venodilatador donador de NO: ↓ preload y ↓ PAP. Contraindicada con PDE-5 recientes (sildenafil 24 h, tadalafil 48 h).",
        listOf(
            Regimen("Bolus (espasmo coronario)", false, DoseUnit.UG, 50.0, 100.0,
                note = "Espasmo intraoperatorio; también 0,4 mg SL."),
            Regimen("Infusión", true, DoseUnit.UG_KG_MIN, 0.5, 5.0,
                note = "Adulto fijo: 5–200 µg/min. Taquifilaxia 24–48 h; metahemoglobinemia >5 µg/kg/min.",
                pedMin = 0.5, pedMax = 5.0, pedNote = "Pediátrico (HTAP): 0,5–5 µg/kg/min.",
                dilutions = listOf(
                    dil("10 mg/100 mL (100 µg/mL)", 100.0),
                    dil("Jeringa 50 mg/50 mL (1000 µg/mL)", 1000.0)
                ))
        )
    ),

    // ---------------- ANTIHIPERTENSIVOS Y ANTIARRÍTMICOS ----------------

    prof(
        "Labetalol",
        "Bloqueo mixto α1+β: crisis hipertensivas y preeclampsia. Acumula: hipotensión prolongada.",
        listOf(
            Regimen("Bolus IV lento", false, DoseUnit.MG, 5.0, 20.0,
                note = "En 1–2 min, repetir cada 10 min; máximo 200–300 mg."),
            Regimen("Infusión", true, DoseUnit.MG_MIN, 0.5, 2.0,
                note = "Titular a PA; bradicardia y bloqueo AV: contraindicado.",
                dilutions = listOf(
                    dil("200 mg/200 mL (1 mg/mL)", 1.0),
                    dil("Jeringa 100 mg/20 mL (5 mg/mL)", 5.0)
                ))
        )
    ),
    prof(
        "Amiodarona",
        "Clase III: vigilar QT, K y Mg (torsades). Pediátrico: carga 5 mg/kg (máx. 300 mg).",
        listOf(
            Regimen("Taquiarritmia con pulso", false, DoseUnit.MG, 150.0, 150.0,
                note = "Infundir en 10 min (bomba); luego infusión de mantenimiento."),
            Regimen("Paro FV/TV sin pulso", false, DoseUnit.MG, 300.0, 300.0,
                note = "Tras el 3.º choque; repetir 150 mg si recurre."),
            Regimen("Infusión de mantenimiento", true, DoseUnit.MG_MIN, 0.5, 1.0,
                note = "1 mg/min × 6 h + 0,5 mg/min × 18 h; máximo 2,2 g/24 h. Vía central si es posible.",
                dilutions = listOf(
                    dil("450 mg/500 mL (0,9 mg/mL)", 0.9),
                    dil("450 mg/250 mL (1,8 mg/mL)", 1.8)
                ))
        )
    ),

    // ---------------- ANTIEMÉTICOS Y ANTIULCEROSOS ----------------

    prof(
        "Metoclopramida",
        "Mejor profiláctica que terapéutica. Extrapiramidales → difenhidramina 25 mg IV.",
        listOf(
            Regimen("IV lenta", false, DoseUnit.MG_KG, 0.1, 0.15,
                note = "En 2–3 min, c/8 h; máximo 30–45 mg/día y 5 días.",
                pedMin = 0.1, pedMax = 0.15, cap = 10.0, pedCap = 5.0)
        )
    ),
    prof(
        "Ranitidina",
        "Profilaxis de Mendelson: ↑ pH y ↓ volumen gástrico. En Cuba sigue en uso institucional (alternativa: famotidina 20 mg IV).",
        listOf(
            Regimen("IV c/8 h", false, DoseUnit.MG_KG, 1.0, 1.0,
                note = "VO: 150 mg la noche anterior y 2 h antes de la cirugía electiva.",
                cap = 50.0)
        )
    ),
    prof(
        "Cimetidina",
        "Potente inhibidor del CYP450: interacciones con diazepam, warfarina, lidocaína, teofilina.",
        listOf(
            Regimen("IV", false, DoseUnit.MG, 300.0, 300.0,
                note = "c/6–8 h, diluido en 20 mL y en 2 min. Pediátrico: 5–10 mg/kg/día dividido.")
        )
    ),
    prof(
        "Difenhidramina (Benadrilina)",
        "Coadyuvante tras adrenalina en reacciones alérgicas; antídoto de las extrapiramidales.",
        listOf(
            Regimen("IV lenta / IM", false, DoseUnit.MG_KG, 0.5, 1.25,
                note = "c/6 h; máximo 300 mg/día. Sedación marcada.",
                cap = 50.0, pedMin = 1.0, pedMax = 1.0, pedCap = 25.0)
        )
    ),
    prof(
        "Hidrocortisona",
        "No omitir en el paciente con esteroides crónicos (insuficiencia suprarrenal perioperatoria).",
        listOf(
            Regimen("Estrés / anafilaxia", false, DoseUnit.MG_KG, 1.0, 2.0,
                note = "100–200 mg IV en el adulto; fase tardía de la anafilaxia y choque refractario.",
                cap = 200.0),
            Regimen("Sustitución suprarrenal", false, DoseUnit.MG, 50.0, 100.0,
                note = "c/8 h el día de la cirugía y 24–72 h según el grado de estrés.")
        )
    ),

    // ---------------- ANTÍDOTOS ----------------

    prof(
        "Naloxona",
        "Vida media 30–45 min vs. opioides largos: RENARCOTIZACIÓN. Vigilar 2 h mínimo y titular, no bolus.",
        listOf(
            Regimen("IV titulada (adulto)", false, DoseUnit.UG, 40.0, 100.0,
                note = "Diluir 0,4 mg en 10 mL (40 µg/mL); repetir cada 2–3 min.",
                ageScope = AgeScope.ADULT),
            Regimen("Pediátrico", false, DoseUnit.UG_KG, 1.0, 5.0,
                note = "Titular a FR ≥10 y sedación leve.",
                ageScope = AgeScope.PEDIATRIC)
        )
    ),
    prof(
        "Flumazenil",
        "NO usar de rutina: convulsiones si dependencia a benzodiazepinas o ingestión mixta con tricíclicos.",
        listOf(
            Regimen("Adulto", false, DoseUnit.MG, 0.2, 0.2,
                note = "En 15 s; si no responde, 0,1 mg/min hasta 1 mg. Vigilar re-sedación 2 h.",
                ageScope = AgeScope.ADULT),
            Regimen("Pediátrico", false, DoseUnit.MG_KG, 0.01, 0.01,
                note = "Máximo 0,2 mg.",
                ageScope = AgeScope.PEDIATRIC, cap = 0.2)
        )
    ),
    prof(
        "Atropina",
        "Pediátrico: dosis MÍNIMA 0,1 mg (evita bradicardia paradójica). Ineficaz en corazón denervado.",
        listOf(
            Regimen("Bradicardia sintomática", false, DoseUnit.MG, 0.5, 1.0,
                note = "Repetible cada 3–5 min hasta 3 mg (adulto).",
                pedMin = 0.01, pedMax = 0.02, pedCap = 1.0,
                pedNote = "Pediátrico: 0,01–0,02 mg/kg (mínimo 0,1 mg)."),
            Regimen("Antisialagogo (premedicación)", false, DoseUnit.MG_KG, 0.005, 0.005,
                note = "IM/SC 30–60 min antes; alternativa: glicopirrolato 0,005 mg/kg.",
                cap = 1.0)
        )
    ),

    // ---------------- HEMOSTASIA ----------------

    prof(
        "Heparina sódica no fraccionada",
        "Monitorear ACT/TTPa. HIT: contar plaquetas. Reversión: protamina 1 mg por cada 100 U.",
        listOf(
            Regimen("Pre-CEX", false, DoseUnit.U_KG, 300.0, 400.0,
                note = "ACT >480 s antes de canular; re-bolos según ACT durante el circuito."),
            Regimen("Cirugía vascular", false, DoseUnit.U_KG, 50.0, 100.0,
                note = "ACT objetivo 250–350 s según procedimiento."),
            Regimen("Profilaxis SC", false, DoseUnit.U, 5000.0, 5000.0,
                note = "c/8–12 h SC. En obesidad usar peso ajustado.")
        )
    ),
    prof(
        "Protamina",
        "Cálculo NO ponderal: 1 mg por cada 100 U de heparina activa. SIEMPRE en ≥10 min: colapso con la inyección rápida.",
        listOf(
            Regimen("Reversión de heparina", false, DoseUnit.MG, 25.0, 50.0,
                note = "Según heparina residual (100 % si <30 min; 50 % a 2 h; 25 % a >8 h). Máximo 50 mg por vía periférica. Reacción anafiláctica: diabéticos en NPH, alergia al pescado, vasectomía.")
        )
    ),

    // ---------------- ANTIEMÉTICOS RESTANTES ----------------

    prof(
        "Ondansetrón",
        "Inyectar en 2–5 min (prolonga QT). Si falló como profilaxis, cambiar de clase para el rescate.",
        listOf(
            Regimen("Profilaxis / rescate", false, DoseUnit.MG_KG, 0.1, 0.1,
                note = "4–8 mg en el adulto al final de la cirugía o 30 min antes; máximo 16 mg/día. Pediátrico >1 mes: 0,1 mg/kg.",
                cap = 8.0)
        )
    ),
    prof(
        "Dexametasona",
        "Hiperglucemia transitoria: vigilar diabéticos 4–6 h. AntiNVPO potente con sinergia 5-HT3.",
        listOf(
            Regimen("AntiNVPO", false, DoseUnit.MG_KG, 0.1, 0.15,
                note = "4–8 mg IV al inicio de la inducción.",
                cap = 8.0),
            Regimen("Edema / antiinflamatorio", false, DoseUnit.MG_KG, 0.1, 0.15,
                note = "4–10 mg IV c/6–8 h; coadyuvante de bloqueos periféricos 4–8 mg.",
                cap = 10.0)
        )
    ),
    prof(
        "Droperidol",
        "Rescate NVPO refractario a 5-HT3. ECG si factores de riesgo QT; acatisia → difenhidramina.",
        listOf(
            Regimen("Rescate NVPO", false, DoseUnit.MG, 0.625, 1.25,
                note = "Al final de la cirugía; dosis mínima eficaz. Neuroleptoanalgesia histórica: 2,5–5 mg con fentanilo.")
        )
    )
).associateBy { it.name }
