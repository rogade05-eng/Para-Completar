# CHANGELOG — Cronos Anestesia v2.6.2 (versionCode 28)

**Fecha:** octubre 2026 · **RoGaDe Software** · APK offline, sin permiso INTERNET.

## Titular
Créditos de desarrollo ampliados: la aplicación acredita ahora a su equipo
completo — **Ronald García Deroncele · Dr. Romay Díaz Deroncele** — en la
portada y en Ajustes, en los tres idiomas. Además, la documentación técnica
incorpora la **declaración oficial de herramientas de desarrollo** (lenguaje,
IDE, compilación, SDK y asistencia de IA), lista para cualquier formulario de
registro de software o requerimiento institucional de transparencia.

## Novedades (v2.6.2)
- **Equipo de desarrollo acreditado en pantalla:** la portada (splash) y la
  sección «Acerca de» de Ajustes muestran «Desarrollado por Ronald García
  Deroncele · Dr. Romay Díaz Deroncele» en Español, English («Developed by…»)
  y Português do Brasil («Desenvolvido por…»). Los nombres propios no se
  traducen; solo cambia el verbo del idioma activo.
- **Constante de equipo `DEVELOPER_CREDITS`:** único punto del código con los
  dos nombres, separador neutro «·», documentada para futuras pantallas o
  informes exportados. El contacto de WhatsApp y la emisión de licencias
  siguen canalizados por Ronald García Deroncele (sin cambios funcionales).
- **Declaración de herramientas de desarrollo (ADENDA_TECNICA.md §5):**
  Kotlin · Android Studio · Gradle 8.14.2 + AGP 8.5.2 · Android SDK 34 (build-tools
  34.0.0) · OpenJDK 17 · Jetpack Compose + Room/SQLCipher · Git · asistencia
  de IA generativa (Z.ai GLM). Tabla lista para copiar en registros de
  software, formularios académicos o declaraciones de transparencia.

## Sin cambios funcionales
- Ningún contenido clínico, calculadora, licencia ni flujo se modifica en
  esta versión: es una release de créditos y documentación.
- La actualización sobre la v2.6.1 es directa (mismo certificado de firma) y
  no altera datos locales, idioma preferido ni estado de licencia.

## Correcciones
- Ninguna pendiente: hereda intactas todas las correcciones de v2.6.1
  (reevaluación de idioma en caliente, «Progreso: X de Y», detección de EVA
  por bandera de deslizador).

## Técnico
- versionCode 28 · versionName 2.6.2 · minSdk 24 (Android 7.0) · targetSdk 34.
- Sin permiso INTERNET: único permiso DYNAMIC_RECEIVER_NOT_EXPORTED.
- Locales empaquetadas: en, es, pt.
- Certificado de firma idéntico (SHA-256 628592a3…35ba8): actualización
  directa sobre cualquier versión anterior sin desinstalar.
- Suite de pruebas: 172 tests en verde (7 nuevos de v2.6.2: paridad de
  créditos en los tres idiomas, separador, contacto intacto, versión).
- SBOM CycloneDX actualizado (root @2.6.2, autores RoGaDe Software).
