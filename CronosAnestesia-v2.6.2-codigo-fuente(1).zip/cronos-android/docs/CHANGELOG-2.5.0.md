# CHANGELOG — Cronos Anestesia v2.5.0 (versionCode 25)

Fecha: 26 de octubre de 2026 · Desarrollador: Ronald García Deroncele · WhatsApp +53 55301268

Nota de reconstrucción: el entorno de trabajo sufrió un reset que revirtió el código a v2.2.0.
La v2.5.0 se reconstruyó sobre esa base con el mismo certificado de firma (SHA-256
628592a3…35ba8) y versionCode 25, por lo que **actualiza directamente** sobre cualquier
versión anterior instalada (incluida 2.4.x) sin desinstalar.

## 1. Cálculos ventilatorios (nueva calculadora n.º 12 «Ventilación»)
- **Volumen corriente protector (ARDSnet)**: peso corporal predicho (PBW) por talla y sexo;
  VT diana 6 mL/kg con rango protector 4–8 mL/kg; aviso si el VT programado queda fuera del rango.
- **Ventilación minuto**: VE = VT × FR (mL/min y L/min).
- **Espacio muerto (ecuación de Bohr)**: VD/VT = (PaCO2 − ETCO2)/PaCO2 y **ventilación alveolar**
  VA = (VT − VD) × FR, con aviso si VD/VT > 50 %.
- **Compliance respiratoria**: estática VT/(Pmeseta − PEEP) y dinámica VT/(Ppico − PEEP),
  con clasificación (normal 50–100 mL/cmH2O; severamente reducida <30) y Δ resistiva
  (pico − meseta) con nota si ≥ 6 cmH2O.
- **Índice P/A (PaO2/PAO2)** con interpretación por bandas y **índice de oxigenación OI**
  = PAM × FiO2 × 100/PaO2 con clasificación (normal <4 … extrema ≥24, valorar ECMO).
- Motor puro en CalcEngine (sección 12) con vectores dorados probados.

## 2. Escala EVA de dolor posoperatorio con deslizador
- La EVA —Escala Visual Analógica (0–10)— ahora se responde con un **slider continuo 0–10**
  (el estándar mundial de evaluación del dolor posoperatorio): al soltar muestra la cifra,
  el descriptor («Sin dolor» … «El peor dolor imaginable»), la banda de intensidad
  (leve 1–3 / moderado 4–6 / severo 7–9 / muy severo 10) y la acción analgésica recomendada.
- Conserva los 11 descriptores equivalentes (escala numérica verbal) por compatibilidad.

## 3. Atribución de cálculos y estudios a un paciente determinado
- Nuevo botón «Guardar en expediente» con **selector de paciente destino** en:
  las 12 calculadoras (incluidas ayuno, hidratación, dosis/peso, infusión, peso ideal,
  tubo pediátrico, sangrado, gasometría, anestésico local y ventilación), las 12 calculadoras
  de temas clínicos (CPP, ANH, MELD-Na, MgSO4, Qp/Qs, fisiología resp./cardio, CEC, trauma,
  OLV, laparoscopia) y **las 16 escalas** (cada resultado queda atribuido).
- Si no existe ningún paciente, se crea uno automáticamente (mismo comportamiento de antes);
  si existen varios, se elige el destino sin cambiar el paciente activo.

## 4. Estadísticas e investigación sobre todos los casos registrados
- **Filtro por periodo**: 7 días · 30 días · 90 días · 1 año · todo el histórico;
  recalcula resumen, secciones más registradas, series y tabla de casos.
- **Gráficos** (dibujados por la app, sin librerías externas):
  - Barras de **registros en el tiempo** (diaria para 7/30 días, mensual para 90 días/1 año/todo)
    con **línea de tendencia** y lectura textual («en ascenso +N %», «en descenso −N %», «estable»).
  - Barras de **distribución por clase ASA** (I–VI + sin dato) de todos los pacientes.
  - Barras horizontales de **secciones (cálculos) más registradas**.
- **Tablas**: distribución por sexo y grupos de edad, y **casos registrados**
  (paciente · ASA · registros del periodo · edad · sexo).
- El análisis por ASA se alimenta del nuevo **campo ASA de la ficha del paciente**
  (clase I–VI + sufijo E de emergencia); el consentimiento informado usa ese ASA por defecto.

## 5. Presentación farmacéutica de los 45 fármacos
- Nueva ficha «Presentación farmacéutica» en el calculador «Infusión por fármaco»:
  forma, concentraciones y envases habituales de los 45 fármacos (ampollas, viales, liofilizados,
  frascos IV, parches, formas orales).
- El **buscador** ahora cumple lo que promete la cabecera: filtra por nombre, alias, clase,
  **indicación** (bug corregido) y **presentación**.

## 6. Consentimiento informado en Word
- Además del PDF, el consentimiento informado se exporta en **Word real (.docx)**,
  con el mismo contenido legal (9 secciones y las listas de riesgos por técnica),
  listo para editar o imprimir en la institución.

## 7. Enlaces externos (sin permiso INTERNET)
- **Medik Brain con doble enlace**: botones «Ver canal en YouTube (@MedikBrain)» y
  «Ver página en Facebook (MedikBrain)» en cada perla clínica.
- **Video de presentación** de la app (Facebook) en Ajustes → Ayuda.
- Todos los enlaces se abren delegando en una aplicación externa (ACTION_VIEW); si el
  dispositivo no tiene ninguna app capaz de abrirlos, se ignora en silencio.

## Pruebas y calidad
- 133 pruebas unitarias en verde (118 de v2.2.0 + 15 nuevas de v2.5.0: fórmulas ventilatorias,
  slider EVA, normalización y distribución ASA, filtro por periodo, series/tendencia,
  45 presentaciones, bloqueo de enlaces por contrato, docx del consentimiento con ASA).
- Cero permisos peligrosos: solo `DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION` (sin INTERNET).
- SBOM CycloneDX regenerado con root @2.5.0 · SHA256SUMS regenerado.
