# Cronos Anestesia v2.4.0 (versionCode 24) — 31 de octubre de 2026

## Conocimiento e imágenes (contrato §5.2 · v2.4.0)
Entrega anticipada: fecha contractual 31/01/2027.

### 1. Cálculos ventilatorios (Calculadoras 12 y 13)

- **Ventilación: Vt y VM** — volumen corriente sobre el **peso predicho**
  (PBW, Devine ajustado por sexo), con rango de seguridad 4–8 mL/kg,
  ventilación minuto, frecuencia necesaria para una VM objetivo, espacio
  muerto estimado (2,2 mL/kg PBW), ventilación alveolar y regla de
  corrección de la PaCO2 (VM × factor ⇒ PaCO2 ÷ factor). **La altura se
  autocompleta desde el paciente activo del expediente** (pacientes con
  autocompletado).
- **Ventilación mecánica** — a partir del monitor y la gasometría:
  distensibilidad estática (con zona), presión motriz (meta < 15 cmH2O),
  resistencia de la vía aérea, RSBI (< 105 favorable para extubar),
  espacio muerto de Bohr (Vd/Vt), relación P/F con categoría orientativa
  de Berlín e índice de oxigenación de Horowitz.
- Motor puro `Vent` (sin Android) con vectores dorados: PBW, Vt, VM, FR,
  Vd, VA, Cst, ΔP, Raw, τ = R×C, RSBI, ecuación alveolar, gradiente A-a
  esperado por edad, P/F, OI, Bohr, CaO2 y DO2.

### 2. Bloqueos neuroaxiales ampliados (Clínica → Bloqueos, 16 → 21 técnicas)

5 temas nuevos con esquemas vectoriales integrados:

- **Anestesia raquídea (espinal)** — anatomía de la vía media, técnica
  (punta lápiz, LOR, ángulos), dosis de referencia por fármaco
  (bupivacaína hiperbárica 12–15 mg, levobupivacaína, ropivacaína,
  mepivacaína; adyuvantes), niveles esperables, hipotensión/bradicardia
  (Bezold-Jarisch) y complicaciones (PDPH, hematoma/ASRA, espinal total).
- **Epidural lumbar y torácica** — espacio, pérdida de resistencia con
  salino, catéter, dosis de prueba, dosis por indicación (quirúrgica,
  torácica, obstétrica), fallos y retiro con ventanas ASRA.
- **Combinada espinal-epidural (CSE)** — técnica aguja-por-aguja, dosis
  obstétrica, ventajas, riesgos propios y manejo del fallo.
- **Bloqueo caudal** — anatomía del hiato, técnica pediátrica/adulta
  (Armitaje orientativo, máximo por peso), ventajas y errores frecuentes.
- **Anatomía neuroaxial aplicada** — niveles (Tuffier, escápula, xifoides),
  ligamentos, dermatomas de memoria (C4/T4/T6/T8/T10/L1/S2-S4), Bromage,
  Adamkiewicz y resumen ASRA.

### 3. Presentación de fármacos (pestaña Fármacos, selector Fichas / Presentaciones)

- Catálogo estructurado de **41 presentaciones** enlazadas a los fármacos
  del catálogo: envases y concentraciones habituales, ejemplo práctico de
  extracción (dosis → mL) y notas de conservación/riesgo (cadena de frío
  de la succinilcolina, luz en catecolaminas, estabilidad del propofol,
  precipitación de la amiodarona en salino, adsorción de la NTG al PVC…).
- **Conversor mg → mL** integrado en cada presentación, con advertencia de
  verificar el vial real y etiquetar la jeringa.
- Ayudantes puros `volumeForMg` / `volumeForUg` con pruebas.

### 4. Fisiología aplicada (Clínica → Fisiología, categoría nueva)

8 temas de síntesis fisiológica orientados a la práctica anestésica:

1. Mecánica respiratoria aplicada (con calculadora de mecánica y esquema
   presión-volumen).
2. Intercambio gaseoso (con esquema alveolo-capilar).
3. Transporte de O2 y CO2 (CaO2, DO2, curva de disociación, Haldane).
4. Control de la ventilación (quimiorreceptores, CO2, opioides, reflejos).
5. Circulación y retorno venoso (Starling, Fick, autoregulación, posiciones).
6. Balance hídrico y electrolitos (tonicidad, hipoNat, K/Mg/Ca, cristaloides
   balanceados vs. salino).
7. Regulación de la temperatura (tres caídas, consecuencias, manejo,
   diferencial de hipertermias).
8. Dolor: bases fisiológicas (transducción, puerta, sensibilización,
   multimodal, dolor no verbalizable).

### 5. Temario R1–R4 (pestaña nueva, con progreso)

Plan de estudio **orientativo** de la residencia en 4 cursos (R1 fundamentos
y seguridad; R2 consolidación con regional inicial, obstetricia y pediatría;
R3 alta complejidad — cardíaca, torácica, neuro, intensivos, dolor, docencia;
R4 jefatura, gestión, emergencias masivas, trasplantes y examen estatal),
en **23 áreas y 135 temas** marcables. Progreso por curso/área
guardado solo en el teléfono (SharedPreferences); botón «Limpiar curso».
Incluye aviso explícito de que no sustituye el programa oficial.

### 6. Imágenes (pestaña nueva + integradas en los temas)

5 esquemas **vectoriales** dibujados por la aplicación (Compose Canvas,
sin PNG, nítidos a cualquier tamaño):

- **Columna lumbar sagital** (punción raquídea: piel, ligamentos, cono
  medular L1, aguja 15° cefalada, L3-L4).
- **Espacio epidural** (ligamento amarillo, LOR con salino, venas, dura,
  catéter 4–5 cm).
- **Dermatomas** (bandas C4→S2-S4 con niveles quirúrgicos de referencia).
- **Intercambio alveolo-capilar** (gradientes, membrana, shunt vs V/Q).
- **Curva presión-volumen** (histéresis, PII/PIS, zona de trabajo protectora).

Cada esquema vive además dentro de su tema clínico (ClinTopic.artId) con
leyenda; la pestaña Imágenes ofrece la galería y el detalle ampliado.

### 7. Pacientes con autocompletado

- **Consentimiento**: selector «Paciente (autocompletado del expediente)»
  que abre la lista de pacientes guardados y rellena nombre, CI, edad,
  sexo, peso y altura en el documento (las 4 plantillas).
- **Calculadoras de ventilación**: altura autocompletada del paciente activo.
- Los datos nunca salen del dispositivo (contrato §11.2).

### 8. Documentación y recursos

- Manual embebido: navegación (18 pestañas), calculadoras (13), Clínica
  (7 apartados), y 4 secciones nuevas (Presentaciones, Temario, Imágenes,
  Pacientes con autocompletado).
- Deep links nuevos: `cronos://temario` (16) y `cronos://imagenes` (17).
- Ajustes: contador actualizado (65 temas clínicos, 21 bloqueos,
  13 calculadoras, presentaciones, temario, esquemas).

### Verificación

- **153/153 pruebas unitarias en verde** (131 previas + 22 nuevas de v2.4.0).
- Certificado SHA-256 `628592a3…35ba8` idéntico → instalación directa sobre
  v2.3.0/v2.2.x sin desinstalar (contrato §3.5).
- Sin permiso INTERNET (solo `DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION`),
  minSdk 24, targetSdk 34, ABIs arm64-v8a + armeabi-v7a, zipalign OK.
- Tamaño: 11,8 MB (11.775.064 B).
