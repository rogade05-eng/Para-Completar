# CHANGELOG — Cronos Anestesia v2.6.1 (versionCode 27)

**Fecha:** octubre 2026 · **RoGaDe Software** · APK offline, sin permiso INTERNET.

## Titular
Traducción profunda del contenido clínico completo: las ~38.000 palabras de
contenido médico (45 fármacos, 51 temas clínicos, 16 escalas, 6 protocolos de
emergencia, 14 complicaciones, premedicación, 8 soluciones, perlas, máquina de
anestesia, presentaciones, preparación y perfiles de dosificación) ya están
disponibles en **Español, English y Português (Brasil)**. Con esto, el 100 %
de la aplicación —interfaz, informes, consentimiento, ayuda y contenido
clínico— funciona en los tres idiomas.

## Novedades (v2.6.1)
- **Contenido clínico trilingüe (ola profunda):** 1.905 literales únicos
  traducidos al inglés y al portugués de Brasil, con conservación exacta de
  cifras, dosis, unidades y concentraciones (validación automática de
  paridad numérica cadena por cadena).
  - 45 fármacos: clase, dosis, indicaciones, precauciones.
  - 51 temas clínicos: 8 comorbilidades, 16 bloqueos regionales, 7 de
    monitorización, plan preoperatorio, equipamiento y 14 temas quirúrgicos.
  - 16 escalas interactivas: nombre, descripción, opciones, interpretación.
  - 6 protocolos de emergencia: reconocimiento, pasos, dosis y referencias.
  - 14 complicaciones, 14 temas de premedicación, 8 soluciones parenterales.
  - Perlas clínicas (título original del video preservado) y máquina de
    anestesia (partes, materiales, verificación).
  - Preparación y administración de 45 fármacos, presentaciones comerciales
    y perfiles de dosificación calculable (regímenes, notas y diluciones).
- **Cambio de idioma instantáneo y estable:** el contenido clínico se
  reevalúa en el idioma activo en cada lectura; ya no depende del momento
  del primer acceso (se corrigió el congelamiento de checklist, manual e
  introducción del manual heredado de la v2.6.0).
- **Estabilidad de claves:** los nombres genéricos (INN) de fármacos, claves
  de mapas, calcId y alias comerciales no se traducen: el buscador, las
  fichas de preparación y las calculadoras siguen localizando cada fármaco
  en cualquier idioma.
- **Detección de EVA por bandera:** la escala EVA se identifica por su
  deslizador (sliderMax > 0) y no por el texto del nombre, que ahora se
  traduce (VAS — Visual Analogue Scale / EVA — Escala Visual Analógica).
- Unas 65 cadenas cuyo texto es idéntico en español y portugués (cognados
  clínicos) se registran explícitamente para mantener paridad total de
  claves entre idiomas.

## Correcciones
- «Progreso: X de Y» del Checklist OMS ya se traduce (quedaba fijo en
  español desde la v2.6.0).
- Degradación elegante conservada: cualquier cadena futura sin traducción
  se muestra en español sin romper la aplicación.

## Técnico
- versionCode 27 · versionName 2.6.1 · minSdk 24 (Android 7.0) · targetSdk 34.
- Sin permiso INTERNET: único permiso DYNAMIC_RECEIVER_NOT_EXPORTED.
- Locales empaquetadas: en, es, pt.
- Certificado de firma idéntico (SHA-256 628592a3…35ba8): actualización
  directa sobre cualquier versión anterior sin desinstalar.
- Tamaño: 23,9 MB. Suite de pruebas: 165 tests en verde (14+16 nuevos de
  internacionalización profunda: paridad de claves, cifras preservadas,
  claves estables, reevaluación de idioma en caliente).
- SBOM CycloneDX actualizado (root @2.6.1).
