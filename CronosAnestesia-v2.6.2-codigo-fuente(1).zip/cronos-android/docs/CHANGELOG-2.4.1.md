# Cronos Anestesia v2.4.1 (versionCode 24) — 24 de octubre de 2026

## Corregido / Enlazado

### 1. El video de Facebook ya abre el video EXACTO (antes: buscador provisional)
En la v2.4.0 los botones del video («Ver video de Cronos Anestesia» en Inicio,
Perlas y Ajustes) abrían una **búsqueda** de Facebook porque aún no existía el
enlace definitivo del video. Con esta versión los tres botones abren
directamente el **video compartido por el desarrollador**:

- **Nuevo enlace integrado**: `https://www.facebook.com/share/v/19FTQBahTb/`
- Se mantiene el mismo mecanismo seguro de siempre: `ACTION_VIEW` que delega
  en la app de Facebook o en el navegador del teléfono. La app sigue **sin
  permiso INTERNET** (contrato §2: cero permisos de red) — nada se descarga
  ni se reproduce dentro de la app.
- Si el teléfono no tiene ninguna app capaz de abrir el enlace, el botón lo
  ignora de forma silenciosa (mismo manejo de ActivityNotFoundException que
  los enlaces de WhatsApp).

### 2. Detalles técnicos
- `ExternalLinks.CRONOS_VIDEO_FB` (Links.kt): constante única actualizada;
  `MEDIK_BRAIN_FB` se queda con el buscador del canal hasta recibir el enlace
  definitivo del canal de Medik Brain.
- Prueba de contrato actualizada (`V240Test.enlaces_video_como_constantes_estables`):
  ahora exige el enlace exacto `share/v/19FTQBahTb` (evita regresiones).
- Sin cambios clínicos: 80 temas, 12 calculadoras, 16 escalas y el contenido
  clínico «v3 · octubre 2026» quedan idénticos a la v2.4.0.

## Instalación
- APK firmado (SHA-256 del certificado `628592a3…35ba8`, idéntico a todas las
  versiones anteriores): **instalación directa por encima de la v1.x–v2.4.0,
  sin desinstalar nada** (se conservan expediente, licencia y ajustes).
- Descarga: `http://47.57.232.232:8000/CronosAnestesia-v2.4.1.apk`
- Verificación de integridad: `http://47.57.232.232:8000/SHA256SUMS.txt`
