# Cronos Anestesia v2.2.1 (versionCode 22) — 31 de octubre de 2026

## Optimización de tamaño (contrato §5.2 · v2.2.1)

**Objetivo declarado: 12–15 MB · Resultado: 11,69 MB (−50,3 %).**

### Auditoría del APK v2.2.0 (23,5 MB)

| Componente | Sin comprimir en APK | Diagnóstico |
| --- | --- | --- |
| `libsqlcipher.so` × 4 ABIs | 21.609.272 B (91,7 %) | Duplicado en x86, x86_64, armeabi-v7a y arm64-v8a |
| `classes.dex` + `classes2.dex` | 3.757.836 B → 1,69 MB comprimido | R8 minificado, sin POI (exportación con generador propio) |
| `resources.arsc` + `res/` + `assets/` | < 0,1 MB | Solo vector drawables: nada que convertir a WebP |
| Resto (manifiesto, Kotlin, perfiles) | < 0,1 MB | — |

**Conclusión:** el peso no estaba en código ni recursos, sino en los binarios
nativos de SQLCipher empaquetados cuatro veces (uno por ABI). Las ABIs x86 y
x86_64 solo sirven para emuladores de escritorio: ningún teléfono real las usa.

### Cambios

- **Filtro de ABIs a ARM** (`ndk.abiFilters`): se eliminan `x86` y `x86_64`
  (−11.794.164 B exactos, sin comprimir). Se conservan **arm64-v8a**
  (optimizado para los móviles actuales) y **armeabi-v7a** (cubre los pocos
  teléfonos de 32 bits con Android 7+). Ninguna herramienta del app cambia:
  SQLCipher, Room, Compose, TCI, escalas y exportaciones funcionan igual.
- **R8 en modo completo explícito** (`android.enableR8.fullMode=true`),
  con las reglas de conservación previas (DataStore, SafeMode, SQLCipher).
- **WebP:** sin aplicación práctica — la app no contiene imágenes rasterizadas;
  todo el `res/` son vector drawables y esquemas dibujados con Compose Canvas.
- versionCode 22, versionName 2.2.1; sin permiso INTERNET (contrato R-01).
- Resolución de dependencias endurecida para esta red (espejos Aliyun +
  Tencent primero, repositorios oficiales como respaldo; plugins vía
  `buildscript` classpath para esquivar el 429/502 del Plugin Portal).

### Paridad verificada

- Mismo certificado de firma SHA-256 `628592a3…35ba8` → instalación directa
  sobre v2.2.0 sin desinstalar (contrato §3.5).
- **118/118 pruebas unitarias en verde** (sin cambios de código clínico:
  la batería completa se ejecuta sobre la misma configuración).
- `aapt dump badging`: sin permiso INTERNET (solo
  `DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION`, definido por la propia app),
  minSdk 24, targetSdk 34, `native-code: arm64-v8a armeabi-v7a`.
- Funcionalidad, textos y pantallas idénticos a v2.2.0 (criterios de paridad
  ESPEC-CA-220).
