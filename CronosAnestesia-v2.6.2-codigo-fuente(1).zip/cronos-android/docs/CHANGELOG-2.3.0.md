# Cronos Anestesia v2.3.0 (versionCode 23) — 31 de octubre de 2026

## Firma y documentos clínicos (contrato §5.2 · v2.3.0)

### 1. Consentimientos informados: 4 plantillas editables con PDF y modo lectura

En **Expediente → Consentimiento** (v2.0.0 existía 1 plantilla fija; ahora 4):

- **Anestesia** — la plantilla oficial de v2.0.0, intacta (6 técnicas con
  riesgos específicos por técnica).
- **Transfusión de hemoderivados** (nueva) — marco legal (Ley No. 156/2022),
  hemocomponentes y compatibilidad, beneficios, riesgos completos (febril,
  hemolítica aguda y tardía, aloinmunización, TACO, TRALI, infecciones
  residuales, inmunomodulación, hierro, EICH), alternativas de ahorro de
  sangre, derechos del paciente y firmas.
- **Analgesia del parto** (nueva) — técnicas (epidural continua, combinada
  espinal-epidural, espinal única), riesgos neuraxiales obstétricos
  (hipotensión, cefalea postpunción, hematoma/absceso, LAST, bloqueo alto,
  efecto sobre el bebé), alternativas (opioides, gas entonador, no
  analgesia) y firmas.
- **Sedación para procedimientos** (nueva) — grados de sedación, riesgos,
  instrucciones obligatorias de alta (acompañante, 24 h sin conducir, ayuno)
  y firmas.

Funciones sobre TODAS las plantillas:

- **Editar plantilla**: añade riesgos particulares (uno por línea) y
  cláusulas adicionales en texto libre; se guardan en el teléfono y se
  aplican al documento; «Restablecer» devuelve la plantilla oficial.
- **Guardar mis datos**: memoriza institución, servicio y nombre del
  anestesiólogo por plantilla para las próximas veces.
- **Modo lectura**: vista previa completa del documento en pantalla antes
  de firmar.
- **PDF**: documento A4 completo con bloques de firma, generado offline
  (mismo motor PdfDocument) y compartido con cualquier aplicación.

### 2. Checklist anestésica de verificación (pestaña Checklist, 2.ª lista)

La pestaña Checklist ahora tiene selector **OMS / Anestésica**. La lista
anestésica verifica el acto anestésico en 3 momentos con ítems agrupados:

- **Pre-inducción (27 ítems)**: Máquina (leak test, absorbedor, O₂ de
  reserva, vaporizador, ventilador, succión), Monitor (ECG, SpO₂ audible,
  PANI, capnografía, alarmas), Drogas (inducción y relajante etiquetados,
  vasopresores, adrenalina, reversor, lípidos para LAST, sangre), Vía aérea
  (laringoscopio, tubos, LMA, equipo de vía aérea difícil, aspiración,
  preoxigenación, ayuno).
- **Durante (10 ítems)**: capnografía continua, profundidad, TOF, fluidos,
  temperatura, posición, sangrado, comunicación con el cirujano.
- **Después (8 ítems)**: reversión con TOF, criterios de extubación,
  traslado monitorizado, traspaso verbal estructurado, analgesia/antieméticos,
  documentación y conciliación de drogas.

Los críticos están destacados; el resumen se guarda en el expediente
(registrando los críticos pendientes).

### 3. Contenido clínico nuevo (51 → 52 temas)

- **Anemia y terapia transfusional** (9.ª comorbilidad): clasificación y
  evaluación preoperatoria, umbral restrictivo (TRICS III, Hb 7 g/dL),
  gestión de la sangre del paciente (PBM: hierro, EPO, ANH, celda de
  salvamento), hemoderivados qué y cuándo (CGC, PFC, plaquetas,
  crioprecipitado), protocolo de hemorragia masiva (1:1:1, PROPPR,
  ácido tranexámico CRASH-2, hipotermia, calcio), riesgos transfusionales
  (TRALI, TACO, aloinmunización) y situaciones especiales (testigos de
  Jehová, hemoglobinopatías, zonas sin banco de sangre).

### 4. Soluciones: catálogo 8 → 9

- **Albúmina humana 5 %** (nueva ficha): composición, expansión, usos con
  evidencia (paracentesis de gran volumen, ALBIOS en sepsis, hepatorrenal),
  no indicaciones (SAFE, TCE), dosificación y precauciones.

### Verificación

- 131/131 pruebas unitarias en verde (118 previas + 13 nuevas de v2.3.0).
- Certificado SHA-256 `628592a3…35ba8` idéntico → instalación directa sobre
  v2.2.1/v2.2.0 sin desinstalar (contrato §3.5).
- Sin permiso INTERNET (solo `DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION`),
  minSdk 24, targetSdk 34, ABIs arm64-v8a + armeabi-v7a.
- Tamaño: 11,7 MB (mantenido con el filtro de ABIs de v2.2.1).
