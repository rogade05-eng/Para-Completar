# CHANGELOG — Cronos Anestesia v2.6.0 (versionCode 26)

Fecha: 27 de octubre de 2026 · Desarrollador: Ronald García Deroncele · WhatsApp +53 55301268

## Internacionalización: English + Português (Brasil) — «en todo»

La app ahora funciona en **tres idiomas**: Español (base), **English** y
**Português (Brasil)**. La internacionalización cubre interfaz, mensajes de
ayuda, informes, funcionalidades y configuraciones.

### 1. Selección de idioma (sistema + ajustes)
- La app arranca con el **idioma del teléfono**; si el sistema está en un
  idioma no soportado (francés, italiano, etc.) arranca en **español**
  (idioma base del producto).
- Nuevo selector en **Ajustes → Idioma**: Sistema · Español · English ·
  Português. Al cambiar, la preferencia se guarda en el dispositivo y la app
  se reinicia aplicando el idioma a recursos XML y contenido compilado.
- Cero conexión: la resolución de idioma es local (sin servicios de Google).

### 2. Recursos de interfaz (372 cadenas × 3 idiomas)
- `values/` (español, base) + nuevos `values-en/` y `values-pt/` con las 372
  cadenas traducidas (pestañas, inicio, ajustes, licencias, tarifas, TCI,
  expediente, consentimiento, máquina, checklist, análisis, atribución…).
- Nuevo filtro `resourceConfigurations` con es/en/pt: el APK empaqueta las
  tres locales verificadas con aapt (`locales: en es pt`).

### 3. Contenido funcional traducido (tablas por idioma, ~440 claves)
- **Calculadoras**: etiquetas, notas de fórmulas, avisos y bandas EVA de las
  12 calculadoras (ayuno, hidratación, dosis/peso, infusión, peso ideal, tubo
  pediátrico, sangrado, gasometría, anestésico local, TCI, infusión por
  fármaco y ventilación), incluidas las clases de resultado del motor
  (Berlín, compliance, índices P/A y OI, mortalidad).
- **Análisis de casos**: etiquetas de pantalla, bloque de resumen,
  distribuciones y textos de tendencia.
- **Expediente**: informe PDF y CSV con cabeceras traducidas.
- **Consentimiento informado**: documento legal completo en los tres idiomas
  (PDF y Word) — marco legal (Ley 156/2022 y Helsinki), 9 secciones, riesgos
  por técnica, beneficios, alternativas, derechos, declaración y firmas.
- **Manual de usuario**: los 16 apartados traducidos.
- **Checklist OMS**: las 3 fases con sus ítems traducidos.
- **Tarifas y confirmación de pago**: planes, duraciones y mensajes WhatsApp.
- **Modo seguro** (pantalla de fallo), splash y licencias.

### 4. Arquitectura (contrato sin conexión intacto)
- `L10n.kt`: enum `Lang`, resolución preferencia→sistema→español, envoltura
  de contexto en `attachBaseContext` (recursos XML) y `String.tr()` con
  **degradación elegante**: una cadena clínica aún sin traducir se muestra en
  español; ninguna ola parcial puede romper la app.
- Tablas de traducción por clave (texto original español) en `I18nUi.kt`,
  `I18nConsent.kt` e `I18nClinical.kt`, registradas de forma idempotente.
- Las etiquetas guardadas en el expediente («Cálculo: …», «Escala: …») son
  datos: los registros antiguos conservan su idioma original.

### 5. Alcance clínico pendiente (v2.6.1)
Las fichas profundas de la base clínica compilada (45 fármacos, 51 temas
clínicos, 16 escalas, 6 protocolos de emergencia, 14 complicaciones,
premedicación, 8 soluciones, perlas, máquina y presentación de fármacos)
mantienen su texto original en español en esta entrega; el marco `tr()` ya
está instrumentado para traducirlas por olas sin tocar los datos.

### 6. Pruebas y calidad
- **148 pruebas unitarias en verde** (134 previas + 14 nuevas de V260Test:
  resolución BCP-47, fallback español, idempotencia de registro, paridad de
  claves EN/PT, degradación `tr()`, consentimiento/informes/checklist/tarifas
  traducidos y contenido clínico intacto en modo español).
- Cero permisos peligrosos: solo `DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION`
  (sin INTERNET).
- Certificado de firma sin cambios (SHA-256 628592a3…35ba8): actualización
  directa sobre cualquier versión anterior sin desinstalar.
- SBOM CycloneDX regenerado con root @2.6.0 (99 componentes).
