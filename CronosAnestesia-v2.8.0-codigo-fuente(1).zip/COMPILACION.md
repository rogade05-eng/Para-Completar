# Cronos Anestesia v2.7.0 — Compilación del código fuente

Snapshot del código fuente de **Cronos Anestesia v2.7.0 (versionCode 30)**
· RoGaDe Software · contenido clínico del Dr. Romay Díaz Deroncele ·
app 100 % offline (sin permiso INTERNET) · Jetpack Compose + Room/SQLCipher.

## Requisitos

| Componente | Versión |
| --- | --- |
| JDK | 17 (OpenJDK) |
| Android SDK | 34 · build-tools 34.0.0 · plataforma android-34 |
| Gradle | 8.9 – 8.14 (el proyecto no incluye wrapper; `gradle` en PATH) |
| AGP / Kotlin | 8.5.2 / 2.0.20 (fijados en `build.gradle.kts` vía buildscript) |

## Compilación y pruebas

```bash
gradle assembleDebug          # APK de depuración
gradle assembleRelease        # APK firmable (ver firma abajo)
gradle testDebugUnitTest      # suite unitaria (V200…V270)
```

## Firma (release)

El almacén de claves **no viaja con el código** (`.gitignore`: `*.keystore`);
se entrega por separado como `cronos-release.keystore` (alias `cronos`).
Colocar la copia junto al proyecto y firmar:

```bash
zipalign -f -p 4 app/build/outputs/apk/release/app-release-unsigned.apk app-release-aligned.apk
apksigner sign --ks cronos-release.keystore --ks-key-alias cronos --out CronosAnestesia-v2.6.2.apk app-release-aligned.apk
apksigner verify --print-certs CronosAnestesia-v2.6.2.apk
```

El certificado de todas las entregas es el mismo (SHA-256 `628592a3…35ba8`);
consérvelo para que la actualización sobre una versión instalada sea directa
(sin desinstalar ni perder datos locales).

## Repositorios de dependencias

`settings.gradle.kts` y el bloque `buildscript` de `build.gradle.kts`
priorizan los espejos Aliyun/Tencent porque la red de desarrollo recibe
429/502 de Maven Central y del Plugin Portal; en una red abierta funcionan
igual (son los mismos artefactos). Si un build falla por red, bastan 2–3
reintentos.

## Puntos clave del proyecto

- `app/build.gradle.kts`: versionCode 28 / versionName «2.6.2»; ABIs
  `arm64-v8a` + `armeabi-v7a`; `resourceConfigurations` es/en/pt; R8 completo.
- Almacén cifrado: Room 2.6.1 + SQLCipher 4.6.1 (`ContentDb.kt`).
- Exportaciones con generador propio (sin Apache POI): `OfficeExport.kt`
  (XLSX/DOCX), `XlsxWriter.kt`, `PdfExporter.kt` (PDF).
- Idiomas: Español (base), English y Português do Brasil (`L10n.kt`, `I18n*.kt`).
- Créditos de equipo (v2.6.2): constante única `DEVELOPER_CREDITS` en
  `LicenseContact.kt`; los nombres propios no se traducen.
- Documentación: `docs/CHANGELOG-2.2.0…2.6.2.md`, `ADENDA_TECNICA.md`,
  `C4.md`, `LICENCIAS.md`, `SBOM.cdx.json`.
- El contenido clínico se versiona aparte y es visible en Ajustes (§10.1).
