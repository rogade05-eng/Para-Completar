package cu.cronos.anestesia

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.io.File
import java.text.SimpleDateFormat
import java.time.Instant
import java.time.YearMonth
import java.time.ZoneId
import java.util.Calendar
import java.util.Date
import java.util.Locale

// =====================================================================
//  ESTADÍSTICAS, ESTUDIOS E INVESTIGACIÓN (v2.5.0)
//  ----------------------------------------------------------------------------
//  Amplía el «Análisis de casos» (v2.2.0) a un módulo completo de
//  estadística clínica a partir de TODOS los casos registrados en el
//  expediente local:
//   · TENDENCIAS: serie mensual (12 meses) con gráfico de línea, y
//     comparación últimos 30 días vs 30 días previos.
//   · GRÁFICOS: barras horizontales (edades, secciones, días de la
//     semana) y anillo (sexo) dibujados con Canvas de Compose — sin
//     librerías externas, sin red.
//   · TABLAS: frecuencia de secciones (n y %) y registros por paciente
//     (n y última fecha).
//  El motor (StatsEngine) es puro JVM y queda bloqueado en V250Test.
// =====================================================================

data class Stats(
    val patients: Int,
    val entries: Int,
    val male: Int,
    val female: Int,
    val sexUnknown: Int,
    val ageGroups: List<Pair<String, Int>>,
    val topTags: List<Pair<String, Int>>,
    val allTags: List<Pair<String, Int>>,
    val monthly: List<Pair<String, Int>>,          // etiqueta «oct 26» → n (12 meses)
    val weekdays: List<Pair<String, Int>>,         // Lun..Dom → n
    val perPatient: List<Triple<String, Int, Long?>>, // nombre, registros, último ts
    val last7: Int,
    val last30: Int,
    val prev30: Int,
    val avgPerPatient: Double,
    val firstTs: Long?,
    val lastTs: Long?
)

object StatsEngine {

    /** Etiquetas cortas de los días, de lunes a domingo. */
    val WEEK_LABELS = listOf("Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom")

    private val MONTH_FMT = java.time.format.DateTimeFormatter.ofPattern("LLL yy", Locale("es"))

    /** Clave de mes de un timestamp: YearMonth en la zona del dispositivo. */
    fun monthOf(ts: Long): YearMonth =
        YearMonth.from(Instant.ofEpochMilli(ts).atZone(ZoneId.systemDefault()))

    /** Índice 0..6 del día de la semana (0 = lunes). */
    fun weekdayIndex(ts: Long): Int {
        val cal = Calendar.getInstance()
        cal.timeInMillis = ts
        return (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7
    }

    /** Serie mensual FIJA de 12 puntos terminando en el mes actual. */
    fun monthlySeries(allEntries: List<ExpEntry>, now: Long, months: Int = 12): List<Pair<YearMonth, Int>> {
        val counts = HashMap<YearMonth, Int>()
        allEntries.forEach { e -> counts[monthOf(e.ts)] = (counts[monthOf(e.ts)] ?: 0) + 1 }
        val current = monthOf(now)
        return (months - 1 downTo 0).map { back ->
            val ym = current.minusMonths(back.toLong())
            ym to (counts[ym] ?: 0)
        }
    }

    /** Variación porcentual últimos 30 vs 30 previos; null si no hay base de comparación. */
    fun trendPct(last30: Int, prev30: Int): Double? {
        if (prev30 == 0) return null
        return (last30 - prev30) * 100.0 / prev30
    }

    /** Porcentaje legible en es-CU («12,3 %»); reutilizado por UI, informe y hoja. */
    fun pctOf(part: Int, total: Int): String =
        if (total == 0) "0 %" else fmt1(part * 100.0 / total) + " %"

    /** Frase de tendencia en es-CU (estilo del informe de v2.2.0). */
    fun trendText(last30: Int, prev30: Int): String {
        val pct = trendPct(last30, prev30)
        return when {
            prev30 == 0 && last30 == 0 -> "Sin actividad registrada en los últimos 60 días."
            prev30 == 0 -> "Se registraron $last30 registro(s) en los últimos 30 días (sin actividad en los 30 previos)."
            pct != null && pct > 0.5 -> "Tendencia al ALZA: +${fmt1(pct)} % frente a los 30 días previos ($last30 vs $prev30)."
            pct != null && pct < -0.5 -> "Tendencia a la BAJA: ${fmt1(pct)} % frente a los 30 días previos ($last30 vs $prev30)."
            else -> "Actividad estable frente a los 30 días previos ($last30 vs $prev30)."
        }
    }

    private fun fmt1(v: Double): String {
        val r = (v * 10).toLong() / 10.0
        return if (r == r.toLong().toDouble()) r.toLong().toString() else r.toString().replace('.', ',')
    }

    /** Analiza pacientes + TODAS las entradas de TODOS los casos. */
    fun compute(
        patients: List<Patient>,
        allEntries: List<ExpEntry>,
        now: Long = System.currentTimeMillis()
    ): Stats {
        var male = 0; var female = 0; var sexUnknown = 0
        val ageCounts = CaseAnalysis.AGE_ORDER.associateWith { 0 }.toMutableMap()
        patients.forEach { p ->
            when (p.sex.trim().uppercase(Locale.ROOT)) {
                "M", "H", "MASCULINO", "HOMBRE" -> male++
                "F", "FEMENINO", "MUJER" -> female++
                else -> sexUnknown++
            }
            CaseAnalysis.ageGroupOf(p.age)?.let { ageCounts[it] = ageCounts[it]!! + 1 }
        }

        val allTags = allEntries.groupBy { it.tag.ifBlank { "Sin sección" } }
            .map { (k, v) -> k to v.size }
            .sortedWith(compareByDescending<Pair<String, Int>> { it.second }.thenBy { it.first })

        val day = 86_400_000L
        val last7 = allEntries.count { it.ts >= now - 7 * day }
        val last30 = allEntries.count { it.ts >= now - 30 * day }
        val prev30 = allEntries.count { it.ts >= now - 60 * day && it.ts < now - 30 * day }

        val wd = IntArray(7)
        allEntries.forEach { e -> wd[weekdayIndex(e.ts)]++ }

        val byPatient = patients.map { p ->
            val es = allEntries.filter { it.patientId == p.id }
            Triple(p.name.ifBlank { "Sin nombre" }, es.size, es.maxOfOrNull { it.ts })
        }.sortedWith(compareByDescending<Triple<String, Int, Long?>> { it.second }.thenBy { it.first })

        return Stats(
            patients = patients.size,
            entries = allEntries.size,
            male = male,
            female = female,
            sexUnknown = sexUnknown,
            ageGroups = CaseAnalysis.AGE_ORDER.map { it to (ageCounts[it] ?: 0) },
            topTags = allTags.take(8),
            allTags = allTags,
            monthly = monthlySeries(allEntries, now).map { (ym, n) ->
                ym.format(MONTH_FMT) to n
            },
            weekdays = WEEK_LABELS.mapIndexed { i, l -> l to wd[i] },
            perPatient = byPatient,
            last7 = last7,
            last30 = last30,
            prev30 = prev30,
            avgPerPatient = if (patients.isEmpty()) 0.0 else allEntries.size.toDouble() / patients.size,
            firstTs = allEntries.minOfOrNull { it.ts },
            lastTs = allEntries.maxOfOrNull { it.ts }
        )
    }
}

// ============================== INFORME (bloques y hojas) ==============================

object StatsReport {

    private fun fmt(n: Double): String {
        val r = (n * 10).toLong() / 10.0
        return if (r == r.toLong().toDouble()) r.toLong().toString() else r.toString()
    }

    private fun pct(part: Int, total: Int): String = StatsEngine.pctOf(part, total)

    /** Bloques del informe (0 título / 1 encabezado / 2 cuerpo) para PDF y Word. */
    fun blocks(
        s: Stats,
        f: SimpleDateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    ): List<Pair<String, Int>> {
        val out = mutableListOf<Pair<String, Int>>()
        out.add("Cronos Anestesia — Estadísticas de casos" to 0)
        out.add(
            "Estudio descriptivo generado offline a partir de todos los casos registrados en el expediente " +
                "de este dispositivo. Contiene datos clínicos agregados: custodiar conforme a la " +
                "confidencialidad de la historia clínica y al consentimiento del paciente." to 2
        )
        out.add("Resumen general" to 1)
        out.add(
            "Casos (pacientes): ${s.patients}\n" +
                "Registros totales: ${s.entries}\n" +
                "Promedio de registros por caso: ${fmt(s.avgPerPatient)}\n" +
                "Registros últimos 7 días: ${s.last7}\n" +
                "Registros últimos 30 días: ${s.last30} · 30 días previos: ${s.prev30}\n" +
                StatsEngine.trendText(s.last30, s.prev30) + "\n" +
                (if (s.firstTs != null) "Periodo estudiado: ${f.format(Date(s.firstTs))} — ${f.format(Date(s.lastTs ?: s.firstTs))}" else "Periodo: sin registros") to 2
        )
        out.add("Distribución por sexo" to 1)
        out.add(
            "Masculino: ${s.male} (${pct(s.male, s.patients)}) · Femenino: ${s.female} (${pct(s.female, s.patients)})" +
                (if (s.sexUnknown > 0) " · Sin dato: ${s.sexUnknown} (${pct(s.sexUnknown, s.patients)})" else "") to 2
        )
        out.add("Casos por grupo de edad" to 1)
        out.add(s.ageGroups.joinToString("\n") { "• ${it.first}: ${it.second} (${pct(it.second, s.patients)})" } to 2)
        out.add("Tendencia mensual de registros (últimos 12 meses)" to 1)
        out.add(s.monthly.joinToString("\n") { "• ${it.first}: ${it.second}" } to 2)
        out.add("Actividad por día de la semana" to 1)
        out.add(s.weekdays.joinToString("\n") { "• ${it.first}: ${it.second}" } to 2)
        out.add("Frecuencia de secciones (cálculos y estudios)" to 1)
        out.add(
            (if (s.allTags.isEmpty()) "Sin registros aún."
            else s.allTags.joinToString("\n") { "• ${it.first}: ${it.second} (${pct(it.second, s.entries)})" }) to 2
        )
        out.add("Tabla: registros por paciente" to 1)
        if (s.perPatient.isEmpty()) {
            out.add("No hay casos guardados en este dispositivo." to 2)
        } else {
            s.perPatient.forEach { (name, n, last) ->
                out.add(
                    "• $name: $n registro(s)" +
                        (if (last != null) " — último ${f.format(Date(last))}" else "") to 2
                )
            }
        }
        out.add(
            "Documento generado por Cronos Anestesia (sin conexión). Use estas cifras como apoyo para " +
                "sus estudios e investigaciones locales; verifique los datos antes de archivar o publicar." to 2
        )
        return out
    }
}

/** Filas de la hoja Excel de estadísticas (una sola hoja, como v2.2.0). */
object StatsSheets {

    fun rows(
        s: Stats,
        patients: List<Patient>,
        entriesByPatient: Map<String, List<ExpEntry>>
    ): List<List<String?>> {
        val f = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val rows = mutableListOf<List<String?>>()
        rows.add(listOf("Cronos Anestesia — Estadísticas de casos", "", "", ""))
        rows.add(listOf("Indicador", "Valor", "", ""))
        rows.add(listOf("Casos (pacientes)", s.patients.toString(), "", ""))
        rows.add(listOf("Registros totales", s.entries.toString(), "", ""))
        rows.add(listOf("Promedio por caso", String.format(Locale.US, "%.1f", s.avgPerPatient), "", ""))
        rows.add(listOf("Últimos 7 días", s.last7.toString(), "", ""))
        rows.add(listOf("Últimos 30 días", s.last30.toString(), "", ""))
        rows.add(listOf("30 días previos", s.prev30.toString(), "", ""))
        rows.add(listOf("Tendencia", StatsEngine.trendText(s.last30, s.prev30), "", ""))
        rows.add(emptyList())
        rows.add(listOf("Mes", "Registros", "", ""))
        s.monthly.forEach { (m, n) -> rows.add(listOf(m, n.toString(), "", "")) }
        rows.add(emptyList())
        rows.add(listOf("Sexo", "Casos", "", ""))
        rows.add(listOf("Masculino", s.male.toString(), "", ""))
        rows.add(listOf("Femenino", s.female.toString(), "", ""))
        if (s.sexUnknown > 0) rows.add(listOf("Sin dato", s.sexUnknown.toString(), "", ""))
        rows.add(emptyList())
        rows.add(listOf("Grupo de edad", "Casos", "", ""))
        s.ageGroups.forEach { (g, n) -> rows.add(listOf(g, n.toString(), "", "")) }
        rows.add(emptyList())
        rows.add(listOf("Sección", "Registros", "Porcentaje", ""))
        s.allTags.forEach { (t, n) ->
            rows.add(listOf(t, n.toString(), StatsEngine.pctOf(n, s.entries), ""))
        }
        rows.add(emptyList())
        rows.add(listOf("Día de la semana", "Registros", "", ""))
        s.weekdays.forEach { (d, n) -> rows.add(listOf(d, n.toString(), "", "")) }
        rows.add(emptyList())
        rows.add(listOf("Paciente", "Registros", "Último registro", ""))
        s.perPatient.forEach { (name, n, last) ->
            rows.add(listOf(name, n.toString(), last?.let { f.format(Date(it)) } ?: "", ""))
        }
        rows.add(emptyList())
        rows.add(listOf("Fecha", "Paciente", "Sección", "Registro"))
        patients.forEach { p ->
            (entriesByPatient[p.id] ?: emptyList()).forEach { e ->
                rows.add(listOf(f.format(Date(e.ts)), p.name.ifBlank { "Sin nombre" }, e.tag, e.text))
            }
        }
        return rows
    }
}

// ============================== GRÁFICOS (Canvas/Compose) ==============================

/** Gráfico de barras horizontales: etiqueta | barra proporcional | valor. */
@Composable
fun HBarChart(
    data: List<Pair<String, Int>>,
    modifier: Modifier = Modifier,
    barColor: Color = MaterialTheme.colorScheme.primary
) {
    val sp = LocalSpacing.current
    val maxV = (data.maxOfOrNull { it.second } ?: 0).coerceAtLeast(1)
    val track = MaterialTheme.colorScheme.surfaceVariant
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(sp.xs.dp)) {
        data.forEach { (label, v) ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    label,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1.1f)
                )
                Box(
                    Modifier
                        .weight(1.6f)
                        .height(14.dp)
                        .clip(RoundedCornerShape(7.dp))
                        .background(track)
                ) {
                    Box(
                        Modifier
                            .fillMaxHeight()
                            .fillMaxWidth((v.toFloat() / maxV).coerceIn(0.03f, 1f))
                            .clip(RoundedCornerShape(7.dp))
                            .background(barColor)
                    )
                }
                Text(
                    v.toString(),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(start = sp.s.dp)
                )
            }
        }
    }
}

/** Anillo (dona) para distribuciones pequeñas (sexo). */
@Composable
fun DonutChart(
    segments: List<Triple<String, Int, Color>>,
    modifier: Modifier = Modifier
) {
    val sp = LocalSpacing.current
    val total = segments.sumOf { it.second }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Canvas(modifier.size(110.dp)) {
            var start = -90f
            val stroke = 20.dp.toPx()
            segments.forEach { (_, v, color) ->
                if (v <= 0 || total == 0) return@forEach
                val sweep = 360f * v / total
                drawArc(
                    color = color,
                    startAngle = start,
                    sweepAngle = sweep,
                    useCenter = false,
                    style = Stroke(width = stroke, cap = StrokeCap.Butt)
                )
                start += sweep
            }
        }
        Spacer(Modifier.size(sp.s.dp))
        Column(verticalArrangement = Arrangement.spacedBy(sp.xs.dp)) {
            segments.forEach { (label, v, color) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).clip(CircleShape).background(color))
                    Spacer(Modifier.size(sp.xs.dp))
                    Text(
                        "$label: $v",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

/** Gráfico de línea con área para la tendencia mensual. */
@Composable
fun LineTrendChart(
    points: List<Pair<String, Int>>,
    modifier: Modifier = Modifier,
    lineColor: Color = MaterialTheme.colorScheme.primary
) {
    val sp = LocalSpacing.current
    val dark = isSystemInDarkTheme()
    val grid = if (dark) Color(0x33FFFFFF) else Color(0x22000000)
    Column(modifier.fillMaxWidth()) {
        Canvas(
            Modifier
                .fillMaxWidth()
                .height(110.dp)
        ) {
            val maxV = (points.maxOfOrNull { it.second } ?: 0).coerceAtLeast(1)
            drawLine(
                grid,
                Offset(0f, size.height - 1f),
                Offset(size.width, size.height - 1f),
                strokeWidth = 1.dp.toPx()
            )
            if (points.size < 2) return@Canvas
            val stepX = size.width / (points.size - 1)
            fun y(v: Int): Float =
                size.height * 0.92f - (v.toFloat() / maxV) * (size.height * 0.78f)

            val path = Path()
            val area = Path()
            points.forEachIndexed { i, (_, v) ->
                val x = i * stepX
                val py = y(v)
                if (i == 0) {
                    path.moveTo(x, py); area.moveTo(x, size.height); area.lineTo(x, py)
                } else {
                    path.lineTo(x, py); area.lineTo(x, py)
                }
            }
            area.lineTo(size.width, size.height)
            area.close()
            drawPath(area, lineColor.copy(alpha = 0.14f))
            drawPath(path, lineColor, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))
            points.forEachIndexed { i, (_, v) ->
                drawCircle(lineColor, radius = 3.dp.toPx(), center = Offset(i * stepX, y(v)))
            }
        }
        if (points.size >= 2) {
            Row(Modifier.fillMaxWidth()) {
                Text(
                    points.first().first,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.weight(1f))
                Text(
                    points.last().first,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// tema oscuro (heurística estándar de Compose)
// (isSystemInDarkTheme importado arriba)

// ============================== SECCIÓN UI ==============================

@Composable
fun StatsSection() {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    val patients = remember { Expediente.patients(ctx) }
    val entriesByPatient = remember(patients) {
        patients.associate { it.id to Expediente.entries(ctx, it.id) }
    }
    val allEntries = entriesByPatient.values.flatten()
    val stats = remember(patients, allEntries) { StatsEngine.compute(patients, allEntries) }

    if (patients.isEmpty()) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Text(
                stringResource(R.string.analysis_empty),
                modifier = Modifier.padding(sp.m.dp),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
        return
    }

    // --- tarjetas de resumen (2 x 2) ---
    val statPairs = listOf(
        stringResource(R.string.analysis_stat_cases) to stats.patients.toString(),
        stringResource(R.string.analysis_stat_entries) to stats.entries.toString(),
        stringResource(R.string.analysis_stat_last30) to stats.last30.toString(),
        stringResource(R.string.analysis_stat_avg) to String.format(Locale.getDefault(), "%.1f", stats.avgPerPatient)
    )
    for (start in statPairs.indices step 2) {
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            for (k in 0 until minOf(2, statPairs.size - start)) {
                val (label, value) = statPairs[start + k]
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(Modifier.padding(sp.m.dp)) {
                        Text(
                            value,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            label,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }

    // --- TENDENCIA: serie mensual + comparación 30 vs 30 ---
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(sp.m.dp)) {
            Text(
                stringResource(R.string.stats_trend_title),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                stringResource(R.string.stats_trend_hint),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(sp.xs.dp))
            LineTrendChart(stats.monthly)
            Spacer(Modifier.height(sp.xs.dp))
            Text(
                StatsEngine.trendText(stats.last30, stats.prev30),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                stringResource(R.string.stats_trend_windows, stats.last7, stats.last30, stats.prev30),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }

    // --- SEXO: anillo ---
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(sp.m.dp)) {
            Text(
                stringResource(R.string.stats_sex_title),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(sp.xs.dp))
            DonutChart(
                listOf(
                    Triple(stringResource(R.string.sex_male), stats.male, MaterialTheme.colorScheme.primary),
                    Triple(stringResource(R.string.sex_female), stats.female, MaterialTheme.colorScheme.tertiary),
                    Triple(stringResource(R.string.sex_unknown), stats.sexUnknown, MaterialTheme.colorScheme.outline)
                )
            )
        }
    }

    // --- EDADES: barras ---
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(sp.m.dp)) {
            Text(
                stringResource(R.string.stats_age_title),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(sp.xs.dp))
            HBarChart(stats.ageGroups, barColor = MaterialTheme.colorScheme.tertiary)
        }
    }

    // --- SECCIONES más registradas: barras ---
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(sp.m.dp)) {
            Text(
                stringResource(R.string.stats_sections_title),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(sp.xs.dp))
            if (stats.topTags.isEmpty()) {
                Text(stringResource(R.string.stats_no_data), style = MaterialTheme.typography.bodyMedium)
            } else {
                HBarChart(stats.topTags)
            }
        }
    }

    // --- DÍA DE LA SEMANA: barras ---
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(sp.m.dp)) {
            Text(
                stringResource(R.string.stats_weekday_title),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(sp.xs.dp))
            HBarChart(stats.weekdays, barColor = MaterialTheme.colorScheme.secondary)
        }
    }

    // --- TABLA: frecuencia de secciones (todas, con %) ---
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(sp.m.dp)) {
            Text(
                stringResource(R.string.stats_table_sections_title),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(sp.xs.dp))
            TableHeader(
                listOf(
                    stringResource(R.string.stats_col_section),
                    stringResource(R.string.stats_col_n),
                    stringResource(R.string.stats_col_pct)
                ),
                weights = listOf(2f, 1f, 1f)
            )
            if (stats.allTags.isEmpty()) {
                Text(stringResource(R.string.stats_no_data), style = MaterialTheme.typography.bodyMedium)
            } else {
                stats.allTags.forEach { (t, n) ->
                    TableRowCells(
                        listOf(t, n.toString(), StatsEngine.pctOf(n, stats.entries)),
                        weights = listOf(2f, 1f, 1f)
                    )
                }
            }
        }
    }

    // --- TABLA: registros por paciente ---
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(sp.m.dp)) {
            Text(
                stringResource(R.string.stats_table_patients_title),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(sp.xs.dp))
            TableHeader(
                listOf(
                    stringResource(R.string.stats_col_patient),
                    stringResource(R.string.stats_col_n),
                    stringResource(R.string.stats_col_last)
                ),
                weights = listOf(2f, 1f, 1.4f)
            )
            stats.perPatient.forEach { (name, n, last) ->
                TableRowCells(
                    listOf(
                        name,
                        n.toString(),
                        last?.let { SimpleDateFormat("dd/MM/yy", Locale.getDefault()).format(Date(it)) } ?: "—"
                    ),
                    weights = listOf(2f, 1f, 1.4f)
                )
            }
        }
    }

    // --- Exportación ---
    SectionLabel(stringResource(R.string.stats_export_title))
    Text(
        stringResource(R.string.analysis_export_note),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
        AppButton(
            "PDF",
            secondary = true,
            modifier = Modifier.weight(1f),
            onClick = {
                runExport(ctx) {
                    val f = File(exportDirSt(ctx), "estadisticas_${stampSt()}.pdf")
                    Expediente.exportPdfBlocks(f, StatsReport.blocks(stats))
                    f
                }
            }
        )
        AppButton(
            stringResource(R.string.analysis_export_xlsx),
            secondary = true,
            modifier = Modifier.weight(1f),
            onClick = {
                runExport(ctx) {
                    val f = File(exportDirSt(ctx), "estadisticas_${stampSt()}.xlsx")
                    OfficeExport.writeXlsx(
                        f, "Estadísticas",
                        listOf("Cronos Anestesia — Estadísticas de casos", "", "", ""),
                        StatsSheets.rows(stats, patients, entriesByPatient)
                    )
                    f
                }
            }
        )
    }
    AppButton(
        stringResource(R.string.analysis_export_docx),
        secondary = true,
        modifier = Modifier.fillMaxWidth(),
        onClick = {
            runExport(ctx) {
                val f = File(exportDirSt(ctx), "estadisticas_${stampSt()}.docx")
                OfficeExport.writeDocx(f, StatsReport.blocks(stats))
                f
            }
        }
    )
}

// filas de tabla genéricas (alineadas con el resto de la app)
@Composable
private fun TableHeader(labels: List<String>, weights: List<Float>) {
    Row(Modifier.fillMaxWidth()) {
        labels.forEachIndexed { i, l ->
            Text(
                l,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(weights[i])
            )
        }
    }
    Spacer(Modifier.height(4.dp))
}

@Composable
private fun TableRowCells(cells: List<String>, weights: List<Float>) {
    Row(Modifier.fillMaxWidth().padding(top = 2.dp)) {
        cells.forEachIndexed { i, c ->
            Text(
                c,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(weights[i])
            )
        }
    }
}

private fun exportDirSt(ctx: Context): File = File(ctx.cacheDir, "exports").apply { mkdirs() }
private fun stampSt(): String = SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())

private fun runExport(ctx: Context, make: () -> File) {
    try {
        val f = make()
        val mime = when {
            f.name.endsWith(".xlsx") -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            f.name.endsWith(".docx") -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            else -> "application/pdf"
        }
        Expediente.share(ctx, f, mime)
    } catch (e: Throwable) {
        Toast.makeText(ctx, e.message ?: "Error", Toast.LENGTH_LONG).show()
    }
}
