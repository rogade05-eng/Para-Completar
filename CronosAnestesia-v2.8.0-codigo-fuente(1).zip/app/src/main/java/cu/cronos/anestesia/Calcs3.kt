package cu.cronos.anestesia

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

// =====================================================================
//  CALCULADORAS v2.1.0 — Bloqueos regionales + jeringa perfusora
//  · EspinalCalc   (rac)     → dosis espinal por altura (Tagariello)
//  · EpiduralCalc  (epi)     → volumen de carga por dermatomas
//  · SyringeCalc   (jeringa) → regla universal de la jeringa perfusora
//  (La TCI vive en Tci.kt: esquema BET exacto Marsh/Schnider/Minto.)
//  Mismo patrón que Calcs2.kt: NumField → CalcEngine (puro, testeado)
//  → ResultCard con «Guardar en expediente».
// =====================================================================

@Composable
private fun NumField3(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    suffix: String,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = modifier,
        label = { Text(label) },
        suffix = { Text(suffix) },
        singleLine = true,
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.primary,
            cursorColor = MaterialTheme.colorScheme.primary
        )
    )
}

@Composable
private fun ResultCard3(title: String, lines: List<Pair<String, String>>, tag: String) {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(sp.m.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.height(sp.xs.dp))
            lines.forEach { (k, v) ->
                Text(
                    k,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    v,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(sp.xs.dp))
            }
            AppButton(
                stringResource(R.string.exp_save_calc),
                secondary = true,
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    Expediente.saveCalc(ctx, title, tag)
                    Toast.makeText(ctx, ctx.getString(R.string.exp_saved), Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}

// ---- Dosis espinal (Raquianestesia) ----

@Composable
fun EspinalCalc() {
    val sp = LocalSpacing.current
    var height by rememberSaveable { mutableStateOf("170") }
    var elderly by rememberSaveable { mutableStateOf(false) }
    val h = CalcEngine.parseNum(height)
    val base = CalcEngine.spinalBupivacaineMg(h)
    val dose = if (elderly) base * 0.75 else base
    val range = "${CalcEngine.fmt(dose * 0.85)}–${CalcEngine.fmt(dose * 1.1)} mg"
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            NumField3(height, { height = it }, "Altura", "cm", Modifier.weight(1f))
        }
        SettingSwitchRow(
            "Paciente ≥65 años o con enfermedad cardiovascular",
            "Reduce la dosis un 25 % (el bloqueo sube más y dura menos)",
            elderly,
            { elderly = it }
        )
        ResultCard3(
            "Dosis espinal (bupivacaína hiperbárica 0,5 %)",
            listOf(
                "Fórmula: 0,06 mg × altura (cm)" to "${CalcEngine.fmt(base)} mg",
                "Dosis sugerida" to if (elderly) "${CalcEngine.fmt(dose)} mg (ajustada −25 %)" else "${CalcEngine.fmt(base)} mg",
                "Rango de trabajo" to range,
                "Objetivo" to "Nivel T6–T8 (cirugía infraumbilical); cesárea T4–T6 con 10–12 mg",
                "Adyuvantes" to "Fentanilo 15–25 µg (calidad) · morfina 0,1–0,2 mg en cesárea (vigilar 12–24 h)",
                "Compruebe SIEMPRE" to "Aspiración de LCR libre, dosis según protocolo institucional y estatura/peso reales"
            ),
            tag = "Espinal: ${CalcEngine.fmt(dose)} mg bupivacaína 0,5 % hiperbárica (altura ${CalcEngine.fmt(h)} cm${if (elderly) ", ajustada ≥65 años" else ""})"
        )
    }
}

// ---- Volumen epidural (Peridural) ----

@Composable
fun EpiduralCalc() {
    val sp = LocalSpacing.current
    var segments by rememberSaveable { mutableStateOf("10") }
    var weight by rememberSaveable { mutableStateOf("70") }
    var conc by rememberSaveable { mutableStateOf("5.0") }
    val segs = CalcEngine.parseNum(segments).toInt()
    val load = CalcEngine.epiduralLoadMl(segs)
    val w = CalcEngine.parseNum(weight)
    val c = CalcEngine.parseNum(conc)
    val spec = CalcEngine.LA_SPECS.first { it.name == "Bupivacaína" }
    val laMax = CalcEngine.localAnestheticMax(spec, w, false, false, c)
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            NumField3(segments, { segments = it }, "Dermatomas a bloquear", "", Modifier.weight(1f))
            NumField3(weight, { weight = it }, "Peso", "kg", Modifier.weight(1f))
        }
        NumField3(conc, { conc = it }, "Concentración epidural elegida", "mg/mL")
        ResultCard3(
            "Anestesia/analgesia epidural",
            listOf(
                "Volumen de carga = 1,5 mL × dermatomas + 4 mL" to "${CalcEngine.fmt(load)} mL",
                "Dosis testigo previa" to "3 mL de lidocaína 2 % + epinefrina 1:200 000 (15 µg): descartar intravascular e intratecal",
                "Dosis máxima de bupivacaína (sin adrenalina)" to "${CalcEngine.fmt(laMax.maxMg)} mg = ${CalcEngine.fmt(laMax.maxMl)} mL al ${CalcEngine.fmt(c)} mg/mL",
                "Top-ups" to "6–10 mL c/2–4 h o infusión 6–10 mL/h (bupivacaína 0,125 % + fentanilo 2 µg/mL)",
                "Fraccionar SIEMPRE" to "Cada 5 mL con verificación de aspiración; catéter: nunca force al retirarlo"
            ),
            tag = "Epidural: carga ${CalcEngine.fmt(load)} mL (${segs} dermatomas) · máx bupivacaína ${CalcEngine.fmt(laMax.maxMg)} mg"
        )
    }
}


// ---- Función renal (Cockcroft-Gault) — v2.7.0 ----

@Composable
fun CockcroftCalc() {
    val sp = LocalSpacing.current
    var age by rememberSaveable { mutableStateOf("65") }
    var weight by rememberSaveable { mutableStateOf("70") }
    var cr by rememberSaveable { mutableStateOf("1.0") }
    var female by rememberSaveable { mutableStateOf(false) }
    val ageV = CalcEngine.parseNum(age)
    val wV = CalcEngine.parseNum(weight)
    val crV = CalcEngine.parseNum(cr)
    val clcr = CalcEngine.cockcroftGault(ageV, wV, crV, female)
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            NumField3(age, { age = it }, "Edad", "años", Modifier.weight(1f))
            NumField3(weight, { weight = it }, "Peso real", "kg", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            NumField3(cr, { cr = it }, "Creatinina sérica", "mg/dL", Modifier.weight(1f))
            Column(Modifier.weight(1f)) {
                SettingSwitchRow(
                    "Mujer",
                    "Multiplica el resultado por 0,85",
                    female,
                    { female = it }
                )
            }
        }
        ResultCard3(
            "Depuración de creatinina estimada (Cockcroft-Gault)",
            listOf(
                "Fórmula" to "(140 − edad) × peso / (72 × creatinina)" + if (female) " × 0,85" else "",
                "ClCr estimada" to CalcEngine.fmt(clcr) + " mL/min",
                "Función renal" to CalcEngine.cockcroftGaultClass(clcr),
                "Ajuste de fármacos" to "Reducir dosis o intervalo en ClCr < 60: enoxaparina terapéutica, morfina (metabolitos), vancomicina, magnesio, digoxina; comprobar siempre la ficha del fármaco",
                "Precaución" to "Estimación imprecisa en obesidad (usar peso ajustado), masa corporal extrema y función renal cambiante; confirmar con depuración medida si el ajuste es crítico"
            ),
            tag = "ClCr (Cockcroft-Gault): " + CalcEngine.fmt(clcr) + " mL/min (" + CalcEngine.fmt(ageV) + " años, " +
                CalcEngine.fmt(wV) + " kg, Cr " + CalcEngine.fmt(crV) + " mg/dL" + (if (female) ", mujer" else "") + ")"
        )
    }
}

// ---- Volumen gástrico por ecografía (Perlas) — v2.7.0 ----

@Composable
fun PerlasCalc() {
    val sp = LocalSpacing.current
    var area by rememberSaveable { mutableStateOf("5.0") }
    var age by rememberSaveable { mutableStateOf("40") }
    var weight by rememberSaveable { mutableStateOf("70") }
    val aV = CalcEngine.parseNum(area)
    val ageV = CalcEngine.parseNum(age)
    val wV = CalcEngine.parseNum(weight)
    val vol = CalcEngine.gastricVolumePerlas(aV, ageV)
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            NumField3(area, { area = it }, "Área del antro (decúbito supino)", "cm²", Modifier.weight(1f))
            NumField3(age, { age = it }, "Edad", "años", Modifier.weight(1f))
        }
        NumField3(weight, { weight = it }, "Peso", "kg")
        ResultCard3(
            "Volumen gástrico estimado (fórmula de Perlas)",
            listOf(
                "Fórmula" to "V = 27,0 + 14,6 × ATG − 1,28 × edad",
                "Volumen estimado" to CalcEngine.fmt(vol) + " mL",
                "Riesgo (volumen/peso)" to CalcEngine.gastricRiskClass(vol, wV),
                "Cómo medir" to "Paciente en decúbito supino y luego lateral derecho: el antro entre el lóbulo izquierdo y la aorta, corte perpendicular; use el mayor diámetro anteroposterior y transverso (ATG = π × AP × T / 4)",
                "Conducta" to "Volumen alto o antro lleno en decúbito Y lateral: ayuno no confirmado → secuencia de inducción en intubación rápida, presión cricoidea según protocolo y evitar presión positiva sin vía aérea protegida"
            ),
            tag = "Ecografía gástrica (Perlas): " + CalcEngine.fmt(vol) + " mL (ATG " + CalcEngine.fmt(aV) +
                " cm², " + CalcEngine.fmt(ageV) + " años) — " + (if (wV > 0) CalcEngine.fmt(vol / wV) else "—") + " mL/kg"
        )
    }
}
