package cu.cronos.anestesia

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

// ============================== NAVEGACIÓN ==============================

private val DETAIL_TABS = setOf(1, 2, 3, 5, 6, 7, 8, 9, 12, 15, 17)

@Composable
private fun tabTitles(): List<String> = listOf(
    stringResource(R.string.tab_inicio), stringResource(R.string.tab_emergencias),
    stringResource(R.string.tab_farmacos), stringResource(R.string.tab_gases),
    stringResource(R.string.tab_calculadoras), stringResource(R.string.tab_escalas),
    stringResource(R.string.tab_complicaciones), stringResource(R.string.tab_premedicacion),
    stringResource(R.string.tab_soluciones), stringResource(R.string.tab_clinica),
    stringResource(R.string.tab_bibliografia), stringResource(R.string.tab_expediente),
    stringResource(R.string.tab_perlas), stringResource(R.string.tab_maquina),
    stringResource(R.string.tab_checklist), stringResource(R.string.tab_ajustes),
    stringResource(R.string.tab_temario), stringResource(R.string.tab_imagenes),
    stringResource(R.string.tab_escuela), stringResource(R.string.tab_tutor),
    stringResource(R.string.tab_crisis)
)

/** Versión del contenido clínico (contrato 10.1: visible al usuario). */
const val CONTENT_VERSION = "v3 · octubre 2026"

// Límites de contenido en modo demostración (sin licencia)
private const val DEMO_DRUGS = 10
private const val DEMO_COMPL = 4
private const val DEMO_SOL = 2
private const val DEMO_REFS = 3

private sealed interface Detail {
    data class DrugD(val i: Int) : Detail
    data class GasD(val i: Int) : Detail
    data class ScaleD(val i: Int) : Detail
    data class ComplD(val i: Int) : Detail
    data class PremedD(val i: Int) : Detail
    data class SolD(val i: Int) : Detail
}

@Composable
fun CronosApp(appVersion: String, initialTab: Int = 0) {
    var tab by rememberSaveable { mutableStateOf(initialTab) }
    var detail by rememberSaveable(
        tab
    ) { mutableStateOf<Int?>(null) } // índice dentro de la pestaña

    BackHandler(enabled = detail != null) { detail = null }

    val tabs = tabTitles()

    // Raíz con fondo a pantalla completa y respetando barras del sistema
    // (corrige las pestañas pegadas al borde superior: status bar inset).
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        // Sin aserción no nula: el índice se desenpaqueta de forma segura
        // (Fase 3 del plan de adecuación: corrección de detail!!).
        val detailIndex = detail
        if (detailIndex != null && tab in DETAIL_TABS) {
            DetailHost(
                tab = tab,
                index = detailIndex,
                appVersion = appVersion,
                onBack = { detail = null },
                onActivate = { tab = 15; detail = null }
            )
            return
        }

        ScrollableTabRow(
            selectedTabIndex = tab,
            edgePadding = 8.dp,
            containerColor = MaterialTheme.colorScheme.background,
            contentColor = MaterialTheme.colorScheme.primary
        ) {
            tabs.forEachIndexed { i, t ->
                Tab(
                    selected = tab == i,
                    onClick = { tab = i; detail = null },
                    text = {
                        Text(t, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                )
            }
        }
        // Licencia: gating de secciones según el nivel activo (v1.5.0)
        val lic = LocalLicense.current
        when (tab) {
            0 -> HomeTab(onGoTo = { tab = it; detail = null })
            1 -> EmergencyTab(onOpen = { detail = it }) // Emergencias: siempre libre (seguridad)
            2 -> DrugTab(onOpen = { detail = it }, onActivate = { tab = 15; detail = null })
            3 -> GasTab(onOpen = { detail = it })
            4 -> CalcTab(onActivate = { tab = 15; detail = null })
            5 -> ScaleTab(onOpen = { detail = it }, onActivate = { tab = 15; detail = null })
            6 -> ComplTab(onOpen = { detail = it }, onActivate = { tab = 15; detail = null })
            7 -> if (lic.features.premedAll) PremedTab(onOpen = { detail = it })
                else LockedSection(
                    stringResource(R.string.tab_premedicacion),
                    stringResource(R.string.lic_lock_premed_msg),
                    onActivate = { tab = 15; detail = null }
                )
            8 -> SolTab(onOpen = { detail = it }, onActivate = { tab = 15; detail = null })
            9 -> if (lic.features.clinic) ClinTab(onOpen = { detail = it })
                else LockedSection(
                    stringResource(R.string.tab_clinica),
                    stringResource(R.string.lic_lock_clinic_msg),
                    onActivate = { tab = 15; detail = null }
                )
            10 -> BiblioTab(onActivate = { tab = 15; detail = null })
            11 -> ExpedienteTab(onActivate = { tab = 15; detail = null })
            12 -> PearlsTab(onOpen = { detail = it })
            13 -> MachineTab(onActivate = { tab = 15; detail = null })
            14 -> ChecklistTab(onActivate = { tab = 15; detail = null })
            15 -> SettingsTab(appVersion, onOpenManual = { detail = 0 })
            16 -> TemarioTab()
            17 -> ArtGallery(onOpen = { detail = it })
            // v2.7.0 FIX: las pestañas Escuela (18) y Tutor (19) estaban sin despachar
            // en el when (pantalla en blanco); se corrigen en v2.8.0 junto con Crisis (20).
            18 -> if (lic.features.school) StudyTab()
                else LockedSection(
                    stringResource(R.string.tab_escuela),
                    stringResource(R.string.lic_lock_school_msg),
                    onActivate = { tab = 15; detail = null }
                )
            19 -> if (lic.features.tutor) TutorTab()
                else LockedSection(
                    stringResource(R.string.tab_tutor),
                    stringResource(R.string.lic_lock_tutor_msg),
                    onActivate = { tab = 15; detail = null }
                )
            20 -> if (lic.features.school) CrisisTab()
                else LockedSection(
                    stringResource(R.string.tab_crisis),
                    stringResource(R.string.lic_lock_school_msg),
                    onActivate = { tab = 15; detail = null }
                )
        }
    }
}

// ============================== INICIO ==============================

@Composable
private fun HomeTab(onGoTo: (Int) -> Unit) {
    val sp = LocalSpacing.current
    ScreenColumn {
        Spacer(Modifier.height(sp.xs.dp))
        Text(
            "Cronos Anestesia",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            stringResource(R.string.home_subtitle),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        // Estado de licencia (v1.5.0): toque lleva a Ajustes → Activación
        LicenseBadgeLine(onGoSettings = { onGoTo(15) })
        if (LocalLicense.current.tampered) TamperedBanner()
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer
            )
        ) {
            Text(
                stringResource(R.string.home_disclaimer),
                modifier = Modifier.padding(sp.m.dp),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }

        // EMERGENCIAS: acceso destacado en 1 toque (contrato 8.2: ≤2 toques)
        AppButton(
            stringResource(R.string.home_emergency_btn),
            danger = true,
            modifier = Modifier.fillMaxWidth(),
            onClick = { onGoTo(1) }
        )

        // Accesos rápidos: pares de botones de ancho idéntico
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            AppButton(stringResource(R.string.home_drugs_btn), secondary = true, modifier = Modifier.weight(1f), onClick = { onGoTo(2) })
            AppButton(stringResource(R.string.home_gases_btn), secondary = true, modifier = Modifier.weight(1f), onClick = { onGoTo(3) })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            AppButton(stringResource(R.string.home_calcs_btn), secondary = true, modifier = Modifier.weight(1f), onClick = { onGoTo(4) })
            AppButton(stringResource(R.string.home_scales_btn), secondary = true, modifier = Modifier.weight(1f), onClick = { onGoTo(5) })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            AppButton(stringResource(R.string.home_compl_btn), secondary = true, modifier = Modifier.weight(1f), onClick = { onGoTo(6) })
            AppButton(stringResource(R.string.home_premed_btn), secondary = true, modifier = Modifier.weight(1f), onClick = { onGoTo(7) })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            AppButton(stringResource(R.string.home_sol_btn), secondary = true, modifier = Modifier.weight(1f), onClick = { onGoTo(8) })
            AppButton(stringResource(R.string.home_clin_btn), secondary = true, modifier = Modifier.weight(1f), onClick = { onGoTo(9) })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            AppButton(stringResource(R.string.home_expediente_btn), secondary = true, modifier = Modifier.weight(1f), onClick = { onGoTo(11) })
            AppButton(stringResource(R.string.home_perlas_btn), secondary = true, modifier = Modifier.weight(1f), onClick = { onGoTo(12) })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            AppButton(stringResource(R.string.home_maquina_btn), secondary = true, modifier = Modifier.weight(1f), onClick = { onGoTo(13) })
            AppButton(stringResource(R.string.home_checklist_btn), secondary = true, modifier = Modifier.weight(1f), onClick = { onGoTo(14) })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            AppButton(stringResource(R.string.home_temario_btn), secondary = true, modifier = Modifier.weight(1f), onClick = { onGoTo(16) })
            AppButton(stringResource(R.string.home_img_btn), secondary = true, modifier = Modifier.weight(1f), onClick = { onGoTo(17) })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            AppButton(stringResource(R.string.home_escuela_btn), secondary = true, modifier = Modifier.weight(1f), onClick = { onGoTo(18) })
            AppButton(stringResource(R.string.home_tutor_btn), secondary = true, modifier = Modifier.weight(1f), onClick = { onGoTo(19) })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            AppButton(stringResource(R.string.home_crisis_btn), secondary = true, modifier = Modifier.fillMaxWidth(), onClick = { onGoTo(20) })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            AppButton(stringResource(R.string.home_biblio_btn), secondary = true, modifier = Modifier.weight(1f), onClick = { onGoTo(10) })
            AppButton(stringResource(R.string.home_settings_btn), secondary = true, modifier = Modifier.weight(1f), onClick = { onGoTo(15) })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            AppButton(stringResource(R.string.home_temario_btn), secondary = true, modifier = Modifier.weight(1f), onClick = { onGoTo(16) })
            AppButton(stringResource(R.string.home_img_btn), secondary = true, modifier = Modifier.weight(1f), onClick = { onGoTo(17) })
        }

        Text(
            stringResource(R.string.home_offline_note),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// ============================== FÁRMACOS ==============================

@Composable
private fun SearchField(value: String, onChange: (String) -> Unit, hint: String) {
    val sp = LocalSpacing.current
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        placeholder = { Text(hint) },
        shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.primary,
            cursorColor = MaterialTheme.colorScheme.primary
        )
    )
}

@Composable
private fun DrugTab(onOpen: (Int) -> Unit, onActivate: () -> Unit) {
    val sp = LocalSpacing.current
    var query by rememberSaveable { mutableStateOf("") }
    var mode by rememberSaveable { mutableStateOf(0) } // 0 = fichas, 1 = presentaciones (v2.4.0)
    val lic = LocalLicense.current
    val limit = if (lic.features.drugsAll) DRUGS.size else DEMO_DRUGS
    val presLimit = if (lic.features.drugsAll) DRUG_PRESENTATIONS.size else 3
    val filtered = remember(query, limit) {
        val base = if (query.isBlank()) DRUGS.indices.toList()
        else DRUGS.withIndex().filter { (_, d) ->
            val q = query.trim().lowercase()
            d.name.lowercase().contains(q) || d.cls.lowercase().contains(q) ||
                d.indications.lowercase().contains(q)
        }.map { it.index }
        base.take(limit)
    }
    val presFiltered = remember(query, presLimit) {
        val base = if (query.isBlank()) DRUG_PRESENTATIONS.indices.toList()
        else DRUG_PRESENTATIONS.withIndex().filter { (_, p) ->
            val q = query.trim().lowercase()
            p.drug.lowercase().contains(q) || p.forms.lowercase().contains(q)
        }.map { it.index }
        base.take(presLimit)
    }
    Column(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = sp.screenHPad.dp)) {
            Spacer(Modifier.height(sp.s.dp))
            SearchField(query, { query = it }, stringResource(R.string.search_drugs_hint))
            Spacer(Modifier.height(sp.xs.dp))
            SegmentedRow(
                listOf(stringResource(R.string.drugs_mode_fichas), stringResource(R.string.drugs_mode_presentaciones)),
                selected = mode, onSelect = { mode = it }
            )
            Spacer(Modifier.height(sp.s.dp))
        }
        if (mode == 1) {
            // Presentaciones de fármacos (v2.4.0)
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(
                    horizontal = sp.screenHPad.dp, vertical = sp.xs.dp
                ),
                verticalArrangement = Arrangement.spacedBy(sp.xs.dp)
            ) {
                items(presFiltered, key = { 1000 + it }) { i ->
                    val p = DRUG_PRESENTATIONS[i]
                    ItemCard(
                        title = p.drug,
                        subtitle = stringResource(R.string.sub_presentacion),
                        badge = null,
                        onClick = { onOpen(1000 + i) }
                    )
                }
                if (presFiltered.isEmpty()) {
                    item {
                        Text(
                            stringResource(R.string.no_results, query),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(sp.m.dp)
                        )
                    }
                }
                if (presLimit < DRUG_PRESENTATIONS.size) {
                    item {
                        LockedInlineCard(
                            stringResource(R.string.lic_demo_more_pres),
                            stringResource(R.string.lic_demo_more_msg),
                            onActivate
                        )
                    }
                }
            }
            return
        }
        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(
                horizontal = sp.screenHPad.dp, vertical = sp.xs.dp
            ),
            verticalArrangement = Arrangement.spacedBy(sp.xs.dp)
        ) {
            items(filtered, key = { it }) { i ->
                val d = DRUGS[i]
                ItemCard(
                    title = d.name,
                    subtitle = d.cls,
                    badge = null,
                    onClick = { onOpen(i) }
                )
            }
            if (filtered.isEmpty()) {
                item {
                    Text(
                        stringResource(R.string.no_results, query),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(sp.m.dp)
                    )
                }
            }
            if (limit < DRUGS.size) {
                item {
                    LockedInlineCard(
                        stringResource(R.string.lic_demo_more_drugs),
                        stringResource(R.string.lic_demo_more_msg),
                        onActivate
                    )
                }
            }
        }
    }
}

// ============================== GASES ==============================

@Composable
private fun GasTab(onOpen: (Int) -> Unit) {
    val sp = LocalSpacing.current
    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(
            horizontal = sp.screenHPad.dp, vertical = sp.s.dp
        ),
        verticalArrangement = Arrangement.spacedBy(sp.xs.dp)
    ) {
        items(GASES.size) { i ->
            val g = GASES[i]
            ItemCard(title = g.name, subtitle = g.mac, onClick = { onOpen(i) })
        }
    }
}

// ============================== COMPLICACIONES ==============================

@Composable
private fun ComplTab(onOpen: (Int) -> Unit, onActivate: () -> Unit) {
    val sp = LocalSpacing.current
    val lic = LocalLicense.current
    val count = if (lic.features.complAll) COMPLICATIONS.size else DEMO_COMPL
    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(
            horizontal = sp.screenHPad.dp, vertical = sp.s.dp
        ),
        verticalArrangement = Arrangement.spacedBy(sp.xs.dp)
    ) {
        items(count) { i ->
            ItemCard(title = COMPLICATIONS[i].name, subtitle = stringResource(R.string.sub_manejo_y_reconocimiento), onClick = { onOpen(i) })
        }
        if (count < COMPLICATIONS.size) {
            item {
                LockedInlineCard(
                    stringResource(R.string.lic_lock_compl_title),
                    stringResource(R.string.lic_lock_compl_msg),
                    onActivate
                )
            }
        }
    }
}

// ============================== PREMEDICACIÓN ==============================

@Composable
private fun PremedTab(onOpen: (Int) -> Unit) {
    val sp = LocalSpacing.current
    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(
            horizontal = sp.screenHPad.dp, vertical = sp.s.dp
        ),
        verticalArrangement = Arrangement.spacedBy(sp.xs.dp)
    ) {
        items(PREMED_TOPICS.size) { i ->
            ItemCard(title = PREMED_TOPICS[i].title, subtitle = stringResource(R.string.sub_premedicacion), onClick = { onOpen(i) })
        }
    }
}

// ============================== SOLUCIONES ==============================

@Composable
private fun SolTab(onOpen: (Int) -> Unit, onActivate: () -> Unit) {
    val sp = LocalSpacing.current
    val lic = LocalLicense.current
    val count = if (lic.features.solAll) SOLUTIONS.size else DEMO_SOL
    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(
            horizontal = sp.screenHPad.dp, vertical = sp.s.dp
        ),
        verticalArrangement = Arrangement.spacedBy(sp.xs.dp)
    ) {
        items(count) { i ->
            ItemCard(title = SOLUTIONS[i].title, subtitle = stringResource(R.string.sub_fluidoterapia), onClick = { onOpen(i) })
        }
        if (count < SOLUTIONS.size) {
            item {
                LockedInlineCard(
                    stringResource(R.string.lic_lock_sol_title),
                    stringResource(R.string.lic_lock_sol_msg),
                    onActivate
                )
            }
        }
    }
}

// ============================== BIBLIOGRAFÍA ==============================

@Composable
private fun BiblioTab(onActivate: () -> Unit) {
    val sp = LocalSpacing.current
    val lic = LocalLicense.current
    val count = if (lic.features.refsAll) BIBLIO.size else DEMO_REFS
    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(
            horizontal = sp.screenHPad.dp, vertical = sp.s.dp
        ),
        verticalArrangement = Arrangement.spacedBy(sp.xs.dp)
    ) {
        items(count) { i ->
            val b = BIBLIO[i]
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(sp.m.dp)) {
                    Text(
                        b.title,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        b.detail,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        if (count < BIBLIO.size) {
            item {
                LockedInlineCard(
                    stringResource(R.string.lic_lock_refs_title),
                    stringResource(R.string.lic_lock_refs_msg),
                    onActivate
                )
            }
        }
        item {
            Text(
                "Ediciones citadas a solicitud del usuario; verifique la disponibilidad local.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = sp.xs.dp)
            )
        }
    }
}

// ============================== DETALLES ==============================

// (la versión de la app se calcula en MainActivity y se pasa como parámetro)

@Composable
private fun DetailHost(tab: Int, index: Int, appVersion: String, onBack: () -> Unit, onActivate: () -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        when (tab) {
            1 -> {
                EmergencyDetail(index = index, onBack = onBack)
            }
            2 -> {
                if (index >= 1000) {
                    // Presentación de fármaco (v2.4.0): índices 1000+
                    val pi = index - 1000
                    val pr = DRUG_PRESENTATIONS[pi]
                    DetailTopBar(pr.drug, stringResource(R.string.sub_presentacion), onBack)
                    ScreenColumn {
                        SectionLabel(stringResource(R.string.pres_forms))
                        BodyText(pr.forms)
                        SectionLabel(stringResource(R.string.pres_draw))
                        BodyText(pr.draw)
                        if (pr.note.isNotBlank()) {
                            SectionLabel(stringResource(R.string.pres_note))
                            BodyText(pr.note)
                        }
                        SectionLabel(stringResource(R.string.pres_convert_title))
                        PresConvertCalc(pr.drug)
                        SectionLabel(stringResource(R.string.sec_verificar))
                        BodyText(stringResource(R.string.pres_verify))
                    }
                } else {
                    val d = DRUGS[index]
                    DetailTopBar(d.name, d.cls, onBack)
                ScreenColumn {
                    // «Dosis calculada» requiere licencia Básica o superior (v1.5.0)
                    if (LocalLicense.current.features.doseCalc) {
                        SectionLabel(stringResource(R.string.sec_dosis_calculada))
                        DrugDoseCalc(d.name)
                    } else {
                        LockedInlineCard(
                            stringResource(R.string.lic_lock_dose_title),
                            stringResource(R.string.lic_lock_dose_msg),
                            onActivate
                        )
                    }
                    SectionLabel(stringResource(R.string.sec_dosificacion))
                    BodyText(d.dose)
                    SectionLabel(stringResource(R.string.sec_indicaciones))
                    BodyText(d.indications)
                    SectionLabel(stringResource(R.string.sec_precauciones))
                        BodyText(d.cautions)
                    }
                }
            }
            3 -> {
                val g = GASES[index]
                DetailTopBar(g.name, stringResource(R.string.sub_gases), onBack)
                ScreenColumn {
                    SectionLabel(stringResource(R.string.sec_mac))
                    BodyText(g.mac)
                    SectionLabel(stringResource(R.string.sec_propiedades))
                    BodyText(g.props)
                    SectionLabel(stringResource(R.string.sec_uso_advertencias))
                    BodyText(g.notes)
                    if (g.warnings.isNotBlank()) {
                        SectionLabel(stringResource(R.string.sec_riesgos))
                        BodyText(g.warnings)
                    }
                }
            }
            5 -> {
                ScaleDetail(index = index, onBack = onBack)
            }
            6 -> {
                val c = COMPLICATIONS[index]
                DetailTopBar(c.name, stringResource(R.string.sub_complicaciones), onBack)
                ScreenColumn {
                    SectionLabel(stringResource(R.string.sec_reconocimiento))
                    BodyText(c.recognition)
                    SectionLabel(stringResource(R.string.sec_manejo))
                    BodyText(c.management)
                }
            }
            7 -> {
                val t = PREMED_TOPICS[index]
                DetailTopBar(t.title, stringResource(R.string.sub_premedicacion), onBack)
                ScreenColumn { BodyText(t.body) }
            }
            8 -> {
                val t = SOLUTIONS[index]
                DetailTopBar(t.title, stringResource(R.string.sub_soluciones), onBack)
                ScreenColumn { BodyText(t.body) }
            }
            9 -> {
                ClinDetail(index = index, onBack = onBack)
            }
            12 -> {
                PearlDetail(index = index, onBack = onBack)
            }
            15 -> {
                ManualDetail(onBack = onBack)
            }
            17 -> {
                ArtDetail(index = index, onBack = onBack)
            }
        }
    }
}
