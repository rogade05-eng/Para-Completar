package cu.cronos.anestesia

/*
 * ============================================================================
 *  SIMULADOR DE CRISIS v2.8.0 — UI (pestaña «Crisis»)
 *  Flujo: lista de escenarios → viñeta inicial → puntos de decisión con
 *  retroalimentación calificada (3/2/1/0) → informe final (debriefing) con
 *  puntaje, tiempo, puntos clave, dosis críticas y referencias.
 *  Progreso local por escenario (SharedPreferences, CrisisEngine).
 *  Todos los literales pasan por .tr() (traducción completa v2.8.0).
 * ============================================================================
 */

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

// ------------------------------ COLORES POR CALIFICACIÓN ------------------------------

private fun gradeColor(grade: Int): Color = when (grade) {
    CrisisEngine.GRADE_CORRECT -> Color(0xFF2E7D32)      // verde: correcta
    CrisisEngine.GRADE_ACCEPTABLE -> Color(0xFF00838F)   // teal: aceptable
    CrisisEngine.GRADE_SUBOPT -> Color(0xFFB26A00)       // ámbar: subóptima
    else -> Color(0xFFB3261E)                            // rojo: peligrosa
}

private fun gradeLabel(grade: Int): String = when (grade) {
    CrisisEngine.GRADE_CORRECT -> "Correcto".tr()
    CrisisEngine.GRADE_ACCEPTABLE -> "Aceptable".tr()
    CrisisEngine.GRADE_SUBOPT -> "Subóptimo".tr()
    else -> "Peligroso".tr()
}

private fun fmtTime(totalSec: Int): String {
    val m = totalSec / 60
    val s = totalSec % 60
    return "%d:%02d min".tr().format(m, s)
}

// ------------------------------ PESTAÑA RAÍZ ------------------------------

@Composable
fun CrisisTab() {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    var openId by rememberSaveable { mutableStateOf<String?>(null) }

    val scenario = openId?.let { id -> CRISIS_SCENARIOS.firstOrNull { it.id == id } }
    if (scenario != null) {
        CrisisRunScreen(scenario = scenario, onBack = { openId = null })
        return
    }

    val done = CrisisEngine.scenariosAttempted(ctx)
    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = sp.screenHPad.dp)
            .padding(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(sp.s.dp)
    ) {
        Spacer(Modifier.height(sp.xs.dp))
        val intro1 = "Simulador de crisis — %1\$d escenarios de decisión clínica con puntuación, informe final (debriefing) y progreso local.".tr().format(CRISIS_SCENARIOS.size)
        val intro2 = "Progreso: %1\$d/%2\$d completados.".tr().format(done, CRISIS_SCENARIOS.size)
        Text(
            "$intro1 $intro2",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        CRISIS_SCENARIOS.forEach { sc ->
            val best = CrisisEngine.bestScore(ctx, sc.id)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { openId = sc.id },
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(sp.m.dp)) {
                    Text(sc.title.tr(), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(2.dp))
                    Text(
                        "${sc.category.tr()} · ${sc.level} · ${sc.steps.size} ${"puntos de decisión".tr()} · " +
                            if (best != null) "mejor resultado %1\$d%% en %2\$s".tr().format(best.first, fmtTime(best.second))
                            else "sin correr".tr(),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(sc.subtitle.tr(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

// ------------------------------ EJECUCIÓN DEL ESCENARIO ------------------------------

@Composable
private fun CrisisRunScreen(scenario: CrisisScenario, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var phase by rememberSaveable { mutableStateOf(0) }        // 0 viñeta · 1 pasos · 2 informe
    var step by rememberSaveable { mutableStateOf(0) }
    var chosen by rememberSaveable { mutableStateOf(-1) }      // opción elegida (-1 = ninguna)
    var score by rememberSaveable { mutableStateOf(0) }
    var startMs by rememberSaveable { mutableStateOf(0L) }
    var elapsedSec by rememberSaveable { mutableStateOf(0) }

    when (phase) {
        0 -> CrisisIntroScreen(sc = scenario, onStart = {
            startMs = System.currentTimeMillis()
            step = 0; chosen = -1; score = 0
            phase = 1
        }, onBack = onBack)
        1 -> {
            val s = scenario.steps[step]
            CrisisStepScreen(
                scenario = scenario,
                stepIndex = step,
                st = s,
                chosen = chosen,
                onChoose = { i ->
                    if (chosen < 0) {
                        chosen = i
                        score += s.options[i].grade
                    }
                },
                onNext = {
                    if (step + 1 >= scenario.steps.size) {
                        elapsedSec = ((System.currentTimeMillis() - startMs) / 1000).toInt()
                        val pct = (score * 100) / scenario.maxScore
                        CrisisEngine.saveProgress(ctx, scenario.id, pct, elapsedSec)
                        phase = 2
                    } else {
                        step += 1
                        chosen = -1
                    }
                },
                onBack = onBack
            )
        }
        else -> CrisisDebriefScreen(
            sc = scenario,
            score = score,
            elapsedSec = elapsedSec,
            onRetry = {
                step = 0; chosen = -1; score = 0
                startMs = System.currentTimeMillis()
                phase = 1
            },
            onBack = onBack
        )
    }
}

// ------------------------------ VIÑETA INICIAL ------------------------------

@Composable
private fun CrisisIntroScreen(sc: CrisisScenario, onStart: () -> Unit, onBack: () -> Unit) {
    val sp = LocalSpacing.current
    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = sp.screenHPad.dp)
            .padding(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(sp.s.dp)
    ) {
        DetailTopBar(sc.title.tr(), null, onBack)
        Text(
            "${sc.subtitle.tr()} · ${sc.category.tr()} · ${sc.level}",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            "Viñeta inicial".tr(),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )
        Text(sc.intro.tr(), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
        MonitorStrip(sc.monitor.tr())
        Text(
            "Objetivo: manejar la crisis eligiendo la mejor conducta en cada punto de decisión. " +
                "Cada elección se califica (correcta, aceptable, subóptima o peligrosa) y al final " +
                "recibirás el informe con dosis críticas y puntos clave.".tr(),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        AppButton("Iniciar simulación (%1\$d puntos de decisión)".tr().format(sc.steps.size), onClick = onStart)
    }
}

// ------------------------------ PASO DE DECISIÓN ------------------------------

@Composable
private fun CrisisStepScreen(
    scenario: CrisisScenario,
    stepIndex: Int,
    st: CrisisStep,
    chosen: Int,
    onChoose: (Int) -> Unit,
    onNext: () -> Unit,
    onBack: () -> Unit
) {
    val sp = LocalSpacing.current
    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = sp.screenHPad.dp)
            .padding(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(sp.s.dp)
    ) {
        DetailTopBar(
            scenario.title.tr(),
            "Pregunta %1\$d de %2\$d".tr().format(stepIndex + 1, scenario.steps.size),
            onBack
        )
        Text(
            "Situación".tr(),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )
        Text(st.situation.tr(), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
        MonitorStrip(st.monitor.tr())

        st.options.forEachIndexed { i, opt ->
            val isChosen = chosen == i
            val revealed = chosen >= 0
            val c = gradeColor(opt.grade)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(enabled = !revealed) { onChoose(i) },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = when {
                        revealed && isChosen -> c.copy(alpha = 0.16f)
                        else -> MaterialTheme.colorScheme.surface
                    }
                ),
                border = if (revealed && isChosen) androidx.compose.foundation.BorderStroke(1.dp, c) else null
            ) {
                Column(Modifier.padding(sp.m.dp)) {
                    Row(verticalAlignment = Alignment.Top) {
                        Text(
                            "${"ABCD"[i]} · ",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(opt.text.tr(), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
                    }
                    if (revealed && isChosen) {
                        Spacer(Modifier.height(6.dp))
                        Text(
                            gradeLabel(opt.grade),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = c
                        )
                        Text(opt.feedback.tr(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }

        if (chosen >= 0) {
            AppButton(
                if (stepIndex + 1 >= scenario.steps.size) "Ver informe final".tr() else "Continuar".tr(),
                onClick = onNext
            )
        }
    }
}

// ------------------------------ INFORME FINAL (DEBRIEFING) ------------------------------

@Composable
private fun CrisisDebriefScreen(
    sc: CrisisScenario,
    score: Int,
    elapsedSec: Int,
    onRetry: () -> Unit,
    onBack: () -> Unit
) {
    val sp = LocalSpacing.current
    val pct = (score * 100) / sc.maxScore
    val rating = CrisisEngine.rating(pct)
    val ratingText = when (rating) {
        3 -> "Desempeño de experto — manejo guía".tr()
        2 -> "Seguro, con demoras corregibles".tr()
        1 -> "Con riesgos evitables: repasa el informe".tr()
        else -> "Repaso urgente antes de la próxima guardia".tr()
    }
    val ratingColor = when (rating) {
        3 -> gradeColor(CrisisEngine.GRADE_CORRECT)
        2 -> gradeColor(CrisisEngine.GRADE_ACCEPTABLE)
        1 -> gradeColor(CrisisEngine.GRADE_SUBOPT)
        else -> gradeColor(CrisisEngine.GRADE_DANGEROUS)
    }
    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = sp.screenHPad.dp)
            .padding(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(sp.s.dp)
    ) {
        DetailTopBar(sc.title.tr(), null, onBack)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(sp.m.dp)) {
                Text(
                    "Puntaje: %1\$d / %2\$d (%3\$d%%)".tr().format(score, sc.maxScore, pct),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = ratingColor
                )
                Text(ratingText, style = MaterialTheme.typography.bodyMedium, color = ratingColor)
                Text(
                    "Tiempo empleado: %1\$s".tr().format(fmtTime(elapsedSec)),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Text(
            "Puntos clave del cierre".tr(),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )
        sc.debrief.forEach {
            Text("•  ${it.tr()}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
        }
        Text(
            "Dosis críticas".tr(),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )
        sc.doses.forEach {
            Text("•  ${it.tr()}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
        }
        Text(
            "Referencias: ".tr() + sc.refs.tr(),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            AppButton("Repetir escenario".tr(), secondary = true, modifier = Modifier.weight(1f), onClick = onRetry)
            AppButton("Volver a la lista".tr(), modifier = Modifier.weight(1f), onClick = onBack)
        }
    }
}

// ------------------------------ MONITOR ------------------------------

@Composable
private fun MonitorStrip(text: String) {
    val sp = LocalSpacing.current
    Text(
        text,
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
            .padding(sp.s.dp),
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary
    )
}
