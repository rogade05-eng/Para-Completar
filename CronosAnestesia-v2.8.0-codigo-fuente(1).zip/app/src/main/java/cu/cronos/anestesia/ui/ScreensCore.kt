// Cronos Anestesia — Pantallas: Paciente, Ayuno y fluidos
package cu.cronos.anestesia.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import cu.cronos.anestesia.engine.DerivedWeights
import cu.cronos.anestesia.engine.FASTING_RULES
import cu.cronos.anestesia.engine.PatientState
import cu.cronos.anestesia.engine.derive
import cu.cronos.anestesia.engine.fastingLimit
import cu.cronos.anestesia.engine.fmt
import cu.cronos.anestesia.engine.hollidaySegar

@Composable
fun PacienteScreen(patient: PatientState, derived: DerivedWeights, onPatient: (PatientState) -> Unit) {
    val sp = LocalSpacing.current
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(sp.m),
    ) {
        SectionCard("Datos del paciente") {
            LabeledField("Peso", fmt(patient.weight), { v -> onPatient(patient.copy(weight = v.toDoubleOrNull() ?: 0.0)) }, "kg")
            if (!derived.isPeds) {
                LabeledField("Talla", fmt(patient.height), { v -> onPatient(patient.copy(height = v.toDoubleOrNull() ?: 0.0)) }, "cm")
            } else {
                LabeledField("Talla (opcional)", fmt(patient.height), { v -> onPatient(patient.copy(height = v.toDoubleOrNull() ?: 0.0)) }, "cm")
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(sp.xs)) {
                // Unidad de edad
                CronosButton("Años", { onPatient(patient.copy(ageUnit = "anios")) }, Modifier.weight(1f), enabled = patient.ageUnit != "anios")
                CronosButton("Meses", { onPatient(patient.copy(ageUnit = "meses")) }, Modifier.weight(1f), enabled = patient.ageUnit != "meses")
            }
            LabeledField(
                if (patient.ageUnit == "anios") "Edad" else "Edad (meses)",
                fmt(patient.ageValue),
                { v -> onPatient(patient.copy(ageValue = v.toDoubleOrNull() ?: 0.0)) },
                if (patient.ageUnit == "anios") "años" else "meses",
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(sp.s)) {
                CronosButton("Masculino", { onPatient(patient.copy(sex = "m")) }, Modifier.weight(1f), enabled = patient.sex != "m")
                CronosButton("Femenino", { onPatient(patient.copy(sex = "f")) }, Modifier.weight(1f), enabled = patient.sex != "f")
            }
        }

        SectionCard("Pesos derivados y volémicos") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(sp.s)) {
                StatBox("IMC", fmt(derived.bmi), "kg/m²", Modifier.weight(1f))
                StatBox("SC (Mosteller)", fmt(derived.bsa), "m²", Modifier.weight(1f))
            }
            if (!derived.isPeds) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(sp.s)) {
                    StatBox("Peso ideal (Devine)", fmt(derived.ibw), "kg", Modifier.weight(1f))
                    StatBox("Peso magro (Janmahasatian)", fmt(derived.lbw), "kg", Modifier.weight(1f))
                }
            }
            Text(
                "Volemia estimada: ${derived.volemiaMl} mL (${if (patient.ageMonths <= 24) "90" else if (patient.ageMonths <= 144) "80" else "70"} mL/kg)",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (derived.isPeds) {
                Text(
                    "Modo pediátrico activo (edad < 18 años): dosis y fluidos ajustados por peso; talla opcional.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }

        Text(
            "Los cálculos de fármacos, infusiones, gases y fluidos usan automáticamente estos datos.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        SourceNote("smith")
    }
}

// pequeño auxiliar de espaciado
private val SP2 = 2.dp

@Composable
fun FluidosScreen(patient: PatientState) {
    val sp = LocalSpacing.current
    var hora by remember { mutableStateOf("07:30") }
    var npo by remember { mutableStateOf("8") }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(sp.m),
    ) {
        SectionCard("Ayuno preoperatorio (ASA 2-4-6-8)") {
            LabeledField("Hora quirúrgica (24 h)", hora, { hora = it })
            LabeledField("Horas transcurridas sin ingesta", npo, { npo = it })
            val horasTranscurridas = npo.toDoubleOrNull() ?: 0.0
            FASTING_RULES.forEach { rule ->
                val limite = fastingLimit(parseHora(hora), rule.hours)
                val ok = horasTranscurridas >= rule.hours
                KeyValueRow(
                    rule.item,
                    java.lang.String.format(java.util.Locale.US, "%02d:00", limite) + " · " + if (ok) "CUMPLE" else "NO cumple",
                )
            }
            Text(
                "Regla mnemotécnica ASA: 2 h líquidos claros · 4 h leche materna · 6 h leche/fórmula y comida ligera · 8 h comida pesada.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            SourceNote("morgan")
        }

        SectionCard("Hidratación transoperatoria (Holliday-Segar 4-2-1)") {
            val hid = hollidaySegar(patient.weight)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(sp.s)) {
                StatBox("Mantenimiento", "${hid.mlH}", "mL/h", Modifier.weight(1f))
                StatBox("Volumen 24 h", "${hid.mlDay}", "mL/día", Modifier.weight(1f))
            }
            val deficitPorHora = hid.mlH
            Text(
                "Déficit aproximado por ayuno: ${npo.toDoubleOrNull()?.let { (it * deficitPorHora).toInt() } ?: 0} mL (${npo} h × ${deficitPorHora} mL/h). Reposición habitual: mitad en la 1.ª hora y el resto en 2–3 h.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            SourceNote("smith")
        }

        SectionCard("Soluciones parenterales habituales") {
            SOLUTIONS_TABLE.forEach { s ->
                Text(s.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                KeyValueRow("Tipo", s.osm)
                KeyValueRow("Indicaciones", s.use)
                if (s.caution.isNotEmpty()) {
                    Text("⚠ ${s.caution}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

private val SOLUTIONS_TABLE = listOf(
    SimpleSol("Solución salina 0.9 % (SSN)", "Isotónica · Na+ 154 mmol/L", "Volumen inicial, dilución de fármacos", "Acidosis hiperclorémica con volúmenes grandes"),
    SimpleSol("Glucosado 5 % (SG5 %)", "Hipotónica libre de electrolitos", "Vehículo de drogas (amiodarona), neonatos", "No expande volumen eficaz; hiponatremia"),
    SimpleSol("Ringer lactato (Hartmann)", "Isotónica balanceada", "Reposición de pérdidas, cirugía abdominal", "Evitar en insuficiencia hepática severa"),
    SimpleSol("Glucosado-salina 5 % + 0.45 %", "Isotónica mixta", "Mantenimiento pediátrico con aporte calórico", "Vigilar glucemia"),
    SimpleSol("Manitol 20 %", "Hipertónica osmótica", "Reducción de PIC, protección renal puntual", "Diuresis osmótica: reponer electrolitos"),
)

private data class SimpleSol(val name: String, val osm: String, val use: String, val caution: String)

private fun parseHora(h: String): Int {
    val parts = h.split(":")
    return (parts.getOrNull(0)?.toIntOrNull() ?: 7).coerceIn(0, 23)
}
