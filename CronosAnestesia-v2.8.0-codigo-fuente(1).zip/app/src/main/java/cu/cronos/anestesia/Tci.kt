package cu.cronos.anestesia

/*
 * ============================================================================
 *  TCI (v2.6) — Motor de perfusión objetivo para la calculadora de Pumps.kt.
 *
 *  Puente sobre los modelos farmacocinéticos de CalcEngine (Pk3):
 *   · Marsh (propofol, por peso)  · Schnider (propofol, edad/talla/sexo)
 *   · Minto (remifentanilo, LBM).
 *
 *  Unidades de trabajo (coherentes entre sí):
 *   · propofol: diana en µg/mL (= mg/L) y masas en mg.
 *   · remifentanilo: diana en ng/mL (= µg/L) y masas en µg.
 * ============================================================================
 */

object Tci {

    /** Parámetros reducidos para la UI: V1, aclaramiento central, ke0 y LBM (0 = no aplica). */
    data class TciParams(
        val v1: Double,      // L
        val cl1: Double,     // L/min
        val ke0: Double,     // 1/min
        val lbw: Double,     // kg (0 si el modelo no lo usa)
        val pk: CalcEngine.Pk3
    )

    /** Punto del perfil simulado: t (min), Cp, Ce (en la unidad de la diana) y velocidad (masa/min). */
    data class TciStep(val tMin: Double, val cp: Double, val ce: Double, val rateMgMin: Double)

    /** Resultado de la simulación a 30 min. */
    data class TciSim(
        val bolusMg: Double,
        val rate0MgMin: Double,
        val timeToCe90Min: Double,
        val cum30Mg: Double,
        val maxCp: Double,
        val steps: List<TciStep>
    )

    fun marsh(weightKg: Double): TciParams {
        val p = CalcEngine.marshPropofol(weightKg)
        return TciParams(p.v1, p.clearanceLMin, p.ke0, 0.0, p)
    }

    fun schnider(ageYears: Double, weightKg: Double, heightCm: Double, male: Boolean): TciParams {
        val p = CalcEngine.schniderPropofol(ageYears, weightKg, heightCm, male)
        return TciParams(p.v1, p.clearanceLMin, p.ke0, CalcEngine.leanBodyMass(weightKg, heightCm, male), p)
    }

    fun minto(ageYears: Double, weightKg: Double, heightCm: Double, male: Boolean): TciParams {
        val p = CalcEngine.mintoRemifentanil(ageYears, weightKg, heightCm, male)
        return TciParams(p.v1, p.clearanceLMin, p.ke0, CalcEngine.leanBodyMass(weightKg, heightCm, male), p)
    }

    /** Velocidad de mantenimiento para Cp = diana: r = diana × Cl1 (masa/min). */
    fun maintenanceMgMin(p: TciParams, target: Double): Double = target * p.cl1

    /**
     * Simula 30 min con integración de Euler (dt = 0,02 min).
     *  · Modo plasma: esquema BET (bolo = diana·V1 y r(t) BET) → Cp ≈ diana sin overshoot.
     *  · Modo efecto: bolo mayor (2 × diana·V1, el límite que anuncia la UI) +
     *    mantenimiento plano (diana·Cl1) → Ce asciende más rápido.
     */
    fun simulate(p: TciParams, target: Double, effectSite: Boolean): TciSim {
        require(target > 0.0) { "diana inválida" }
        val pk = p.pk
        val bolus = target * p.v1 * if (effectSite) 2.0 else 1.0
        fun betRate(tMin: Double): Double =
            target * p.v1 * (pk.k10 + pk.k12 * kotlin.math.exp(-pk.k21 * tMin) +
                pk.k13 * kotlin.math.exp(-pk.k31 * tMin))
        fun rate(tMin: Double): Double = if (effectSite) target * p.cl1 else betRate(tMin)

        val dt = 0.02
        val sampleTimes = doubleArrayOf(0.0, 1.0, 2.0, 5.0, 10.0, 15.0, 20.0, 30.0)
        val steps = ArrayList<TciStep>(sampleTimes.size)
        var sampleIdx = 0

        var ac = bolus
        var ap2 = 0.0
        var ap3 = 0.0
        var ce = 0.0
        var t = 0.0
        var maxCp = if (p.v1 > 0) ac / p.v1 else 0.0
        var cum = bolus
        val rate0 = rate(0.0)

        fun sample(now: Double) {
            while (sampleIdx < sampleTimes.size && now >= sampleTimes[sampleIdx] - 1e-9) {
                val st = sampleTimes[sampleIdx]
                val r = if (st == 0.0) rate0 else rate(st)
                steps.add(TciStep(st, ac / p.v1, ce, r))
                sampleIdx++
            }
        }
        sample(0.0)
        while (t < 30.0) {
            val r = rate(t)
            val cp = ac / p.v1
            val dCentral = r - (pk.k10 + pk.k12 + pk.k13) * ac + pk.k21 * ap2 + pk.k31 * ap3
            val dP2 = pk.k12 * ac - pk.k21 * ap2
            val dP3 = pk.k13 * ac - pk.k31 * ap3
            val dCe = pk.ke0 * (cp - ce)
            ac += dCentral * dt; ap2 += dP2 * dt; ap3 += dP3 * dt
            ce += dCe * dt; cum += r * dt
            t += dt
            val cpNow = ac / p.v1
            if (cpNow > maxCp) maxCp = cpNow
            sample(t)
        }
        return TciSim(
            bolusMg = bolus,
            rate0MgMin = rate0,
            timeToCe90Min = kotlin.math.ln(10.0) / pk.ke0,
            cum30Mg = cum,
            maxCp = maxCp,
            steps = steps
        )
    }
}
