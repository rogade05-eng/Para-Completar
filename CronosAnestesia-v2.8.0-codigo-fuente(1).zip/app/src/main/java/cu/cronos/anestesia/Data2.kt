package cu.cronos.anestesia

// ------------------------------- ESCALAS (16 en 6 grupos, v2.1.0) -------------------------------
// Grupos: Valoración preoperatoria · Vía aérea · Sedación y conciencia ·
//         Dolor · Recuperación · Paciente crítico

val SCALES_RAW = listOf(
    // ============ 1. VALORACIÓN PREOPERATORIA (4) ============
    ScaleDef(
        "Clasificación ASA",
        "Estado físico del paciente según la Sociedad Americana de Anestesiólogos.",
        emptyList(),
        "ASA III o mayor: morbilidad y mortalidad perioperatoria aumentadas. La letra E (emergencia) multiplica el riesgo.",
        listOf(
            ScaleOption("I — Paciente sano, sin patologías", 1),
            ScaleOption("II — Enfermedad sistémica leve sin limitación funcional", 2),
            ScaleOption("III — Enfermedad sistémica grave con limitación funcional definida", 3),
            ScaleOption("IV — Enfermedad grave que amenaza constantemente la vida", 4),
            ScaleOption("V — Paciente moribundo, se espera que no sobreviva sin la operación", 5),
            ScaleOption("VI — Paciente con muerte cerebral, donante de órganos", 6)
        ),
        category = "Valoración preoperatoria"
    ),
    ScaleDef(
        "Índice de Riesgo Cardíaco Revisado (RCRI, Lee)",
        "Riesgo de complicación cardíaca mayor en cirugía no cardíaca.",
        emptyList(),
        "0 factores: bajo riesgo (<1%). 1–2: intermedio (evaluar según capacidad funcional y tipo de cirugía). ≥3: alto riesgo (>11%): optimizar, considerar estrategia no invasiva o revascularización según guía.",
        listOf(
            ScaleOption("Cirugía de riesgo intermedio-alto (intratorácica, intraabdominal, suprarrenal)", 1),
            ScaleOption("Historia de cardiopatía isquémica (no solo angina)", 1),
            ScaleOption("Historia de insuficiencia cardíaca congestiva", 1),
            ScaleOption("Historia de enfermedad cerebrovascular (ACV/AIT)", 1),
            ScaleOption("Diabetes mellitus insulinodependiente", 1),
            ScaleOption("Creatinina preoperatoria >2 mg/dL (177 µmol/L)", 1)
        ),
        category = "Valoración preoperatoria"
    ),
    ScaleDef(
        "ARISCAT (riesgo de complicaciones pulmonares)",
        "Riesgo de complicaciones pulmonares postoperatorias (Canet 2010). Marque cada factor presente.",
        emptyList(),
        "≤25: riesgo bajo (≈2%). 26–44: intermedio (≈13%). ≥45: alto (≈40%): considerar fisioterapia preop, analgesia multimodal, estrategia de ventilación protectora y expansión pulmonar postoperatoria agresiva.",
        listOf(
            ScaleOption("Edad 51–80 años", 3),
            ScaleOption("Edad >80 años", 16),
            ScaleOption("SpO2 preoperatoria 91–95 %", 8),
            ScaleOption("SpO2 preoperatoria ≤90 %", 24),
            ScaleOption("Infección respiratoria en el último mes", 17),
            ScaleOption("Anemia preoperatoria (Hb <10 g/dL)", 11),
            ScaleOption("Incisión quirúrgica abdominal alta", 15),
            ScaleOption("Incisión intratorácica", 20),
            ScaleOption("Duración de cirugía 2–3 h", 16),
            ScaleOption("Duración de cirugía >3 h", 23),
            ScaleOption("Cirugía de urgencia", 8)
        ),
        category = "Valoración preoperatoria"
    ),
    ScaleDef(
        "STOP-Bang (apnea obstructiva del sueño)",
        "Tamizaje de apnea obstructiva del sueño (AOS). Marque cada respuesta afirmativa.",
        emptyList(),
        "0–2: riesgo bajo. 3–4: intermedio. ≥5: riesgo alto de AOS moderada-severa: planear vía aérea, precaución con opioides y sedantes, monitorización postoperatoria con oximetría. Si además hay 2 o más de: hombre, IMC >35, perímetro cervical >40 cm → riesgo muy alto.",
        listOf(
            ScaleOption("S — Ronca fuerte (se oye a través de la puerta)", 1),
            ScaleOption("T — Cansancio o somnolencia diurna frecuente", 1),
            ScaleOption("O — Alguien observó que deja de respirar dormido", 1),
            ScaleOption("P — Presión arterial tratada o elevada", 1),
            ScaleOption("B — IMC >35 kg/m²", 1),
            ScaleOption("A — Edad >50 años", 1),
            ScaleOption("N — Perímetro cervical >40 cm", 1),
            ScaleOption("G — Sexo masculino (género hombre)", 1)
        ),
        category = "Valoración preoperatoria"
    ),
    ScaleDef(
        "Escala de Apfel (riesgo de NVPO)",
        "Modelo simplificado de Apfel para náuseas y vómitos postoperatorios en adultos. Marque cada factor presente (1 punto c/u).",
        emptyList(),
        "0–1 puntos ≈ 10–20 % de NVPO · 2 ≈ 40 % · 3 ≈ 60 % · 4 ≈ 80 %. Con ≥2 factores indicar profilaxis multimodal (antiemético de 2 clases + TIVA con propofol + analgesia opioide-sparing); con 3–4 añadir una tercera clase. Factores: sexo femenino, no fumador, antecedente de NVPO o cinetosis, uso postoperatorio esperado de opioides.",
        listOf(
            ScaleOption("Sexo femenino", 1),
            ScaleOption("No fumador", 1),
            ScaleOption("Antecedente de NVPO o cinetosis (mareo del movimiento)", 1),
            ScaleOption("Uso postoperatorio esperado de opioides", 1)
        ),
        category = "Valoración preoperatoria"
    ),
    ScaleDef(
        "Escala de Fragilidad Clínica (CFS)",
        "Clinical Frailty Scale (Rockwood): cribado de fragilidad en el adulto mayor según capacidad funcional y dependencia (9 puntos).",
        emptyList(),
        "1–3: no frágil (2–3: comorbilidad controlada sin dependencia). 4: vulnerable — tras un incidente se degrada pero se recupera. 5–6: fragilidad leve a moderada — necesita ayuda con actividades instrumentales: optimizar antes de cirugía electiva mayor. ≥7: fragilidad severa — dependencia total o terminal: discutir objetivos del cuidado, riesgo muy alto de declive y mortalidad.",
        listOf(
            ScaleOption("1 — Muy en forma: activo, energético, el más apto de su grupo", 1),
            ScaleOption("2 — En forma: sin síntomas activos, pero menos apto que el 1", 2),
            ScaleOption("3 — Bien con comorbilidades controladas: actividad regular ocasional", 3),
            ScaleOption("4 — Vulnerable: no depende de otros, pero se queja de lentitud o síntomas", 4),
            ScaleOption("5 — Levemente frágil: necesita ayuda con actividades instrumentales (compras, dinero, transporte)", 5),
            ScaleOption("6 — Moderadamente frágil: ayuda con baño, ducha y escaleras; no sale solo", 6),
            ScaleOption("7 — Severamente frágil: dependencia parcial o total para el aseo personal", 7),
            ScaleOption("8 — Muy severamente frágil: dependencia total, en cama o silla, en riesgo terminal", 8),
            ScaleOption("9 — Terminal: expectativa de vida menor a 6 meses", 9)
        ),
        category = "Valoración preoperatoria"
    ),
    ScaleDef(
        "NYHA (insuficiencia cardíaca)",
        "Clasificación funcional de la New York Heart Association según la limitación del paciente en su vida diaria.",
        emptyList(),
        "I–II: compensada, bajo riesgo incremental. III: síntomas con actividad mínima — optimizar tratamiento antes de cirugía electiva, considerar evaluación cardiológica. IV: síntomas en reposo — cirugía electiva contraindicada hasta compensar; emergencia solo con equipo avanzado y plan de soporte. La clase NYHA III–IV es un marcador independiente de eventos perioperatorios.",
        listOf(
            ScaleOption("I — Sin limitación: actividad habitual sin síntomas", 1),
            ScaleOption("II — Limitación leve: síntomas con actividad habitual, cómodo en reposo", 2),
            ScaleOption("III — Limitación marcada: síntomas con actividad menor a la habitual, cómodo en reposo", 3),
            ScaleOption("IV — Síntomas en reposo: cualquier actividad exacerba la disnea o angina", 4)
        ),
        category = "Valoración preoperatoria"
    ),
    ScaleDef(
        "Capacidad funcional (METs)",
        "Equivalentes metabólicos de tarea (1 MET = 3,5 mL O2/kg/min): reserva cardiorrespiratoria estimada por las actividades que el paciente tolera.",
        emptyList(),
        "≥4 METs (subir 2 tramos de escaleras, caminar 4 cuadras): capacidad adecuada — posponer pruebas solo si el riesgo quirúrgico es alto y la capacidad es desconocida. <4 METs: capacidad pobre — riesgo perioperatorio mayor; en cirugía de alto riesgo considerar evaluación funcional. ≥10 METs: excelente. La capacidad autoinformada sobreestima: pregunte por ejemplos concretos (escaleras, bolsas del mercado).",
        listOf(
            ScaleOption("1–2 METs — cuidado personal: comer, vestirse, deambular en casa", 1),
            ScaleOption("3–4 METs — actividad ligera: caminar llano 1–2 cuadras, tareas domésticas ligeras", 2),
            ScaleOption("5–9 METs — moderada: subir 2 tramos de escaleras, 4+ cuadras, jardinería, baile", 3),
            ScaleOption("≥10 METs — vigorosa: deporte intenso regular, atleta entrenado", 4)
        ),
        category = "Valoración preoperatoria"
    ),
    // ============ 2. VÍA AÉREA (2) ============
    ScaleDef(
        "Mallampati (modificada)",
        "Predicción de vía aérea difícil. Paciente sentado, lengua fuera, fonando \"ah\", sin fonación forzada.",
        emptyList(),
        "Clase III–IV: vía aérea difícil probable. Combinar con apertura bucal, tiro-mentoniana (≥6 cm), distancia esternomentoniana y movilidad cervical (test de Wilson/LEMON).",
        listOf(
            ScaleOption("I — Paladar blando, fauces, úvula y pilares visibles", 1),
            ScaleOption("II — Paladar blando, fauces y base de la úvula", 2),
            ScaleOption("III — Solo paladar blando y base de la úvula", 3),
            ScaleOption("IV — Solo paladar duro (úvula no visible)", 4)
        ),
        category = "Vía aérea"
    ),
    ScaleDef(
        "Cormack-Lehane (vista laringoscópica)",
        "Grado de visualización glótica en la laringoscopía directa. Registrar el mejor visto con maniobra óptima.",
        emptyList(),
        "I–II: intubación generalmente fácil. III–IV: laringoscopía difícil: optimizar posición, maniobra BURP, videolaringoscopio y plan B/D preparados (vía aérea difícil anticipada). En III distinguir IIIa (epiglotis levantable) de IIIb (no levantable).",
        listOf(
            ScaleOption("I — Cuerdas vocales completamente visibles", 1),
            ScaleOption("II — Solo ariténoides y porción posterior de las cuerdas", 2),
            ScaleOption("IIIa — Solo epiglotis, levantable", 3),
            ScaleOption("IIIb — Solo epiglotis, adherida a la pared posterior", 4),
            ScaleOption("IV — Epiglotis no visible", 5)
        ),
        category = "Vía aérea"
    ),
    // ============ 3. SEDACIÓN Y CONCIENCIA (3) ============
    ScaleDef(
        "RASS (Agitación-Sedación de Richmond)",
        "Profundidad de sedación estándar en UCI, de +4 (combativo) a −5 (no despertable).",
        emptyList(),
        "Objetivo habitual en UCI: 0 a −1. −2 a −3 en ventilación mecánica con sedación profunda programada. RASS −4/−5 no permite evaluar delirio (primero ajustar sedación). Con RASS entre −3 y +4 procede el tamizaje con CAM-ICU.",
        listOf(
            ScaleOption("+4 — Combativo: riesgo inmediato para el personal", 4),
            ScaleOption("+3 — Muy agitado: retira equipos, tubos, catéteres", 3),
            ScaleOption("+2 — Agitado: movimientos vigorosos frecuentes no intencionales", 2),
            ScaleOption("+1 — Inquieto: ansioso, movimientos no vigorosos", 1),
            ScaleOption("0 — Alerta y tranquilo", 0),
            ScaleOption("−1 — Somnoliento: no totalmente alerta, atención >10 s a la voz", -1),
            ScaleOption("−2 — Sedación ligera: contacto breve (<10 s) con la voz", -2),
            ScaleOption("−3 — Sedación moderada: movimientos con la voz, sin contacto visual", -3),
            ScaleOption("−4 — Sedación profunda: sin respuesta a la voz, sí a estimulación física", -4),
            ScaleOption("−5 — No despertable: sin respuesta a la voz ni a la estimulación física", -5)
        ),
        category = "Sedación y conciencia"
    ),
    ScaleDef(
        "Escala de Ramsay",
        "Profundidad de la sedación. Útil en UCI y sedación de procedimientos.",
        emptyList(),
        "2–3: sedación consciente adecuada para la mayoría de los procedimientos. 5–6: sedación profunda con riesgo de depresión respiratoria.",
        listOf(
            ScaleOption("1 — Ansioso, agitado o inquieto", 1),
            ScaleOption("2 — Cooperativo, orientado, tranquilo", 2),
            ScaleOption("3 — Responde solo a órdenes", 3),
            ScaleOption("4 — Respuesta enérgica a luz o golpe glabelar", 4),
            ScaleOption("5 — Respuesta perezosa a estímulo", 5),
            ScaleOption("6 — No responde a estímulos", 6)
        ),
        category = "Sedación y conciencia"
    ),
    ScaleDef(
        "Escala de Glasgow",
        "Estado neurológico por respuesta ocular, verbal y motora. Aplicar al mejor estado del paciente.",
        listOf(
            ScaleGroup(
                "Apertura ocular (E)",
                listOf(
                    ScaleOption("Espontánea", 4),
                    ScaleOption("A la orden", 3),
                    ScaleOption("Al dolor", 2),
                    ScaleOption("Ninguna", 1)
                )
            ),
            ScaleGroup(
                "Respuesta verbal (V)",
                listOf(
                    ScaleOption("Orientado, conversa", 5),
                    ScaleOption("Confuso, desorientado", 4),
                    ScaleOption("Palabras inapropiadas", 3),
                    ScaleOption("Sonidos incomprensibles", 2),
                    ScaleOption("Ninguna", 1)
                )
            ),
            ScaleGroup(
                "Respuesta motora (M)",
                listOf(
                    ScaleOption("Obedece órdenes", 6),
                    ScaleOption("Localiza el dolor", 5),
                    ScaleOption("Retira flexionando", 4),
                    ScaleOption("Flexión anormal (descerebración)", 3),
                    ScaleOption("Extensión anormal (decorticación)", 2),
                    ScaleOption("Ninguna", 1)
                )
            )
        ),
        "Leve: 13–15 · Moderado: 9–12 · Grave: 3–8 (intubar si ≤8).",
        category = "Sedación y conciencia"
    ),
    // ============ 4. DOLOR (2) ============
    ScaleDef(
        "EVA — Escala Visual Analógica (0–10)",
        "Intensidad del dolor autoinformada. Para pacientes CAPACES DE COMUNICARSE (adulto consciente, pediátrico >7-8 años con cara-escala según edad).",
        emptyList(),
        "0–2: leve — paracetamol/AINE suele bastar. 3–5: moderado — añadir opioide menor o adyuvantes. 6–8: severo — opioide mayor, bloqueos, multimodal. 9–10: muy severo — rescate urgente, revisar complicaciones. Meta terapéutica: EVA ≤3 en reposo. El descriptor de la cifra corresponde a la escala numérica verbal (EVN) equivalente.",
        listOf(
            ScaleOption("0 — Sin dolor", 0),
            ScaleOption("1 — Muy leve", 1),
            ScaleOption("2 — Leve", 2),
            ScaleOption("3 — Leve-moderado", 3),
            ScaleOption("4 — Moderado", 4),
            ScaleOption("5 — Moderado", 5),
            ScaleOption("6 — Moderado-severo", 6),
            ScaleOption("7 — Severo", 7),
            ScaleOption("8 — Severo", 8),
            ScaleOption("9 — Muy severo", 9),
            ScaleOption("10 — El peor dolor imaginable", 10)
        ),
        category = "Dolor",
        sliderMax = 10
    ),
    ScaleDef(
        "CPOT (dolor en el paciente crítico no comunicable)",
        "Critical-Care Pain Observation Tool: conducta observable en el paciente intubado/sedado o incapaz de autorreportarse. Puntúe cada ítem observando en reposo y con procedimientos.",
        listOf(
            ScaleGroup(
                "Expresión facial",
                listOf(
                    ScaleOption("0 — Relajada, neutra", 0),
                    ScaleOption("1 — Tensión: ceño fruncido, párpados entreabiertos", 1),
                    ScaleOption("2 — Gesticulación de dolor: todo el rostro tensado", 2)
                )
            ),
            ScaleGroup(
                "Movimientos del cuerpo",
                listOf(
                    ScaleOption("0 — No se mueve o se mueve con facilidad", 0),
                    ScaleOption("1 — Protector: tira suavemente, intenta mirar el sitio", 1),
                    ScaleOption("2 — Agitado: tira con fuerza, intenta retirar dispositivos", 2)
                )
            ),
            ScaleGroup(
                "Tensión muscular (evaluar brazo flexionado)",
                listOf(
                    ScaleOption("0 — Relajado", 0),
                    ScaleOption("1 — Tensado, rígido", 1),
                    ScaleOption("2 — Muy tensado: puño cerrado, flexión de dedos del pie", 2)
                )
            ),
            ScaleGroup(
                "Compatibilidad con el ventilador o vocalización",
                listOf(
                    ScaleOption("0 — Tolera el ventilador / no vocaliza", 0),
                    ScaleOption("1 — Tose pero tolera / gime o grita ocasionalmente", 1),
                    ScaleOption("2 — Lucha contra el ventilador / llora o gime constantemente", 2)
                )
            )
        ),
        "Total 0–8. ≥3: dolor significativo probable → ANALGESIA PRIMERO (titular opioide) antes de añadir sedante; reevaluar con la escala tras cada intervención. Con analgesia insuficiente no confundir el dolor con delirio o agitación.",
        category = "Dolor"
    ),
    // ============ 5. RECUPERACIÓN (2) ============
    ScaleDef(
        "Aldrete modificada (alta de recuperación postanestésica)",
        "Puntuación de recuperación en sala de despertar: 5 ítems con 0, 1 o 2 puntos (máximo 10).",
        listOf(
            ScaleGroup(
                "Actividad (movimiento de extremidades)",
                listOf(
                    ScaleOption("0 — Sin mover extremidades", 0),
                    ScaleOption("1 — Mueve dos extremidades", 1),
                    ScaleOption("2 — Mueve cuatro extremidades", 2)
                )
            ),
            ScaleGroup(
                "Respiración",
                listOf(
                    ScaleOption("0 — Apnea", 0),
                    ScaleOption("1 — Disnea o respiración limitada", 1),
                    ScaleOption("2 — Respiración profunda y tos eficaz", 2)
                )
            ),
            ScaleGroup(
                "Circulación (presión arterial vs. preoperatoria)",
                listOf(
                    ScaleOption("0 — ±50 % del valor preoperatorio", 0),
                    ScaleOption("1 — ±20–49 %", 1),
                    ScaleOption("2 — ±20 % o menos de diferencia", 2)
                )
            ),
            ScaleGroup(
                "Conciencia",
                listOf(
                    ScaleOption("0 — Sin respuesta", 0),
                    ScaleOption("1 — Responde a estímulos", 1),
                    ScaleOption("2 — Despierto, orientado", 2)
                )
            ),
            ScaleGroup(
                "Saturación de O2",
                listOf(
                    ScaleOption("0 — <90 % incluso con oxígeno suplementario", 0),
                    ScaleOption("1 — Requiere O2 para mantener ≥90 %", 1),
                    ScaleOption("2 — ≥92 % respirando aire ambiente", 2)
                )
            )
        ),
        "9–10 puntos: apto para trasladarse de recuperación (con criterio clínico añadido). No sustituye la evaluación para el alta a domicilio: use también PADSS. Un puntaje de actividad <2 en bloqueos regionales no debe retrasar el alta si es esperable.",
        category = "Recuperación"
    ),
    ScaleDef(
        "PADSS (aptitud para el alta ambulatoria)",
        "Post-Anesthetic Discharge Scoring System: 5 dominios de 0 a 2 (máximo 10). Para alta a DOMICILIO tras cirugía ambulatoria.",
        listOf(
            ScaleGroup(
                "Signos vitales",
                listOf(
                    ScaleOption("2 — Dentro del 20 % del valor preoperatorio", 2),
                    ScaleOption("1 — 20–40 % de variación", 1),
                    ScaleOption("0 — Más del 40 % de variación", 0)
                )
            ),
            ScaleGroup(
                "Actividad y estado mental",
                listOf(
                    ScaleOption("2 — Orientado en 3 esferas y camina sin mareo", 2),
                    ScaleOption("1 — Mareo al incorporarse", 1),
                    ScaleOption("0 — Mareo en reposo o ataxia", 0)
                )
            ),
            ScaleGroup(
                "Náuseas y vómitos",
                listOf(
                    ScaleOption("2 — Leves, controlables con antiemético", 2),
                    ScaleOption("1 — Moderados con tratamiento", 1),
                    ScaleOption("0 — Severos o repetidos pese al tratamiento", 0)
                )
            ),
            ScaleGroup(
                "Dolor",
                listOf(
                    ScaleOption("2 — Mínimo o ausente (EVA ≤3)", 2),
                    ScaleOption("1 — Moderado y tolerable", 1),
                    ScaleOption("0 — Severo o no controlado", 0)
                )
            ),
            ScaleGroup(
                "Sangrado quirúrgico",
                listOf(
                    ScaleOption("2 — Mínimo (no requiere cambio de apósito)", 2),
                    ScaleOption("1 — Moderado (hasta 2 cambios de apósito)", 1),
                    ScaleOption("0 — Severo (más de 3 cambios)", 0)
                )
            )
        ),
        "≥9 puntos sin acompañante responsable ni complicaciones: apto para el alta. Instrucciones escritas (analgesia escalonada, señales de alarma, teléfono de contacto), acompañante adulto y prohibición de conducir 24 h.",
        category = "Recuperación"
    ),
    // ============ 6. PACIENTE CRÍTICO (3) ============
    ScaleDef(
        "SOFA (disfunción orgánica en el crítico)",
        "Sequential Organ Failure Assessment: 6 sistemas de 0 a 4 puntos (máximo 24). Registre el PEOR valor de cada jornada.",
        listOf(
            ScaleGroup(
                "Respiratorio (PaO2/FiO2 en mmHg)",
                listOf(
                    ScaleOption("0 — ≥400", 0),
                    ScaleOption("1 — <400", 1),
                    ScaleOption("2 — <300", 2),
                    ScaleOption("3 — <200 con soporte ventilatorio", 3),
                    ScaleOption("4 — <100 con soporte ventilatorio", 4)
                )
            ),
            ScaleGroup(
                "Coagulación (plaquetas ×10³/µL)",
                listOf(
                    ScaleOption("0 — ≥150", 0),
                    ScaleOption("1 — <150", 1),
                    ScaleOption("2 — <100", 2),
                    ScaleOption("3 — <50", 3),
                    ScaleOption("4 — <20", 4)
                )
            ),
            ScaleGroup(
                "Hepático (bilirrubina mg/dL)",
                listOf(
                    ScaleOption("0 — <1,2", 0),
                    ScaleOption("1 — 1,2–1,9", 1),
                    ScaleOption("2 — 2,0–5,9", 2),
                    ScaleOption("3 — 6,0–11,9", 3),
                    ScaleOption("4 — >12", 4)
                )
            ),
            ScaleGroup(
                "Cardiovascular",
                listOf(
                    ScaleOption("0 — PAM ≥70 mmHg sin vasopresores", 0),
                    ScaleOption("1 — PAM <70 mmHg", 1),
                    ScaleOption("2 — Dopamina ≤5 µg/kg/min o dobutamina (cualquier dosis)", 2),
                    ScaleOption("3 — Dopamina >5 o adrenalina/noradrenalina ≤0,1 µg/kg/min", 3),
                    ScaleOption("4 — Dopamina >15 o adrenalina/noradrenalina >0,1 µg/kg/min", 4)
                )
            ),
            ScaleGroup(
                "Sistema nervioso central (Glasgow)",
                listOf(
                    ScaleOption("0 — 15", 0),
                    ScaleOption("1 — 13–14", 1),
                    ScaleOption("2 — 10–12", 2),
                    ScaleOption("3 — 6–9", 3),
                    ScaleOption("4 — <6", 4)
                )
            ),
            ScaleGroup(
                "Renal (creatinina mg/dL o diuresis mL/día)",
                listOf(
                    ScaleOption("0 — Creatinina <1,2", 0),
                    ScaleOption("1 — 1,2–1,9", 1),
                    ScaleOption("2 — 2,0–3,4", 2),
                    ScaleOption("3 — 3,5–4,9 o diuresis <500 mL/día", 3),
                    ScaleOption("4 — >5,0 o diuresis <200 mL/día", 4)
                )
            )
        ),
        "0–24 puntos. Un incremento de ≥2 respecto al basal define disfunción orgánica aguda (Sepsis-3: sin otra causa, define sepsis con infección). Mortalidad hospitalaria aproximada: 0–6: <10 %; 7–9: 15–20 %; 10–12: 40–50 %; ≥13: >50 %. SOFA alto o ascendente pese al tratamiento → discusión de intensidad terapéutica.",
        category = "Paciente crítico"
    ),
    ScaleDef(
        "APACHE II (gravedad en UCI)",
        "Fisiología aguda (12 variables, peores valores de 24 h) + edad + salud crónica. Marque el valor peor de cada variable.",
        listOf(
            ScaleGroup(
                "Temperatura rectal (°C)",
                listOf(
                    ScaleOption("+4 — ≥41 o ≤29,9", 4),
                    ScaleOption("+3 — 39,1–41 o 30–31,9", 3),
                    ScaleOption("+2 — 38,5–39 o 32–33,9", 2),
                    ScaleOption("+1 — 37,0–38,4 o 34,0–35,9", 1),
                    ScaleOption("0 — 36,0–36,9", 0)
                )
            ),
            ScaleGroup(
                "PAM (mmHg)",
                listOf(
                    ScaleOption("+4 — ≥160 o ≤49", 4),
                    ScaleOption("+3 — 130–159", 3),
                    ScaleOption("+2 — 110–129 o 50–69", 2),
                    ScaleOption("0 — 70–109", 0)
                )
            ),
            ScaleGroup(
                "Frecuencia cardíaca (lpm)",
                listOf(
                    ScaleOption("+4 — ≥180 o ≤39", 4),
                    ScaleOption("+3 — 140–179", 3),
                    ScaleOption("+2 — 110–139 o 55–69", 2),
                    ScaleOption("0 — 70–109", 0)
                )
            ),
            ScaleGroup(
                "Frecuencia respiratoria (rpm)",
                listOf(
                    ScaleOption("+4 — ≥50 o ≤5", 4),
                    ScaleOption("+3 — 35–49", 3),
                    ScaleOption("+2 — 25–34 o 10–11", 2),
                    ScaleOption("0 — 12–24", 0)
                )
            ),
            ScaleGroup(
                "Oxigenación (FiO2 ≥50 %: gradiente A–a; FiO2 <50 %: PaO2)",
                listOf(
                    ScaleOption("+4 — A–a ≥500 o PaO2 <55", 4),
                    ScaleOption("+3 — A–a 350–499", 3),
                    ScaleOption("+2 — A–a 200–349 o PaO2 55–60", 2),
                    ScaleOption("0 — A–a <200 o PaO2 >60", 0)
                )
            ),
            ScaleGroup(
                "pH arterial",
                listOf(
                    ScaleOption("+4 — ≥7,7 o <7,15", 4),
                    ScaleOption("+3 — 7,6–7,69", 3),
                    ScaleOption("+2 — 7,5–7,59 o 7,15–7,24", 2),
                    ScaleOption("+1 — 7,25–7,32", 1),
                    ScaleOption("0 — 7,33–7,49", 0)
                )
            ),
            ScaleGroup(
                "Sodio (mmol/L)",
                listOf(
                    ScaleOption("+4 — ≥180 o ≤110", 4),
                    ScaleOption("+3 — 160–179 o 111–119", 3),
                    ScaleOption("+2 — 155–159 o 120–129", 2),
                    ScaleOption("+1 — 150–154", 1),
                    ScaleOption("0 — 130–149", 0)
                )
            ),
            ScaleGroup(
                "Potasio (mmol/L)",
                listOf(
                    ScaleOption("+4 — ≥7,0 o <2,5", 4),
                    ScaleOption("+3 — 6,0–6,9", 3),
                    ScaleOption("+2 — 5,5–5,9 o 2,5–2,9", 2),
                    ScaleOption("+1 — 3,0–3,4", 1),
                    ScaleOption("0 — 3,5–5,4", 0)
                )
            ),
            ScaleGroup(
                "Creatinina (mg/dL) — duplique el punto si hay insuficiencia renal crónica",
                listOf(
                    ScaleOption("+4 — ≥3,5", 4),
                    ScaleOption("+3 — 2,0–3,4", 3),
                    ScaleOption("+2 — 1,5–1,9 o <0,6", 2),
                    ScaleOption("0 — 0,6–1,4", 0)
                )
            ),
            ScaleGroup(
                "Hematocrito (%)",
                listOf(
                    ScaleOption("+4 — ≥60 o <20", 4),
                    ScaleOption("+2 — 50–59,9 o 20–29,9", 2),
                    ScaleOption("+1 — 46–49,9", 1),
                    ScaleOption("0 — 30–45,9", 0)
                )
            ),
            ScaleGroup(
                "Leucocitos (×10³/µL)",
                listOf(
                    ScaleOption("+4 — ≥40 o <1", 4),
                    ScaleOption("+2 — 20–39,9 o 1–2,9", 2),
                    ScaleOption("+1 — 15–19,9", 1),
                    ScaleOption("0 — 3–14,9", 0)
                )
            ),
            ScaleGroup(
                "Glasgow (suma 15 − GCS)",
                listOf(
                    ScaleOption("+4 — GCS 3–5", 4),
                    ScaleOption("+3 — GCS 6–8", 3),
                    ScaleOption("+2 — GCS 9–11", 2),
                    ScaleOption("+1 — GCS 12–14", 1),
                    ScaleOption("0 — GCS 15", 0)
                )
            ),
            ScaleGroup(
                "Edad",
                listOf(
                    ScaleOption("+6 — ≥75 años", 6),
                    ScaleOption("+5 — 65–74", 5),
                    ScaleOption("+3 — 55–64", 3),
                    ScaleOption("+2 — 45–54", 2),
                    ScaleOption("0 — ≤44", 0)
                )
            ),
            ScaleGroup(
                "Salud crónica grave (falla orgánica documentada o inmunocompromiso)",
                listOf(
                    ScaleOption("+5 — No operatoria o postoperatorio de urgencia", 5),
                    ScaleOption("+2 — Postoperatorio electivo", 2),
                    ScaleOption("0 — Ausente", 0)
                )
            )
        ),
        "0–71 puntos. Mortalidad hospitalaria aproximada (no operatoria): 0–4: 4 %; 5–9: 8 %; 10–14: 15 %; 15–19: 25 %; 20–24: 40 %; 25–29: 55 %; ≥30: >70 %. Reevalúe diario; el peor SOFA/APACHE de las primeras 24 h orienta admisión a UCI y límites terapéuticos.",
        category = "Paciente crítico"
    ),
    ScaleDef(
        "CAM-ICU (tamizaje de delirio)",
        "Confusion Assessment Method for the ICU. Aplique SOLO si RASS está entre −3 y +4. Marque SÍ/NO en cada característica.",
        listOf(
            ScaleGroup(
                "1. Inicio agudo o curso fluctuante (cambio vs. basal en horas/días, o fluctuación en 24 h)",
                listOf(
                    ScaleOption("SÍ — presente", 1),
                    ScaleOption("NO — ausente", 0)
                )
            ),
            ScaleGroup(
                "2. Inatención (dificultad para focalizar: dedos del 1 al 10, letras A-S-L-T-C-T-E)",
                listOf(
                    ScaleOption("SÍ — presente", 1),
                    ScaleOption("NO — ausente", 0)
                )
            ),
            ScaleGroup(
                "3. Pensamiento desorganizado (preguntas estándar: ¿una mosca y un topo se parecen?, ¿una piedra y una pelota se parecen?, comandos: saluda, levanta el pulgar)",
                listOf(
                    ScaleOption("SÍ — presente", 1),
                    ScaleOption("NO — ausente", 0)
                )
            ),
            ScaleGroup(
                "4. Nivel de conciencia alterado (cualquier RASS distinto de 0)",
                listOf(
                    ScaleOption("SÍ — presente", 1),
                    ScaleOption("NO — ausente", 0)
                )
            )
        ),
        "CAM-ICU POSITIVO si las características 1 y 2 están presentes (con 3 o 4 acompañantes en la mayoría de versiones): delirio confirmado → buscar desencadenantes (dolor no tratado — use CPOT, retiro de alcohol/benzodiacepinas, infección, retención, fármacos), no sedantes: rehabilitación, reorientación, sueño, audífonos/lentes. CAM-ICU negativo: continuar tamizaje en cada turno. El delirio hipocativo (RASS negativo) es el más frecuente y el más pasado por alto.",
        category = "Paciente crítico"
    )
)

// ------------------------------- COMPLICACIONES (14) -------------------------------

val COMPLICATIONS_RAW = listOf(
    Complication(
        "Hipoxemia perioperatoria",
        "SpO2 <90%, cianosis tardía, taquicardia → bradicardia. Causas: DOPE — Desconexión del circuito, Obstrucción del tubo (doblado, secreciones, mordida), Pneumotórax, Equipo (oxígeno, fuente, vaporizador). Además: endobronquial, atelectasia, aspiración, broncoespasmo, embolia, bajo gasto.",
        "O2 100% + bolsa de reanimación manual (verificar que sube y baja el reservorio: confirma ventilación). Auscultar bilateral, mirar el circuito completo, succión del tubo, progresión capnográfica. PEEP 5–10, reclutamiento. Si persiste: pensar neumotórax (agujas en 2.º espacio), embolia, anafilaxia. Fibrobroncoscopia si duda de posición. Nunca paralizar sin tener control de la vía aérea."
    ),
    Complication(
        "Hipotensión intraoperatoria",
        "PA sistólica ↓ >20–30% del basal. Causas frecuentes: profundidad anestésica excesiva (vasodilatación), hipovolemia/sangrado, posición (decúbito lateral, Trendelenburg alto), bradicardia vagal, bloqueo neuraxial alto. Causas letales ocultas: anafilaxia, embolia pulmonar, neumotórax a tensión, taponamiento, isquemia ventricular derecha.",
        "Primera línea: reducir el anestésico + volumen + vasopresor (efedrina 5–10 mg si FC baja; fenilefrina 50–100 µg si FC normal o alta). Reevaluar sangrado y gases (Hb, lactato). Vasopresor en infusión si recurre. Si refractaria: buscar las 5 causas letales — anafilaxia (erupción, broncoespasmo), embolia (EtCO2 cae), neumotórax a tensión (un pulmón no ventila), taponamiento (ECG estático, PVC↑), isquemia (ST)."
    ),
    Complication(
        "Hipertensión intraoperatoria",
        "PA ↑ >20–30% del basal. Causas: analgesia insuficiente (la más común), profundidad hipnótica inadecuada, respuesta al laringoscopio, hipercapnia, hipoxemia, catéter/sonda (vejiga llena), preeclampsia, feocromocitoma (raro pero letal), abstinencia de clonidina o β-bloqueante.",
        "Primero: analgesia (fentanilo 25–50 µg o remifentanilo) y profundidad hipnótica adecuada; verificar ventilación (EtCO2 35–40 mmHg) y O2. Luego fármacos: labetalol 5–10 mg IV, metoprolol 1–2 mg, urapidilo 12,5–25 mg, nitroglicerina o nitroprusiato en infusión si refractaria. Vigilar diuresis y reflejos pupilares. Preeclampsia: labetalol o hidralazina, MgSO4."
    ),
    Complication(
        "Bradicardia intraoperatoria",
        "FC <50 lpm con o sin hipotensión. Causas: reflejo vagal (tracción peritoneal, oculocardiaco, mesenterio, succión faríngea), opioides (fentanilo, remifentanilo, suxametonio en niños), dexmedetomidina, hipoxia (la más peligrosa: SOLO trate el ritmo tras asegurar oxigenación), bloqueo AV, hipertensión intracraneal.",
        "O2 100% primero; suspender el estímulo vagal. Atropina 0,5 mg IV (repetir hasta 3 mg) o glicopirrolato 0,2 mg. Si refractaria o inestable: adrenalina 5–10 µg IV bolus titulados, infusión 0,05 µg/kg/min. Marcapasos transcutáneo como rescate. Chequear K+, calcio, hipoxia, isquemia inferior (ST en II, III, aVF: pensar bloqueo por enfermedad del nodo)."
    ),
    Complication(
        "Taquicardia intraoperatoria",
        "FC >100 lpm. Causas: dolor/analgesia insuficiente, hipnosis inadecuada (típico al moverse o sudar), hipovolemia, anemia, fiebre/sepsis, hipercapnia, tirazón de tubo, fármacos (atropina, ketamina, efedrina), taquiarritmias (FA, TSV), hipertiroidismo.",
        "Tratar la causa: analgesia (fentanilo), profundidad (subir hipnótico), volumen si hipovolemia. Si es taquiarritmia: FA de inicio reciente → amiodarona o control de frecuencia con β-bloqueante; TSV con pulso estable → maniobras vagales y adenosina 6–12 mg; inestable → cardioversión sincronizada (100 J). Vigilar QT, K+, Mg2+. Catecolaminas exógenas: revisar bombas y dosis."
    ),
    Complication(
        "Laringoespasmo",
        "Cierre glótico reflejo por estímulo de la vía aérea (secreciones, tubo, sangre, olor anestésico), típico al despertar o en la inducción. Estridor inspiratorio → \"silencio\" con esfuerzo respiratorio sin movimiento del reservorio → desaturación rápida. Triada: retracción, estridor, desaturación.",
        "O2 100% + CPAP con mascarilla + elevar el mentón (manipulación laríngea leve con presión detrás de las ramas mandibulares). Si no cede en 30–60 s: propofol 0,5–1 mg/kg IV. Si hay desaturación grave o imposibilidad de ventilar: suxametonio 0,5–1 mg/kg IV (2–4 mg/kg IM si no hay vía) + intubar/ventilar. Prevención: succión cuidadosa, extubar en plano profundo (o muy despierto), lidocaína IV 1–1,5 mg/kg previa."
    ),
    Complication(
        "Broncoespasmo intraoperatorio",
        "Sibilancias espiratorias + ↑ presión pico + onda capnográfica empinada (bloqueo espiratorio). Causas: asma/EPOC irritado (intubación superficial, secreciones), reacción alérgica (considerar siempre), tubo endobronquial (posición/carina), edema pulmonar, embolia, embolia de líquido amniótico.",
        "O2 100%, profundizar la anestesia (volátil o propofol: ambos broncodilatadores), salbutamol inhalado 4–10 puffs por el circuito o 2,5–5 mg nebulizado, hidrocortisona 100–200 mg IV. Grave: adrenalina titulada 5–50 µg o infusión 0,05–0,1 µg/kg/min, MgSO4 2 g IV en 20 min. Si es alérgico: adrenalina + volumen (protocolo de anafilaxia). Revisar posición del tubo antes de dar broncodilatador."
    ),
    Complication(
        "Hipotermia perioperatoria",
        "T. central <36 °C (medir siempre en >30 min de cirugía). Consecuencias: coagulopatía (↓ función plaquetaria y factores), isquemia miocárdica, infección de la herida, delirium, prolongación de los relajantes y del metabolismo de fármacos, escalofríos (↑ consumo de O2 hasta 400–500%).",
        "Prevención es la clave: mantas de aire forzado (mejor evidencia), fluidos calientes si >500 mL/h, humidificación de los gases, temperatura de quirófano ≥21 °C, limitar la exposición, calentar la preparación de la piel. Tratamiento: rewarming activo gradual (1 °C/h), O2 si el consumo aumenta, sedar los escalofríos (petidina 0,3–0,5 mg/kg es la más eficaz). Vigilar K+ y arritmias durante el recalentamiento."
    ),
    Complication(
        "Hipertermia maligna",
        "Urgencia genética. Gatillos: todos los volátiles halogenados + suxametonio. Presentación: ↑ EtCO2 inexplicable (el primer signo), taquicardia, rigidez de maseteros/cuerpo, acidosis respiratoria y metabólica, temperatura tardía (↑ 1–2 °C cada 15 min), mioglobinuria, hiperkalemia. Mortalidad >70% sin dantroleno, <5% con tratamiento correcto.",
        "1) PARAR volátiles y suxametonio, circuito limpio y O2 10 L/min, anestesia con propofol/opioides. 2) Pedir ayuda + dantroleno 2,5 mg/kg IV rápido, repetir hasta resolver (se han usado hasta 10 mg/kg; no existe límite real). 3) Enfriamiento activo (IV fría, lavado gástrico/vesical, superficie) PARAR a 38 °C. 4) Tratar hiperkalemia (insulina+dextrosa 50%, CaCl2, bicarbonato), acidosis (bicarbonato 2–4 mEq/kg). 5) Arritmias: evitar bloqueantes de Ca. 6) Vigilar UCI 24–48 h (recrudescencia), mioglobinuria → hidratar y alcalinizar orina. Notificar y consejo genético."
    ),
    Complication(
        "Anafilaxia perioperatoria",
        "Reacción grave de hipersensibilidad (IgE o no IgE). Triada: hipotensión severa (la presentación más común en anestesia, a veces solo colapso), broncoespasmo, erupción cutánea (ausente en 20–40% al inicio). Causas típicas: antibióticos (β-lactámicos), relajantes (suxametonio, rocuronio), látex, clorhexidina, tintes. EtCO2 cae por broncoespasmo + bajo gasto.",
        "1) PARAR el agente sospechoso + pedir ayuda. 2) ADRENALINA: IM 0,5 mg (0,5 mL 1:1000) repetir cada 5 min; con vía IV y monitoría: 50–100 µg titulados, luego infusión 0,05–0,1 µg/kg/min. 3) VOLUMEN: cristaloide 20–30 mL/kg rápido (gran extravasación por vasodilatación). 4) Posición: piernas elevadas. 5) Refractario: adrenalina en infusión, noradrenalina, vasopresina, glucagón 1–5 mg si hay β-bloqueo. 6) Segunda línea: difenhidramina 25–50 mg, hidrocortisona 200 mg (fase tardía), salbutamol si broncoespasmo persistente. 7) Triptasa en 30 min y 2–24 h; plan de alergia y estudio inmunológico posterior."
    ),
    Complication(
        "Regurgitación y aspiración pulmonar",
        "Paciente de riesgo: urgencia, obesidad, embarazo >20 semanas, reflujo, íleo, trauma, diabetes con gastroparesia. Diagnóstico: bilis o contenido gástrico en la faringe/succión, " +
            "desaturación + broncoespasmo + infiltrados en la radiografía 1–6 h después (Mendelson: neumonitis química si pH <2,5 y volumen >0,4 mL/kg... >25 mL en adulto).",
        "Prevención es lo esencial: RSI con cricoides (presión cricoidea 30 N), tubo con balón, preoxigenación, H2 o IPPV + metoclopramida en riesgo, posición semi-sentada. Si ocurre: Trendelenburg + lateral izquierdo, succión inmediata de la faringe, O2 100%, no lavado rutinario, fibrobroncoscopia para extraer partículas, PEEP, cuidar la ventilación. Tratamiento de soporte (corticoides no demostrados). Ingreso en observación 6–24 h con oximetría y radiografía de tórax."
    ),
    Complication(
        "Despertar intraoperatorio",
        "Conciencia con memoria durante la anestesia general (0,1–0,2%). Factores de riesgo: TIVA sin monitor de profundidad, hipnosis insuficiente (dosis reducidas, taquifilaxia), cirugía cardíaca, obstétrica, trauma, paciente con tolerancia (alcohol, opioides, benzodiazepinas), equipo mal cargado/vaporizador vacío. Secuelas: TEPT, ansiedad, insomnio, miedo a la anestesia futura.",
        "Prevención: dosis de hipnótico acorde con el estímulo, BIS 40–60 (o índice equivalente) en pacientes de riesgo, verificar vaporizador y circuito al inicio, monitorizar EtCO2 y sus cambios de perfil. Si el paciente lo refiere: escuchar con seriedad, NO minimizar, entrevista estructurada (Brice), derivación a psicología, seguimiento. Documentar. En el intraoperatorio sospechado: subir hipnótico, verificar sistema, revisar movilidad, sudor, lágrimas, HR/HRV."
    ),
    Complication(
        "Náuseas y vómitos postoperatorios (NVPO)",
        "La complicación más común (20–30%; hasta 80% sin profilaxis en alto riesgo). Factores (Apfel): sexo femenino, no fumador, antecedente de NVPO, opioides postoperatorios; cirugía laparoscópica/ginecológica/orl añaden riesgo. Consecuencias: dolor, sangrado, dehiscencia, demora del alta, ingreso no planificado.",
        "Profilaxis según el riesgo (Apfel ≥2: doble terapia): ondansetrón 4 mg (fin de cirugía) + dexametasona 4–8 mg (inicio) o droperidol 0,625–1,25 mg; TIVA con propofol reduce el riesgo ~30%. Rescate (cambiar de clase al usado en la profilaxis): dimenhidrinato 1 mg/kg o metoclopramida 10 mg o droperidol si no se usó. Manejo no farmacológico: hidratación adecuada, analgesia multimodal opioide-sparing, P6 (acupresión). Evitar el N2O y los opioides en el alto riesgo."
    ),
    Complication(
        "Bloqueo neuromuscular residual",
        "TOF <0,9 al despertar: la causa común de hipoxemia y reintubación en la recuperación. Signos clínicos poco sensibles: no puede elevar la cabeza 5 s, diplopía, \"sonrisa\" incompleta, incapacidad de morder, dificultad respiratoria. Riesgo alto: adulto mayor, renal, hepático, obesidad, cirugía larga, neostigmina con TOF bajo.",
        "Prevención: monitorizar SIEMPRE con TOF (aceleromiografía si se dispone), revertir solo cuando hay T2 (o usar sugammadex 2–4 mg/kg), TOF objetivo ≥0,9 antes del alta. Tratamiento del residual: sugammadex si es rocuronio/vecuronio; si es bencilisoquinolina: esperar + cuidar la vía aérea + ventilación de apoyo; considerar neostigmina extra solo si hay T2. No dar de alta sin TOF adecuado, SpO2 basal en aire y respiración estable."
    )
)

// ------------------------------- PREMEDICACIÓN Y CONDICIONES ESPECIALES (14) -------------------------------

val PREMED_TOPICS_RAW = listOf(
    Topic(
        "Diabetes mellitus",
        "Objetivo: glicemia 5–10 mmol/L (90–180 mg/dL) durante el perioperatorio, sin hipoglucemias. CIRUGÍA ELECTIVA: los hipoglicemiantes orales (metformina, SGLT2, sulfonilureas) se omiten el día de la cirugía (metformina idealmente 24–48 h si contraste o cirugía mayor; los SGLT2 3 días antes por cetoacidosis euglicémica). Insulina basal: reducir a 50–80% y ajustar según glicemias horarias con esquema corrección. NPH/remezclas: la mitad de la dosis matutina. Comida + insulina prandial: omitir. Cirugía urgente o larga: esquema de insulina-glicemia-potasio (GKI) con dextrosa 10% + KCl e insulina en bomba. Vigilar hipoglucemia no perceptible (sin sedación clara: el diabético con neuropatía autonómica puede hipotensar con la inducción). Prioridad: primero glicemia, luego el resto."
    ),
    Topic(
        "Hipertensión arterial",
        "Vigilar siempre: PA <160/100 mmHg para diferir electiva (opcional según protocolo). Los β-bloqueantes y los bloqueantes de calcio no dihidropiridínicos NUNCA se suspenden (rebote: riesgo de isquemia por retirada). IECA y ARA2: política institucional, típicamente omiten el día de la cirugía por hipotensión refractaria (reiniciar en 24–48 h si hay estabilidad). Diuréticos: omitir si hay diuresis adecuada. Clonidina: mantener (retirarla causa crisis hipertensivas). Paciente con PA alta en la mañana de la cirugía: dar el antihipertensivo habitual (excepto IECA/ARA2) con un sorbo de agua y reevaluar; no diferir por 160–180 sistólica aislada sin lesión de órgano. Anestesia: evitar la taquicardia (isquemia) y la hipotensión profunda (disfunción endotelial); vasopresores listos."
    ),
    Topic(
        "Coagulopatías y anticoagulantes",
        "Warfarina: suspender 5 días antes (INR objetivo ≤1,4; puente con HBPM solo si alto riesgo trombótico). AOD (rivaroxabán, apixabán, dabigatrán): 48–72 h según la función renal y el riesgo del procedimiento. HBPM profiláctica: 12 h antes de la neuraxial; terapéutica: 24 h. Clopidogrel: 5–7 días (con stent reciente: consultar cardiólogo). NUNCA suspender el AAS por decisión propia: el AAS puede mantenerse en la mayoría de las cirugías no cardíacas. Aspirina: decisión por cirugía (retirar en neurocirugía, ojo; mantener en stents y cardio). Neuraxial: seguir las guías ASRA; el catéter epidural se retira con tiempos seguros (4–6 h tras la HBPM profiláctica). Coagulopatía hepática/CI: plasma fresco, vitamina K, ácido tranexámico según la causa. SIEMPRE: balance riesgo sangrado vs. trombosis documentado en la historia."
    ),
    Topic(
        "Paciente neurológico y neuromuscular",
        "Epilepsia: mantener los anticonvulsivos; evitar la retirada abrupta; tiopental y benzodiazepinas son anticonvulsivantes; cuidar la hiponatremia por carbamazepina. Miastenia gravis: resistencia a suxametonio (dosis 2×, cuidado con fase II) e hipersensibilidad a no despolarizantes (usar 10–20% de la dosis habitual, preferir cisatracurio con TOF y tener sugammadex disponible); evitar los aminoglucósidos; cirugía de timoma: planificar con neurólogo. ACV reciente <3 meses: diferir electiva si es posible (riesgo de extensión); mantener la perfusión cerebral (normocapnia, PA basal). Parkinson: continuar la levodopa (la mitad de cada dosis si NPO prolongado); evitar metoclopramida y butirofenonas (bloquean D2 y empeoran); delirium postoperatorio frecuente. Esclerosis múltiple: evitar hipertermia; los brotes se asocian con estrés quirúrgico."
    ),
    Topic(
        "Anestesia fuera del quirófano",
        "Radiología, tomografía, RM, endoscopía, cateterismo, radioterapia: entorno hostil (acceso limitado al paciente, oscuridad, radiación, distancia al equipo, ritmo de trabajo alto). Requisitos: O2, succión, bolsa-valva, circuito de anestesia portable, capnografía (obligatoria), oxímetro con alarma audible y volumen alto, fuente de energía aislada, vía IV firme, monitor defibrilador a mano. RM: equipo compatible (ferromagnético: ¡cuidado con las bombas y el O2!). Sedación profunda = anestesia general (mismos estándares de monitoría y personal). Limitar el tiempo en la sala oscura: rotación. Radiación: delantal, distancia, dosímetro. Comunicación con el equipo del servicio antes de empezar (quién hace qué)."
    ),
    Topic(
        "Embarazadas (no obstétrica y obstétrica)",
        "Toda embarazada >20 semanas: posición con desplazamiento uterino a la izquierda (cuña 15–30°) para evitar el síndrome de compresión aortocava. Vía aérea: RSI con cricoides (embarazo = estómago lleno), tubo 6,5–7,0, laringoscopio corto preparado; intubación más difícil (edema de vía aérea, pechos grandes). Fármacos: evitar N2O en el primer trimestre (teratogenicidad teórica) y benzodiazepinas; los volátiles son seguros; fenilefrina es el vasopresor de primera línea en la hipotensión espinal (mejor pH fetal que la efedrina); evitar los AINE en el 3.er trimestre (ducto). Monitor fetal: >23–24 semanas, monitoreo pre y postoperatorio si es electiva (no ctg intraoperatorio rutinario). Profilaxis de trombosis: HBPM. Identificar y consensuar con obstetricia el plan si hay emergencia fetal."
    ),
    Topic(
        "Endocrinopatías",
        "Hipertiroidismo: diferir electiva hasta eutiroidismo (tormenta tiroidea = mortalidad alta); β-bloqueante (propranolol o metoprolol) + yoduro/antitiroideo previo; evitar ketamina, adrenalina y estimulación simpática; mantener la temperatura y la sedación profunda. Hipotiroidismo: dosis de inducción reducidas (hipersensibilidad), vía aérea macroglosia, cuidado con la hiponatremia y la hipotermia; la anestesia espinal puede precipitar la miopatía. Feocromocitoma: α-bloqueo (fentolamina/urapidilo) 1–2 semanas antes, luego β-bloqueo; NO dar β-bloqueante solo (crisis hipertensiva); anestesia con propofol-remifentanilo, evitar histamina, ketamina, metoclopramida, morfina; volumen previo; nitroprusiato y fentolamina listos. Insuficiencia suprarrenal/esteroides crónicos: hidrocortisona de estrés 50–100 mg IV c/8 h. Hiperparatiroidismo: hipercalcemia, evitar la deshidratación, vigilar el QT."
    ),
    Topic(
        "Insuficiencia cardíaca",
        "Objetivo: mantener el equilibrio pre-carga/post-carga e isquemia. Inducción: etomidato (0,1–0,2 mg/kg) o propofol MUY titulado con opioides; evitar la taquicardia y la hipovolemia brusca; vasopresor puro (fenilefrina) preferido a la efedrina (↑ consumo de O2). Mantenimiento: TIVA con remifentanilo o volátil en dosis bajas; PEEP moderada. Monitorización: si FEVI <35% o cirugía mayor: artérial + PVC ± doppler esofágico; considerar inotrópicos profilácticos (dobutamina 2–5 µg/kg/min) si hay deterioro. Evitar: hipervolemia (el volumen no mejora la FC baja), bradicardia (marcapasos listo), arritmias (K+ y Mg2+ normales). En el postoperatorio: el pico de riesgo es 24–72 h (redisposición de fluidos): balance estricto, oxígeno, volver a la medicación crónica (β-bloqueante, IECA cuando la perfusión renal lo permita)."
    ),
    Topic(
        "Paciente anciano (geriatría)",
        "Cambios: ↓ reserva fisiológica, masa muscular y agua; ↑ grasa (liposolubles: acumulación); CFR pulmonar y renal reducida. Dosis: reducir 30–50% de los hipnóticos y opioides; titulación lenta; TOF prolongado (especialmente con la neostigmina); evitar las benzodiazepinas (delirium, caídas: criterios de Beers). Delirium postoperatorio (20–50%): prevención multimodal — analgesia adecuada sin opioides excesivos, volver a gafas/audífonos, reorientación, sueño nocturno, movilización temprana, evitar anticolinérgicos. Vía aérea: osteoartritis cervical (cuidado con la extensión), xerostomía, dientes flojos. Hipotermia rápida: abrigo activo. Presión arterial: el basal puede estar \"reanimado\" con medición falsa; vigilar la perfusión cerebral (PA basal ±10%). Comorbilidad múltiple: polifarmacia e interacciones. Frailty: escala de fragilidad clínica si se dispone."
    ),
    Topic(
        "Insuficiencia renal",
        "Dosis: atracurio/cisatracurio (Hoffman, independiente de la función renal) o rocuronio + TOF; evitar la morfina (M6G acumula) y la petidina (normeperidina convulsiones): preferir fentanilo, remifentanilo, tramadol con precaución. Dipirona/paracetamol: dosis ajustada (paracetamol máx. 3 g/día si CrCl <30). Evitar AINE si CrCl <60 (hipoperfusión medular). Glicemia: evitar hipoglucemia (no hay gluconeogénesis de reserva). Potasio: vigilar hiperkalemia (suxametonio + hiperK preexistente: contraindicado si K+ >5,5). Balance: cristaloides equilibrados (evitar NaCl 0,9% masivo: acidosis hiperclorémica); monitorear diuresis horaria. Heparina/anticoagulantes: dosis ajustada al peso y la función renal. Sugammadex: se aclara renal, en diálisis grave no recomendado (dosis extra si es preciso). El trasplante renal previo: continuar la inmunosupresión (consultar nefrología)."
    ),
    Topic(
        "Insuficiencia hepática",
        "Cambios: hipoproteinemia (↑ fracción libre), ↓ metabolismo de primera pasada, coagulopatía (↓ factores + hiperfibrinolisis), encefalopatía, ascitis, varices, hipotensión por vasodilatación (VO bajo). Dosis: opioides y benzodiazepinas reducidas (riesgo de encefalopatía); atracurio (Hoffman) ideal; propofol OK titulado. Vía aérea: varices esofágicas (cuidado con el traumatismo del tubo). Coagulación: vitamina K, plasma según la hemostasia (TEG/ROTEM si se dispone); NO corregir rutinariamente sin sangrado. Fluido: cristaloide equilibrado, albúmina si hay hipovolemia + hipoalbuminemia. Hipoglucemia: glucemia horaria en Child C. Evitar: N2O (distensión), AINE, dosis altas de midazolam. Child-Pugh C: alto riesgo; considerar derivar a centro especializado. Analgesia multimodal opioide-sparing (paracetamol OK ≤2 g/día en Child A–B)."
    ),
    Topic(
        "Paciente oncológico",
        "Quimioterapia previa: doxorrubicina (cardiotoxicidad: ECO/FEVI, vigilar arritmias), bleomicina (neumonitis: evitar FiO2 alta innecesaria... mantener SpO2 objetivo con FiO2 mínima razonable y balance de fluidos), cisplatino (nefrotoxicidad: vigilancia renal y Mg2+), ciclofosfamida (SIADH). Hiperalgesia y tolerancia a opioides (dolor crónico oncológico): continuar la medicación basal del paciente y dar el 100–150% de la dosis habitual como analgesia basal; no \"poner a dieta\" al paciente con opioides. Emesis: perfil de alto riesgo → profilaxis agresiva (ondansetrón + dexametasona + NK1 si se dispone). Mielosupresión: cuidado con la anestesia neuraxial (contar plaquetas), infecciones (asepsia estricta, evitar las vías rectales). Esteroides crónicos: cobertura de estrés. Venas malas: ecoguía si se dispone; PICC/Port-A-Cath: no punzar sin protocolo. Vigilar la sedación excesiva por dosis altas acumuladas."
    ),
    Topic(
        "Obesidad",
        "Dosis: peso ideal (IBW) para la mayoría de los fármacos... excepciones: suxametonio por peso TOTAL (masa colinérgica proporcional), rocuronio por peso ideal, propofol por peso total para la inducción (inicio rápido) y por peso ajustado en la infusión; opioides por peso ajustado. Vía aérea: preoxigenación 3 min en posición rampa/sentada (Fowler 25–30°) con CPAP + PEEP, RSI con cricoides, TOF obligatorio, equipo difícil (video-laringoscopio si se dispone), tubo más largo. Ventilación: Vt 6–8 mL/kg IBW, PEEP 5–10, reclutamiento, posición reverse Trendelenburg; capnografía siempre. Accesos: vía IV larga y firme (no en el antebrazo adiposo), PA con manguito ancho correcto o artérial si es difícil. Postoperatorio: posición sentada, O2 nocturno si SAHOS, CPAP propia del paciente, analgesia multimodal (evitar opioides largos), movilización temprana y profilaxis de trombosis. Peso corporal: BMI ≥40 (o ≥35 con comorbilidad): considerar derivación a centro bariátrico."
    ),
    Topic(
        "Inmunodeficiencia y paciente trasplantado",
        "VIH: precauciones universales (guantes, protección ocular, no reencapuchar las agujas); interacciones: ritonavir inhibe el CYP3A4 (midazolam oral contraindicado), efavirenz (metabolismo hepático), cuidar el delirium; glucocorticoides si hay insuficiencia suprarrenal (dosis de estrés). Trasplante de órganos: mantener la inmunosupresión (tacrolimus/ciclosporina: nefrotoxicidad añadida con los AINE y el NaCl masivo; monitorizar niveles); esteroides: cobertura de estrés; infecciones oportunistas: cuidado con el gabinete estéril; anestesia neuraxial con plaquetas y coagulación verificadas. Neutropenia (<1000/mm3): evitación de las vías rectales, cuidado con las punciones, antibiótico profiláctico según el protocolo, no dar aspirina/AINE, protección invertida (habitación estéril). Inmunoglobulinas y biológicos (rituximab, anti-TNF): calendario de vacunas y riesgo infeccioso documentado. Medicación: consultar siempre con el especialista del trasplante antes de modificar la inmunosupresión."
    )
)

// ------------------------------- BIBLIOGRAFÍA (24) -------------------------------

val BIBLIO = listOf(
    Biblio(
        "Miller's Anesthesia",
        "Miller RD (ed.). 10.ª edición, Elsevier, 2025. Referencia mundial integral de anestesiología: base molecular, farmacología, manejo perioperatorio y subespecialidades. Volúmenes 1–2."
    ),
    Biblio(
        "Anestesia Clínica (Barash, Cullen & Stoelting)",
        "Barash PG, Cullen BF, Stoelting RK, Cahalan MK (eds.). 9.ª edición, Lippincott Williams & Wilkins, 2025. Enfoque clínico orientado al manejo perioperatorio por especialidades quirúrgicas y comorbilidades."
    ),
    Biblio(
        "Smith and Aitkenhead's Textbook of Anaesthesia",
        "Cross M, Plunkett E (eds.). 8.ª edición, Elsevier, 2025. Texto británico clásico, claro y práctico: farmacología, física aplicada, vía aérea y anestesia por sistemas."
    ),
    Biblio(
        "Morgan and Mikhail's Clinical Anesthesiology",
        "Morgan GE, Mikhail MS, Murray MJ. 7.ª edición, McGraw-Hill, 2025. Formato conciso y de fácil consulta; muy usado en formación de posgrado: fisiología aplicada, farmacología y manejo clínico por capítulos."
    ),
    Biblio(
        "Anesthesiology Core Review",
        "Freeman BS, Berger JS (eds.). 2.ª edición, McGraw-Hill, 2024. Preparación para el examen oral de la especialidad: casos clínicos breves de alta rentabilidad didáctica, algoritmos de decisión rápida."
    ),
    Biblio(
        "Tratado de Anestesiología, Reanimación y Terapéutica del Dolor (SEDAR)",
        "Sociedad Española de Anestesiología, Reanimación y Terapéutica del Dolor (SEDAR), ed. José María Calvo Vecino. 1.ª edición, Panamericana, 2025. Referencia en español: anestesia, reanimación y tratamiento del dolor con enfoque iberoamericano."
    ),
    Biblio(
        "Braunwald's Heart Disease",
        "Libby P, Bonow RO, Mann DL, Tomaselli GF (eds.). 12.ª edición, Elsevier, 2025. La referencia mundial de cardiología: isquemia, insuficiencia cardíaca, valvulopatías y arritmias — base del paciente cardiópata anestésico."
    ),
    Biblio(
        "ESC Guidelines for Non-Cardiac Surgery: Cardiovascular Assessment and Management",
        "Halvorsen S, Mehilli J, Cassese S et al. European Society of Cardiology, European Heart Journal, 2022. Guía europea de evaluación cardíaca preoperatoria: riesgo, pruebas, antiagregación y anticoagulación perioperatoria."
    ),
    Biblio(
        "ACC/AHA Guideline on Perioperative Cardiovascular Management",
        "Lindman BR, Alexander KP, Baron SJ et al. American College of Cardiology/American Heart Association, Circulation, 2024. Guía americana del paciente que se operará: estratificación, manejo de fármacos crónicos y decisiones preoperatorias."
    ),
    Biblio(
        "Kaplan's Cardiac Anesthesia: In Noncardiac Surgery",
        "Kaplan JA, Augustides JGT (eds.). 8.ª edición, Elsevier, 2024. Anestesia cardíaca y del paciente cardíaco no operado de corazón: hemodinamia, eco transesofágico, CEC y destete."
    ),
    Biblio(
        "Anesthesia for Congenital Heart Disease",
        "Andropoulos DB, Stayer SA, Mossad EB, Miller-Hance WC (eds.). 4.ª edición, Wiley-Blackwell, 2024. Referencia en congénitas: shunts, fisiología cianótica, Fontan y el adulto operado de corazón congénito."
    ),
    Biblio(
        "Hurst's the Heart",
        "Fuster V, Narula J, Vaishnava P et al. (eds.). 15.ª edición, McGraw-Hill, 2025. Tratado clásico de cardiología: fisiopatología completa del corazón enfermo con enfoque clínico."
    ),
    Biblio(
        "Chestnut's Obstetric Anesthesia: Principles and Practice",
        "Wong CA, Eltzschig HK, Herzenberg JE (eds.). 6.ª edición, Elsevier, 2024. Referencia mundial en obstetricia anestésica: trabajo de parto, cesárea, preeclampsia, hemorragia y emergencias maternas."
    ),
    Biblio(
        "Pediatric Anesthesia (Cote & Lerman)",
        "Cote CJ, Lerman J, Anderson BJ (eds.). 6.ª edición, Elsevier, 2024. Anestesia pediátrica de referencia: vías aéreas, dosis, síndromes y cuidado perioperatorio del niño."
    ),
    Biblio(
        "Clinical Anesthesia Procedures of the Massachusetts General Hospital",
        "Department of Anesthesia, Critical Care and Pain Medicine, MGH. 10.ª edición, Wolters Kluwer, 2023. Manual de bolsillo de consulta rápida: pautas concisas para el quirófano y la sala de recuperación."
    ),
    Biblio(
        "Anesthesia and Uncommon Diseases",
        "Fleisher LA (ed.). 7.ª edición, Elsevier, 2021. Enfermedades raras y su impacto anestésico: síndromes, miopatías, alteraciones metabólicas y genéticas que modifican la conducta."
    ),
    Biblio(
        "Manual de Procedimientos en Anestesiología y Reanimación (MINSAP)",
        "Ministerio de Salud Pública de la República de Cuba. Manuales y protocolos nacionales de anestesiología: ajustados a la disponibilidad local de fármacos y equipos del sistema de salud cubano. Consultar la edición vigente en su hospital."
    ),
    Biblio(
        "Revista Cubana de Anestesiología y Reanimación",
        "Publicación científica cubana de la especialidad (ECIMED/Sociedad Cubana de Anestesiología y Reanimación): artículos originales, casos y protocolos adaptados al contexto nacional."
    ),
    Biblio(
        "Anesthesiology",
        "Revista oficial de la American Society of Anesthesiologists (ASA): investigación original, guías de práctica y revisiones de la especialidad."
    ),
    Biblio(
        "British Journal of Anaesthesia",
        "Revista oficial de la Royal College of Anaesthetists: evidencia y revisiones clásicas de fisiología, farmacología y outcome perioperatorio."
    ),
    Biblio(
        "Anesthesia & Analgesia",
        "Revista oficial de la International Anesthesia Research Society (IARS): ensayos clínicos, modelos farmacocinéticos y investigación de seguridad del paciente."
    ),
    Biblio(
        "Revista Española de Anestesiología y Reanimación (REDAR)",
        "Revista oficial de SEDAR: protocolos en español, manejo perioperatorio y documentos de consenso iberoamericanos."
    ),
    Biblio(
        "Malignant Hyperthermia Crisis Task Force Protocol",
        "Malignant Hyperthermia Association of the United States (MHAUS). Protocolo de crisis de hipertermia maligna (edición vigente en mhaus.org): el algoritmo de referencia mundial para la emergencia más temida de la anestesia."
    ),
    Biblio(
        "Crisis Management in Anesthesiology",
        "Gaba DM, Fish KJ, Howard SK, Burden AR. 2.ª edición, Saunders/Elsevier, 2015. Manual de crisis: cada emergencia perioperatoria en formato «reconocimiento → causa → acción» — la base didáctica de los simuladores."
    )
)

// ------------------------------- SOLUCIONES PARENTERALES -------------------------------

val SOLUTIONS_RAW = listOf(
    Topic(
        "NaCl 0,9% (Salino fisiológico)",
        "Cristaloide isotónico. Na+ 154 mEq/L, Cl− 154 mEq/L; osmolaridad 308 mOsm/L, pH 5,5. Sin K+, Ca2+ ni buffer. Uso: volumen de primera línea cuando no hay solución equilibrada, diluyente universal, arrastre, vía de fármacos (compatible con casi todo). Riesgo con volúmenes grandes (>3–4 L): acidosis hiperclorémica, vasoconstricción renal (↓ flujo cortical), hipokalemia. En neurocirugía y TCE es preferido (hipotónico evita el edema cerebral: el 0,9% es \"isotónico\" respecto al plasma)."
    ),
    Topic(
        "Lactato de Ringer (Hartmann)",
        "Cristaloide equilibrado/balanceado. Na+ 130, Cl− 109, K+ 4, Ca2+ 3 mEq/L, lactato 28 mEq/L (metabolizado a bicarbonato en el hígado); osmolaridad ~273 mOsm/L (ligeramente hipotónico respecto al plasma pero isotónico \"efectivo\"). Uso: fluidoterapia intraoperatoria de primera línea, hipovolemia, obstetricia (primera opción), quemados. Precauciones: NO como vehículo de sangre en la misma línea (Ca2+ coagula: usar filtro o enjuague con salino), evitar en insuficiencia hepática grave (no metaboliza el lactato) y en la hipercaliemia... el K+ es bajo pero presente."
    ),
    Topic(
        "Dextrosa 5% (SG 5%)",
        "Solución de dextrosa en agua: 50 g/L de glucosa, osmolaridad 252 mOsm/L (hipotónica efectiva: la glucosa se metaboliza y queda agua libre). Sin electrólitos. Uso: hipoglucemia, portadores de insulina con NPO, hiperkalemia + insulina, vehículo de fármacos específicos (amiodarona, noradrenalina), neonatos. NO usar como volumen de reanimación (agua libre → edema cerebral e hiponatremia dilucional). Máx. ~1–2 L/día en el adulto como agua libre."
    ),
    Topic(
        "NaCl 0,45% (Salino medio)",
        "Cristaloide hipotónico: Na+ 77, Cl− 77 mEq/L; osmolaridad 154 mOsm/L. Uso: rehidratación con déficit de agua libre, hipernatremia, mantenimiento pediátrico con dextrosa (SG 2,5% en 0,45% típico). Riesgo: hemólisis e hiponatremia si administración rápida o masiva; NO en hipovolemia (sale del vascular rápido), NO en TCE/neuro (edema cerebral)."
    ),
    Topic(
        "Coloides (HES, albúmina, gelatinas)",
        "Hidroxietil almidón 130/0,4 al 6%: efecto de expansión 1:1 durante 4–6 h; MÁXIMO 30 mL/kg/día; riesgo de lesión renal aguda y coagulopatía (evitar en sepsis grave, renal crítica, cirugía cardíaca con CPB y el paciente crítico renal: la EMA lo restringe). Albúmina 4–5%: segura, expande ~1× el volumen infundido; útil en la cirugía hepática, ascitis, hipoalbuminemia con hipovolemia; cara y escasa. Gelatinas (suciniladas): disponibles en algunos países; reacciones anafilactoides (~0,05–0,35%), expandidas 1×, sin límite de dosis estricto pero cuidado renal. Regla general: el cristaloide equilibrado es la primera línea; el coloide se usa para el volumen rápido con límites claros y vigilancia renal."
    ),
    Topic(
        "Albúmina humana 5%",
        "Coloide natural estéril: 5 g/100 mL (50 g/L) en electrolitos semejantes al plasma (Na+ 130–160 mEq/L); osmolaridad ~300 mOsm/L, presión oncótica similar al plasma; pH 6,7–7,3; calentada a 60 °C durante 10 h (sin riesgo viral conocido). Expande ~0,8–1× el volumen infundido y el efecto dura 3–6 h (varía con la fuga capilar). Usos con evidencia: paracentesis de gran volumen (>5 L: albúmina 6–8 g por litro extraído para prevenir la disfunción circulatoria), sepsis grave con hipoalbuminemia (el estudio ALBIOS usó albúmina 20 % con objetivo de albúmina sérica 4–5 g/dL, sin daño y con posible beneficio en sepsis con choque), síndrome hepatorrenal (con vasoconstrictor), y volumen en el paciente con hipoalbuminemia grave e hipovolemia cuando el cristaloide no alcanza. No indicada (el estudio SAFE la demostró equivalente al salino en el paciente crítico general, y en TCE puede aumentar la mortalidad): nutrición, hipovolemia sin hipoalbuminemia, TCE. Dosis habitual: 250–500 mL de 5% (o 50–100 mL de 20–25%, que expande 3–4×, cuidado con la sobrecarga). Precauciones: sobrecarga de volumen en insuficiencia cardíaca y renal, no diluir con agua estéril (hemólisis), vigilar el ionograma. En Cuba: disponibilidad limitada y costo alto — el cristaloide equilibrado sigue siendo la primera línea."
    ),
    Topic(
        "Reglas prácticas de fluidoterapia perioperatoria",
        "Mantenimiento: regla 4-2-1 (4 mL/kg/h el primer 10 kg, 2 mL/kg/h el segundo 10 kg, 1 mL/kg/h por cada kg restante). Déficit por ayuno: mantenimiento × horas de NPO; reponer 50% en la 1.ª hora + mantenimiento, 25% en la 2.ª y 3.ª. Sangrado: reponer cristaloide 3:1 o coloide 1:1 hasta el umbral transfusional (Hb 7–8 g/dL; <10 en isquemia). \"Liberal vs. restrictivo\": hoy balance por objetivos (beat-to-beat, SV variación <10–13% con ventilación controlada, diuresis >0,5 mL/kg/h). Pediatria: dextrosa de mantenimiento si NPO >4–6 h o neonato (evitar la hipoglucemia). Obstetricia: evitar el exceso de cristaloide antes de la espinal (no reduce la hipotensión y añade edema pulmonar)."
    ),
    Topic(
        "NaCl hipertónico (3% y 7,5%)",
        "NaCl 3%: Na+ 513 mEq/L, 1027 mOsm/L; NaCl 7,5%: 1283 mEq/L, 2567 mOsm/L. Extraen agua del tejido cerebral al espacio vascular (osmoterapia): TCE con signos de herniación, crisis hipertensiva intracraneal refractaria a manitol, y en la resucitación de hemorragia masiva en dosis pequeña (4 mL/kg de 7,5% históricamente) como expansor temporal. Administración: por vía central o periférica bien vigilada (3% puede ir periférico con control; 7,5% preferir central), bolos de 100–250 mL de 3% o 2–4 mL/kg, con Na sérico objetivo y control cada 4–6 h (ascenso máx. 8–12 mmol/L/día para evitar síndrome de desmielinización osmótica en hiponatremia crónica; en TCE el objetivo es 145–155 mmol/L). Vigilar potasio (los bolos lo reducen) y sobrecarga de volumen en insuficiencia cardíaca/renal. NO en deshidratación hipertónica simple ni como mantenimiento. Ante hemorragia masiva NO sustituye la sangre: solo gana tiempo."
    ),
    Topic(
        "Manitol 20%",
        "Osmótico: 0,25–1 g/kg (bolos de 100–200 mL de manitol 20% en el adulto) en 15–30 min. Acción: eleva la osmolaridad plasmática y extrae agua del parénquima cerebral (efecto en 10–20 min, pico 30–60 min, dura 2–6 h) y produce diuresis osmótica posterior. Indicaciones: crisis de hipertensión intracraneal (TCE con herniación, edema postoperatorio de tumor), reducción de presión intraocular en oftalmología, protección renal en cirugía vascular mayor (uso debatido). Contraindicaciones: anuria, insuficiencia cardíaca descompensada, edema pulmonar, hemorragia intracraneal activa con hemostasia no lograda, deshidratación grave. Precauciones: reponer el volumen perdido con cristaloide equilibrado (la diuresis osmótica vacía el paciente: la hipovolemia tardía empeora la perfusión cerebral), osmolaridad sérica objetivo <320 mOsm/L (por encima: riesgo de lesión renal aguda osmótica), electrolitos cada 4–6 h, tener sonda vesical. Si el paciente no diuresa tras manitol (fallo renal): suspender y pasar a hipertónico salino. No es alternativa a la cirugía descompresiva: es un puente temporal."
    )
)
