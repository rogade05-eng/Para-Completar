// Cronos Anestesia — Motor de cálculo puro (sin dependencias de UI)
package cu.cronos.anestesia.engine

import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

data class PatientState(
    val weight: Double = 70.0,
    val height: Double = 170.0,
    val ageValue: Double = 40.0,
    val ageUnit: String = "anios", // anios | meses
    val sex: String = "m",         // m | f
) {
    val ageMonths: Double get() = if (ageUnit == "anios") ageValue * 12.0 else ageValue
    val ageYears: Double get() = if (ageUnit == "anios") ageValue else ageValue / 12.0
    val isPeds: Boolean get() = ageMonths < 216.0
}

data class DerivedWeights(
    val bmi: Double,
    val ibw: Double,
    val lbw: Double,
    val bsa: Double,
    val volemiaMl: Int,
    val isPeds: Boolean,
    val ageMonths: Double,
)

fun round1(n: Double): Double = (n * 10).roundToInt() / 10.0
fun round2(n: Double): Double = (n * 100).roundToInt() / 100.0

fun fmt(n: Double): String {
    val r = (n * 100).roundToInt() / 100.0
    return if (r == r.toLong().toDouble()) r.toLong().toString() else {
        if (r * 10 == (r * 10).roundToInt().toDouble()) String.format(java.util.Locale.US, "%.1f", r)
        else String.format(java.util.Locale.US, "%.2f", r)
    }
}

// IMC
fun bmi(p: PatientState): Double = p.weight / (p.height / 100.0).pow(2)

// Peso ideal (Devine 1974)
fun devine(heightCm: Double, sex: String): Double {
    val inchesOver5ft = max(0.0, (heightCm - 152.4) / 2.54)
    return 50.0 + 2.3 * inchesOver5ft + if (sex == "f") -4.5 else 0.0
}

// Peso magro (Janmahasatian 2005)
fun leanBodyWeight(weightKg: Double, heightCm: Double, sex: String): Double {
    val h = heightCm / 100.0
    return if (sex == "m") {
        9270.0 * weightKg / (6680.0 + 216.0 * bmi(PatientState(weightKg, heightCm)))
    } else {
        9270.0 * weightKg / (8780.0 + 244.0 * bmi(PatientState(weightKg, heightCm)))
    }
}

// Superficie corporal (Mosteller)
fun bsa(weightKg: Double, heightCm: Double): Double = sqrt(heightCm * weightKg / 3600.0)

fun derive(p: PatientState): DerivedWeights {
    val volPerKg = when {
        p.ageMonths <= 24 -> 90.0
        p.ageMonths <= 144 -> 80.0
        else -> 70.0
    }
    return DerivedWeights(
        bmi = round1(bmi(p)),
        ibw = round1(devine(p.height, p.sex)),
        lbw = round1(leanBodyWeight(p.weight, p.height, p.sex)),
        bsa = round2(bsa(p.weight, p.height)),
        volemiaMl = (volPerKg * p.weight).roundToInt(),
        isPeds = p.isPeds,
        ageMonths = p.ageMonths,
    )
}

// ---------- Dosis en bolo ----------
data class BolusResult(
    val minDose: Double,   // en mg o mcg según kind
    val maxDose: Double,
    val minMl: Double,
    val maxMl: Double,
    val unit: String,      // "mg" | "mcg"
    val perKgNote: String, // detalle kg usado
)

/**
 * Calcula la dosis absoluta y el volumen:
 *  - mgkg: usa peso real; en obesidad (IMC ≥ 35) si useIbwOnObese usa IBW
 *  - mcgkg: peso real (opioideos) o LBW si useLbw
 *  - fixed: dosis absoluta, sin escalado
 * Los topes absolutos (minAbs/maxAbs, en mg) se aplican siempre.
 */
fun bolusDose(
    kind: String,
    min: Double,
    max: Double,
    weight: Double,
    derived: DerivedWeights,
    mgPerMl: Double,
    minAbs: Double? = null,
    maxAbs: Double? = null,
    pedsMin: Double? = null,
    pedsMax: Double? = null,
    useIbwOnObese: Boolean = false,
): BolusResult {
    val peds = derived.isPeds
    val w = if (!peds && useIbwOnObese && derived.bmi >= 35.0) derived.ibw else weight
    var lo: Double
    var hi: Double
    when (kind) {
        "fixed" -> { lo = min; hi = max }
        "mgkg" -> {
            lo = min * w; hi = max * w
            if (peds && pedsMin != null && pedsMax != null) { lo = pedsMin * w; hi = pedsMax * w }
        }
        "mcgkg" -> {
            lo = min * w; hi = max * w
            if (peds && pedsMin != null && pedsMax != null) { lo = pedsMin * w; hi = pedsMax * w }
        }
        else -> { lo = min * w; hi = max * w }
    }
    // Topes absolutos (en mg; convertir si kind es mcgkg)
    val factor = if (kind == "mcgkg") 1000.0 else 1.0
    minAbs?.let { lo = max(lo, it * factor) }
    maxAbs?.let { hi = min(hi, it * factor) }
    if (lo > hi) { val t = lo; lo = hi; hi = t }
    val loMl = lo / mgPerMl
    val hiMl = hi / mgPerMl
    val unit = if (kind == "mcgkg") "mcg" else "mg"
    val kgNote = if (!peds && useIbwOnObese && derived.bmi >= 35.0) "IBW ${fmt(derived.ibw)} kg (IMC ≥ 35)" else "peso ${fmt(w)} kg"
    return BolusResult(round2(lo), round2(hi), round2(loMl), round2(hiMl), unit, kgNote)
}

// ---------- Infusión ----------
data class InfusionResult(val minMlH: Double, val usualMlH: Double, val maxMlH: Double, val minGts: Int, val usualGts: Int, val maxGts: Int)

/** Conversión directa: (mcg/kg/min × kg × 60)/1000 = mg/h → mL/h según concentración. */
fun rateMlH(mcgKgMin: Double, weightKg: Double, mgPerMl: Double): Double {
    val mgPerH = mcgKgMin * weightKg * 60.0 / 1000.0
    return mgPerH / mgPerMl
}

fun infusionResult(min: Double, usual: Double, max: Double, weight: Double, mgPerMl: Double, gtsPerMl: Int = 20): InfusionResult {
    fun ml(v: Double) = round2(rateMlH(v, weight, mgPerMl))
    fun gts(v: Double) = (rateMlH(v, weight, mgPerMl) * gtsPerMl / 60.0).roundToInt()
    return InfusionResult(ml(min), ml(usual), ml(max), gts(min), gts(usual), gts(max))
}

// ---------- Gases ----------
/** MAC corregida por edad (Mapleson 1996): MAC_edad = MAC40 × 10^(−0.00269 × (edad − 40)) */
fun macForAge(mac40: Double, ageYears: Double): Double {
    val corrected = mac40 * 10.0.pow(-0.00269 * (ageYears - 40.0))
    return round2(corrected)
}

/** Mezcla aire/O2: FiO2 = (flujoAire × 0.21 + flujoO2) / flujoTotal */
fun fiO2Mix(airLMin: Double, o2LMin: Double): Double {
    val total = airLMin + o2LMin
    if (total <= 0.0) return 0.0
    return (airLMin * 0.21 + o2LMin) / total
}

// ---------- Ayuno (ASA 2-4-6-8) ----------
data class FastingRule(val item: String, val hours: Int)

val FASTING_RULES = listOf(
    FastingRule("Líquidos claros (agua, jugo sin pulpa, té, café sin leche)", 2),
    FastingRule("Leche materna", 4),
    FastingRule("Leche de fórmula / líquidos con grasa", 6),
    FastingRule("Comida ligera (tostada, jugo con pulpa)", 6),
    FastingRule("Comida pesada, fritos, grasas, carnes", 8),
)

/** Hora límite = hora quirúrgica − horas de ayuno (modular 24). */
fun fastingLimit(surgeryHour: Int, fastingHours: Int): Int = ((surgeryHour - fastingHours) % 24 + 24) % 24

// ---------- Hidratación transoperatoria (Holliday-Segar 4-2-1) ----------
data class Hydration(val mlH: Int, val mlDay: Int)

fun hollidaySegar(weightKg: Double): Hydration {
    val mlH = (min(weightKg, 10.0) * 4.0 + (max(0.0, min(weightKg, 20.0) - 10.0)) * 2.0 + max(0.0, weightKg - 20.0) * 1.0).roundToInt()
    return Hydration(mlH, mlH * 24)
}
