package cu.cronos.anestesia

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import java.io.OutputStream

// =====================================================================
//  CONSENTIMIENTO INFORMADO (v2.0.0): formulario oficial y explícito.
//  Entradas → vista previa del documento → copiar / compartir / exportar
//  a PDF (Carta o A4) / guardar en expediente. 100 % sin conexión.
// =====================================================================

@Composable
private fun ConsentField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    singleLine: Boolean = true
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = modifier.fillMaxWidth(),
        singleLine = singleLine,
        label = { Text(label) },
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.primary,
            cursorColor = MaterialTheme.colorScheme.primary
        )
    )
}

@Composable
fun ConsentTab(appVersion: String) {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current

    var institution by rememberSaveable { mutableStateOf("") }
    var service by rememberSaveable { mutableStateOf("") }
    var physician by rememberSaveable { mutableStateOf("") }
    var physicianLicense by rememberSaveable { mutableStateOf("") }
    var patientName by rememberSaveable { mutableStateOf("") }
    var patientId by rememberSaveable { mutableStateOf("") }
    var patientAge by rememberSaveable { mutableStateOf("") }
    var patientSex by rememberSaveable { mutableStateOf("") }
    var representative by rememberSaveable { mutableStateOf("") }
    var representativeRelation by rememberSaveable { mutableStateOf("") }
    var diagnosis by rememberSaveable { mutableStateOf("") }
    var procedure by rememberSaveable { mutableStateOf("") }
    var anesthesiaType by rememberSaveable { mutableStateOf(0) }
    var technique by rememberSaveable { mutableStateOf("") }
    var asaClass by rememberSaveable { mutableStateOf("") }
    var consentTransfusion by rememberSaveable { mutableStateOf(false) }
    var consentTeaching by rememberSaveable { mutableStateOf(false) }
    var place by rememberSaveable { mutableStateOf("") }
    var dateText by rememberSaveable { mutableStateOf("") }
    var timeText by rememberSaveable { mutableStateOf("") }
    var witness by rememberSaveable { mutableStateOf("") }
    var pdfSize by rememberSaveable { mutableStateOf(PdfExporter.SIZE_A4) }
    var showSave by rememberSaveable { mutableStateOf(false) }

    val data = ConsentData(
        institution = institution, service = service, physician = physician,
        physicianLicense = physicianLicense, patientName = patientName,
        patientId = patientId, patientAge = patientAge, patientSex = patientSex,
        representative = representative, representativeRelation = representativeRelation,
        diagnosis = diagnosis, procedure = procedure, anesthesiaType = anesthesiaType,
        technique = technique, asaClass = asaClass,
        consentTransfusion = consentTransfusion, consentTeaching = consentTeaching,
        place = place, dateText = dateText, timeText = timeText, witness = witness
    )
    val docText = remember(data, appVersion) { ConsentDoc.buildText(data, appVersion) }

    fun suggest(ext: String): String =
        "Consentimiento_" + data.procedure.ifBlank { "anestesia" }
            .map { c -> if (c.isLetterOrDigit() || c == ' ') c else '_' }
            .joinToString("").trim().replace(' ', '_').take(40) +
            "_" + RecFmt.day(RecFmt.now()) + "." + ext

    val pdfLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null) runCatching {
            ctx.contentResolver.openOutputStream(uri)?.use { os ->
                PdfExporter.writeConsent(ctx, os, pdfSize, data, appVersion)
            }
            Toast.makeText(ctx, R.string.rec_export_ok, Toast.LENGTH_SHORT).show()
        }.onFailure {
            Toast.makeText(ctx, R.string.rec_export_err, Toast.LENGTH_SHORT).show()
        }
    }

    ScreenColumn {
        Spacer(Modifier.height(sp.xs.dp))
        Text(
            stringResource(R.string.tab_consentimiento),
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            stringResource(R.string.consent_intro),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        SectionLabel(stringResource(R.string.consent_sec_patient))
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            ConsentField(patientName, { patientName = it }, stringResource(R.string.rec_name_label), Modifier.weight(1f))
            ConsentField(patientId, { patientId = it }, stringResource(R.string.consent_ci_label), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            ConsentField(patientAge, { patientAge = it }, stringResource(R.string.rec_age_label), Modifier.weight(1f))
            ConsentField(patientSex, { patientSex = it }, stringResource(R.string.consent_sex_label), Modifier.weight(1f))
        }
        ConsentField(representative, { representative = it }, stringResource(R.string.consent_rep_label))
        if (representative.isNotBlank()) {
            ConsentField(representativeRelation, { representativeRelation = it }, stringResource(R.string.consent_rep_rel_label))
        }

        SectionLabel(stringResource(R.string.consent_sec_procedure))
        ConsentField(diagnosis, { diagnosis = it }, stringResource(R.string.consent_dx_label))
        ConsentField(procedure, { procedure = it }, stringResource(R.string.consent_proc_label))
        Text(
            stringResource(R.string.consent_type_label),
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary
        )
        for (start in 0 until ConsentAnesthesia.TYPES.size step 2) {
            Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
                val count = minOf(2, ConsentAnesthesia.TYPES.size - start)
                for (c in 0 until count) {
                    val idx = start + c
                    AppButton(
                        ConsentAnesthesia.TYPES[idx],
                        secondary = anesthesiaType != idx,
                        modifier = Modifier.weight(1f),
                        onClick = { anesthesiaType = idx }
                    )
                }
            }
        }
        ConsentField(technique, { technique = it }, stringResource(R.string.consent_technique_label))
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            ConsentField(asaClass, { asaClass = it }, stringResource(R.string.consent_asa_label), Modifier.weight(1f))
            ConsentField(service, { service = it }, stringResource(R.string.consent_service_label), Modifier.weight(1f))
        }

        SectionLabel(stringResource(R.string.consent_sec_professional))
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            ConsentField(physician, { physician = it }, stringResource(R.string.consent_physician_label), Modifier.weight(1f))
            ConsentField(physicianLicense, { physicianLicense = it }, stringResource(R.string.consent_license_label), Modifier.weight(1f))
        }
        ConsentField(witness, { witness = it }, stringResource(R.string.consent_witness_label))

        SectionLabel(stringResource(R.string.consent_sec_specific))
        SegmentedRow(
            options = listOf(
                stringResource(R.string.consent_transfusion_no),
                stringResource(R.string.consent_transfusion_yes)
            ),
            selected = if (consentTransfusion) 1 else 0,
            onSelect = { consentTransfusion = it == 1 }
        )
        SegmentedRow(
            options = listOf(
                stringResource(R.string.consent_teaching_no),
                stringResource(R.string.consent_teaching_yes)
            ),
            selected = if (consentTeaching) 1 else 0,
            onSelect = { consentTeaching = it == 1 }
        )

        SectionLabel(stringResource(R.string.consent_sec_place))
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            ConsentField(place, { place = it }, stringResource(R.string.consent_place_label), Modifier.weight(1f))
            ConsentField(dateText, { dateText = it }, stringResource(R.string.consent_date_label), Modifier.weight(1f))
            ConsentField(timeText, { timeText = it }, stringResource(R.string.consent_time_label), Modifier.weight(1f))
        }

        SectionLabel(stringResource(R.string.consent_sec_preview))
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                Modifier
                    .padding(sp.m.dp)
                    .verticalScroll(rememberScrollState())
                    .height(320.dp)
            ) {
                ConsentDoc.buildBlocks(data, appVersion).forEach { b ->
                    when (b) {
                        is ConsentBlock.Header -> {
                            Spacer(Modifier.height(6.dp))
                            Text(
                                b.text,
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(Modifier.height(4.dp))
                        }
                        is ConsentBlock.Para -> Text(
                            b.text,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        is ConsentBlock.KeyValue -> Text(
                            "${b.key}: ${b.value}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        is ConsentBlock.Check -> Text(
                            (if (b.checked) "[X] " else "[ ] ") + b.label,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        is ConsentBlock.Signature -> Text(
                            "______________________  ${b.label}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        ConsentBlock.Divider -> Spacer(Modifier.height(8.dp))
                    }
                    Spacer(Modifier.height(6.dp))
                }
            }
        }

        SectionLabel(stringResource(R.string.consent_actions))
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            AppButton(
                stringResource(R.string.consent_copy),
                secondary = true,
                modifier = Modifier.weight(1f),
                onClick = {
                    clipboard.setText(AnnotatedString(docText))
                    Toast.makeText(ctx, R.string.consent_copied, Toast.LENGTH_SHORT).show()
                }
            )
            AppButton(
                stringResource(R.string.consent_share),
                secondary = true,
                modifier = Modifier.weight(1f),
                onClick = {
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, data.title)
                        putExtra(Intent.EXTRA_TEXT, docText)
                    }
                    ctx.startActivity(Intent.createChooser(intent, null))
                }
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            AppButton(
                stringResource(R.string.consent_pdf_a4),
                secondary = pdfSize == PdfExporter.SIZE_LETTER,
                modifier = Modifier.weight(1f),
                onClick = { pdfSize = PdfExporter.SIZE_A4; pdfLauncher.launch(suggest("pdf")) }
            )
            AppButton(
                stringResource(R.string.consent_pdf_letter),
                secondary = pdfSize == PdfExporter.SIZE_A4,
                modifier = Modifier.weight(1f),
                onClick = { pdfSize = PdfExporter.SIZE_LETTER; pdfLauncher.launch(suggest("pdf")) }
            )
        }
        if (LocalLicense.current.features.records) {
            AppButton(
                stringResource(R.string.rec_save_btn),
                onClick = { showSave = true }
            )
        }

        Text(
            stringResource(R.string.consent_disclaimer),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }

    if (showSave) {
        SaveRecordDialog(
            kind = "Documento",
            title = data.title,
            subtitle = data.anesthesiaTypeText,
            lines = ConsentDoc.summaryLines(data),
            onDismiss = { showSave = false }
        )
    }
}
