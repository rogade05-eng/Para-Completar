package cu.cronos.anestesia

import kotlin.math.roundToLong

/*
 * ============================================================================
 *  TARIFAS Y FORMAS DE PAGO (v1.6.0)
 *  ----------------------------------------------------------------------------
 *  Único lugar donde viven los precios, la cuenta de Transfermóvil y las
 *  reglas del flujo comercial:
 *    · El cliente PAGA PRIMERO (Transfermóvil en CUP, efectivo a conveniar o
 *      vía internacional negociada) y DESPUÉS recibe su clave por WhatsApp.
 *    · El importe en CUP se calcula con la tasa de cambio del dólar del día
 *      según elTOQUE: la app no aplica ninguna tasa por sí sola (offline).
 *    · El teléfono del cliente es la referencia para identificar quién hizo
 *      la transferencia, por eso viaja en todos los mensajes.
 *  Objeto puro (sin Android) para poder probarlo en JVM.
 * ============================================================================
 */
object Tariffs {

    /** Duraciones en venta. DURATION_DAYS = vigencia de la clave (0 = perpetua). */
    val DURATIONS = listOf("Mensual", "Trimestral", "Anual", "Perpetua")
    val DURATION_DAYS = listOf(30, 90, 365, 0)
    const val PERPETUAL_INDEX = 3

    /** Formas de pago aceptadas (se muestran como chips en la solicitud). */
    val PAYMENT_METHODS = listOf(
        "Transfermóvil (CUP)",
        "Tarjeta Clásica (USD)",
        "Efectivo (a conveniar)",
        "Internacional (a negociar)"
    )

    data class Plan(
        val key: String,       // BAS / PRO / INST (equivale a LicenseTier)
        val display: String,   // nombre visible
        val monthly: Int,      // USD / 30 días
        val quarterly: Int,    // USD / 90 días
        val annual: Int,       // USD / 365 días
        val perpetual: Int,    // USD pago único
        val note: String       // qué incluye, en una línea
    )

    val PLANS = listOf(
        Plan(
            "BAS", "Básica", 2, 5, 15, 25,
            "Todo el contenido, excepto la pestaña Clínica."
        ),
        Plan(
            "PRO", "Profesional", 4, 10, 35, 60,
            "Todo el contenido de la app, incluida la Clínica."
        ),
        Plan(
            "INST", "Institucional", 20, 50, 180, 300,
            "Uso institucional: licencia a nombre del hospital."
        )
    )

    /** Cuenta Transfermóvil (CUP) que recibe los pagos en Cuba: 16 dígitos. */
    const val TRANSFERMOVIL_ACCOUNT = "9234069992511687"

    /** Misma cuenta agrupada para leerla mejor; sin espacios para copiar. */
    const val TRANSFERMOVIL_ACCOUNT_DISPLAY = "9234 0699 9251 1687"

    /** Tarjeta Clásica en USD: el plan se paga exacto, sin conversión. */
    const val USD_ACCOUNT = "9760039003567228"

    /** Misma tarjeta agrupada para leerla mejor. */
    const val USD_ACCOUNT_DISPLAY = "9760 0390 0356 7228"

    fun priceUsd(plan: Plan, durationIndex: Int): Int = when (durationIndex) {
        0 -> plan.monthly
        1 -> plan.quarterly
        2 -> plan.annual
        else -> plan.perpetual
    }

    /** «Profesional · Anual» — etiqueta del plan para mensajes y resúmenes. */
    fun planLabel(plan: Plan, durationIndex: Int): String =
        plan.display + " · " + DURATIONS[durationIndex]

    /** Equivalente mensual aproximado (null en Mensual y en Perpetua). */
    fun perMonth(plan: Plan, durationIndex: Int): Double? = when (durationIndex) {
        1 -> plan.quarterly / 3.0
        2 -> plan.annual / 12.0
        else -> null
    }

    /** % de ahorro frente a pagar esos meses sueltos (null en Mensual/Perpetua). */
    fun savingsPercent(plan: Plan, durationIndex: Int): Int? {
        val months = when (durationIndex) {
            1 -> 3
            2 -> 12
            else -> return null
        }
        val full = plan.monthly * months
        val price = priceUsd(plan, durationIndex)
        if (full <= 0 || price >= full) return null
        return Math.round(100.0 * (full - price) / full).toInt()
    }

    /** USD → CUP con la tasa elTOQUE que introduce el usuario (pura). */
    fun cupFor(usd: Int, rate: Double): Long = Math.round(usd * rate)

    /** Acepta «440», «440,5», « 440.5 »; null si no es número > 0. */
    fun parseRate(text: String): Double? =
        text.trim().replace(',', '.').toDoubleOrNull()?.takeIf { it > 0.0 }

    /** 15400 → «15 400» (miles con espacio, sin decimales). */
    fun formatCup(n: Long): String {
        val digits = n.toString()
        val sign = if (n < 0) "-" else ""
        val body = if (n < 0) digits.substring(1) else digits
        val sb = StringBuilder()
        for ((i, c) in body.withIndex()) {
            if (i > 0 && (body.length - i) % 3 == 0) sb.append(' ')
            sb.append(c)
        }
        return sign + sb.toString()
    }

    /** 3.3333 → «3,33» (coma decimal, 2 cifras, sin ceros colgantes). */
    fun formatUsd2(v: Double): String {
        val r = Math.round(v * 100.0) / 100.0
        val s = if (r == Math.floor(r)) r.toLong().toString() else r.toString()
        return s.replace('.', ',')
    }

    /** Teléfono válido para identificar un pago: 8–15 dígitos. */
    fun isValidPaymentPhone(phone: String): Boolean {
        val d = LicenseContact.normalizePhone(phone)
        return d.length in 8..15
    }

    /**
     * Mensaje «Ya pagué» para WhatsApp (puro, testeable). Incluye el teléfono
     * de la transferencia —la referencia para saber quién pagó—, la moneda
     * usada (CUP con tasa elTOQUE del día, o USD exactos por la tarjeta
     * Clásica), y ambas cuentas receptoras para verificar en un vistazo.
     */
    fun buildPaymentMessage(
        versionName: String,
        deviceFormatted: String,
        planLabel: String,
        priceUsd: Int,
        phone: String,
        holder: String = "",
        cupText: String = "",
        paidCurrency: String = "CUP"
    ): String = buildString {
        append("Confirmación de pago — Cronos Anestesia\n")
        append("App: ").append(versionName).append('\n')
        append("Plan contratado: ").append(planLabel)
            .append(" (USD ").append(priceUsd).append(")\n")
        if (holder.isNotBlank()) append("Titular: ").append(holder.trim()).append('\n')
        append("Teléfono de la transferencia: ").append(phone.trim()).append('\n')
        append("ID del dispositivo: ").append(deviceFormatted).append('\n')
        append("Moneda pagada: ").append(if (paidCurrency == "USD") "USD" else "CUP").append('\n')
        if (paidCurrency == "USD") {
            append("Monto: USD ").append(priceUsd)
                .append(" exactos (sin conversión)\n")
        } else {
            append("Monto en CUP: ")
            if (cupText.isNotBlank()) append(cupText.trim())
            else append("____ (tasa del día según elTOQUE)")
            append('\n')
        }
        append("Comprobante: pegue aquí la captura o el número de operación\n")
        append("Cuenta CUP (Transfermóvil): ").append(TRANSFERMOVIL_ACCOUNT).append('\n')
        append("Cuenta USD (Tarjeta Clásica): ").append(USD_ACCOUNT)
    }
}
