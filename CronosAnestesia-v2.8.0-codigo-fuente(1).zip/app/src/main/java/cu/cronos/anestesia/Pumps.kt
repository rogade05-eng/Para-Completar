package cu.cronos.anestesia

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp

// =====================================================================
//  BOMBAS (v2.2.0) — requisito ⑧⑨ del usuario:
//   · Jeringa perfusora: dosis ↔ mL/h con las 5 unidades usuales de UCI,
//     autonomía de la jeringa y reglas de seguridad del recambio.
//   · TCI (perfusión objetivo): modelos Marsh, Schnider y Minto con
//     simulación plasma/efecto 100 % offline (Tci en CalcEngine.kt).
// =====================================================================

private fun fmt(v: Double): String = CalcEngine.fmt(v)

/** Tarjeta de resultado con guardado en el expediente (patrón Calcs2). */
@Composable
private fun PumpsResultCard(title: String, lines: List<Pair<String, String>>, tag: String) {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(sp.m.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.height(sp.xs.dp))
            lines.forEach { (k, v) ->
                Text(
                    k,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    v,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(sp.xs.dp))
            }
            AppButton(
                stringResource(R.string.exp_save_calc),
                secondary = true,
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    Expediente.saveCalc(ctx, title, tag)
                    Toast.makeText(ctx, ctx.getString(R.string.exp_saved), Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}

@Composable
private fun PumpNumField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    suffix: String,
    modifier: Modifier = Modifier.fillMaxWidth()
) {
    OutlinedTextField(
        value = value,
        onValueChange = { raw ->
            val cleaned = raw.filter { it.isDigit() || it == ',' || it == '.' }
            if (cleaned.length <= 6) onChange(cleaned)
        },
        modifier = modifier,
        singleLine = true,
        label = { Text(label) },
        suffix = { Text(suffix) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.primary,
            cursorColor = MaterialTheme.colorScheme.primary
        )
    )
}

// ---------------------------------------------------------------------------
//  1. JERINGA PERFUSORA
// ---------------------------------------------------------------------------

/** Diluciones usuales de UCI (µg/mL) para precargar la concentración. */
private val PUMP_PRESETS = listOf(
    "Noradrenalina 4 mg/50 mL" to 80.0,
    "Adrenalina 0,5 mg/50 mL" to 10.0,
    "Dopamina 200 mg/50 mL" to 4000.0,
    "Dobutamina 250 mg/50 mL" to 5000.0,
    "Fentanilo 0,5 mg/50 mL" to 10.0,
    "Remifentanilo 2,5 mg/50 mL" to 50.0,
    "Dexmedetomidina 200 µg/50 mL" to 4.0,
    "Propofol 1 % (10 mg/mL)" to 10000.0,
    "Ketamina 50 mg/50 mL" to 1000.0,
    "Midazolam 5 mg/50 mL" to 100.0,
    "Milrinona 10 mg/50 mL" to 200.0,
    "Nitroglicerina 50 mg/50 mL" to 1000.0
)

private val DOSE_UNITS = listOf("µg/kg/min", "µg/kg/h", "mg/kg/h", "µg/min", "mg/h")

@Composable
fun SyringeCalc() {
    val sp = LocalSpacing.current
    var inverse by rememberSaveable { mutableStateOf(0) }   // 0 = dosis→mL/h, 1 = mL/h→dosis
    var unit by rememberSaveable { mutableStateOf(0) }      // índice en DOSE_UNITS
    var dose by rememberSaveable { mutableStateOf("") }
    var mlhIn by rememberSaveable { mutableStateOf("") }
    var weight by rememberSaveable { mutableStateOf("70") }
    var conc by rememberSaveable { mutableStateOf("80") }
    var volume by rememberSaveable { mutableStateOf("50") }

    val w = CalcEngine.parseNum(weight)
    val c = CalcEngine.parseNum(conc)
    val vol = CalcEngine.parseNum(volume)

    // núcleo del cálculo: µg/min de la jeringa
    val ugMin: Double = if (inverse == 0) {
        CalcEngine.syringeDoseToUgMin(CalcEngine.parseNum(dose), DOSE_UNITS[unit], w)
    } else {
        CalcEngine.syringeMlHToUgMin(CalcEngine.parseNum(mlhIn), c)
    }
    val mlh: Double = if (inverse == 0) CalcEngine.syringeUgMinToMlH(ugMin, c) else CalcEngine.parseNum(mlhIn)
    val valid = w > 0 && c > 0 && ugMin > 0 && mlh > 0
    val durH = if (valid) CalcEngine.syringeDurationH(vol, mlh) else 0.0

    Column(Modifier.fillMaxWidth()) {
        Text(
            "La jeringa perfusora es la bomba de elección cuando el volumen horario es pequeño y la dosis debe ser precisa (vasopresores, opioides, sedantes). Calcule la velocidad en mL/h y la autonomía de la jeringa; en el modo inverso convierta una velocidad ya programada a dosis.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(sp.s.dp))

        SegmentedRow(listOf("Dosis → mL/h", "mL/h → Dosis"), inverse) { inverse = it }
        Spacer(Modifier.height(sp.s.dp))

        // --- Diluciones usuales ---
        SectionLabel("Diluciones usuales (precargar concentración)")
        PUMP_PRESETS.chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
                pair.forEachIndexed { i, (name, cc) ->
                    AppButton(
                        name,
                        secondary = conc != fmt(cc),
                        modifier = Modifier.weight(1f),
                        onClick = { conc = fmt(cc) }
                    )
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(sp.s.dp))

        if (inverse == 0) {
            PumpNumField(dose, { dose = it }, "Dosis prescrita", DOSE_UNITS[unit])
            Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
                DOSE_UNITS.take(3).forEachIndexed { i, u ->
                    AppButton(u, secondary = unit != i, modifier = Modifier.weight(1f), onClick = { unit = i })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
                DOSE_UNITS.drop(3).forEachIndexed { i, u ->
                    AppButton(u, secondary = unit != i + 3, modifier = Modifier.weight(1f), onClick = { unit = i + 3 })
                }
                Spacer(Modifier.weight(1f))
            }
        } else {
            PumpNumField(mlhIn, { mlhIn = it }, "Velocidad programada", "mL/h")
        }
        Spacer(Modifier.height(sp.s.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            PumpNumField(weight, { weight = it }, "Peso", "kg", Modifier.weight(1f))
            PumpNumField(conc, { conc = it }, "Concentración", "µg/mL", Modifier.weight(1f))
        }
        PumpNumField(volume, { volume = it }, "Volumen de la jeringa", "mL")

        if (valid) {
            Spacer(Modifier.height(sp.s.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f))
            ) {
                Column(Modifier.padding(sp.m.dp)) {
                    Text(
                        if (inverse == 0) "Velocidad de la bomba" else "Dosis administrada",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        if (inverse == 0) "${fmt(mlh)} mL/h" else "${fmt(CalcEngine.syringeMlHToUgMin(mlh, c) / maxOf(w, 1e-9))} µg/kg/min",
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
            Spacer(Modifier.height(sp.s.dp))
            val tag = buildString {
                append("Jeringa perfusora: ")
                if (inverse == 0) {
                    append(dose).append(" ").append(DOSE_UNITS[unit])
                    append(" · conc ").append(conc).append(" µg/mL → ").append(fmt(mlh)).append(" mL/h")
                } else {
                    append(mlhIn).append(" mL/h · conc ").append(conc).append(" µg/mL → ")
                    append(fmt(CalcEngine.syringeMlHToUgMin(mlh, c))).append(" µg/min")
                }
                append(" · peso ").append(fmt(w)).append(" kg · autonomía ").append(fmt(durH)).append(" h")
            }
            PumpsResultCard(
                "Resultado",
                listOf(
                    "Velocidad" to "${fmt(mlh)} mL/h",
                    "En µg/kg/min" to fmt(ugMin / maxOf(w, 1e-9)),
                    "En µg/kg/h" to fmt(ugMin * 60.0 / maxOf(w, 1e-9)),
                    "En mg/h" to fmt(ugMin * 60.0 / 1000.0),
                    "En µg/min" to fmt(ugMin),
                    "Autonomía de la jeringa" to if (durH >= 1.0) "${fmt(durH)} h (jeringa de ${fmt(vol)} mL)" else "${fmt(durH * 60.0)} min (jeringa de ${fmt(vol)} mL)"
                ),
                tag
            )
            Spacer(Modifier.height(sp.s.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(sp.m.dp)) {
                    Text(
                        "Seguridad con bombas de jeringa",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(sp.xs.dp))
                    Text(
                        "· Recambio sin interrupción: prepare la jeringa nueva y el segundo canal ANTES de terminar la actual (técnica de doble bomba); nunca detenga un vasopresor «un momento».\n" +
                            "· Existe dosis residual: 1–2 mL quedan en la línea y el conector al cambiar la jeringa; no purgue el vial hacia el paciente.\n" +
                            "· Mantenga la vía exclusiva y rotulada; vigile la alarma de oclusión y revísela al bajar el brazo de la cama (sifonaje o reflujo).\n" +
                            "· Al arrancar una jeringa nueva el émbolo debe estar cargado y purgado; el arranque puede tardar (backlash): en fármacos vitales no permita bajas de dosis por demora.\n" +
                            "· Rótula la jeringa: fármaco, concentración, diluyente, fecha y hora. Una jeringa sin rotular se considera no válida.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
//  2. BOMBAS TCI (perfusión objetivo)
// ---------------------------------------------------------------------------

private data class TciModel(
    val label: String,
    val isPropofol: Boolean,   // false = remifentanilo (Minto)
    val useDemographics: Boolean,
    val concDefault: String,
    val concUnit: String,
    val targetUnit: String,
    val targetHint: String,
    val massUnit: String       // unidad del bolo: mg o µg
)

private val TCI_MODELS = listOf(
    TciModel("Propofol · Marsh", true, false, "10", "mg/mL", "µg/mL", "habituales 2–8", "mg"),
    TciModel("Propofol · Schnider", true, true, "10", "mg/mL", "µg/mL", "habituales 2–6", "mg"),
    TciModel("Remifentanilo · Minto", false, true, "50", "µg/mL", "ng/mL", "habituales 2–8 en infusiones LMA; 4–10 con TIVA", "µg")
)

@Composable
fun TciCalc() {
    val sp = LocalSpacing.current
    var model by rememberSaveable { mutableStateOf(0) }
    var age by rememberSaveable { mutableStateOf("40") }
    var weight by rememberSaveable { mutableStateOf("70") }
    var height by rememberSaveable { mutableStateOf("170") }
    var male by rememberSaveable { mutableStateOf(0) }
    var target by rememberSaveable { mutableStateOf("4") }
    var conc by rememberSaveable { mutableStateOf("10") }
    var effect by rememberSaveable { mutableStateOf(0) } // 0 plasma, 1 efecto

    val m = TCI_MODELS[model]
    val w = CalcEngine.parseNum(weight)
    val ageY = CalcEngine.parseNum(age)
    val hCm = CalcEngine.parseNum(height)
    val tgt = CalcEngine.parseNum(target)
    val concMgMl = CalcEngine.parseNum(conc)

    val params = remember(model, ageY, w, hCm, male) {
        when {
            model == 0 && w > 0 -> Tci.marsh(w)
            model == 1 && w > 0 && hCm > 0 -> Tci.schnider(ageY, w, hCm, male == 0)
            model == 2 && w > 0 && hCm > 0 -> Tci.minto(ageY, w, hCm, male == 0)
            else -> null
        }
    }
    val sim = remember(params, tgt, effect) {
        if (params != null && tgt > 0) try {
            Tci.simulate(params, tgt, effect == 1)
        } catch (e: Exception) {
            null
        } else null
    }
    val maintMlH = if (params != null && tgt > 0 && concMgMl > 0) Tci.maintenanceMgMin(params, tgt) * 60.0 / concMgMl else 0.0

    Column(Modifier.fillMaxWidth()) {
        Text(
            "La perfusión objetivo (TCI) programa el fármaco por CONCENTRACIÓN, no por velocidad: usted elige la concentración deseada en sangre (Cp) o en el sitio de efecto (Ce) y la bomba calcula los bolos y velocidades. Esta calculadora reproduce los modelos Marsh, Schnider y Minto para planificar la inducción y explicar los números de la bomba.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(sp.s.dp))

        SegmentedRow(TCI_MODELS.map { it.label }, model) { model = it }
        if (m.useDemographics) {
            Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
                PumpNumField(age, { age = it }, "Edad", "años", Modifier.weight(1f))
                PumpNumField(weight, { weight = it }, "Peso", "kg", Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
                PumpNumField(height, { height = it }, "Talla", "cm", Modifier.weight(1f))
                Column(Modifier.weight(1f)) {
                    SegmentedRow(listOf("H", "M"), male) { male = it }
                }
            }
        } else {
            PumpNumField(weight, { weight = it }, "Peso", "kg")
        }
        Spacer(Modifier.height(sp.s.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            PumpNumField(target, { target = it }, "Objetivo (${m.targetUnit})", m.targetUnit, Modifier.weight(1f))
            PumpNumField(conc, { conc = it }, "Conc. jeringa", m.concUnit, Modifier.weight(1f))
        }
        SegmentedRow(listOf("Plasma (Cp)", "Efecto (Ce)"), effect) { effect = it }
        Spacer(Modifier.height(sp.xs.dp))
        Text(
            "Objetivos ${m.targetHint} ${m.targetUnit}; ajuste según edad, ASA y estimulación. En modo efecto la bomba da un bolo mayor (limitado a 2× el objetivo) para alcanzar la Ce rápido.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        if (params != null && sim != null && concMgMl > 0) {
            Spacer(Modifier.height(sp.s.dp))
            val bolus = sim.bolusMg
            val bolusPerKg = bolus / maxOf(w, 1e-9)
            val rate0MlH = sim.rate0MgMin * 60.0 / concMgMl
            val maintMlH2 = maintMlH
            val tag = buildString {
                append("TCI ${m.label}: objetivo ").append(fmt(tgt)).append(" ").append(m.targetUnit)
                append(if (effect == 1) " (Ce)" else " (Cp)")
                append(" · bolo ").append(fmt(bolus)).append(" ").append(m.massUnit)
                append(" · mantenimiento ").append(fmt(maintMlH2)).append(" mL/h")
                append(" · Ce90 ").append(fmt(sim.timeToCe90Min)).append(" min")
                if (m.useDemographics) append(" · ").append(fmt(ageY)).append(" años · ").append(fmt(w)).append(" kg · ").append(fmt(hCm)).append(" cm")
            }
            PumpsResultCard(
                "Plan de inducción (${m.label})",
                listOf(
                    if (params.lbw > 0.0) "Masa magra (modelo)" to "${fmt(params.lbw)} kg" else "Modelo por peso total" to "V1 ${fmt(params.v1)} L · Cl1 ${fmt(params.cl1 * 1000.0)} mL/min",
                    "Bolo de inducción" to "${fmt(bolus)} ${m.massUnit} (${fmt(bolusPerKg)} ${if (m.isPropofol) "mg/kg" else "µg/kg"})",
                    "Velocidad de mantenimiento" to "${fmt(maintMlH2)} mL/h (C × Cl1)",
                    "Velocidad inicial (pico)" to "${fmt(rate0MlH)} mL/h durante el primer minuto",
                    "Tiempo hasta Ce ≥ 90 %" to "${fmt(sim.timeToCe90Min)} min (ke0 ${fmt(params.ke0)}/min)",
                    "Dosis total a 30 min" to "${fmt(sim.cum30Mg)} ${m.massUnit}",
                    "Cp máxima" to "${fmt(sim.maxCp)} ${m.targetUnit}" + if (sim.maxCp > 2.0 * tgt) " — revísela" else ""
                ),
                tag
            )
            Spacer(Modifier.height(sp.s.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(sp.m.dp)) {
                    Text(
                        "Perfil simulado (Cp y Ce, velocidad de bomba)",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(sp.xs.dp))
                    Text(
                        "t (min) · Cp (${m.targetUnit}) · Ce (${m.targetUnit}) · mL/h",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    sim.steps.forEach { s ->
                        Text(
                            "${fmt(s.tMin)} · ${fmt(s.cp)} · ${fmt(s.ce)} · ${fmt(s.rateMgMin * 60.0 / concMgMl)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(Modifier.height(sp.xs.dp))
                    Text(
                        "Herramienta EDUCATIVA para planificar y entender la TCI: no sustituye a la bomba certificada ni al monitor de profundidad. Valide siempre la vía, la concentración de la jeringa y la respuesta clínica.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
