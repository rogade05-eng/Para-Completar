package cu.cronos.anestesia

// =====================================================================
//  CONSENTIMIENTO INFORMADO ANESTÉSICO (v2.0.0)
//  Texto oficial y explícito, alineado con la Ley No. 156 «De la Salud
//  Pública» de la República de Cuba (2022), los principios éticos de la
//  Asociación Médica Mundial (Declaración de Helsinki) y las prácticas
//  internacionales de anestesia. Estructura: identificación → descripción
//  del procedimiento → riesgos explícitos por técnica → beneficios →
//  alternativas → declaración de voluntariedad → firmas.
//  100 % offline: se completa con los datos del expediente y se exporta
//  a PDF para imprimir y firmar.
// =====================================================================

object Consent {

    /** Tipos de técnica anestésica seleccionables. */
    val TYPES = listOf(
        "Anestesia general",
        "Anestesia general + bloqueo regional",
        "Raquianestesia (subaracnoidea)",
        "Anestesia epidural",
        "Sedación + anestesia local",
        "Bloqueo regional periférico"
    )

    /** Riesgos generales aplicables a cualquier anestesia. */
    val RISKS_COMMON = listOf(
        "Náuseas y vómitos postoperatorios (frecuentes; se aplica profilaxis)",
        "Dolor en el sitio de punción o en la garganta (intubación)",
        "Reacción alérgica a los fármacos anestésicos (de leve a grave)",
        "Lesiones dentales, de labios o lengua durante la laringoscopia (excepcional; informe previo de dentadura)",
        "Temblores (escalofríos) y sensación de frío en la recuperación",
        "Retención urinaria o necesidad de sonda vesical",
        "Dolor de cabeza postoperatorio",
        "Confusión o delirio transitorio, especialmente en el adulto mayor",
        "Caída de la presión arterial o alteraciones del ritmo cardíaco durante la anestesia (vigiladas y tratadas en el momento)"
    )

    /** Riesgos específicos de la anestesia general con vía aérea. */
    val RISKS_GENERAL = listOf(
        "Dificultad para intubar o para ventilar (vía aérea difícil): puede requerir técnicas especiales o despertar al paciente",
        "Aspiración de contenido gástrico al pulmón (neumonía aspirativa) si no se respetan las indicaciones de ayuno",
        "Laringoespasmo o broncoespasmo (obstrucción de la vía aérea)",
        "Hipoxemia (bajada del oxígeno en sangre) y necesidad de ventilación mecánica prolongada",
        "Daño a los labios, dientes, lengua o cuerdas vocales; ronquera transitoria",
        "Mialgias (dolor muscular) por relajantes, especialmente con succinilcolina",
        "Anestesia demasiado profunda o insuficiente (con registros de monitorización continua para evitarlo)",
        "Hipertermia maligna (reacción metabólica muy rara, aproximadamente 1 de cada 100 000 anestesias, con protocolo de tratamiento disponible)"
    )

    /** Riesgos específicos de las técnicas neuraxiales (raquídea/epidural). */
    val RISKS_NEURAXIAL = listOf(
        "Cefalea postpunción dural (escape de líquido cefalorraquídeo): frecuente si se punciona la dura; puede requerir tratamiento (sello epidural)",
        "Hipotensión (caída de la presión arterial) con riesgo de mareo, náuseas o afectación del bebé en obstetricia: se previene con volumen y vasopresores",
        "Bloqueo insuficiente o de un solo lado que obligue a convertir a anestesia general",
        "Prurito, escalofríos o dificultad para orinar transitorios",
        "Hematoma o absceso epidural (complicación muy grave y muy rara): puede comprimir la médula y exigir cirugía urgente; se vigila la coagulación antes de puncionar",
        "Lesión neurológica directa del nervio o la médula (parálisis o pérdida de sensibilidad permanente: excepcional, menos de 1 de cada 100 000–150 000)",
        "Infección en el sitio de punción",
        "Convulsión por inyección intravascular accidental del anestésico local (toxicidad sistémica: LAST)"
    )

    /** Riesgos de bloqueos periféricos y sedación. */
    val RISKS_REGIONAL = listOf(
        "Bloqueo incompleto o de duración más corta/larga de lo esperado",
        "Parestesias (hormigueo) o lesión del nervio punturado, habitualmente transitorias",
        "Neumotórax (pulmón pinchado) en bloqueos cercanos al tórax/cuello",
        "Inyección intravascular con toxicidad de anestésico local (LAST): convulsiones o arritmias, con protocolo de lípidos disponible",
        "Hematoma en el sitio de punción o lesión de vasos próximos",
        "Infección en el sitio de punción",
        "Falla del bloqueo que obligue a convertir a anestesia general",
        "Dolor durante el procedimiento si el bloqueo es insuficiente",
        "Caída de la presión arterial por simpaticolisis si el bloqueo es extenso"
    )

    val RISKS_SEDATION = listOf(
        "Depresión respiratoria (frenación de la respiración) que puede exigir apoyo con oxígeno o vía aérea",
        "Sedación insuficiente (recuerdo del procedimiento) o excesiva",
        "Agitación paradójica, especialmente en el adulto mayor",
        "Aspiración si no se respetan las indicaciones de ayuno",
        "Hipotensión o bradicardia transitorias durante la sedación",
        "Cefalea, mareo o somnolencia prolongada en la recuperación",
        "Dolor en el sitio de inyección",
        "Reacción alérgica a los fármacos sedantes"
    )

    /** Bloques de texto del documento: (encabezado, cuerpo) + estilo PDF (0 título, 1 encabezado, 2 cuerpo). */
    fun buildBlocks(
        patient: Patient,
        anesthesiologist: String,
        institution: String,
        service: String,
        technique: String,
        procedure: String,
        risksExtra: String,
        date: String,
        asa: String
    ): List<Triple<String, Int, String>> = buildList {
        add(Triple("CONSENTIMIENTO INFORMADO PARA ANESTESIA", 0, ""))
        add(Triple(
            "Marco legal y ético. Yo, como paciente (o su representante legal), ejerzo mi derecho a recibir información veraz, completa y comprensible sobre el procedimiento anestésico propuesto, y a otorgar o negar mi consentimiento de forma libre y voluntaria, conforme a la Ley No. 156 «De la Salud Pública» de la República de Cuba, el Código de Ética Médica y los principios de la Declaración de Helsinki de la Asociación Médica Mundial. Ningún procedimiento anestésico se realizará sin mi consentimiento informado, salvo emergencia que comprometa la vida y me sea imposible expresar mi voluntad, situación que se documentará en la historia clínica.",
            2, ""
        ))

        add(Triple("1. IDENTIFICACIÓN DEL PACIENTE", 1, ""))
        add(Triple(
            "Nombre y apellidos: ${patient.name.ifBlank { "___________" }}\n" +
                "Carné de identidad: ${patient.ci.ifBlank { "___________" }}\n" +
                "Edad: ${patient.age.ifBlank { "____" }} años    Sexo: ${patient.sex.ifBlank { "____" }}\n" +
                "Peso: ${patient.weightKg.ifBlank { "____" }} kg    Altura: ${patient.heightCm.ifBlank { "____" }} cm\n" +
                "Antecedentes médicos declarados: ${patient.hx.ifBlank { "____________________________________" }}\n" +
                "Clasificación física ASA: $asa",
            2, ""
        ))

        add(Triple("2. IDENTIFICACIÓN DEL PROFESIONAL Y DE LA INSTITUCIÓN", 1, ""))
        add(Triple(
            "Institución: ${institution.ifBlank { "___________" }}\n" +
                "Servicio: ${service.ifBlank { "___________" }}\n" +
                "Anestesiólogo responsable: ${anesthesiologist.ifBlank { "___________" }}\n" +
                "Fecha: $date",
            2, ""
        ))

        add(Triple("3. DESCRIPCIÓN DEL PROCEDIMIENTO PROPUESTO", 1, ""))
        add(Triple(
            "Intervención o procedimiento quirúrgico previsto: ${procedure.ifBlank { "___________" }}\n" +
                "Técnica anestésica propuesta: $technique.\n\n" +
                "La anestesia es un acto médico que mediante fármacos y técnicas específicas suprime o bloquea la sensibilidad y la conciencia (según la técnica) para permitir la cirugía de forma segura e indolora. Incluye la vigilancia continua con monitorización de la actividad eléctrica del corazón, la presión arterial, la oxigenación de la sangre (SpO2) y la concentración de CO2 espirado (capnografía), así como la atención de la vía aérea, la administración de fluidos y medicamentos, y el cuidado en la recuperación posanestésica hasta el alta de la sala de recuperación.",
            2, ""
        ))

        add(Triple("4. RIESGOS Y COMPLICACIONES POSIBLES", 1, ""))
        add(Triple(
            "A pesar de que la anestesia moderna es muy segura gracias a la monitorización continua y a los protocolos de seguridad, ningún acto anestésico está exento de riesgos. Declaro haber sido informado(a), en lenguaje claro, de los riesgos generales y de los específicos de la técnica propuesta, descritos a continuación.",
            2, ""
        ))
        add(Triple("4.1 Riesgos generales (cualquier técnica anestésica)", 2, ""))
        add(Triple(RISKS_COMMON.joinToString("\n") { "•  $it" }, 2, ""))
        when (technique) {
            TYPES[0], TYPES[1] -> {
                add(Triple("4.2 Riesgos específicos de la anestesia general", 2, ""))
                add(Triple(RISKS_GENERAL.joinToString("\n") { "•  $it" }, 2, ""))
            }
            TYPES[2], TYPES[3] -> {
                add(Triple("4.2 Riesgos específicos de la técnica neuraxial (raquídea/epidural)", 2, ""))
                add(Triple(RISKS_NEURAXIAL.joinToString("\n") { "•  $it" }, 2, ""))
            }
            TYPES[4] -> {
                add(Triple("4.2 Riesgos específicos de la sedación", 2, ""))
                add(Triple(RISKS_SEDATION.joinToString("\n") { "•  $it" }, 2, ""))
            }
            TYPES[5] -> {
                add(Triple("4.2 Riesgos específicos del bloqueo regional periférico", 2, ""))
                add(Triple(RISKS_REGIONAL.joinToString("\n") { "•  $it" }, 2, ""))
            }
        }
        add(Triple("4.3 Riesgos graves excepcionales", 2, ""))
        add(Triple(
            "•  Reacción anafiláctica grave a fármacos (aproximadamente 1 de cada 10 000–20 000 anestesias), con equipo de reanimación disponible de inmediato.\n" +
                "•  Paro cardíaco o daño cerebral por hipoxia (extremadamente raro).\n" +
                "•  Muerte atribuible exclusivamente a la anestesia (menos de 1 de cada 100 000–200 000 anestesias según las series internacionales).\n" +
                "•  Complicaciones derivadas de condiciones previas del paciente (enfermedad cardíaca, pulmonar, renal, diabetes, obesidad, vía aérea difícil) que aumentan individualmente los riesgos anteriores.",
            2, ""
        ))
        if (risksExtra.isNotBlank()) {
            add(Triple("4.4 Riesgos particulares comunicados por el anestesiólogo", 2, ""))
            add(Triple(risksExtra, 2, ""))
        }

        add(Triple("5. BENEFICIOS ESPERADOS", 1, ""))
        add(Triple(
            "Realizar el procedimiento quirúrgico o diagnóstico de forma indolora y segura, con la mayor comodidad posible, control de las funciones vitales durante toda la intervención y tratamiento del dolor postoperatorio mediante técnicas y fármacos específicos.",
            2, ""
        ))

        add(Triple("6. ALTERNATIVAS DISPONIBLES", 1, ""))
        add(Triple(
            "Se me ha explicado que existen, cuando el procedimiento lo permite, técnicas anestésicas alternativas (por ejemplo: anestesia regional en lugar de general, o viceversa) y sus ventajas e inconvenientes. También se me ha explicado la alternativa de NO realizarme el procedimiento anestésico, que implica renunciar a la cirugía o al diagnóstico propuesto, con las consecuencias que el especialista tratante me ha informado sobre mi salud.",
            2, ""
        ))

        add(Triple("7. DERECHOS DEL PACIENTE", 1, ""))
        add(Triple(
            "•  Recibir toda la información que solicite y hacer las preguntas que considere necesarias antes de firmar.\n" +
                "•  Revocar este consentimiento en cualquier momento antes del procedimiento, sin que ello afecte la calidad de la atención que recibiré.\n" +
                "•  Solicitar una segunda opinión sobre el plan anestésico.\n" +
                "•  Que un familiar o acompañante esté informado, si así lo deseo.\n" +
                "•  Recibir el tratamiento del dolor postoperatorio y comunicar cualquier molestia durante la recuperación.",
            2, ""
        ))

        add(Triple("8. DECLARACIÓN Y AUTORIZACIÓN", 1, ""))
        add(Triple(
            "Declaro que he leído (o me ha sido leído) este documento, que comprendo su contenido, que se me ha explicado la naturaleza del procedimiento anestésico, sus riesgos, beneficios y alternativas, y que se han respondido todas mis preguntas de forma satisfactoria. Autorizo de forma libre y expresa al equipo anestésico a realizar la técnica descrita y las medidas concomitantes que el procedimiento requiera (vía aérea, canalización venosa, monitorización, transfusión de hemoderivados si fuese estrictamente necesaria para la vida).",
            2, ""
        ))

        add(Triple("9. FIRMAS", 1, ""))
        add(Triple(
            "Paciente (o representante legal)\n\nNombre: ______________________    CI: ____________________\n\nFirma: ______________________    Fecha y hora: __________________\n\n" +
                "Anestesiólogo responsable\n\nNombre: ${anesthesiologist.ifBlank { "______________________" }}    CI: ____________________\n\nFirma: ______________________    Fecha y hora: __________________\n\n" +
                "Testigo\n\nNombre: ______________________    CI: ____________________\n\nFirma: ______________________    Fecha y hora: __________________",
            2, ""
        ))
        add(Triple(
            "El original se archiva en la historia clínica y se entrega copia al paciente. Este documento fue generado por la aplicación Cronos Anestesia como apoyo a la práctica clínica; su validez formal se ajusta a la normativa vigente de la institución.",
            2, ""
        ))
    }

    /** Resumen de riesgos para la vista previa en pantalla. */
    fun riskSummary(technique: String): List<String> =
        RISKS_COMMON + when (technique) {
            TYPES[0], TYPES[1] -> RISKS_GENERAL
            TYPES[2], TYPES[3] -> RISKS_NEURAXIAL
            TYPES[4] -> RISKS_SEDATION
            TYPES[5] -> RISKS_REGIONAL
            else -> emptyList()
        }
}
