// Cronos Anestesia — Tipos del catálogo maestro (espejo del motor de la demo web)
package cu.cronos.anestesia.data

// ---------- Fuentes bibliográficas ----------
data class Source(val id: String, val label: String)

object Sources {
    val ALL = listOf(
        Source("morgan", "Morgan & Mikhail, Clinical Anesthesiology 7.ª ed."),
        Source("miller", "Miller's Anesthesia 10.ª ed."),
        Source("barash", "Barash, Clinical Anesthesia 9.ª ed."),
        Source("smith", "Smith & Aitkenhead, Textbook of Anaesthesia 8.ª ed."),
        Source("core", "Core Review for Anesthesiology 2.ª ed."),
        Source("sedar", "Manual SEDAR de Anestesiología 1.ª ed."),
    )

    fun label(id: String): String = ALL.firstOrNull { it.id == id }?.label ?: id
}

// ---------- Fármacos ----------
// kind: "mgkg" (mg/kg) | "mcgkg" (mcg/kg) | "fixed" (mg totales)
// Cada dosis admite tope absoluto (minAbs/maxAbs en mg) y variante pediátrica.
data class Dose(
    val label: String,
    val route: String,
    val kind: String,
    val min: Double,
    val max: Double,
    val minAbs: Double? = null,
    val maxAbs: Double? = null,
    val pedsMin: Double? = null,
    val pedsMax: Double? = null,
    val note: String = "",
    val source: String = "morgan",
)

data class Drug(
    val id: String,
    val name: String,
    val aliases: List<String> = emptyList(),
    val category: String,
    val concentration: String,
    val mgPerMl: Double,
    val doses: List<Dose>,
    val warnings: List<String> = emptyList(),
)

// ---------- Infusiones (mcg/kg/min → mL/h) ----------
data class Infusion(
    val id: String,
    val name: String,
    val mgPerMl: Double,        // concentración tras dilución indicada
    val dilution: String,
    val minMcgKgMin: Double,
    val maxMcgKgMin: Double,
    val usualMcgKgMin: Double,
    val note: String = "",
    val source: String = "morgan",
)

// ---------- Gases ----------
data class Gas(
    val id: String,
    val name: String,
    val mac40: Double,          // MAC en adulto de 40 años (CAM 1 atm)
    val note: String = "",
    val source: String = "miller",
)

// ---------- Soluciones parenterales ----------
data class Solution(
    val name: String,
    val osm: String,
    val use: String,
    val caution: String = "",
)

// ---------- Escenarios del asistente ----------
data class Scenario(
    val id: String,
    val title: String,
    val steps: List<String>,
    val jumpToDrug: String = "",
)

// ---------- Premedicación ----------
data class PremedItem(val drug: String, val dose: String, val timing: String)

data class PremedProtocol(
    val id: String,
    val name: String,
    val purpose: String,
    val items: List<PremedItem>,
    val notes: List<String> = emptyList(),
    val source: String = "morgan",
)

data class ChronicMed(val group: String, val examples: String, val action: String, val detail: String)

// ---------- Comorbilidades ----------
// Ampliadas en v2.3.0: título, resumen ejecutivo, listas por fase
// (preop / intraop / evitar / postop) y cita bibliográfica directa (src).
data class Comorbidity(
    val id: String,
    val titulo: String,
    val resumen: String,
    val preop: List<String>,
    val intraop: List<String>,
    val evitar: List<String>,
    val postop: List<String>,
    val src: String,
)
