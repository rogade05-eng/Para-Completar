package cu.cronos.anestesia

/*
 * ============================================================================
 *  STUDY DATA 2/2 (v2.7.0) — Escuela de Residentes: áreas 7–12.
 *  Fluidos y sangre · Perioperatorio y comorbilidades · Obstetricia ·
 *  Pediatría · Dolor · Crisis y emergencias.
 * ============================================================================
 */

val STUDY_AREAS_2: List<StudyArea> = listOf(

    // ============================== 7. FLUIDOS Y SANGRE ==============================
    StudyArea(
        id = "flu",
        name = "Fluidos y sangre",
        desc = "Fluidoterapia racional, reposición del sangrado y terapia transfusional restrictiva.",
        cards = listOf(
            StudyCard(
                "Cristaloides, coloides y elección",
                "La elección del fluido depende del objetivo (mantenimiento, reposición, resucitación) y del paciente (renal, hepático, cerebral).",
                listOf(
                    "Cristaloides balanceados (Ringer lactato, PlasmaLyte): preferibles al salino 0,9 % en grandes volúmenes (menos hipercloremia)",
                    "Salino 0,9 %: hipercloremia con >2–3 L (acidosis no-gap, vasoconstricción renal)",
                    "Coloides sintéticos (HES): restringidos en sepsis y críticos (riesgo renal) — usar solo según protocolo",
                    "Albúmina 5 %: resucitación en hepático/ascitis y cirugía cardiaca según protocolo",
                    "Glucosa 5 %: solo mantenimiento (no resucita volumen: se distribuye)"
                ),
                listOf(
                    "Reglas de reposición: cristaloide 3:1 y coloide 1:1 por mL de sangrado estimado (histórico — hoy: respuesta dinámica)",
                    "Ringer lactato: Na 130, K 4, Ca 1,4, lactato 28 mEq/L; no mezclar con transfusión en la misma línea",
                    "Salino hipertónico 3 %: 4 mL/kg en TCE intracraneal (protocolo de la app, Soluciones)",
                    "Mantenimiento: 4-2-1 (calculadora de la app) + déficit de ayuno + pérdidas terciarias"
                ),
                listOf(
                    "Resucitar todo con salino 0,9 % masivo (hipercloremia)",
                    "Usar HES en el paciente con daño renal agudo o sepsis",
                    "Confundir «edema periférico» con «sobre-carga»: en el anestesiado la hipoalbuminemia y el tercer espacio distorsionan la clínica"
                ),
                "Balanceado > salino para grandes volúmenes; coloides solo con protocolo y albúmina en indicaciones claras."
            ),
            StudyCard(
                "Volemia, sangrado y pérdida máxima permisible",
                "Estimar la volemia y el sangrado permite decidir cuándo transfundir: el objetivo es el hematocrito mínimo tolerado, no «rellenar».",
                listOf(
                    "Volemia estimada: adulto 70 mL/kg (hombre 75, mujer 65), niño 80, lactante 90 (calculadora Sangrado)",
                    "Pérdida máxima permisible = VSE × (Hto inicial − Hto mínimo)/(Hto promedio) — fórmula de Gross",
                    "Medir el sangrado: aspirado + compresas (pesar: 1 g ≈ 1 mL) − líquidos de lavado",
                    "Sangrado oculto: tercer espacio (laparotomía 4–8 mL/kg/h), evaporación, hematoma",
                    "Umbral transfusional restrictivo: Hb 7 (adulto sano), 8 (cardiopatía), 7,5 (ortopedia de alto riesgo)"
                ),
                listOf(
                    "Hombre 70 kg: VSE ≈ 5,2 L; pérdida permisible con Hto 42→27 ≈ 1,8 L",
                    "Reposición: 3 mL cristaloide por 1 mL de sangrado o 1 mL coloide (transitorio)",
                    "Concentrado eritrocitario: espera +1 g/dL por unidad en el adulto",
                    "Plaquetas: 1 concentrado/10 kg eleva ~5 000–10 000/µL; transfundir <50 000 sangrando o <100 000 en neuro"
                ),
                listOf(
                    "Transfundir por cifra sin síntoma ni sangrado activo",
                    "Subestimar el sangrado oculto del tercer espacio en laparotomías largas",
                    "Ignorar el contexto (cardiopatía: umbral más alto; sepsis: protocolo propio)"
                ),
                "Transfunda por umbral y por evidencia de sangrado: calcule la pérdida permisible antes de abrir la unidad."
            ),
            StudyCard(
                "Hemorragia masiva: protocolo 1:1:1 y TXA",
                "Cuando el sangrado supera 1 volemia en 24 h (o 50 % en 3 h): activar protocolo — hemocomponentes en proporción, ácido tranexámico y corrección de coagulopatía.",
                listOf(
                    "Protocolo 1:1:1 (GR:plasma:plaquetas) o 1:1:2 según banco: evitar la dilución secuencial",
                    "Ácido tranexámico 1 g IV en 10 min + 1 g en 8 h (CRASH-2) — idealmente <3 h del sangrado",
                    "Fibrinógeno: objetivo >200 mg/dL (crioprecipitado o concentrado de fibrinógeno)",
                    "Calcio: mantener iónico >1,1 mmol/L (transfusión masiva citrata)",
                    "Guía viscoelástica (ROTEM/TEG) si está disponible: dirige los hemocomponentes"
                ),
                listOf(
                    "Objetivos de laboratorio: Hb 7–9, plaquetas >50 000 (>100 000 neuro), INR/TTPa <1,5, fibrinógeno >200",
                    "Coagulopatía dilucional e hipotermia + acidosis = «triada letal»: calentar, corregir Ca, componentes",
                    "Vasopresores de apoyo mientras se repone; no depender de cristaloides en masa",
                    "La app trae Anemia y terapia transfusional en Clínica → Comorbilidades"
                ),
                listOf(
                    "Llenar con cristaloides mientras el paciente sangra (diluye, hipotermia, edema)",
                    "Retrasar el TXA «hasta tener pruebas»: se da temprano por protocolo",
                    "Olvidar el calcio y la temperatura en transfusión masiva"
                ),
                "Masiva = protocolo: 1:1:1 + TXA temprano + fibrinógeno + calcio + calidez; laboratorio guiado si hay ROTEM."
            ),
            StudyCard(
                "Reposición por ayuno, tercer espacio y péridas insensibles",
                "El balance hídrico perioperatorio suma mantenimiento + déficit de ayuno + pérdidas intraoperatorias: ni de más ni de menos (over-load lesiona pulmones y asas).",
                listOf(
                    "Mantenimiento: Holliday-Segar 4-2-1 (calculadora de la app)",
                    "Déficit de ayuno: horas de ayuno × mantenimiento × 1/2–2/3 en la 1.ª–2.ª h",
                    "Tercer espacio quirúrgico: laparoscopía 2–4, laparotomía 4–8, trauma mayor 8–12 mL/kg/h",
                    "Pérdidas insensibles: ~0,5 mL/kg/h (triplica con fiebre)",
                    "Objetivo: euvolemia funcional — no «llenar hasta que sature»"
                ),
                listOf(
                    "Ayuno 2-4-6-8: claros hasta 2 h, leche 4–6 h, sólidos 6–8 h (regla local puede variar)",
                    "En el niño: déficit + mantenimiento con dextrosa-salina balanceada (evitar hipoglucemia)",
                    "Cirugía intestinal: NG en obstrucción + péridas por sonda descontadas",
                    "Monitorizar respuesta dinámica: variación de pulso, renacimiento capilar, diuresis 0,5 mL/kg/h"
                ),
                listOf(
                    "Reponer el déficit de ayuno «de golpe» (sobrecarga: darlo en 1–2 h)",
                    "Olvidar la glucosa en pediatría y ayunos prolongados",
                    "Ignorar las pérdidas por sonda, drenajes y evaporación"
                ),
                "Balance = mantenimiento (4-2-1) + déficit fraccionado + tercer espacio + insensibles; vigilar respuesta dinámica."
            ),
            StudyCard(
                "Complicaciones transfusionales y hemovigilancia",
                "Toda transfusión tiene riesgo: inmunológico, infeccioso, sobrecarga y error de administración. La doble verificación y la vigilancia son obligatorias.",
                listOf(
                    "Reacción hemolítica aguda (incompatibilidad ABO): fiebre, dolor lumbar, hemoglobinuria — PARAR, soporte, notificar",
                    "TRALI: hipoxemia aguda tras transfusión con infiltrados: parar, soporte ventilatorio (no diurético de rutina)",
                    "Sobrecarga circulatoria (TACO): en cardiopatas y ancianos: transfundir lento, diurético si aplica",
                    "Fiebre no hemolítica y alergia: reacciones más frecuentes, benignas pero vigiladas",
                    "Verificación doble: paciente + unidad + grupo en voz alta ANTES de infundir"
                ),
                listOf(
                    "Velocidad: unidad de GR 1,5–4 h; en emergencia con calentador",
                    "Filtro y SF exclusivo (no Ringer ni glucosa en la misma línea)",
                    "Registro de la transfusión en el expediente (lote, hora, reacciones)",
                    "Calentador de sangre obligatorio si >1 unidad rápida (previene hipotermia y arritmias)"
                ),
                listOf(
                    "Transfundir sin doble verificación (error ABO: causa prevenible de muerte)",
                    "Continuar la unidad ante «fiebre leve» sin evaluar hemólisis",
                    "Olvidar el riesgo de TACO en el paciente cardiópata (transfundir lento y vigilar)"
                ),
                "Doble verificación antes de infundir y vigilancia en la primera hora: la hemovigilancia es del anestesiólogo."
            )
        ),
        questions = listOf(
            StudyQuestion(
                "Hombre de 80 kg, Hto 40 %, cirugía con Hto objetivo mínimo 28 %. Pérdida máxima permisible aprox:",
                listOf(
                    "~1,0 L",
                    "~2,2 L (VSE 5,6 L × (40−28)/34 promedio)",
                    "~3,5 L",
                    "~0,5 L"
                ),
                1,
                "VSE = 70 mL/kg ≈ 5,6 L. MPP = 5,6 L × (40−28)/34 ≈ 2,0–2,2 L. La calculadora Sangrado de la app lo hace.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "Umbral transfusional restrictivo correcto en un adulto sano sin síntomas:",
                listOf(
                    "Hb 10 g/dL",
                    "Hb 7 g/dL",
                    "Hb 6 g/dL con sangrado activo en shock",
                    "Hb 9 g/dL"
                ),
                1,
                "Umbral restrictivo: Hb 7 g/dL sin síntomas; 8 en cardiopatía y 7,5 en cirugía ortopédica de alto riesgo.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "Transfusión masiva: componente que NO debe faltar en el primer paquete:",
                listOf(
                    "Solo concentrados eritrocitarios",
                    "Concentrados + plasma + plaquetas en proporción 1:1:1 (o 1:1:2) + TXA 1 g",
                    "Solo plasma",
                    "Cristaloides masivos primero"
                ),
                1,
                "La proporción temprana 1:1:1 evita la coagulopatía dilucional; el TXA se administra temprano (<3 h).",
                listOf("R2", "R3")
            ),
            StudyQuestion(
                "Mantenimiento hídrico por hora en un niño de 22 kg:",
                listOf(
                    "40 mL/h",
                    "62 mL/h (4-2-1: 40 + 12 + 2 × 1)",
                    "80 mL/h",
                    "22 mL/h"
                ),
                1,
                "Holliday-Segar: 4 mL/kg/h × 10 kg = 40; 2 × 10 = 20; 2 kg × 1 = 2 → 62 mL/h. Calculadora Hidratación de la app.",
                listOf("R1")
            ),
            StudyQuestion(
                "Hipoxemia aguda con infiltrados 2 h tras una transfusión de plasma. Diagnóstico más probable:",
                listOf(
                    "TACO (sobrecarga)",
                    "TRALI (lesión pulmonar aguda relacionada con transfusión)",
                    "Reacción hemolítica",
                    "Embolia grasa"
                ),
                1,
                "TRALI = hipoxemia aguda + infiltrados bilaterales en las 6 h post-transfusión; manejo de soporte ventilatorio, NO diurético de rutina.",
                listOf("R3")
            ),
            StudyQuestion(
                "El salino 0,9 % en volúmenes >2–3 L produce:",
                listOf(
                    "Alcalosis metabólica",
                    "Hipercloremia con acidosis no-gap y vasoconstricción renal",
                    "Hiponatremia",
                    "Nada relevante"
                ),
                1,
                "La carga de cloro del salino genera hipercloremia, acidosis no-gap y reducción del flujo renal: en grandes volúmenes prefiere balanceados.",
                listOf("R2", "R3")
            )
        ),
        bibliography = listOf(
            "Miller RD. Miller's Anesthesia, 10.ª ed., capítulo de fluidoterapia y transfusión (2024).",
            "Myles PS et al. Restrictive vs liberal fluid therapy for major abdominal surgery (RELIEF). NEJM. 2018;378(24):2263-2274.",
            "CRASH-2 Collaborators. Effects of tranexamic acid on death in trauma patients. Lancet. 2010;376(9734):23-32.",
            "Cronos Anestesia: Soluciones (9 fichas) y tema Anemia y terapia transfusional en Clínica."
        )
    ),

    // ============================== 8. PERIOPERATORIO Y COMORBILIDADES ==============================
    StudyArea(
        id = "per",
        name = "Perioperatorio y comorbilidades",
        desc = "Valoración cardíaca y respiratoria, diabetes, antihipertensivos, obesidad y tabaquismo: el plan antes del quirófano.",
        cards = listOf(
            StudyCard(
                "Valoración cardíaca preoperatoria: RCRI, METs y ASA",
                "La evaluación combina riesgo quirúrgico, capacidad funcional y factores del paciente: decidir pruebas solo si cambian la conducta.",
                listOf(
                    "RCRI (Lee): 6 factores — alto riesgo si ≥3 (calculadora Escalas de la app)",
                    "Capacidad funcional: ≥4 METs adecuada; <4 con cirugía de alto riesgo → evaluación",
                    "Cirugía de riesgo alto: vascular mayor (abdominal-aórtica, carótida), cardiacas",
                    "Algoritmo ESC/ACC: emergencia → optimizar; electivo con RCRI ≥3 o METs <4 → evaluar",
                    "Bibliografía y estudios: válido hasta 90 días si no hay cambio clínico (auditar en Verificación de estudios)"
                ),
                listOf(
                    "Factor RCRI más pesado en práctica: cirugía de alto riesgo + IC + isquemia previa",
                    "Pruebas de isquemia solo si el resultado cambia el plan (revascularización solo con indicación independiente)",
                    "Betabloqueo: continuar si es usuario crónico; NO iniciar de rutina",
                    "Estatinas y AAS: mantener según decisión quirúrgica (AAS solo no contraindica bloqueo)"
                ),
                listOf(
                    "Pedir pruebas «porque siempre» (ecos, pruebas de esfuerzo de rutina)",
                    "Suspender betabloqueantes crónicos por «síntomas» (rebete isquémico)",
                    "Ignorar el riesgo del retraso por sobre-estudio: el tiempo también es riesgo"
                ),
                "RCRI + METs + tipo de cirugía: si no cambia la conducta, no pida la prueba."
            ),
            StudyCard(
                "Diabetes perioperatoria: insulina, orales y SGLT2",
                "El objetivo: glucemia 140–180 mg/dL, evitar hipoglucemia y cetoacidosis euglucémica (SGLT2). Los antidiabéticos tienen cronogramas propios.",
                listOf(
                    "Metformina: omitir el día de la cirugía (48 h con contraste IV)",
                    "SGLT2 (dapagliflozina/empagliflozina): SUSPENDER 3 días antes — cetoacidosis euglucémica",
                    "Sulfonilureas/glinidas: omitir el día de (hipoglucemia); DPP-4: omitir el día de",
                    "Insulina basal: 80 % de la dosis usual el día de la cirugía; correctores según glucemia",
                    "GLP-1 agonistas: mantener según protocolo actual (retardo del vaciado gástrico si ayuno prolongado)"
                ),
                listOf(
                    "Objetivo de glucemia perioperatorio: 140–180 mg/dL (evitar <100 y >250)",
                    "Glucemia >250: medir cetonas; >300 postergar electiva",
                    "Bombas de insulina: suspender y usar esquema IV perioperatorio",
                    "La app trae el tema Diabetes en Clínica → Comorbilidades con el cronograma completo"
                ),
                listOf(
                    "Mantener SGLT2 «porque es un antidiabético nuevo»: riesgo de CAD euglucémica",
                    "Dejar la insulina basal en 100 % con ayuno (hipoglucemia)",
                    "Ignorar la polifarmacia del diabético: asociar con nefropatía y autónomos alterados"
                ),
                "SGLT2 fuera 3 días, basal al 80 %, objetivo 140–180: la seguridad diabética es de cronograma, no de «azúcar baja»."
            ),
            StudyCard(
                "Hipertensión y antihipertensivos perioperatorios",
                "Decidir qué antihipertensivo continúa, cuál se suspende y qué hacer con la PA elevada del día de la cirugía.",
                listOf(
                    "Continuar: betabloqueantes, calciantagonistas no dihidropiridínicos, IECA/ARA-II según protocolo (controversia: algunos protocolos omiten el día de por hipotensión)",
                    "Diuréticos: omitir el día de la cirugía (evitar hipovolemia e hipokalemia)",
                    "Clonidina y metildopa: continuar (riesgo de rebete si se suspenden)",
                    "PA 180/110: cirugía electiva de alto riesgo: posponer y tratar; leve/moderada: proceder con vigilancia",
                    "Diuréticos ahorradores de K + IECA: vigilar K y creatinina preoperatoria"
                ),
                listOf(
                    "Regla práctica: betabloqueante SIEMPRE continúa; diurético SE OMITE; IECA/ARA-II según protocolo institucional",
                    "Lab preoperatorio del hipertenso: creatinina, K, Na, ECG (hipertrofia)",
                    "Nifedipino sublingual NO para la PA aguda (isquemia brusca)",
                    "La hipotensión de inducción es mayor en pacientes con IECA/ARA-II activos: tener vasopresor listo"
                ),
                listOf(
                    "Suspender betabloqueantes crónicos (rebete isquémico)",
                    "Operar electiva mayor con PA >180/110 sin tratar",
                    "Omitir el vasopresor de rescate en el paciente con IECA/ARA-II del día"
                ),
                "Betabloqueante continúa, diurético se omite, IECA/ARA-II según protocolo; vasopresor siempre a mano."
            ),
            StudyCard(
                "Obesidad: dosificación, vía aérea y posición",
                "El paciente obeso pide plan específico: dosis por peso ajustado, preoxigenación prolongada, rampa y riesgo de AOS.",
                listOf(
                    "Dosis: succinilcolina por peso TOTAL; rocuronio/propofol inducción por IBW/ajustado; mantenimiento por ajustado",
                    "Preoxigenación 3–5 min con PEEP/CPAP + O2 nasal apneico: reserva de FRC menor",
                    "Rampa 25–30° (orejas al nivel del esternón): mejora laringoscopía y FRC",
                    "STOP-Bang ≥3: AOS de alto riesgo — opioides mínimos, oximetría postop",
                    "Enfisema subcutáneo post-laparoscopía: vigilar vía aérea y presión de circuito"
                ),
                listOf(
                    "IBW/ABW: calculadora Peso ideal de la app (Devine + ajustado + VT protector)",
                    "VT por IBW 6 mL/kg; PEEP 5–8 cmH2O y reclutamiento periódico",
                    "Volátiles: desflurano/sevo por menor solubilidad; MAC sin cambio relevante",
                    "Epi dosis máx de anestésicos locales: por IBW/ajustado en la neuraxial reducir 20–30 %"
                ),
                listOf(
                    "Dosificar propofol por peso total en IMC >40 (sobredosis y colapso)",
                    "Ventilar con VT por peso real (barotrauma y atelectrauma)",
                    "Ignorar el riesgo de AOS postop: opioides + sedantes + oximetría continua"
                ),
                "Obeso = rampa + preoxigenación + dosis ajustada + vigilancia de AOS postop."
            ),
            StudyCard(
                "Tabaquismo, alcohol y abstinencia",
                "El tabaquismo activo y el consumo de alcohol cambian el riesgo respiratorio y la farmacología: son intervenciones perioperatorias, no «datos de la historia».",
                listOf(
                    "Tabaco: incrementa PPC (ARISCAT), infección de herida y dificultad de vía aérea; suspender ≥4 semanas ideal (≥24 h ya mejora CO y oxigenación)",
                    "Alcohol ≥2 unidades/día: tolerancia a anestésicos, riesgo de abstinencia postop y coagulopatía",
                    "Abstinencia alcohólica: profile delirium 48–72 h — tiamina, benzodiacepinas, vigilancia",
                    "Cannabis crónico: tolerancia a propofol y opioide, hiperemesis cannabis (vigilar PONV)",
                    "Cocaína/simpaticomiméticos: riesgo isquémico — diferir electiva si uso reciente"
                ),
                listOf(
                    "COHb del fumador: 5–10 % (SpO2 falsamente alta): buscar acidosis y síntomas",
                    "Abstinencia: CIWA-Ar para titulación; la app no sustituye el protocolo de psiquiatría",
                    "Vaporizador: el fumador crónico puede pedir más hipnótico (tolerancia CYP1A2)"
                ),
                listOf(
                    "Omitir el consejo de cese («no llega a tiempo»): 24 h ya mejora la oxigenación",
                    "No planear la abstinencia alcohólica en el paciente con cirrosis o consumo diario",
                    "Interpretar SpO2 alta con COHb como «no hay hipoxia»"
                ),
                "Tobacco/alcohol = riesgo modificado: consejo + plan de abstinencia y ajuste de dosis."
            )
        ),
        questions = listOf(
            StudyQuestion(
                "RCRI con 2 factores y capacidad funcional 6 METs para cirugía abdominal media. Conducta:",
                listOf(
                    "Prueba de esfuerzo obligatoria",
                    "Proceder: riesgo intermedio con buena capacidad funcional no requiere más estudios",
                    "Posponer indefinidamente",
                    "Cateterismo cardíaco"
                ),
                1,
                "RCRI 2 + METs ≥4 + cirugía de riesgo intermedio: proceder con control de PA y manejo de fármacos. Las pruebas solo si cambian la conducta.",
                listOf("R2", "R3")
            ),
            StudyQuestion(
                "Antidiabético que DEBE suspenderse 3 días antes de la cirugía electiva por riesgo de cetoacidosis euglucémica:",
                listOf(
                    "Metformina",
                    "Inhibidores de SGLT2 (dapagliflozina, empagliflozina)",
                    "Sulfonilurea",
                    "Insulina basal"
                ),
                1,
                "SGLT2 → CAD euglucémica perioperatoria: suspender 3 días antes y medir cetonas si la glucemia sube.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "Dosis de succinilcolina en el paciente con IMC 45:",
                listOf(
                    "Por peso ideal",
                    "Por peso TOTAL (1–1,5 mg/kg TBW)",
                    "Por peso ajustado",
                    "Dosis fija de 100 mg"
                ),
                1,
                "La succinilcolina se dosifica por peso TOTAL; el rocuronio y el propofol de inducción, por IBW/ajustado.",
                listOf("R2")
            ),
            StudyQuestion(
                "Paciente hipertenso en enalapril y atenolol, PA 150/90 el día de la cirugía. Conducta:",
                listOf(
                    "Suspender ambos",
                    "Continuar atenolol; omitir enalapril el día de según protocolo; proceder con vasopresor listo",
                    "Posponer la cirugía",
                    "Añadir nifedipino sublingual"
                ),
                1,
                "El betabloqueante continúa (rebete); el IECA se suele omitir el día de (hipotensión de inducción); 150/90 no es motivo de postergación.",
                listOf("R2", "R3")
            ),
            StudyQuestion(
                "Fumador activo que debe operarse en 48 h. Intervención útil YA:",
                listOf(
                    "Nada: no hay tiempo",
                    "Cese absoluto desde hoy + consejo (24 h ya reducen CO y mejoran la oxigenación)",
                    "Broncodilatador solo",
                    "Posponer siempre"
                ),
                1,
                "El cese ≥24 h ya desciende el COHb y desplaza la curva de O2; ≥4 semanas reduce PPC — cualquier tiempo suma.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "Paciente de 60 años con consumo diario de alcohol, cirugía electiva en 5 días. Riesgo principal postoperatorio:",
                listOf(
                    "Hipertermia maligna",
                    "Abstinencia alcohólica con delirium (48–72 h) — planear tiamina y benzodiacepinas",
                    "Alergia al anestésico",
                    "Hipoglucemia solo"
                ),
                1,
                "El síndrome de abstinencia aparece a las 48–72 h: tiamina, vigilancia CIWA-Ar y benzodiacepinas; la app documenta en el expediente.",
                listOf("R2", "R3")
            )
        ),
        bibliography = listOf(
            "Halvorsen S et al. ESC 2022 Guidelines on non-cardiac surgery: cardiovascular assessment and management. Eur Heart J. 2022;43(39):3826-3884.",
            "Duceppe E et al. Canadian Cardiovascular Society Guidelines on Perioperative Cardiac Risk Assessment. Can J Cardiol. 2017;33(1):17-32.",
            "Cronos Anestesia: Clínica → Comorbilidades (9 temas con ajustes de dosis).",
            "Akhtar S et al. Perioperative management of obesity. Anesth Analg (revisión periódica)."
        )
    ),

    // ============================== 9. OBSTETRICIA ==============================
    StudyArea(
        id = "obs",
        name = "Obstetricia",
        desc = "Fisiología del embarazo, analgesia de parto, cesárea, preeclampsia y hemorragia posparto.",
        cards = listOf(
            StudyCard(
                "Fisiología del embarazo y su impacto anestésico",
                "El embarazo cambia todo: vía aérea, pulmón, corazón, estómago y columna. Las dosis y los tiempos son otros.",
                listOf(
                    "Vía aérea: edema de mucosa (tubo 0,5–1 mm menor), mallampati empeora durante el trabajo de parto",
                    "FRC ↓ ~20 % en término + consumo ↑: desaturación en 1–2 min — preoxigenación obligatoria",
                    "Compresión aortocava: inclinación lateral izquierda ≥15° en toda mujer >20 semanas",
                    "Volumen sanguíneo ↑ 40–50 %: anemia fisiológica (Hb ~11 g/dL)",
                    "Espacio epidural reducido: la raqui sube ~6 dermatomas con la misma dosis"
                ),
                listOf(
                    "Dosis de bupivacaína hiperbárica en cesárea: 10–12 mg (vs 15 mg en no embarazada)",
                    "Cifra de vasopresor de elección: fenilefrina 50–100 µg bolos o 0,25–1 µg/kg/min",
                    "Gasto cardíaco ↑ 30–50 %; en las contracciones: autotransfusión de 300–500 mL",
                    "MPE y protección gástrica: el vacío está SIEMPRE en la cesárea (RSI)"
                ),
                listOf(
                    "Anestesia general «por rutina» en cesárea electiva (la regional es de elección si no hay contraindicación)",
                    "Preoxigenar solo 60 s (insuficiente en embarazo)",
                    "Olvidar la inclinación lateral en la raqui o en el transporte"
                ),
                "Embarazada >20 semanas: inclinación izquierda, preoxigenación completa y dosis neuraxial reducida."
            ),
            StudyCard(
                "Analgesia de parto: epidural y combinada",
                "La epidural de parto titula alivio (T10–L1) con bloqueo motor mínimo: concentraciones bajas de anestésico + opioide.",
                listOf(
                    "Mezcla de analgesia: bupivacaína/ropivacaína 0,0625–0,125 % + fentanilo 2 µg/mL a 8–12 mL/h",
                    "Carga inicial: 10–15 mL fraccionados; nivel objetivo T10 (no anestésico: analgésico)",
                    "CSE: raqui con sufentanilo 2,5–5 µg (inicio inmediato) + catéter epidural",
                    "Vigilar: nivel, PA (hipotensión → fenilefrina), motor (Bromage), retención urinaria",
                    "Contraindicaciones: coagulopatía, sepsis, rechazo; fiebre no es contraindicación absoluta"
                ),
                listOf(
                    "Bolos epidurales de bupivacaína 0,25 %: analgesia 60–120 min",
                    "Ropivacaína 0,1 % + sufentanilo 0,3 µg/mL: infusión 10–15 mL/h",
                    "Bromage 0 = motor libre; en analgesia de parto debe mantenerse 0–1",
                    "El catéter debe retirarse con criterios ASRA si hay anticoagulación"
                ),
                listOf(
                    "Dar analgesia «de anestesia» (bloqueo motor): interfiere con el parto y aumenta instrumental",
                    "Omitir la vigilancia de hipotensión y fetal después de la carga",
                    "Confundir analgesia insuficiente con «catéter mal» y retirarlo antes de revisar nivel y dosis"
                ),
                "Analgesia de parto = dilución alta + opioide + nivel T10 + motor libre."
            ),
            StudyCard(
                "Cesárea: raqui, hipotensión y atónicos",
                "La cesárea electiva se hace con raqui (10–12 mg bupi hiperbárica) con objetivo T4–T6; el manejo de la hipotensión y del uterotónico define la estabilidad.",
                listOf(
                    "Hipotensión: fenilefrina profiláctica (infusión 0,25–1 µg/kg/min) o bolos titulados",
                    "Náuseas con hipotensión: dar vasopresor, no antiemético solo",
                    "Uterotónicos escalonados: oxitocina 5 U lento + infusión 20–40 U en 1 L; ergotamina si no sangra; carboprost 250 µg IM",
                    "Nivel T4–T6; si hay urgencia sin catéter: raqui; si hay catéter epidural: carga 15–20 mL de lidocaína 2 % + epi",
                    "Alta: TOF, Aldrete, analgesia multimodal (morfina raqui 0,1–0,15 mg + paracetamol/AINE)"
                ),
                listOf(
                    "Oxitocina IV rápida: hipotensión y taquicardia — dar en ≥30 s y diluida",
                    "Morfina raqui 0,1–0,15 mg: analgesia 18–24 h con vigilancia de depresión respiratoria",
                    "Cristaloides de pre-carga: 500 mL moderado (no hay que «llenar» — el vasopresor es el tratamiento)",
                    "La app trae el tema Hemorragia posparto y reanimación materna en Clínica → Temas quirúrgicos"
                ),
                listOf(
                    "Dosificar la raqui de cesárea como la de herniorrafia (sobredosis y bloqueo alto)",
                    "Tratar la náusea de hipotensión con antiemético sin corregir el vasopresor",
                    "Olvidar la vigilancia de la depresión respiratoria de la morfina raqui en la sala"
                ),
                "Cesárea: 10–12 mg, fenilefrina profiláctica, uterotónicos escalonados y vigilancia post-raqui."
            ),
            StudyCard(
                "Preeclampsia: MgSO4, antihipertensivos y plan anestésico",
                "La preeclampsia grave exige anticonvulsivante (MgSO4), control de PA y plan neuraxial con plaquetas y coagulación.",
                listOf(
                    "MgSO4: carga 4–6 g en 20 min + infusión 1–2 g/h; vigilar reflejos, diuresis y respiración",
                    "Anticonvulsivo de rescate: MgSO4 2 g IV o diazepam; ante convulsión: magnesium + protección vía aérea",
                    "Antihipertensivo: labetalol 10–20 mg IV o hidralazina 5 mg IV; objetivo PA <160/110",
                    "Neuraxial de elección si plaquetas >75 000 y coagulación normal; evitar hematoma: cronograma ASRA",
                    "General si coagulopatía: RSI + vigilancia de vía aérea edematosa"
                ),
                listOf(
                    "MgSO4 tóxico: reflejos abolidos, FR <12 — antídoto: gluconato de calcio 10 % 10 mL",
                    "Anestesia general: menor MAC en preeclampsia (magnesio potencia el relajante: TOF obligatorio)",
                    "Hemolisis, transaminasas altas y plaquetas bajas (HELLP): coagulopatía — neuraxial contraindicada",
                    "La app trae Hipertensión del embarazo en Clínica → Comorbilidades"
                ),
                listOf(
                    "Bloquear neuraxial con plaquetas <75 000 en preeclampsia (riesgo de hematoma)",
                    "MgSO4 sin vigilar reflejos y respiración (intoxicación inadvertida)",
                    "Asumir vía aérea «normal» en preeclampsia grave (edema de mucosa)"
                ),
                "Preeclampsia: magnesio + labetalol + plaquetas antes del neuraxial + TOF vigilado."
            ),
            StudyCard(
                "Hemorragia posparto y reanimación materna",
                "La HPP es la emergencia obstétrica más letal: protocolo escalonado, transfusión masiva materna y RCP con cesárea perimortem.",
                listOf(
                    "Protocolo HPP: uterotónicos escalonados → TXA 1 g → transfusión masiva 1:1:1 con fibrinógeno >200 mg/dL",
                    "Causas 4T: Tono, Tejido, Trauma, Trombina (coagulopatía)",
                    "RCP materna: compresiones estándar SIN inclinación lateral (la inclinación se hace con la mano)",
                    "Cesárea perimortem en 4–5 min si el embarazo ≥20 semanas (salva a la madre y al bebé)",
                    "La app trae el tema completo en Clínica → Temas quirúrgicos"
                ),
                listOf(
                    "TXA 1 g IV temprano (WOMAN trial: reduce mortalidad por sangrado)",
                    "Ácido tranexámico NO sustituye a los uterotónicos: sumar",
                    "Embolia de líquido amniótico: diagnóstico de exclusión — soporte, no «protocolo HPP» puro",
                    "Reanimación neonatal: equipo pediátrico en toda HPP"
                ),
                listOf(
                    "Retrasar la transfusión masiva «hasta ver el laboratorio» (siga el protocolo 1:1:1)",
                    "Olvidar el fibrinógeno (hipofibrinogenemia en HPP grave)",
                    "Aplicar la RCP con inclinación lateral completa (no permite compresiones efectivas)"
                ),
                "HPP = uterotónicos + TXA + 1:1:1 + fibrinógeno; RCP materna estándar + cesárea perimortem 4–5 min."
            )
        ),
        questions = listOf(
            StudyQuestion(
                "Dosis de bupivacaína hiperbárica 0,5 % para cesárea electiva:",
                listOf(
                    "15–18 mg",
                    "10–12 mg con objetivo T4–T6",
                    "5 mg",
                    "25 mg"
                ),
                1,
                "En el embarazo a término el espacio epidural está comprimido: 10–12 mg alcanzan T4–T6; dosis mayores hipotensión y bloqueo alto.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "Vasopresor de elección para la hipotensión de la raqui en cesárea:",
                listOf(
                    "Efedrina exclusivamente",
                    "Fenilefrina (bolos 50–100 µg o infusión)",
                    "Adrenalina",
                    "Norepinefrina en dosis altas"
                ),
                1,
                "Fenilefrina: mejor pH fetal y control más predecible; efedrina si hay bradicardia asociada.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "Preeclampsia grave con plaquetas 60 000/µL para cesárea. Técnica anestésica:",
                listOf(
                    "Raqui de rutina",
                    "Anestesia general con RSI (plaquetas <75 000: contraindicación relativa del neuraxial)",
                    "Epidural con catéter",
                    "Bloqueo TAP"
                ),
                1,
                "Con plaquetas <75 000 y HELLP, el neuraxial se contraindica: RSI con via aérea edematosa, magnesio en marcha y TOF vigilado.",
                listOf("R3")
            ),
            StudyQuestion(
                "MgSO4 intoxicación: signo y antídoto:",
                listOf(
                    "Bradicardia — atropina",
                    "Reflejos abolidos y FR <12 — gluconato de calcio 10 % 10 mL",
                    "Convulsión — diazepam",
                    "Hipertensión — labetalol"
                ),
                1,
                "La intoxicación por magnesio: reflejos patelares abolidos, depresión respiratoria y oliguria; antídoto: calcio gluconato.",
                listOf("R2")
            ),
            StudyQuestion(
                "RCP materna a término (≥20 semanas) en paro: maniobra correcta:",
                listOf(
                    "Inclinación lateral izquierda completa durante las compresiones",
                    "Compresiones estándar + desplazamiento uterino manual + cesárea perimortem a 4–5 min",
                    "Solo soporte avanzado sin cesárea",
                    "Cricoid pressure durante la RCP"
                ),
                1,
                "A partir de 20 semanas, compresiones estándar con desplazamiento uterino manual y cesárea perimortem en 4–5 min: salva a la madre y al bebé.",
                listOf("R2", "R3")
            ),
            StudyQuestion(
                "Analgesia de parto con motor libre (Bromage 0) — fórmula habitual:",
                listOf(
                    "Bupivacaína 0,5 % sola",
                    "Bupivacaína/ropivacaína 0,0625–0,125 % + fentanilo 2 µg/mL en infusión 8–12 mL/h",
                    "Lidocaína 2 % en bolos",
                    "Clorprocaina 3 %"
                ),
                1,
                "Analgesia diluida con opioide: alivio T10 con motor libre; concentraciones altas bloquean motor e interfieren con el parto.",
                listOf("R1", "R2")
            )
        ),
        bibliography = listOf(
            "Chestnut's Obstetric Anesthesia: Principles and Practice, 7.ª ed., Elsevier, 2024.",
            "Santos AC et al. Obstetric anesthesia: guías de práctica (revisión periódica).",
            "OMS. Manejo de las complicaciones del embarazo y el parto: hemorragia posparto (guía).",
            "Cronos Anestesia: Clínica → Temas quirúrgicos → Obstetricia (HPP y reanimación materna)."
        )
    ),

    // ============================== 10. PEDIATRÍA ==============================
    StudyArea(
        id = "ped",
        name = "Pediatría",
        desc = "Diferencias fisiológicas, dosis, vía aérea pediátrica y dolor en el niño.",
        cards = listOf(
            StudyCard(
                "Diferencias fisiológicas del niño",
                "El lactante no es un adulto pequeño: reserva respiratoria y cardíaca diferentes, termorregulación y fluidos con reglas propias.",
                listOf(
                    "Respiración: FRC pequeño, cierre de vía aérea fácil, consumo de O2 5–8 mL/kg/min (doble del adulto) → desaturación rápida",
                    "Circulación: débito dependiente de frecuencia; volumen sistólico fijo",
                    "Vía aérea: laringe más alta (C3–C4), epiglotis omega, estrechez cricoidea (tubo sin manguito <8 años según protocolo)",
                    "Termorregulación: superficie/peso alto — hipotermia rápida",
                    "Glucosa: reservas hepáticas bajas — vigilar e infundir dextrosa en ayunos largos"
                ),
                listOf(
                    "Tubo: Levi (edad/4 + 4) interno; profundidad = 12 + edad/2 (calculadora de la app)",
                    "Fluidos: Holliday-Segar 4-2-1 + déficit; dextrosa-salina balanceada en ayunos >4 h",
                    "Volemia: lactante 90 mL/kg, niño 80 mL/kg (calculadora Sangrado con categorías)",
                    "Bradycardia = hipoxia hasta prueba en contra: detener, oxigenar, atropina/adrenalina si no responde"
                ),
                listOf(
                    "Tratar al lactante como «adulto mini» en dosis y en fluidos",
                    "Olvidar la dextrosa en el lactante con ayuno prolongado (hipoglucemia)",
                    "Ignorar la bradicardia: en pediatría es el signo de alarma nº 1"
                ),
                "Niño = desaturación rápida + bradicardia + hipotermia: prepárese para las tres."
            ),
            StudyCard(
                "Vía aérea pediátrica",
                "La vía aérea del niño cambia con la edad: tubo por fórmula, laringoscopio apropiado y cuidado con la posición.",
                listOf(
                    "Tubo sin manguito <8 años (protocolo institucional); con manguito: presión <20 cmH2O",
                    "Laringoscopio: Wiskinson/Miller 1 en lactante; Mac 2 en >2 años",
                    "Posición: plano del hombro con anillo (no hiperextensión); hombro para el lactante",
                    "Mascarillas: tamaño 1–4 según edad; SLM pediátrico por peso",
                    "Aspirador y O2 de rescate SIEMPRE listos; broncoespasmo frecuente en lactantes"
                ),
                listOf(
                    "Tubo: ID = edad/4 + 4 (con manguito: −0,5); profundidad = 12 + edad/2 cm",
                    "Talla de mascarilla: recién nacido 1, lactante 2, niño 3, adolescente 4",
                    "SLM: talla 1 (<5 kg), 1,5 (5–10), 2 (10–20), 2,5 (20–30), 3 (30–50 kg)",
                    "Broncoespasmo: albuterol nebulizado, hidrocortisona; evitar el trauma repetido"
                ),
                listOf(
                    "Forzar un tubo «ajustado» (trauma subglótico y estenosis): elegir el menor que fuga",
                    "Hiperextensión cervical en el lactante (obstruye: la laringe es alta)",
                    "Ignorar la fuga: 20–30 cmH2O con fuga audible indica tamaño correcto"
                ),
                "Tubo por fórmula con fuga 20–30, laringe alta y broncoespasmo vigilado: la vía aérea pediátrica se planifica por edad."
            ),
            StudyCard(
                "Dosis y fluidos pediátricos",
                "Dosis por kg calculadas y verificadas doble: el margen de error es menor y las consecuencias mayores.",
                listOf(
                    "Propofol 2–4 mg/kg (lactante ~3); sevoflurano inducción 5–8 % con máscara (más frecuente)",
                    "Rocuronio 0,6–1,2 mg/kg; SCh 1,5–2 mg/kg IV (o 3–4 IM)",
                    "Fentanilo 1–2 µg/kg; morfina 0,05–0,1 mg/kg; paracetamol 15 mg/kg VO/IV",
                    "Fluidos: 4-2-1 + déficit + sangrado (calculadora Hidratación y Sangrado de la app)",
                    "Transfusión: umbral Hb 7–8 g/dL (protocolo pediátrico); VSE por categoría"
                ),
                listOf(
                    "Pérdida máxima permisible: (VSE × (Hto i − Hto m))/Hto promedio — calculadora Sangrado",
                    "Aldrete pediátrico: mismo esquema con temperatura y actividad ajustadas",
                    "Dextrosa: 2–4 mg/kg/min en lactantes con ayuno prolongado (DS balanceada)",
                    "Volumen de mantenimiento: 4-2-1 por hora; añadir el déficit fraccionado"
                ),
                listOf(
                    "Confundir mg/kg con mL/kg (dosis y volumen son distintos: verificar concentración)",
                    "Usar dosis adultas «a mitad» (errático: calcular por kg y revisar con otra persona)",
                    "Olvidar el peso del expediente al calcular (usar el peso medido del día)"
                ),
                "Doble cálculo + doble verificación: la dosis pediátrica no se improvisa."
            ),
            StudyCard(
                "Dolor pediátrico y analgesia multimodal",
                "El dolor del niño se evalúa con escalas específicas y se trata multimodal desde la premedicación.",
                listOf(
                    "Escalas: FLACC (2 meses–7 años), Wong-Baker caras (3+), EVA numérica (>7–8 años)",
                    "Multimodal: paracetamol 15 mg/kg + AINE (ibuprofeno 10 mg/kg o ketorolaco 0,5 mg/kg) + bloqueos locales",
                    "Bloqueos comunes: TAP, ilioinguinal, dorsal (caudal 0,125 % bupi 1 mL/kg hasta L1)",
                    "Opioides: morfina 0,05–0,1 mg/kg IV; PCA desde 6–8 años; vigilancia de sedación",
                    "Sución oral (sacarosa) y confort no farmacológico en lactantes"
                ),
                listOf(
                    "Caudal: bupivacaína 0,125–0,2 % 0,5–1 mL/kg (máx 20 mL) ± morfina 30–50 µg/kg",
                    "Bupivacaína máx en niño: 2,5 mg/kg (con epi 3); lidocaína 5 mg/kg",
                    "Ketorolaco 0,5 mg/kg IV máx 15 mg en cirugía con sangrado; evitar en nefropatía",
                    "PONV pediátrico: profilaxis doble (ondansetrón 0,1 mg/kg + dexametasona 0,15 mg/kg)"
                ),
                listOf(
                    "Subtratar el dolor «porque no sabe decir» (usar FLACC/caras)",
                    "Omitir la profilaxis de PONV en el niño (incidencia 30–80 %)",
                    "Opioides sin vigilancia de sedación en el lactante"
                ),
                "Niño: escala específica + multimodal + bloqueo cuando aplique + PONV profilaxis doble."
            ),
            StudyCard(
                "Emergencias pediátricas perioperatorias",
                "Laringoespasmo, broncoespasmo, paro cardíaco pediátrico y la hiperkalemia de la SCh: los cuatro escenarios que hay que tener memorizados.",
                listOf(
                    "Laringoespasmo: O2 100 % + presión continua + propofol 0,5–1 mg/kg; SCh 0,5–1 mg/kg IV (2–4 IM) si no cede",
                    "Paro pediátrico: mayoría asfíctico — RCP 15:2 en dos rescatadores; adrenalina 0,01 mg/kg IV/IO",
                    "Desfibrilación: 2–4 J/kg (bifásico 2 J/kg, luego 4 J/kg)",
                    "Hiperkalemia por SCh: solo en contraindicados (quemadura, trauma, desinnervación) — evitar",
                    "Anafilaxia: adrenalina 0,01 mg/kg IM (máx 0,5 mg) repetida; la app trae el protocolo"
                ),
                listOf(
                    "Adrenalina en paro: 0,01 mg/kg (0,1 mL/kg de 1:10 000) cada 3–5 min",
                    "Volumen de resucitación: 20 mL/kg de cristaloide balanceado",
                    "Laringoespasmo completo: signo es la barrera en la capnografía — no ventila ni con máscara",
                    "Fórmulas rápidas: ETT = edad/4+4; peso = (edad×2)+8 (approx) — usar el medido cuando exista"
                ),
                listOf(
                    "Aplicar dosis adultas en paro pediátrico (adrenalina 1 mg sería 100× la dosis)",
                    "Retrasar la adrenalina IM en anafilaxia por buscar acceso IV",
                    "Olvidar que el paro pediátrico es asfíctico: oxigenación y ventilación antes que compresiones"
                ),
                "Pediatría en crisis: dosis por kg verificada, adrenalina 0,01 mg/kg, oxigenación primero."
            )
        ),
        questions = listOf(
            StudyQuestion(
                "Tubo endotraqueal interno correcto en un niño de 4 años:",
                listOf(
                    "6,0 mm (edad/4 + 4 = 5,0 sin manguito; con manguito ~4,5–5,0)",
                    "4,0 mm",
                    "5,5 mm con manguito en todos los casos",
                    "3,0 mm"
                ),
                0,
                "Fórmula de Levi: ID = edad/4 + 4 (sin manguito) o −0,5 con manguito. Profundidad = 12 + edad/2. Calculadora Tubo pediátrico de la app.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "Mantenimiento hídrico por hora en un niño de 25 kg:",
                listOf(
                    "25 mL/h",
                    "65 mL/h (4-2-1)",
                    "125 mL/h",
                    "50 mL/h"
                ),
                1,
                "4-2-1: 10 kg × 4 = 40; 10 kg × 2 = 20; 5 kg × 1 = 5 → 65 mL/h.",
                listOf("R1")
            ),
            StudyQuestion(
                "Laringoespasmo completo con desaturación que no cede con O2 y presión. Siguiente paso:",
                listOf(
                    "Esperar a que ceda",
                    "Propofol 0,5–1 mg/kg IV y, si no cede, SCh 0,5–1 mg/kg",
                    "Tubo de mayor tamaño",
                    "Solo broncodilatador"
                ),
                1,
                "Propofol relaja la laringe; la SCh (0,5–1 mg/kg) es el rescate definitivo. En pediatría, dosis IM 2–4 mg/kg si no hay acceso.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "Dosis de adrenalina en paro cardíaco pediátrico:",
                listOf(
                    "0,01 mg/kg IV/IO cada 3–5 min",
                    "1 mg fijo",
                    "0,1 mg/kg",
                    "0,5 mg/kg"
                ),
                0,
                "0,01 mg/kg (0,1 mL/kg de la dilución 1:10 000) cada 3–5 min, máx 1 mg. El error clásico es usar la dosis adulta.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "Escala de dolor apropiada para un lactante de 6 meses:",
                listOf(
                    "EVA numérica",
                    "FLACC (conducta observada)",
                    "Wong-Baker solo",
                    "Ninguna: no sienten dolor"
                ),
                1,
                "FLACC evalúa cara, piernas, actividad, llanto y consolabilidad: apropiada de 2 meses a 7 años. Los lactantes SÍ sienten dolor.",
                listOf("R1")
            ),
            StudyQuestion(
                "Succinilcolina en un niño con quemadura de 30 % de hace 5 días:",
                listOf(
                    "Segura a dosis estándar",
                    "Contraindicada: riesgo de hiperkalemia (desinnervación >48–72 h)",
                    "Segura solo IM",
                    "Segura con midazolam previo"
                ),
                1,
                "Desde las 48–72 h de la quemadura, la SCh desencadena hiperkalemia masiva: usar rocuronio 1,2 mg/kg.",
                listOf("R2", "R3")
            )
        ),
        bibliography = listOf(
            "Smith's Anesthesia for Infants and Children, 10.ª ed., Elsevier, 2023.",
            "APLS: Advanced Paediatric Life Support (guía vigente).",
            "Cronos Anestesia: calculadora Tubo pediátrico, Hidratación y Sangrado (categorías pediátricas).",
            "Riazi S et al. Paediatric dosing: revisión de errores de cálculo (Anesth Analg, revisión periódica)."
        )
    ),

    // ============================== 11. DOLOR ==============================
    StudyArea(
        id = "dol",
        name = "Dolor",
        desc = "Analgesia multimodal, opioides con vigilancia, bloqueos y prevención del dolor crónico.",
        cards = listOf(
            StudyCard(
                "Analgesia multimodal: el fundamento",
                "Combinar fármacos de distintas vías y mecanismos con opioides mínimos: mejor alivio, menos efectos adversos y menos dolor crónico.",
                listOf(
                    "Línea base: paracetamol 1 g c/6 h (15 mg/kg pediátrico) + AINE (si no contraindicado)",
                    "Adyuvantes: ketamina baja (0,1–0,3 mg/kg/h), lidocaína IV (cirugía abdominal), dexametasona",
                    "Bloqueos: TAP, ilioinguinal, paravertebral, neuroaxial — la analgesia regional es el pilar",
                    "Opioides titulados al efecto con vigilancia (sedación y respiración)",
                    "Planear la analgesia ANTES de terminar la cirugía (no en la recuperación)"
                ),
                listOf(
                    "Paracetamol 1 g IV en 15 min (máx 4 g/día; 3 g en >75 años)",
                    "Ketorolaco 10–30 mg IV o ibuprofeno IV 400–800 mg; evitar en renal grave y sangrado",
                    "Lidocaína IV 1–2 mg/kg bolo + 1–2 mg/kg/h (monitorizar toxicidad)",
                    "Dexametasona 4–8 mg preincisión: analgesia + antiemético"
                ),
                listOf(
                    "Basar toda la analgesia en el opioide (más PONV, sedación, retención, iléo)",
                    "Olvidar el paracetamol «porque es débil» (sinergia real con AINE y opioides)",
                    "AINE en el paciente renal o con sangrado activo sin evaluar el riesgo"
                ),
                "Multimodal = paracetamol + AINE + regional + adyuvantes; el opioide es el rescate titulado, no la base."
            ),
            StudyCard(
                "Opioides y PCA: seguridad",
                "El opioide titulado con vigilancia de sedación y respiración es seguro; el bolo no vigilado no lo es.",
                listOf(
                    "Sedación precede a la depresión respiratoria: escala PASS/PADOS vigilada",
                    "PCA: bolo con candado (morfina 1 mg/6–8 min; fentanilo 10–20 µg) — el paciente titula",
                    "No dar bolo de enfermería ni de familiar (error clásico de sobredosis)",
                    "Naloxona titulada 0,04 mg IV: despierta sin crisis de dolor; repetir (duración menor)",
                    "Capnografía o apnea-monitor en pacientes de riesgo (AOS, ancianos, combinación con sedantes)"
                ),
                listOf(
                    "Morfina PCA: 1 mg/bolo, candado 6–8 min, sin infusión continua en AOS",
                    "Equianalgesia: morfina 10 mg ≈ fentanilo 100 µg ≈ hidromorfona 1,5 mg",
                    "Fentanilo transdérmico NO para dolor agudo postop (inicio 12–24 h)",
                    "Rotación oral: morfina 30 mg VO ≈ oxicodeona 20 mg ≈ fentanilo parche 25 µg/h (aprox, estables)"
                ),
                listOf(
                    "PCA con infusión continua de base en obeso con AOS",
                    "Naloxona en bolo único de 0,4 mg (crisis de dolor, edema agudo)",
                    "Confundir sedación con «comodidad» y aumentar el bolo"
                ),
                "Opioide = titulación + vigilancia de sedación + naloxona titulada lista; PCA sin base continua en riesgo."
            ),
            StudyCard(
                "Escalas de dolor y sedación",
                "Medir para tratar: EVA/EVN en comunicantes, caras en pediátricos, CPOT en no comunicables; RASS/CPOT para sedación.",
                listOf(
                    "EVA 0–10: objetivo ≤3 en reposo (slider interactivo en la app)",
                    "Wong-Baker (caras): 3 años+; FLACC: 2 meses–7 años",
                    "CPOT 0–8: dolor en paciente crítico no comunicable; >2 = dolor significativo",
                    "RASS −5..+4: sedación; objetivo típico en UCI −2..0",
                    "Documentar en el expediente: tendencia, no solo el número aislado"
                ),
                listOf(
                    "EVA ≥7: rescate multimodal, no solo opioide",
                    "CPOT: expresión facial, movimientos, tono, compatibilidad con ventilador, consuelo",
                    "Aldrete incluye actividad y respiración: el dolor influye en ambos",
                    "PADSS: alta de cirugía ambulatoria — dolor controlado es criterio"
                ),
                listOf(
                    "Asumir «no duele» porque el paciente sedado no se queja (usar CPOT)",
                    "Medir solo una vez y dar alta de la sala (medir en el tiempo)",
                    "Confundir agitación de dolor con delirium sin evaluar ambas"
                ),
                "Escala correcta + objetivo EVA ≤3 + tendencia documentada: el dolor se gestiona con datos."
            ),
            StudyCard(
                "Bloqueos para analgesia postoperatoria",
                "El bloqueo regional es la analgesia más eficaz con menos efectos adversos: elección según cirugía, técnica ecoguiada y catéter cuando la duración lo pide.",
                listOf(
                    "Abdomen: TAP, subcostal, ilioinguinal/iliohipogástrico, rectus — ropivacaína 0,2–0,375 %",
                    "Torax: paravertebral, serratus, Pecs I/II — alternativa a la epidural torácica",
                    "Extremidades: femoral, adductor canal, sciatic, interscalene (con advertencia frénica)",
                    "Catéter continuo: ropivacaína 0,2 % a 5–10 mL/h — vigilar fuerza, LAST y filtración",
                    "Técnica: ecografía, inyección fraccionada, dosis máxima contada (calculadora de la app)"
                ),
                listOf(
                    "Ropivacaína 0,2 %: 20–40 mL de bolo; catéter 5–10 mL/h",
                    "Bupi 0,25 %: máx 2,5 mg/kg (175 mg/70 kg); con epi 3 mg/kg",
                    "Adyuvantes: dexamedetomidina 50–100 µg o dexametasona 8 mg prolongan el bloqueo",
                    "TAP: 0,2–0,3 mL/kg por lado con ropi 0,3 % (máx 3 mg/kg total)"
                ),
                listOf(
                    "Bolo en alta presión o con parestesia (riesgo intraneural)",
                    "Exceder la dosis máxima al sumar bloqueos bilaterales",
                    "Confundir bloqueo motor esperado con «complicación» sin revisar el plan"
                ),
                "Bloqueo = analgesia potentísima: ecografía + dosis máxima + plan de catéter cuando la cirugía lo pide."
            ),
            StudyCard(
                "Prevención del dolor crónico postquirúrgico",
                "El dolor agudo mal tratado predice dolor crónico: la prevención empieza en el quirófano, no en la consulta del mes 3.",
                listOf(
                    "Factores de riesgo: dolor agudo intenso, cirugía con riesgo nervioso (toracotomía, mastectomía, hernia), psicología, opioides previos",
                    "Prevención: multimodal intensivo en las primeras 48–72 h + bloqueo regional + ketamina en cirugías de alto riesgo",
                    "Gabapentinoides preoperatorios: evidencia mixta — solo en protocolos específicos",
                    "Vigilar y documentar: la tendencia de EVA detecta el dolor que se cronifica",
                    "Plan de alta: escalera de analgesia oral + criterios de alarma + cita si EVA >4 persistente"
                ),
                listOf(
                    "Objetivo en las primeras 72 h: EVA ≤3 en reposo, ≤4 con movimiento",
                    "Cirugías de riesgo (toracotomía, mastectomía): paravertebral/serratus + ketamina 0,1 mg/kg/h",
                    "El dolor con movimiento (EVA dinámica) predice mejor la cronificación que el de reposo",
                    "La app documenta EVA y analgesia en el expediente: audite las tendencias"
                ),
                listOf(
                    "Dar de alta con EVA 6 «porque en casa se tolera»",
                    "Terminar la analgesia cuando termina el bloqueo (planear la transición oral)",
                    "Ignorar el paciente que ya tomaba opioides (plan de escalado y descenso)"
                ),
                "El dolor crónico se previene en 72 h: multimodal + regional + transición oral planificada."
            )
        ),
        questions = listOf(
            StudyQuestion(
                "Regimen multimodal más racional para colecistectomía laparoscópica:",
                listOf(
                    "Morfina PCA sola",
                    "Paracetamol + AINE + bloqueo TAP/rectus + opioide de rescate",
                    "Parche de fentanilo",
                    "Solo ketamina continua"
                ),
                1,
                "Multimodal: línea base no opioide + regional + opioide de rescate. El parche transdérmico no es para dolor agudo.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "PCA de morfina correcta en un adulto sano:",
                listOf(
                    "2 mg/bolo con candado de 2 min",
                    "1 mg/bolo con candado de 6–8 min, sin base continua en AOS",
                    "Bolo de enfermería cada hora",
                    "Infusión continua de 2 mg/h + bolos"
                ),
                1,
                "PCA estándar: 1 mg de morfina, candado 6–8 min; base continua solo en casos seleccionados (no en AOS).",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "Escala de dolor para un paciente crítico intubado y sedado:",
                listOf(
                    "EVA",
                    "CPOT",
                    "Wong-Baker",
                    "FLACC"
                ),
                1,
                "CPOT (0–8) evalúa el dolor del no comunicable; >2 indica dolor significativo. La app la incluye en Escalas → Dolor.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "Objetivo de EVA en reposo en las primeras 72 h postoperatorias:",
                listOf(
                    "0 siempre",
                    "≤3 en reposo y ≤4 con movimiento",
                    "≤6",
                    "No hay objetivo"
                ),
                1,
                "El objetivo terapéutico clásico: EVA ≤3 en reposo; el dolor dinámico alto predice cronificación.",
                listOf("R1")
            ),
            StudyQuestion(
                "Adyuvante que prolonga el bloqueo periférico ecoguiado:",
                listOf(
                    "Adrenalina en bupi 0,25 % siempre",
                    "Dexamedetomidina 50–100 µg o dexametasona 8 mg",
                    "Ondansetrón",
                    "Bicarbonato aislado"
                ),
                1,
                "Dexamedetomidina y dexametasona son los adyuvantes con mejor evidencia para prolongar el bloqueo; la adrenalina solo con bupi y en dosis límite.",
                listOf("R2", "R3")
            ),
            StudyQuestion(
                "Paciente con EVA 8 a las 12 h de toracotomía con catéter paravertebral funcionando. Conducta:",
                listOf(
                    "Subir opioide solo",
                    "Revisar el catéter/bloqueo + añadir multimodal (paracetamol, AINE, ketamina baja)",
                    "Nada: es normal",
                    "Suspender el catéter"
                ),
                1,
                "EVA 8 con bloqueo en marcha exige revisar el bloqueo (nivel, filtración) y reforzar la multimodal: la escalera, no solo el opioide.",
                listOf("R3")
            )
        ),
        bibliography = listOf(
            "Chou R et al. Management of Postoperative Pain: A Clinical Practice Guideline (APS/ASRA/ASA). J Pain. 2016;17(2):131-157.",
            "Wick EC, Grant MC, Wu CL. Postoperative multimodal analgesia pain management with nonopioid analgesics and techniques. JAMA Surg. 2017;152(7):691-697.",
            "Kehlet H, Jensen TS, Woolf CJ. Persistent postsurgical pain: risk factors and prevention. Lancet. 2006;367(9522):1618-1625.",
            "Cronos Anestesia: Escalas (EVA, CPOT, RASS) y calculadoras de dosis local en la app."
        )
    ),

    // ============================== 12. CRISIS Y EMERGENCIAS ==============================
    StudyArea(
        id = "cri",
        name = "Crisis y emergencias",
        desc = "Anafilaxia, hipertermia maligna, LAST, paro perioperatorio y broncoespasmo: los cinco minutos que definen el desenlace.",
        cards = listOf(
            StudyCard(
                "Anafilaxia perioperatoria",
                "Reacción alérgica grave intraoperatoria: hipotensión + broncoespasmo + rash tras un fármaco. La adrenalina IM temprana salva.",
                listOf(
                    "Signos: hipotensión brusca (a veces solo), broncoespasmo, urticaria, angioedema, EtCO2 baja",
                    "Gatillos más frecuentes: antibióticos, relajantes, látex, clorhexidina, colorantes",
                    "Adrenalina IM 0,5 mg (1:1000) repetida cada 5 min; IV 50–100 µg bolos si hay acceso y monitor",
                    "Parar el gatillo, 100 % O2, volumen (20–30 mL/kg), retirar el vaporizador, llamar ayuda",
                    "Después: triptasa sérica (1–4 h), estudio alergológico a 4–6 semanas, escribir el expediente"
                ),
                listOf(
                    "Adrenalina IM: 0,5 mg (adulto) en el muslo; niños 0,01 mg/kg (máx 0,5)",
                    "Infusión post-reanimación: adrenalina 0,05–0,1 µg/kg/min si es refractaria",
                    "El bolo IV de 1 mg NO está indicado (salvo paro): causa arritmias e isquemia",
                    "Antihistamínicos y corticoides: adyuvantes, NO sustituyen a la adrenalina"
                ),
                listOf(
                    "Retrasar la adrenalina IM por buscar el acceso IV",
                    "Dar solo «bolos de cristaloide» esperando que la presión suba",
                    "Olvidar la triptasa y la derivación alergológica (el paciente vuelve a exponerse)"
                ),
                "Anafilaxia = adrenalina IM YA (0,5 mg) + volumen + retirar el gatillo; después, estudio y documentación."
            ),
            StudyCard(
                "Hipertermia maligna: protocolo de dantroleno",
                "Crisis hipermetabólica por gatillos (volátiles + succinilcolina) en susceptibles: EtCO2 alta inexplicable, taquicardia, rigidez, acidosis y fiebre tardía.",
                listOf(
                    "Signo más temprano: EtCO2 >55 mmHg pese a aumentar la ventilación",
                    "Parar los gatillos, llamar ayuda, dantroleno 2,5 mg/kg IV repetido hasta controlar (máx 10 mg/kg)",
                    "Enfriar activo (<38 °C): suero frío, manto, lavado gástrico frío",
                    "Tratar hiperkalemia: CaCl, insulina-glucosa; acidosis: bicarbonato si pH <7,2",
                    "Vigilar 24–48 h en UCI (recrudescencia) y estudiar genética; dejar naloxona fuera"
                ),
                listOf(
                    "Dantroleno: 2,5 mg/kg IV en bolo, repetir cada 5–10 min; 20 mg/vial con 60 mL de agua estéril",
                    "Dantroleno lleva manitol: diuresis >2 mL/kg/h obligatoria",
                    "Gasometría cada 15 min; CK puede >10 000; vigilar insuficiencia renal",
                    "Alternativa: azumoleno (dantrium IV nanosuspensión) según disponibilidad"
                ),
                listOf(
                    "«Sólo es fiebre»: retrasar el dantroleno por esperar la temperatura (llega TARDE)",
                    "Seguir con el volátil «porque el paciente tolera»",
                    "Olvidar el seguimiento UCI y el estudio familiar (consejo genético)"
                ),
                "HM: parar gatillos + dantroleno 2,5 mg/kg repetido + enfriar + UCI; la EtCO2 es el aviso temprano."
            ),
            StudyCard(
                "LAST: protocolo de lípidos",
                "Toxicidad sistémica por anestésico local: convulsiones y colapso cardiovascular con arritmias refractarias al tratamiento estándar.",
                listOf(
                    "Prodromos: perioral, tinnitus, agitación, somnolencia, arritmia o convulsión repentina",
                    "LIPÍDOS 20 %: 1,5 mL/kg en bolo (≈100 mL adulto) + infusión 0,25 mL/kg/min",
                    "Si persiste: repetir bolo ×1 y subir a 0,5 mL/kg/min; máx 12 mL/kg",
                    "Paro: RCP prolongada >1 h; adrenalina <1 µg/kg bolos; evitar lidocaína, vasopresina y bloqueadores Ca",
                    "Prevención: dosis máxima contada, testigo, ecografía, aspiración, fraccionamiento"
                ),
                listOf(
                    "Bolo típico adulto 70 kg: 105 mL (≈ 1 bolsita de 100 mL); infusión 17,5 mL/min",
                    "La app trae la calculadora de dosis máxima de anestésicos y el protocolo en Emergencias → LAST",
                    "Vigilar 12 h después (redistribución: puede reascender)",
                    "Propofol NO sustituye a los lípidos (dosis de lípidos insuficiente y depresión)"
                ),
                listOf(
                    "Adrenalina a dosis de ACLS estándar en LAST (peor desenlace en modelos)",
                    "Seguir «protocolo de convulsión» con benzodiacepinas altas sin lípidos",
                    "No vigilar el reascenso de la toxicidad tras el rescate"
                ),
                "LAST: lípidos 20 % YA, RCP larga, adrenalina modesta; prevención = dosis máxima + testigo + ecografía."
            ),
            StudyCard(
                "Paro cardíaco perioperatorio",
                "El paro en quirófano suele ser reversible si la causa se corrige: piense en las 4H/4T con el quirófano como ventaja (monitor, vía aérea, equipo).",
                listOf(
                    "Causas perioperatorias: hipoxia, hipovolemia/sangrado, neumotórax a tensión, taponamiento, embolia (aire, grasa, amniótica), anafilaxis, LAST, HM, hipotermia",
                    "RCP: 100–120/min, 5–6 cm, interrupciones mínimas; capnografía guía la calidad (EtCO2 >10 mmHg)",
                    "Adrenalina 1 mg IV/IO cada 3–5 min en paro no desfibrilable; VF/TV: desfibrilar 200 J (bifásico) y continuar",
                    "Corregir la causa en paralelo: volumen, sangre, descompresión, antídoto (lípidos, dantroleno, glucagon)",
                    "Reanimación prolongada tiene más éxito en el quirófano (causa reversible + equipo)"
                ),
                listOf(
                    "EtCO2 <10 mmHg tras 20 min de RCP bien hecha: mal pronóstico; salto brusco = retorno",
                    "Percusión precordial en el quirófano: diagnosticar taponamiento/neumotórax en segundos",
                    "ECO al lecho (FoCUS): differentiate paro pseudo (hipovolemia, taponamiento)",
                    "Post-paro: ICU, TTM 32–36 °C según protocolo, coronariografía si es isquémico"
                ),
                listOf(
                    "Seguir RCP «de rutina» sin buscar la causa perioperatoria específica",
                    "Olvidar el neumotórax a tensión en laparoscopía con presión alta",
                    "Suspender la reanimación antes de corregir las causas reversibles"
                ),
                "Paro perioperatorio: 4H/4T + capnografía + Eco al lecho: el quirófano tiene las herramientas para revertirlo."
            ),
            StudyCard(
                "Broncoespasmo, laringoespasmo y aspiración",
                "Las tres crisis respiratorias intraoperatorias más frecuentes: reconocer y actuar por pasos, sin improvisar.",
                listOf(
                    "Broncoespasmo: sibilancias + presión pico alta + meseta en capnografía → salbutamol inhalado/nebulizado, volátil (broncodilatador), hidrocortisona 100–200 mg, MgSO4 2 g si refractario",
                    "Laringoespasmo: estridor inspiratorio, no ventila → O2 100 % + presión continua + propofol 0,5–1 mg/kg; SCh 0,5–1 mg/kg si no cede",
                    "Aspiración: rechazo por material en la vía aérea, lavado solo si es sólido; oxígeno, PEEP, antibiótico NO profiláctico de rutina; vigilar 6 h",
                    "EtCO2 baja + sibilancias + presión alta: piense también en tubo obstruido, mordida, neumotórax, anafilaxis",
                    "Prevención: ayuno, bloqueo/protección con antiácidos en riesgo, PONV controlado (vómito aspirado)"
                ),
                listOf(
                    "Salbutamol: 4–8 puffs por vía del tubo o 2,5–5 mg nebulizado; repetir cada 10–20 min",
                    "Hidrocortisona 100–200 mg IV en broncoespasmo moderado-severo",
                    "Laringoespasmo: el 80 % cede con presión continua + propofol; SCh es el rescate",
                    "Aspiración con pH <2,5 y volumen >0,4 mL/kg: riesgo alto — vigilancia con SpO2 y radiografía"
                ),
                listOf(
                    "Atribuir toda la sibilancia al asma (tubo, alergia, edema, anafilaxis)",
                    "Ventilar con presión alta «para abrir» el laringoespasmo (empeora: el aire entra al estómago)",
                    "Lavado bronquial agresivo de la aspiración (difiere el daño)"
                ),
                "Broncoespasmo: broncodilatador + volátil; laringoespasmo: presión + propofol → SCh; aspiración: aspirar, O2, vigilar."
            )
        ),
        questions = listOf(
            StudyQuestion(
                "Hipotensión brusca + broncoespasmo + urticaria a los 10 min de la inducción con rocuronio. Primera medida:",
                listOf(
                    "Adrenalina IM 0,5 mg y parar el gatillo",
                    "Bolos de cristaloide solo",
                    "Aumentar el volátil",
                    "Hidrocortisona 100 mg y vigilar"
                ),
                0,
                "Anafilaxia: adrenalina IM temprana (0,5 mg adulto) + parar el gatillo + volumen; corticoides y antihistamínicos son adyuvantes tardíos.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "EtCO2 58 mmHg con taquicardia y rigidez maseterina a los 30 min de anestesia con sevoflurano y SCh. Medicamento clave:",
                listOf(
                    "Atropina",
                    "Dantroleno 2,5 mg/kg IV repetido",
                    "Sodio bicarbonato",
                    "Fentanilo"
                ),
                1,
                "HM: dantroleno 2,5 mg/kg IV repetido cada 5–10 min hasta controlar, más enfriamiento y corrección de K/acidosis.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "Convulsión y arritmia durante un bloqueo axilar con lidocaína. Tratamiento específico:",
                listOf(
                    "Lípidos 20 % 1,5 mL/kg bolo + infusión 0,25 mL/kg/min",
                    "Benzodiacepina a dosis altas sola",
                    "Adrenalina 1 mg IV",
                    "Atropina"
                ),
                0,
                "LAST: lípidos 20 % es el tratamiento específico; adrenalina a dosis ACLS estándar empeora; vigilar 12 h.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "EtCO2 cae a 3 mmHg en un paciente con RCP en marcha. Significado:",
                listOf(
                    "Compresiones insuficientes o fallo de vía aérea: optimizar calidad",
                    "Mejoría",
                    "Hiperkalemia",
                    "Nada relevante"
                ),
                0,
                "EtCO2 <10 mmHg durante la RCP refleja baja perfusión: mejorar compresiones, revisar vía aérea y buscar la causa reversible.",
                listOf("R2", "R3")
            ),
            StudyQuestion(
                "Laringoespasmo completo tras extubación. Secuencia correcta:",
                listOf(
                    "O2 100 % + presión continua + propofol 0,5–1 mg/kg; SCh 0,5–1 mg/kg si no cede",
                    "Intubar de inmediato",
                    "Solo aspirar",
                    "Broncodilatador nebulizado"
                ),
                0,
                "La secuencia clásica: presión positiva continua con O2, propofol (relajante laríngeo) y SCh como rescate definitivo.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "Neumotórax a tensión intraoperatorio (presión pico alta, hipotensión, EtCO2 baja). Maniobra inmediata:",
                listOf(
                    "Aumentar PEEP",
                    "Descompresión con aguja en el 2.º espacio intercostal línea clavicular media",
                    "Esperar radiografía",
                    "Suspender la laparoscopía y observar"
                ),
                1,
                "Descompresión inmediata con aguja (o trocar) en el hemitórax afectado; luego tubo torácico. La laparoscopía y la PEEP son factores de riesgo.",
                listOf("R2", "R3")
            )
        ),
        bibliography = listOf(
            "Cronos Anestesia: pestaña Emergencias (6 protocolos: ACLS, PALS, anafilaxia, HM, LAST, vía aérea difícil).",
            "Kroigaard M et al. Management of anaphylaxis: guideline de la Society (revisión periódica).",
            "Rosenberg H et al. Malignant Hyperthermia Association of the United States (MHAUS): protocolo vigente.",
            "Neal JM et al. ASRA checklist: LAST treatment. Reg Anesth Pain Med. 2010;35(2):152-156."
        )
    )
)
