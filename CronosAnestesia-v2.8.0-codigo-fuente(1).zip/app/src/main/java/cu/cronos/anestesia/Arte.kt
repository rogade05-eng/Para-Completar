package cu.cronos.anestesia

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// =====================================================================
//  IMÁGENES DE LA APLICACIÓN (v2.4.0 — contrato §5.2 «imágenes»)
//  Esquemas anatómicos y fisiológicos dibujados por la aplicación con
//  Compose Canvas: 100 % vectoriales (nítidos a cualquier zoom, sin
//  archivos PNG ni permisos), offline, en español.
//  Cada esquema se inserta en su tema clínico (ClinTopic.artId) y se
//  consulta en la pestaña Imágenes.
// =====================================================================

data class ArtInfo(
    val id: String,
    val title: String,
    val caption: String,
    val usedIn: String
)

object Arte {
    val ALL: List<ArtInfo> = listOf(
        ArtInfo(
            "columna_sagital",
            "Columna lumbar: corte sagital",
            "Vía media de la punción raquídea: piel, ligamentos supraspinoso e interespinoso, ligamento amarillo (el «pop»), espacio epidural y dura con LCR. El cono medular termina en L1 (adulto): se puntúa en L3-L4 o por debajo, con la aguja 10–15° cefalada.",
            "Clínica → Bloqueos → Anestesia raquídea · Combinada (CSE)"
        ),
        ArtInfo(
            "espacio_epidural",
            "Espacio epidural y pérdida de resistencia",
            "El ligamento amarillo cede de golpe al llegar al epidural (LOR con salino). El espacio contiene grasa y venas (plexo de Batson): aspirar antes de inyectar; la aguja corta del Tuohy avanza centímetros, no milímetros, y el catéter queda 4–5 cm dentro.",
            "Clínica → Bloqueos → Epidural · Caudal"
        ),
        ArtInfo(
            "dermatomas",
            "Dermatomas del bloqueo neuroaxial",
            "Alturas de referencia para fijar el nivel del bloqueo: C4 hombros, T4 pezón (objetivo de la cesárea), T6 xifoides, T8 reborde costal, T10 ombligo, L1 ingle, S2–S4 perineo. El simpático sube 2 segmentos sobre el sensitivo y el motor queda 2 por debajo.",
            "Clínica → Bloqueos → Anatomía neuroaxial aplicada"
        ),
        ArtInfo(
            "alveolo_capilar",
            "Intercambio alveolo-capilar",
            "El O2 difunde del alvéolo (PAO2 ≈ 100 mmHg) al capilar (PvO2 ≈ 40) y el CO2 hace el camino inverso, a través de una membrana de 0,3 µm. El gradiente alveolo-arterial que se calcula en gasometría nace de las desigualdades V/Q y del shunt anatómico.",
            "Clínica → Fisiología → Intercambio gaseoso"
        ),
        ArtInfo(
            "curva_pv",
            "Curva presión-volumen de la ventilación",
            "Bajo el punto de inflexión inferior (PII) el pulmón colapsado se recluta con presión pero poco volumen; la zona lineal es el rango de trabajo del Vt protector (6 mL/kg de peso predicho); sobre el punto de inflexión superior se sobreexpande y lesiona.",
            "Clínica → Fisiología → Mecánica respiratoria aplicada · Ventilación mecánica (Calculadoras)"
        )
    )

    fun info(id: String): ArtInfo? = ALL.firstOrNull { it.id == id }

    fun indexOf(id: String): Int = ALL.indexOfFirst { it.id == id }
}

/** Registro válido de artId para pruebas. */
val ART_IDS: Set<String> = Arte.ALL.map { it.id }.toSet()

@Composable
fun ArtHost(artId: String, modifier: Modifier = Modifier) {
    val info = Arte.info(artId) ?: return
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(
                info.title,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(6.dp))
            ArtScheme(artId, Modifier.fillMaxWidth().height(240.dp))
            Spacer(Modifier.height(6.dp))
            Text(
                info.caption,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun ArtScheme(artId: String, modifier: Modifier = Modifier) {
    val primary = MaterialTheme.colorScheme.primary
    val onSurface = MaterialTheme.colorScheme.onSurface
    val surfaceVariant = MaterialTheme.colorScheme.surfaceVariant
    val secondaryContainer = MaterialTheme.colorScheme.secondaryContainer
    val errorColor = MaterialTheme.colorScheme.error
    val tertiary = MaterialTheme.colorScheme.tertiary
    val density = LocalDensity.current
    val labelSize = with(density) { 11.sp.toPx() }
    val noteSize = with(density) { 9.sp.toPx() }

    Canvas(modifier) {
        val tp = android.graphics.Paint().apply {
            color = onSurface.toArgb()
            textSize = labelSize
            isAntiAlias = true
        }
        val tpSmall = android.graphics.Paint(tp).apply { textSize = noteSize }
        when (artId) {
            "columna_sagital" -> drawColumna(primary, secondaryContainer, errorColor, tertiary, tp, tpSmall)
            "espacio_epidural" -> drawEpidural(primary, secondaryContainer, errorColor, tertiary, tp, tpSmall)
            "dermatomas" -> drawDermatomas(primary, secondaryContainer, tp, tpSmall)
            "alveolo_capilar" -> drawAlveolo(primary, secondaryContainer, errorColor, tertiary, tp, tpSmall)
            "curva_pv" -> drawCurvaPv(primary, secondaryContainer, errorColor, tp, tpSmall)
        }
    }
}

// coordenadas de diseño 0..300 (x) × 0..220 (y), escaladas al lienzo
private fun DrawScope.S() = size.width / 300f

private fun DrawScope.txt(text: String, x: Float, y: Float, paint: android.graphics.Paint) {
    drawContext.canvas.nativeCanvas.drawText(text, x * S(), y * S(), paint)
}

private fun DrawScope.ln(x1: Float, y1: Float, x2: Float, y2: Float, c: Color, w: Float = 2f) {
    drawLine(c, Offset(x1 * S(), y1 * S()), Offset(x2 * S(), y2 * S()), strokeWidth = w * S() / 1.4f, cap = StrokeCap.Round)
}

private fun DrawScope.dot(x: Float, y: Float, r: Float, c: Color) {
    drawCircle(c, r * S(), Offset(x * S(), y * S()))
}

private fun DrawScope.box(x: Float, y: Float, w: Float, h: Float, c: Color, fill: Boolean = true) {
    val sz = Size(w * S(), h * S())
    val off = Offset(x * S(), y * S())
    if (fill) drawRoundRect(c, off, sz, CornerRadius(4 * S()))
    else drawRoundRect(c, off, sz, CornerRadius(4 * S()), style = Stroke(1.6f * S()))
}

private fun DrawScope.pathOf(pts: List<OffsetF>, c: Color, close: Boolean = true, fill: Boolean = true, w: Float = 2f) {
    val p = Path()
    p.moveTo(pts[0].x * S(), pts[0].y * S())
    pts.drop(1).forEach { p.lineTo(it.x * S(), it.y * S()) }
    if (close) p.close()
    if (fill) drawPath(p, c) else drawPath(p, c, style = Stroke(w * S() / 1.4f))
}

private data class OffsetF(val x: Float, val y: Float)

// --------------------- 1. Columna lumbar sagital ---------------------
private fun DrawScope.drawColumna(
    line: Color, band: Color, danger: Color, accent: Color,
    tp: android.graphics.Paint, tpS: android.graphics.Paint
) {
    // piel (superficie posterior a la derecha: la aguja entra por la derecha)
    ln(268f, 8f, 268f, 212f, line, 2f)
    txt("Piel", 272f, 24f, tpS)

    // cuerpos vertebrales (izquierda = anterior)
    val bodies = listOf(14f, 64f, 114f, 164f)
    bodies.forEach { y ->
        box(6f, y, 60f, 26f, band)
        box(6f, y, 60f, 26f, line, fill = false)
        // disco intervertebral
        if (y != bodies.last()) ln(10f, y + 26f, 62f, y + 26f, accent, 3f)
    }
    txt("Cuerpos vertebrales (anterior)", 6f, 210f, tpS)

    // láminas y apófisis espinosas (posterior, derecha)
    val procY = listOf(24f, 74f, 124f, 174f) // punta de cada apófisis
    bodies.forEachIndexed { i, y ->
        pathOf(listOf(OffsetF(66f, y + 2f), OffsetF(96f, y + 10f), OffsetF(procY[i], y + 16f), OffsetF(96f, y + 24f), OffsetF(66f, y + 22f)), line, fill = false)
    }
    // ligamento supraspinoso: une las puntas por fuera
    val tips = procY.mapIndexed { i, p -> OffsetF(p, bodies[i] + 16f) }
    for (i in 0 until tips.size - 1) ln(tips[i].x, tips[i].y, tips[i + 1].x, tips[i + 1].y, accent, 3f)
    txt("Lig. supraspinoso", 208f, 66f, tpS)

    // cono medular (L1) y cauda
    ln(30f, 20f, 30f, 96f, line, 4f)
    txt("Cono medular (L1)", 34f, 30f, tpS)
    for (i in 0..3) ln(30f, 96f + i * 8f, 40f + i * 6f, 130f, line, 1f)
    txt("Cauda equina", 34f, 108f, tpS)

    // dura / LCR: línea que baja paralela al canal
    ln(44f, 16f, 44f, 196f, line, 2f)
    txt("Dura · LCR", 48f, 150f, tpS)

    // espacio epidural: banda entre lámina y dura en el espacio L3-L4
    box(50f, 140f, 20f, 18f, band)
    txt("Espacio epidural", 76f, 138f, tpS)

    // ligamento amarillo en el espacio L3-L4 (entre procesos)
    ln(102f, 140f, 102f, 158f, danger, 5f)
    txt("Lig. amarillo", 108f, 168f, tpS)

    // aguja: entra desde abajo-derecha 15° cefalada hasta el espacio L3-L4
    ln(262f, 196f, 106f, 150f, line, 3f)
    dot(106f, 150f, 2.4f, danger)
    txt("Aguja 25G · 15° cefalada", 190f, 202f, tpS)

    // etiqueta del espacio de punción
    txt("Punción L3-L4", 118f, 118f, tpS)
    ln(120f, 121f, 112f, 146f, danger, 1f)
}

// --------------------- 2. Espacio epidural (zoom) ---------------------
private fun DrawScope.drawEpidural(
    line: Color, band: Color, danger: Color, accent: Color,
    tp: android.graphics.Paint, tpS: android.graphics.Paint
) {
    // capas de izquierda (superficial) a derecha (profunda)
    // piel y subcutáneo
    box(4f, 70f, 40f, 80f, band)
    txt("Subcutáneo", 8f, 60f, tpS)
    // ligamento supraspinoso / interespinoso
    ln(44f, 60f, 44f, 160f, accent, 6f)
    txt("Lig. interespinoso", 40f, 48f, tpS)
    // ligamento amarillo
    box(70f, 60f, 26f, 100f, Color(0xFFB5A642))
    txt("Lig. amarillo", 66f, 48f, tpS)
    // espacio epidural: grasa + venas
    box(96f, 60f, 70f, 100f, band)
    for (i in 0..2) dot(112f + i * 20f, 84f + (i % 2) * 34f, 4f, danger)
    txt("Epidural: grasa + venas", 100f, 172f, tpS)
    // dura madre
    box(166f, 56f, 12f, 108f, danger)
    txt("Dura madre", 160f, 44f, tpS)
    // aracnoides
    ln(186f, 60f, 186f, 160f, line, 2f)
    txt("Aracnoides", 190f, 44f, tpS)
    // LCR y médula
    box(196f, 60f, 92f, 100f, Color(0x332196F3))
    ln(226f, 78f, 226f, 142f, line, 4f)
    txt("LCR", 288f, 120f, tpS)
    txt("Médula / raíces", 202f, 172f, tpS)

    // aguja Tuohy desde abajo con bisel y LOR
    ln(20f, 210f, 112f, 118f, line, 3f)
    // jeringa con émbolo (pérdida de resistencia)
    box(6f, 196f, 34f, 14f, line, fill = false)
    ln(8f, 203f, 22f, 203f, danger, 2f)
    txt("Jeringa de LOR (salino)", 40f, 214f, tpS)
    dot(112f, 118f, 2.6f, danger)
    txt("Punta en el epidural", 88f, 96f, tpS)

    // catéter dentro del espacio
    ln(108f, 126f, 160f, 126f, accent, 3f)
    txt("Catéter 4–5 cm", 116f, 140f, tpS)

    // advertencia
    txt("¡Aspirar: sangre = vena, LCR = demasiado profundo!", 8f, 26f, tpS)
}

// --------------------- 3. Dermatomas ---------------------
private fun DrawScope.drawDermatomas(
    line: Color, band: Color,
    tp: android.graphics.Paint, tpS: android.graphics.Paint
) {
    // silueta frontal simplificada
    // cabeza
    drawCircle(line, 18f * S(), Offset(80f * S(), 26f * S()), style = Stroke(2f * S() / 1.4f))
    // cuello + tronco
    pathOf(listOf(
        OffsetF(72f, 44f), OffsetF(88f, 44f), OffsetF(90f, 54f), OffsetF(112f, 62f),
        OffsetF(118f, 92f), OffsetF(118f, 176f), OffsetF(42f, 176f), OffsetF(42f, 92f),
        OffsetF(48f, 62f), OffsetF(70f, 54f)
    ), band, fill = true)
    pathOf(listOf(
        OffsetF(72f, 44f), OffsetF(88f, 44f), OffsetF(90f, 54f), OffsetF(112f, 62f),
        OffsetF(118f, 92f), OffsetF(118f, 176f), OffsetF(42f, 176f), OffsetF(42f, 92f),
        OffsetF(48f, 62f), OffsetF(70f, 54f)
    ), line, fill = false)
    // brazos
    ln(42f, 70f, 22f, 140f, line, 2f)
    ln(118f, 70f, 138f, 140f, line, 2f)
    // piernas
    ln(62f, 176f, 58f, 214f, line, 2f)
    ln(98f, 176f, 102f, 214f, line, 2f)

    // bandas horizontales con etiquetas a la derecha
    val rows = listOf(
        Triple("C4 · hombros", 64f, "clavículas"),
        Triple("T4 · pezón", 92f, "objetivo cesárea"),
        Triple("T6 · xifoides", 112f, "abdomen alto"),
        Triple("T8 · reborde", 128f, "colecistectomía"),
        Triple("T10 · ombligo", 146f, "apéndice, hernia"),
        Triple("L1 · ingle", 168f, "hernia inguinal"),
        Triple("S2–S4 · perineo", 184f, "silla de montar")
    )
    rows.forEachIndexed { i, (label, y, note) ->
        ln(44f, y, 116f, y, if (i % 2 == 0) line else band.copy(alpha = 0.9f), 2f)
        txt(label, 128f, y + 3f, tpS)
        txt(note, 208f, y + 3f, tpS)
    }
    txt("El nivel sensitivo se barre con alcohol o frío", 8f, 208f, tpS)
    txt("Motor: Bromage · Simpático: +2 segmentos", 8f, 218f, tpS)
}

// --------------------- 4. Alvéolo-capilar ---------------------
private fun DrawScope.drawAlveolo(
    line: Color, band: Color, danger: Color, accent: Color,
    tp: android.graphics.Paint, tpS: android.graphics.Paint
) {
    // alvéolo
    drawCircle(band.copy(alpha = 0.5f), 58f * S(), Offset(90f * S(), 60f * S()))
    drawCircle(line, 58f * S(), Offset(90f * S(), 60f * S()), style = Stroke(2.4f * S() / 1.4f))
    txt("Alvéolo", 66f, 30f, tp)
    txt("PAO2 ≈ 100 · PACO2 ≈ 40", 40f, 44f, tpS)

    // membrana
    ln(50f, 118f, 130f, 118f, danger, 4f)
    txt("Membrana 0,3 µm", 148f, 122f, tpS)

    // capilar con eritrocitos
    box(20f, 126f, 200f, 40f, Color(0x22E53935))
    for (i in 0..3) drawCircle(danger, 6f * S(), Offset((44 + i * 40) * S(), (146 - (i % 2) * 8) * S()))
    txt("Capilar pulmonar", 24f, 178f, tpS)
    txt("Venoso: O2 40 · CO2 46 → Arterial: O2 100 · CO2 40", 24f, 190f, tpS)

    // flechas de difusión
    ln(90f, 84f, 90f, 122f, accent, 3f)
    txt("O2", 96f, 104f, tp)
    ln(140f, 122f, 140f, 84f, line, 3f)
    txt("CO2", 148f, 104f, tp)

    // notas laterales
    txt("Shunt: perfusión sin ventilación", 236f, 70f, tpS)
    txt("→ hipoxemia refractaria a O2", 236f, 84f, tpS)
    txt("V/Q bajo: responde a O2", 236f, 106f, tpS)
    txt("FiO2 útil en el quirófano: 0,5–1,0", 236f, 122f, tpS)
    txt("Gradiente A-a ≈ edad/4 + 4", 236f, 146f, tpS)
}

// --------------------- 5. Curva presión-volumen ---------------------
private fun DrawScope.drawCurvaPv(
    line: Color, band: Color, danger: Color,
    tp: android.graphics.Paint, tpS: android.graphics.Paint
) {
    // ejes
    ln(40f, 12f, 40f, 190f, line, 2f)   // eje Y (presión)
    ln(40f, 190f, 288f, 190f, line, 2f) // eje X (volumen)
    txt("P (cmH2O)", 8f, 18f, tpS)
    txt("V (mL)", 262f, 200f, tpS)

    // bucle de histeresis: rama inspiratoria (derecha) y espiratoria (izquierda)
    val up = listOf(
        OffsetF(60f, 176f), OffsetF(70f, 150f), OffsetF(84f, 118f),
        OffsetF(104f, 88f), OffsetF(136f, 62f), OffsetF(184f, 42f), OffsetF(232f, 34f)
    )
    val down = listOf(
        OffsetF(232f, 34f), OffsetF(196f, 56f), OffsetF(160f, 80f),
        OffsetF(126f, 104f), OffsetF(96f, 132f), OffsetF(74f, 158f), OffsetF(60f, 176f)
    )
    pathOf(up, line, close = false, fill = false, w = 3f)
    pathOf(down, danger, close = false, fill = false, w = 3f)
    txt("Inspiración", 196f, 46f, tpS)
    txt("Espiración", 150f, 96f, tpS)

    // punto de inflexión inferior (PII)
    dot(70f, 150f, 3f, danger)
    txt("PII: reclutamiento", 44f, 136f, tpS)
    // punto de inflexión superior
    dot(232f, 34f, 3f, danger)
    txt("PIS: sobreexpansión", 168f, 22f, tpS)

    // zona de trabajo
    box(60f, 70f, 150f, 76f, band.copy(alpha = 0.25f), fill = true)
    txt("Zona de trabajo:", 84f, 90f, tpS)
    txt("Vt 6 mL/kg de peso predicho", 84f, 102f, tpS)
    txt("Pplat < 30 · ΔP < 15", 84f, 114f, tpS)
    txt("PEEP sobre el PII", 84f, 126f, tpS)
}

// --------------------- Galería y detalle (pestaña Imágenes) ---------------------

/** Lista de esquemas disponibles con su descripción (pestaña Imágenes). */
@Composable
fun ArtGallery(onOpen: (Int) -> Unit) {
    val sp = LocalSpacing.current
    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(
            horizontal = sp.screenHPad.dp, vertical = sp.s.dp
        ),
        verticalArrangement = Arrangement.spacedBy(sp.xs.dp)
    ) {
        items(Arte.ALL.size) { i ->
            val a = Arte.ALL[i]
            ItemCard(
                title = a.title,
                subtitle = a.usedIn.substringAfter("→").trim().ifBlank { a.usedIn },
                badge = null,
                onClick = { onOpen(i) }
            )
        }
        item {
            Text(
                "Los esquemas son vectoriales: nítidos a cualquier tamaño, sin conexión. " +
                    "Cada uno se abre también desde su tema clínico correspondiente.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(sp.xs.dp)
            )
        }
    }
}

/** Detalle de un esquema: dibujo ampliado + leyenda + dónde se usa. */
@Composable
fun ArtDetail(index: Int, onBack: () -> Unit) {
    val safe = if (index in Arte.ALL.indices) index else 0
    val a = Arte.ALL[safe]
    val sp = LocalSpacing.current
    DetailTopBar(a.title, "Esquema de la aplicación", onBack)
    ScreenColumn {
        ArtScheme(a.id, Modifier.fillMaxWidth().height(260.dp))
        Spacer(Modifier.height(sp.s.dp))
        SectionLabel("Leyenda")
        BodyText(a.caption)
        SectionLabel("Dónde se usa")
        BodyText(a.usedIn)
    }
}
