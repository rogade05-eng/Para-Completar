package cu.cronos.anestesia

/*
 * ============================================================================
 *  DoseEngine — lógica PURA de la calculadora de dosis por fármaco
 *  (petición del usuario: peso + edad → infusión / sedación / analgesia para
 *  cada medicamento, p. ej. noradrenalina, adrenalina, dopamina, dobutamina).
 *  Sin dependencias de Android ni Compose → testeable con vectores dorados.
 *  La UI (DoseUI.kt) solo pinta los resultados.
 *  Identificadores en inglés; el contenido clínico (etiquetas, notas) es
 *  contenido de datos en español, igual que Data.kt/Data2.kt.
 * ============================================================================
 */

import kotlin.math.min

/** Unidades de dosificación admitidas por el motor. */
enum class DoseUnit(
    val label: String,
    val infusion: Boolean,
    /** Base del total de un bolo: "mg", "µg" o "U". */
    val base: String,
    /** Concentración de dilución esperada: "mg/mL" o "U/mL". */
    val dilutionBase: String,
    /** Etiqueta del caudal horario (solo infusiones). */
    val hourLabel: String = "",
    /** true si el caudal horario es en µg (la dilución va en µg/mL). */
    val isMicro: Boolean = false
) {
    // Dosis única / bolo
    MG_KG("mg/kg", false, "mg", "mg/mL"),
    UG_KG("µg/kg", false, "mg", "mg/mL"),
    MG("mg", false, "mg", "mg/mL"),
    UG("µg", false, "µg", "mg/mL"),
    U_KG("U/kg", false, "U", "U/mL"),
    U("U", false, "U", "U/mL"),

    // Infusiones continuas
    MG_KG_H("mg/kg/h", true, "mg", "mg/mL", "mg/h"),
    UG_KG_H("µg/kg/h", true, "mg", "mg/mL", "µg/h", isMicro = true),
    UG_KG_MIN("µg/kg/min", true, "mg", "mg/mL", "µg/h", isMicro = true),
    MG_KG_MIN("mg/kg/min", true, "mg", "mg/mL", "mg/h"),
    MG_MIN("mg/min", true, "mg", "mg/mL", "mg/h"),
    U_KG_MIN("U/kg/min", true, "U", "U/mL", "U/h"),
    U_MIN("U/min", true, "U", "U/mL", "U/h")
}

/** Dilución estándar: concentración en la MISMA base que la unidad del régimen. */
data class Dilution(val label: String, val concPerMl: Double)

/** Ámbito de edad del régimen. */
object AgeScope {
    const val ALL = 0
    const val ADULT = 1
    const val PEDIATRIC = 2
}

/**
 * Régimen de dosificación de un fármaco.
 * @param pedMin/pedMax rango pediátrico (mismo unit) si difiere del adulto.
 * @param pedAgeLimit edad (años) por debajo de la cual aplica el rango pediátrico.
 * @param cap/pedCap límite absoluto de la dosis total (mg o U).
 */
data class Regimen(
    val label: String,
    val infusion: Boolean,
    val unit: DoseUnit,
    val min: Double,
    val max: Double,
    val note: String = "",
    val pedMin: Double? = null,
    val pedMax: Double? = null,
    val pedNote: String = "",
    val pedAgeLimit: Double = 12.0,
    val cap: Double? = null,
    val pedCap: Double? = null,
    val ageScope: Int = AgeScope.ALL,
    val dilutions: List<Dilution> = emptyList()
)

/** Perfil de dosificación calculable de un fármaco. */
data class DrugDoseProfile(
    val name: String,
    val generalNote: String,
    val regimens: List<Regimen>
)

/** Resultado numérico de un régimen para un paciente dado. */
data class DoseResult(
    /** Dosis total del régimen (bolo) o caudal horario (infusión). */
    val amountMin: Double,
    val amountMax: Double,
    val amountLabel: String,
    /** Velocidad de bomba en mL/h para la dilución elegida. */
    val mlMin: Double,
    val mlMax: Double,
    val pediatric: Boolean,
    /** true si el peso/edad introducido no permite calcular. */
    val needsWeight: Boolean
)

object DoseEngine {

    /** Rango pediátrico activo solo si hay edad introducida y es < límite. */
    fun isPediatric(ageYears: Double, limit: Double = 12.0): Boolean =
        ageYears > 0 && ageYears < limit

    /** ¿Es visible este régimen para la edad dada? */
    fun regimenVisible(r: Regimen, ageYears: Double): Boolean = when (r.ageScope) {
        AgeScope.ADULT -> !isPediatric(ageYears, r.pedAgeLimit)
        AgeScope.PEDIATRIC -> isPediatric(ageYears, r.pedAgeLimit)
        else -> true
    }

    /** Rango (min, max) aplicable según edad. */
    fun rangeFor(r: Regimen, ageYears: Double): Pair<Double, Double> {
        val ped = isPediatric(ageYears, r.pedAgeLimit) && r.pedMin != null && r.pedMax != null
        return if (ped) r.pedMin!! to r.pedMax!! else r.min to r.max
    }

    /** ¿Aplica el límite pediátrico? */
    private fun capFor(r: Regimen, ageYears: Double): Double? {
        val ped = isPediatric(ageYears, r.pedAgeLimit) && r.pedMin != null
        return if (ped) r.pedCap ?: r.cap else r.cap
    }

    /** Dosis total de un bolo en la base de la unidad (mg, µg o U). */
    fun boloAmount(dose: Double, weightKg: Double, unit: DoseUnit): Double = when (unit) {
        DoseUnit.MG_KG -> dose * weightKg
        DoseUnit.UG_KG -> dose * weightKg / 1000.0
        DoseUnit.MG, DoseUnit.UG, DoseUnit.U -> dose
        DoseUnit.U_KG -> dose * weightKg
        else -> 0.0
    }

    /**
     * Caudal horario de una infusión EN LA BASE DE LA DILUCIÓN:
     * unidades µg → µg/h (la dilución va en µg/mL); mg → mg/h; U → U/h.
     */
    fun perHour(dose: Double, weightKg: Double, unit: DoseUnit): Double = when (unit) {
        DoseUnit.MG_KG_H -> dose * weightKg
        DoseUnit.UG_KG_H -> dose * weightKg
        DoseUnit.UG_KG_MIN -> dose * weightKg * 60.0
        DoseUnit.MG_KG_MIN -> dose * weightKg * 60.0
        DoseUnit.MG_MIN -> dose * 60.0
        DoseUnit.U_KG_MIN -> dose * weightKg * 60.0
        DoseUnit.U_MIN -> dose * 60.0
        else -> 0.0
    }

    /** mL/h de bomba: caudal horario / concentración (misma base). */
    fun mlPerHour(perHourValue: Double, concPerMl: Double): Double =
        if (concPerMl > 0) perHourValue / concPerMl else 0.0

    /**
     * Calcula un régimen para peso y edad. Si la dosis tiene límite absoluto
     * (cap), el total se trunca al cap.
     */
    fun regimenResult(
        r: Regimen,
        weightKg: Double,
        ageYears: Double,
        dilution: Dilution?
    ): DoseResult {
        val ped = isPediatric(ageYears, r.pedAgeLimit) && r.pedMin != null && r.pedMax != null
        val (dMin, dMax) = rangeFor(r, ageYears)
        val cap = capFor(r, ageYears)
        val valid = weightKg > 0
        val amountUnit = if (r.infusion) r.unit.hourLabel else r.unit.base

        if (!r.infusion) {
            val aMin = if (valid) {
                val raw = boloAmount(dMin, weightKg, r.unit)
                if (cap != null) min(raw, cap) else raw
            } else 0.0
            val aMax = if (valid) {
                val raw = boloAmount(dMax, weightKg, r.unit)
                if (cap != null) min(raw, cap) else raw
            } else 0.0
            return DoseResult(aMin, aMax, amountUnit, 0.0, 0.0, ped, !valid)
        }

        val phMin = if (valid) perHour(dMin, weightKg, r.unit) else 0.0
        val phMax = if (valid) perHour(dMax, weightKg, r.unit) else 0.0
        val mlMin = if (valid && dilution != null) mlPerHour(phMin, dilution.concPerMl) else 0.0
        val mlMax = if (valid && dilution != null) mlPerHour(phMax, dilution.concPerMl) else 0.0
        return DoseResult(phMin, phMax, amountUnit, mlMin, mlMax, ped, !valid)
    }

    /** Perfil calculable de un fármaco por nombre exacto. */
    fun profileFor(name: String): DrugDoseProfile? = DRUG_DOSE_PROFILES[name]
}
