package cu.cronos.anestesia

import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

// =====================================================================
//  ESCRITORES OOXML MINIMOS (v2.2.0) — 100 % JVM, sin librerías
//  Genera .xlsx (Office Open XML SpreadsheetML) y .docx (WordprocessingML)
//  válidos usando solo java.util.zip. Compatibles con Excel/Word,
//  LibreOffice y Google Docs (importación). Escapan entidades XML.
//  Testeable en JVM (V220Test).
// =====================================================================

object OfficeExport {

    fun escapeXml(s: String): String = buildString(s.length) {
        for (c in s) when {
            c == '&' -> append("&amp;")
            c == '<' -> append("&lt;")
            c == '>' -> append("&gt;")
            c == '"' -> append("&quot;")
            c == '\'' -> append("&apos;")
            c == '\t' -> append("\t")
            c == '\n' -> append(" ")
            c.code < 0x20 -> {} // descarta controles no válidos en XML 1.0
            else -> append(c)
        }
    }

    private fun colLetter(index: Int): String {
        var n = index
        val sb = StringBuilder()
        while (n >= 0) {
            sb.insert(0, ('A' + n % 26))
            n = n / 26 - 1
        }
        return sb.toString()
    }

    /**
     * Escribe una hoja .xlsx con encabezado en negrita y filas de texto o número.
     * Devuelve el archivo escrito.
     */
    fun writeXlsx(
        f: File,
        sheetName: String,
        header: List<String>,
        rows: List<List<String?>>
    ): File {
        fun isNumeric(v: String): Boolean =
            v.toDoubleOrNull() != null && v.length < 16

        fun cell(ref: String, value: String, bold: Boolean): String {
            val s = escapeXml(value)
            return if (isNumeric(value)) {
                "<c r=\"$ref\" s=\"0\"><v>$s</v></c>"
            } else if (bold) {
                "<c r=\"$ref\" t=\"inlineStr\" s=\"1\"><is><t>$s</t></is></c>"
            } else {
                "<c r=\"$ref\" t=\"inlineStr\"><is><t>$s</t></is></c>"
            }
        }

        val sbRows = StringBuilder()
        // fila de encabezado (xf 1 = negrita)
        sbRows.append("<row r=\"1\">")
        header.forEachIndexed { ci, h ->
            sbRows.append("<c r=\"${colLetter(ci)}1\" t=\"inlineStr\" s=\"1\"><is><t>${escapeXml(h)}</t></is></c>")
        }
        sbRows.append("</row>")
        rows.forEachIndexed { ri, row ->
            sbRows.append("<row r=\"${ri + 2}\">")
            row.forEachIndexed { ci, v ->
                if (v != null) sbRows.append(cell("${colLetter(ci)}${ri + 2}", v, bold = false))
            }
            sbRows.append("</row>")
        }

        val contentTypes = """
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>"""

        val rels = """
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""

        val workbook = """
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets><sheet name="${escapeXml(sheetName.take(31))}" sheetId="1" r:id="rId1"/></sheets>
</workbook>"""

        val wbRels = """
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""

        val sheet = """
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<sheetData>${sbRows}</sheetData>
</worksheet>"""

        val styles = """
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="2">
<font><sz val="10"/><name val="Calibri"/></font>
<font><b/><sz val="10"/><color rgb="FF00425A"/><name val="Calibri"/></font>
</fonts>
<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>
<borders count="1"><border/></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="2">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>
</cellXfs>
</styleSheet>"""

        zipFile(
            f,
            mapOf(
                "[Content_Types].xml" to contentTypes,
                "_rels/.rels" to rels,
                "xl/workbook.xml" to workbook,
                "xl/_rels/workbook.xml.rels" to wbRels,
                "xl/worksheets/sheet1.xml" to sheet,
                "xl/styles.xml" to styles
            )
        )
        return f
    }

    /**
     * Escribe un documento .docx con párrafos de 3 estilos:
     * 0 = título (grande, negrita), 1 = encabezado (negrita), 2 = cuerpo.
     */
    fun writeDocx(f: File, blocks: List<Pair<String, Int>>): File {
        val body = StringBuilder()
        blocks.forEach { (text, style) ->
            val rpr = when (style) {
                0 -> "<w:rPr><w:b/><w:color w:val=\"00425A\"/><w:sz w:val=\"32\"/></w:rPr>"
                1 -> "<w:rPr><w:b/><w:color w:val=\"00425A\"/><w:sz w:val=\"24\"/></w:rPr>"
                else -> "<w:rPr><w:sz w:val=\"22\"/></w:rPr>"
            }
            // un párrafo por salto de línea: escapar cada línea por separado
            text.split("\n").forEach { line ->
                body.append("<w:p><w:r>").append(rpr).append("<w:t xml:space=\"preserve\">")
                    .append(escapeXml(line)).append("</w:t></w:r></w:p>")
            }
        }

        val contentTypes = """
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>"""

        val rels = """
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""

        val document = """
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:body>${body}
<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134"/></w:sectPr>
</w:body>
</w:document>"""

        zipFile(
            f,
            mapOf(
                "[Content_Types].xml" to contentTypes,
                "_rels/.rels" to rels,
                "word/document.xml" to document
            )
        )
        return f
    }

    private fun zipFile(f: File, entries: Map<String, String>) {
        ZipOutputStream(FileOutputStream(f)).use { zos ->
            entries.forEach { (name, content) ->
                zos.putNextEntry(ZipEntry(name))
                zos.write(content.toByteArray(Charsets.UTF_8))
                zos.closeEntry()
            }
        }
    }
}
