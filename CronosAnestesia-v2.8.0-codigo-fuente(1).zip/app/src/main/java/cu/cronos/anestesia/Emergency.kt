package cu.cronos.anestesia

// =====================================================================
//  MÓDULO DE EMERGENCIAS (Fase 1 del plan de adecuación)
//  Cumple el requisito 8.2 del contrato: escenarios críticos alcanzables
//  en 2 toques. ACLS, PALS, vía aérea difícil y LAST completan los
//  protocolos propios; anafilaxia e hipertermia maligna se incluye el
//  protocolo resumido y remiten a Complicaciones para el detalle.
//  Contenido: v2 (octubre 2026) — verificar contra protocolo institucional.
// =====================================================================

data class Emergency(
    val name: String,
    val subtitle: String,
    val category: String,
    val recognize: String,
    val steps: List<String>,
    val doses: List<String>,
    val warnings: String,
    val refs: String
)

val EMERGENCIES_RAW = listOf(
    // ------------------------------------------------------------------
    // 1. ACLS
    // ------------------------------------------------------------------
    Emergency(
        "Paro cardíaco (ACLS)",
        "Adulto perioperatorio · RCP de alta calidad",
        "Adulto",
        "Ausencia de pulso central y pérdida de conciencia. En quirófano: caída súbita y sostenida de EtCO2 (<10 mmHg), pérdida de onda pulsátil en PA invasiva, SpO2 ilegible, FV/TVSP, AESP o asistolia en el monitor. La capnografía es la mejor herramienta para confirmar intubación traqueal y la calidad de las compresiones.",
        listOf(
            "Declarar el paro en voz alta, llamar al equipo de reanimación y pedir el desfibrilador. Detener anestésicos: cerrar vaporizador y detener infusiones sedantes.",
            "O2 al 100% con flujo alto, ventilar con bolsa y reservorio. Asegurar vía aérea (tubo o mascarilla supraglótica) solo cuando sea posible sin interrumpir compresiones.",
            "Compresiones: centro del tórax, 5–6 cm de profundidad, 100–120/min, interrupciones <10 s. Con vía aérea avanzada: ventilación continua a 10/min sin pausas.",
            "Ritmo desfibrilable (FV/TVSP): shock bifásico 150–200 J de inmediato y reanudar compresiones al soltar. Segundo y siguientes shocks con la misma o mayor energía.",
            "Epinefrina 1 mg IV/IO cada 3–5 min. En FV/TVSP iniciar tras el 2.º shock fallido; en asistolia/AESP cuanto antes.",
            "Amiodarona 300 mg IV tras el 3.er shock, repetir 150 mg tras el 5.º. Alternativa: lidocaína 1–1,5 mg/kg y luego 0,5–0,75 mg/kg.",
            "Buscar causas reversibles 4H (hipoxia, hipovolemia, hipo/hiperpotasemia y otros trastornos metabólicos, hipotermia) y 4T (neumotórax a tensión, taponamiento, tóxicos/fármacos, tromboembolia).",
            "Específico perioperatorio: sangrado masivo (transfundir), neumotórax a tensión (descompresión con aguja 14 G en 2.º espacio), embolia (EtCO2 cae de golpe), anestésico local tóxico (lípidos), laparotomía abierta (masaje cardíaco directo, compresiones por debajo del diafragma o en prono invertidas a nivel T7–T10).",
            "RCE: cuidados postparo — presión arterial media ≥65 mmHg, SpO2 94–98%, control glucémico, control de temperatura (32–36 °C si comatoso) y traspaso a cuidados intensivos."
        ),
        listOf(
            "Epinefrina: 1 mg IV/IO (10 mL de 0,1 mg/mL) cada 3–5 min",
            "Amiodarona: 300 mg bolo, luego 150 mg; lidocaína 1–1,5 mg/kg",
            "Desfibrilación bifásica: 150–200 J (monofásica 360 J)",
            "Bolos de vasopresina/fenilefrina no sustituyen a la adrenalina",
            "Volumen si hipovolemia: cristaloides o sangre a chorro"
        ),
        "Minimizar interrupciones (<10 s): solo se pausa para shock y para verificar ritmo. La adrenalina IV solo en paro; fuera de paro se diluye y se titula. EtCO2 <10 mmHg tras 20 min confiere mal pronóstico pero no indica parar si hay otros signos. Mantener registro de tiempos y fármacos.",
        "AHA 2020 · ERC 2021 · Recomendaciones ASA/ERC del paro perioperatorio"
    ),
    // ------------------------------------------------------------------
    // 2. PALS
    // ------------------------------------------------------------------
    Emergency(
        "Paro cardíaco pediátrico (PALS)",
        "Niño y lactante · la hipoxia es la causa nº 1",
        "Pediátrico",
        "Niño sin respuesta, sin pulso central (carotídeo/femoral) o con <60 lpm asociado a mala perfusión: iniciar compresiones. En lactante usar pulso braquial. Causa más frecuente: hipoxia progresiva por insuficiencia respiratoria o shock compensado que decompensa. EtCO2 <10 mmHg indica compresiones inadecuadas.",
        listOf(
            "Llamar al equipo de reanimación pediátrica. O2 100% con bolsa de reservorio de tamaño apropiado. Comprimir: 1/3 del diámetro anteroposterior del tórax (4 cm lactante, 5 cm niño), 100–120/min, dos dedos (lactante) o dos manos en el esternón (niño).",
            "Ritmo desfibrilable (FV/TVSP): shock 2 J/kg al inicio, 4 J/kg en los siguientes (máx. 10 J/kg). Reanudar compresiones de inmediato.",
            "Epinefrina 0,01 mg/kg IV/IO (0,1 mL/kg de la presentación de 0,1 mg/mL) cada 3–5 min, máximo 1 mg. En FV/TVSP tras el 2.º shock.",
            "Acceso: intraóseo si no hay vía IV en 60 s. Volumen: cristaloides equilibrados 10–20 mL/kg en bolos; sangre si hay sangrado.",
            "Amiodarona 5 mg/kg IV/IO tras el 3.er shock; alternativa lidocaína 1 mg/kg.",
            "Medir glucemia: dextrosa 0,5–1 g/kg (2–5 mL/kg de D10) si <60 mg/dL. Corregir calcio e iones según gasometría.",
            "Si el ritmo es de paro por hipoxia (asistolia/bradicardia extrema): asegurar vía aérea y ventilación eficaz ANTES que fármacos; la mayoría responde a oxigenación + compresiones.",
            "RCE: evitar hiperoxia (SpO2 94–98%), normocapnia, presión arterial de acuerdo con la edad, temperatura controlada y traslado a intensivos pediátricos."
        ),
        listOf(
            "Epinefrina IV/IO: 0,01 mg/kg (0,1 mL/kg de 0,1 mg/mL) c/3–5 min, máx. 1 mg",
            "Desfibrilación: 2 J/kg → 4 J/kg → 4 J/kg (máx. 10 J/kg)",
            "Amiodarona 5 mg/kg · lidocaína 1 mg/kg",
            "Cristaloides 10–20 mL/kg por bolo",
            "Dextrosa 10%: 2–5 mL/kg si hipoglucemia"
        ),
        "Nunca usar dosis de adulto. Peso estimado = (edad × 2) + 8 kg (2–12 años) o usar cinta/brazaletes de reanimación. La atropina ya no se recomienda de rutina en el paro pediátrico. Sospechar hiperpotasemia ante hemólisis, traumatismo aplastante o insuficiencia renal: tratar con calcio + insulina/glucosa. En la muerte súbita infantil considerar causas ocultas (trauma no accidental, intoxicación).",
        "PALS/AHA 2020 · ERC 2021 · Guía pediátrica institucional"
    ),
    // ------------------------------------------------------------------
    // 3. Anafilaxia
    // ------------------------------------------------------------------
    Emergency(
        "Anafilaxia perioperatoria",
        "Adrenalina IM temprana + volumen agresivo",
        "Reacción",
        "Bajo anestesia la presentación más común es HIPOTENSIÓN SÚBITA + BRONCOESPASMO, con o sin erupción. Otros: taquicardia, caída de EtCO2, flush, urticaria, angioedema. Desencadenantes típicos: antibióticos (β-lactámicos), relajantes neuromusculares (incluida succinilcolina), látex, clorhexidina, colorantes (azul de metileno), AINE/opioides como cofactores.",
        listOf(
            "Suspender el fármaco sospechoso y reducir/anular los anestésicos si hay hipotensión grave. Llamar ayuda. O2 100% y aumentar la ventilación manual si hay broncoespasmo.",
            "ADRENALINA IM 0,5 mg (0,5 mL de 1 mg/mL) en el cuádriceps; repetir cada 5 min según respuesta. En niños 0,01 mg/kg IM, máx. 0,5 mg.",
            "Volumen agresivo: cristaloides 20–30 mL/kg en bolos (frecuentemente hacen falta 2–4 L: hay fuga capilar masiva y el paciente queda hipovolémico).",
            "Hipotensión refractaria: adrenalina IV en infusión 0,05–0,1 µg/kg/min o bolos titulados de 50–100 µg en adultos (1–5 µg/kg en niños). Añadir noradrenalina como vasopresor de apoyo.",
            "Broncoespasmo persistente: salbutamol inhalado/nebulizado; la adrenalina también actúa como broncodilatador. Aminofilina opcional.",
            "Segunda línea (NUNCA primera): clorfenamina 10 mg IV (adultos) o cetirizina; hidrocortisona 200 mg IV. Los antihistamínicos no tratan la hipotensión.",
            "Antes del alta: extraer muestra de triptasa sérica a los 30–120 min del inicio; remitir a estudio de alergia en 4–6 semanas (prick/ID) y entregar tarjeta de alerta. Vigilar reacción bifásica 1–20 h tras la mejoría.",
            "Etiquetar la sospecha en la historia y reportar el caso (farmacovigilancia)."
        ),
        listOf(
            "Adrenalina IM: 0,5 mg adulto · 0,01 mg/kg en niños (máx. 0,5 mg)",
            "Adrenalina IV refractaria: 0,05–0,1 µg/kg/min o bolos de 50–100 µg",
            "Cristaloides: 20–30 mL/kg",
            "Hidrocortisona 200 mg IV · clorfenamina 10 mg IV (adulto)",
            "Salbutamol nebulizado 2,5–5 mg si broncoespasmo"
        ),
        "La adrenalina tardía o insuficiente es el error más letal. Fuera de paro NO administrar bolos IV de 0,5–1 mg sin diluir (arritmias, isquemia): usar diluciones de 10 µg/mL o vía IM. El bloqueo neuraxial puede enmascarar el flush y amplificar la hipotensión. En cesárea, la madre estable es la mejor protección fetal.",
        "ERC 2021 · RCoA/NICE Anaphylaxis Guideline 2021 · ASRA · Ver también Complicaciones → Anafilaxia"
    ),
    // ------------------------------------------------------------------
    // 4. Hipertermia maligna
    // ------------------------------------------------------------------
    Emergency(
        "Hipertermia maligna",
        "Dantroleno inmediato · la fiebre llega TARDE",
        "Metabólico",
        "↑ EtCO2 inexplicable (>55 mmHg pese a aumentar ventilación) — el signo más temprano y fiable; taquicardia, rigidez de maseteros o generalizada, acidosis respiratoria + metabólica, hiperpotasemia, mioglobinuria, temperatura >39 °C solo de forma tardía. Gatillos: halogenados y succinilcolina. También puede desencadenarse sin gatillos claros (estrés, calor, ejercicio).",
        listOf(
            "PARAR los gatillos: retirar el vaporizador y NO administrar más succinilcolina. Pedir en voz alta el dantroleno (cuantos frascos haya) y llamar al equipo MH. Nombrar a alguien para preparar el fármaco.",
            "Hiperventilar con O2 100% y flujo alto (≥10 L/min). Cambiar el circuito/caldera o colocar filtro nuevo; nunca reutilizar el circuito contaminado.",
            "DANTROLENO 2,5 mg/kg IV en bolo rápido y repetir cada 5–10 min hasta controlar EtCO2, rigidez y acidosis. Continuar hasta 10 mg/kg; si la crisis persiste, hasta 20 mg/kg. (Ryanodex 250 mg/5 mL se reconstituye más rápido que Revonto 20 mg/mL).",
            "Tratar la hiperpotasemia: CaCl2 10 mg/kg (o gluconato 30 mg/kg), insulina regular 0,1 U/kg + glucosa 0,5 g/kg, bicarbonato 1–2 mmol/kg. El K rebota: repetir gasometría cada 10–15 min.",
            "Enfriar si T >39 °C: suero frío IV 20–30 mL/kg, lavado gástrico/vesical, hielo en pliegues. DETENER el enfriamiento al llegar a 38 °C (no hipotermia).",
            "Monitorizar: gasometría cada 15 min, potasio, CK (puede >10 000 U/L), coagulación (CID), diuresis >2 mL/kg/h (el dantroleno lleva manitol); vigilar insuficiencia renal.",
            "Terapia de continuación: dantroleno 1 mg/kg cada 4–6 h (o infusión 0,25 mg/kg/h) durante 24–48 h en UCI. La recidiva ocurre en ~25% de los casos.",
            "Al alta: consejo genético y prueba de mutación (RYR1/CACNA1S) para el paciente y la familia; brazaletes de alerta médica; registrar en la historia."
        ),
        listOf(
            "Dantroleno: 2,5 mg/kg IV bolo, repetir hasta 10 mg/kg (máx. 20 mg/kg)",
            "CaCl2 10–20 mg/kg · insulina 0,1 U/kg + glucosa 0,5 g/kg",
            "Bicarbonato 1–2 mmol/kg",
            "Reconstituir con AGUA DESTILADA (nunca salino en Revonto)",
            "Continuación: 1 mg/kg c/4–6 h × 24–48 h"
        ),
        "La temperatura es un criterio tardío: NO esperarla para iniciar tratamiento. Una crisis abortada no está resuelta. Con dantroleno disponible la mortalidad es <5%; sin él supera el 70%. Confirmar la existencia de dantroleno en la dotación del quirófano ANTES de cada jornada con pacientes MH-susceptibles o familiares de primer grado.",
        "MHAUS · Protocolo MH de la SEDAR/REDACOM · Ver también Complicaciones → Hipertermia maligna"
    ),
    // ------------------------------------------------------------------
    // 5. LAST
    // ------------------------------------------------------------------
    Emergency(
        "Toxicidad por anestésicos locales (LAST)",
        "Lípidos 20% · no esperar el paro",
        "Toxicidad",
        "Síntomas centrales: zumbido, gusto metálico, perioral, agitación → convulsiones tónico-clónicas. Cardiovascular: taquicardia/HTA inicial → bradicardia, hipotensión, FV/TVSP, asistolia o paro resistente. Puede presentar solo síntomas cardíacos y de inicio TARDÍO (hasta 30–60 min tras la inyección). Riesgo ↑: inyección intravascular, bloqueos plexo/intercostales, dosis elevadas, embarazo, hepatopatía, edad avanzada.",
        listOf(
            "PARAR la inyección y pedir ayuda. Anunciar \"sospecha de LAST\" y conseguir la emulsión lipídica 20% (intralipid) y el equipo de reanimación.",
            "Convulsiones: benzodiacepina (midazolam 1–2 mg IV). Evitar propofol en dosis altas (deprime el gasto cardíaco).",
            "Signos graves (arritmia, hipotensión, depresión del sensorio): LÍPIDOS DE INMEDIATO sin esperar el paro — bolo 1,5 mL/kg de emulsión 20% en >1 min; infusión 0,25 mL/kg/min.",
            "Si el paciente sigue inestable: repetir el bolo y duplicar la infusión a 0,5 mL/kg/min. Máximo total 10–12 mL/kg en la primera media hora.",
            "Paro o arritmia grave: RCP estándar con RCP prolongada (≥1 hora si hace falta: la recuperación con lípidos tarda más). Desfibrilar con energías normales.",
            "Adrenalina en dosis MENORES que las estándar: bolos <1 µg/kg (evitar 1 mg). Evitar bloqueadores de calcio, B-bloqueantes, vasopresina y lidocaína como antiarrítmico.",
            "Si no responde: considerar oxigenación por membrana extracorpórea (ECMO) o circulación extracorpórea; activar el protocolo con antelación.",
            "Vigilar 4–6 h en monitorización continua aunque mejore (los síntomas pueden recidivar). Comunicar el caso y revisar la técnica/dosis que causó el evento."
        ),
        listOf(
            "Emulsión lipídica 20%: bolo 1,5 mL/kg (~100 mL en adulto de 70 kg)",
            "Infusión: 0,25 mL/kg/min (0,5 mL/kg/min si inestable)",
            "Máximo: 10–12 mL/kg en 30 min",
            "Midazolam 1–2 mg IV para convulsiones",
            "Adrenalina en paro por LAST: bolos ≤1 µg/kg"
        ),
        "El paro por LAST es más largo que el habitual: continuar RCP ≥1 h. La mitad de los casos se inicia 1–5 min tras la inyección, pero hasta 40% aparece después de 5 min: la vigilancia post-inyección 30 min es obligatoria. Aspirar antes de inyectar y fraccionar la dosis con marcado del espacio reduce el riesgo.",
        "ASRA/ESRA Checklist LAST 2020 (Neal, Barron) · AAGBI Safety Guideline · Ver Calculadoras → Anestésico local para dosis máximas"
    ),
    // ------------------------------------------------------------------
    // 6. Vía aérea difícil
    // ------------------------------------------------------------------
    Emergency(
        "Vía aérea difícil / CICO",
        "Planes A–D · declarar y oxigenar siempre",
        "Vía aérea",
        "Ventilación con máscara imposible + laringoscopia fallida (Cormack-Lehane 3–4) con desaturación. Factores de riesgo: Mallampati ≥3, apertura <3 cm, distancia tiromentoniana <6 cm, micrognatia, barba, radioterapia de cuello, edema (angioedema, quemadura, infección), OSA, obesidad, embarazo. Declarar \"VÍA AÉREA DIFÍCIL\" en voz alta y pedir ayuda.",
        listOf(
            "ANUNCIAR y pedir ayuda experta. OXIGENAR SIEMPRE en cada paso: O2 de alto flujo por sonda nasal o vía supraglótica mientras se intenta otra cosa.",
            "PLAN A: optimizar la laringoscopia — posición (orejas a nivel del esternón), báscula externa de la laringe, videolaringoscopio, estilete/hidrofiado. Máximo 2–3 intentos; reoxigenar con mascarilla supraglótica entre intentos.",
            "PLAN B: mascarilla supraglótica de 2.ª generación (i-gel, LMA ProSeal). Si ventila: decidir con calma entre despertar, intubar a través de la SGA o anestesia con SGA.",
            "PLAN C: recuperación de la ventilación con máscara — vía oral + nasal, máscara con dos manos, parálisis completa si no existe, posición lateral si regurgita, PEEP y maniobras. Si no hay oxigenación ni con SGA → PLAN D sin demora.",
            "PLAN D (CICO: can't intubate, can't oxygenate): acceso quirúrgico al frente del cuello — cricotiroidotomía con bisturí (DAS): identificar membrana cricotiroidea, incisión vertical de piel + transversa de membrana, avanzar tubo ≤6.0 con fiador. Paliativo en <1 min desde la decisión.",
            "Recuperación: si el paciente desatura de forma peligrosa durante los intentos, DESPERTARLO (a menos que ya esté en paro) y planificar vía aérea electiva (despierto, fibroscopia, quirófano).",
            "Documentar la técnica fallida y exitosa, colocar alerta/brazalete de vía aérea difícil y notificar a la familia. Considerar registro local de vía aérea difícil."
        ),
        listOf(
            "Suxametonio 1–1,5 mg/kg IV para reintentos de intubación urgente",
            "Rocuronio 1,2 mg/kg si se prefiere no despolarizante (recuerda: 45–60 min, rescate con sugammadex 16 mg/kg)",
            "Cricotiroidotomía: tubo ≤6.0 con fiador; en pediatría punción con aguja 14 G y oxigenación transtraqueal (evitar lesión del cartílago)",
            "O2 nasal 15 L/min continuo durante todos los intentos"
        ),
        "Cada intento fallido empeora el siguiente (sangrado, edema, sangre en la vía). Regla: 3 intentos de laringoscopia + 1 SGA fallida = PLAN D. Nunca dejar al paciente sin oxígeno mientras se decide. En obesidad y embarazo la desaturación es más rápida: preoxigenar bien y anticipar el equipo quirúrgico de cuello abierto en la mesa.",
        "DAS 2015 (Frerk et al.) · ASA 2022 Difficult Airway · 4.ª National Audit (NAP4)"
    )
)
