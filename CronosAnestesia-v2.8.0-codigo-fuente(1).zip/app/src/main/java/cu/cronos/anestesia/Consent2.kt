package cu.cronos.anestesia

import android.content.Context

// =====================================================================
//  CONSENTIMIENTOS INFORMADOS v2.3.0 (amplía Consent.kt de v2.0.0)
//  · 4 plantillas: Anestesia (la original de Consent.kt), Transfusión de
//    hemoderivados, Analgesia del parto (neuraxial obstétrica) y
//    Sedación para procedimientos.
//  · Editables: el anestesiólogo puede añadir riesgos particulares y
//    cláusulas adicionales a cada plantilla, y guardar sus datos de
//    identificación (institución, servicio, nombre) como valores por
//    defecto. Todo se conserva en el teléfono (SharedPreferences + JSON).
//  · Modo lectura: el documento completo se puede leer en pantalla antes
//    de exportar el PDF (mismo motor de Expediente.writePdf).
//  · 100 % offline; sin permiso INTERNET (contrato R-01).
// =====================================================================

/** Datos editables por plantilla, persistidos en el dispositivo. */
data class ConsentEditData(
    val risks: List<String> = emptyList(),   // riesgos particulares añadidos
    val clauses: String = "",                // cláusulas adicionales (texto libre)
    val institution: String = "",
    val service: String = "",
    val anesthesiologist: String = ""
)

/** Almacén de ediciones de consentimiento (JSON en SharedPreferences). */
object ConsentEditStore {
    private const val PREFS = "consent_edits"

    fun load(ctx: Context, templateId: String): ConsentEditData {
        val s = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(templateId, "") ?: ""
        return if (s.isBlank()) ConsentEditData() else fromJson(s)
    }

    fun save(ctx: Context, templateId: String, d: ConsentEditData) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(templateId, toJson(d)).apply()
    }

    fun clear(ctx: Context, templateId: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().remove(templateId).apply()
    }

    // ---------- serialización pura (testeable, sin org.json) ----------
    // Formato CE1: campos separados por «|», con escape de %, | y saltos de
    // línea para que el texto libre nunca rompa la estructura:
    // CE1|cláusulas|institución|servicio|anestesiólogo|riesgo1\nriesgo2…
    private fun esc(s: String): String =
        s.replace("%", "%25").replace("|", "%7C").replace("\n", "%0A").replace("\r", "")

    private fun unesc(s: String): String =
        s.replace("%0A", "\n").replace("%7C", "|").replace("%25", "%")

    fun toJson(d: ConsentEditData): String =
        listOf("CE1", d.clauses, d.institution, d.service, d.anesthesiologist, d.risks.joinToString("\n"))
            .joinToString("|") { esc(it) }

    fun fromJson(s: String): ConsentEditData {
        if (!s.startsWith("CE1|")) return ConsentEditData()
        val parts = s.split("|").map { unesc(it) }
        if (parts.size < 6) return ConsentEditData()
        return ConsentEditData(
            clauses = parts[1],
            institution = parts[2],
            service = parts[3],
            anesthesiologist = parts[4],
            risks = parts[5].split("\n").filter { it.isNotBlank() }
        )
    }

    /** Bloque común con los riesgos/cláusulas añadidas por el profesional. */
    fun applyEdits(
        blocks: MutableList<Triple<String, Int, String>>,
        edit: ConsentEditData,
        nextSection: Int
    ) {
        if (edit.risks.isNotEmpty()) {
            blocks.add(Triple("Riesgos particulares añadidos por el anestesiólogo", 1, ""))
            blocks.add(Triple(edit.risks.joinToString("\n") { "•  $it" }, 2, ""))
        }
        if (edit.clauses.isNotBlank()) {
            blocks.add(Triple("Cláusulas adicionales acordadas con el paciente", 1, ""))
            blocks.add(Triple(edit.clauses, 2, ""))
        }
    }
}

/** Plantillas de consentimiento disponibles (v2.3.0). */
object ConsentTemplates {

    const val ANESTESIA = "anestesia"
    const val TRANSFUSION = "transfusion"
    const val PARTO = "parto"
    const val SEDACION = "sedacion"

    val ALL = listOf(ANESTESIA, TRANSFUSION, PARTO, SEDACION)

    fun title(id: String): String = when (id) {
        ANESTESIA -> "Anestesia"
        TRANSFUSION -> "Transfusión de hemoderivados"
        PARTO -> "Analgesia del parto"
        SEDACION -> "Sedación para procedimientos"
        else -> "Consentimiento"
    }

    // ---------------------------------------------------------------
    //  TRANSFUSIÓN DE HEMODERIVADOS
    // ---------------------------------------------------------------
    fun buildTransfusion(
        edit: ConsentEditData,
        patient: Patient,
        anesthesiologist: String,
        institution: String,
        service: String,
        procedure: String,
        components: String,
        reason: String,
        date: String
    ): List<Triple<String, Int, String>> = buildList {
        add(Triple("CONSENTIMIENTO INFORMADO PARA TRANSFUSIÓN DE HEMODERIVADOS", 0, ""))
        add(Triple(
            "Marco legal y ético. Yo, como paciente (o su representante legal), ejerzo mi derecho a recibir información veraz, completa y comprensible sobre la transfusión de sangre o de sus componentes propuesta, y a otorgar o negar mi consentimiento de forma libre y voluntaria, conforme a la Ley No. 156 «De la Salud Pública» de la República de Cuba, el Código de Ética Médica y los principios de la Organización Mundial de la Salud sobre el uso clínico apropiado de la sangre. La decisión de aceptar o rechazar la transfusión no afectará la calidad ni la dignidad de mi atención.",
            2, ""
        ))
        add(Triple("1. IDENTIFICACIÓN DEL PACIENTE", 1, ""))
        add(Triple(
            "Nombre y apellidos: ${patient.name.ifBlank { "___________" }}\n" +
                "Carné de identidad: ${patient.ci.ifBlank { "___________" }}\n" +
                "Edad: ${patient.age.ifBlank { "____" }} años    Sexo: ${patient.sex.ifBlank { "____" }}\n" +
                "Grupo sanguíneo y Rh: ____________    Antecedentes de interés: ${patient.hx.ifBlank { "____________________________________" }}",
            2, ""
        ))
        add(Triple("2. IDENTIFICACIÓN DEL PROFESIONAL Y DE LA INSTITUCIÓN", 1, ""))
        add(Triple(
            "Institución: ${institution.ifBlank { "___________" }}\n" +
                "Servicio: ${service.ifBlank { "___________" }}\n" +
                "Médico responsable de la transfusión: ${anesthesiologist.ifBlank { "___________" }}\n" +
                "Fecha: $date",
            2, ""
        ))
        add(Triple("3. PROCEDIMIENTO PROPUESTO", 1, ""))
        add(Triple(
            "Motivo clínico (cirugía, hemorragia, anemia u otra condición): ${reason.ifBlank { "___________" }}\n" +
                "Procedimiento relacionado: ${procedure.ifBlank { "___________" }}\n" +
                "Hemocomponentes propuestos y cantidad aproximada: ${components.ifBlank { "___________" }}\n\n" +
                "La transfusión consiste en administrar por vía intravenosa sangre o componentes separados de la sangre (concentrado de glóbulos rojos, plasma fresco congelado, concentrado de plaquetas, crioprecipitado) obtenidos de donantes voluntarios. Toda la sangre donada se somete a análisis serológicos obligatorios de laboratorio para detectar infecciones transmisibles, y se verifica la compatibilidad entre el donante y el paciente mediante pruebas de laboratorio antes de cada transfusión.",
            2, ""
        ))
        add(Triple("4. BENEFICIOS ESPERADOS", 1, ""))
        add(Triple(
            "Restablecer o mantener la capacidad de la sangre para transportar oxígeno, corregir los defectos de la coagulación o reponer la pérdida de volumen por sangrado, con el fin de reducir el riesgo de daño a los órganos y de muerte asociado a la anemia o a la hemorragia. La transfusión se indica solo cuando el beneficio esperado supera el riesgo, siguiendo criterios restrictivos y todas las alternativas disponibles para minimizar su uso.",
            2, ""
        ))
        add(Triple("5. RIESGOS Y COMPLICACIONES POSIBLES", 1, ""))
        add(Triple(
            "A pesar del análisis obligatorio de la sangre donada y de las pruebas de compatibilidad, toda transfusión conlleva riesgos que se describen a continuación.",
            2, ""
        ))
        add(Triple(
            "•  Reacciones febriles no hemolíticas y reacciones alérgicas (urticaria, erupción): las más frecuentes, habitualmente leves y tratadas en el momento.\n" +
                "•  Reacción hemolítica aguda por incompatibilidad (destrucción de los glóbulos transfundidos): muy rara con las pruebas de compatibilidad; puede ser grave.\n" +
                "•  Reacción hemolítica tardía y aloinmunización (formación de anticuerpos contra glóbulos rojos ajenos): puede complicar transfusiones o embarazos futuros.\n" +
                "•  Sobrecarga circulatoria (TACO): dificultad respiratoria por exceso de volumen, especialmente en adultos mayores o con insuficiencia cardíaca.\n" +
                "•  Lesión pulmonar aguda relacionada con la transfusión (TRALI): dificultad respiratoria por reacción inmunitaria, poco frecuente, una de las causas principales de mortalidad asociada a la transfusión.\n" +
                "•  Transmisión de infecciones (virus de la inmunodeficiencia humana, hepatitis B y C, sífilis, enfermedad de Chagas y otras): el riesgo residual es extremadamente bajo gracias al análisis serológico obligatorio de cada donación, pero no puede reducirse a cero.\n" +
                "•  Inmunomodulación y aumento de la susceptibilidad a infecciones asociadas a la transfusión múltiple.\n" +
                "•  Sobrecarga de hierro con transfusiones repetidas crónicas.\n" +
                "•  Enfermedad injerto contra huésped asociada a la transfusión (excepcional; se previene irradiando los componentes en pacientes inmunodeprimidos seleccionados).",
            2, ""
        ))
        add(Triple("6. ALTERNATIVAS PARA EVITAR O REDUCIR LA TRANSFUSIÓN", 1, ""))
        add(Triple(
            "•  Tratamiento previo de la anemia con hierro (oral o intravenoso) y, en casos seleccionados, agentes estimulantes de la eritropoyesis.\n" +
                "•  Extracción y recuperación de la propia sangre del paciente (autotransfusión programada, recuperación intraoperatoria de sangre derramada con celda de salvamento cuando esté disponible).\n" +
                "•  Hemodilución aguda normovolémica y anestesia que reduce el sangrado (técnica hipotensa controlada cuando proceda).\n" +
                "•  Uso de fármacos hemostáticos (ácido tranexámico) y de un manejo riguroso de la hemostasia quirúrgica y de la temperatura.\n" +
                "•  Umbrales transfusionales restrictivos avalados por la evidencia (transfundir solo si la concentración de hemoglobina lo justifica y hay signos de intolerance).\n" +
                "•  La alternativa de NO recibir la transfusión, con las consecuencias que el especialista me ha explicado y que quedan registradas.",
            2, ""
        ))
        add(Triple("7. DERECHOS DEL PACIENTE", 1, ""))
        add(Triple(
            "•  Recibir toda la información que solicite y hacer las preguntas que considere necesarias antes de firmar.\n" +
                "•  Rechazar la transfusión o retirar el consentimiento en cualquier momento, dejándolo constancia escrita en la historia clínica.\n" +
                "•  Solicitar una segunda opinión sobre la indicación de transfusión.\n" +
                "•  Que se respeten sus convicciones religiosas o personales, documentando conjuntamente con el equipo las alternativas aceptadas.",
            2, ""
        ))
        add(Triple("8. DECLARACIÓN Y AUTORIZACIÓN", 1, ""))
        add(Triple(
            "Declaro que he leído (o me ha sido leído) este documento, que comprendo su contenido, que se me ha explicado el motivo de la transfusión propuesta, sus riesgos, beneficios y alternativas, y que se han respondido todas mis preguntas. Autorizo de forma libre y expresa la transfusión de los hemocomponentes descritos y las medidas concomitantes necesarias (canalización venosa, pruebas de compatibilidad, vigilancia durante y después de la transfusión).",
            2, ""
        ))
        add(Triple("9. FIRMAS", 1, ""))
        add(Triple(
            "Paciente (o representante legal)\n\nNombre: ______________________    CI: ____________________\n\nFirma: ______________________    Fecha y hora: __________________\n\n" +
                "Médico responsable\n\nNombre: ${anesthesiologist.ifBlank { "______________________" }}    CI: ____________________\n\nFirma: ______________________    Fecha y hora: __________________\n\n" +
                "Testigo\n\nNombre: ______________________    CI: ____________________\n\nFirma: ______________________    Fecha y hora: __________________",
            2, ""
        ))
        add(Triple(
            "El original se archiva en la historia clínica y se entrega copia al paciente. Documento generado por la aplicación Cronos Anestesia como apoyo a la práctica clínica; su validez formal se ajusta a la normativa vigente de la institución.",
            2, ""
        ))
        ConsentEditStore.applyEdits(this, edit, 10)
    }

    // ---------------------------------------------------------------
    //  ANALGESIA DEL PARTO (NEURAXIAL OBSTÉTRICA)
    // ---------------------------------------------------------------
    fun buildParto(
        edit: ConsentEditData,
        patient: Patient,
        anesthesiologist: String,
        institution: String,
        service: String,
        technique: String,
        risksExtra: String,
        date: String
    ): List<Triple<String, Int, String>> = buildList {
        add(Triple("CONSENTIMIENTO INFORMADO PARA ANALGESIA DEL PARTO (TÉCNICA NEURAXIAL)", 0, ""))
        add(Triple(
            "Marco legal y ético. Yo, como paciente (o su representante legal), ejerzo mi derecho a recibir información veraz, completa y comprensible sobre la analgesia del parto propuesta, y a otorgar o negar mi consentimiento de forma libre y voluntaria, conforme a la Ley No. 156 «De la Salud Pública» de la República de Cuba, el Código de Ética Médica y los principios de la Declaración de Helsinki de la Asociación Médica Mundial. El consentimiento puede otorgarse durante el trabajo de parto y puede retirarse en cualquier momento.",
            2, ""
        ))
        add(Triple("1. IDENTIFICACIÓN DE LA PACIENTE", 1, ""))
        add(Triple(
            "Nombre y apellidos: ${patient.name.ifBlank { "___________" }}\n" +
                "Carné de identidad: ${patient.ci.ifBlank { "___________" }}\n" +
                "Edad: ${patient.age.ifBlank { "____" }} años    Gestaciones: ____    Partos previos: ____\n" +
                "Embarazo de: ____ semanas    Antecedentes de interés: ${patient.hx.ifBlank { "____________________________________" }}",
            2, ""
        ))
        add(Triple("2. IDENTIFICACIÓN DEL PROFESIONAL Y DE LA INSTITUCIÓN", 1, ""))
        add(Triple(
            "Institución: ${institution.ifBlank { "___________" }}\n" +
                "Servicio: ${service.ifBlank { "___________" }}\n" +
                "Anestesiólogo responsable: ${anesthesiologist.ifBlank { "___________" }}\n" +
                "Fecha: $date",
            2, ""
        ))
        add(Triple("3. DESCRIPCIÓN DEL PROCEDIMIENTO PROPUESTO", 1, ""))
        add(Triple(
            "Técnica propuesta: $technique.\n\n" +
                "La analgesia neuraxial del parto consiste en colocar un catéter o aguja en el espacio epidural (o en el espacio subaracnoideo, según la técnica) de la espalda baja, para administrar medicación que bloquea la sensibilidad del dolor del abdomen y del periné manteniendo el movimiento y la conciencia. Alivia el dolor del parto de forma más eficaz que cualquier otra medida disponible, permite descansar durante el trabajo de parto y puede intensificarse si se requiere una cesárea u otro procedimiento obstétrico. La colocación se realiza con asepsia y monitorización, y la dosis se ajusta para minimizar la debilidad de las piernas y el efecto sobre el impulso de pujar.",
            2, ""
        ))
        add(Triple("4. RIESGOS Y COMPLICACIONES POSIBLES", 1, ""))
        add(Triple(
            "•  Caída de la presión arterial que puede afectar el flujo hacia el bebé: se previene con líquidos, posición lateral y fármacos vasoconstrictores seguros en el embarazo, y se vigila de forma continua.\n" +
                "•  Alivio incompleto del dolor o bloqueo de un solo lado: puede requerir recolocar el catéter o cambiar de técnica.\n" +
                "•  Cefalea postpunción dural (escape de líquido cefalorraquídeo): aparece en una proporción pequeña de casos cuando se punciona accidentalmente la dura; puede requerir reposo, analgesia o un sello epidural con sangre.\n" +
                "•  Prurito, escalofríos, náuseas, fiebre leve y dificultad para orinar (habitualmente transitorios).\n" +
                "•  Alargamiento leve de la segunda etapa del parto y mayor probabilidad de uso de instrumentos (fórceps o ventosa), según la dosis y el momento de administración.\n" +
                "•  Dolor en el sitio de punción o molestia lumbar transitoria (la analgesia epidural no causa dolor lumbar crónico: el embarazo y el parto sí se asocian a él con la misma frecuencia con o sin epidural).\n" +
                "•  Lesión neurológica (pérdida de sensibilidad o de fuerza persistente): excepcional; la mayoría de las neuropatías del parto se deben al propio parto y no a la anestesia.\n" +
                "•  Hematoma o absceso epidural (complicación muy grave y muy rara): puede comprimir la médula y exigir cirugía urgente; se revisan las pruebas de coagulación y los antecedentes antes de puncionar.\n" +
                "•  Toxicidad sistémica por anestésico local (LAST): convulsiones o arritmias por inyección intravascular accidental; es rara y existe protocolo de tratamiento con lípidos.\n" +
                "•  Bloqueo alto o total (extremadamente raro): puede afectar la respiración y requerir anestesia general de urgencia.\n" +
                "•  Efecto sobre el bebé: la medicación pasa al bebé en cantidad mínima; puede observarse una pequeña variación del registro cardíaco fetal, que el equipo vigila de forma continua.\n" +
                "•  Si la analgesia falla o se requiere cesárea urgente, puede ser necesaria una nueva técnica o una anestesia general, con sus propios riesgos.",
            2, ""
        ))
        if (risksExtra.isNotBlank()) {
            add(Triple("Riesgos particulares comunicados por el anestesiólogo", 1, ""))
            add(Triple(risksExtra, 2, ""))
        }
        add(Triple("5. BENEFICIOS ESPERADOS", 1, ""))
        add(Triple(
            "Alivio eficaz y continuo del dolor del parto, con la madre despierta y participativa, menor consumo de oxígeno y mejor tolerancia al trabajo de parto, posibilidad de descansar y de intensificar la analgesia para una cesárea sin anestesia general cuando sea posible, y mejor experiencia del nacimiento.",
            2, ""
        ))
        add(Triple("6. ALTERNATIVAS DISPONIBLES", 1, ""))
        add(Triple(
            "•  Analgesia sistémica con fármacos (opioides) por vía intravenosa o intramuscular: alivio parcial, con paso mayor de medicación al bebé y somnolencia.\n" +
                "•  Técnicas de apoyo no farmacológico: respiración, masaje, apoyo continuo, posición, baños tibios y bloqueos de nervio periféricos en momentos concretos del parto.\n" +
                "•  Gas entonador (óxido nitroso al 50 %) cuando la institución lo tenga disponible.\n" +
                "•  No realizar analgesia, con la posibilidad de solicitarla en cualquier momento posterior del parto.",
            2, ""
        ))
        add(Triple("7. DERECHOS DE LA PACIENTE", 1, ""))
        add(Triple(
            "•  Recibir toda la información que solicite y hacer las preguntas que considere necesarias antes de aceptar.\n" +
                "•  Retirar el consentimiento en cualquier momento, sin que ello afecte la calidad de la atención.\n" +
                "•  Ser atendida con respeto a su plan de parto y a la presencia de su acompañante, según las normas de la institución.\n" +
                "•  Recibir información clara de cada paso del procedimiento durante su realización.",
            2, ""
        ))
        add(Triple("8. DECLARACIÓN Y AUTORIZACIÓN", 1, ""))
        add(Triple(
            "Declaro que he leído (o me ha sido leído) este documento, que comprendo su contenido, que se me ha explicado la técnica de analgesia propuesta, sus riesgos, beneficios y alternativas, y que se han respondido todas mis preguntas. Autorizo de forma libre y expresa la realización del procedimiento descrito y las medidas concomitantes que requiera (canalización venosa, monitorización de la madre y del bebé, administración de líquidos y fármacos, y la conversión a anestesia general o cesárea si la situación clínica lo exige).",
            2, ""
        ))
        add(Triple("9. FIRMAS", 1, ""))
        add(Triple(
            "Paciente\n\nNombre: ______________________    CI: ____________________\n\nFirma: ______________________    Fecha y hora: __________________\n\n" +
                "Anestesiólogo responsable\n\nNombre: ${anesthesiologist.ifBlank { "______________________" }}    CI: ____________________\n\nFirma: ______________________    Fecha y hora: __________________\n\n" +
                "Testigo\n\nNombre: ______________________    CI: ____________________\n\nFirma: ______________________    Fecha y hora: __________________",
            2, ""
        ))
        add(Triple(
            "El original se archiva en la historia clínica y se entrega copia a la paciente. Documento generado por la aplicación Cronos Anestesia como apoyo a la práctica clínica; su validez formal se ajusta a la normativa vigente de la institución.",
            2, ""
        ))
        ConsentEditStore.applyEdits(this, edit, 10)
    }

    // ---------------------------------------------------------------
    //  SEDACIÓN PARA PROCEDIMIENTOS
    // ---------------------------------------------------------------
    fun buildSedacion(
        edit: ConsentEditData,
        patient: Patient,
        anesthesiologist: String,
        institution: String,
        service: String,
        procedure: String,
        risksExtra: String,
        date: String
    ): List<Triple<String, Int, String>> = buildList {
        add(Triple("CONSENTIMIENTO INFORMADO PARA SEDACIÓN EN PROCEDIMIENTOS", 0, ""))
        add(Triple(
            "Marco legal y ético. Yo, como paciente (o su representante legal), ejerzo mi derecho a recibir información veraz, completa y comprensible sobre la sedación propuesta para el procedimiento indicado, y a otorgar o negar mi consentimiento de forma libre y voluntaria, conforme a la Ley No. 156 «De la Salud Pública» de la República de Cuba, el Código de Ética Médica y los principios de la Declaración de Helsinki de la Asociación Médica Mundial.",
            2, ""
        ))
        add(Triple("1. IDENTIFICACIÓN DEL PACIENTE", 1, ""))
        add(Triple(
            "Nombre y apellidos: ${patient.name.ifBlank { "___________" }}\n" +
                "Carné de identidad: ${patient.ci.ifBlank { "___________" }}\n" +
                "Edad: ${patient.age.ifBlank { "____" }} años    Sexo: ${patient.sex.ifBlank { "____" }}\n" +
                "Peso: ${patient.weightKg.ifBlank { "____" }} kg    Antecedentes médicos declarados: ${patient.hx.ifBlank { "____________________________________" }}",
            2, ""
        ))
        add(Triple("2. IDENTIFICACIÓN DEL PROFESIONAL Y DE LA INSTITUCIÓN", 1, ""))
        add(Triple(
            "Institución: ${institution.ifBlank { "___________" }}\n" +
                "Servicio: ${service.ifBlank { "___________" }}\n" +
                "Profesional responsable de la sedación: ${anesthesiologist.ifBlank { "___________" }}\n" +
                "Fecha: $date",
            2, ""
        ))
        add(Triple("3. DESCRIPCIÓN DEL PROCEDIMIENTO PROPUESTO", 1, ""))
        add(Triple(
            "Procedimiento a realizar: ${procedure.ifBlank { "___________" }}\n\n" +
                "La sedación consiste en administrar medicamentos por vía intravenosa (y, si procede, anestesia local aplicada por el equipo realizador) para alcanzar un estado de calma y somnolencia durante el procedimiento, con alivio de la ansiedad y del dolor. Existen grados de sedación: moderada (el paciente responde a estímulos verbales) y profunda (el paciente responde solo a estímulos más intensos y puede requerir apoyo para mantener la vía aérea). El grado se decide según el procedimiento y las condiciones del paciente, y en cualquier momento puede profundizarse o convertirse en anestesia general si la situación lo exige. Durante toda la sedación se vigila de forma continua la oxigenación (oxímetro de pulso), la respiración (capnografía cuando esté disponible), la actividad eléctrica del corazón (electrocardiograma) y la presión arterial.",
            2, ""
        ))
        add(Triple("4. RIESGOS Y COMPLICACIONES POSIBLES", 1, ""))
        add(Triple(
            "•  Depresión respiratoria (frenación de la respiración) y descenso del oxígeno en sangre: el riesgo más frecuente de la sedación; puede exigir estimular al paciente, aplicar oxígeno, ventilar con mascarilla o intubar.\n" +
                "•  Caída de la presión arterial o alteraciones del ritmo cardíaco, vigiladas y tratadas en el momento.\n" +
                "•  Sedación insuficiente (recuerdo del procedimiento) o excesiva (somnolencia prolongada).\n" +
                "•  Agitación paradójica (inquietud inesperada), especialmente en el adulto mayor y en niños.\n" +
                "•  Náuseas, vómitos y dolor en el sitio de la punción.\n" +
                "•  Reacción alérgica a los fármacos sedantes (de leve a grave).\n" +
                "•  Aspiración de contenido gástrico al pulmón si no se respetan las indicaciones de ayuno.\n" +
                "•  Laringoespasmo o broncoespasmo (obstrucción de la vía aérea).\n" +
                "•  Conversión en anestesia general si la sedación resulta insuficiente o aparece alguna complicación, con los riesgos propios de esa técnica.\n" +
                "•  En pacientes con enfermedad cardíaca, pulmonar, renal, hepática, obesidad, apnea del sueño o edad avanzada, los riesgos anteriores aumentan y se evalúan individualmente.",
            2, ""
        ))
        if (risksExtra.isNotBlank()) {
            add(Triple("Riesgos particulares comunicados por el profesional", 1, ""))
            add(Triple(risksExtra, 2, ""))
        }
        add(Triple("5. BENEFICIOS ESPERADOS", 1, ""))
        add(Triple(
            "Realizar el procedimiento diagnóstico o terapéutico con comodidad, ausencia de ansiedad y de dolor, sin los riesgos y la recuperación propios de una anestesia general, con despertar rápido y alta precoz cuando el estado clínico lo permita.",
            2, ""
        ))
        add(Triple("6. ALTERNATIVAS DISPONIBLES", 1, ""))
        add(Triple(
            "•  Realizar el procedimiento sin sedación, con anestesia local cuando proceda.\n" +
                "•  Anestesia general: se reserva para procedimientos prolongados, pacientes con contraindicación de la sedación o preferencia expresa, y conlleva sus propios riesgos descritos en el consentimiento de anestesia.\n" +
                "•  Postergar o cancelar el procedimiento si las condiciones del paciente no son las adecuadas.",
            2, ""
        ))
        add(Triple("7. INSTRUCCIONES OBLIGATORIAS PARA EL ALTA", 1, ""))
        add(Triple(
            "•  Debe acudir acompañado y volver al domicilio acompañado: no conducir vehículos ni operar maquinaria durante las 24 horas siguientes.\n" +
                "•  No tomar alcohol, ni firmar documentos de importancia, ni tomar decisiones trascendentes durante las 24 horas siguientes.\n" +
                "•  Respetar el ayuno indicado antes del procedimiento (habitualmente 6 horas para alimentos sólidos y 2 horas para líquidos claros).\n" +
                "•  Acudir a urgencias si presenta dificultad para respirar, dolor torácico, vómitos persistentes, sangrado, fiebre o somnolencia que no se corrige con estímulos.",
            2, ""
        ))
        add(Triple("8. DERECHOS DEL PACIENTE", 1, ""))
        add(Triple(
            "•  Recibir toda la información que solicite y hacer las preguntas que considere necesarias antes de firmar.\n" +
                "•  Retirar este consentimiento en cualquier momento antes del procedimiento.\n" +
                "•  Solicitar una segunda opinión sobre el plan propuesto.\n" +
                "•  Que un familiar o acompañante esté informado, si así lo deseo.",
            2, ""
        ))
        add(Triple("9. DECLARACIÓN Y AUTORIZACIÓN", 1, ""))
        add(Triple(
            "Declaro que he leído (o me ha sido leído) este documento, que comprendo su contenido, que se me ha explicado la sedación propuesta, sus riesgos, beneficios y alternativas, que declaro haber respetado el ayuno indicado y que se han respondido todas mis preguntas. Autorizo de forma libre y expresa la realización de la sedación descrita y las medidas concomitantes que el procedimiento requiera (canalización venosa, monitorización, apoyo de vía aérea y, si fuese estrictamente necesario, conversión a anestesia general).",
            2, ""
        ))
        add(Triple("10. FIRMAS", 1, ""))
        add(Triple(
            "Paciente (o representante legal)\n\nNombre: ______________________    CI: ____________________\n\nFirma: ______________________    Fecha y hora: __________________\n\n" +
                "Profesional responsable\n\nNombre: ${anesthesiologist.ifBlank { "______________________" }}    CI: ____________________\n\nFirma: ______________________    Fecha y hora: __________________\n\n" +
                "Testigo\n\nNombre: ______________________    CI: ____________________\n\nFirma: ______________________    Fecha y hora: __________________",
            2, ""
        ))
        add(Triple(
            "El original se archiva en la historia clínica y se entrega copia al paciente. Documento generado por la aplicación Cronos Anestesia como apoyo a la práctica clínica; su validez formal se ajusta a la normativa vigente de la institución.",
            2, ""
        ))
        ConsentEditStore.applyEdits(this, edit, 11)
    }

}
