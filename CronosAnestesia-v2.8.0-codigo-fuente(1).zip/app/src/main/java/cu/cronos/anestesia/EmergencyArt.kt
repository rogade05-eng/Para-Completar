package cu.cronos.anestesia

/**
 * v2.3.0 — Esquemas dinámicos de Emergencias (RCP y vía aérea).
 * Canvas animado con zonas táctiles, mismo patrón que Machine.kt (sin INTERNET).
 */

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.sin

private val ART_GREEN = Color(0xFF2E7D32)
private val ART_BLUE = Color(0xFF1565C0)
private val ART_RED = Color(0xFFC62828)
private val ART_AMBER = Color(0xFFB26A00)
private val ART_PURPLE = Color(0xFF6A1B9A)

private data class ArtBox(
    val title: String,
    val sub: String,
    val x: Float,
    val y: Float,
    val w: Float = 0.28f,
    val h: Float = 0.24f,
    val accent: Color? = null
)

private data class ArtZone(
    val x1: Float, val y1: Float, val x2: Float, val y2: Float,
    val title: String, val body: String
)

private fun DrawScope.boxShape(b: ArtBox, w: Float, h: Float, fill: Color, line: Color) {
    drawRoundRect(
        color = fill,
        topLeft = Offset(b.x * w, b.y * h),
        size = Size(b.w * w, b.h * h),
        cornerRadius = CornerRadius(14f, 14f)
    )
    drawRoundRect(
        color = line,
        topLeft = Offset(b.x * w, b.y * h),
        size = Size(b.w * w, b.h * h),
        cornerRadius = CornerRadius(14f, 14f),
        style = Stroke(3f)
    )
}

@Composable
private fun ArtHint() {
    Text(
        "Esquemas animados: toque una zona numerada o resaltada para ver su explicación. Funcionan sin conexión.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

// ============================ RCP ============================

@Composable
fun RcpArtScreen() {
    Column {
        ArtHint()
        Spacer(Modifier.height(8.dp))
        SurvivalChainCanvas()
        Spacer(Modifier.height(12.dp))
        CprFlowCanvas()
        Spacer(Modifier.height(12.dp))
        CompressionCanvas()
    }
}

/** Cadena de supervivencia: 5 eslabones con pulso animado de un extremo al otro. */
@Composable
private fun SurvivalChainCanvas() {
    val phase = rememberInfiniteTransition(label = "chain")
        .animateFloat(0f, 1f, infiniteRepeatable(tween(3000, easing = LinearEasing), RepeatMode.Restart), label = "ph")
    val primary = MaterialTheme.colorScheme.primary
    val onSurface = MaterialTheme.colorScheme.onSurface
    val density = LocalDensity.current
    val labelPx = with(density) { 12.dp.toPx() }
    val numPx = with(density) { 20.dp.toPx() }

    val labels = listOf(
        "Reconocer" to "y activar",
        "RCP" to "inmediata",
        "Desfibrilar" to "rápido",
        "Soporte" to "avanzado",
        "Cuidados" to "postparo"
    )
    val colors = listOf(ART_BLUE, ART_GREEN, ART_RED, ART_PURPLE, ART_AMBER)

    Canvas(Modifier.fillMaxWidth().height(190.dp)) {
        val w = size.width; val h = size.height
        drawRoundRect(color = primary.copy(alpha = 0.06f), cornerRadius = CornerRadius(24f, 24f))
        val r = 0.30f * h
        val cy = 0.40f * h
        // flechas entre eslabones
        for (i in 0..3) {
            val x1 = (i + 0.5f) / 5f * w + r; val x2 = (i + 1.5f) / 5f * w - r
            val alpha = if (abs(phase.value - (i + 1f) / 5f) < 0.18f) 1f else 0.35f
            drawLine(ART_GREEN.copy(alpha = alpha), Offset(x1, cy), Offset(x2, cy), strokeWidth = 6f, cap = StrokeCap.Round)
            // punta de flecha
            val p = Path().apply {
                moveTo(x2, cy); lineTo(x2 - 12f, cy - 8f); lineTo(x2 - 12f, cy + 8f); close()
            }
            drawPath(p, ART_GREEN.copy(alpha = alpha))
        }
        // eslabones
        for (i in 0..4) {
            val cx = (i + 0.5f) / 5f * w
            val active = abs(phase.value - i / 4f) < 0.12f
            drawCircle(colors[i].copy(alpha = if (active) 0.95f else 0.55f), radius = r, center = Offset(cx, cy))
            drawCircle(Color.White.copy(alpha = 0.9f), radius = r * 0.82f, center = Offset(cx, cy))
            drawCircle(colors[i], radius = r, center = Offset(cx, cy), style = Stroke(3.5f))
        }
        val pNum = android.graphics.Paint().apply {
            color = onSurface.toArgb(); textSize = numPx; isAntiAlias = true
            textAlign = android.graphics.Paint.Align.CENTER
        }
        val pLab = android.graphics.Paint().apply {
            color = onSurface.toArgb(); textSize = labelPx; isAntiAlias = true
            textAlign = android.graphics.Paint.Align.CENTER
        }
        for (i in 0..4) {
            val cx = (i + 0.5f) / 5f * w
            drawContext.canvas.nativeCanvas.drawText("${i + 1}", cx, cy + numPx * 0.35f, pNum)
            drawContext.canvas.nativeCanvas.drawText(labels[i].first, cx, h * 0.86f, pLab)
            drawContext.canvas.nativeCanvas.drawText(labels[i].second, cx, h * 0.86f + labelPx * 1.25f, pLab)
        }
    }
    Text(
        "Cadena de supervivencia: cada minuto sin RCP cuesta 7–10 % de supervivencia en FV. La desfibrilación precoz y las compresiones ininterrumpidas son los dos eslabones que más vidas salvan.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

/** Algoritmo universal: evaluación → activación → 2 min RCP → ritmo. */
@Composable
private fun CprFlowCanvas() {
    val pulse = rememberInfiniteTransition(label = "flow")
        .animateFloat(0f, 1f, infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Restart), label = "pu")
    val primary = MaterialTheme.colorScheme.primary
    val onSurface = MaterialTheme.colorScheme.onSurface
    val density = LocalDensity.current
    val labelPx = with(density) { 11.dp.toPx() }

    Canvas(Modifier.fillMaxWidth().height(300.dp)) {
        val w = size.width; val h = size.height
        drawRoundRect(color = primary.copy(alpha = 0.06f), cornerRadius = CornerRadius(24f, 24f))
        val boxes = listOf(
            ArtBox("No responde y", "no respira normal", 0.02f, 0.05f, 0.30f, 0.20f, ART_BLUE),
            ArtBox("Activar emergencias", "RCP 30:2 + DEA", 0.02f, 0.38f, 0.30f, 0.20f, ART_BLUE),
            ArtBox("2 min de RCP", "reevaluar ritmo", 0.37f, 0.38f, 0.26f, 0.20f, ART_GREEN),
            ArtBox("¿Ritmo", "desfibrilable?", 0.69f, 0.38f, 0.26f, 0.20f, ART_AMBER),
            ArtBox("SÍ: 1 descarga", "150–200 J bifásico", 0.37f, 0.76f, 0.26f, 0.20f, ART_RED),
            ArtBox("NO: adrenalina", "1 mg · 4H/4T", 0.69f, 0.76f, 0.26f, 0.20f, ART_BLUE)
        )
        val a = 0.45f + 0.55f * abs(pulse.value - 0.5f) * 2f
        boxes.forEach { b -> boxShape(b, w, h, (b.accent ?: primary).copy(alpha = 0.14f), (b.accent ?: primary).copy(alpha = 0.65f)) }
        val paint = android.graphics.Paint().apply {
            color = onSurface.toArgb(); textSize = labelPx; isAntiAlias = true
            textAlign = android.graphics.Paint.Align.CENTER
        }
        boxes.forEach { b ->
            drawContext.canvas.nativeCanvas.drawText(b.title, (b.x + b.w / 2f) * w, (b.y + 0.085f) * h, paint)
            drawContext.canvas.nativeCanvas.drawText(b.sub, (b.x + b.w / 2f) * w, (b.y + 0.165f) * h, paint)
        }
        // flechas
        fun v(x: Float, y1: Float, y2: Float, c: Color) = drawLine(c, Offset(x * w, y1 * h), Offset(x * w, y2 * h), strokeWidth = 6f, cap = StrokeCap.Round)
        fun hz(x1: Float, x2: Float, y: Float, c: Color) = drawLine(c, Offset(x1 * w, y * h), Offset(x2 * w, y * h), strokeWidth = 6f, cap = StrokeCap.Round)
        fun head(x: Float, y: Float, c: Color, up: Boolean = false, left: Boolean = false) {
            val p = Path()
            if (up) { p.moveTo(x * w, y * h); p.lineTo(x * w - 8f, y * h + 12f); p.lineTo(x * w + 8f, y * h + 12f) }
            else if (left) { p.moveTo(x * w, y * h); p.lineTo(x * w + 12f, y * h - 8f); p.lineTo(x * w + 12f, y * h + 8f) }
            else { p.moveTo(x * w, y * h); p.lineTo(x * w - 8f, y * h - 12f); p.lineTo(x * w + 8f, y * h - 12f) }
            p.close(); drawPath(p, c)
        }
        v(0.17f, 0.25f, 0.38f, ART_BLUE.copy(alpha = a)); head(0.17f, 0.38f, ART_BLUE.copy(alpha = a))
        hz(0.32f, 0.37f, 0.48f, ART_GREEN.copy(alpha = a)); head(0.37f, 0.48f, ART_GREEN.copy(alpha = a))
        hz(0.63f, 0.69f, 0.48f, ART_AMBER.copy(alpha = a)); head(0.69f, 0.48f, ART_AMBER.copy(alpha = a))
        v(0.82f, 0.58f, 0.76f, ART_AMBER.copy(alpha = a)); head(0.82f, 0.76f, ART_AMBER.copy(alpha = a))
        // SÍ (rama izquierda) por codo
        v(0.75f, 0.58f, 0.67f, ART_AMBER.copy(alpha = a))
        hz(0.50f, 0.75f, 0.67f, ART_AMBER.copy(alpha = a))
        v(0.50f, 0.67f, 0.76f, ART_AMBER.copy(alpha = a)); head(0.50f, 0.76f, ART_AMBER.copy(alpha = a))
        drawContext.canvas.nativeCanvas.drawText("SÍ", 0.72f * w, 0.665f * h, paint)
        drawContext.canvas.nativeCanvas.drawText("NO", 0.835f * w, 0.665f * h, paint)
        // bucles de vuelta al hub de 2 min
        v(0.50f, 0.76f, 0.58f, ART_RED.copy(alpha = a)); head(0.50f, 0.58f, ART_RED.copy(alpha = a), up = true)
        v(0.82f, 0.76f, 0.72f, ART_BLUE.copy(alpha = a))
        hz(0.55f, 0.82f, 0.72f, ART_BLUE.copy(alpha = a))
        v(0.55f, 0.72f, 0.58f, ART_BLUE.copy(alpha = a)); head(0.55f, 0.58f, ART_BLUE.copy(alpha = a), up = true)
    }
    Text(
        "Algoritmo universal: 30:2 sin vía aérea avanzada; con vía avanzada, compresiones continuas y 1 ventilación cada 6 s. Adrenalina 1 mg cada 3–5 min (precoz en ritmo no desfibrilable); amiodarona 300 mg tras la tercera descarga.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

/** Metrónomo de compresiones: profundidad y frecuencia animadas. */
@Composable
private fun CompressionCanvas() {
    val ph = rememberInfiniteTransition(label = "comp")
        .animateFloat(0f, 1f, infiniteRepeatable(tween(545, easing = LinearEasing), RepeatMode.Restart), label = "t")
    val primary = MaterialTheme.colorScheme.primary
    val onSurface = MaterialTheme.colorScheme.onSurface
    val density = LocalDensity.current
    val labelPx = with(density) { 11.dp.toPx() }

    Canvas(Modifier.fillMaxWidth().height(210.dp)) {
        val w = size.width; val h = size.height
        drawRoundRect(color = primary.copy(alpha = 0.06f), cornerRadius = CornerRadius(24f, 24f))
        val paint = android.graphics.Paint().apply {
            color = onSurface.toArgb(); textSize = labelPx; isAntiAlias = true
            textAlign = android.graphics.Paint.Align.CENTER
        }
        // tórax esquemático
        val cx = 0.30f * w; val top = 0.16f * h; val bot = 0.78f * h
        drawRoundRect(
            color = ART_BLUE.copy(alpha = 0.16f),
            topLeft = Offset(cx - 0.17f * w, top), size = Size(0.34f * w, bot - top),
            cornerRadius = CornerRadius(40f, 40f)
        )
        // talón de la mano
        val depth = sin(ph.value * 2f * Math.PI.toFloat())
        val handY = 0.34f * h + depth * 0.055f * h
        drawRoundRect(
            color = ART_RED,
            topLeft = Offset(cx - 0.10f * w, handY), size = Size(0.20f * w, 0.045f * h),
            cornerRadius = CornerRadius(16f, 16f)
        )
        drawLine(ART_RED, Offset(cx, handY + 0.045f * h), Offset(cx, handY + 0.10f * h + depth * 0.05f * h), strokeWidth = 9f, cap = StrokeCap.Round)
        // marcas de profundidad
        drawLine(onSurface.copy(alpha = 0.4f), Offset(0.62f * w, 0.34f * h), Offset(0.62f * w, 0.60f * h), strokeWidth = 3f)
        drawLine(onSurface.copy(alpha = 0.4f), Offset(0.60f * w, 0.34f * h), Offset(0.64f * w, 0.34f * h), strokeWidth = 3f)
        drawLine(onSurface.copy(alpha = 0.4f), Offset(0.60f * w, 0.60f * h), Offset(0.64f * w, 0.60f * h), strokeWidth = 3f)
        drawContext.canvas.nativeCanvas.drawText("5–6 cm", 0.72f * w, 0.36f * h, paint)
        drawContext.canvas.nativeCanvas.drawText("(1/3 del tórax", 0.72f * w, 0.36f * h + labelPx * 1.3f, paint)
        drawContext.canvas.nativeCanvas.drawText("en el niño)", 0.72f * w, 0.36f * h + labelPx * 2.6f, paint)
        drawContext.canvas.nativeCanvas.drawText("100–120/min · retroceso completo · pausas < 10 s · relevo cada 2 min", cx, 0.90f * h, paint)
    }
    Text(
        "Compresiones: talón de la mano en el tercio inferior del esternón, brazos rectos, ETCO2 como control de calidad (<10 mmHg = mejorar; salto >40 = posible ROSC).",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

// ============================ VÍA AÉREA ============================

@Composable
fun AirwayArtScreen() {
    Column {
        ArtHint()
        Spacer(Modifier.height(8.dp))
        AirwayAnatomyCanvas()
        Spacer(Modifier.height(12.dp))
        AirwayPlanCanvas()
    }
}

/** Corte sagittal con zonas táctiles (anatomía aplicada). */
@Composable
private fun AirwayAnatomyCanvas() {
    val sp = LocalSpacing.current
    var selected by rememberSaveable { mutableStateOf(-1) }
    val primary = MaterialTheme.colorScheme.primary
    val onSurface = MaterialTheme.colorScheme.onSurface
    val density = LocalDensity.current
    val labelPx = with(density) { 11.dp.toPx() }

    val zones = listOf(
        ArtZone(0.58f, 0.12f, 0.74f, 0.26f, "Nariz y fosas nasales",
            "Vía aérea superior: humedece y calienta. El lactante respira OBLIGADAMENTE por la nariz: una costra o una sonda pueden descompensarlo. En la fibroscopía despierta se anestesia con lidocaína y vasoconstrictor tópico."),
        ArtZone(0.26f, 0.30f, 0.50f, 0.50f, "Cavidad oral y lengua",
            "La lengua es la masa que obstruye al anestesiado: la elevación de la mandíbula y la cánula de Guedel la separan de la pared posterior. Mallampati valora el espacio entre lengua y paladar."),
        ArtZone(0.47f, 0.42f, 0.63f, 0.55f, "Vallecula y epiglotis",
            "La hoja curva (Macintosh) se asienta en la vallecula y tensa la ligera hioepiglótica; la hoja recta (Miller) atrapa la epiglotis: la elección en el lactante (epiglotis corta y flotante) y en la vía flotante."),
        ArtZone(0.50f, 0.53f, 0.65f, 0.61f, "Glotis y cuerdas vocales",
            "La entrada de la vía: solo el tubo que pasa entre las cuerdas está en la tráquea. Incisivos-cuerdas 11–13 cm; tubo a 21 cm (mujer) o 23 cm (varón). Lesión del recurrente: voz ronca posquirúrgica."),
        ArtZone(0.52f, 0.60f, 0.68f, 0.92f, "Tráquea y cricoides",
            "El cricoides es el único anillo completo y el punto estrecho del lactante (tubos sin balón o con balón de baja presión). Tráquea 10–13 cm: cuidado con la intubación selectiva del bronquio derecho (más vertical)."),
        ArtZone(0.28f, 0.58f, 0.46f, 0.92f, "Esófago",
            "Queda dorsal a la tráquea: la intubación esofágica es la complicación clásica de la laringoscopía con mala visión. Confirmación con capnografía de forma de onda: el estándar de oro, no la oximetría (tarda en caer).")
    )

    Canvas(
        Modifier
            .fillMaxWidth()
            .height(300.dp)
            .pointerInput(Unit) {
                detectTapGestures { pos ->
                    val w = size.width.toFloat(); val h = size.height.toFloat()
                    var hit = -1
                    zones.forEachIndexed { i, z ->
                        val nx = pos.x / w; val ny = pos.y / h
                        if (nx in z.x1..z.x2 && ny in z.y1..z.y2) hit = i
                    }
                    selected = if (hit == selected) -1 else hit
                }
            }
    ) {
        val w = size.width; val h = size.height
        drawRoundRect(color = primary.copy(alpha = 0.06f), cornerRadius = CornerRadius(24f, 24f))
        // perfil de la cabeza (esquemático, mirando a la derecha)
        drawCircle(Color(0xFFE8B08A).copy(alpha = 0.30f), radius = 0.30f * h, center = Offset(0.40f * w, 0.30f * h))
        drawArc(
            Color(0xFFE8B08A), startAngle = -60f, sweepAngle = 240f, useCenter = false,
            topLeft = Offset(0.16f * w, 0.06f * h), size = Size(0.46f * w, 0.48f * h), style = Stroke(4f)
        )
        // columna cervical
        for (i in 0..3) {
            val y = (0.42f + i * 0.055f) * h
            drawRoundRect(
                color = ART_BLUE.copy(alpha = 0.25f),
                topLeft = Offset(0.22f * w, y), size = Size(0.10f * w, 0.04f * h),
                cornerRadius = CornerRadius(8f, 8f)
            )
        }
        // paladar y cavidad nasal
        drawLine(ART_PURPLE, Offset(0.60f * w, 0.24f * h), Offset(0.44f * w, 0.30f * h), strokeWidth = 6f, cap = StrokeCap.Round)
        drawLine(ART_PURPLE, Offset(0.60f * w, 0.24f * h), Offset(0.66f * w, 0.20f * h), strokeWidth = 6f, cap = StrokeCap.Round)
        // lengua
        drawOvalShape(0.30f * w, 0.33f * h, 0.16f * w, 0.11f * h, Color(0xFFC62828).copy(alpha = 0.35f))
        // epiglotis
        drawArc(ART_AMBER, startAngle = 110f, sweepAngle = 130f, useCenter = false,
            topLeft = Offset(0.44f * w, 0.42f * h), size = Size(0.14f * w, 0.10f * h), style = Stroke(5f))
        // glotis
        drawLine(ART_RED, Offset(0.52f * w, 0.575f * h), Offset(0.62f * w, 0.575f * h), strokeWidth = 6f, cap = StrokeCap.Round)
        // tráquea con anillos
        val tx = 0.58f * w
        drawLine(ART_GREEN, Offset(tx, 0.58f * h), Offset(tx, 0.90f * h), strokeWidth = 14f, cap = StrokeCap.Round)
        for (i in 0..5) {
            val y = (0.615f + i * 0.05f) * h
            drawLine(Color.White.copy(alpha = 0.75f), Offset(tx - 0.022f * w, y), Offset(tx + 0.022f * w, y), strokeWidth = 3f)
        }
        // esófago (dorsal)
        drawLine(ART_BLUE.copy(alpha = 0.8f), Offset(0.36f * w, 0.58f * h), Offset(0.38f * w, 0.90f * h), strokeWidth = 10f, cap = StrokeCap.Round)
        // tiroides y cricoides
        drawCircle(ART_AMBER.copy(alpha = 0.8f), radius = 0.022f * w, center = Offset(0.555f * w, 0.555f * h))
        // zonas táctiles
        zones.forEachIndexed { i, z ->
            val sel = i == selected
            drawRoundRect(
                color = primary.copy(alpha = if (sel) 0.22f else 0.07f),
                topLeft = Offset(z.x1 * w, z.y1 * h),
                size = Size((z.x2 - z.x1) * w, (z.y2 - z.y1) * h),
                cornerRadius = CornerRadius(10f, 10f),
                style = Stroke(if (sel) 3.5f else 2f)
            )
        }
        val paint = android.graphics.Paint().apply {
            color = onSurface.toArgb(); textSize = labelPx; isAntiAlias = true
            textAlign = android.graphics.Paint.Align.CENTER
        }
        val zoneNames = listOf("Nariz", "Lengua", "Epiglotis", "Glotis", "Tráquea", "Esófago")
        zones.forEachIndexed { i, z ->
            drawContext.canvas.nativeCanvas.drawText(
                zoneNames[i], ((z.x1 + z.x2) / 2f) * w, (z.y2 - 0.015f) * h, paint
            )
        }
    }
    if (selected >= 0) {
        Card(
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(Modifier.padding(sp.m.dp)) {
                Text(
                    zones[selected].title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.height(4.dp))
                Text(zones[selected].body, style = MaterialTheme.typography.bodyMedium)
            }
        }
    } else {
        Text(
            "Corte sagittal de la vía aérea: toque una zona para leer su aplicación anestésica (anatomía, distancias y errores clásicos).",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawOvalShape(
    x: Float, y: Float, rw: Float, rh: Float, color: Color
) {
    drawOval(color, topLeft = Offset(x, y), size = Size(rw * 2f, rh * 2f))
}

/** Plan A–D de vía aérea difícil con alerta CICO. */
@Composable
private fun AirwayPlanCanvas() {
    val pulse = rememberInfiniteTransition(label = "plan")
        .animateFloat(0f, 1f, infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Restart), label = "pu")
    val primary = MaterialTheme.colorScheme.primary
    val onSurface = MaterialTheme.colorScheme.onSurface
    val density = LocalDensity.current
    val labelPx = with(density) { 11.dp.toPx() }

    Canvas(Modifier.fillMaxWidth().height(300.dp)) {
        val w = size.width; val h = size.height
        drawRoundRect(color = primary.copy(alpha = 0.06f), cornerRadius = CornerRadius(24f, 24f))
        val boxes = listOf(
            ArtBox("A · Laringoscopía", "óptima: 2–3 intentos", 0.03f, 0.04f, 0.42f, 0.185f, ART_GREEN),
            ArtBox("B · Máscara laríngea", "rescate + fibroscopía", 0.03f, 0.285f, 0.42f, 0.185f, ART_BLUE),
            ArtBox("C · Despertar", "si es electiva", 0.03f, 0.53f, 0.42f, 0.185f, ART_AMBER),
            ArtBox("D · No intubar/no oxigenar", "cricotiroidotomía YA", 0.03f, 0.775f, 0.42f, 0.185f, ART_RED)
        )
        val notes = listOf(
            0.04f to "Preoxigenación + O2 nasal continuo; posición RAMP; hoja correcta y maniobra externa. Cada reintento suma edema y sangre.",
            0.285f to "i-gel o ProSeal: restaura la oxigenación y sirve de ventanilla para la fibroscopía con tubo Aintree.",
            0.53f to "La salida segura en cirugía electiva: anestesia local, sedación y reintento otro día con más equipo.",
            0.775f to "Bisturí + tubo 6.0 sobre la membrana cricotiroidea. Menos de 60 segundos de hipoxia: decide, no tantees."
        )
        val a = 0.45f + 0.55f * abs(pulse.value - 0.5f) * 2f
        boxes.forEach { b -> boxShape(b, w, h, (b.accent ?: primary).copy(alpha = 0.14f), (b.accent ?: primary).copy(alpha = 0.7f)) }
        val paint = android.graphics.Paint().apply {
            color = onSurface.toArgb(); textSize = labelPx; isAntiAlias = true
            textAlign = android.graphics.Paint.Align.CENTER
        }
        val paintSmall = android.graphics.Paint().apply {
            color = onSurface.toArgb(); textSize = labelPx * 0.95f; isAntiAlias = true
        }
        boxes.forEach { b ->
            drawContext.canvas.nativeCanvas.drawText(b.title, (b.x + b.w / 2f) * w, (b.y + 0.085f) * h, paint)
            drawContext.canvas.nativeCanvas.drawText(b.sub, (b.x + b.w / 2f) * w, (b.y + 0.165f) * h, paint)
        }
        // notas a la derecha
        notes.forEach { (y, txt) ->
            drawContext.canvas.nativeCanvas.drawText(
                "•", 0.50f * w, (y + 0.085f) * h, paintSmall
            )
        }
        // flechas verticales A→B→C→D
        for (i in 0..2) {
            val y1 = boxes[i].y + boxes[i].h + 0.005f; val y2 = boxes[i + 1].y - 0.005f
            drawLine(
                (boxes[i].accent ?: primary).copy(alpha = a),
                Offset(0.34f * w, y1 * h), Offset(0.34f * w, y2 * h),
                strokeWidth = 6f, cap = StrokeCap.Round
            )
        }
        // flecha de emergencia B→D (CICO): punteada
        drawLine(
            ART_RED.copy(alpha = a),
            Offset(0.14f * w, 0.47f * h), Offset(0.14f * w, 0.765f * h),
            strokeWidth = 5f, cap = StrokeCap.Round,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(16f, 12f), 0f)
        )
        drawContext.canvas.nativeCanvas.drawText("CICO", 0.14f * w, 0.62f * h, paint)
        val notePaint = paintSmall
        notePaint.textAlign = android.graphics.Paint.Align.LEFT
        notes.forEachIndexed { i, (y, txt) ->
            val lines = txt.chunked(30)
            lines.forEachIndexed { j, ln ->
                drawContext.canvas.nativeCanvas.drawText(ln, 0.52f * w, (y + 0.075f + j * 0.07f) * h, notePaint)
            }
        }
    }
    Text(
        "Plan A–D (DAS/ASGA): la flecha punteada es el atajo de emergencia — si no puede oxigenar (CICO), el plan D no espera: menos de 60 s para la cricotiroidotomía con bisturí.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}
