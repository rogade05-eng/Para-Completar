// Cronos Anestesia — Pantallas: Gases (MAC + mezcla FiO2) y Escalas (6 escalas interactivas)
package cu.cronos.anestesia.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import cu.cronos.anestesia.engine.PatientState
import cu.cronos.anestesia.engine.derive
import cu.cronos.anestesia.engine.fiO2Mix
import cu.cronos.anestesia.engine.fmt
import cu.cronos.anestesia.engine.macForAge

@Composable
fun GasesScreen(patient: PatientState) {
    val sp = LocalSpacing.current
    var air by remember { mutableStateOf("1.0") }
    var o2 by remember { mutableStateOf("1.0") }
    val edad = patient.ageYears

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(sp.m),
    ) {
        SectionCard("MAC corregida por edad (Mapleson)") {
            Text(
                "Edad usada: ${fmt(edad)} años · MAC_edad = MAC₄₀ × 10^(−0.00269 × (edad − 40))",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            cu.cronos.anestesia.data.GASES.forEach { gas ->
                val mac = macForAge(gas.mac40, edad)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(gas.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    Text(
                        "$mac CAM (0.65–1.3 CAM = ${fmt(mac * 0.65)}–${fmt(mac * 1.3)})",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                Text(gas.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            SourceNote("miller")
        }

        SectionCard("Mezcla de gases: FiO₂ de la mezcla aire/O₂") {
            LabeledField("Flujo de aire", air, { air = it }, "L/min")
            LabeledField("Flujo de O₂", o2, { o2 = it }, "L/min")
            val a = air.toDoubleOrNull() ?: 0.0
            val o = o2.toDoubleOrNull() ?: 0.0
            val fio2 = fiO2Mix(a, o)
            val total = a + o
            Text(
                if (total <= 0.0) "Introduzca flujos positivos."
                else "FiO₂ = ${fmt(fio2 * 100)} % (flujo total ${fmt(total)} L/min)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
            )
            if (total > 0.0 && fio2 < 0.25) {
                Text(
                    "⚠ FiO₂ muy baja: riesgo de hipoxia. Verifique la mezcla y el análisis de gases inspirados.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                )
            }
            SourceNote("miller")
        }
    }
}

// ---------- Escalas ----------

@Composable
fun EscalasScreen() {
    val sp = LocalSpacing.current
    var escala by remember { mutableStateOf(0) }
    val nombres = listOf("Glasgow", "Glasgow pediátrico", "Ramsay", "Mallampati", "RCRI (Lee)", "ASA + E", "NYHA")

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(sp.m),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(sp.xs)) {
            CronosButton("<", { escala = (escala - 1 + nombres.size) % nombres.size }, enabled = true)
            Text(
                nombres[escala],
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.weight(1f),
            )
            CronosButton(">", { escala = (escala + 1) % nombres.size }, enabled = true)
        }
        when (escala) {
            0 -> GlasgowScreen(peds = false)
            1 -> GlasgowScreen(peds = true)
            2 -> RamsayScreen()
            3 -> MallampatiScreen()
            4 -> RcriScreen()
            5 -> AsaScreen()
            6 -> NyhaScreen()
        }
    }
}

@Composable
private fun OptionPicker(title: String, options: List<Pair<String, Int>>, score: Int, onScore: (Int) -> Unit) {
    val sp = LocalSpacing.current
    Column(verticalArrangement = Arrangement.spacedBy(sp.xs)) {
        Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
        options.forEach { (label, value) ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(sp.xs)) {
                CronosButton(
                    label,
                    { onScore(value) },
                    Modifier.weight(1f),
                    enabled = score != value,
                )
            }
        }
    }
}

@Composable
private fun GlasgowScreen(peds: Boolean) {
    val sp = LocalSpacing.current
    var ocular by remember { mutableStateOf(4) }
    var verbal by remember { mutableStateOf(if (peds) 5 else 5) }
    var motora by remember { mutableStateOf(6) }

    SectionCard(if (peds) "Glasgow pediátrico (< 2 años)" else "Escala de Glasgow") {
        OptionPicker(
            "Apertura ocular",
            listOf("Espontánea" to 4, "A la voz" to 3, "Al dolor" to 2, "Ninguna" to 1),
            ocular,
        ) { ocular = it }
        if (peds) {
            OptionPicker(
                "Respuesta verbal (lactante)",
                listOf("Balbucea, sonríe" to 5, "Llora pero consolable" to 4, "Quejido persistente" to 3, "Inquietud agitada" to 2, "Ninguna" to 1),
                verbal,
            ) { verbal = it }
        } else {
            OptionPicker(
                "Respuesta verbal",
                listOf("Orientado" to 5, "Confuso" to 4, "Palabras inapropiadas" to 3, "Sonidos incomprensibles" to 2, "Ninguna" to 1),
                verbal,
            ) { verbal = it }
        }
        OptionPicker(
            "Respuesta motora",
            listOf("Obedece órdenes" to 6, "Localiza el dolor" to 5, "Retira" to 4, "Flexión patológica" to 3, "Extensión" to 2, "Ninguna" to 1),
            motora,
        ) { motora = it }
        val total = ocular + verbal + motora
        Text(
            "Glasgow total: $total (${if (total >= 13) "leve" else if (total >= 9) "moderado" else "grave"})",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
        )
        Text("Intubación recomendada si Glasgow ≤ 8.", style = MaterialTheme.typography.bodySmall)
        SourceNote("morgan")
    }
}

@Composable
private fun RamsayScreen() {
    SectionCard("Sedación de Ramsay") {
        listOf(
            1 to "Ansioso, agitado o inquieto",
            2 to "Cooperador, orientado y tranquilo (sedación objetivo clásica)",
            3 to "Responde a órdenes solo",
            4 to "Respuesta enérgica al estímulo glabelar o ruido fuerte",
            5 to "Respuesta lenta al estímulo doloroso",
            6 to "Sin respuesta al estímulo doloroso",
        ).forEach { (nivel, desc) ->
            KeyValueRow("Nivel $nivel", desc)
        }
        Text("Procedimientos: Ramsay 2–3. Ventilación en UCI: 3–4.", style = MaterialTheme.typography.bodySmall)
        SourceNote("morgan")
    }
}

@Composable
private fun MallampatiScreen() {
    SectionCard("Mallampati modificado (Samsoon)") {
        listOf(
            "Clase I: paladar blando, fauces, úvula y pilares visibles",
            "Clase II: paladar blando, fauces y úvula visibles",
            "Clase III: paladar blando y base de la úvula visibles",
            "Clase IV: solo paladar duro visible",
        ).forEachIndexed { i, desc ->
            KeyValueRow("Clase ${i + 1}", desc)
        }
        Text(
            "Clases III–IV: vía aérea difícil posible. Combinar con medición tiro-mentoniana, apertura bucal y perímetro cervical en obesidad.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        SourceNote("morgan")
    }
}

@Composable
private fun RcriScreen() {
    val sp = LocalSpacing.current
    val checks = remember { mutableStateListOf(false, false, false, false, false, false) }
    val factores = listOf(
        "Cirugía de alto riesgo (intratorácica, intraabdominal, vascular suprainguinal)",
        "Historia de cardiopatía isquémica",
        "Historia de insuficiencia cardíaca congestiva",
        "Historia de enfermedad cerebrovascular",
        "Diabetes mellitus con insulina",
        "Creatinina preoperatoria > 2.0 mg/dL (176 µmol/L)",
    )
    val score = checks.count { it }
    SectionCard("Índice de riesgo cardíaco revisado (RCRI de Lee)") {
        factores.forEachIndexed { i, f ->
            RowSwitch(f, checked = checks[i], onChange = { checks[i] = it })
        }
        Text(
            "$score factor(es) — riesgo de eventos cardíacos:",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        val riesgo = when {
            score == 0 -> "0.4 % (bajo)"
            score == 1 -> "0.9 % (bajo)"
            score == 2 -> "6.6 % (intermedio)"
            else -> "> 11 % (alto)"
        }
        Text(
            riesgo,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
        )
        Text("≥ 3 factores o cirugía vascular mayor: valorar ecocardiograma y estrategias de protección cardíaca.", style = MaterialTheme.typography.bodySmall)
        SourceNote("morgan")
    }
}

@Composable
private fun AsaScreen() {
    SectionCard("Clasificación ASA física + E") {
        listOf(
            "ASA I: paciente sano",
            "ASA II: enfermedad sistémica leve sin limitación funcional",
            "ASA III: enfermedad sistémica grave con limitación funcional definida",
            "ASA IV: enfermedad grave que es amenaza constante para la vida",
            "ASA V: paciente moribundo que no se espera que sobreviva sin la operación",
            "ASA VI: paciente con muerte cerebral, donante de órganos",
        ).forEachIndexed { i, desc -> KeyValueRow("Clase ${i + 1}", desc) }
        Text(
            "Sufijo «E» = urgencia/emergencia (p. ej., ASA IIIE). Añade riesgo y reduce tiempo de optimización.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        SourceNote("morgan")
    }
}

@Composable
private fun NyhaScreen() {
    SectionCard("Insuficiencia cardíaca — NYHA") {
        listOf(
            "Clase I: sin limitación de la actividad habitual",
            "Clase II: leve limitación; cómodo en reposo, síntomas con actividad ordinaria",
            "Clase III: marcada limitación; síntomas con actividad mínima",
            "Clase IV: síntomas en reposo, incapacidad para cualquier actividad",
        ).forEachIndexed { i, desc -> KeyValueRow("Clase ${i + 1}", desc) }
        Text("NYHA III–IV: alto riesgo perioperatorio; considerar evaluación cardiológica y hemodinámica invasiva en cirugía mayor.", style = MaterialTheme.typography.bodySmall)
        SourceNote("morgan")
    }
}
