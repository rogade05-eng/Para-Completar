// Cronos Anestesia — Premedicación perioperatoria: 6 protocolos, checklist de aspiración,
// escala de Apfel y 20 grupos de medicación crónica.
package cu.cronos.anestesia.data

val PREMED_PROTOCOLS = listOf(
    PremedProtocol(
        "gastro", "Gastroprofilaxis (aspiración)",
        "Reduce volumen y acidez gástrica en pacientes con riesgo de aspiración",
        listOf(
            PremedItem("Ranitidina", "50 mg EV (1 mg/kg)", "30–60 min antes de la inducción"),
            PremedItem("Metoclopramida", "10 mg EV (0.1–0.15 mg/kg)", "Al inducir, EV lenta"),
            PremedItem("Citrato de magnesio 0.3 M", "30 mL VO", "10–20 min antes (si disponible)"),
            PremedItem("Omeprazol", "40 mg EV (alternativa a H2)", "1 h antes"),
        ),
        listOf("Indicado: embarazo > 12 sem, obesidad mórbida, íleo, urgencias, diabetes autonómica", "No sustituye la técnica de secuencia rápida"),
        "morgan",
    ),
    PremedProtocol(
        "ansiolisis", "Ansiolisis",
        "Disminuye ansiedad, mejora la tolerancia a la separación y al acceso vascular",
        listOf(
            PremedItem("Midazolam", "0.03–0.08 mg/kg IM (máx. 5 mg)", "30–45 min antes"),
            PremedItem("Diazepam", "5–10 mg VO", "60–90 min antes"),
        ),
        listOf("Reducir 30–50 % en > 65 años y en ASA III-IV", "Con opioides: mayor riesgo de apnea"),
        "morgan",
    ),
    PremedProtocol(
        "antisialagogos", "Antisialagogos",
        "Secreciones secas: indispensable en anestesia con técnica inhalatoria y procedimientos de vía aérea",
        listOf(
            PremedItem("Atropina", "0.01 mg/kg EV (mín. 0.1 mg)", "Al inducir"),
            PremedItem("Glicopirrolato", "4–8 mcg/kg EV", "30 min antes (sin efectos centrales)"),
        ),
        listOf("Atropina puede provocar taquicardia y bradicardia paradójica a dosis bajas"),
        "morgan",
    ),
    PremedProtocol(
        "antibiotica", "Profilaxis antibiótica quirúrgica",
        "Reduce infección del sitio operatorio: administer en los 60 min previos a la incisión",
        listOf(
            PremedItem("Cefazolina", "2 g EV (3 g si > 120 kg)", "30–60 min antes de la incisión"),
            PremedItem("Cefazolina pediátrica", "25–50 mg/kg EV (máx. 2 g)", "30–60 min antes"),
            PremedItem("Metronidazol", "500 mg EV", "Colorectal / apendicular, junto a cefazolina"),
            PremedItem("Vancomicina", "15 mg/kg EV lenta", "Solo alergia a β-lactámicos o SARM (comenzar 60–120 min antes)"),
        ),
        listOf("NO re-dosificar cefazolina en cirugías < 4 h", "Re-dosificar si > 4 h o sangrado > 1.5 L"),
        "sedar",
    ),
    PremedProtocol(
        "ponv", "Profilaxis de náuseas y vómitos (PONV)",
        "Estratificar con Apfel y combinar 2 medidas si ≥ 3 factores",
        listOf(
            PremedItem("Dexametasona", "0.1–0.15 mg/kg EV (máx. 8 mg)", "Al inicio de la cirugía"),
            PremedItem("Ondansetrón", "0.05–0.1 mg/kg EV (máx. 4 mg)", "Al final de la cirugía"),
            PremedItem("Metoclopramida", "10 mg EV", "Al final (coadyuvante)"),
            PremedItem("Difenhidramina", "0.5–1 mg/kg (máx. 50 mg)", "Alternativa / rescate"),
        ),
        listOf("Evitar opioides; considerar TIVA con propofol", "Rescate: usar un antiémético de OTRA clase"),
        "morgan",
    ),
    PremedProtocol(
        "hpa", "Cobertura del eje HPA (corticoides crónicos)",
        "Previene crisis adrenal en usuarios de corticoides (equivalente > 5 mg prednisona/día > 3 semanas)",
        listOf(
            PremedItem("Hidrocortisona", "1–2 mg/kg EV (50–100 mg)", "En la inducción"),
            PremedItem("Hidrocortisona mantenimiento", "50–100 mg EV c/8 h", "Primeras 24 h (uso crónico intenso)"),
        ),
        listOf("En dosis bajas/inhaladas: cobertura única en la inducción suele bastar"),
        "morgan",
    ),
)

// ---------- Checklist de riesgo de aspiración (8 factores) ----------
val ASPIRATION_FACTORS = listOf(
    "Íleo, obstrucción intestinal o emptying gástrico alterado",
    "Embarazo > 12 semanas",
    "Urgencia / emergencia (sin ayuno fiable)",
    "Obesidad mórbida (IMC ≥ 40)",
    "Diabetes con gastropatía autonómica",
    "Reflujo gastroesofágico sintomático",
    "Dolor intenso u opioides preoperatorios",
    "Nivel de conciencia disminuido / trauma",
)

// ---------- Apfel simplificado ----------
val APFEL_FACTORS = listOf(
    "Sexo femenino",
    "No fumador",
    "Historia previa de PONV / mareo",
    "Opioides postoperatorios planificados",
)

// ---------- Medicación crónica (20 grupos) ----------
val CHRONIC_MEDS = listOf(
    ChronicMed("Antidiabéticos orales", "Metformina, glibenclamida, sitagliptina", "Suspender", "Metformina el día de la cirugía (riesgo de acidosis láctica); SGLT2 3 días antes (cetoacidosis euglucémica)"),
    ChronicMed("Insulina basal", "Glargina, detemir, NPH", "Continuar/ajustar", "Reducir 20–25 % la dosis nocturna previa; control glucémico cada 1–2 h"),
    ChronicMed("Insulina prandial", "Rápida/aspart/lispro", "Suspender", "No administrar mientras haya ayuno; corregir según glucemia"),
    ChronicMed("IECA / ARA2", "Enalapril, losartán", "Suspender", "24 h antes: hipotensión refractaria bajo anestesia"),
    ChronicMed("Betabloqueadores", "Propranolol, metoprolol", "Continuar", "NO suspender bruscamente (rebado isquémico); titular taquicardia"),
    ChronicMed("Calcioantagonistas", "Amlodipino, diltiazem", "Continuar", "Sin cambios; potencian relajantes y vasodilatadores"),
    ChronicMed("Diuréticos", "Furosemida, espironolactona", "Individualizar", "Omitir el día de la cirugía si diuresis vigila; revisar K+"),
    ChronicMed("Estatinas", "Simvastatina, rosuvastatina", "Continuar", "Beneficio en cirugía vascular y cardíaca"),
    ChronicMed("Aspirina", "AAS 100 mg", "Individualizar", "Mantener en stents/cardíacos; suspender 5–7 días si riesgo hemorrálico > trombótico"),
    ChronicMed("Clopidogrel / ticagrelor", "Plavix", "Individualizar", "Suspender 5–7 días (cardiología) salvo stent reciente < 3 meses"),
    ChronicMed("Anticoagulantes orales directos", "Rivaroxabán, apixabán, dabigatrán", "Suspender", "48–72 h antes según función renal; puente solo con criterio de cardiología"),
    ChronicMed("Warfarina (acenocumarol)", "Sintrom", "Suspender + puente", "5 días antes; INR < 1.5; HNF o HBPM si alto riesgo trombótico"),
    ChronicMed("HBPM", "Enoxaparina", "Individualizar", "Profiláctica: 12 h antes; terapéutica: 24 h antes"),
    ChronicMed("Corticoides crónicos", "Prednisona, beclometasona", "Continuar + cobertura", "Hidrocortisona 1–2 mg/kg en la inducción (eje HPA)"),
    ChronicMed("Levotiroxina", "Eutirox", "Continuar", "Sin cambios; revisar TSH en hipotiroidismo grave sintomático"),
    ChronicMed("Antiepilépticos", "Carbamazepina, ácido valproico", "Continuar", "Nivel sérico si crisis recientes; valproato revisa coagulación"),
    ChronicMed("Antiparkinsonianos", "Levodopa, selegilina", "Individualizar", "Levodopa: tomar lo más cercano posible (parche rotigotina si NPO); selegilina: evitar con petidina"),
    ChronicMed("Antidepresivos ISRS/IMAO", "Fluoxetina, fenelzina", "Individualizar", "IMAO: suspensión 2 semanas (petidina y simpaticomiméticos contraindicados); ISRS: riesgo de sangrado"),
    ChronicMed("Anticonceptivos / THS", "Estrógenos", "Suspender", "4 semanas antes (riesgo trombótico) en cirugía mayor con inmovilización"),
    ChronicMed("Biológicos / inmunosupresores", "Adalimumab, metotrexato, azatioprina", "Individualizar", "Biológicos: suspender 1 ciclo de dosificación previo; MTX y azatioprina continúan en dosis bajas"),
)

