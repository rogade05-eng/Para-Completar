package cu.cronos.anestesia

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.foundation.clickable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp

@Composable
fun SettingsTab(appVersion: String, onOpenManual: () -> Unit = {}) {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    val settings = LocalAppSettings.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = sp.screenHPad.dp)
            .padding(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(sp.s.dp)
    ) {
        Spacer(Modifier.height(sp.xs.dp))
        Text(
            stringResource(R.string.settings_title),
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground
        )

        // --- Licencia y activación (v1.5.0) ---
        LicenseSection()

        // --- Tema ---
        Text(
            stringResource(R.string.settings_appearance),
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary
        )
        SegmentedRow(
            options = listOf(
                stringResource(R.string.theme_system),
                stringResource(R.string.theme_light),
                stringResource(R.string.theme_dark)
            ),
            selected = settings.themeMode,
            onSelect = { SettingsRepo.setTheme(ctx, it) }
        )

        // --- Tamaño de letra ---
        LabeledSlider(
            title = stringResource(R.string.settings_font),
            valueText = "${(settings.fontScale * 100).toInt()}%",
            value = settings.fontScale,
            onValueChange = { SettingsRepo.setFont(ctx, it) }
        )

        // --- Densidad y botones ---
        SettingSwitchRow(
            title = stringResource(R.string.settings_compact),
            description = stringResource(R.string.settings_compact_desc),
            checked = settings.compact,
            onChange = { SettingsRepo.setCompact(ctx, it) }
        )
        SettingSwitchRow(
            title = stringResource(R.string.settings_bigbtn),
            description = stringResource(R.string.settings_bigbtn_desc),
            checked = settings.bigButtons,
            onChange = { SettingsRepo.setBigButtons(ctx, it) }
        )

        // --- Restablecer ---
        AppButton(
            text = stringResource(R.string.settings_reset),
            secondary = true,
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                SettingsRepo.setTheme(ctx, 0)
                SettingsRepo.setFont(ctx, 1f)
                SettingsRepo.setCompact(ctx, false)
                SettingsRepo.setBigButtons(ctx, false)
                Toast.makeText(ctx, ctx.getString(R.string.settings_reset_done), Toast.LENGTH_SHORT).show()
            }
        )

        // --- Ayuda ---
        Text(
            stringResource(R.string.settings_help),
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary
        )
        AppButton(
            text = stringResource(R.string.settings_manual),
            secondary = true,
            modifier = Modifier.fillMaxWidth(),
            onClick = onOpenManual
        )

        // --- Información ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(sp.m.dp)) {
                Text(
                    stringResource(R.string.app_name),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    appVersion,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    stringResource(R.string.settings_privacy),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    stringResource(R.string.settings_counts),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    stringResource(R.string.settings_content_version, CONTENT_VERSION),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
                // Estado del registro cifrado de contenido (Room + SQLCipher, contrato S-02/10.1)
                var store by remember { mutableStateOf<ContentStatus?>(null) }
                LaunchedEffect(Unit) { store = ContentStore.ensureRegistered(ctx, CONTENT_VERSION) }
                val st = store
                Text(
                    if (st != null && st.available && st.encrypted)
                        stringResource(R.string.settings_content_store_ok, st.history)
                    else stringResource(R.string.settings_content_store_off),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    stringResource(R.string.settings_disclaimer),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    stringResource(R.string.settings_developer),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    stringResource(R.string.settings_medik_credit),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    stringResource(R.string.settings_developer_contact),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .padding(top = 2.dp)
                        .clickable {
                            val saludo =
                                LicenseContact.contactMessage(LicenseContact.appVersion(ctx))
                            if (!LicenseContact.openWhatsApp(ctx, saludo)) {
                                LicenseContact.shareRequest(ctx, saludo)
                            }
                        }
                )
            }
        }
    }
}
