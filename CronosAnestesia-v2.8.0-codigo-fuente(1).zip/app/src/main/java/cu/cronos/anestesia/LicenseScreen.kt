package cu.cronos.anestesia

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

/*
 * ============================================================================
 *  UI DE LICENCIAS (v1.5.0)
 *  · LicenseSection: gestión completa dentro de Ajustes.
 *  · LicenseBadgeLine: una línea de estado en Inicio (toque → Ajustes).
 *  · LockedSection / LockedInlineCard: secciones bloqueadas sin licencia.
 *  · TamperedBanner: aviso rojo si el APK no coincide con el certificado
 *    original (copia re-empaquetada).
 * ============================================================================
 */

@Composable
private fun statusColor(): androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.primary

@Composable
private fun alertColor(): androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.error

/** Línea de estado compacta para Inicio. */
@Composable
fun LicenseBadgeLine(onGoSettings: () -> Unit) {
    val sp = LocalSpacing.current
    val lic = LocalLicense.current
    var showRequest by rememberSaveable { mutableStateOf(false) }
    var showTarifas by rememberSaveable { mutableStateOf(false) }
    val text = when {
        lic.tampered -> stringResource(R.string.lic_badge_tampered)
        lic.active -> stringResource(
            R.string.lic_badge_active,
            lic.info?.tier?.displayName ?: "",
            lic.info?.holder ?: "",
            lic.info?.expiresText() ?: ""
        )
        lic.status == LicenseStatus.EXPIRED -> stringResource(R.string.lic_badge_expired)
        else -> stringResource(R.string.lic_badge_demo)
    }
    Column(Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onGoSettings)
                .padding(vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                if (lic.active) Icons.Filled.Lock else Icons.Filled.Warning,
                contentDescription = null,
                tint = if (lic.tampered || lic.status == LicenseStatus.EXPIRED) alertColor() else statusColor(),
                modifier = Modifier.size(16.dp)
            )
            Spacer(Modifier.width(6.dp))
            Text(
                text,
                style = MaterialTheme.typography.labelMedium,
                color = if (lic.tampered || lic.status == LicenseStatus.EXPIRED) alertColor() else MaterialTheme.colorScheme.primary
            )
        }
        // Solicitud directa por WhatsApp: visible sin licencia activa (demo,
        // caducada o de otro equipo). Nunca en APK alterada.
        if (!lic.active && !lic.tampered) {
            Text(
                stringResource(R.string.lic_request_button),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .padding(start = 22.dp, top = 2.dp, bottom = 2.dp)
                    .clickable { showRequest = true }
            )
        }
        // Tarifas y formas de pago (v1.6.0): siempre visibles, salvo APK alterada.
        if (!lic.tampered) {
            Text(
                stringResource(R.string.tarifas_open_button),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .padding(start = 22.dp, top = 2.dp, bottom = 2.dp)
                    .clickable { showTarifas = true }
            )
        }
    }
    if (showRequest) RequestLicenseDialog(onDismiss = { showRequest = false })
    if (showTarifas) TarifasDialog { showTarifas = false }
}

/**
 * Diálogo de solicitud de licencia (v1.5.2, ampliado en v1.6.0): arma el
 * mensaje con ID de dispositivo, nivel, duración, teléfono del cliente
 * (referencia para identificar su transferencia) y forma de pago prevista;
 * flujo «pague primero, reciba la clave después». Sin WhatsApp ofrece
 * «Compartir» y siempre permite copiar.
 */
@Composable
fun RequestLicenseDialog(
    onDismiss: () -> Unit,
    preTier: String = "Profesional",
    preDuration: String = "Mensual",
    preMethod: String = Tariffs.PAYMENT_METHODS[0]
) {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    val devHash = remember { deviceHash(ctx) }
    var holder by rememberSaveable { mutableStateOf("") }
    var org by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }
    var tier by rememberSaveable { mutableStateOf(preTier) }
    var duration by rememberSaveable {
        mutableStateOf(if (Tariffs.DURATIONS.contains(preDuration)) preDuration else "Mensual")
    }
    var method by rememberSaveable {
        mutableStateOf(if (Tariffs.PAYMENT_METHODS.contains(preMethod)) preMethod else Tariffs.PAYMENT_METHODS[0])
    }
    var copied by rememberSaveable { mutableStateOf(false) }
    var fallback by rememberSaveable { mutableStateOf(false) }
    val phoneOk = Tariffs.isValidPaymentPhone(phone)

    val message = remember(holder, org, phone, tier, duration, method, devHash) {
        LicenseContact.buildRequestMessage(
            versionName = LicenseContact.appVersion(ctx),
            deviceFormatted = if (devHash.isBlank()) "—" else formatDeviceHash(devHash),
            tier = tier,
            holder = holder,
            org = org,
            phone = if (phoneOk) phone else "",
            duration = duration,
            method = method
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.lic_request_title)) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(sp.s.dp)
            ) {
                Text(
                    stringResource(R.string.lic_request_intro),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = holder,
                    onValueChange = { holder = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text(stringResource(R.string.lic_request_holder)) },
                    shape = RoundedCornerShape(12.dp)
                )
                OutlinedTextField(
                    value = org,
                    onValueChange = { org = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text(stringResource(R.string.lic_request_org)) },
                    shape = RoundedCornerShape(12.dp)
                )
                Text(
                    stringResource(R.string.lic_request_tier),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Básica", "Profesional", "Institucional").forEach { t ->
                        FilterChip(
                            selected = tier == t,
                            onClick = { tier = t },
                            label = { Text(t) }
                        )
                    }
                }
                Text(
                    stringResource(R.string.lic_request_duration),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Tariffs.DURATIONS.forEach { d ->
                        FilterChip(
                            selected = duration == d,
                            onClick = { duration = d },
                            label = { Text(d) }
                        )
                    }
                }
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text(stringResource(R.string.lic_request_phone)) },
                    supportingText = { Text(stringResource(R.string.lic_request_phone_hint)) },
                    isError = phone.isNotBlank() && !phoneOk,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    shape = RoundedCornerShape(12.dp)
                )
                Text(
                    stringResource(R.string.lic_request_method),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Tariffs.PAYMENT_METHODS.forEach { m ->
                        FilterChip(
                            selected = method == m,
                            onClick = { method = m },
                            label = { Text(m) }
                        )
                    }
                }
                Text(
                    stringResource(R.string.lic_request_preview),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Text(
                        message,
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(sp.s.dp)
                    )
                }
                if (fallback) {
                    Text(
                        stringResource(R.string.lic_request_fallback),
                        style = MaterialTheme.typography.bodySmall,
                        color = alertColor()
                    )
                }
                if (copied) {
                    Text(
                        stringResource(R.string.lic_request_copied),
                        style = MaterialTheme.typography.bodySmall,
                        color = statusColor()
                    )
                }
                Text(
                    stringResource(R.string.lic_request_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (phone.isBlank()) {
                    Text(
                        stringResource(R.string.lic_request_phone_optional),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else if (!phoneOk) {
                    Text(
                        stringResource(R.string.lic_request_phone_needed),
                        style = MaterialTheme.typography.bodySmall,
                        color = alertColor()
                    )
                }
                AppButton(
                    text = stringResource(R.string.lic_request_copy),
                    secondary = true,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { copied = LicenseContact.copyRequest(ctx, message) }
                )
            }
        },
        confirmButton = {
            // Botón de envío FIJO en el pie del diálogo (siempre visible y
            // siempre activo). Antes vivía al final del contenido: en pantallas
            // pequeñas el texto se recortaba y solo quedaba a la vista
            // «Cerrar», y además el botón quedaba deshabilitado sin teléfono.
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(stringResource(R.string.lic_request_cancel))
                }
                AppButton(
                    text = stringResource(R.string.lic_request_open),
                    modifier = Modifier.weight(2f),
                    onClick = {
                        if (!LicenseContact.openWhatsApp(ctx, message)) {
                            LicenseContact.shareRequest(ctx, message)
                            fallback = true
                        } else {
                            onDismiss()
                        }
                    }
                )
            }
        },
        dismissButton = null
    )
}

/** Aviso rojo: APK alterada (la firma no coincide con el certificado original). */
@Composable
fun TamperedBanner() {
    val sp = LocalSpacing.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer,
            contentColor = MaterialTheme.colorScheme.onErrorContainer
        )
    ) {
        Row(Modifier.padding(sp.m.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Warning, contentDescription = null, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(sp.s.dp))
            Text(
                stringResource(R.string.lic_tampered_msg),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

/** Pestaña/sección completa bloqueada sin licencia. */
@Composable
fun LockedSection(title: String, message: String, onActivate: () -> Unit) {
    val sp = LocalSpacing.current
    var showRequest by rememberSaveable { mutableStateOf(false) }
    var showTarifas by rememberSaveable { mutableStateOf(false) }
    ScreenColumn {
        Spacer(Modifier.height(sp.l.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(sp.l.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    Icons.Filled.Lock,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(40.dp)
                )
                Spacer(Modifier.height(sp.s.dp))
                Text(
                    title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(sp.m.dp))
                AppButton(stringResource(R.string.lic_locked_cta), onClick = onActivate)
                Spacer(Modifier.height(sp.s.dp))
                AppButton(
                    text = stringResource(R.string.tarifas_open_button),
                    secondary = true,
                    onClick = { showTarifas = true }
                )
                AppButton(
                    text = stringResource(R.string.lic_request_button),
                    secondary = true,
                    onClick = { showRequest = true }
                )
            }
        }
        if (showRequest) RequestLicenseDialog(onDismiss = { showRequest = false })
        if (showTarifas) TarifasDialog { showTarifas = false }
    }
}

/** Tarjeta pequeña para contenido parcialmente bloqueado dentro de una lista. */
@Composable
fun LockedInlineCard(title: String, message: String, onActivate: () -> Unit) {
    val sp = LocalSpacing.current
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onActivate),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            contentColor = MaterialTheme.colorScheme.onSurfaceVariant
        )
    ) {
        Row(Modifier.padding(sp.m.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Filled.Lock,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(22.dp)
            )
            Spacer(Modifier.width(sp.s.dp))
            Column {
                Text(
                    title,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(message, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

/** Sección completa de gestión de licencia (se muestra en Ajustes). */
@Composable
fun LicenseSection() {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    val lic = LocalLicense.current
    var keyText by rememberSaveable { mutableStateOf("") }
    var lastMsg by rememberSaveable { mutableStateOf("") }
    var lastOk by rememberSaveable { mutableStateOf<Boolean?>(null) }

    val devHash = remember { deviceHash(ctx) }
    var showRequest by rememberSaveable { mutableStateOf(false) }
    var showTarifas by rememberSaveable { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(sp.s.dp)) {
        Text(
            stringResource(R.string.lic_section_title),
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary
        )

        // ---- Estado actual ----
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(Modifier.padding(sp.m.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                val info = lic.info
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Filled.Lock,
                        contentDescription = null,
                        tint = if (lic.active) statusColor() else alertColor(),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(sp.s.dp))
                    Text(
                        when (lic.status) {
                            LicenseStatus.ACTIVE -> stringResource(R.string.lic_state_active, lic.tier.displayName)
                            LicenseStatus.EXPIRED -> stringResource(R.string.lic_state_expired)
                            LicenseStatus.WRONG_DEVICE -> stringResource(R.string.lic_state_wrong_device)
                            LicenseStatus.INVALID -> stringResource(R.string.lic_state_invalid)
                            LicenseStatus.TAMPERED -> stringResource(R.string.lic_state_tampered)
                            LicenseStatus.NO_LICENSE -> stringResource(R.string.lic_state_none)
                        },
                        style = MaterialTheme.typography.titleSmall,
                        color = if (lic.active) statusColor() else
                            if (lic.status == LicenseStatus.NO_LICENSE) MaterialTheme.colorScheme.onSurfaceVariant
                            else alertColor()
                    )
                }
                if (info != null && lic.status != LicenseStatus.NO_LICENSE && lic.status != LicenseStatus.INVALID) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        stringResource(R.string.lic_holder_line, info.holder),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (info.org.isNotBlank()) {
                        Text(
                            stringResource(R.string.lic_org_line, info.org),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Text(
                        stringResource(R.string.lic_expiry_line, info.expiresText()),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        stringResource(R.string.lic_serial_line, info.serial),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // ---- ID del dispositivo ----
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(sp.m.dp)) {
                Text(
                    stringResource(R.string.lic_device_title),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    if (devHash.isBlank()) stringResource(R.string.lic_device_unavailable)
                    else formatDeviceHash(devHash),
                    style = MaterialTheme.typography.labelLarge.copy(fontFamily = FontFamily.Monospace),
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    stringResource(R.string.lic_device_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (lic.tampered) {
            TamperedBanner()
        }

        // ---- Activación / desactivación ----
        if (lic.active) {
            AppButton(
                text = stringResource(R.string.lic_remove),
                secondary = true,
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    LicenseRepo.deactivate(ctx)
                    keyText = ""
                    lastOk = false
                    lastMsg = ctx.getString(R.string.lic_removed)
                }
            )
        } else {
            OutlinedTextField(
                value = keyText,
                onValueChange = { keyText = it },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                maxLines = 6,
                placeholder = { Text(stringResource(R.string.lic_key_hint)) },
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    cursorColor = MaterialTheme.colorScheme.primary
                )
            )
            AppButton(
                text = stringResource(R.string.lic_activate),
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    if (keyText.isBlank()) {
                        lastOk = false
                        lastMsg = ctx.getString(R.string.lic_err_empty)
                    } else {
                        val st = LicenseRepo.activate(ctx, keyText)
                        when (st.status) {
                            LicenseStatus.ACTIVE -> {
                                lastOk = true
                                lastMsg = ctx.getString(
                                    R.string.lic_ok_activated,
                                    st.info?.holder ?: "",
                                    st.info?.tier?.displayName ?: ""
                                )
                                keyText = ""
                            }
                            LicenseStatus.EXPIRED -> {
                                lastOk = false
                                lastMsg = ctx.getString(
                                    R.string.lic_err_expired,
                                    st.info?.expiresText() ?: ""
                                )
                            }
                            LicenseStatus.WRONG_DEVICE -> {
                                lastOk = false
                                lastMsg = ctx.getString(R.string.lic_err_wrong_device)
                            }
                            LicenseStatus.INVALID -> {
                                lastOk = false
                                lastMsg = ctx.getString(R.string.lic_err_invalid, st.detail)
                            }
                            LicenseStatus.TAMPERED -> {
                                lastOk = false
                                lastMsg = ctx.getString(R.string.lic_state_tampered)
                            }
                            else -> {}
                        }
                    }
                }
            )
            if (lastMsg.isNotBlank()) {
                Text(
                    lastMsg,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (lastOk == true) statusColor() else alertColor()
                )
            }
            Text(
                stringResource(R.string.lic_buy_hint),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // ---- Tarifas y formas de pago (v1.6.0) ----
        AppButton(
            text = stringResource(R.string.tarifas_open_button),
            secondary = true,
            modifier = Modifier.fillMaxWidth(),
            onClick = { showTarifas = true }
        )

        // ---- Solicitud directa al desarrollador (v1.5.2) ----
        AppButton(
            text = stringResource(R.string.lic_request_button),
            secondary = true,
            modifier = Modifier.fillMaxWidth(),
            onClick = { showRequest = true }
        )
        if (showRequest) RequestLicenseDialog(onDismiss = { showRequest = false })
        if (showTarifas) TarifasDialog { showTarifas = false }
    }
}
