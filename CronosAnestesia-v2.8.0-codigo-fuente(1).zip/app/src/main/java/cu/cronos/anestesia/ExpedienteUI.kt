// Expedientes de pacientes (v1.7.0): registro histórico por paciente
// (Profesional/Institucional) con exportación a Excel (.xlsx) y PDF (Carta/A4).
package cu.cronos.anestesia

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import java.io.OutputStream

// ============================= Pestaña Expedientes =============================

@Composable
fun ExpedientesTab() {
    val ctx = LocalContext.current
    val sp = LocalSpacing.current
    var selected by remember { mutableStateOf<Long?>(null) }
    var showNew by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { ExpedienteRepo.ensureLoaded(ctx) }

    val current = selected?.let { ExpedienteRepo.patient(it) }
    if (current != null) {
        PatientDetail(patient = current, onBack = { selected = null })
        return
    }

    ScreenColumn {
        Spacer(Modifier.height(sp.xs.dp))
        Text(
            stringResource(R.string.tab_expedientes),
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            stringResource(R.string.rec_intro),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        if (ExpedienteRepo.patients.value.isEmpty()) {
            Spacer(Modifier.height(sp.m.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(Modifier.padding(sp.m.dp)) {
                    Text(
                        stringResource(R.string.rec_empty_title),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        stringResource(R.string.rec_empty_body),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            Spacer(Modifier.height(sp.s.dp))
            ExpedienteRepo.patients.value.sortedByDescending { it.createdAt }.forEach { p ->
                val n = ExpedienteRepo.entriesFor(p.id).size
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = sp.s.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    onClick = { selected = p.id }
                ) {
                    Column(Modifier.padding(sp.m.dp)) {
                        Text(
                            p.name,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        val sum = p.summaryLine()
                        if (sum.isNotBlank()) {
                            Text(
                                sum,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (p.historyId.isNotBlank()) {
                            Text(
                                p.historyId,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            RecFmt.ts(p.createdAt) + " · " + n + " " +
                                stringResource(R.string.rec_entries_unit),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(sp.s.dp))
        AppButton(stringResource(R.string.rec_new_patient), onClick = { showNew = true })
    }

    if (showNew) {
        PatientDialog(initial = null, onClose = { showNew = false })
    }
}

// ============================= Detalle del paciente =============================

@Composable
private fun PatientDetail(patient: RecPatient, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val sp = LocalSpacing.current
    var showNote by remember { mutableStateOf(false) }
    var showEdit by remember { mutableStateOf(false) }
    var deletePatient by remember { mutableStateOf(false) }
    var deleteEntry by remember { mutableStateOf<Long?>(null) }
    var pdfSize by remember { mutableStateOf(PdfExporter.SIZE_A4) }

    val entries = ExpedienteRepo.entriesFor(patient.id)

    fun suggest(ext: String): String =
        "Expediente_" + patient.exportName() + "_" + RecFmt.day(RecFmt.now()) + "." + ext

    val excelLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { uri ->
        if (uri != null) runCatching {
            val (header, rows) = XlsxWriter.expedienteRows(patient, ExpedienteRepo.entriesFor(patient.id))
            ctx.contentResolver.openOutputStream(uri)?.use { os ->
                os.write(XlsxWriter.xlsx(header, rows)); os.flush()
            }
            Toast.makeText(ctx, R.string.rec_export_ok, Toast.LENGTH_SHORT).show()
        }.onFailure {
            Toast.makeText(ctx, R.string.rec_export_err, Toast.LENGTH_SHORT).show()
        }
    }

    fun writePdf(os: OutputStream, size: Int) {
        PdfExporter.writeExpediente(
            ctx, os, size, patient, ExpedienteRepo.entriesFor(patient.id),
            appVersion = "Cronos Anestesia v2.0.0",
            exportedAtText = RecFmt.ts(RecFmt.now())
        )
    }

    val pdfLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null) runCatching {
            ctx.contentResolver.openOutputStream(uri)?.use { os -> writePdf(os, pdfSize) }
            Toast.makeText(ctx, R.string.rec_export_ok, Toast.LENGTH_SHORT).show()
        }.onFailure {
            Toast.makeText(ctx, R.string.rec_export_err, Toast.LENGTH_SHORT).show()
        }
    }

    ScreenColumn {
        Spacer(Modifier.height(sp.xs.dp))
        AppButton(stringResource(R.string.rec_back), onClick = onBack, secondary = true)

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(Modifier.padding(sp.m.dp)) {
                Text(
                    patient.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                listOf(
                    "Historia" to patient.historyId,
                    "Edad" to patient.ageText,
                    "Peso" to patient.weightText,
                    "Sexo" to patient.sex,
                    "Alergias" to patient.allergies,
                    "Notas" to patient.notes
                ).filter { it.second.isNotBlank() }.forEach { (k, v) ->
                    Text(
                        "$k: $v",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    RecFmt.ts(patient.createdAt),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
                    TextButton(onClick = { showEdit = true }) {
                        Text(stringResource(R.string.rec_edit))
                    }
                    TextButton(onClick = { deletePatient = true }) {
                        Text(
                            stringResource(R.string.rec_delete_patient),
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }

        SectionLabel(stringResource(R.string.rec_entries_title) + " (" + entries.size + ")")

        if (entries.isEmpty()) {
            Text(
                stringResource(R.string.rec_entries_empty),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            entries.forEach { e ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = sp.s.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(Modifier.padding(sp.m.dp)) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                e.kind,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                RecFmt.ts(e.createdAt),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            e.title,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (e.subtitle.isNotBlank()) {
                            Text(
                                e.subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (e.lines.isNotEmpty()) {
                            Spacer(Modifier.height(4.dp))
                            e.lines.forEach { (k, v) ->
                                Text(
                                    "$k: $v",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                        if (e.note.isNotBlank()) {
                            Spacer(Modifier.height(4.dp))
                            Text(
                                stringResource(R.string.rec_note_prefix) + " " + e.note,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.tertiary
                            )
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { deleteEntry = e.id }) {
                                Text(
                                    stringResource(R.string.rec_delete_entry),
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
        }

        SectionLabel(stringResource(R.string.rec_export_title))
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            AppButton(
                stringResource(R.string.rec_export_letter),
                onClick = { pdfSize = PdfExporter.SIZE_LETTER; pdfLauncher.launch(suggest("pdf")) },
                secondary = true,
                modifier = Modifier.weight(1f)
            )
            AppButton(
                stringResource(R.string.rec_export_a4),
                onClick = { pdfSize = PdfExporter.SIZE_A4; pdfLauncher.launch(suggest("pdf")) },
                secondary = true,
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(sp.s.dp))
        AppButton(stringResource(R.string.rec_export_excel), onClick = {
            excelLauncher.launch(suggest("xlsx"))
        })
        Spacer(Modifier.height(sp.s.dp))
        AppButton(stringResource(R.string.rec_add_note), onClick = { showNote = true }, secondary = true)
        Text(
            stringResource(R.string.rec_export_hint),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(sp.l.dp))
    }

    if (showNote) NoteDialog(patient.id, onClose = { showNote = false })
    if (showEdit) PatientDialog(initial = patient, onClose = { showEdit = false })
    if (deletePatient) AlertDialog(
        onDismissRequest = { deletePatient = false },
        title = { Text(stringResource(R.string.rec_delete_patient)) },
        text = { Text(stringResource(R.string.rec_delete_patient_q)) },
        confirmButton = {
            TextButton(onClick = {
                ExpedienteRepo.deletePatient(ctx, patient.id)
                deletePatient = false
                onBack()
            }) { Text(stringResource(R.string.rec_yes), color = MaterialTheme.colorScheme.error) }
        },
        dismissButton = {
            TextButton(onClick = { deletePatient = false }) { Text(stringResource(R.string.rec_cancel)) }
        }
    )
    deleteEntry?.let { id ->
        AlertDialog(
            onDismissRequest = { deleteEntry = null },
            title = { Text(stringResource(R.string.rec_delete_entry)) },
            text = { Text(stringResource(R.string.rec_delete_entry_q)) },
            confirmButton = {
                TextButton(onClick = {
                    ExpedienteRepo.deleteEntry(ctx, id)
                    deleteEntry = null
                }) { Text(stringResource(R.string.rec_yes), color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { deleteEntry = null }) { Text(stringResource(R.string.rec_cancel)) }
            }
        )
    }
}

// ============================= Diálogos =============================

/** Alta/edición de paciente. */
@Composable
private fun PatientDialog(initial: RecPatient?, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val sp = LocalSpacing.current
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var history by remember { mutableStateOf(initial?.historyId ?: "") }
    var age by remember { mutableStateOf(initial?.ageText ?: "") }
    var weight by remember { mutableStateOf(initial?.weightText ?: "") }
    var sex by remember { mutableStateOf(initial?.sex ?: "") }
    var allergies by remember { mutableStateOf(initial?.allergies ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(stringResource(if (initial == null) R.string.rec_new_patient else R.string.rec_edit)) },
        text = {
            // Scroll preventivo: 7 campos pueden superar la altura del diálogo.
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(sp.xs.dp)
            ) {
                OutlinedTextField(
                    value = name, onValueChange = { if (it.length <= 80) name = it },
                    label = { Text(stringResource(R.string.rec_name_label)) }, singleLine = true
                )
                OutlinedTextField(
                    value = history, onValueChange = { if (it.length <= 40) history = it },
                    label = { Text(stringResource(R.string.rec_history_label)) }, singleLine = true
                )
                Row(horizontalArrangement = Arrangement.spacedBy(sp.xs.dp)) {
                    OutlinedTextField(
                        value = age, onValueChange = { if (it.length <= 16) age = it },
                        label = { Text(stringResource(R.string.rec_age_label)) }, singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = weight, onValueChange = { if (it.length <= 16) weight = it },
                        label = { Text(stringResource(R.string.rec_weight_label)) }, singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(sp.xs.dp)) {
                    AppButton("—", onClick = { sex = "" }, secondary = sex.isEmpty(), modifier = Modifier.weight(1f))
                    AppButton("F", onClick = { sex = "F" }, secondary = sex != "F", modifier = Modifier.weight(1f))
                    AppButton("M", onClick = { sex = "M" }, secondary = sex != "M", modifier = Modifier.weight(1f))
                }
                OutlinedTextField(
                    value = allergies, onValueChange = { if (it.length <= 200) allergies = it },
                    label = { Text(stringResource(R.string.rec_allergies_label)) }, singleLine = true
                )
                OutlinedTextField(
                    value = notes, onValueChange = { if (it.length <= 500) notes = it },
                    label = { Text(stringResource(R.string.rec_notes_label)) }
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (name.isBlank()) return@TextButton
                    if (initial == null) {
                        ExpedienteRepo.addPatient(
                            ctx,
                            RecPatient(
                                id = ExpedienteRepo.newId(), name = name.trim(),
                                historyId = history.trim(), ageText = age.trim(),
                                weightText = weight.trim(), sex = sex,
                                allergies = allergies.trim(), notes = notes.trim(),
                                createdAt = RecFmt.now()
                            )
                        )
                    } else {
                        ExpedienteRepo.updatePatient(
                            ctx,
                            initial.copy(
                                name = name.trim(), historyId = history.trim(),
                                ageText = age.trim(), weightText = weight.trim(), sex = sex,
                                allergies = allergies.trim(), notes = notes.trim()
                            )
                        )
                    }
                    onClose()
                },
                enabled = name.isNotBlank()
            ) { Text(stringResource(R.string.rec_yes)) }
        },
        dismissButton = {
            TextButton(onClick = onClose) { Text(stringResource(R.string.rec_cancel)) }
        }
    )
}

/** Nota / procedimiento manual dentro del expediente. */
@Composable
private fun NoteDialog(patientId: Long, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val sp = LocalSpacing.current
    var title by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(stringResource(R.string.rec_add_note)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(sp.xs.dp)) {
                OutlinedTextField(
                    value = title, onValueChange = { if (it.length <= 80) title = it },
                    label = { Text(stringResource(R.string.rec_note_title)) }, singleLine = true
                )
                OutlinedTextField(
                    value = note, onValueChange = { if (it.length <= 800) note = it },
                    label = { Text(stringResource(R.string.rec_note_body)) }
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    ExpedienteRepo.addEntry(
                        ctx,
                        RecEntry(
                            id = ExpedienteRepo.newId(), patientId = patientId,
                            kind = "Nota", title = if (title.isBlank()) "Nota" else title.trim(),
                            subtitle = "", lines = emptyList(), note = note.trim(),
                            createdAt = RecFmt.now()
                        )
                    )
                    onClose()
                },
                enabled = title.isNotBlank() || note.isNotBlank()
            ) { Text(stringResource(R.string.rec_yes)) }
        },
        dismissButton = {
            TextButton(onClick = onClose) { Text(stringResource(R.string.rec_cancel)) }
        }
    )
}

/**
 * Diálogo «Guardar en expediente»: vincula un cálculo/escala/dosis a un
 * paciente existente o a uno nuevo. Se usa desde Dosis calculada,
 * Calculadoras y Escalas (solo visible con licencia Profesional/Institucional).
 */
@Composable
fun SaveRecordDialog(
    kind: String,
    title: String,
    subtitle: String,
    lines: List<Pair<String, String>>,
    onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    val sp = LocalSpacing.current
    var pick by remember { mutableStateOf<Long?>(null) }
    var newName by remember { mutableStateOf("") }
    var newHistory by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    val patients = ExpedienteRepo.patients.value.sortedByDescending { it.createdAt }
    val canSave = (pick != null && patients.isNotEmpty()) || (patients.isEmpty() && newName.isNotBlank())

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.rec_pick_patient)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(sp.xs.dp)) {
                Text(
                    stringResource(R.string.rec_saving) + " " + kind + " · " + title,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (patients.isEmpty()) {
                    Text(
                        stringResource(R.string.rec_no_patients),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    patients.forEach { p ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            androidx.compose.material3.RadioButton(
                                selected = pick == p.id,
                                onClick = { pick = p.id }
                            )
                            Column(Modifier.padding(start = 4.dp)) {
                                Text(
                                    p.name,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                val sum = p.summaryLine()
                                if (sum.isNotBlank()) Text(
                                    sum,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
                if (patients.isEmpty()) {
                    OutlinedTextField(
                        value = newName, onValueChange = { if (it.length <= 80) newName = it },
                        label = { Text(stringResource(R.string.rec_name_label)) }, singleLine = true
                    )
                    OutlinedTextField(
                        value = newHistory, onValueChange = { if (it.length <= 40) newHistory = it },
                        label = { Text(stringResource(R.string.rec_history_label)) }, singleLine = true
                    )
                }
                OutlinedTextField(
                    value = note, onValueChange = { if (it.length <= 500) note = it },
                    label = { Text(stringResource(R.string.rec_note_body)) }
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val pid: Long
                    if (pick != null) {
                        pid = pick!!
                    } else {
                        val np = RecPatient(
                            id = ExpedienteRepo.newId(), name = newName.trim(),
                            historyId = newHistory.trim(), ageText = "", weightText = "",
                            sex = "", allergies = "", notes = "", createdAt = RecFmt.now()
                        )
                        ExpedienteRepo.addPatient(ctx, np)
                        pid = np.id
                    }
                    ExpedienteRepo.addEntry(
                        ctx,
                        RecEntry(
                            id = ExpedienteRepo.newId(), patientId = pid,
                            kind = kind, title = title, subtitle = subtitle,
                            lines = lines, note = note.trim(), createdAt = RecFmt.now()
                        )
                    )
                    Toast.makeText(ctx, R.string.rec_saved, Toast.LENGTH_SHORT).show()
                    onDismiss()
                },
                enabled = canSave
            ) { Text(stringResource(R.string.rec_save_entry)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.rec_cancel)) }
        }
    )
}

/** Botón pequeño para guardar en expediente (oculto sin licencia PRO/INST). */
@Composable
fun SaveRecordButton(onClick: () -> Unit) {
    if (!LocalLicense.current.features.records) return
    TextButton(onClick = onClick) {
        Text(stringResource(R.string.rec_save_btn))
    }
}
