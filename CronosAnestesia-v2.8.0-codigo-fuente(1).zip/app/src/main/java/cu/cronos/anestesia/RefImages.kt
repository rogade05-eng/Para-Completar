package cu.cronos.anestesia

/**
 * v2.4.0 — Imágenes de referencia generales (apartado 9 de Clínica).
 * Ilustraciones médicas empaquetadas en assets/refimg (100 % offline, sin INTERNET).
 * Las ilustraciones no contienen texto: los rótulos se presentan en español
 * dentro de la app (el texto generado por IA no es fiable).
 */

import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

data class RefImage(
    val file: String,     // nombre dentro de assets/refimg/
    val title: String,
    val subtitle: String,
    val caption: String,  // «Qué muestra»
    val notes: String     // «Aplicación clínica»
)

const val REF_IMG_PREFIX = "img:"
const val REF_IMG_DIR = "refimg"

val REF_IMAGES = listOf(
    RefImage(
        "img_via_aerea_equipo.jpg",
        "Equipo de vía aérea",
        "Bandeja de intubación ordenada",
        "Bandeja de intubación con los elementos de una vía aérea completa: tubo endotraqueal con balón, laringoscopio (hojas curva y recta), mascarilla laríngea, fiador, jeringa para inflar el balón, cánula de Guedel y bolsa-válvula-mascarilla autoinflable. El orden NO es estético: es la secuencia de uso real (chequeo, laringoscopia, tubo, rescate supraglótico).",
        "La bandeja se arma y se revisa ANTES de cada inducción (protocolo del leak test y de la hoja que ilumina): tubo probado con balón íntegro, dos tamaños contiguos, hoja encendida de repuesto y dispositivo supraglótico disponible. En emergencias, la bandeja preparada es la diferencia entre intubar en 30 segundos o perder el paciente mientras se busca una jeringa."
    ),
    RefImage(
        "img_videolaringo.jpg",
        "Videolaringoscopio: visión glótica",
        "Pantalla con vista de cuerdas vocales",
        "Videolaringoscopio en mano con su pantalla mostrando la visión glótica: las cuerdas vocales pálidas formando una V y la entrada de la tráquea como abertura oscura central. La ventaja del video es ver donde la laringoscopia directa no llega (lengua gruesa, cuello corto, movilidad cervical limitada) y COMPARTIR la visión con el equipo.",
        "El videolaringoscopio ha convertido en intubaciones «normales» bocas que antes eran imposibles: mantenerlo cargado y disponible en TODAS las salas es estándar de seguridad. Regla práctica: no repetir el mismo intento con la misma técnica; si la primera laringoscopia falla, pasar al video o al plan B con oxigenación entre intentos. La pantalla compartida permite que la persona de ayuda anticipe el siguiente paso."
    ),
    RefImage(
        "img_oxigeno.jpg",
        "Dispositivos de oxigenoterapia",
        "Mascarilla, cánula nasal y reservorio",
        "Tres dispositivos de aporte de oxígeno: mascarilla simple con orificios laterales, cánula nasal con puntas nasales y mascarilla con reservorio (no reinhalatoria). La fracción inspirada de oxígeno (FiO2) aproximada: cánula nasal 24–40 % (1–5 L/min), mascarilla simple 35–55 % (5–8 L/min), mascarilla con reservorio 60–90 % (10–15 L/min, NUNCA con flujo bajo que colapse la bolsa).",
        "La oxigenoterapia no sustituye la ventilación: un paciente con CO2 elevado y máscara puesta sigue siendo hipercápnico. En el perioperatorio la cánula nasal es la transición habitual de la sedación y el postoperatorio; la mascarilla con reservorio es el estándar de la preoxigenación de emergencia junto con la Venturi de alta FiO2 en el paciente CO2-dependiente. Recordar: piel facial quemada o barba espesa rompen el sellado; en esos casos, goteo nasal de alto flujo o mascarilla laríngea."
    ),
    RefImage(
        "img_via_iv.jpg",
        "Canalización venosa periférica",
        "Catéter venoso periférico fijado",
        "Canalización venosa periférica: catéter corto insertado en vena del dorso de la mano o del antebrazo, fijado con apósito transparente y conectado a extensión y frasco de infusión. Secuencia: torniquete, venopunción con bisel arriba, aparición de sangre en el canal, retirar el mandril, comprobar flujo libre, fijar y rotular. El calibre se elige por PROPÓSITO: 18–20 G para cirugía general, 16 G o mayor si se anticipa hemorragia o transfusión.",
        "La vía periférica bien puesta sirve para casi todo el perioperatorio, incluida la anestesia general y los vasopresores diluidos de corta duración. Reglas de seguridad: preferir el antebrazo proximal para cirugía con movilización del brazo, nunca puncionar a través de infección de piel o en el brazo con fístula arteriovenosa, cambiar el catéter si hay flebitis o más de 72–96 h, y SIEMPRE identificar la vía antes de la inducción (dos vías de gran calibre en hemorragia o trauma: ver «Terapia transfusional»)."
    ),
    RefImage(
        "img_linea_arterial.jpg",
        "Canalización arterial radial",
        "Catéter arterial y transductor",
        "Cateterismo arterial radial: catéter fino en la arteria radial fijado con apósito transparente, conectado por tubería rígida a un transductor de presión posicionado a nivel del corazón (línea axilar media), con bolsa de salino bajo presión que mantiene el sistema despejado. Proporciona presión arterial BEAT A BEAT, gases arteriales en cualquier momento y curva con información clínica (hipovolemia, variación respiratoria).",
        "Indicaciones perioperatorias habituales: cirugía cardíaca y de gran sangrado, hipertensión inestable, vasopresores a dosis altas, paciente crítico y monitorización neurológica (PAM objetivo estricta, como en el ictus endovascular). Antes de punzar la radial: comprobar la circulación colateral (prueba de Allen modificada o Doppler) y elegir la arteria con mejor flujo. Complicaciones a vigilar: isquemia distal (mirar la punta de los dedos), trombosis, infección y fuga — el apósito transparente permite inspección diaria. La calibración del transductor y el cero al nivel del corazón son obligatorios: un transductor mal nivelado engaña más que la ausencia de dato."
    ),
    RefImage(
        "img_monitor_qx.jpg",
        "Monitorización estándar del quirófano",
        "Los cinco parámetros básicos",
        "Monitor de quirófano con las trazas estándar: electrocardiograma (verde, con derivación elegida por el problema: II para arritmias, V5 para isquemia), pletismografía de oximetría de pulso (azul, la amplitud ES información de perfusión), capnografía (amarillo, la traza más importante de la anestesia: forma, frecuencia y valor numérico del CO2 espirado) y traza de presión (roja). El estándar mínimo de la ASA para anestesia general: EKG, oximetría, capnografía continua, temperatura y guía de la profundidad anestésica cuando proceda.",
        "La capnografía es el parámetro que separa la anestesia moderna de la supervivencia: detecta desconexión, obstrucción, embolia, broncoespasmo y además calibra la calidad de la RCP. La pletismografía que pierde amplitud NO es siempre mala perfusión: puede ser mala posición del sensor (comprobar el pulso con la mano). Regla de la sala: los ALARMAS se activan y se ajustan ANTES de inducir, no después del primer incidente; un monitor silenciado es un monitor decorativo."
    ),
    RefImage(
        "img_neuroaxial.jpg",
        "Punción neuroaxial lumbar",
        "Aguja espinal y espacios de la columna",
        "Representación esquemática de la punción neuroaxial lumbar: la aguja avanza entre procesos espinosos (línea media o paramediana) a través de piel, subcutáneo, ligamento supraespinoso e interespinoso, ligamento amarillo (pérdida de resistencia en la epidural), espacio epidural, dura y aracnoideas hasta el espacio subaracnoideo (LCR fluye). En el adulto la médula termina en L1–L2: puncionar en L3–L4 o por debajo es la regla de seguridad.",
        "La identificación del espacio es un reflejo aprendido con la mano, no con los ojos: el ligamento amarillo se reconoce por su resistencia y el LCR confirma el subaracnoideo. Detalles de seguridad: posición fetal bien hecha (flexión sin inclinar el eje), contar los niveles desde la cresta ilíaca (L4), aguja con introductor si es fina, retirar y recolocar si aparece dolor o parestesia, y en anticoagulados seguir la pauta ASRA (ver «Bloqueos y anticoagulación»). La cefalea postpunción dura se sospecha al sentarse al paciente y se trata en secuencia: analgesia, hidratación, cafeína y parche epidural de sangre si es invalidante."
    ),
    RefImage(
        "img_pos_supino.jpg",
        "Decúbito supino: almohadillado",
        "Puntos de apoyo y protección",
        "Posicionamiento supino operatorio visto desde arriba: cabeza con apoyo que evita la rotación excesiva, brazos en aducción a los lados (o abducción <90° con palmas hacia arriba), almohada bajo las rodillas para flexión ligera de la cadera y la rodilla, talones descargados con almohadilla. La protección de puntos de presión (occipucio, escápulas, sacro, talones, codos) no es lujo: es prevención de lesiones que el paciente recordará más que la cirugía.",
        "Las lesiones por posicionamiento son las complicaciones «evitables» más reclamadas en anestesiología: neuropatía del cubital (el brazo que se mueve solo), compresión prolongada del plexo braquial, presión en talones y caída del brazo fuera de la mesa. Rutina de seguridad: brazos fijados SIEMPRE tras la inducción, dedos fuera del borde de la mesa (un dedo atrapado en el acoplamiento de la mesa es una amputación), ojos cerrados y protegidos con cinta en la cirugía con campo del rostro, y re-verificar el posicionamiento DESPUÉS de cada cambio de mesa (trendelenburg, rotaciones)."
    ),
    RefImage(
        "img_rcp_manos.jpg",
        "RCP: posición de manos",
        "Compresiones torácicas efectivas",
        "Rescatador realizando compresiones torácicas en un adulto sobre superficie firme: talón de la mano sobre el tercio inferior del esternón (centro del tórax, línea intermamaria), la otra mano encima con los dedos entrelazados, codos extendidos y hombros perpendiculares sobre la muñeca. Compresiones de 5–6 cm de profundidad a 100–120/min con retorno completo del tórax entre compresiones y pausas mínimas.",
        "La calidad de las compresiones es el único predictor de supervivencia modificable en la parada presenciada: la fatiga aparece a los 2 minutos y degrada la profundidad sin que el rescatador lo note — por eso los ciclos de relevo son cada 2 minutos (coincide con el ciclo de análisis del desfibrilador). La app incluye un metrónomo de compresiones en Emergencias → «RCP: esquemas dinámicos». Errores frecuentes: comprimir sobre el xifoides (lesión hepática), apoyarse en los costados (compresión ineficaz) y ventilar en exceso (la hiperinsuflación devuelve presión torácica y mata el retorno venoso)."
    ),
    RefImage(
        "img_desfibrilador.jpg",
        "Desfibrilación: colocación de parches",
        "Parches anterolateral y desfibrilador",
        "Paciente en decúbito supino con parches desfibrilables: uno bajo la clavícula derecha (borde esternal derecho) y el otro en la línea axilar media izquierda, por debajo de la axila — el eje entre ambos atraviesa el corazón. El desfibrilador conectado permite desfibrilación manual, cardioversión sincronizada o estimulación transcutánea según el modo. Los parches reemplazan el gel y las paletas: se colocan sobre piel seca y depilada si hace falta.",
        "La desfibrilación temprana es el único tratamiento del ritmo desfibrilable (FV/TV sin pulso): cada minuto sin choque resta ~7–10 % de supervivencia. Rutina de sala: desfibrilador encendido y parches colocados o alcanzables en <1 minuto en cualquier sala de anestesia. Detalles que fallan en la vida real: parches sobre apósitos, gel o desviación de ECG (chispa e incendio), oxígeno fluyendo sobre el tórax (riesgo de inflamación) y ritmo sincronizado activo cuando se desfibrila una FV (el sincronizado NO descarga en FV). En el portador de marcapasos/DAI: parches lo más lejos posible del generador y reinterrogar el dispositivo después."
    )
)

/** Los 10 temas del apartado «Imágenes» (calcId "img:<archivo>"). */
val REF_IMAGE_TOPICS: List<ClinTopic> = REF_IMAGES.map {
    ClinTopic(
        it.title,
        it.subtitle,
        "Imagen",
        listOf("Qué muestra" to it.caption, "Aplicación clínica" to it.notes),
        REF_IMG_PREFIX + it.file
    )
}

/** Carga una imagen desde assets (100 % offline) con reserva si falta el archivo. */
@Composable
fun RefImageBitmap(file: String, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val bmp = remember(file) {
        try {
            ctx.assets.open("$REF_IMG_DIR/$file").use { BitmapFactory.decodeStream(it) }
                ?.asImageBitmap()
        } catch (_: Exception) {
            null
        }
    }
    if (bmp != null) {
        Image(
            bitmap = bmp,
            contentDescription = file,
            modifier = modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp)),
            contentScale = ContentScale.FillWidth
        )
    } else {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(180.dp)
                .clip(RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "Ilustración no disponible",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/** Ruta de assets (para pruebas JVM que validan el empaquetado). */
fun refImageAssetPath(context: Context, file: String): String = "$REF_IMG_DIR/$file"
