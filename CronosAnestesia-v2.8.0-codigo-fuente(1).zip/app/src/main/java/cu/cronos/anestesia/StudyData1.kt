package cu.cronos.anestesia

/*
 * ============================================================================
 *  STUDY DATA 1/2 (v2.7.0) — Escuela de Residentes: áreas 1–6.
 *  Farmacología · Vía aérea · Anestesia general · Regional · Monitorización ·
 *  Fisiología aplicada. Cada área: 5 fichas + 6 preguntas con niveles R1–R4.
 * ============================================================================
 */

val STUDY_AREAS_1: List<StudyArea> = listOf(

    // ============================== 1. FARMACOLOGÍA ANESTÉSICA ==============================
    StudyArea(
        id = "far",
        name = "Farmacología anestésica",
        desc = "Cinética y dinámica de los fármacos del acto anestésico: hipnóticos, opioides, relajantes y su reversión.",
        cards = listOf(
            StudyCard(
                "Farmacocinética aplicada a la anestesia",
                "Estudio de qué hace el organismo con el fármaco (absorción, distribución, metabolismo, excreción). Los conceptos operativos son el volumen de distribución, el aclaramiento y la vida media sensible al contexto.",
                listOf(
                    "Vd = dosis/concentración plasmática: Vd alto = liposolubilidad alta y acumulación periférica",
                    "Aclaramiento: volumen de plasma «limpiado» por unidad de tiempo; define la velocidad de caída",
                    "Vida media de eliminación NO predice el despertar: use la vida media sensible al contexto (CSHT)",
                    "Modelos de 3 compartimentos explican la redistribución: central (V1), viscerales (V2), musculares/grasos (V3)",
                    "Fenómeno de flujo bajo: drogas con alta extracción pulmonar (propofol, lidocaína) tardan en equilibrar tras bolos repetidos"
                ),
                listOf(
                    "CSHT propofol: ~40 min tras infusión de 8 h; fentanilo: ~475 min tras 8 h (acumulación)",
                    "Tiopental: Vd 2,5 L/kg, protege al cerebro pero acumula tras bolos repetidos",
                    "Midazolam: t½ 2–4 h (doble en el anciano); diazepam t½ 20–50 h",
                    "Regla práctica: efecto del 50 % desaparece cuando el efecto sitio cae al 50 % del EC50 (C50)"
                ),
                listOf(
                    "Extrapolar la t½ de eliminación al despertar clínico (el fentanilo «corto» acumula en infusiones largas)",
                    "Olvidar ajustar por edad: el Vd y el aclaramiento cambian (anciano: hipnótico a 30–50 % de la dosis del adulto)",
                    "Dosis repetidas de tiopental o midazolam sin esperar la redistribución → despertar tardío"
                ),
                "Lo que despierta al paciente es la REDISTRIBUCIÓN y el ACLARAMIENTO, no la vida media del libro: piense en el sitio de efecto."
            ),
            StudyCard(
                "Propofol y etomidato: hipnóticos IV",
                "Propofol (alquilfenol) es el hipnótico IV de elección para inducción y TIVA; etomidato (imidazol) es el de elección en el paciente inestable por mínima depresión cardiovascular.",
                listOf(
                    "Propofol: inducción 1,5–2,5 mg/kg en 30–45 s; TIVA 4–8 mg/kg/h con opioide",
                    "Depresión cardiorrespiratoria dosis-dependiente: hipotensión y apnea frecuentes",
                    "Dolor a la inyección: vena grande, lidocaína 1 % o premezcla; emulsión lipídica: descartar a 6 h",
                    "Etomidato 0,2–0,3 mg/kg: sin analgesia, mioclonías, supresión adrenal transitoria de una dosis única",
                    "Ketamina 1–2 mg/kg: alternativa «estable»: broncodilatadora, mantiene presión (cuidado con taquicardia)"
                ),
                listOf(
                    "Propofol 70 kg: ~140–175 mg (2–2,5 mg/kg); anciano o ASA III: 1–1,5 mg/kg",
                    "Etomidato 70 kg: 14–21 mg; midazolam premedicación: 0,02–0,05 mg/kg IV",
                    "TIVA propofol: diana plasmática habitual 2,5–6 µg/mL con remifentanilo 2–8 ng/mL (TCI)",
                    "Ketamina 1 mg/kg IV: analgesia; 0,25 mg/kg: antihiperalgésico postop"
                ),
                listOf(
                    "Usar propofol a dosis completa en el hipovolémico o el anciano → colapso: titule",
                    "Inyectar propofol por vía periférica fina sin diluir ni lavar → dolor e irritación",
                    "Esperar analgesia del etomidato o la ketamina a dosis hipnótica: no dan analgesia completa sola"
                ),
                "Inestable: etomidato o ketamina titulada; estable y TIVA: propofol con opioide; el anciano siempre pide menos."
            ),
            StudyCard(
                "Relajantes neuromusculares: despolarizantes y no despolarizantes",
                "Succinilcolina (despolarizante, ultracorta) frente a rocuronio/vecuronio/atracurio/cisatracurio (no despolarizantes). La elección depende de la vía aérea, la duración y las contraindicaciones.",
                listOf(
                    "Succinilcolina 1–1,5 mg/kg: inicio 45–60 s, duración 6–10 min; fasciculaciones, hiperkalemia",
                    "Contraindicaciones de la SCh: hiperkalemia, quemaduras/trauma >48 h, parálisis prolongada, miopatías, HM previa, miotonías",
                    "Rocuronio 0,6 mg/kg (intubación 1–1,2 mg/kg RSI): 30–60 min; reversible con sugammadex",
                    "Atracurio/cisatracurio: eliminación independiente de órganos (Hofmann) → elección en renal/hepático grave",
                    "Monitorice SIEMPRE con TOF: revertir solo con T2 visible; objetivo TOF ≥0,9 antes del alta"
                ),
                listOf(
                    "SCh dosis RSI: 1,5 mg/kg (adulto 100–120 mg); onset ≈ 45 s",
                    "Rocuronio RSI 1,2 mg/kg: onset ~60 s (alternativa si SCh contraindicada) — duración 45–90 min",
                    "Sugammadex 16 mg/kg: reversión inmediata de rocuronio profundo; 2–4 mg/kg con T2",
                    "Neostigmina 0,04–0,05 mg/kg + glicopirrolato/atropina: solo con T2; máximo ~0,07 mg/kg",
                    "Bolas de K con SCh: +0,5–1 mEq/L en el sano; hasta +3–5 mEq/L en el lesionado"
                ),
                listOf(
                    "Dar SCh a un paciente inmovilizado o quemado → hiperkalemia y paro: pregunte cuándo perdió la movilidad",
                    "Revertir un bloqueo profundo con neostigmina (sin T2) → bloqueo residual y debilidad: espere T2 o use sugammadex",
                    "Confundir fasciculaciones con convulsiones o confundir rigidez de SCh con HM incipiente"
                ),
                "Vía aérea difícil + SCh contraindicada = rocuronio 1,2 mg/kg con sugammadex listo; TOF siempre antes de revertir."
            ),
            StudyCard(
                "Opioides perioperatorios: equianalgesia y remifentanilo",
                "Los opioides completan la hipnosis, atenúan la respuesta al estímulo y dan analgesia. La seguridad perioperatoria exige conocer la equianalgesia, el techo de efectos y los fármacos que NO acumulan.",
                listOf(
                    "Fentanilo: potente (100× morfina), rápida titulación; acumula en infusión prolongada",
                    "Remifentanilo: metabolismo por esterasas — el más predecible; TIVA 0,05–0,3 µg/kg/min",
                    "Morfina: metabolito M6G activo (acumula en renal); hidromorfona y fentanilo preferibles en renal",
                    "Hiperanalgesia por remifentanilo: planear analgesia multimodal ANTES de terminar",
                    "Antagonista: naloxona 0,04 mg titulada — duración menor que el opioide: vigilar resedación"
                ),
                listOf(
                    "Equianalgesia IV aproximada: morfina 10 mg ≈ fentanilo 100 µg ≈ hidromorfona 1,5 mg ≈ petidina 100 mg",
                    "Bolos de fentanilo en inducción: 1–2 µg/kg; mant. 0,5–2 µg/kg/h",
                    "Remi en TCI: diana 2–8 ng/mL; BET bolo = diana × V1 (la calculadora Bomba TCI lo planifica)",
                    "PCA morfina: 1 mg/bolo, candado 6–8 min; PCA fentanilo: 10–20 µg",
                    "Cuidado con petidina: normepetidina neurotóxica y serotonina con IMAO — evitar"
                ),
                listOf(
                    "Terminar una TIVA con remifentanilo sin analgesia multimodal previa → dolor explosivo y bradicardia de rebote",
                    "Dosis de rescate con duración desconocida: reevaluar cada 15 min (sedación y capnografía en no intubados)",
                    "Asumir que la naloxona «resuelve»: puede desencadenar edema agudo, taquicardia y dolor intenso — titule"
                ),
                "El remifentanilo se apaga al apagar la bomba: la analgesia la planea usted, no el opioide."
            ),
            StudyCard(
                "Reversión y bloqueo residual",
                "El bloqueo neuromuscular residual (TOF <0,9) al despertar es una causa prevenible de hipoxemia y reintubación. La reversión correcta depende del relajante y de la profundidad del bloqueo.",
                listOf(
                    "Sugammadex: encapsula a rocuronio/vecuronio (NO actúa sobre bencilisoquinolinas)",
                    "Neostigmina: inhibidor de la colinesterasa — techo de efecto y bloqueo paradoxal si el bloqueo es profundo",
                    "Bencilisoquinolinas (atracurio/cisatracurio/mivacurio): esperar + soporte; neostigmina solo con T2",
                    "Criterios de extubación neuromuscular: TOF ≥0,9, cabeza arriba 5 s, fuerza de apriete, PImax",
                    "Factores de riesgo de residual: renal, hepático, anciano, obesidad, neostigmina con TOF bajo, hipotermia, Mg"
                ),
                listOf(
                    "Sugammadex 2 mg/kg: T2 presente; 4 mg/kg: TOF 1–2; 16 mg/kg: bloqueo profundo post-bolo",
                    "Neostigmina máx 0,07 mg/kg con glicopirrolato 0,007 mg/kg o atropina 0,015 mg/kg",
                    "TOF ratio <0,9 = residual aunque el paciente «respire»: riesgo de colapso faríngeo y aspiración",
                    "Aldrete exige movimiento de extremidades; PADSS exige estabilidad y sin residual"
                ),
                listOf(
                    "Revertir «de rutina» sin TOF: la neostigmina sobre un bloqueo profundo empeora la debilidad",
                    "Dar de alta sin TOF ni criterios clínicos por prisa de sala",
                    "Confiar en «se mueve» en vez de cuantificar con TOF aceleromiográfico"
                ),
                "TOF ≥0,9 antes del alta, sin excepciones; sugammadex si el bloqueo es de rocuronio y profundo."
            )
        ),
        questions = listOf(
            StudyQuestion(
                "Paciente de 72 años, ASA III, hipovolémico por sangrado digestivo, requiere intubación urgente. ¿Cuál es la inducción más segura?",
                listOf(
                    "Propofol 2,5 mg/kg IV en bolo único",
                    "Etomidato 0,15–0,2 mg/kg titulado (o ketamina 0,5–1 mg/kg) con presión arterial vigilada",
                    "Tiopental 5 mg/kg IV",
                    "Midazolam 0,3 mg/kg IV"
                ),
                1,
                "En el paciente inestable o hipovolémico, etomidato (mínima depresión cardiovascular) o ketamina titulada son las elecciones racionales; el propofol o tiopental a dosis plena causan colapso.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "En una TIVA de 6 horas con propofol 6 mg/kg/h y fentanilo continuo, el paciente no despierta al final. La causa más probable es:",
                listOf(
                    "Dosis insuficiente de propofol",
                    "Acumulación del fentanilo (CSHT larga tras infusión prolongada) sumada al efecto del hipnótico",
                    "Hipertermia maligna subclínica",
                    "Hipoglucemia por la TIVA"
                ),
                1,
                "La vida media sensible al contexto del fentanilo tras infusiones largas supera las 4–8 h: acumula. Propofol tiene CSHT corta comparativa; por eso las TIVA modernas usan remifentanilo.",
                listOf("R2", "R3")
            ),
            StudyQuestion(
                "Contraindicación ABSOLUTA más clásica de la succinilcolina:",
                listOf(
                    "Historia de asma",
                    "Parálisis prolongada (quemadura o trauma masivo >48–72 h) con hiperkalemia esperada",
                    "Uso previo de rocuronio el día anterior",
                    "Enfermedad renal con creatinina 2 mg/dL"
                ),
                1,
                "La SCh desencadena liberación masiva de K en tejidos desinnervados o quemados >48 h: riesgo de paro hiperpotasémico. La renal aislada no contraindica la SCh (la SCh no se acumula en renal).",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "TOF con T2 presente tras rocuronio, cirugía terminada. Reversión adecuada:",
                listOf(
                    "Sugammadex 16 mg/kg",
                    "Neostigmina 0,05 mg/kg con glicopirrolato, con objetivo de TOF ≥0,9",
                    "Nada: el paciente se mueve",
                    "Doxapram"
                ),
                1,
                "Con T2 presente, la neostigmina con anticolinérgico es adecuada (y costo-efectiva); sugammadex 16 mg/kg está indicado en bloqueo PROFUNDO post-bolo. «No revertir» deja riesgo de residual.",
                listOf("R2", "R3")
            ),
            StudyQuestion(
                "Equianalgesia más próxima: 100 µg de fentanilo IV equivalen a:",
                listOf(
                    "1 mg de morfina IV",
                    "10 mg de morfina IV",
                    "100 mg de petidina VO",
                    "0,1 mg de buprenorfina"
                ),
                1,
                "Fentanilo es ~100 veces más potente que la morfina: 100 µg ≈ 10 mg de morfina IV. Este orden de magnitud previene sobredosis al rotar fármacos.",
                listOf("R1", "R2", "R3")
            ),
            StudyQuestion(
                "Caso: 45 años, obesidad IMC 42, TIVA con remifentanilo para laparoscopía, terminada hace 5 min, dolor intenso (EVA 9). Conducta inicial:",
                listOf(
                    "Bolo único de morfina 0,15 mg/kg y reevaluar en 30 min",
                    "Analgesia multimodal inmediata: fentanilo titulado + paracetamol/AINE + bloqueo local si aplica, planeada ANTES de terminar la infusión",
                    "Aumentar propofol para «sedarlo del dolor»",
                    "Naloxona para corregir la hiperanalgesia"
                ),
                1,
                "El remifentanilo desaparece en minutos: la analgesia debe plantearse multimodal y anticipada. La morfina sola tarda; el propofol solo seda; la naloxona agravaría el dolor.",
                listOf("R3", "R4")
            )
        ),
        bibliography = listOf(
            "Morgan GE, Mikhail MS, Murray MJ. Clinical Anesthesiology, 7.ª ed., capítulos de farmacología (2022).",
            "Sneyd JR, Absalom AR. Anaesthesia & intensive care medicine: TIVA y farmacocinética clínica (revisión periódica).",
            "Murphy GS, Brull SJ. Residual neuromuscular block: lessons unlearned. Anesth Analg. 2010;111(1):189-194.",
            "Ficha técnica (epígrafe) del propofol, etomidato, succinilcolina, rocuronio y sugammadex (SPUMED/Cubafarma según disponibilidad)."
        )
    ),

    // ============================== 2. VÍA AÉREA ==============================
    StudyArea(
        id = "via",
        name = "Vía aérea",
        desc = "Evaluación, manejo y rescate: de la laringoscopia rutinaria al CICO y la cricotiroidotomía.",
        cards = listOf(
            StudyCard(
                "Evaluación preoperatoria de la vía aérea",
                "La predicción de laringoscopia difícil combina historia, exploración y pruebas morfológicas. Ningún test aislado basta: se combinan (LEMON/Wilson).",
                listOf(
                    "Mallampati modificado (III–IV), apertura bucal <3 cm, tiro-mentoniana <6 cm",
                    "LEMON: Look, Evaluate 3-3-2, Mallampati, Obstrucción, Movilidad cervical",
                    "Historia: ronquera, stridor, radioterapia, apnea del sueño, intubaciones previas difíciles",
                    "Anote SIEMPRE el grado de Cormack-Lehane de cada laringoscopia en el expediente",
                    "Vía aérea «oculta»: embarazadas, ancianos edéntulos (mejora con reubicación), OSA"
                ),
                listOf(
                    "3-3-2: apertura 3 dedos, suelo mentón-laríngea 3, base mentón-hioidea 2",
                    "Distancia esternomentoniana <12,5 cm: extensión cervical limitada",
                    "Wilson: peso, movilidad cervical, mentón retruido, dientes prominentes, maloclusión",
                    "Stridor en inspiración = obstrucción extratorácica: NO sedar sin equipo y plan"
                ),
                listOf(
                    "Asumir vía aérea normal porque «Mallampati I» — no mira movilidad ni historia",
                    "No mirar el expediente previo: la intubación difícil previa es el mejor predictor",
                    "Olvidar aspiración gástrica: Mallampati no mide riesgo de vacío (perlas/ayuno)"
                ),
                "Vía aérea = historia + LEMON + expediente previo; el Mallampati aislado no predice nada."
            ),
            StudyCard(
                "Secuencia de intubación rápida (RSI)",
                "Preoxigenación agresiva + hipnótico a dosis plena + relajante de onset rápido + presión cricoidea + intubación con tubo con manguito, SIN ventilación con máscara si hay vacío gástrico.",
                listOf(
                    "Preoxigenar 3 min O2 100 % (o 8 capacidades vitales) + O2 nasal apneico durante la laringoscopia",
                    "Rampa 25–30° en obesos/embarazadas: mejora la visión y la reserva de FRC",
                    "Hipnótico a dosis plena (propofol 2–2,5 mg/kg o etomidato) + SCh 1,5 mg/kg o rocuronio 1,2 mg/kg",
                    "Presión cricoidea (Sellick): 30 N hasta confirmar el tubo; relajar si el paciente vomita activamente",
                    "Confirmar con capnografía continua (6 curvas) — la SpO2 no confirma posición"
                ),
                listOf(
                    "Tiempo de apnea segura: ~3–4 min en el sano preoxigenado; 1–2 min en embarazada/obesa/niño",
                    "SCh onset 45–60 s; rocuronio 1,2 mg/kg onset ~60 s",
                    "Objetivo PaO2 tras preoxigenación: FAO2 ~0,87 → apnea segura prolongada",
                    "ATLS/APLS: RSI en trauma con inmovilización cervical y presión cricoidea"
                ),
                listOf(
                    "Ventilar con máscara «para ganar tiempo» en el paciente de vacío → distensión gástrica y aspiración",
                    "Hipoxemia en RSI: en vez de oxigenar por máscara, reposicionar la laringoscopia y O2 nasal apneico",
                    "Presión cricoidea en vomito activo: puede romper el esófago — suéltela"
                ),
                "RSI: preoxígena 3 min, rampa, dosis plenas, capnografía; y si no entra, plan de rescate ANUNCIADO."
            ),
            StudyCard(
                "Máscaras laríngeas y ventilación supraglótica",
                "Dispositivos supraglóticos (SLM) que asientan alrededor de la laringe: alternativa y rescate de la intubación en anestesia general y en el algoritmo de vía aérea difícil.",
                listOf(
                    "Ventilación de rescate en el algoritmo ASA: intubación fallida → SLM → despierto/abrir",
                    "Tamaños: 3 (30–50 kg), 4 (50–70 kg), 5 (70–100 kg) para la clásica; reusables con calibración",
                    "Presión del manguito <60 cmH2O para evitar daño de mucosa y nervio",
                    "Contraindicaciones relativas: vacío gástrico, cirugía intraabdominal alta, obesidad extrema, laparoscopía prolongada",
                    "ProSeal/i-gel: canal gástrico para despresurizar el estómago"
                ),
                listOf(
                    "Volumen de inflado típico: máx 30 mL (talla 4); fuga al ventilar: revise tamaño/posición",
                    "Profundidad de inserción: cuello del dispositivo a los incisivos; airway tutor: balón a nivel",
                    "Con SLM se puede pasar tubo (fibro/visión) si está diseñada para intubación (Fastrach/ILMA)",
                    "En pediatría: talla por peso — 1 (<5 kg), 1,5 (5–10), 2 (10–20), 2,5 (20–30), 3 (30–50)"
                ),
                listOf(
                    "Usar SLM en un paciente de estómago lleno sin canal gástrico ni plan de rescate",
                    "Sobreinflar el manguito «para sellar»: necrosis y neuralgia; si fuga, reposicione o cambie talla",
                    "Dejar la SLM sin vigilancia tras el alta a la sala: puede migrar y obstruir"
                ),
                "La SLM es rescate y alternativa: en vacío gástrico solo con canal gástrico y plan B listo."
            ),
            StudyCard(
                "Vía aérea difícil y CICO: el algoritmo y el rescate quirúrgico",
                "Intubación fallida + ventilación fallida = CICO (cannot intubate, cannot oxygenate): declarar en voz alta y avanzar a acceso frontolateral (cricotiroidotomía) sin demoras.",
                listOf(
                    "Algoritmo: plan A (laringoscopía óptica) → plan B (SLM) → plan C (despertar) → plan D (acceso quirúrgico)",
                    "Límite clásico: SpO2 90 % tras 3 intentos por operador capacitado = detener y cambiar de plan",
                    "Cricotiroidotomía con cánula grande o kit de aguja + oxigenación transtraqueal (jet 1 s en 4 s)",
                    "Preparación anticipada: equipo de vía aérea difícil, tubo 2 tamaños, guía/buji, videolaringoscopio, fibro",
                    "Llama en voz alta: «Vía aérea difícil» — pide ayuda, fija el plan, nombrara a quién pide cada cosa"
                ),
                listOf(
                    "Membra cricotiroidea: cricoides 4–6 cm bajo el cartílago tiroides; mejor con eco si hay tiempo",
                    "Jet de oxígeno transtraqueal: 1,4 bares, 1 s de insuflación, 4 s de exhalación (riesgo de barotrauma si no exhala)",
                    "Videolaringoscopio: mejora la vista, no siempre el paso del tubo — tenga bujía",
                    "Despertar: si SpO2 desciende y no hay plan C exitoso, despertar al paciente y reevaluar con analgesia local"
                ),
                listOf(
                    "Repetir la misma laringoscopía «una vez más» sin cambiar operador, dispositivo ni posición",
                    "Retrasar la cricotiroidotomía por buscar el fibrobroncoscopio en la crisis (desatención mortal)",
                    "No declarar el CICO en voz alta: el equipo no sabe que hay que cambiar de plan"
                ),
                "Tres intentos, tres cambios de dispositivo: si no hay oxígeno, anuncie CICO y opere el cuello."
            ),
            StudyCard(
                "Extubación y protección post-extubación",
                "La extubación planificada (despierto vs profunda) con criterios y plan de rescate: la mitad de las complicaciones de vía aérea suceden DESPUÉS de la cirugía.",
                listOf(
                    "Criterios: TOF ≥0,9, responde a órdenes, fuerza de cabeza/apego, volumen y presión suficientes, sin re-sangrado",
                    "Despierta: menor riesgo de aspiración; profunda: menos broncoespasmo/laringoespasmo (elección según riesgo)",
                    "Preparar máscara, O2, SCh/sugammadex, aspirador y operador presente antes de retirar",
                    "Post-extubación: oxígeno nasal, vigilancia de estridor (diferencia de >25 % entre inspiración/espiración)",
                    "Estridor: dexametasona 0,1–0,2 mg/kg (anticipada) y/o nebulización de adrenalina (1 mg en 5 mL)"
                ),
                listOf(
                    "Leak test en pediatría: fuga a 20–30 cmH2O indica edema aceptable para extubar",
                    "Después de cirugía de cuello/tiroides: hematoma → abrir la herida en la cama si hay distress",
                    "Laringoespasmo: 100 % O2 + presión continua + propofol 0,5–1 mg/kg; SCh 0,5–1 mg/kg si no cede",
                    "Extubación tardía o transferencia con TOF desconocido = riesgo de residual"
                ),
                listOf(
                    "Extubar «de pasada» sin operador en la habitación ni aspirador conectado",
                    "Ignorar el estridor postoperativo hasta la desaturación (el estridor es el aviso)",
                    "Extubar profunda en el paciente de estómago lleno o con reflejos deprimidos"
                ),
                "Plan de extubación = plan de intubación: criterios, operador, equipo de rescate a mano y vigilancia del estridor."
            )
        ),
        questions = listOf(
            StudyQuestion(
                "Paciente de 30 años, embarazada de 38 semanas, programada para cesárea urgente con estómago lleno. Componentes de la RSI correctos:",
                listOf(
                    "Preoxigenación 3 min + rampa + cricoidea + SCh 1,5 mg/kg + capnografía",
                    "Ventilación previa con máscara para asegurar la oxigenación",
                    "Inducción con propofol a dosis reducida (1 mg/kg) para evitar depresión fetal",
                    "Uso de SLM de segunda generación como plan inicial"
                ),
                0,
                "La RSI clásica: preoxigenación, rampa, presión cricoidea, hipnótico a dosis plena, SCh, capnografía. Ventilar con máscara distiende el estómago; la SLM no protege del vacío.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "Laringoscopía fallida en 2 intentos por operador experto, SpO2 93 % con O2 nasal, máscara difícil. Siguiente paso:",
                listOf(
                    "Tercer intento con la misma hoja",
                    "Inserción de SLM (rescate supraglótico) mientras se prepara el plan D",
                    "Cricotiroidotomía inmediata",
                    "Despertar al paciente ahora mismo"
                ),
                1,
                "El algoritmo: si falla la laringoscopía, rescate supraglótico (SLM) mientras se prepara el plan quirúrgico; cricotiroidotomía solo con CICO real (sin oxigenación con SLM).",
                listOf("R2", "R3")
            ),
            StudyQuestion(
                "Signo más temprano de vía aérea obstruida tras extubación:",
                listOf(
                    "Desaturación a 90 %",
                    "Estridor inspiratorio audible",
                    "Taquicardia",
                    "Agitación aislada"
                ),
                1,
                "El estridor precede a la desaturación: es el aviso. La conducta es O2 + nebulización de adrenalina + dexametasona y vigilancia estrecha; no esperar a la SpO2.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "Paciente con historia de intubación difícil (Cormack III previo) programado para colecistectomía. Estrategia electiva más segura:",
                listOf(
                    "RSI con SCh y laringoscopía directa estándar",
                    "Intubación despierta con fibrobroncoscopio o planificación anticipada (videolaringoscopio + ayuda + equipo)",
                    "Sedar y probar «con suerte»",
                    "Máscara laríngea para toda la cirugía"
                ),
                1,
                "La intubación difícil previa obliga a plan anticipado: fibro despierto o videolaringoscopio con ayuda y equipo. Improvisar con SCh en vía aérea conocida difícil es peligroso.",
                listOf("R3", "R4")
            ),
            StudyQuestion(
                "Presión cricoidea correcta durante la RSI:",
                listOf(
                    "10–20 N hasta la intubación",
                    "30 N desde la preoxigenación hasta confirmar el tubo; se suelta si hay vómito activo",
                    "60 N constante para sellar mejor",
                    "Solo durante el paso del tubo"
                ),
                1,
                "30 N (≈3 kg) es la presión recomendada; puede aplicarse desde la preoxigenación si el paciente coopera, y se SUELTA si vomita activamente (riesgo de rotura esofágica).",
                listOf("R2")
            ),
            StudyQuestion(
                "Jet de oxígeno transtraqueal correcto para el rescate de CICO:",
                listOf(
                    "1 s de insuflación y 4 s de exhalación (riesgo de barotrauma si no exhala)",
                    "Insuflación continua de 30 s",
                    "1 s cada 10 s",
                    "Flujo de 2 L/min continuo"
                ),
                0,
                "El jet transtraqueal (1 s en 4 s) ventila si la vía aérea superior permite exhalación; la insuflación continua causa barotrauma y neumotórax a tensión.",
                listOf("R3", "R4")
            )
        ),
        bibliography = listOf(
            "Apfelbaum JL et al. Practice Guidelines for Management of the Difficult Airway (ASA). Anesthesiology 2013;118(2):251-270.",
            "Frerk C et al. Difficult Airway Society 2015 guidelines: management of unanticipated difficult intubation. Br J Anaesth. 2015;115(6):827-848.",
            "Hagberg CA. Airway Management (Benumof), 5.ª ed., 2024.",
            "Bhat R, Dubey L. Manual de vía aérea difícil para residentes (texto de referencia en español)."
        )
    ),

    // ============================== 3. ANESTESIA GENERAL ==============================
    StudyArea(
        id = "age",
        name = "Anestesia general",
        desc = "Inducción, mantenimiento con volátiles o TIVA, profundidad y despertar: el núcleo diario de la especialidad.",
        cards = listOf(
            StudyCard(
                "Inducción y mantenimiento: decisiones de inicio",
                "La inducción define el tono del acto anestésico: elección de hipnótico, opioide, relajante y plan de vía aérea, con vigilancia de la respuesta hemodinámica.",
                listOf(
                    "Titule la inducción en ASA III–IV: dosis divididas, vigilando PA y HR antes de avanzar",
                    "Mantenimiento: volátil (sevo/desflurano con MAC 1–1,3) o TIVA (propofol + opioide)",
                    "La respuesta al estímulo (intubación, incisión) se atenúa con opioide: 1–2 µg/kg de fentanilo",
                    "Alcanzar MAC estable antes de la incisión; ajustar por edad (MAC baja ~6 %/década)",
                    "Perfil de riesgo: hipotensión de inducción más frecuente con propofol + opioide + edad avanzada"
                ),
                listOf(
                    "MAC: sevo 2,0 %, iso 1,15 %, desflurano 6 %; MAC-BAR ~1,5 MAC bloquea respuesta adrenérgica",
                    "En TIVA: diana propofol 2,5–6 µg/mL con remifentanilo 2–8 ng/mL (TCI, calculadora de la app)",
                    "Pentotal 4 mg/kg vs propofol 2,5 mg/kg: horizontes de despertar similares en el sano",
                    "Límites de presión: en hipertensos crónicos mantener PA basal ±10–20 %"
                ),
                listOf(
                    "Inducir rápido en el hipovolémico sin prehidratar ni titular",
                    "Sobreopioidar en la inducción y luego quedar con apnea prolongada en anestesia local",
                    "Olvidar la analgesia de línea base (paracetamol/AINE/bloqueo) y quedarse solo con opioide"
                ),
                "Inducir con titulación y objetivo hemodinámico: cada bolo siguiente espera la lectura del monitor."
            ),
            StudyCard(
                "Volátiles: MAC, solubilidad y efectos",
                "Los halogenados ofrecen hipnosis controlable por espirómetro. MAC, coeficiente sangre/gas y flujo del circuito definen la velocidad y el fin de la anestesia.",
                listOf(
                    "MAC = concentración alveolar que inmóviliza al 50 % ante estímulo; MAC 1,2–1,3 evita movimiento en el 95 %",
                    "Solubilidad baja (sevo 0,65, desflurano 0,42) = lavado rápido; N2O MAC 104 % no es anestésico solo",
                    "Desflurano: requiere vaporizador presurizado; sube taquicardia si aumenta bruscamente",
                    "Sevoflurano + cal sodada seca: compuesto A (precaución en flujos <1 L/min prolongados)",
                    "El MAC baja ~6 % por década de edad; baja con hipotermia, prematuros, opioide, embarazo"
                ),
                listOf(
                    "MACAwake ~0,3–0,4 MAC; MAC-BAR ~1,5 MAC",
                    "Sevo: coeficiente sangre/gas 0,65; iso 1,4; halotano 2,4 (obsoleto, hepatotóxico)",
                    "FEV del volátil con flujo bajo: la fracción inspirada ≈ espirada tarda 15–20 min en equilibrar",
                    "FiO2 mínima 30 % cuando hay N2O (evita hipoxia de difusión al apagar)"
                ),
                listOf(
                    "Confiar en el diafragma del vaporizador a flujo bajo sin esperar el equilibrio",
                    "Usar N2O en neumotórax, obstrucción intestinal o cirugía de oído (expansión de espacios cerrados)",
                    "Atribuir toda la hipotensión al volátil sin revisar sangrado o profundidad"
                ),
                "MAC por edad y solubilidad: el desflurano despierta rápido, el sevo es suave, el N2O es adyuvante no anestésico."
            ),
            StudyCard(
                "TIVA y TCI: propofol + remifentanilo",
                "Anestesia total intravenosa con propofol y remifentanilo guiada por diana (Cp o Ce) con esquema BET: planificable con la calculadora Bomba TCI de esta app.",
                listOf(
                    "Diana habitual: propofol 2,5–6 µg/mL; remifentanilo 2–8 ng/mL (ajuste por edad y ASA)",
                    "Diana de efecto (Ce) evita el overshoot plasmático; la Ce alcanza el 90 % en ln(10)/ke0 minutos",
                    "BET: bolo = diana × V1, velocidad que decae exponencialmente — la bomba TCI la resuelve cada 10 s",
                    "Ventajas: menos PONV, útil en MHS, mejor en vía aérea compartida y neurocirugía",
                    "Riesgos: bolus accidental al cambiar jeringa, desconexión, cansancio de bomba — doble chequeo"
                ),
                listOf(
                    "Schnider (propofol): V1 4,27 L, Cl1 1,89 L/min ajustado por edad; Marsh solo por peso",
                    "Minto (remifentanilo): usa LBM de Janmahasatian; ke0 0,595−0,007×(edad−40)",
                    "Ce 90 %: propofol (Schnider) ~5 min; remifentanilo (Minto) ~4 min",
                    "Al terminar: cambiar a propofol sedante (25–50 µg/kg/min) si la cirugía continúa; apagar el remi y planear analgesia"
                ),
                listOf(
                    "Cambiar la jeringa sin pausar la bomba y sin puente → bolo accidental o hipnosis perdida",
                    "Ajustar la diana «a ojo» sin capnografía ni monitor de profundidad en TIVA pura",
                    "Olvidar que el remifentanilo no da analgesia postoperatoria: planear multimodal antes"
                ),
                "TIVA = diana + tiempo: la Ce sube exponencialmente; use la calculadora TCI para enseñar los números."
            ),
            StudyCard(
                "Monitorización de profundidad: BIS, TOF y clínica",
                "La profundidad anestésica se juzga con clínica + MAC + BIS/entropía + TOF. El objetivo: evitar despertar intraoperatorio y sobredosificación.",
                listOf(
                    "BIS 40–60: hipnosis adecuada para cirugía general; 60–75: sedación; >75 con estímulo: riesgo de recuerdo",
                    "El BIS es engañoso con ketamina, N2O, midazolam solo, hipotermia o artefactos electromecánicos",
                    "TOF mide el bloqueo neuromuscular, no la hipnosis; el «TOF sin movimiento» no garantiza anestesia",
                    "La combinación MAC + BIS + TOF + hemodinámica reduce el riesgo de despertar",
                    "Documente valores y eventos: el expediente con registro en la app apoya la auditoría"
                ),
                listOf(
                    "Riesgo de recuerdo: 0,1–0,2 % general; 0,4–1 % en cardiacas, obstétricas y trauma con hipnosis inadecuada",
                    "Prevención de recuerdo: ≥0,7 MAC o BIS 40–60 en TIVA; amortiguar la inducción (opioide) en RSI",
                    "Procesamiento EEG: la anestesia produce patrones (alfa frontal, ondas lentas) que el BIS comprime a un número",
                    "EMG elevada puede falsamente elevar el BIS: revisar relajante y electrodos"
                ),
                listOf(
                    "Dejar MAC <0,7 + BIS >70 con estímulo quirúrgico intenso: recuerdo posible",
                    "Confundir despertar intraoperatorio con «recordar la conversación de la sala» (sedación de prequirófano)",
                    "Ajustar el anestésico por el BIS sin revisar el estímulo ni la hemodinámica"
                ),
                "BIS 40–60, MAC ≥0,7, TOF vigilado: tres capturas cruzadas evitan el recuerdo y la sobredosis."
            ),
            StudyCard(
                "Despertar intraoperatorio: prevención y conducta",
                "Recuerdo con o sin dolor durante la anestesia general. Raro, grave, prevenible: riesgo conocido en cesárea, cardiacas, trauma, obesidad y TIVA mal manejada.",
                listOf(
                    "Factores: hipnosis inadecuada por necesidad reducida (shock, prematuridad), equipos o diluciones erradas, uso de relajante sin hipnótico suficiente",
                    "La RSI con relajante exige hipnótico a dosis plena y MAC ≥0,7 pronto",
                    "Prevención en TIVA: diana y vigilancia (BIS) + capnografía; documentar cambios de jeringa",
                    "Si el paciente refiere recuerdo: escuchar, disculparse, derivar a psicología y documentar; revisar el caso",
                    "El recuerdo explícito con dolor tiene secuelas de TEPT: tratarlo como evento adverso serio"
                ),
                listOf(
                    "Incidente clásico: vaporizador vacío o apagado (revisar al inicio y a mitad)",
                    "En cesárea con volátil: MAC 0,75–1 con N2O 50 % mantiene hipnosis sin depresión fetal excesiva",
                    "En trauma hipovolémico: la MAC efectiva baja — hipnosis con propofol titulado + opioide",
                    "Registro del expediente con eventos ayuda al análisis del caso"
                ),
                listOf(
                    "Restar hipnosis «porque el BIS dice 50» cuando hay artefacto (cauterio, marcapasos)",
                    "Ajustar propofol por peso TOTAL en obesidad extrema (usar IBW/ajustado; app: calculadora peso ideal)",
                    "Comunicar mal al paciente tras el incidente: el silencio multiplica el daño psicológico"
                ),
                "Prevención: hipnosis suficiente para el estímulo (MAC/BIS), doble chequeo de jeringas y registro; conducta: escuchar y derivar."
            )
        ),
        questions = listOf(
            StudyQuestion(
                "MAC del sevoflurano en un adulto de 30 años y su comportamiento en un paciente de 80:",
                listOf(
                    "2,0 %; en el anciano baja ~15–20 %",
                    "1,15 %; en el anciano sube",
                    "6 %; igual en cualquier edad",
                    "0,65 %; no cambia con la edad"
                ),
                0,
                "MAC sevo ≈ 2,0 % y desciende ~6 % por década: en el octogenario, ~1,5–1,7 %. Este ajuste evita sobredosificación.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "En TIVA con remifentanilo, el tiempo hasta Ce ≥ 90 % (t90) depende de:",
                listOf(
                    "El aclaramiento hepático del remifentanilo",
                    "La ke0: t90 = ln(10)/ke0 (≈ 4 min en Minto)",
                    "El peso del paciente",
                    "La concentración de la jeringa"
                ),
                1,
                "La Ce asciende como diana×(1−e^(−ke0·t)): alcanza el 90 % a ln(10)/ke0. La calculadora Bomba TCI de la app lo muestra.",
                listOf("R2", "R3")
            ),
            StudyQuestion(
                "BIS 75 con MAC 0,6 en un paciente sin relajante durante laparotomía. Conducta más segura:",
                listOf(
                    "Continuar: el BIS no importa si el paciente no se mueve",
                    "Aumentar hipnosis (MAC ≥0,7 / diana propofol) y revisar estímulo y analgesia",
                    "Dar relajante adicional",
                    "Disminuir el volátil"
                ),
                1,
                "BIS 75 + MAC 0,6 = hipnosis insuficiente: riesgo de recuerdo. Aumentar hipnosis y revisar analgesia; el relajante no cura la hipnosis insuficiente.",
                listOf("R2", "R3")
            ),
            StudyQuestion(
                "El mayor factor de riesgo de despertar intraoperatorio en cesárea con anestesia general:",
                listOf(
                    "Uso de N2O",
                    "Hipnosis insuficiente para equilibrar MAC reducida, vía aérea compartida y urgencia",
                    "Dosis de relajante",
                    "Uso de sevoflurano"
                ),
                1,
                "El recuerdo en cesárea se asocia a hipnosis inadecuada (MAC baja, hipotensión, inducción a dosis reducida). Mantener MAC ≥0,7–0,75 con volátil o TIVA vigilada.",
                listOf("R3")
            ),
            StudyQuestion(
                "El vaporizador está vacío a mitad de una cirugía de 3 h. Medida inmediata y luego:",
                listOf(
                    "Añadir N2O y continuar",
                    "Sustituir el vaporizador o cambiar a TIVA con propofol, mantener hipnosis ≥0,7 MAC equivalente y documentar el evento",
                    "Subir el flujo de O2",
                    "Terminar la cirugía"
                ),
                1,
                "Primero restituir la hipnosis (recambio de vaporizador o TIVA) y vigilar profundidad; luego documentar y reportar el evento (seguridad del paciente).",
                listOf("R2", "R3")
            ),
            StudyQuestion(
                "Paciente obeso IMC 45, TIVA con propofol. La dosis de inducción debe calcularse con:",
                listOf(
                    "Peso total (TBW)",
                    "Peso ideal o peso ajustado (titulado), no el peso total",
                    "Peso del expediente anterior",
                    "Peso − 20 kg"
                ),
                1,
                "En obesidad, la inducción con propofol se dosifica por peso ajustado/IBW titulado; el TBW sobre-dosa. La app tiene la calculadora de peso ideal/ajustado.",
                listOf("R2", "R3")
            )
        ),
        bibliography = listOf(
            "Miller RD et al. Miller's Anesthesia, 10.ª ed., capítulos de anestesia general inhalatoria y TIVA (2024).",
            "Absalom AR, De Keyser R, Struys MMRF. Target controlled infusion: a mature technology. Anesth Analg. 2016;122(1):70-78.",
            "Mashour GA et al. Prevention of intraoperative awareness in a protocol of BIS. NEJM. 2011;365(7):591-600.",
            "Prys-Roberts C. MAC: definición y uso clínico (revisión clásica)."
        )
    ),

    // ============================== 4. ANESTESIA REGIONAL ==============================
    StudyArea(
        id = "reg",
        name = "Anestesia regional",
        desc = "Neuraxial y periférico: indicaciones, dosis máximas, complicaciones graves y su manejo.",
        cards = listOf(
            StudyCard(
                "Raquianestesia: nivel, dosis y efectos",
                "Anestesia neuraxial subaracnoidea: bloqueo denso, rápido y predecible para cirugía infraumbilical y obstétrica; los efectos dependen de nivel, barra, dosis y baricidad.",
                listOf(
                    "Objetivo sensitivo T4–T6 (cesárea) o T8–T10 (cirugía infraumbilical)",
                    "Bupivacaína hiperbárica 0,5 %: 10–15 mg (cesárea 10–12 mg); hipobárica/isobárica según plan",
                    "Hipotensión por simpaticolisis: prevenir con volumen, vasopresor (efedrina/fenilefrina) y vigilancia",
                    "Bradicardia y paro por bloqueo alto (apnea por bloqueo C3–C5 y taquicardia de mamífero)",
                    "Adyuvantes: fentanilo 15–25 µg (calidad), morfina 0,1–0,2 mg (analgesia prolongada)"
                ),
                listOf(
                    "Cefalea post-punción: 1–3 % con aguja punta-lápiz 25–27 G; sello epidural si no cede",
                    "Hematoma epidural: riesgo <1:150 000 — vigilancia de déficit motor tras el bloqueo",
                    "El bloqueo sube ~6 dermatomas en el embarazo a término con la misma dosis",
                    "Vasopresor de elección obstétrica: fenilefrina 50–100 µg bolos o 0,25–1 µg/kg/min"
                ),
                listOf(
                    "Dosificar la raqui «por kg» sin considerar estatura, edad y embarazo",
                    "Ignorar la hipotensión y dar solo líquidos: el vasopresor es el tratamiento principal",
                    "No vigilar la resolución: alta con bloqueo motor presente"
                ),
                "Raqui: dosis por objetivo dermatómico, vasopresor listo, vigilancia de nivel y de resolución."
            ),
            StudyCard(
                "Epidural y combinada: catéter y analgesia continua",
                "Anestesia/analgesia epidural con catéter: titulable, útil en trabajo de parto, cirugía infraumbilical y analgesia postoperatoria; la combinada espinal-epidural (CSE) suma inicio rápido + continuo.",
                listOf(
                    "Carga epidural: 1,5 mL por dermatoma + 4 mL (calculadora de la app); fraccionar 5 mL cada vez",
                    "Lidocaína 2 % con epinefrina para cirugía; bupivacaína/ropivacaína 0,125–0,2 % para analgesia",
                    "Testigo: 3 mL de lidocaína 2 % + epi 1:200 000 (15 µg) descarta intravascular e intratecal",
                    "Top-up 6–10 mL c/2–4 h o infusión 6–10 mL/h (bupi 0,125 % + fentanilo 2 µg/mL)",
                    "Nivel analgésico T10 para parto; T6–T8 para cirugía"
                ),
                listOf(
                    "Máximos de anestésico local sin/con epinefrina: lidocaína 5/7 mg/kg; bupivacaína 2,5/3 mg/kg; ropivacaína 3/3,5 mg/kg",
                    "Fentanilo epidural 50–100 µg en bolo; sufentanilo 10–15 µg en parto",
                    "Retiro del catéter con criterios ASRA: anticoagulante esperado 24–72 h según fármaco",
                    "Epidural torácica postoperatoria: infusión T7–T10, vigilancia de retención urinaria y hipotensión"
                ),
                listOf(
                    "Inyectar la carga completa de una vez (intraarterial o intratecal): fraccionar SIEMPRE",
                    "Forzar el catéter al retirarlo (puede cortarse): consulta ASRA antes",
                    "Confundir bloqueo subdural (lento, asimétrico) con «epidural fallida» y volver a puncionar"
                ),
                "Epidural: testigo, fraccionamiento, dosis máximas y criterios ASRA para el catéter."
            ),
            StudyCard(
                "Bloqueos periféricos: ecografía y dosis",
                "Bloqueo ecoguiado de plexo y nervios periféricos: analgesia excelente con mínima depresión sistémica; exige dominio de anatomía, dosis máxima e inyección intraneural.",
                listOf(
                    "Interscaleno (hombro/clavícula), supraclavicular (brazo), axilar (mano), femoral/ciático (rodilla/pie)",
                    "Sagital oblicuo TAP/rectus (pared abdominal), Pecs I/II (mama), paravertebral (torácica)",
                    "Inyección: 0,1–0,3 mL/kg por objetivo, fraccionada cada 5 mL con aspiración",
                    "Los bloqueos mayores (interescaleno, paravertebral) pueden bloquear el frénico — ojo en EPOC",
                    "Adyuvante habitual: dexamedetomidina 50–100 µg o dexametasona 4–8 mg prolongan el bloqueo"
                ),
                listOf(
                    "Ropivacaína 0,375–0,5 %: 20–40 mL según el bloqueo; máximo 3 mg/kg",
                    "Bupivacaína 0,25–0,5 %: máx 2,5–3 mg/kg (con epi 3 mg/kg) — calculadora Anestésico local en la app",
                    "Lidocaína 1–1,5 %: máx 5–7 mg/kg; mepivacaína 4–7 mg/kg",
                    "Catéter periférico continuo: ropivacaína 0,2 % a 5–10 mL/h, vigilancia de LAST y de fuerza"
                ),
                listOf(
                    "Inyectar con alta presión (>15 psi) o con parestesia persistente: riesgo intraneural",
                    "Exceder la dosis máxima al combinar múltiples bloqueos (contar TODOS los mL)",
                    "Bloquear interescaleno en EPOC severo sin advertir la parálisis frénica"
                ),
                "Ecografía + dosis máxima contada + inyección fraccionada baja presión: el bloqueo seguro."
            ),
            StudyCard(
                "Toxicidad local (LAST) y protocolo de lípidos",
                "Last: toxicidad sistémica del anestésico local por inyección intravascular o sobredosis: pródromos neurológicos, convulsiones y colapso cardiovascular con arritmias refractarias.",
                listOf(
                    "Prodromos: perioral, tinnitus, agitación, somnolencia; luego convulsiones y arritmia (taquicardia ventricular, paro)",
                    "Tratamiento: LIPÍDOS 20 % 1,5 mL/kg en bolo (≈100 mL adulto) + infusión 0,25 mL/kg/min",
                    "Si persiste: repetir bolo ×1 (doble de dosis total) y subir infusión a 0,5 mL/kg/min; máx 12 mL/kg",
                    "Paro: RCP prolongada (>1 h), evitar lidocaína/bloqueadores Ca, amiodarona para VF/TV",
                    "Prevención: dosis máxima contada, testigo, ecografía, fraccionamiento, aspiración"
                ),
                listOf(
                    "Lípidos 20 %: adulto 70 kg → 105 mL bolo; luego 17,5 mL/min; bolsas disponibles en el carro",
                    "Evitar propofol como «sustituto» de lípidos (dosis lípidas insuficientes y depresión)",
                    "Vasopresina y bloqueadores de Ca: evitar en LAST (peor respuesta)",
                    "La app incluye la calculadora de dosis máxima y el protocolo en Emergencias → LAST"
                ),
                listOf(
                    "Seguir «protocolo ACLS» estándar con adrenalina a dosis altas: empeora en LAST (usar adrenalina ≤1 µg/kg bolos)",
                    "Retrasar los lípidos hasta «descartar» otras causas: en sospecha de LAST, lípidos YA",
                    "No vigilar tras el rescate: la toxicidad puede reascender (redistribución) — vigilar 12 h"
                ),
                "LAST = sospecha + lípidos 20 % inmediatos + RCP prolongada con adrenalina modesta: memorice el protocolo."
            ),
            StudyCard(
                "Coagulación y técnicas neuraxiales (ASRA)",
                "Los bloqueos neuraxiales exigen balance entre beneficio y riesgo de hematoma epidural: cronogramas ASRA por fármaco, tiempo y función renal.",
                listOf(
                    "Punción epidural/raqui requiere INR <1,5 y plaquetas ≥75 000–80 000 (según contexto)",
                    "ACOD (apixabán/rivaroxabán): 24–72 h antes según riesgo; reanudar 24 h después",
                    "Enoxaparina profiláctica: 12 h antes y 12 h después del catéter; terapéutica: 24 h",
                    "Warfarina: INR <1,5; clopidogrel 7 días antes; AAS solo NO contraindica",
                    "Catéter: retirar con los mismos criterios de espera que para puncionar"
                ),
                listOf(
                    "Heparina IV: 4–6 h + TTPa normal; re-infundar 1 h después del catéter",
                    "Dabigatrán: 72 h (ajustar por ClCr: calculadora de la app)",
                    "Síntomas de hematoma: dolor de espalda intenso, déficit motor progresivo — RM urgente + neurocirugía",
                    "Vigilar el bloqueo motor: una raqui debe resolver; si el motor persiste >4–6 h, alarma"
                ),
                listOf(
                    "Puncionar neuraxial con ACOD dentro de la ventana: hematoma epidural",
                    "Retirar el catéter sin respetar el tiempo de espera del anticoagulante",
                    "Atribuir el déficit motor al bloqueo «normal» y no activar el protocolo de RM"
                ),
                "Cronograma ASRA antes de puncionar y antes de retirar: el hematoma epidural es raro pero devastador."
            )
        ),
        questions = listOf(
            StudyQuestion(
                "Cesárea con raqui: bupivacaína hiperbárica 0,5 % dosis típica y nivel objetivo:",
                listOf(
                    "15–20 mg con T10",
                    "10–12 mg con objetivo T4–T6",
                    "5 mg con T8",
                    "25 mg con T6"
                ),
                1,
                "Cesárea: 10–12 mg de bupivacaína hiperbárica 0,5 % para nivel T4–T6; más dosis aumenta hipotensión y bloqueo alto.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "Sospecha de LAST tras bloqueo axilar: primera medida específica además de parar la inyección y pedir ayuda:",
                listOf(
                    "Propofol 2 mg/kg para «sedar» la convulsión",
                    "Lípidos 20 %: 1,5 mL/kg en bolo + infusión 0,25 mL/kg/min",
                    "Adrenalina 1 mg IV en bolo",
                    "Lidocaína IV"
                ),
                1,
                "El protocolo de lípidos es el rescate específico de LAST; la adrenalina en bolos altos empeora la recuperación; el propofol NO sustituye los lípidos.",
                listOf("R2", "R3")
            ),
            StudyQuestion(
                "Dosis máxima de bupivacaína sin adrenalina en un adulto de 70 kg:",
                listOf(
                    "500 mg",
                    "175 mg (2,5 mg/kg)",
                    "70 mg",
                    "350 mg"
                ),
                1,
                "Bupivacaína: 2,5 mg/kg sin epinefrina (70 kg → ~175 mg); con epinefrina 3 mg/kg. La app trae la calculadora.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "Epidural en trabajo de parto con enoxaparina profiláctica 40 mg c/24 h. Cronograma ASRA correcto:",
                listOf(
                    "Colocar el catéter 2 h después de la dosis",
                    "Colocar el catéter ≥12 h después de la última dosis profiláctica; retirar el catéter ≥12 h después de la última dosis",
                    "No aplicar epidural en ninguna circumstance",
                    "Retirar el catéter 2 h después"
                ),
                1,
                "Enoxaparina profiláctica (12/12): punción y retiro con ≥12 h desde la última dosis; terapéutica 24 h.",
                listOf("R2", "R3")
            ),
            StudyQuestion(
                "Bloqueo interescaleno en paciente con EPOC severo: principal riesgo a explicar:",
                listOf(
                    "Neumotórax",
                    "Parálisis del frénico ipsilateral (≥90 %): puede requerir apoyo ventilatorio",
                    "Síndrome de Horner",
                    "LAST"
                ),
                1,
                "El interescaleno bloquea casi siempre el frénico: en EPOC dependiente puede descompensar. Considerar alternativa (supra/infraclavicular o axilar).",
                listOf("R3")
            ),
            StudyQuestion(
                "Tras raqui para herniorrafia, a las 6 h el paciente NO mueve los pies. Conducta:",
                listOf(
                    "Reposar: es normal",
                    "Alarma: sospecha de hematoma epidural → RM urgente y neurocirugía",
                    "Dar más opioide",
                    "Elevar las piernas y esperar a las 12 h"
                ),
                1,
                "El bloqueo motor de la raqui con bupi 0,5 % resuelve en 3–4 h: persistencia a 6 h exige descartar hematoma (RM urgente) — ventana quirúrgica <8 h.",
                listOf("R3", "R4")
            )
        ),
        bibliography = listOf(
            "Horlocker TT et al. Regional Anesthesia in the Patient Receiving Antithrombotic or Thrombolytic Therapy (ASRA Evidence-Based Guidelines). Reg Anesth Pain Med. 2018;43(3):263-309.",
            "Neal JM et al. ASRA Practice Advisory on Neurologic Complications in Regional Anesthesia and Pain Medicine. Reg Anesth Pain Med. 2015;40(5):477-486.",
            "Neal JM et al. ASRA checklist: LAST treatment. Reg Anesth Pain Med. 2010;35(2):152-156.",
            "Clinical2.kt de esta app: bloqueos básicos, avanzados y neuroaxiales con esquemas y calculadora de dosis."
        )
    ),

    // ============================== 5. MONITORIZACIÓN Y EQUIPOS ==============================
    StudyArea(
        id = "mon",
        name = "Monitorización y equipos",
        desc = "Del estándar ASA a la capnografía y la máquina: qué mirar, cómo funciona y cómo falla.",
        cards = listOf(
            StudyCard(
                "Monitorización estándar ASA y vigilancia clínica",
                "La vigilancia combina el estándar ASA (oximetría, capnografía, ECG, PA, temperatura) con la observación clínica continua: el monitor no reemplaza al anestesiólogo.",
                listOf(
                    "Oximetría de pulso: SpO2 con demora (10–20 s) y errores por perfusión, movimiento, esmalte, metahemoglobinemia, CO",
                    "ECG DII (ritmo) + V5 (isquemia); PA no invasiva cada 5 min como mínimo",
                    "Capnografía en TODA anestesia general (identificación de intubación y de ventilación)",
                    "Temperatura en todos los anestesiados >30 min (hipotermia prevenible)",
                    "Cuantitativo cuando aplique: débito, PAM invasiva, diuresis, gases"
                ),
                listOf(
                    "PA invasiva: línea radial con curva; dar ~0,5–1 mL/kg de salino en el transductor",
                    "Alarmas configuradas: límites por paciente (el valor por defecto no sirve para todos)",
                    "SpO2 100 % en un paciente intubado en el esófago: la oximetría tarda en caer — la capnografía es inmediata",
                    "Gasometría: comprobar SpO2 vs PaO2 ante dudas (curva de disociación)"
                ),
                listOf(
                    "Silenciar alarmas sin arreglar la causa",
                    "Confiar en SpO2 para confirmar intubación (la capnografía es el estándar)",
                    "No monitorizar temperatura en cirugías largas: la hipotermia incrementa infección y sangrado"
                ),
                "Monitor = estándar ASA + alarma bien fijada + mirada clínica: la capnografía confirma la vía aérea."
            ),
            StudyCard(
                "Capnografía: curvas y patrones",
                "La capnografía (EtCO2 + forma de onda) es el monitor fisiológico central del acto anestésico: confirma ventilación, revela reperfusión, embolia y problemas del circuito.",
                listOf(
                    "EtCO2 normal: 35–45 mmHg; curva rectangular con meseta alveolar",
                    "Caída abrupta a 0: desconexión, desintubación, paro circulatorio masivo o embolia letal",
                    "Caída gradual: hipoperfusión, embolia pulmonar, aumento de espacio muerto",
                    "Curva en «tiburón» (inclinada): broncoespasmo/EPOC (espacio muerto y obstrucción espiratoria)",
                    "EtCO2 alto: hipoventilación, rebreathing (cal sodada agotada, válvulas), maligna incipiente"
                ),
                listOf(
                    "Diferencia PaCO2–EtCO2: 2–5 mmHg normal; >10 sugiere espacio muerto (embolia, bajo débito)",
                    "HM: EtCO2 sube abrupta y sostenida >55 mmHg (signo más temprano y fiable)",
                    "Reanimación: EtCO2 <10 mmHg tras 20 min = mal pronóstico; brusco salto = retorno de circulación",
                    "Rebreathing: revisar FGF mínimo (0,5–1 L/min con absorbedor), válvulas y cal sodada"
                ),
                listOf(
                    "Atribuir la EtCO2 baja a «hiperventilación» sin revisar débito ni embolia",
                    "Ignorar la forma de la curva: la inclinación espiratoria revela broncoespasmo antes del ruido",
                    "Usar capnografía colorimétrica solo como confirmación inicial: no sirve para vigilancia continua"
                ),
                "La curva de capnografía es un ECG del pulmón: meseta rectangular = normal; leer forma + número + tendencia."
            ),
            StudyCard(
                "Máquina de anestesia: verificación en 8 pasos",
                "La verificación preoperatoria de la máquina es obligatoria antes de cada paciente (checklist de la app): fuentes de gas, mesa, vaporizadores, circuito, absorbedor, ventilador, alarmas y succión.",
                listOf(
                    "1) O2/presiones de fuentes y cilindros; 2) mesa de flujo y no-retorno; 3) vaporizadores llenos y cerrados",
                    "4) leak test del circuito: presurizar a 30 cmH2O y mantener 10 s; 5) cal sodada fresca (violeta→blanca=agotada)",
                    "6) ventilador: alarmas de presión y desconexión (probar ocluyendo la Y); 7) succión y equipo de rescate; 8) monitor: trazas y alarmas",
                    "Circuito circular: válvulas de no retorno (fuga o «sticking» causa rebreathing); baflés",
                    "La app trae la pestaña Máquina con 13 partes, 10 materiales y esquemas animados"
                ),
                listOf(
                    "Leak test: 30 cmH2O sostenido >10 s; con SLM dentro del circuito probar con el conector adecuado",
                    "Cal sodada agotada: cambio de color, calor del absorbedor, EtCO2 creciente con ventilación estable",
                    "Alarmas mínimas: presión pico, FiO2, desconexión (apnea), batería, gas anestésico",
                    "Cilindro E de O2: ~600 L a 137 bares; regla: presión/2 = L disponibles (aprox)"
                ),
                listOf(
                    "Saltarse el leak test por prisa: fuga detectada con el paciente ya anestesiado",
                    "Usar cal sodada vencida «porque se ve bien»: el color engaña si el absorbedor está secado",
                    "No probar la alarma de desconexión del ventilador antes de cada lista"
                ),
                "8 pasos antes de cada lista: el leak test y la alarma de desconexión salvan vidas silenciosas."
            ),
            StudyCard(
                "Ventiladores anestésicos: modos y alarmas",
                "Modos de ventilación del anestesiado (volúmenes vs presiones) y alarmas obligatorias: la vigilancia mecánica del pulmón bajo anestesia debe ser activa y con límites fijados.",
                listOf(
                    "VC-CMV: VT fijo (6–8 mL/kg IBW) con presión variable; PC-CMV: presión fija (12–18 cmH2O) con volumen variable",
                    "PEEP 5 cmH2O base; ΔP (driving) <15 cmH2O objetivo de protección",
                    "Alarmas: presión pico, desconexión/apnea, FiO2, volumen minuto, batería, O2 de reserva",
                    "Ventilación espontánea: SIMV/PSV en la recuperación; LMA con respiración espontánea vigilada",
                    "Circuitos: absorción de CO2 con cal sodada, humedad (HME) y filtros"
                ),
                listOf(
                    "VT protector: 6–8 mL/kg del PBW (calculadora Vt de la app); FR ajustada a EtCO2 35–45",
                    "Límites de presión pico: 30–35 cmH2O; si sube: revisar obstrucción, broncoespasmo, neumotórax, mordida",
                    "PSV en SLM: presión de apoyo 8–15 cmH2O según esfuerzo y EtCO2",
                    "Verificación de alarma de desconexión: ocluir la Y y comprobar que suena"
                ),
                listOf(
                    "VT calculado por peso TOTAL en el obeso (usar IBW: calculadora peso ideal)",
                    "PEEP alta en hipotensos sin revisar retorno venoso",
                    "Dejar alarmas por defecto con límites que el paciente ya «dispara» de forma crónica"
                ),
                "VT por IBW, ΔP <15, PEEP 5 y alarmas probadas: el ventilador protege solo si usted lo fija."
            ),
            StudyCard(
                "Alarmas y errores de monitorización",
                "Las alarmas son la red de seguridad: configurarlas, escucharlas y resolver la causa. Los errores habituales son de configuración y de interpretación.",
                listOf(
                    "Alarma de desconexión: la más crítica — probarla en cada lista",
                    "SpO2 baja «sin explicación»: revisar perfusión, electrodos, curva de pulso, posición",
                    "Curvas de gases/volátiles: FiO2, MAC, N2O; el MAC integrado muestra la profundidad real",
                    "Alarmas cruzadas: hipotensión + taquicardia + EtCO2 baja = bajo débito/embolia, no «arte del monitor»",
                    "Documentación: registrar límites y eventos en el expediente de la app"
                ),
                listOf(
                    "Límites típicos: HR 50–130 (ajuste por edad), SpO2 >92 %, PA −20/+20 % del basal, EtCO2 30–50",
                    "Artefactos de ECG: cauterio, movimiento; filtrar y mirar la SpO2 y PA para corroborar",
                    "Si el monitor «no se puede creer»: verifique al paciente primero, luego el equipo",
                    "Mute total en cirugía larga = riesgo alto: no es una opción"
                ),
                listOf(
                    "Silenciar «solo unos minutos» y olvidarse",
                    "Ajustar la alarma para que deje de sonar (manipulación de límites al margen del paciente)",
                    "Interpretar curvas sin correlación clínica (falsa SpO2 alta con CO intoxicación)"
                ),
                "Alarma bien configurada y escuchada = un segundo anestesiólogo en la sala."
            )
        ),
        questions = listOf(
            StudyQuestion(
                "EtCO2 cae de 38 a 4 mmHg abruptamente en un paciente intubado. La primera hipótesis a revisar en voz alta:",
                listOf(
                    "Hipoventilación",
                    "Desconexión/desintubación o paro circulatorio: comprobar circuito, tube y pulso",
                    "Fiebre",
                    "Rebreathing"
                ),
                1,
                "La caída abrupta a 0 = circuito (desconexión, desintubación) o circulación (paro, embolia masiva). Comprobar en segundos: pecho, tube, pulso, conexión.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "Signo más temprano de hipertermia maligna en el monitor intraoperatorio:",
                listOf(
                    "Temperatura >39 °C",
                    "EtCO2 elevada inexplicable (>55 mmHg) con taquicardia y rigidez",
                    "Hipotensión",
                    "SpO2 95 %"
                ),
                1,
                "La EtCO2 elevada inexplicable es el signo más temprano de HM; la fiebre llega tarde. Ver Emergencias → HM de la app (dantroleno inmediato).",
                listOf("R2", "R3")
            ),
            StudyQuestion(
                "Curva de capnografía con meseta inclinada («tiburón») indica:",
                listOf(
                    "Hiperventilación",
                    "Obstrucción espiratoria (broncoespasmo/EPOC) o espacio muerto",
                    "Desconexión",
                    "Cal sodada nueva"
                ),
                1,
                "La meseta inclinada refleja vaciamiento alveolar heterogéneo por obstrucción espiratoria: tratar broncoespasmo y revisar circuito.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "El leak test del circuito se considera correcto cuando:",
                listOf(
                    "Se presuriza a 30 cmH2O y se mantiene >10 s",
                    "Se infla el baflé manualmente y baja en 5 s",
                    "La presión pico es 20 cmH2O durante la ventilación",
                    "El ventilador marca volumen minuto normal"
                ),
                0,
                "Leak test: presurizar el circuito (a 30 cmH2O, válvula APL cerrada) y que mantenga >10 s. Detecta fugas antes del paciente.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "En el ventilador de anestesia, el VT protector se calcula con:",
                listOf(
                    "Peso real",
                    "Peso predicho (IBW) — 6–8 mL/kg, con ΔP <15 cmH2O",
                    "IMC",
                    "Peso ideal + 20 %"
                ),
                1,
                "VT por peso predicho (ARDsNet): 6–8 mL/kg IBW, ΔP objetivo <15. La app calcula IBW/VT en la calculadora Peso ideal.",
                listOf("R2")
            ),
            StudyQuestion(
                "Cal sodada agotada en el absorbedor se manifiesta por:",
                listOf(
                    "EtCO2 creciente y cambios de color (violeta→blanca)",
                    "FiO2 baja",
                    "Presión pico alta",
                    "Curva de capnografía plana"
                ),
                0,
                "La cal agotada no absorbe CO2: sube la EtCO2 con ventilación estable y cambia de color. Cambiarla y revisar válvulas.",
                listOf("R1", "R2")
            )
        ),
        bibliography = listOf(
            "ASA. Standards for Basic Anesthetic Monitoring (última versión vigente).",
            "Miller RD. Miller's Anesthesia, 10.ª ed., capítulo de monitorización (2024).",
            "Longnecker DE. Anesthesiology, 3.ª ed., capítulo de equipos y monitorización (2023).",
            "Cronos Anestesia, pestaña Máquina: 13 partes, materiales y verificación de 8 pasos (contenido interno)."
        )
    ),

    // ============================== 6. FISIOLOGÍA APLICADA ==============================
    StudyArea(
        id = "fis",
        name = "Fisiología aplicada",
        desc = "Mecánica ventilatoria, transporte de O2, circulación y ácido-base: la base racional de cada decisión.",
        cards = listOf(
            StudyCard(
                "Mecánica ventilatoria y volumen corriente protector",
                "El pulmón anestesiado colapsa (FRC baja) y es vulnerable: VT por peso predicho, ΔP bajo y PEEP moderada previenen lesión y atelectasia.",
                listOf(
                    "FRC cae ~20 % en decúbito supino y más con anestesia: colapso alveolar y shunt",
                    "VT protector: 6–8 mL/kg del peso PREDICHO (IBW), no del real",
                    "ΔP = meseta − PEEP: objetivo <15 cmH2O (driving pressure)",
                    "PEEP 5–8 cmH2O + reclutamiento intermitente en cirugía larga",
                    "Maniobras: reclutamiento con presión sostenida o suspiros; oxigenación alveolar al final"
                ),
                listOf(
                    "PBW hombre: 50 + 0,91 × (altura − 152,4) cm; mujer: 45,5 + 0,91 × …",
                    "Cst normal 50–80 mL/cmH2O; <30 = severamente reducida",
                    "RSBI (FR/VT en L) <105: favorable para extubar",
                    "Hypoventilación permisiva en síndrome de dificultad: PaCO2 45–60 aceptada si pH >7,20"
                ),
                listOf(
                    "Calcular el VT por peso real en obesos (lesiona: usa IBW)",
                    "PEEP 0 en cirugía laparoscopica prolongada (atelectasia y atelectrauma)",
                    "Olvidar el reclutamiento al final de la cirugía (atelectasias postop y PPC)"
                ),
                "VT 6 mL/kg del PESO PREDICHO, ΔP <15, PEEP moderada y reclutamiento al final."
            ),
            StudyCard(
                "Transporte de O2: DO2, VO2 y la curva",
                "El oxígeno llega por débito × contenido arterial: la anestesia compromete todos los componentes (débito, Hb, saturación, extracción).",
                listOf(
                    "CaO2 = (1,34 × Hb × SaO2) + (0,003 × PaO2): la Hb domina el contenido",
                    "DO2 = débito × CaO2; VO2 = DO2 − VvO2×débito; el cuerpo extrae ~25 % en reposo",
                    "Curva de disociación: desplazamiento a la derecha (ácido, febre, 2,3-DPG) libera O2; a la izquierda (alcalosis, hipotermia) lo retiene",
                    "El pulso oxímetro mide saturación, no contenido: un paciente anémico puede tener SpO2 100 % con DO2 crítico",
                    "La P50 (~27 mmHg) resume la afinidad de la Hb"
                ),
                listOf(
                    "DO2 crítico: ~330 mL/min/m² (debajo: metabolismo anaerobio y lactato)",
                    "Umbral transfusional restrictivo: Hb 7 g/dL (8 en cardiovascular; 7,5 en ortopedia con riesgo)",
                    "1 g/dL de Hb ≈ 1,34 mL O2/dL en sangre",
                    "En anemia: DO2 se sostiene con débito (taquicardia) hasta el umbral"
                ),
                listOf(
                    "Transfundir por «número» sin síntoma ni contexto (ver umbral restrictivo)",
                    "Olvidar que el CO2 y la temperatura mueven la curva: pH 7,2 desplaza a la derecha",
                    "Asumir SpO2 100 % = oxigenación garantizada en el anémico"
                ),
                "DO2 = débito × Hb × saturación: la anestesia y la anemia la comprometen juntas; transfunda por umbral, no por rutina."
            ),
            StudyCard(
                "Circulación y presión arterial bajo anestesia",
                "La PA es el resultado de débito × resistencias. Bajo anestesia, la hipotensión es multifactorial: hipnosis, analgesia insuficiente, hipovolemia, bloqueo, posición.",
                listOf(
                    "PAM = PA diastólica + 1/3 de la presión de pulso; objetivo: basal ±20 %",
                    "Causas de hipotensión: hipnosis/relajación (retorno), bloqueo neuraxial (simpaticolisis), sangrado, arritmias, anafilaxis",
                    "Causas de hipertensión: dolor, hipoxia, hipercapnia, retracción, previa HTA",
                    "El débito depende de precarga, contractilidad y postcarga (curvas de Starling)",
                    "Vigilar perfusión, no solo número: diuresis, lactato, temperatura periférica"
                ),
                listOf(
                    "Hipotensión de inducción: ~30 % de los pacientes con propofol + opioide",
                    "Vasopresores: fenilefrina 50–200 µg (vaso), efedrina 5–10 mg (alfa+beta), noradrenalina infusión 0,05–0,3 µg/kg/min",
                    "En bloqueo neuraxial obstétrico: fenilefrina profiláctica en infusión es de elección",
                    "Prueba de volumen: responder a bolo de 250–500 mL con ascenso transitorio de PA sugiere hipovolemia"
                ),
                listOf(
                    "Tratar toda hipotensión con volumen (no siempre es hipovolemia: puede ser vasodilatación o bloqueo)",
                    "Corregir la hipertensión con anestésico sin revisar dolor, hipoxia o hipercapnia",
                    "Ignorar el lactato y la diuresis: la PA «aceptable» puede esconder mala perfusión"
                ),
                "PA = débito × resistencias: trate la causa (volumen, vasopresor, analgesia), no solo el número."
            ),
            StudyCard(
                "Equilibrio ácido-base: interpretación rápida",
                "Enfoque sistemático: pH, PaCO2, HCO3, base exceso y brecha aniónica; el diagnóstico es matemático antes que clínico.",
                listOf(
                    "Paso 1: pH (acidosis <7,35 / alcalosis >7,45); Paso 2: PaCO2 vs HCO3 — quién es primario",
                    "Compensación: respiratoria aguda ΔHCO3 −2 por cada −10 mmHg de PaCO2; crónica −4",
                    "Brecha aniónica = Na − (Cl + HCO3): normal 8–12; alta → lactato, cetoácidos, insuficiencia renal, tóxicos",
                    "Brecha de osmoles si brecha aniónica alta no explicada (metanol, etilenglicol)",
                    "Base exceso: <−2 = déficit (acidosis metabólica); >+2 = exceso"
                ),
                listOf(
                    "Lactato >2 mmol/L: hipoperfusión/anaerobiosis; >4: crítico",
                    "Acidosis de la hipovolemia: lactato + brecha alta; corregir volumen y perfusión",
                    "Alcalosis respiratoria por hiperventilación (dolor, ansiedad, sepsis temprana): bajar FR y revisar dolor",
                    "En cirugía prolongada: gasometría cada 1–2 h si hay transfusión, ventilación inestable o acidosis"
                ),
                listOf(
                    "Corregir el pH con bicarbonato sin corregir la hipoperfusión (trate la causa)",
                    "Interpretar la compensación como «segunda alteración» (la compensación es esperada)",
                    "Olvidar el ión cloro en acidosis hipoclorémica (vómito, SNG)"
                ),
                "pH + PaCO2 + HCO3 + brecha aniónica en 4 pasos: el diagnóstico ácido-base es aritmética."
            ),
            StudyCard(
                "Hipertermia, hipotermia y control de la temperatura",
                "La temperatura cae 1–2 °C en la primera hora de anestesia (redistribución). La hipotermia aumenta sangrado, infección y estancia; la hipertermia inesperada puede ser HM.",
                listOf(
                    "Hipotermia <36 °C: prevenir con abrigo activo (manta de aire forzado), fluidos calientes y sala ≥21 °C",
                    "Monitorear en todos los >30 min de anestesia (estándar)",
                    "Estremecimiento postop: meperidina 12,5–25 mg IV es eficaz; también tramadol",
                    "Hipertermia intraoperatoria: descartar HM (EtCO2 alta, rigidez, acidosis), infección, trasfusión",
                    "En pediatría la pérdida es más rápida (superficie/peso)"
                ),
                listOf(
                    "Objetivo de normotermia: ≥36 °C al alta de la sala (calidad de recuperación)",
                    "La hipotermia <35,5 °C triplica el riesgo de infección de herida y aumenta el sangrado",
                    "Manta de aire forzado: +0,5–1 °C/h; fluidos calientes si >1 L/h",
                    "HM: emergencia — dantroleno 2,5 mg/kg repetido; protocolo en la pestaña Emergencias"
                ),
                listOf(
                    "Monitorizar temperatura pero no intervenir (la vigilancia sin acción no previene)",
                    "Atribuir el estremecimiento a «frío del quirófano» sin corregir la hipotermia",
                    "Olvidar la hipertermia por HM en cirugías de larga duración con volátil + SCh"
                ),
                "Normotermia activa: manta, fluidos calientes, sala templada — y ante hipertermia inexplicable, piense en HM."
            )
        ),
        questions = listOf(
            StudyQuestion(
                "En un paciente de 80 kg con altura 170 cm (PBW ~66 kg), el VT protector correcto es:",
                listOf(
                    "560 mL (8 mL/kg del peso real)",
                    "400 mL (6 mL/kg del peso predicho)",
                    "800 mL (10 mL/kg del peso real)",
                    "480 mL (8 mL/kg del peso predicho + 15 %)"
                ),
                1,
                "VT = 6–8 mL/kg del peso PREDICHO: 66 kg × 6 ≈ 400 mL. El peso real sobredimensiona el pulmón.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "La principal determinante del contenido arterial de O2 (CaO2) es:",
                listOf(
                    "La PaO2",
                    "La hemoglobina (1,34 × Hb × SaO2)",
                    "La temperatura",
                    "El pH"
                ),
                1,
                "CaO2 = (1,34 × Hb × SaO2) + (0,003 × PaO2): la Hb domina. Un anémico con SpO2 100 % puede tener DO2 crítico.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "Hipotensión en un paciente con raqui para cesárea. Manejo de elección:",
                listOf(
                    "Solo líquidos",
                    "Fenilefrina profiláctica/terapéutica (bolos 50–100 µg o infusión) con volumen moderado",
                    "Efedrina exclusivamente",
                    "Atropina"
                ),
                1,
                "En obstetricia, la fenilefrina es de elección (mejor pH fetal); la efedrina se reserva para bradicardia asociada. Los líquidos solos no corrigen la simpaticolisis.",
                listOf("R2", "R3")
            ),
            StudyQuestion(
                "Paciente con pH 7,15, PaCO2 30, HCO3 10, brecha aniónica 22. Interpretación:",
                listOf(
                    "Acidosis respiratoria con compensación",
                    "Acidosis metabólica con brecha aniónica alta y compensación respiratoria parcial",
                    "Alcalosis metabólica",
                    "Acidosis mixta respiratoria y metabólica sin compensación"
                ),
                1,
                "pH bajo + HCO3 bajo (primario metabólico) + PaCO2 baja (compensación) + brecha alta (lactato, cetoácidos, uremia): acidosis metabólica de brecha alta.",
                listOf("R2", "R3")
            ),
            StudyQuestion(
                "Umbral transfusional restrictivo en adulto sano postoperatorio:",
                listOf(
                    "Hb 10 g/dL",
                    "Hb 7 g/dL",
                    "Hb 12 g/dL",
                    "Hb 9 g/dL en todos los casos"
                ),
                1,
                "El umbral restrictivo es Hb 7 g/dL (8 en cardiovascular, 7,5 en ortopedia de alto riesgo) — sin síntomas. Transfundir por «número» aumenta complicaciones.",
                listOf("R1", "R2")
            ),
            StudyQuestion(
                "Hipertermia de 38,5 °C con EtCO2 58 mmHg y rigidez maseterina a 40 min de anestesia con sevoflurano y SCh. Conducta:",
                listOf(
                    "Paracetamol y vigilar",
                    "Activar protocolo de HM: parar volátil, dantroleno 2,5 mg/kg, hiperventilar y enfriar",
                    "Aumentar el volátil",
                    "Solo gasometría de control"
                ),
                1,
                "EtCO2 alta + rigidez + hipertermia con gatillos = HM hasta prueba en contrario: protocolo inmediato (dantroleno 2,5 mg/kg repetido).",
                listOf("R2", "R3", "R4")
            )
        ),
        bibliography = listOf(
            "Netter/Fisio: Fisiología respiratoria aplicada a la anestesia (revisión de la app, Fisio.kt).",
            "Lumb AB. Nunn's Applied Respiratory Physiology, 9.ª ed., 2021.",
            "Levick's Introduction to Cardiovascular Physiology, 6.ª ed., 2017.",
            "Sessler DI. Perioperative thermoregulation and heat balance. Lancet. 2016;387(10038):2655-2664."
        )
    )
)
