package cu.cronos.anestesia

// =====================================================================
//  PRESENTACIÓN DE FÁRMACOS (v2.4.0 — contrato §5.2)
//  Catálogo estructurado de envases y concentraciones de los fármacos de
//  uso anestésico más habituales, con el cálculo de volumen a extraer.
//  Complementa la ficha de preparación (DRUG_PREP, v2.0.0): allí el cómo
//  se prepara y administra; aquí el cómo viene el fármaco y cuántos mL
//  corresponden a la dosis indicada.
//  Las presentaciones varían por fabricante y disponibilidad local
//  (Cuba): verifique SIEMPRE la concentración en el vial antes de extraer.
// =====================================================================

data class DrugPresentation(
    val drug: String,      // debe coincidir con DRUGS (prueba cruzada)
    val forms: String,     // envases y concentraciones habituales
    val draw: String,      // ejemplo práctico: dosis → mL a extraer
    val note: String = ""  // conservación, riesgo o error frecuente
)

/** Convierte una dosis (mg) en volumen (mL) según la concentración (mg/mL). */
fun volumeForMg(mg: Double, concMgMl: Double): Double {
    if (concMgMl <= 0.0) return 0.0
    return Math.round((mg / concMgMl) * 100.0) / 100.0
}

/** Convierte una dosis (µg) en volumen (mL) según la concentración (µg/mL). */
fun volumeForUg(ug: Double, concUgMl: Double): Double =
    volumeForMg(ug, concUgMl)

val DRUG_PRESENTATIONS: List<DrugPresentation> = listOf(
    // ---------------- Inductores y sedación ----------------
    DrugPresentation(
        "Propofol",
        "Ampolla de emulsión lipídica 1 % (10 mg/mL): 20 mL (200 mg) y 50 mL (500 mg). Frasco 1 % de 50 mL para infusiones prolongadas.",
        "Inducción 200 mg (70 kg) → extraer 20 mL de la ampolla 10 mg/mL. Sedación en jeringa de 50 mL: 500 mg + 0 mL (50 mL directos) = 10 mg/mL.",
        "Emulsión blanca: no usar si separa (fase oleosa). Descartar 6 h tras abrir. Vía gruesa o diluir a ≥2 mg/mL si la vía es fina."
    ),
    DrugPresentation(
        "Etomidato",
        "Ampolla 2 mg/mL de 10 mL (20 mg).",
        "Inducción 20 mg (70 kg, 0,3 mg/kg) → 10 mL directos, sin diluir.",
        "Solución de propilenglicol: dolor e irritación venosa; lavar la vía. No refrigerar (precipita)."
    ),
    DrugPresentation(
        "Tiopental",
        "Frasco-ampolla de polvo 0,5 g y 1 g. Reconstituir a 25 mg/mL (0,5 g + 20 mL; 1 g + 40 mL).",
        "Inducción 250 mg (70 kg, 3,5 mg/kg) → extraer 10 mL de la solución 25 mg/mL.",
        "Alcalino (pH 10–11): incompatible con relajantes y opioides; lavar la línea. Usar en 24 h tras reconstituir."
    ),
    DrugPresentation(
        "Ketamina",
        "Ampolla 50 mg/mL de 10 mL (500 mg) y 100 mg/mL de 2 mL (200 mg).",
        "Analgesia 30 mg → 3 mL de la 10 mg/mL; para titulación diluir 100 mg en 10 mL de SF (10 mg/mL) y tomar 3 mL.",
        "Proteger de la luz. La 100 mg/mL (2 mL) es para IM o reconstituir infusiones: no bolus IV directo sin diluir."
    ),
    DrugPresentation(
        "Midazolam",
        "Ampolla 1 mg/mL de 5 mL (5 mg) y 5 mg/mL de 3 mL (15 mg).",
        "Sedación 2 mg → 2 mL de la 1 mg/mL (o 0,4 mL de la 5 mg/mL: preferir la diluida para titulación fina).",
        "La concentración 5 mg/mL se confunde con fármacos similares: etiquetar la jeringa. Estable 24 h a la luz."
    ),
    DrugPresentation(
        "Diazepam",
        "Ampolla 5 mg/mL de 2 mL (10 mg), solución oleosa. Comprimidos 5 y 10 mg.",
        "Sedación 5 mg → 1 mL directo IV lento por vía gruesa.",
        "NO diluir en SF (turbidez) ni mezclar con otros fármacos. Dolor y flebitis: la emulsión (Diazemuls) es la alternativa diluible."
    ),
    DrugPresentation(
        "Dexmedetomidina",
        "Ampolla 100 µg/mL de 2 mL (200 µg).",
        "Jeringa de 50 mL: 200 µg (2 mL) + 48 mL de SF 0,9 % = 4 µg/mL. Carga 50 µg → 12,5 mL de esa mezcla.",
        "No bolus rápido (bradicardia/hipotensión). Estable 24 h. Cambio de ampolla/fabricante puede variar el volumen: recalcular."
    ),
    // ---------------- Opioides ----------------
    DrugPresentation(
        "Fentanilo",
        "Ampolla 50 µg/mL de 2 mL (100 µg) y de 10 mL (500 µg).",
        "Jeringa de 50 mL estándar: 500 µg (10 mL) + 40 mL de SF = 10 µg/mL. Bolo 100 µg → 2 mL de la 50 µg/mL.",
        "Potencia 100× morfina: contar los mL en voz alta. La ampolla de 10 mL (500 µg) es la de mayor riesgo de sobredosis: etiquetar."
    ),
    DrugPresentation(
        "Remifentanilo",
        "Frasco-ampolla de polvo 1 mg, 2 mg y 5 mg.",
        "Jeringa de 50 mL para bomba: 2 mg reconstituidos + volumen a 50 mL = 40 µg/mL (dilución Minto habitual).",
        "Reconstituir SOLO con SF o SG5 %: espuma frecuente al agitar (dejar reposar). Renovar cada 12 h; línea dedicada."
    ),
    DrugPresentation(
        "Morfina",
        "Ampolla 10 mg/mL de 1 mL; ampollas 10 mg/5 mL (2 mg/mL) según fabricante. Comprimidos 10 mg; solución oral 2 mg/mL.",
        "Bolo 4 mg → 0,4 mL de la 10 mg/mL diluidos en 10 mL de SF (0,4 mg/mL) para titulación.",
        "Diluir siempre para titulación: el mL directo (10 mg) es sobredosis. En fractura renal evitar (M3G/M6G activos)."
    ),
    DrugPresentation(
        "Petidina (Meperidina)",
        "Ampolla 100 mg/2 mL (50 mg/mL). Comprimidos 50 mg.",
        "Dosis 50 mg → 1 mL diluido en 10 mL de SF (10 mg/mL).",
        "No mezclar con soluciones alcalinas (precipita). Acumula noremeperidina (convulsiones): no usar en ERC ni infusiones largas."
    ),
    DrugPresentation(
        "Tramadol",
        "Ampolla 100 mg/2 mL (50 mg/mL). Comprimidos 50 mg, cápsulas 100 mg, gotas 100 mg/mL.",
        "Dosis 100 mg → 2 mL diluidos en 10 mL de SF o SG5 %.",
        "Máx. 400–600 mg/día. Náusea frecuente: asociar ondansetrón. Cuidado en epilepsia y con ISRS (serotonina)."
    ),
    DrugPresentation(
        "Dipirona (Metamizol)",
        "Ampolla 2 g/5 mL (400 mg/mL). Comprimidos 500 mg; gotas 500 mg/mL.",
        "Dosis 2 g → 5 mL diluidos en 20 mL de SF, IV lenta en ≥5 min.",
        "Infusión rápida causa hipotensión y reacciones anafilácticas: nunca en bolo. Proteger de la luz."
    ),
    DrugPresentation(
        "Paracetamol (Acetaminofén)",
        "Frasco IV 1 g/100 mL listo para infusión. Comprimidos 500 mg y 1 g; jarabe 120 mg/5 mL; supositorios 250 mg.",
        "Dosis 1 g → infundir el frasco completo en ≥15 min (no diluir).",
        "Máx. 4 g/día (3 g en >75 años, hepatopatía, <50 kg): sumar TODAS las vías (VO + IV). Sobredosis = hepatotoxicidad."
    ),
    // ---------------- Relajantes ----------------
    DrugPresentation(
        "Suxametonio (Succinilcolina)",
        "Ampolla 100 mg/2 mL (50 mg/mL); frascos 500 mg para diluir. Conservación 2–8 °C.",
        "RSI 100 mg (70 kg) → 2 mL directos (no diluir para RSI); para goteo titulado diluir a 10 mg/mL.",
        "Cadena de frío obligatoria: fuera de refrigeración pierde potencia. Ampolla turbia = descartar. Contra el K alto."
    ),
    DrugPresentation(
        "Rocuronio",
        "Ampolla 10 mg/mL de 5 mL (50 mg) y 10 mL (100 mg).",
        "Intubación 42 mg (70 kg, 0,6 mg/kg) → 4,2 mL; RSI 1–1,2 mg/kg → 7–8,4 mL directos.",
        "Estable 30 días a temperatura ambiente: puede llevarse en el maletín. Etiquetar: se confunde con inductores transparentes."
    ),
    DrugPresentation(
        "Vecuronio",
        "Frasco-ampolla de polvo 10 mg con 10 mL de disolvente (1 mg/mL).",
        "Intubación 7 mg (70 kg) → 7 mL reconstituidos.",
        "Usar en 24 h tras reconstituir (sin conservantes). En renal/hepática se acumula: preferir cisatracurio."
    ),
    DrugPresentation(
        "Atracurio",
        "Ampolla 10 mg/mL de 2,5 y 5 mL. Conservación 2–8 °C, proteger de la luz.",
        "Intubación 35 mg (70 kg, 0,5 mg/kg) → 3,5 mL.",
        "Degradación de Hofmann (independiente de riñón/hígado). Dosis altas: histamina (hipotensión, enrojecimiento)."
    ),
    DrugPresentation(
        "Cisatracurio",
        "Ampolla 2 mg/mL de 10 mL (20 mg) y 10 mg/mL de 2,5 mL. Refrigerar 2–8 °C.",
        "Intubación 14 mg (70 kg, 0,2 mg/kg) → 7 mL de la 2 mg/mL.",
        "Isómero R del atracurio sin histamina: elección en paciente crítico, cardíaco y hepatorrenal. No diluir en lactato de Ringer."
    ),
    DrugPresentation(
        "Sugammadex",
        "Frasco-ampolla 100 mg/mL de 2 mL (200 mg), 5 mL (500 mg) y 10 mL (1 g).",
        "Reversión 2 mg/kg (70 kg = 140 mg) → 1,4 mL de la 100 mg/mL; rescate 4 mg/kg → 2,8 mL.",
        "Costo alto y disponibilidad limitada: registrar la indicación. Solo revierte rocuronio/vecuronio (no benzilisoquinolinas)."
    ),
    DrugPresentation(
        "Neostigmina + Atropina (reversión)",
        "Ampolla de neostigmina 0,5 mg/mL (2,5 mg/5 mL) o 2,5 mg/1 mL según fabricante; atropina 1 mg/mL.",
        "Mezcla clásica en una jeringa: neostigmina 2,5 mg (1 mL) + atropina 1 mg (1 mL); dosis 0,04–0,06 mg/kg.",
        "Preparar en el momento, no almacenar la mezcla. Alternativa: glicopirrolato 0,2 mg por cada mg de neostigmina."
    ),
    // ---------------- Vasopresores e inotrópicos ----------------
    DrugPresentation(
        "Efedrina",
        "Ampolla 30 mg/mL de 1 mL.",
        "Bolo titulado 5 mg → 1 mL diluido en 10 mL de SF (3 mg/mL): tomar 1,7 mL.",
        "Pérdida de potencia con repetición (taquifilaxis): en obstetricia la fenilefrina es de primera línea si no hay bradicardia."
    ),
    DrugPresentation(
        "Fenilefrina",
        "Ampolla 10 mg/mL de 1 mL.",
        "Bolo 100 µg → 0,1 mL en 10 mL de SF (10 µg/mL); bomba: 2 mg (0,2 mL) en 50 mL de SF = 40 µg/mL.",
        "El 0,1 mL se mide mal en jeringa de 10 mL: preparar la dilución intermedia y etiquetar. Alto riesgo de error por concentración."
    ),
    DrugPresentation(
        "Adrenalina (Epinefrina)",
        "Ampolla 1 mg/mL (1:1000) de 1 mL. Para IV se diluye siempre; existe 1 mg/10 mL (1:10 000) para RCP.",
        "Anafilaxia 0,5 mg IM → 0,5 mL directo de la 1:1000 (muslo, sin diluir). IV: 1 mg en 100 mL de SF = 10 µg/mL (bolos 50–100 µg).",
        "La 1:1000 directa por vía IV causa crisis hipertensiva y FV: IM en anafilaxia, IV solo diluida. Etiquetar ambas."
    ),
    DrugPresentation(
        "Noradrenalina (Norepinefrina)",
        "Ampolla 4 mg/4 mL (1 mg/mL) o 2 mg/2 mL; proteger de la luz.",
        "Bomba: 4 mg + 46 mL de SG5 %/SF = 80 µg/mL en jeringa de 50 mL. Bolo puntual 8 µg → 0,1 mL diluido además a 4 µg/mL.",
        "Extravasación = necrosis cutánea: vía central o buena vía periférica proximal con vigilancia. Titular a PAM ≥ 65 mmHg."
    ),
    DrugPresentation(
        "Dopamina",
        "Ampolla 200 mg/5 mL (40 mg/mL).",
        "Bomba: 200 mg + 45 mL de SG5 % = 4 mg/mL en jeringa de 50 mL. Proteger de la luz.",
        "La «dosis renal» (2–5 µg/kg/min) está en desuso: no mejora la perfusión renal. Taquiarritmias frecuentes a dosis altas."
    ),
    DrugPresentation(
        "Dobutamina",
        "Ampolla 250 mg/20 mL (12,5 mg/mL).",
        "Bomba: 250 mg (20 mL) + 30 mL de SG5 %/SF = 5 mg/mL en jeringa de 50 mL.",
        "Hipotensión posible por β2: en vasoplejía combinar con noradrenalina. Taquicardia límite de la titulación."
    ),
    DrugPresentation(
        "Vasopresina",
        "Ampolla 20 UI/mL de 1 mL.",
        "Bomba: 100 UI (5 mL) + 95 mL de SF = 1 UI/mL. Bolo de rescate 0,4–1 UI directo.",
        "Rescate en vasoplejía refractaria (baja el umbral de noradrenalina). No confundir con desmopresina (DDAVP 4 µg/mL)."
    ),
    DrugPresentation(
        "Nitroglicerina (Trinitrato de glicerilo)",
        "Ampolla 5 mg/mL de 10 mL (50 mg).",
        "Bomba: 50 mg (10 mL) + 40 mL de SG5 % = 1 mg/mL. Dilución menor: 5 mg en 50 mL = 100 µg/mL.",
        "Diluir SOLO en SG5 % (precipita en salino) y usar tubo no PVC (se adsorbe): pérdida de dosis real. Cefalea frecuente."
    ),
    // ---------------- Cardiovasculares y otros ----------------
    DrugPresentation(
        "Amiodarona",
        "Ampolla 150 mg/3 mL (50 mg/mL). Comprimidos 200 mg.",
        "Bolo 150 mg → 3 mL en 100 mL de SG5 % (1,5 mg/mL) en 10 min; mantener en SG5 % (precipita en salino).",
        "Flebitis: vía central si es infusión prolongada. Bradicardia y QT: monitorizar. Máx. 2 g/24 h."
    ),
    DrugPresentation(
        "Labetalol",
        "Ampolla 100 mg/20 mL (5 mg/mL). Comprimidos 100 y 200 mg.",
        "Bolo 10 mg → 2 mL directos IV lentos; bomba: 100 mg + 100 mL de SF = 1 mg/mL.",
        "Contraindicado en asma grave, bradicardia e insuficiencia cardíaca descompensada. Primera línea oral-IV en preeclampsia."
    ),
    DrugPresentation(
        "Atropina",
        "Ampolla 1 mg/mL de 1 mL; pediátrico 0,1 mg/mL disponible según fabricante.",
        "Bradicardia 0,5 mg → 0,5 mL diluido en 10 mL de SF (100 µg/mL).",
        "Dosis < 0,1 mg causan bradicardia paradójica (central): mínimo 0,1 mg. RCP: 1 mg c/3–5 min, máx. 3 mg."
    ),
    DrugPresentation(
        "Naloxona",
        "Ampolla 0,4 mg/mL de 1 mL; presentación pediátrica 0,02 mg/mL según fabricante.",
        "Titulación 40 µg → 0,1 mL en 10 mL de SF (40 µg/mL): subir de a 40–80 µg c/2 min.",
        "Titular (no bolo total): precipita abstinencia, dolor y edema agudo. Duración < opioide: vigilar resedación 2–3 h."
    ),
    DrugPresentation(
        "Flumazenil",
        "Ampolla 0,5 mg/5 mL (0,1 mg/mL).",
        "Dosis 0,2 mg → 2 mL IV; repetir 0,1 mg c/30 s hasta 1 mg.",
        "Riesgo de convulsión en dependientes de benzodiacepinas e intoxicación mixta (triccíclicos): no es «despertador» universal."
    ),
    DrugPresentation(
        "Ondansetrón",
        "Ampolla 8 mg/4 mL (2 mg/mL); frascos 8 mg liofilizados.",
        "Dosis 4 mg → 2 mL IV lentos (2–5 min) o diluidos en 50 mL de SF.",
        "Bradicardia y prolongación del QT con bolos rápidos. Máx. 16 mg/24 h. Efectivo en NVPO, pobre en náusea de movimiento."
    ),
    DrugPresentation(
        "Dexametasona",
        "Ampolla 8 mg/2 mL (4 mg/mL) y 20 mg/5 mL. Comprimidos 0,5 y 4 mg.",
        "NVPO 8 mg → 2 mL directos o diluidos.",
        "Efecto antiemético a las 2–4 h: dar al inicio, no al final. Hiperglucemia en diabéticos; no repetir sin indicación."
    ),
    DrugPresentation(
        "Hidrocortisona",
        "Frasco-ampolla de polvo 100 mg (y 500 mg) con 2 mL de disolvente.",
        "Reconstituir 100 mg + 2 mL = 50 mg/mL; para bomba diluir 100 mg en 100 mL de SF (1 mg/mL).",
        "Sustitución en estrés/shock séptico (200–300 mg/día). Compatible con SF y SG5 %; no mezclar con otros fármacos en la misma línea."
    ),
    DrugPresentation(
        "Heparina sódica no fraccionada",
        "Frasco 5000 UI/mL de 5 mL (25 000 UI) y 1000 UI/mL. Purga: 1000 UI/mL diluida.",
        "CEC 400 UI/kg (70 kg = 28 000 UI) → 5,6 mL de la 5000 UI/mL por vía central. Flushing: 5000 UI en 500 mL de SF = 10 UI/mL.",
        "Etiquetar SIEMPRE la concentración: confusiones entre 1000 y 5000 UI/mL causan hemorragias graves. Controlar ACT."
    ),
    DrugPresentation(
        "Protamina",
        "Ampolla 10 mg/mL de 5 mL (50 mg) y 10 mL (100 mg).",
        "Reversión 25 mg (por 2000 UI de heparina residual) → 2,5 mL diluidos en 50 mL de SF, IV lenta en 10–15 min.",
        "Bolo rápido: hipotensión y hipertensión pulmonar. Riesgo alérgico en diabéticos NPH y alérgicos a pescado; vasopresina disponible."
    ),
    DrugPresentation(
        "Metoclopramida",
        "Ampolla 10 mg/2 mL (5 mg/mL).",
        "Dosis 10 mg → 2 mL IV lentos.",
        "Reacciones extrapiramidales (distonías agudas) en jóvenes y dosis repetidas: antídoto difenhidramina/biperideno."
    ),
    DrugPresentation(
        "Droperidol",
        "Ampolla 5 mg/2 mL (2,5 mg/mL).",
        "NVPO 0,625 mg → 0,25 mL diluidos a 1 mg/mL para poder medir.",
        "Prolongación del QT: ECG si se supera 1,25 mg. Sedación y disforia a dosis altas (neuroleptoanalgesia histórica)."
    ),
    DrugPresentation(
        "Ranitidina",
        "Ampolla 50 mg/2 mL (25 mg/mL) y ampolla 50 mg/5 mL; frasco IV 50 mg/50 mL listo para infundir. VO: comprimidos 150 y 300 mg, jarabe 75 mg/5 mL.",
        "Profilaxis de aspiración: 50 mg IV lento (diluir 2 mL en 20 mL de SF, pasar en ≥5 min) o 50 mg en infusión 50 mL/15 min antes de la inducción.",
        "Infusión rápida: bradicardia y arritmias. Reducir dosis en insuficiencia renal (ClCr <50 mL/min: 50 mg c/18–24 h). Interfiere poco con el citocromo P450 (ventaja frente a cimetidina)."
    ),
    DrugPresentation(
        "Cimetidina",
        "Ampolla 200 mg/2 mL; frasco IV 400 mg/100 mL. VO: comprimidos 200, 400 y 800 mg, jarabe 200 mg/5 mL.",
        "Profilaxis de aspiración: 200–300 mg IV lento en ≥5 min (o 300 mg VO la noche previa y 2 h antes) al inducir.",
        "Inhibidor potente del citocromo P450: interacciona con warfarina, benzodiacepinas, lidocaína y propofol. Confusión en el adulto mayor y en insuficiencia renal; antiandrégico con uso prolongado. Hoy preferir ranitidina o IBP."
    ),
    DrugPresentation(
        "Difenhidramina (Benadrilina)",
        "Ampolla 10 mg/mL de 1 mL y de 30 mL (frasco multidosís); comprimidos 25 y 50 mg; jarabe 12,5 mg/5 mL (elixir 2,5 mg/5 mL pediátrico).",
        "Reacción alérgica leve: 25–50 mg IV lento (diluir en 10–20 mL de SF, pasar en ≥5 min) o IM. Rescate de distonías y acatisia por antieméticos: 25–50 mg IV/IM.",
        "Sedación marcada y anticolinérgico (boca seca, retención urinaria, delirium en el adulto mayor). Evitar en pacientes con glaucoma de ángulo estrecho y retención urinaria. No es sustituto de la adrenalina en anafilaxia."
    ),
    DrugPresentation(
        "Milrinona",
        "Ampolla 10 mg/10 mL (1 mg/mL) y 20 mg/20 mL; diluir en SF o SG5 % (200 mg/100 mL → 2 mg/mL habitual).",
        "Carga 25–50 µg/kg en ≥10 min (raramente necesaria) e infusión 0,375–0,75 µg/kg/min: 10 mg en 100 mL = 100 µg/mL → 15–30 mL/h en 70 kg.",
        "Vasodilatador e inodilatador (inhibidor PDE-3): hipotensión y arritmias; semivida larga (~2,4 h) — no titular en bolo. Reducir dosis en insuficiencia renal. Vigilar K y gasto con eco/débito."
    )
)
