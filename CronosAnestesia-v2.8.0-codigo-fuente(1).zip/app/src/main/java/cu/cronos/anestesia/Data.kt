package cu.cronos.anestesia

data class Drug(
    val name: String,
    val cls: String,
    val dose: String,
    val indications: String,
    val cautions: String
)

data class GasAnest(
    val name: String,
    val mac: String,
    val props: String,
    val notes: String,
    val warnings: String = ""
)

data class ScaleOption(val label: String, val score: Int)
data class ScaleGroup(val title: String, val options: List<ScaleOption>)
data class ScaleDef(
    val name: String,
    val desc: String,
    val groups: List<ScaleGroup>,
    val interpretation: String,
    val fixedOptions: List<ScaleOption> = emptyList(), // escalas sin grupos (una sola lista)
    val category: String = "", // grupo temático (v2.1.0: 6 grupos × 16 escalas)
    val sliderMax: Int = 0 // > 0: la escala usa un slider 0..sliderMax (EVA, v2.5.0)
)

data class Complication(
    val name: String,
    val recognition: String,
    val management: String
)

data class Topic(val title: String, val body: String)
data class Biblio(val title: String, val detail: String)

// ------------------------------- FÁRMACOS (45) -------------------------------

val DRUGS_RAW = listOf(
    Drug(
        "Propofol",
        "Inductor hipnótico (alquilfenol)",
        "Inducción: 1,5–2,5 mg/kg IV (30–45 s). Sedación: 25–100 µg/kg/min. Infusión TIVA: 4–8 mg/kg/h con remifentanilo.",
        "Inducción y mantenimiento de la anestesia general (TIVA/TCI), sedación en UCI y endoscopía, antiemético a dosis bajas (10–20 mg).",
        "Hipotensión y depresión respiratoria frecuentes. Dolor a la inyección (usar vena grande o lidocaína 1%). Alergia a huevo, soja y maní. Dosis reducidas en el adulto mayor y en hipovolemia. Cono lipídico tras uso prolongado (vigilar triglicéridos)."
    ),
    Drug(
        "Etomidato",
        "Inductor imidazólico",
        "Inducción: 0,2–0,3 mg/kg IV. Sin analgesia.",
        "Inducción en el paciente inestable, hipovolémico, cardiópata grave o con trauma: mínima depresión cardiovascular.",
        "Mioclonías (premedicar con midazolam u opioides), supresión adrenal reversible con dosis única, náuseas y vómitos, dolor a la inyección. No mantiene la anestesia en infusión por supresión suprarrenal."
    ),
    Drug(
        "Tiopental",
        "Inductor barbitúrico",
        "Inducción: 3–5 mg/kg IV. Pediátrico: 5–6 mg/kg.",
        "Inducción clásica (aún disponible en Cuba), anticonvulsivante de elección en status epilepticus refractario, neuroprotección tras isquemia cerebral.",
        "Hipotensión (vasodilatación + depresión miocárdica), apnea frecuente, necrosis cutánea si extravasación (solución muy alcalina), proconvulsivo paradójico a dosis bajas, contraindicado en porfiria. Trigger de hipertermia maligna."
    ),
    Drug(
        "Ketamina",
        "Anestésico disociativo (antagonista NMDA)",
        "Inducción: 1–2 mg/kg IV; 4–8 mg/kg IM. Analgesia subanestésica: 0,1–0,3 mg/kg IV; infusión: 0,1–0,5 mg/kg/h. Pediátrico sedación: 1–2 mg/kg IV.",
        "Inducción en shock e hipovolemia, analgesia multimodal y opioide-sparing, broncodilatador (asmático), sedación fuera de quirófano, anestesia en campos de guerra y zonas rurales.",
        "Alucinaciones y sueños vívidos (premedicar midazolam), taquicardia e hipertensión (evitar en cardiopatía isquémica descompensada e HTA no controlada), hipersecretión (usar atropina/glicopirrolato), nistagmo. Conserva reflejos, pero no protege la vía aérea al 100%."
    ),
    Drug(
        "Midazolam",
        "Benzodiazepina de acción corta",
        "Premedicación VO: 0,5 mg/kg (máx. 15–20 mg) en niños; 0,03–0,07 mg/kg IM. Sedación IV: 0,02–0,05 mg/kg titulada. Inducción: 0,1–0,2 mg/kg. Reversión: flumazenil.",
        "Premedicación ansiolítica e hipnótica, sedación consciente, amnesia perioperatoria, control de convulsiones, adyuvante en inducción (sinerjia con propofol).",
        "Depresión respiratoria sinérgica con opioides (dosis habituales reducidas 50%). Acumulación en el anciano, obeso, hepático y renal. Delirium postoperatorio. Vía oral con sospecha de vía aérea difícil: no usar."
    ),
    Drug(
        "Diazepam",
        "Benzodiazepina de acción larga",
        "Sedación: 2–10 mg IV lento (2–5 mg/min). Convulsiones: 5–10 mg IV, repetible cada 10–15 min.",
        "Ansiolisis, control de convulsiones, espasticidad, desintoxicación alcohólica. Emulsión lipídica (Diazemuls) si se necesita IV: menos flebitis.",
        "Vida media muy larga (20–50 h) con metabolito activo (desmetildiazepam): sedación residual. Dolor y tromboflebitis en presentación oleosa. Absorción errática por vía IM. No mezclar en la misma jeringa con otros fármacos."
    ),
    Drug(
        "Dexmedetomidina",
        "Agonista alfa-2 central",
        "Carga: 0,5–1 µg/kg en 10–15 min (opcional). Mantenimiento: 0,2–0,7 µg/kg/h.",
        "Sedación cooperativa sin depresión respiratoria, adyuvante opioide-sparing en TIVA, sedación de intubación en UCI, cirugía despierta (craneotomía awake y endarterectomía carotídea), control de temblor postoperatorio.",
        "Bradicardia e hipotensión con la carga rápida (administración mínima 10 min). Hipertensión paradójica si carga muy rápida. Cuidado en bloqueo AV y paciente con poco volumen."
    ),
    Drug(
        "Fentanilo",
        "Opioide agonista µ sintético",
        "Inducción: 1–3 µg/kg IV. Bolus intraoperatorio: 0,5–1 µg/kg. Infusión: 0,7–2 µg/kg/h. Analgesia postoperatoria: 0,5–1 µg/kg titulada.",
        "Analgesia intraoperatoria de base, estabilidad hemodinámica en la inducción (cardiópata), supresión de la respuesta al laringoscopio, analgesia de parto y postoperatoria.",
        "Depresión respiratoria intensa y prolongada, rigidez torácica con bolus rápidos (>2 µg/kg: paralizar si es preciso), bradicardia vagal. Acumulación tras infusión prolongada (contexto sensible). Náuseas, prurito, retención urinaria. Ventilar siempre tras bolus."
    ),
    Drug(
        "Remifentanilo",
        "Opioide µ de metabolismo por esterasas",
        "Infusión: 0,05–0,25 µg/kg/min (inducción sin bolus: 0,5–1 µg/kg/min con propofol). Bolus no recomendado en mantenimiento.",
        "TIVA con propofol (hipnosis profunda + analgesia profunda), cirugía neuroquirúrgica con recuperación rápida, paciente renal o hepático grave (independiente de la función de órganos), maniobras de vía aérea compartida.",
        "Vida media contextual 3–5 min: NO deja analgesia postoperatoria. Planificar analgesia multimodal 20–30 min antes de suspender (paracetamol + AINE + opioides largos ± bloqueo). Hipersensibilidad a la bradicardia e hipotensión: reducir en el anciano. Hiperalgesia aguda tras suspender."
    ),
    Drug(
        "Morfina",
        "Opioide natural agonista µ",
        "IV titulada: 0,02–0,05 mg/kg (2–4 mg en adulto). Subcutánea: 0,05–0,1 mg/kg. Pediátrica: 0,05 mg/kg IV. Analgesia controlada: 1–2 mg/h infusiones lentas.",
        "Analgesia postoperatoria de referencia, dolor oncológico (escalera de la OMS, escalón II–III), analgesia epidural/intratecal (formas preservadas).",
        "Liberación de histamina: hipotensión, prurito, broncoespasmo (cuidado en asmáticos). Metabolito M6G se acumula en la insuficiencia renal: preferir fentanilo. Depresión respiratoria tardía (pico 20–30 min IV). Náuseas, constipación, retención urinaria, colédocoespasmo."
    ),
    Drug(
        "Petidina (Meperidina)",
        "Opioide sintético fenilpiperidina",
        "IV: 0,5–1 mg/kg (25–100 mg en adulto) titulada. IM: 1–2 mg/kg. Escalofríos postoperatorios: 0,3–0,5 mg/kg IV.",
        "Analgesia postoperatoria alternativa, tratamiento de escalofríos postoperatorios, espasmos de la vía biliar, prurito inducido por neuraxial (dosis bajas).",
        "Metabolito normeperidina neurotóxico (convulsiones) que se acumula en la insuficiencia renal y con dosis repetidas: NO usar más de 48–72 h. Interacción grave con IMAO (síndrome serotoninérgico y crisis). Hipotensión y taquicardia (actividad anticolinérgica). Evitar en el paciente renal, del anciano y con TCA."
    ),
    Drug(
        "Tramadol",
        "Opioide débil + inhibición recaptación de 5-HT/NA",
        "IV lenta: 1–2 mg/kg (50–100 mg), repetible c/6–8 h. Máximo 400–600 mg/día (adulto). VO 50–100 mg c/6–8 h.",
        "Analgesia de escalón II–III (dolor moderado), opioide-sparing postoperatoria, dolor crónico oncológico. Menor depresión respiratoria que los agonistas puros.",
        "Náuseas y vómitos muy frecuentes (usar profilaxis antiemética). Reduce el umbral convulsivo (evitar en epilépticos y con antidepresivos/IMAO: riesgo serotoninérgico). Menos eficaz en metabolizadores ultrarrápidos CYP2D6. Hipoglucemia. Reducir dosis en renal (CrCl<30) y hepático."
    ),
    Drug(
        "Dipirona (Metamizol)",
        "Analgésico-antipirético no opioide (pirazolona)",
        "IV lenta (≥1 mg/kg/min): 15–25 mg/kg (1–2 g en adulto), c/6–8 h. Máximo 5 g/día. VO 500–1000 mg c/6–8 h.",
        "Dolor visceral y postoperatorio de moderado a grave (muy utilizada en Cuba y Latinoamérica), fiebre refractaria, cólico renal y biliar, opioide-sparing.",
        "Inyectar SIEMPRE lento y diluido: hipotensión severa si rápida. Riesgo raro de agranulocitosis (informar al paciente y vigilar fiebre/faringo). Hipersensibilidad (evitar en alérgicos a pirazolonas). Preferir en <7 días de tratamiento."
    ),
    Drug(
        "Paracetamol (Acetaminofén)",
        "Analgésico-antipirético",
        "IV: 15 mg/kg c/6 h (adulto: 1 g c/6 h; máx. 60–75 mg/kg/día, nunca >4 g/día). VO: 10–15 mg/kg c/4–6 h.",
        "Analgesia multimodal de base (siempre que no haya contraindicación), fiebre, opioide-sparing. IV cuando no se tolera la vía oral o preoperatorio inmediato.",
        "Hepatotoxicidad por sobredosis o hígado grave, alcoholismo, desnutrición, bajo peso (<50 kg: máx. 3 g/día). Espaciado mínimo de 4 h por vía IV. Administrar en 15 min. Máx. 3 días IV: pasar a VO."
    ),
    Drug(
        "Suxametonio (Succinilcolina)",
        "Relajante despolarizante",
        "IV: 1–1,5 mg/kg (RSI). Infusión: 0,05–0,1 mg/kg/min. IM (niño): 2–4 mg/kg. Máx. 150–200 mg en adulto.",
        "Secuencia rápida de intubación (aparición 45 s, duración 6–10 min), vía aérea con contenido gástrico, laringoespasmo refractario, intubación de urgencia cuando no hay vía IV (IM).",
        "CONTRAINDICADO: hiperkalemia (quemados, aplastamiento, denervación, miopatía, postrauma >48–72 h), antecedente personal/familiar de hipertermia maligna (trigger), miotonías, glaucoma o lesión ocular abierta, alergia previa. Fase II de bloqueo con infusión prolongada. Bradicardia (niños), espasmo de los maseteros, mialgias postoperatorias, ↑ PIO y PIC."
    ),
    Drug(
        "Rocuronio",
        "Relajante aminosteroide no despolarizante",
        "Intubación: 0,6 mg/kg (1–1,2 mg/kg en RSI). Mantenimiento: 0,1–0,2 mg/kg o 8–12 µg/kg/min. Reversión: neostigmina o sugammadex (2–4 mg/kg; 16 mg/kg si RSI con 1,2).",
        "Secuencia rápida alternativa al suxametonio (reversible inmediatamente con sugammadex), intubación programada 60–90 s, mantenimiento del bloqueo en cirugía general.",
        "Duración 30–60 min (más con dosis altas): monitorizar TOF siempre. Enfermedad hepática y renal: prolongación. Riesgo de bloqueo residual si se revierte antes de tiempo. Conservar en refrigeración."
    ),
    Drug(
        "Vecuronio",
        "Relajante aminosteroide no despolarizante",
        "Intubación: 0,08–0,1 mg/kg (90–120 s). Mantenimiento: 0,02–0,03 mg/kg o infusión 1–2 µg/kg/min.",
        "Mantenimiento del bloqueo sin liberación de histamina (cardiópata, asmático), cirugía cardiovascular y larga duración.",
        "Duración 30–45 min, prolongada en el hepático, renal, obeso y con hipotermia. Acumulación del metabolito 3-OH. Fácil bloqueo residual: TOF obligatorio. Polimixinas y magunesio potencian."
    ),
    Drug(
        "Atracurio",
        "Relajante bencilisoquinolina no despolarizante",
        "Intubación: 0,5 mg/kg (2,5–3 min). Mantenimiento: 0,1–0,2 mg/kg o 6–10 µg/kg/min.",
        "Elegante en la insuficiencia hepática y renal (eliminación por degradación de Hoffman, independiente de órganos), UCI, cirugía general.",
        "Liberación de histamina a dosis altas o rápidas: hipotensión, enrojecimiento, broncoespasmo (inyectar lento). Laudanosina (acumula con dosis muy altas y en el neonato). Duración 25–35 min. Conservar en refrigeración."
    ),
    Drug(
        "Cisatracurio",
        "Relajante bencilisoquinolina (isómero R-cis del atracurio)",
        "Intubación: 0,15–0,2 mg/kg (2–3 min). Mantenimiento: 0,03 mg/kg o 1–3 µg/kg/min.",
        "Igual perfil de Hoffman que el atracurio pero 4× más potente y SIN liberación de histamina: cirugía cardíaca, paciente hepatorrenal, asmático.",
        "Duración 45–60 min. No liberación de histamina clínicamente relevante. TOF siempre. Conservar en refrigeración. Caro: reservar para las indicaciones de elección."
    ),
    Drug(
        "Sugammadex",
        "Agente reversor selectivo (encapsulante de ciclodextrina)",
        "Reversión rutinaria (T2 visible): 2 mg/kg. Bloqueo profundo (1–2 PTC): 4 mg/kg. Reversión inmediata tras 1,2 mg/kg de rocuronio (RSI): 16 mg/kg.",
        "Reversión rápida y predecible del rocuronio y vecuronio (3–5 min con 4 mg/kg), rescate en vía aérea difícil (\"can't intubate, can't ventilate\" tras RSI con rocuronio).",
        "NO revierte bencilisoquinolinas (atracurio/cisatracurio) ni suxametonio. Dosis dependiente de la función renal (en diálisis grave no recomendado). Recurrencia del bloqueo si la dosis es insuficiente o hay fármacos potenciadores. Interacción hormonal (anticoncepción: usar barrera 7 días). Caro: priorizar rescate."
    ),
    Drug(
        "Neostigmina + Atropina (reversión)",
        "Anticolinesterasa + anticolinérgico (mezcla clásica)",
        "Neostigmina 0,04–0,06 mg/kg (máx. 5 mg) + atropina 0,015–0,02 mg/kg IV simultáneas (o glicopirrolato 0,005–0,01 mg/kg). Administrar solo con T2 visible (TOF ≥2).",
        "Reversión del bloqueo neuromuscular no despolarizante al final de la cirugía cuando no se dispone de sugammadex o el bloqueo es moderado.",
        "NUNCA con TOF <2 (reversión paradójica). Efectos muscarínicos: bradicardia, sialorrea, broncoespasmo, hipotensión, peristaltismo (por eso la atropina/glicopirrolato). Neoplasia, obstrucción intestinal, bradicardia severa: precaución. Vigilar TOF ≥0,9 tras 10–15 min."
    ),
    Drug(
        "Efedrina",
        "Simpaticomimético indirecto ± directo (α, β)",
        "Bolus IV: 5–10 mg, repetible cada 3–5 min. Infusión: 0,5–2 mg/min. IM: 25–50 mg si no hay vía IV.",
        "Hipotensión anestésica con bradicardia asociada, hipotensión obstétrica (alternativa a la fenilefrina cuando la FC es baja), primer vasopresor histórico.",
        "Taquicardia y arritmias con dosis repetidas. Taquifilaxia rápida (depleción de noradrenalina). Aumenta el consumo miocárdico de O2 (cuidado en isquemia). Evitar en hipertensión severa."
    ),
    Drug(
        "Fenilefrina",
        "Vasopresor puro α1",
        "Bolus IV: 50–100 µg (0,5–1 µg/kg). Infusión: 0,25–3 µg/kg/min. Dilución práctica: 1 mg en 100 mL = 10 µg/mL.",
        "Hipotensión con taquicardia, primera línea de la hipotensión espinal obstétrica (mantiene la perfusión uterina y el pH fetal), estenosis aórtica subaórtica (HOCM) y tetralogía de Fallot (crisis de cianosis).",
        "Bradicardia refleja (combinar o alternar con efedrina si FC cae). Vasoconstricción periférica e isquemia digital si extravasación. Dosis altas en el feto: acidosis leve, compensable. No mezclar con bicarbonato."
    ),
    Drug(
        "Adrenalina (Epinefrina)",
        "Catecolamina endógena (α, β1, β2)",
        "Anafilaxia: 0,5 mg IM (0,5 mL 1:1000), repetir cada 5 min; IV titulada solo con acceso y monitoría: 50–100 µg, luego 0,05–0,1 µg/kg/min. Paro cardíaco: 1 mg IV cada 3–5 min (pediátrico 0,01 mg/kg). Local: 1:100 000–1:200 000 en el infiltrado.",
        "Anafilaxia perioperatoria (primera línea), paro cardiorrespiratorio, bradicardia/paro neonatal, reducción del sangrado en ORL (adrenalina local), coadyuvante de los anestésicos locales.",
        "Arritmias ventriculares con halogenados e hipercapnia. Isquemia miocárdica. Necrosis si extravasación (fentolamina local). Enmascara la hipovolemia. Dosis imprecisas en diluciones 1:1000 vs 1:10 000: doble control. Las infusiones van siempre en bomba."
    ),
    Drug(
        "Labetalol",
        "Bloqueador mixto α1 + β",
        "Bolus IV lento: 5–10 mg en 1–2 min, repetir 10–20 mg cada 10 min (máx. 200–300 mg). Infusión: 0,5–2 mg/min. VO: 100 mg c/12 h.",
        "Crisis hipertensivas perioperatorias, preeclampsia/eclampsia (primer bloqueador obstétrico), diseción aórtica (con β puro de preferencia), HTA en la fase de inducción.",
        "Bradicardia, bloqueo AV (contraindicado), asma (cuidado), insuficiencia cardíaca aguda descompensada, hipotensión prolongada y acumulativa. Enmascara la hipoglucemia. No suspender β-bloqueantes crónicos."
    ),
    Drug(
        "Amiodarona",
        "Antiarrítmico clase III multifásico",
        "Tachyarritmias con pulso: 150 mg IV en 10 min, luego 1 mg/min × 6 h + 0,5 mg/min × 18 h (máx. 2,2 g/24 h). Paro FV/TVSP: 300 mg IV bolus tras el 3.º choque, repetir 150 mg.",
        "Fibrilación ventricular/TV sin pulso (paro), taquiarritmias supraventriculares y ventriculares perioperatorias, fibrilación auricular de nueva aparición.",
        "Hipotensión y bradicardia con la carga rápida (bomba 10 min). Torsades (prolonga QT: vigilar K y Mg). Toxicidad crónica: tiroides, pulmón (fibrosis), hígado, flebitis (vía central si es posible). Potencia digoxina y warfarina. NO combinar con otros que prolongan el QT."
    ),
    Drug(
        "Metoclopramida",
        "Antiemético procinético (antagonista D2)",
        "IV lenta: 10 mg (0,1–0,15 mg/kg), c/8 h, máx. 30–45 mg/día. VO: 10 mg c/8 h antes de las comidas.",
        "Profilaxis NVPO (mejor profiláctico que terapéutico), vaciado gástrico en la urgencia (entrega de la vía), náuseas por opioides, ileo postoperatorio (coadyuvante).",
        "Reacciones extrapiramidales (discinesia aguda, más en jóvenes y mujeres: difenhidramina 25 mg IV como antídoto), sedación. Contraindicada en obstrucción intestinal, perforación, feocromocitoma, parkinsonismo. Vía IV en 2–3 min. Máximo 5 días."
    ),
    Drug(
        "Ranitidina",
        "Antagonista H2",
        "IV: 50 mg c/8 h (1 mg/kg). VO: 150 mg la noche anterior y 2 h antes de la cirugía electiva. Pediátrico: 1 mg/kg IV.",
        "Profilaxis del síndrome de aspiración (Mendelson): ↑ pH y ↓ volumen del contenido gástrico, paciente con reflujo, embarazo, obesidad, urgencia.",
        "Retirada en varios mercados por nitrosaminas (NDMA): en Cuba sigue en uso institucional (alternativa: famotidina 20 mg IV). Interacción con la absorción de otros fármacos. Reducir dosis en renal. Taquicardia con bolo rápido."
    ),
    Drug(
        "Cimetidina",
        "Antagonista H2 clásico",
        "IV: 300 mg c/6–8 h (diluido en 20 mL, 2 min). VO: 300–400 mg c/6–8 h. Pediátrico: 5–10 mg/kg/día dividido.",
        "Profilaxis de aspiración (alternativa histórica a la ranitidina), úlcera de estrés, dispepsia perioperatoria.",
        "Potente inhibidor del citocromo P450: interacciones con diazepam, warfarina, teofilina, lidocaína. Efectos antiandrogénicos y centrales (confusión en el anciano y renal). Menos usado hoy. Reducir dosis en renal."
    ),
    Drug(
        "Difenhidramina (Benadrilina)",
        "Antihistamínico H1 de primera generación",
        "IV lenta o IM: 25–50 mg (0,5–1,25 mg/kg), c/6 h, máx. 300 mg/día. Pediátrico: 1 mg/kg.",
        "Reacciones anafilactoides y alergia perioperatoria (coadyuvante tras la adrenalina), reacciones extrapiramidales de la metoclopramida, profilaxis de reacciones al contraste/látex, prurito por opioides.",
        "Sedación marcada (no conducir), efecto anticolinérgico: boca seca, midriasis, taquicardia, retención urinaria, delirium en el anciano (Beers). Potencia otros depresores del SNC. Excitación paradójica en niños."
    ),
    Drug(
        "Hidrocortisona",
        "Corticoide glucocorticoide-mineraloide (equivalente endógeno)",
        "Estrés/anafilaxia: 100–200 mg IV (1–2 mg/kg). Sustitución suprarrenal perioperatoria: 50–100 mg IV c/8 h el día de la cirugía y 24–72 h según el grado de estrés.",
        "Insuficiencia suprarrenal perioperatoria (paciente en esteroides crónicos: ¡no omitir!), coadyuvante de la anafilaxia (fase tardía), choque séptico a dosis de estrés, edema de vía aérea.",
        "Hiperglucemia (vigilar en diabéticos), retención de sodio e hipokalemia, immunosupresión con dosis repetidas. No es el de elección antiinflamatoria crónica (preferir prednisona VO en el alta). Reconstituir justo antes de usar."
    ),
    Drug(
        "Naloxona",
        "Antagonista opioide µ puro",
        "IV titulada: 40–100 µg (diluir 0,4 mg en 10 mL = 40 µg/mL), repetir cada 2–3 min. Pediátrico: 1–5 µg/kg. Infusión anti-renarcotización: 2/3 de la dosis total efectiva por hora.",
        "Depresión respiratoria por opioides (diagnóstico + tratamiento), sedación excesiva postoperatoria, sobredosis intencional o accidental, neonatal (madre con opioides).",
        "Vida media corta (30–45 min) vs. morfina/fentanilo: RENARCOTIZACIÓN (vigilar 2 h mín., usar infusión). Reacción de abstinencia aguda (náuseas, taquicardia, agitación, hipertensión: titular, no bolus). Dolor intenso súbito. Edema pulmonar (raro)."
    ),
    Drug(
        "Flumazenil",
        "Antagonista benzodiazepínico competitivo",
        "IV: 0,2 mg en 15 s; si no responde: 0,1 mg/min hasta un máximo de 1 mg. Pediátrico: 0,01 mg/kg (máx. 0,2 mg).",
        "Reversión de la sedación por benzodiazepinas (procedimientos, sedación excesiva), diagnóstico diferencial de coma por benzodiazepinas.",
        "RIESGO DE CONVULSIONES si hay dependencia a benzodiazepinas, epilepsia, ingestión mixta con antidepresivos tricíclicos o con el uso crónico: no usar de rutina. Vida media corta: re-sedación (vigilar 2 h). Náuseas, cefalea, agitación."
    ),
    Drug(
        "Atropina",
        "Anticolinérgico parasimpaticolítico",
        "Bradicardia sintomática: 0,5 mg IV (adulto), repetible hasta 3 mg. Pediátrico: 0,01–0,02 mg/kg (mínimo 0,1 mg). Premedicación antisialagoga: 0,005 mg/kg IM/SC 30–60 min antes.",
        "Bradicardia sintomática y vagal (oculocardiaco, peritoneal, succión), coadyuvante de la reversión con neostigmina, paro cardíaco bradisistólico, reducción de secreciones.",
        "Taquicardia (cuidado en isquemia e hipertermia), midriasis y confusión (delirium en el anciano), boca seca. Ineficaz en trasplante cardíaco (denervado). Dosis pediátrica mínima 0,1 mg (evita bradicardia paradójica). Precaución en glaucoma de ángulo cerrado e hipertrofia prostática"
    ),
    Drug(
        "Ondansetrón",
        "Antiemético antagonista 5-HT3",
        "IV lenta: 0,1 mg/kg (4–8 mg en adulto) al final de la cirugía o 30 min antes. VO: 8 mg 1 h antes (máx. 16 mg/día). Pediátrico >1 mes: 0,1 mg/kg.",
        "Profilaxis y rescate de NVPO, náuseas por quimioterapia, NVPO en pacientes de alto riesgo (femenino, no fumador, antecedente, opioides).",
        "Prolongación del QT (vigilar otros QT y alteraciones electrolíticas), cefalea, estreñimiento. Menos eficaz como rescate tras profilaxis con la misma clase (cambiar de clase: droperidol o dimenhidrinato). Inyectar en 2–5 min."
    ),
    Drug(
        "Dexametasona",
        "Corticoide de acción larga",
        "AntiNVPO: 4–8 mg IV al inicio de la inducción. Edema/antiinflamatorio: 4–10 mg IV c/6–8 h. Coadyuvante de bloqueos: 4–8 mg.",
        "Profilaxis NVPO (potente, sinergia con ondansetrón), edema postquirúrgico (ORL, tiroides), dolor postoperatorio (opioide-sparing), antiinflamatorio general.",
        "Hiperglucemia transitoria (vigilar diabéticos 4–6 h), enrojecimiento facial/anal perineal con IV rápida, insomnio. Riesgo infeccioso con dosis repetidas. No en infección activa sin cobertura. Interfiere con la cicatrización a dosis altas repetidas."
    ),
    Drug(
        "Droperidol",
        "Butirofenona neuroléptica antiemética",
        "IV: 0,625–1,25 mg al final de la cirugía (rescate NVPO). Neuroleptoanalgesia (histórica): 2,5–5 mg con fentanilo.",
        "Rescate de NVPO refractario a 5-HT3, agitación y delirium postoperatorio (dosis bajas), prurito refractario, antiemético multimodal.",
        "Prolongación del QT y arritmias (advertencia FDA histórica: ECG si factores de riesgo). Sedación y disforia, acatisia y síntomas extrapiramidales (difenhidramina como antídoto), hipotensión. Evitar en parkinsonismo. Dosis mínima eficaz."
    ),
    Drug(
        "Heparina sódica no fraccionada",
        "Anticoagulante (potencia la antitrombina III)",
        "Bolus pre-CPB: 300–400 U/kg (ACT >480 s). Cirugía vascular: 50–100 U/kg. Profilaxis: 5000 U SC c/8–12 h. Reversión: protamina 1 mg por cada 100 U de heparina (IV lenta, 10 min).",
        "Circulación extracorpórea, cirugía cardíaca y vascular, tromboprofilaxis perioperatoria, anticoagulación de catéteres y monitores, mantención de vías.",
        "Sangrado (vigilar ACT/TTPa), HIT (trombocitopenia inducida por heparina: contar plaquetas), osteoporosis con uso prolongado. Reacción a la protamina (hipotensión, broncoespasmo, embolia pulmonar; diabéticos en NPH: riesgo alto, inyectar lento). Dosis ajustada en el obeso (peso ajustado)."
    ),
    Drug(
        "Protamina",
        "Antídoto de la heparina (polipéptido básico)",
        "IV MUY lenta (≥10 min): 1 mg por cada 100 U de heparina activa en el paciente (calcular según el tiempo desde el último bolus). Máximo 50 mg por vía periférica.",
        "Reversión de la anticoagulación por heparina al final de la cirugía cardíaca/vascular, sangrado por heparina (parcial, mantener el objetivo ACT ~150–200 s si es posible).",
        "Hipotensión severa y colapso con la inyección rápida (vasodilatación pulmonar, falla ventricular derecha): SIEMPRE lenta, con volumen y vasopresores listos. Reacciones anafilácticas (alergia al pescado, NPH, vasectomía). Anticoagulación paradójica si hay exceso."
    ),
    Drug(
        "Noradrenalina (Norepinefrina)",
        "Vasopresor catecolamínico endógeno (α1 predominante + β1 moderado)",
        "Bolus de rescate IV: 4–8 µg diluidos (16 µg/mL). Infusión: iniciar 0,05 µg/kg/min y titular a PAM ≥65 mmHg; rango habitual 0,02–0,5 µg/kg/min (shock refractario hasta 1). Neonatal/pediátrico: 0,01–0,3 µg/kg/min.",
        "Vasopresor de PRIMERA LÍNEA en el shock séptico y la hipotensión refractaria perioperatoria (sepsis, anafilaxia ya tratada, post-CEX, vasoplejía por IECA/ARA-II). Coadyuvante en la anafilaxia refractaria y el bajo gasto con vasodilatación.",
        "Isquemia distal y necrosis cutánea si extravasación (antídoto local: fentolamina 5–10 mg en 10 mL de SSN). Bradicardia refleja. ↓ flujo esplácnico y renal a dosis altas. Vía central recomendada >0,1 µg/kg/min; si es periférica: vena gruesa, valorar cada 2–4 h. Diluir SIEMPRE en dextrosa 5 % (se oxida en solución salina). Arritmias: menos que dopamina."
    ),
    Drug(
        "Dopamina",
        "Catecolamina endógena (efecto dosis-dependiente: dopaminérgico → β1 → α)",
        "Infusión: 2–20 µg/kg/min titulada. 2–5 µg/kg/min: dopaminérgico (histórico \"renal\", sin beneficio probado). 5–10: inotrópico β1. >10: α vasoconstrictor. Bradicardia sintomática refractaria (ACLS): 5–20 µg/kg/min. Neonatal: 2–20 µg/kg/min.",
        "Shock con hipoperfusión e hipotensión moderada, bradicardia sintomática refractaria a atropina (alternativa al marcapasos transitorio), soporte inotrópico cuando se desea ↑ gasto + ↑ tono vascular simultáneos.",
        "El MÁS arritmogénico de los vasopresores (SOAP II: más taquiarritmias que noradrenalina en sepsis). Extravasación grave (fentolamina local). Taquifilaxia. NO mezclar con bicarbonato ni alcalinos (inactivación). No usar la \"dosis renal\" de rutina ni para la profilaxis de la disfunción renal. ↑ consumo miocárdico de O2 y presiones pulmonares."
    ),
    Drug(
        "Dobutamina",
        "Inotrópico sintético (β1 > β2, agonista directo)",
        "Infusión: 2–20 µg/kg/min (típico 5–10). Neonatal/pediátrico: 2–20 µg/kg/min (lactantes: taquicardia frecuente). No requiere carga.",
        "Bajo gasto cardíaco con PA aceptable: post-CEX con disfunción ventricular, shock séptico con cardiomiopatía (combinado con noradrenalina), test de estrés farmacológico, trasplante cardíaco donante con función límite.",
        "Taquiarritmias (FA, TV) y ↑ consumo miocárdico de O2: evitar en isquemia activa. Vasodilatación β2 → hipotensión (combinar con noradrenalina, no asumir fallo inotrópico). Taquifilaxia >72 h (↓ receptores β). ↑ presiones pulmonares en algunas valvulopatías. No mezclar con bicarbonato ni con alcalinos."
    ),
    Drug(
        "Milrinona",
        "Inhibidor de la fosfodiesterasa-3 (inodilatador, no catecolamínico)",
        "Carga: 25–50 µg/kg en ≥10 min (opcional). Infusión: 0,375–0,75 µg/kg/min. ClCr <50 mL/min: reducir ~50 %. Pediátrico post-CEX: 0,25–0,75 µg/kg/min.",
        "Bajo gasto con hipertensión pulmonar y/o diástole rígida (post-CEX valvular y cardíaco congénito), shock vasopléjico con β-bloqueo crónico (actúa distal al receptor β), coadyuvante del destete de CEX, IC aguda refractaria.",
        "Vasodilatación → HIPOTENSIÓN (omitir la carga si PA límite o hipovolemia; evitar con estenosis valvulares severas: ↓ postcarga crítica). Acumulación renal (vida media 2,4 h): hipotensión prolongada difícil de revertir (antídoto: volumen + vasopresor). Arritmias auriculares. No mezclar con furosemida (precipita)."
    ),
    Drug(
        "Vasopresina",
        "Hormona antidiurética (agonista V1 vascular; no catecolamínica)",
        "Infusión adulto: dosis FIJA 0,01–0,04 U/min (no ponderal, no titulable; refractario: hasta 0,06). Paro cardíaco: 40 U IV (puede sustituir el 1.º o 2.º mg de adrenalina). Pediátrico: 0,0002–0,002 U/kg/min.",
        "Shock vasopléjico CATECOLAMINORRESISTENTE (sepsis tardía, post-CEX, IECA/ARA-II, trasplante): ahorra catecolaminas y ↑ PAM sin ↑ FC ni consumo de O2. Acidosis metabólica severa (pierde efecto la adrenalina). Vasoplejía del trasplante y del cirrótico.",
        "Isquemia esplácnica, digital y miocárdica (↓ flujo territorial). ↓ gasto cardíaco si ya hay falla derecha. Hiponatremia con uso prolongado. NO titulable: pausar ante ↑ PAM brusca. Cuidado en enfermedad coronaria severa y en obstetricia (contracción uterina). Contraindicada relativa: enfermedad vascular oclusiva."
    ),
    Drug(
        "Nitroglicerina (Trinitrato de glicerilo)",
        "Donador de óxido nítrico (venodilatador predominante)",
        "Bolus IV (espasmo coronario): 50–100 µg; SL 0,4 mg. Infusión: iniciar 5–20 µg/min (o 0,5 µg/kg/min) y titular; rango 0,5–5 µg/kg/min (hasta 10). Pediátrico (HTAP): 0,5–5 µg/kg/min.",
        "Isquemia coronaria perioperatoria y espasmo coronario (tratamiento y profilaxis), HTA con ↑ presiones pulmonares o ↓ preload deseable (disfunción diastólica, síndrome de distress agudo), control de sangrado ORL (tópico), tocolisis puntual.",
        "Hipotensión (especialmente con hipovolemia preload-dependiente: estenosis aórtica, HOCM, RV aguda). Cefalea intensa. Taquifilaxia en 24–48 h. Metahemoglobinemia con infusiones >5 µg/kg/min prolongadas. PROHIBIDO con inhibidores PDE-5 recientes (sildenafil <24 h, tadalafil <48 h: colapso refractario; rescate: vasopresina). Absorbido al plástico PVC: usar tubos no PVC si posible. ↑ espacios muertos alveolares y NOU con dosis altas."
    )
)

// ------------------------------- GASES (5) -------------------------------

val GASES_RAW = listOf(
    GasAnest(
        "Sevoflurano",
        "MAC adulto: 2,0–2,1% (anciano ~1,7; niño ~2,5)",
        "Volátil halogenado de menor solubilidad (coeficiente sangre/gas 0,65). Inducción suave y no irritante, aroma aceptable. Punto de ebullición 58,6 °C: vaporizador estándar. Estable en el circuito.",
        "GAS DE INDUCCIÓN PEDIÁTRICA por excelencia (8% + O2/N2O), mantenimiento de la anestesia general, mascarilla en el adulto. Flujo bajo (<2 L/min) prolongado con cal sodada caliente: compuesto A (precaución teórica en <2 h). Recuperación rápida. Perfusión cerebral ↑: cuidado en la hipertensión intracraneal."
    ),
    GasAnest(
        "Isoflurano",
        "MAC adulto: 1,15–1,2%",
        "Solubilidad intermedia (sangre/gas 1,4). Irritante de la vía aérea (no para inducción). Depresión cardiovascular moderada con vasodilatación. Aumenta la FC compensatoria con la profundidad. Económico y muy estable.",
        "MANTENIMIENTO en el paciente general, muy usado en Cuba por costo y disponibilidad. Cirugía cardíaca (precondicionamiento isquémico). No apropiado para inducción por irritación (tos, laringoespasmo). Flujo bajo OK. Coronary steal teórico a >1,5 MAC (debate histórico)."
    ),
    GasAnest(
        "Desflurano",
        "MAC adulto: 6,0–6,5%",
        "El volátil menos soluble (sangre/gas 0,42): recuperación más rápida. Muy irritante (prohibida la inducción). Punto de ebullición 23,5 °C: vaporizador calentado y presurizado (Tec 6). Activa el simpático: taquicardia/HTA al subir bruscamente la concentración.",
        "Cirugía ambulatoria y de corta duración con recuperación ultra-rápida, obesidad mórbida (recuperación temprana), mantenimiento en adulto. NO usar en niños <6 años ni para inducción. Subida brusca de dosis → taquicardia: aumentar gradualmente. Caro: disponibilidad limitada."
    ),
    GasAnest(
        "Halotano",
        "MAC adulto: 0,75% (niño 0,9)",
        "El más soluble (sangre/gas 2,4) y el más potente. No irritante, olor dulce: inducción pediátrica histórica. Depresión miocárdica marcada. Sensibiliza el miocardio a la adrenalina. Se metaboliza 20–25%.",
        "Aún disponible en hospitales cubanos como opción de inducción pediátrica y mantenimiento básico. Vaporizador específico (calibrado). Requiere vigilancia cardíaca: bradicardia e hipotensión.",
        "Hepatitis por halotano (rara, más en adultos y exposiciones repetidas: evitar reexposición <3 meses, espaciar >6 meses si hay ictericia previa). TRIGGER de hipertermia maligna. Arritmias con adrenalina (máx. 1–2 µg/kg lentas). En retirada progresiva del mundo."
    ),
    GasAnest(
        "N2O (Óxido nitroso)",
        "MAC 104% (no anestésico solo: analgésico y adyuvante)",
        "Gas inorgánico almacenado en cilindros grises/azules. Muy poco soluble (sangre/gas 0,47) pero 34× más soluble que el N2: efecto del segundo gas y difusión a cavidades aéreas. Analgésico real a 30–50%. Depresión cardiovascular mínima.",
        "Adyuvante de los volátiles (reducción de la MAC ~50% con 60%), analgesia obstétrica y odontológica (Entonox 50/50), cateterismos y punciones pediátricas. Nunca usar <30% de O2 (riesgo de hipoxia).",
        "CONTRAINDICADO: neumotórax no drenado, embolia gaseosa, obstrucción intestinal, quistes/ampollas de oído medio, neumoperitoneo previo, cirugía de oído medio, neurocirugía con aire intracraneal, traumatismo craneal con aire libre, deficiencia de B12/metionina sintetasa (uso prolongado). Aumenta NVPO. Expande volúmenes de aire ×2–4."
    )
)
