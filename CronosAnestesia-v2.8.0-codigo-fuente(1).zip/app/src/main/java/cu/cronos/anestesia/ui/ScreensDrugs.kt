// Cronos Anestesia — Pantallas: Fármacos (cálculo por peso) e Infusiones (mL/h)
package cu.cronos.anestesia.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import cu.cronos.anestesia.data.Dose
import cu.cronos.anestesia.data.Drug
import cu.cronos.anestesia.engine.DerivedWeights
import cu.cronos.anestesia.engine.PatientState
import cu.cronos.anestesia.engine.bolusDose
import cu.cronos.anestesia.engine.fmt
import cu.cronos.anestesia.engine.infusionResult

@Composable
fun FarmacosScreen(patient: PatientState, derived: DerivedWeights, query: String, onQuery: (String) -> Unit) {
    val sp = LocalSpacing.current
    var expandedId by remember { mutableStateOf<String?>(null) }

    val all = cu.cronos.anestesia.data.allDrugs()
    val filtered = if (query.isBlank()) all else all.filter { d ->
        query.split(" ", ",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }.any { q ->
            d.name.lowercase().contains(q) || d.aliases.any { it.lowercase().contains(q) } ||
                d.category.lowercase().contains(q)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(sp.s),
    ) {
        item {
            OutlinedTextField(
                value = query,
                onValueChange = onQuery,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Buscar fármaco (nombre, alias cubano o categoría)") },
            )
        }
        item {
            Text(
                "Cálculos para: ${fmt(patient.weight)} kg · ${if (derived.isPeds) "pediátrico" else "adulto"}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
            )
        }
        items(filtered, key = { it.id }) { drug ->
            DrugCard(drug, patient, derived, expanded = expandedId == drug.id, onToggle = {
                expandedId = if (expandedId == drug.id) null else drug.id
            })
        }
        if (filtered.isEmpty()) {
            item { Text("Sin resultados para «$query».", style = MaterialTheme.typography.bodyMedium) }
        }
    }
}

@Composable
private fun DrugCard(drug: Drug, patient: PatientState, derived: DerivedWeights, expanded: Boolean, onToggle: () -> Unit) {
    val sp = LocalSpacing.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = onToggle,
        colors = CardDefaults.cardColors(
            containerColor = if (expanded) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
        ),
    ) {
        Column(Modifier.padding(sp.m), verticalArrangement = Arrangement.spacedBy(sp.xs)) {
            Text(drug.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Text(
                drug.category + " · " + drug.concentration,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (expanded) {
                drug.doses.forEach { dose -> DoseRow(dose, patient, derived, drug.mgPerMl) }
                if (drug.warnings.isNotEmpty()) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        drug.warnings.forEach { w ->
                            Text("⚠ $w", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
                Text(
                    "Fuentes: " + drug.doses.map { cu.cronos.anestesia.data.Sources.label(it.source) }.distinct().joinToString(" · "),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                Text(
                    drug.doses.joinToString(" · ") { it.label } + " → toque para calcular",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun DoseRow(dose: Dose, patient: PatientState, derived: DerivedWeights, mgPerMl: Double) {
    val sp = LocalSpacing.current
    val r = bolusDose(
        kind = dose.kind,
        min = dose.min,
        max = dose.max,
        weight = patient.weight,
        derived = derived,
        mgPerMl = mgPerMl,
        minAbs = dose.minAbs,
        maxAbs = dose.maxAbs,
        pedsMin = dose.pedsMin,
        pedsMax = dose.pedsMax,
        useIbwOnObese = dose.kind == "mgkg",
    )
    Column(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${dose.label} (${dose.route})", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            Text(
                "${fmt(r.minDose)}–${fmt(r.maxDose)} ${r.unit}",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
            )
        }
        Text(
            "Volumen: ${fmt(r.minMl)}–${fmt(r.maxMl)} mL · ${r.perKgNote}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (dose.note.isNotEmpty()) {
            Text(dose.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}


@Composable
fun InfusionesScreen(patient: PatientState) {
    val sp = LocalSpacing.current
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(sp.s),
    ) {
        item {
            Text(
                "Ritmos para ${fmt(patient.weight)} kg (equipo de 20 gotas/mL). Dosis en mcg/kg/min → mL/h y gts/min.",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
            )
        }
        items(cu.cronos.anestesia.data.INFUSIONS, key = { it.id }) { inf ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
            ) {
                Column(Modifier.padding(sp.m), verticalArrangement = Arrangement.spacedBy(sp.xs)) {
                    Text(inf.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(inf.dilution, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    val r = infusionResult(inf.minMcgKgMin, inf.usualMcgKgMin, inf.maxMcgKgMin, patient.weight, inf.mgPerMl)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Mín.", style = MaterialTheme.typography.labelSmall)
                        Text("${fmt(r.minMlH)} mL/h · ${r.minGts} gts/min", style = MaterialTheme.typography.bodySmall)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Habitual (${fmt(inf.usualMcgKgMin)})", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
                        Text(
                            "${fmt(r.usualMlH)} mL/h · ${r.usualGts} gts/min",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Máx.", style = MaterialTheme.typography.labelSmall)
                        Text("${fmt(r.maxMlH)} mL/h · ${r.maxGts} gts/min", style = MaterialTheme.typography.bodySmall)
                    }
                    if (inf.note.isNotEmpty()) Text(inf.note, style = MaterialTheme.typography.bodySmall)
                    Text("Fuente: ${cu.cronos.anestesia.data.Sources.label(inf.source)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
