// Expedientes de pacientes (v1.7.0) — modelos y persistencia JSON sin dependencias.
// Planes Profesional/Institucional (y extranjeros con licencia PRO): vincular
// cálculos, escalas y procedimientos a un paciente y conservarlos como registro
// histórico exportable a Excel/PDF.
// Parte pura (JSON, orden, formato) vive aquí para poder probarse en JVM.
package cu.cronos.anestesia

import android.content.Context
import androidx.compose.runtime.mutableStateOf
import java.io.File
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

data class RecPatient(
    val id: Long,
    val name: String,
    val historyId: String,   // historia clínica / cédula (opcional)
    val ageText: String,     // texto libre: «45 a», «6 meses»…
    val weightText: String,  // «70 kg»
    val sex: String,         // "", "F", "M"
    val allergies: String,
    val notes: String,
    val createdAt: Long
) {
    /** Línea resumen para tarjetas: «45 a · 70 kg · F». */
    fun summaryLine(): String =
        listOf(ageText.takeIf { it.isNotBlank() }, weightText.takeIf { it.isNotBlank() }, sex.takeIf { it.isNotBlank() })
            .filterNotNull().joinToString(" · ")

    fun exportName(): String {
        val base = historyId.ifBlank { name }
        return base.map { c -> if (c.isLetterOrDigit()) c else '_' }.joinToString("").take(40).trimEnd('_')
    }
}

data class RecEntry(
    val id: Long,
    val patientId: Long,
    val kind: String,                        // Dosis / Cálculo / Escala / Nota
    val title: String,                       // «Propofol — Bolo de inducción»
    val subtitle: String,                    // contexto (peso/edad al calcular)
    val lines: List<Pair<String, String>>,   // etiqueta → valor, en orden
    val note: String,                        // nota libre del profesional
    val createdAt: Long
)

/** Serialización JSON manual (org.json no está disponible en pruebas JVM). */
object RecJson {

    fun esc(s: String): String = buildString {
        for (c in s) when (c) {
            '"' -> append("\\\"")
            '\\' -> append("\\\\")
            '\n' -> append("\\n")
            '\r' -> append("\\r")
            '\t' -> append("\\t")
            else -> if (c < ' ') append("\\u%04x".format(c.code)) else append(c)
        }
    }

    fun str(s: String): String = "\"" + esc(s) + "\""

    private fun unesc(s: String): String {
        val sb = StringBuilder(s.length)
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '\\' && i + 1 < s.length) {
                when (val n = s[i + 1]) {
                    '"' -> sb.append('"'); '\\' -> sb.append('\\'); '/' -> sb.append('/')
                    'n' -> sb.append('\n'); 'r' -> sb.append('\r'); 't' -> sb.append('\t')
                    'u' -> {
                        val hex = s.substring(i + 2, (i + 6).coerceAtMost(s.length))
                        val code = hex.toIntOrNull(16)
                        if (code != null) { sb.append(code.toChar()); i += 4 } else sb.append(n)
                    }
                    else -> sb.append(n)
                }
                i += 2
            } else { sb.append(c); i++ }
        }
        return sb.toString()
    }

    /** Parser minimalista de objetos JSON planos con arrays anidados de 1 nivel. */
    fun parseObject(text: String, onKV: (key: String, value: Any) -> Unit) {
        var i = 0
        fun ws() { while (i < text.length && text[i].isWhitespace()) i++ }
        fun string(): String {
            i++ // abre comilla
            val sb = StringBuilder()
            while (i < text.length && text[i] != '"') {
                if (text[i] == '\\' && i + 1 < text.length) {
                    val n = text[i + 1]
                    when (n) {
                        '"' -> sb.append('"'); '\\' -> sb.append('\\'); '/' -> sb.append('/')
                        'n' -> sb.append('\n'); 'r' -> sb.append('\r'); 't' -> sb.append('\t')
                        'u' -> {
                            val code = text.substring(i + 2, (i + 6).coerceAtMost(text.length)).toIntOrNull(16) ?: 0
                            sb.append(code.toChar()); i += 4
                        }
                        else -> sb.append(n)
                    }
                    i += 2
                } else { sb.append(text[i]); i++ }
            }
            i++ // cierra comilla
            return sb.toString()
        }
        fun value(): Any {
            ws()
            return when {
                i < text.length && text[i] == '"' -> string()
                i < text.length && text[i] == '[' -> {
                    val arr = mutableListOf<Any>()
                    i++
                    ws()
                    if (i < text.length && text[i] == ']') { i++; return arr }
                    while (i < text.length) {
                        arr.add(value())
                        ws()
                        if (i < text.length && text[i] == ',') { i++; continue }
                        if (i < text.length && text[i] == ']') { i++; break }
                    }
                    arr
                }
                else -> { // número o literal
                    val start = i
                    while (i < text.length && text[i] !in ",]} \n\r\t") i++
                    val raw = text.substring(start, i)
                    raw.toLongOrNull() ?: raw.toDoubleOrNull() ?: raw
                }
            }
        }
        // raíz: objeto
        ws()
        if (i >= text.length || text[i] != '{') return
        i++
        while (true) {
            ws()
            if (i >= text.length || text[i] == '}') break
            if (text[i] == ',') { i++; continue }
            if (text[i] != '"') break
            val key = string()
            ws()
            if (i < text.length && text[i] == ':') i++
            val v = value()
            onKV(key, v)
        }
    }

    fun serialize(patients: List<RecPatient>, entries: List<RecEntry>): String = buildString {
        append("{\"v\":1,\"patients\":[")
        patients.forEachIndexed { pi, p ->
            if (pi > 0) append(',')
            append("{\"id\":").append(p.id)
            append(",\"n\":").append(str(p.name))
            append(",\"h\":").append(str(p.historyId))
            append(",\"a\":").append(str(p.ageText))
            append(",\"w\":").append(str(p.weightText))
            append(",\"s\":").append(str(p.sex))
            append(",\"al\":").append(str(p.allergies))
            append(",\"no\":").append(str(p.notes))
            append(",\"c\":").append(p.createdAt).append('}')
        }
        append("],\"entries\":[")
        entries.forEachIndexed { ei, e ->
            if (ei > 0) append(',')
            append("{\"id\":").append(e.id)
            append(",\"p\":").append(e.patientId)
            append(",\"k\":").append(str(e.kind))
            append(",\"t\":").append(str(e.title))
            append(",\"st\":").append(str(e.subtitle))
            append(",\"ln\":[")
            e.lines.forEachIndexed { li, (k, v) ->
                if (li > 0) append(',')
                append('[').append(str(k)).append(',').append(str(v)).append(']')
            }
            append("],\"no\":").append(str(e.note))
            append(",\"c\":").append(e.createdAt).append('}')
        }
        append("]}")
    }

    fun deserialize(text: String): Pair<List<RecPatient>, List<RecEntry>> {
        val patients = mutableListOf<RecPatient>()
        val entries = mutableListOf<RecEntry>()
        parseFull(text, patients, entries)
        return patients to entries
    }

    /** Parser completo: recorre la estructura con eventos y reconstruye los modelos. */
    private fun parseFull(text: String, patients: MutableList<RecPatient>, entries: MutableList<RecEntry>) {
        var i = 0
        var section = 0
        fun ws() { while (i < text.length && text[i].isWhitespace()) i++ }
        fun string(): String {
            i++
            val sb = StringBuilder()
            while (i < text.length && text[i] != '"') {
                if (text[i] == '\\' && i + 1 < text.length) {
                    val n = text[i + 1]
                    when (n) {
                        '"' -> sb.append('"'); '\\' -> sb.append('\\'); '/' -> sb.append('/')
                        'n' -> sb.append('\n'); 'r' -> sb.append('\r'); 't' -> sb.append('\t')
                        'u' -> {
                            val code = text.substring(i + 2, (i + 6).coerceAtMost(text.length)).toIntOrNull(16) ?: 0
                            sb.append(code.toChar()); i += 4
                        }
                        else -> sb.append(n)
                    }
                    i += 2
                } else { sb.append(text[i]); i++ }
            }
            i++
            return sb.toString()
        }
        fun num(): Long {
            val start = i
            while (i < text.length && (text[i].isDigit() || text[i] == '-')) i++
            return text.substring(start, i).toLongOrNull() ?: 0L
        }
        fun expect(c: Char) { ws(); if (i < text.length && text[i] == c) i++ }

        ws()
        if (i >= text.length || text[i] != '{') return
        i++
        while (true) {
            ws()
            if (i >= text.length || text[i] == '}') break
            if (text[i] == ',') { i++; continue }
            if (text[i] != '"') break
            val key = string()
            expect(':')
            when (key) {
                "v" -> { num() }
                "patients" -> {
                    section = 1
                    expect('[')
                    while (true) {
                        ws()
                        if (i >= text.length || text[i] == ']') { i++; break }
                        if (text[i] == ',') { i++; continue }
                        if (text[i] != '{') break
                        i++
                        var id = 0L; var n = ""; var h = ""; var a = ""; var w = ""; var s = ""; var al = ""; var no = ""; var c = 0L
                        while (true) {
                            ws()
                            if (i >= text.length || text[i] == '}') { i++; break }
                            if (text[i] == ',') { i++; continue }
                            val fk = string(); expect(':')
                            when (fk) {
                                "id" -> id = num(); "n" -> n = string(); "h" -> h = string()
                                "a" -> a = string(); "w" -> w = string(); "s" -> s = string()
                                "al" -> al = string(); "no" -> no = string(); "c" -> c = num()
                                else -> if (i < text.length && text[i] == '"') string() else num()
                            }
                        }
                        patients.add(RecPatient(id, n, h, a, w, s, al, no, c))
                    }
                    section = 0
                }
                "entries" -> {
                    section = 2
                    expect('[')
                    while (true) {
                        ws()
                        if (i >= text.length || text[i] == ']') { i++; break }
                        if (text[i] == ',') { i++; continue }
                        if (text[i] != '{') break
                        i++
                        var id = 0L; var p = 0L; var k = ""; var t = ""; var st = ""
                        var ln = mutableListOf<Pair<String, String>>()
                        var no = ""; var c = 0L
                        while (true) {
                            ws()
                            if (i >= text.length || text[i] == '}') { i++; break }
                            if (text[i] == ',') { i++; continue }
                            val fk = string(); expect(':')
                            when (fk) {
                                "id" -> id = num(); "p" -> p = num(); "k" -> k = string()
                                "t" -> t = string(); "st" -> st = string()
                                "ln" -> {
                                    expect('[')
                                    while (true) {
                                        ws()
                                        if (i >= text.length || text[i] == ']') { i++; break }
                                        if (text[i] == ',') { i++; continue }
                                        if (text[i] != '[') break
                                        i++
                                        val kk = string(); expect(','); val vv = string(); expect(']')
                                        ln.add(kk to vv)
                                    }
                                }
                                "no" -> no = string(); "c" -> c = num()
                                else -> if (i < text.length && text[i] == '"') string() else num()
                            }
                        }
                        entries.add(RecEntry(id, p, k, t, st, ln, no, c))
                    }
                    section = 0
                }
                else -> if (i < text.length && text[i] == '"') string() else num()
            }
        }
    }
}

/** Formato de fecha/hora compartido por UI y exportadores. */
object RecFmt {
    private val TS = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")
    private val DAY = DateTimeFormatter.ofPattern("yyyy-MM-dd")

    fun ts(millis: Long): String =
        LocalDateTime.ofInstant(Instant.ofEpochMilli(millis), ZoneId.systemDefault()).format(TS)

    fun day(millis: Long): String =
        LocalDateTime.ofInstant(Instant.ofEpochMilli(millis), ZoneId.systemDefault()).format(DAY)

    fun now(): Long = System.currentTimeMillis()
}

/**
 * Repositorio de expedientes: un JSON en filesDir, escritura atómica
 * (tmp + rename) y estado reactivo para Compose. Sin permisos (contrato R-01).
 */
object ExpedienteRepo {
    val patients = mutableStateOf<List<RecPatient>>(emptyList())
    val entries = mutableStateOf<List<RecEntry>>(emptyList())

    private var loaded = false

    fun ensureLoaded(ctx: Context) {
        if (loaded) return
        loaded = true
        try {
            val f = File(ctx.filesDir, "expedientes.json")
            if (f.exists()) {
                val (ps, es) = RecJson.deserialize(f.readText())
                patients.value = ps
                entries.value = es
            }
        } catch (_: Throwable) {
            // Archivo corrupto: no crashear, empezar vacío y sobrescribir al guardar.
            patients.value = emptyList()
            entries.value = emptyList()
        }
    }

    fun persist(ctx: Context) {
        try {
            val f = File(ctx.filesDir, "expedientes.json")
            val tmp = File(ctx.filesDir, "expedientes.json.tmp")
            tmp.writeText(RecJson.serialize(patients.value, entries.value))
            if (!tmp.renameTo(f)) {
                f.delete()
                tmp.renameTo(f)
            }
        } catch (_: Throwable) { /* sin almacenamiento: la app sigue funcionando */ }
    }

    fun newId(): Long = RecFmt.now() * 10 + (0..9).random()

    fun addPatient(ctx: Context, p: RecPatient) {
        ensureLoaded(ctx)
        patients.value = patients.value + p
        persist(ctx)
    }

    fun updatePatient(ctx: Context, p: RecPatient) {
        ensureLoaded(ctx)
        patients.value = patients.value.map { if (it.id == p.id) p else it }
        persist(ctx)
    }

    fun deletePatient(ctx: Context, id: Long) {
        ensureLoaded(ctx)
        patients.value = patients.value.filter { it.id != id }
        entries.value = entries.value.filter { it.patientId != id }
        persist(ctx)
    }

    fun addEntry(ctx: Context, e: RecEntry) {
        ensureLoaded(ctx)
        entries.value = entries.value + e
        persist(ctx)
    }

    fun deleteEntry(ctx: Context, id: Long) {
        ensureLoaded(ctx)
        entries.value = entries.value.filter { it.id != id }
        persist(ctx)
    }

    fun entriesFor(patientId: Long): List<RecEntry> =
        entries.value.filter { it.patientId == patientId }.sortedByDescending { it.createdAt }

    fun patient(id: Long): RecPatient? = patients.value.firstOrNull { it.id == id }
}
