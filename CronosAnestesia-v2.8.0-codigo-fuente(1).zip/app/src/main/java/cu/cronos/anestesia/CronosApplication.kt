// Cronos Anestesia — Application: instala la protección contra fallos lo antes posible.
package cu.cronos.anestesia

import android.app.Application

class CronosApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashGuard.install(this)
    }
}
