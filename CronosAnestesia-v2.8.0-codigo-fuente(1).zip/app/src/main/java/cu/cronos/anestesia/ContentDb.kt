package cu.cronos.anestesia

/*
 * ============================================================================
 *  ContentStore — base de contenido CIFRADA en reposo (Room + SQLCipher).
 *  Fase 4 del plan de adecuación (contrato §6 Room+SQLCipher, §10.1
 *  contentVersion y §7 .acupkg/content_history):
 *   · Esquema de contenido versionado: content_meta + content_history.
 *   · Clave de cifrado aleatoria protegida por AndroidKeyStore (AES-GCM).
 *   · El contenido clínico sigue compilado en el APK hasta que exista el
 *     paquete .acupkg (adenda técnica); esta base registra su versión y el
 *     historial de actualizaciones, y servirá de almacén cuando el contenido
 *     pase a datos.
 *  Si el dispositivo no puede abrir la base (Keystore/SO), la app degrada
 *  con elegancia: la pantalla de Ajustes muestra que el registro no está
 *  disponible y el resto de funciones no se ve afectada.
 * ============================================================================
 */

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Upsert
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Entity(tableName = "content_meta")
data class ContentMeta(
    @PrimaryKey val key: String,
    val value: String,
    val updatedAt: Long
)

@Entity(tableName = "content_history")
data class ContentEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val contentVersion: String,
    val installedAt: Long,
    val note: String
)

@Dao
interface ContentDao {
    @Upsert
    suspend fun upsertMeta(meta: ContentMeta)

    @Query("SELECT value FROM content_meta WHERE `key` = :k LIMIT 1")
    suspend fun metaValue(k: String): String?

    @Insert
    suspend fun insertEvent(event: ContentEvent)

    @Query("SELECT COUNT(*) FROM content_history")
    suspend fun historyCount(): Int
}

@Database(
    entities = [ContentMeta::class, ContentEvent::class],
    version = 1,
    exportSchema = false
)
abstract class ContentDb : RoomDatabase() {
    abstract fun dao(): ContentDao
}

/** Estado del almacén cifrado tal como se muestra en Ajustes. */
data class ContentStatus(
    val available: Boolean,
    val encrypted: Boolean,
    val version: String?,
    val history: Int
)

object ContentStore {

    private const val DB_NAME = "cronos_content.db"
    private const val META_KEY_VERSION = "content_version"
    private const val SEC_PREFS = "cronos_db_sec"
    private const val SEC_WRAPPED = "wrapped_passphrase"
    private const val KS_ALIAS = "cronos_db_key"

    @Volatile private var db: ContentDb? = null
    @Volatile private var unavailable = false

    /** Abre (o abre y guarda) la base cifrada; null si el dispositivo no lo permite. */
    fun get(context: Context): ContentDb? {
        if (unavailable) return null
        return db ?: synchronized(this) {
            db ?: try {
                System.loadLibrary("sqlcipher")
                val factory = net.zetetic.database.sqlcipher.SupportOpenHelperFactory(
                    passphrase(context)
                )
                Room.databaseBuilder(
                    context.applicationContext,
                    ContentDb::class.java,
                    DB_NAME
                )
                    .openHelperFactory(factory)
                    .build()
                    .also { db = it }
            } catch (_: Throwable) {
                unavailable = true
                null
            }
        }
    }

    /**
     * Garantiza que la versión de contenido actual esté registrada y que cada
     * cambio de versión quede en el historial (contrato §10.1). Idempotente.
     */
    suspend fun ensureRegistered(context: Context, contentVersion: String): ContentStatus =
        withContext(Dispatchers.IO) {
            val database = get(context)
                ?: return@withContext ContentStatus(false, false, null, 0)
            try {
                val dao = database.dao()
                val prior = dao.metaValue(META_KEY_VERSION)
                if (prior == null) {
                    dao.upsertMeta(
                        ContentMeta(META_KEY_VERSION, contentVersion, System.currentTimeMillis())
                    )
                    dao.insertEvent(
                        ContentEvent(
                            contentVersion = contentVersion,
                            installedAt = System.currentTimeMillis(),
                            note = "instalación inicial"
                        )
                    )
                } else if (prior != contentVersion) {
                    dao.upsertMeta(
                        ContentMeta(META_KEY_VERSION, contentVersion, System.currentTimeMillis())
                    )
                    dao.insertEvent(
                        ContentEvent(
                            contentVersion = contentVersion,
                            installedAt = System.currentTimeMillis(),
                            note = "actualización $prior → $contentVersion"
                        )
                    )
                }
                ContentStatus(
                    available = true,
                    encrypted = true,
                    version = dao.metaValue(META_KEY_VERSION),
                    history = dao.historyCount()
                )
            } catch (_: Throwable) {
                ContentStatus(false, false, null, 0)
            }
        }

    // ---------- Clave de cifrado: aleatoria + protegida por AndroidKeyStore ----------

    private fun passphrase(context: Context): ByteArray {
        val prefs = context.getSharedPreferences(SEC_PREFS, Context.MODE_PRIVATE)
        val stored = prefs.getString(SEC_WRAPPED, null)
        if (stored != null) {
            try {
                return unwrap(base64Key(), Base64.decode(stored, Base64.NO_WRAP))
            } catch (_: Throwable) {
                // Keystore inválido (borrado de usuario, etc.): se regenera.
            }
        }
        val fresh = ByteArray(32).also { SecureRandom().nextBytes(it) }
        val wrapped = wrap(base64Key(), fresh)
        prefs.edit().putString(SEC_WRAPPED, Base64.encodeToString(wrapped, Base64.NO_WRAP)).apply()
        return fresh
    }

    private fun base64Key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getEntry(KS_ALIAS, null) as? KeyStore.SecretKeyEntry)?.let { return it.secretKey }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                KS_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }

    /** Blob = IV (12 B) + ciphertext. */
    private fun wrap(key: SecretKey, plain: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key)
        return cipher.iv + cipher.doFinal(plain)
    }

    private fun unwrap(key: SecretKey, blob: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, blob, 0, 12))
        return cipher.doFinal(blob, 12, blob.size - 12)
    }
}
