// Cronos Anestesia — Pantallas: Premedicación, Comorbilidades, Asistente y Ajustes
package cu.cronos.anestesia.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import cu.cronos.anestesia.data.APFEL_FACTORS
import cu.cronos.anestesia.data.ASPIRATION_FACTORS
import cu.cronos.anestesia.data.CHRONIC_MEDS
import cu.cronos.anestesia.data.COMORBIDITIES
import cu.cronos.anestesia.data.PREMED_PROTOCOLS
import cu.cronos.anestesia.data.SCENARIOS
import cu.cronos.anestesia.data.Sources

@Composable
fun PremedScreen(onJumpToDrug: (String) -> Unit) {
    val sp = LocalSpacing.current
    var seccion by remember { mutableStateOf(0) }
    var expandedProto by remember { mutableStateOf<String?>(null) }
    var qCronicos by remember { mutableStateOf("") }
    val secciones = listOf("Protocolos", "Riesgo de aspiración", "Apfel (PONV)", "Medicación crónica")

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(sp.s),
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(sp.xs)) {
                CronosButton("<", { seccion = (seccion - 1 + secciones.size) % secciones.size })
                Text(
                    secciones[seccion],
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f),
                )
                CronosButton(">", { seccion = (seccion + 1) % secciones.size })
            }
        }
        when (seccion) {
            0 -> {
                item {
                    Text(
                        "Protocolos de premedicación perioperatoria con dosis, horarios y vías. Toque para expandir.",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                items(PREMED_PROTOCOLS, key = { it.id }) { p ->
                    val expanded = expandedProto == p.id
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { expandedProto = if (expanded) null else p.id },
                        colors = CardDefaults.cardColors(
                            containerColor = if (expanded) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                        ),
                    ) {
                        Column(Modifier.padding(sp.m), verticalArrangement = Arrangement.spacedBy(sp.xs)) {
                            Text(p.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text(p.purpose, style = MaterialTheme.typography.bodySmall)
                            if (expanded) {
                                p.items.forEach { it2 ->
                                    Text("• ${it2.drug}: ${it2.dose}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                    Text("   ${it2.timing}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                p.notes.forEach { n -> Text("Nota: $n", style = MaterialTheme.typography.bodySmall) }
                                Text("Fuente: ${Sources.label(p.source)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
            1 -> item { AspiracionCard() }
            2 -> item { ApfelCard() }
            3 -> {
                item {
                    OutlinedTextField(
                        value = qCronicos,
                        onValueChange = { qCronicos = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("Buscar grupo de medicación crónica (p. ej. metformina)") },
                    )
                }
                val filtered = CHRONIC_MEDS.filter { m ->
                    qCronicos.isBlank() || m.group.lowercase().contains(qCronicos.lowercase()) ||
                        m.examples.lowercase().contains(qCronicos.lowercase())
                }
                items(filtered, key = { it.group }) { m ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
                    ) {
                        Column(Modifier.padding(sp.m), verticalArrangement = Arrangement.spacedBy(sp.xs)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(m.group, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Text(
                                    m.action,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = when (m.action) {
                                        "Continuar" -> MaterialTheme.colorScheme.primary
                                        "Suspender" -> MaterialTheme.colorScheme.error
                                        else -> MaterialTheme.colorScheme.secondary
                                    },
                                )
                            }
                            Text("Ejemplos: ${m.examples}", style = MaterialTheme.typography.bodySmall)
                            Text(m.detail, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AspiracionCard() {
    val sp = LocalSpacing.current
    val checks = remember { mutableStateListOf(false, false, false, false, false, false, false, false) }
    val n = checks.count { it }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(sp.xs)) {
        Text(
            "Marque los factores presentes ($n/8). Con ≥ 2: gastroprofilaxis + técnica de secuencia rápida.",
            style = MaterialTheme.typography.bodyMedium,
        )
        ASPIRATION_FACTORS.forEachIndexed { i, f ->
            RowSwitch(f, checks[i], { checks[i] = it })
        }
        val recomendacion = when {
            n == 0 -> "Sin factores marcados: ayuno estándar y técnica habitual."
            n == 1 -> "1 factor: valorar gastroprofilaxis y vigilancia de vía aérea."
            else -> "$n factores: ALTO RIESGO. Gastroprofilaxis (ranitidina/metoclopramida), preoxigenación completa, secuencia rápida con presión cricoidea y personal experto en vía aérea."
        }
        Text(recomendacion, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        SourceNote("morgan")
    }
}

@Composable
private fun ApfelCard() {
    val sp = LocalSpacing.current
    val checks = remember { mutableStateListOf(false, false, false, false) }
    val n = checks.count { it }
    val riesgo = listOf("10 %", "20 %", "40 %", "60 %", "80 %")[n]
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(sp.xs)) {
        Text("Escala de Apfel simplificada: $n/4 factores → riesgo PONV $riesgo", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
        APFEL_FACTORS.forEachIndexed { i, f ->
            RowSwitch(f, checks[i], { checks[i] = it })
        }
        val medidas = when {
            n <= 1 -> "1 medida (profilaxis básica o ninguna)"
            n == 2 -> "1–2 medidas (antiémético de una clase)"
            n == 3 -> "2–3 medidas (combinar clases: dexametasona + ondansetrón ± TIVA con propofol)"
            else -> "3–4 medidas (combinación máxima: TIVA, dexametasona, ondansetrón y evitar opioides)"
        }
        Text(medidas, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
        Text("Rescate con un antiémético de OTRA clase a la empleada en la profilaxis.", style = MaterialTheme.typography.bodySmall)
        SourceNote("morgan")
    }
}

@Composable
fun ComorbidScreen() {
    val sp = LocalSpacing.current
    var q by remember { mutableStateOf("") }
    var expandedId by remember { mutableStateOf<String?>(null) }

    val filtered = COMORBIDITIES.filter { c ->
        q.isBlank() || c.titulo.lowercase().contains(q.lowercase()) ||
            c.resumen.lowercase().contains(q.lowercase()) ||
            (c.preop + c.intraop + c.evitar + c.postop).any { it.lowercase().contains(q.lowercase()) }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(sp.s),
    ) {
        item {
            OutlinedTextField(
                value = q,
                onValueChange = { q = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Buscar comorbilidad o palabra clave (p. ej. «potasio»)") },
            )
        }
        items(filtered, key = { it.id }) { c ->
            val expanded = expandedId == c.id
            Card(
                modifier = Modifier.fillMaxWidth(),
                onClick = { expandedId = if (expanded) null else c.id },
                colors = CardDefaults.cardColors(
                    containerColor = if (expanded) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                ),
            ) {
                Column(Modifier.padding(sp.m), verticalArrangement = Arrangement.spacedBy(sp.xs)) {
                    Text(c.titulo, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(c.resumen, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (expanded) {
                        ComorbSection(c.preop, "Preoperatorio")
                        ComorbSection(c.intraop, "Transoperatorio")
                        if (c.evitar.isNotEmpty()) ComorbSection(c.evitar, "Evitar")
                        ComorbSection(c.postop, "Postoperatorio")
                        Text("Fuente: ${c.src}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        Text("Preoperatorio: ${c.preop.firstOrNull() ?: ""}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        if (filtered.isEmpty()) {
            item { Text("Sin resultados para «$q».", style = MaterialTheme.typography.bodyMedium) }
        }
    }
}

@Composable
private fun ComorbSection(items: List<String>, title: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.secondary)
        items.forEach { t ->
            Text("• $t", style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
fun AsistenteScreen(onJumpToDrug: (String) -> Unit) {
    val sp = LocalSpacing.current
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(sp.s),
    ) {
        item {
            Text(
                "Guías rápidas de urgencias transoperatorias. Toque «Ir al fármaco» para ver dosis calculadas.",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
            )
        }
        items(SCENARIOS, key = { it.id }) { s ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
            ) {
                Column(Modifier.padding(sp.m), verticalArrangement = Arrangement.spacedBy(sp.xs)) {
                    Text(s.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    s.steps.forEach { st ->
                        Text(st, style = MaterialTheme.typography.bodySmall)
                    }
                    if (s.jumpToDrug.isNotEmpty()) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            CronosButton("Ir al fármaco", { onJumpToDrug(s.jumpToDrug) })
                        }
                    }
                }
            }
        }
    }
}
