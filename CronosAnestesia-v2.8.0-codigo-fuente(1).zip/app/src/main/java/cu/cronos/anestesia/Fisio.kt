package cu.cronos.anestesia

// =====================================================================
//  FISIOLOGÍA APLICADA A LA ANESTESIA (v2.4.0 — contrato §5.2 «fisiología»)
//  Ocho temas de síntesis fisiológica orientados a la práctica
//  anestésica. Categoría nueva de la pestaña Clínica.
//  Material educativo de consulta: no sustituye tratados ni protocolos.
// =====================================================================

val FISIOLOGY = listOf(
    ClinTopic(
        "Mecánica respiratoria aplicada",
        "Compliance, resistencia y constante de tiempo en el quirófano",
        "Fisiología",
        listOf(
            "Distensibilidad (compliance)" to "Es el cambio de volumen por cambio de presión (Vt / [Pplat − PEEP]); lo normal en el adulto anestesiado ronda 50–100 mL/cmH2O. Cae con la obesidad, el neumoperitoneo, la posición de Trendelenburg, el edema, la atelectasia y la fibrosis; sube con el enfisema (tejido menos elástico pero más distensible). Una compliance < 30 mL/cmH2O con Vt protector obliga a buscar causa: posición, neumoperitoneo, neumotórax, derrame, sd. aspiración o SDRA.",
            "Resistencia de la vía aérea" to "Se estima como (Ppico − Pplat) / flujo; lo normal es < 10 cmH2O·s/L intubado. Sube con secreciones, mordida del tubo, kinking, broncoespasmo, tubo pequeño o HME obstruido. Regla práctica: si sube Ppico con Pplat estable, el problema está EN la vía o el tubo; si suben ambas, el problema es del parénquima o de la pared (compliance).",
            "Constante de tiempo (τ = R × C)" to "Cada unidad alveolar llena ~63 % del volumen en 1τ, 95 % en 3τ. Con una τ de 0,5 s hacen falta 1,5 s de espiración: si la frecuencia es alta y la relación I:E no da tiempo, aparece auto-PEEP (bloqueo de aire). Es la base de la ventilación del asmático y del EPOC: frecuencias bajas, tiempos espiratorios largos, vigilar la curva de flujo (no termina en cero).",
            "Volúmenes y capacidad funcional residual" to "La CRF (aire al final de la espiración pasiva) cae ~20 % al acostar al paciente y ~50 % bajo anestesia general, por pérdida del tono diafragmático y los músculos inspiratorios; el colapso de las vías menores produce atelectasias dependientes. La maniobra de reclutamiento + PEEP moderada + Vt de 6 mL/kg de peso predicho son la respuesta estándar; en obesidad, inclinación inversa de Trendelenburg y reclutamiento temprano.",
            "Trabajo respiratorio" to "Bajo anestesia la máquina vence la resistencia del tubo, las válvulas, el HME y el circuito: en respiración espontánea con válvulas de demanda viejas o tubos pequeños el paciente «paga» ese trabajo. Índice de respiración rápida y superficial (FR/Vt en litros) < 105 y NIF mejor de −25 cmH2O orientan a extubación; el mayor de los dos problemas en el posoperatorio obeso es la CRF baja, no la fuerza."
        ),
        calcId = "vent_mech",
        artId = "curva_pv"
    ),
    ClinTopic(
        "Intercambio gaseoso",
        "Cascada del O2, ecuación alveolar, shunt y relación V/Q",
        "Fisiología",
        listOf(
            "Cascada del oxígeno" to "El O2 baja de 159 mmHg en el aire inspirado seco a ~149 alveolar (humedecido), ~100 arterial y 23 capilar mitocondrial. Cada escalón (ventilación, difusión, relación V/Q, gasto cardíaco, Hb) es un punto de falla perioperatoria: interpretar la hipoxemia es ubicar el escalón roto. A 2500 m (Cuba: casi todo el país está por debajo de 100 m y las ciudades del interior llegan a 500–900 m): la PaO2 basal baja y el margen se estrecha.",
            "Ecuación alveolar y gradiente A-a" to "PAO2 = FiO2 × (Patm − PH2O) − PaCO2/R. El gradiente alveolo-arterial normal es ≈ (edad/4) + 4 mmHg. Gradiente normal con PaCO2 alta = hipoventilación pura (narcosis, curarización residual): basta ventilar. Gradiente ampliado = problema de O2 real: shunt, V/Q desparejo o difusión (atelectasia, neumonía, edema, émbolo).",
            "Relación ventilación/perfusión" to "El pulmón normal promedia V/Q ≈ 0,8, pero los vértices ventilan más y las bases perfunden más (gravedad). Zonas V/Q baja responden a O2 suplementario; el SHUNT (perfusión sin ventilación, como la sangre que cruza las atelectasias o el foramen oval permeable) NO responde: por eso la hipoxemia del SDRA es refractaria y la de la hipoventilación no.",
            "Efectos de la anestesia" to "Los halogenados y los opioides deprimen la respuesta hipóxica del carotídeo y el tono intercostal; el flujo sanguíneo pulmonar se redistribuye, la CRF cae y el shunt sube a 10–15 % (normal 2–5 %). La capnografía es la llave: ETCO2 alta con PaCO2 normal sugiere espacio muerto (émbolo, bajo gasto); el gradiente PaCO2-ETCO2 normal es 2–5 mmHg y sube en el shunt y en la hipovolemia.",
            "Posiciones quirúrgicas" to "Decúbito prono: mejora V/Q posterior pero comprime el abdomen (liberar, no colgar). Lateral con toracotomía: pulmón dependiente recibe más perfusión, el no dependiente más ventilación; con ventilación unipulmonar el shunt del pulmón operado define la FiO2 (y el CPAP 2–5 cmH2O o la clampada precoz del vaso). Trendelenburg: diafragma cefálico, atelectasias, edema de vía aérea al desinsuflar."
        ),
        calcId = "resp",
        artId = "alveolo_capilar"
    ),
    ClinTopic(
        "Transporte de O2 y CO2",
        "Curva de disociación, CaO2, DO2 y CO2 de la célula al bucle",
        "Fisiología",
        listOf(
            "Contenido y entrega de O2" to "Cada gramo de hemoglobina carga 1,34 mL de O2 al 100 %: CaO2 = (1,34 × Hb × SaO2) + (0,003 × PaO2). Con Hb 15 y SaO2 100 %: ~20 mL/dL; con Hb 7: ~9,5 mL/dL. La DO2 = GC × CaO2 × 10 (normal ~1000 mL/min). Tres palancas de la entrega: gasto cardíaco, Hb y saturación: por eso la anemia tolerada con gasto alto es «metabolicamente» distinta de la anemia con bajo gasto.",
            "Curva de disociación de la Hb" to "Sigmoidea: meseta protectora (SaO2 > 90 % entre PaO2 60–100) y pendiente de descarga (P50 ≈ 26–27 mmHg). Corre a la derecha (menos afinidad, entrega fácil) con acidosis, hipercapnia, hipertermia y 2,3-DPG alto (efecto Bohr); a la izquierda (retenida) con alcalosis, hipocapnia, hipotermia y Hb fetal o transfusión masiva (2,3-DPG bajo en la sangre guardada). El paciente del posoperatorio frío e hiperventilado entrega peor el O2 aunque la SaO2 sea 100 %.",
            "Transporte del CO2" to "Viaja como bicarbonato (~70 %, vía anhidrasa carbónica del eritrocito), en proteínas/Hb (~20 %, carbaminados) y disuelto (~10 %, el que mide la capnografía). El efecto Haldane: la Hb desoxigenada carga más CO2 y libera H+; en el pulmón, al oxigenarse, suelta CO2. Consecuencia práctica: retirar CO2 depende del flujo del circuito y de la ventilación alveolar; la reinspiración de CO2 (válvula, cal sodada agotada) sube el inspired CO2 aunque la VM sea correcta.",
            "Fisiología de la apnea y preoxigenación" to "El consumo de O2 es 250 mL/min (adulto) y sube >2× en sepsis, tirotoxicosis y embarazo; el reservorio (CRF + FiO2 100 % 3–5 min, u 8 VC en 60 s) da 3–8 min de seguridad, que en el obeso, el embarazo y el niño caen a <1–2 min. La preoxigenación (SpO2 98–100 % y EtO2 > 80 % con 15 L/min durante 3–5 min, u 8 respiraciones de capacidad vital en 60 s) es el «paracaídas» de toda secuencia de inducción; la insuflación nasofaríngea de O2 alarga aún más la ventana.",
            "Umbral transfusional visto desde la DO2" to "El umbral restrictivo (Hb 7 g/dL en el paciente estable) funciona porque la DO2 se mantiene subiendo el gasto y la extracción (O2ER). Falla la reserva cuando hay gasto limitado (cardiopatía), consumo alto (sepsis, temblor) o curva a la izquierda (hipotermia): ahí el mismo 7 g/dL no garantiza la entrega. La decisión de transfundir es hemodinámica, no solo hematimétrica (tema «Anemia y terapia transfusional»)."
        )
    ),
    ClinTopic(
        "Control de la ventilación",
        "Quimiorreceptores, respuesta al CO2 y fármacos que la apagan",
        "Fisiología",
        listOf(
            "Centros y quimiorreceptores" to "El bulbo (complejo pre-Bötzinger, grupo respiratorio dorsal) genera el ritmo; los quimiorreceptores centrales (superficie ventrolateral bulbar, baño en LCR) responden a H+ de la PaCO2 (respuesta lineal, 2–3 L/min por mmHg); los periféricos (carotídeo/aórtico) responden a PaO2 < 60 mmHg, pH y hipoperfusión (respuesta hipóxica es hiperbólica y débil hasta 50 mmHg).",
            "Respuesta al CO2 y apnea de la anestesia" to "El CO2 es el motor principal de la respiración; los halogenados y opioides desplazan la curva a la derecha y aplanan su pendiente: por eso el paciente anestesiado respira en grupos irregulares («cluster») y por eso la apnea posoperatoria del obeso y del recién nacido exige monitorización. En el paciente crónico con CO2 retenido, el estímulo pasa a ser hipóxico: el O2 indiscriminado en el EPOC desarma el freno (y la hipoxemia descontrolada mata más rápido: O2 titulado, no apagarlo).",
            "Respuesta hipóxica y opioides" to "La respuesta ventilatoria a la hipoxemia es la primera en perderse: dosis subanestésicas de opioides y hasta el alcohol la borran sin cambiar la SaO2 basal. Consecuencia operativa: todo paciente con opioide espinal o IV posoperatorio necesita vigilancia con pulsioximetría si es obeso, OSA, anciano o recibió benzodiazepinas (sinergia).",
            "Reflejos de la vía aérea" to "Laringoespasmo (cierre reflejo de los aductores, desencadenado por secreciones, sangre o «luz» a plano insuficiente): oxígeno a presión, CPAP, retirar el estímulo, propofol o succinilcolina si no cede. Tos y broncoespasmo reflejo: profundizar, lidocaína IV o intracuff. El reflejo del Valsalva y la maniobra de reanimación del seno carotídeo explican bradicardias de la intubación y de la tracción visceral.",
            "Peculiaridades por edad y altitud" to "El recién nacido respira «a volumen constante» (diafragma fatigable, tipo II lento) y es obligado nasal; el anciano pierde respuesta al hipóxico y al hipercápico y tiene más apneas posoperatorias. En altura (mayor parte del país < 500 m; ciudades interiores hasta 800–900 m): la FiO2 efectiva baja ~1 % cada 100 m — el «0,21» de la tabla es a nivel del mar, y la MAC no cambia pero la reserva sí."
        )
    ),
    ClinTopic(
        "Circulación y retorno venoso",
        "Starling, Fick, reservas y por qué cae la presión al anestesiar",
        "Fisiología",
        listOf(
            "Curva de Starling y tono simpático" to "El gasto depende de la precarga (volumen + tono venoso), la contractilidad y la poscarga. La anestesia general desactiva el tono simpático venoso: la piscina venosa abre, el retorno cae y la presión baja SIN que cambie la volemia. Por eso la hipotensión de la inducción se corrige con volumen moderado + vasopresor + tiempo, no con «hidratación a ciegas»: el tanque no estaba vacío, estaba dilatado.",
            "Determinantes de la presión arterial" to "PA = GC × RVP. La hipotensión perioperatoria se descompone en: volumen (sangrado, tercer espacio, ayuno), tono (anestésicos, anafilaxia, bloqueo neuraxial, sepsis), bomba (isquemia, arritmia, valsava, taponamiento) y ritmos. El diagnóstico intraoperatorio va del monitor al mecanismo: PA baja + ETCO2 baja + FC alta = volumen o tono; PA baja + ETCO2 alta súbita = embolia o liberación de CO2; PA baja + pulsos picudos = anafilaxia.",
            "Reservas cardíacas y Fick" to "GC = FC × VS (4–8 L/min); el principio de Fick (VO2 = GC × dif. arteriovenosa de O2) une consumo y entrega. La reserva de frecuencia es lo primero que gastan los betabloqueados y los ancianos: su hipotensión por bloqueo neuraxial es más profunda y responde mejor a fenilefrina/efedrina temprana que a volumen. La reserva de Frank-Starling se agota en el ventrículo rígido (hipertrofia, isquemia): «precarga dependiente».",
            "Autoregulación de órganos" to "Cerebro (60–150 mmHg de PAM), corazón y riñón mantienen flujo con presión cambiante; la autoregulación se desplaza a la derecha en el hipertenso crónico y a la izquierda en la sepsis. Objetivo operativo: PAM ≥ 65 mmHg (≥ 75–80 en el hipertenso crónico con daño de órgano y en la estenosis carotídea sintomática); el cerebro tolera peor la hipotensión con hipocapnia agresiva (vasoconstricción sumada).",
            "Retorno venoso y maniobras" to "El retorno depende del gradiente presión media sistémica − presión auricular derecha: el Valsalva, el neumoperitoneo, la PEEP y la compresión aortocaval (embarazada > 20 semanas) lo estrangulan; la inclinación lateral izquierda y el descenso del neumoperitoneo lo liberan. El «posicionamiento» es una intervención hemodinámica: cada cambio de mesa se anuncia y se corrige antes de que el monitor lo grite."
        )
    ),
    ClinTopic(
        "Balance hídrico y electrolitos",
        "Compartimentos, tonicidad y los iones que descompensan el quirófano",
        "Fisiología",
        listOf(
            "Compartimentos y tonicity" to "El agua corporal (60 % del peso; 50 % en la mujer y el anciano) se reparte 2/3 intracelular y 1/3 extracelular (¼ plasmático). Lo que mueve agua entre compartimentos es la TONICIDAD (Na efectivo + glucosa): el cristaloide isotónico queda ~25 % intravascular; el salino hipotónico o el SG5 % inundan la célula; el coloide queda en el vaso mientras la albúmina y el endotelio lo permitan (capillary leak lo devuelve al intersticio).",
            "Hiponatremia perioperatoria" to "La más frecuente y la más peligrosa: irrigaciones hipotónicas (RTU), SG5 % de «mantenimiento», y el síndrome de absorción del TURP (glicina) — síntomas: náusea, confusión, convulsión. El riesgo iatrogénico clásico es la niña prepuberal con SG5 % de mantenimiento (hiponatremia): la solución de mantenimiento del niño es salino equilibrado + glucosa según pauta, nunca SG5 % «libre». Corrección crónica: ≤ 8–10 mmol/L/24 h (riesgo de mielinolisis osmótica).",
            "Potasio, magnesio y calcio" to "K: 0,5 mmol/L cae por cada 100 mEq deficitarios; hiperkalemia (> 5,5): evitar succinilcolina, corregir con calcio (estabiliza), insulina-glucosa y bicarbonato (mueve), resinas/diálisis (saca). Mg: hipomagnesemia = arritmias, tetania, broncoespasmo refractario, prolongación de bloqueos; el alcohólico y el diabético descompensado casi siempre la traen. Ca ionizado: manda en coagulación, contractilidad y curarización — chequearlo en transfusión masiva y CEC (citrato).",
            "Pérdidas perioperatorias" to "Ayuno: ~1 mL/kg/h de insensible + orina. Peritoneo e irradiación quirúrgica: evaporation 0,5–1 mL/kg/h en laparotomía abierta. Tercer espacio: ya no se «reposa» por fórmula (overtreatment): reponer lo que se ve (sangrado, orina, pérdida explícita) y guiarse por dinámica (variación de presión del pulso, SVV/PPV, ecografía punt of care) y lactato. El objetivo es la euvolemia, no la «precarga máxima».",
            "Cristaloides balanceados vs. salino 0,9 %" to "El SF 0,9 % (154 mEq/L de Cl−) en grandes volúmenes causa acidosis hiperclorémica y vasoconstricción renal (trials SALT, SMART): preferir Ringer lactato o salino balanceado como base; SF 0,9 % queda para la hiponatremia sintomática, la hipoclorémia de vómito y como vehículo. El lactato del Ringer es metabolizado en el hígado (no «empeora el lactato del shock»: esa es la señal de la hipoperfusión, no del líquido). Coloides sintéticos (HES): riesgo renal y de coagulopatía: restringidos a indicaciones puntuales con protocolo."
        ),
        calcId = "anh"
    ),
    ClinTopic(
        "Regulación de la temperatura",
        "El paciente anestesiado es poiquilotérmico: prevención y consecuencias",
        "Fisiología",
        listOf(
            "Termorregulación bajo anestesia" to "El hipotálamo defiende 36,5–37,5 °C con conductas (buscar calor: reaparecen al despertar) y respuestas autónomas: vasoconstricción (umbral ~36 °C) y temblor (~35,5 °C). La anestesia general y neuraxial estrechan y desplazan los umbrales: el paciente anestesiado no tiembla ni vasoconstruye eficazmente, pierde calor por radiación y convección y se vuelve poiquilotérmico: su temperatura ES la del quirófano.",
            "Las tres caídas" to "1) Redistribución (1ª hora): el calor pasa del centro a la periferia por la vasodilatación — cae 1–1,5 °C aunque el balance sea cero; prevenir con precalentamiento (20–30 min de manta en la sala de espera). 2) Pérdida neta (2ª–3ª h): radiación/convección + líquidos fríos + cavidades abiertas. 3) Meseta: la vasoconstricción tardía «cierra» la periferia. La redistribución no se combate con calor intraoperatorio tardío: se previene antes de la inducción.",
            "Consecuencias de la hipotermia" to "Triplica la morbilidad por isquemia miocárdica, duplica la infección de la herida (vasoconstricción + inmunidad), prolonga la coagulación y la acción de los relajantes, multiplica el temblor (↑ VO2 300–500 %), y ensancha la curva del O2 a la izquierda (entrega peor). El paciente frío sale más tarde del quirófano y del hospital: el calentamiento es intervención de seguridad, no confort.",
            "Manejo práctico" to "Medir (esofágica en intubado; axilar/timpano como mínimo), precalentar cuando haya tiempo, manta de aire caliente (la más eficaz), líquidos y sangre calentados en transfusiones > 1 L, humedecer gases en circuitos largos, limitar la exposición y la lavado de frío. Objetivo intraoperatorio ≥ 36 °C; extubar y trasladar con el paciente > 36 °C y sin temblor (el temblor multiplica el consumo de O2 y estresa el corazón isquémico).",
            "Hipertermia: diagnóstico diferencial" to "Fiebre (sepsis, transfusión, fármacos) ≠ hipertermia pasiva ≠ CRISIS HIPERTÉRMICA MALIGNA (rápida, con hipercapnia precoz, acidosis, rigidez, mioglobinuria: dantroleno 2,5 mg/kg ya, suspender halogenados y succinilcolina, plan de emergencia). Otras: tirotoxicosis, crisis pheo, síndrome neuroléptico maligno, calor quirúrgico (colchón térmico en contacto directo), bolas de cal sodada agotada (exotermia). Si la temperatura sube sin explicación, tocar la máquina y pensar en MH antes de etiquetar fiebre."
        )
    ),
    ClinTopic(
        "Dolor: bases fisiológicas",
        "Del nociceptor a la modulación: por qué la analgesia multimodal funciona",
        "Fisiología",
        listOf(
            "Transducción y transmisión" to "Los nociceptores (terminales libres Aδ y C) traducen estímulo real o potencial de daño: las fibras Aδ (mielínicas, agudo-bien localizado, «retirar la mano») y las C (amielínicas, lento-sordo, ardor). El estímulo viaja por las raíces dorsales al asta posterior (láminas I–V), cruza y sube por el haz espinotalámico lateral al tálamo y la corteza. Cada sinapsis es una diana farmacológica: periférica (AINEs, anestésicos local), axonal, sináptica (opioides presinápticos), segmentaria y suprasegmentaria.",
            "Puerta del asta posterior" to "La teoría de la puerta (Melzack-Wall, hoy con base molecular): las fibras gruesas Aβ (tacto) inhiben la transmisión nociceptiva; los descendentes (PAG-RVM, noradrenalina y 5-HT) también. De ahí salen prácticas reales: estimulación eléctrica transcutánea, masaje, calor, y la acción espinal de los α2 (dexmedetomidina/clonidina) y de la analgesia epidural: cerrar la puerta «desde dentro».",
            "Sensibilización periférica y central" to "La inflamación local (prostaglandinas, bradiquinina, NGF, H+) baja el umbral del nociceptor (hiperalgesia primaria) y la activación repetida «rebota» hacia arriba: el asta posterior facilita (wind-up vía NMDA), aparece la hiperalgesia secundaria del área circundante. La analgesia preventiva tiene base mecanística: bloquear el estímulo antes de que entre (bloqueo regional + ketamina + paracetamol/AINES prequirúrgicos) evita «enseñar» el dolor al sistema.",
            "Por qué multimodal" to "Un solo fármaco no cubre los cuatro nodos: periferia (AINEs/paracetamol, anestésico local), transmisión (bloqueo regional), modulación espinal (ketamina NMDA, α2) y suprasegmental (opioides a dosis mínima). La multimodal reduce el consumo de opioides y sus efectos (náusea, ileo, depresión respiratoria, cronificación) — el opioide pasa a ser el complemento titulado, no la base. El dolor no tratado también duele después: la cirugía «aprende» el sistema y cronifica (mastectomía, hernia, toracotomía).",
            "Dolor en el que no puede hablar" to "El paciente anestesiado, el recién nacido y el paciente crítico sienten y responden (taquicardia, hipertensión, lágrimas, ventilación desacoplada del ventilador): la analgesia se titula por signos, no por quejas; en UCI, CPOT/COMFORT; en el niño, escalas conductuales. La palabra «no me dijo que dolía» no es defensa: la ausencia de queja no es ausencia de dolor."
        )
    )
)
