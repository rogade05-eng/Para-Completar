// Cronos Anestesia — Motor de temas: claro/oscuro, paletas, color personalizado por modo,
// escala de letra, densidad y estilo de botones. Persistencia con DataStore.
package cu.cronos.anestesia.ui

import android.content.Context
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "cronos_theme")

@Immutable
data class ThemeConfig(
    val mode: String = "sistema",   // claro | oscuro | sistema
    val palette: String = "teal",   // teal | azul | indigo | verde
    val bgClaro: String = "",       // hex personalizado del fondo claro
    val bgOscuro: String = "",      // hex personalizado del fondo oscuro
    val fontScale: Float = 1.0f,    // 0.85–1.30
    val density: String = "normal", // compacta | normal | amplia
    val buttonStyle: String = "solido", // solido | contorno | suave
)

object ThemeStore {
    private val K_MODE = stringPreferencesKey("mode")
    private val K_PALETTE = stringPreferencesKey("palette")
    private val K_BG_CLARO = stringPreferencesKey("bg_claro")
    private val K_BG_OSCURO = stringPreferencesKey("bg_oscuro")
    private val K_FONT = floatPreferencesKey("font_scale")
    private val K_DENSITY = stringPreferencesKey("density")
    private val K_BUTTON = stringPreferencesKey("button_style")

    fun flow(context: Context): Flow<ThemeConfig> = context.dataStore.data
        // Si las preferencias están dañadas (p. ej., el sistema mató la app al guardar),
        // se reinician a los valores por defecto en lugar de fallar en cada apertura.
        .catch { emit(emptyPreferences()) }
        .map { p ->
            ThemeConfig(
                mode = p[K_MODE] ?: "sistema",
                palette = p[K_PALETTE] ?: "teal",
                bgClaro = p[K_BG_CLARO] ?: "",
                bgOscuro = p[K_BG_OSCURO] ?: "",
                fontScale = (p[K_FONT] ?: 1.0f).coerceIn(0.5f, 2.0f),
                density = p[K_DENSITY] ?: "normal",
                buttonStyle = p[K_BUTTON] ?: "solido",
            )
        }

    suspend fun save(context: Context, c: ThemeConfig) {
        context.dataStore.edit { p ->
            p[K_MODE] = c.mode
            p[K_PALETTE] = c.palette
            p[K_BG_CLARO] = c.bgClaro
            p[K_BG_OSCURO] = c.bgOscuro
            p[K_FONT] = c.fontScale
            p[K_DENSITY] = c.density
            p[K_BUTTON] = c.buttonStyle
        }
    }
}

// ---------- Paletas (claras y oscuras) ----------
data class PalettePair(val name: String, val label: String, val light: ColorScheme, val dark: ColorScheme)

private fun tealLight() = lightColorScheme(
    primary = Color(0xFF00695C), onPrimary = Color.White,
    primaryContainer = Color(0xFFB2DFDB), onPrimaryContainer = Color(0xFF00201C),
    secondary = Color(0xFF4A635F), onSecondary = Color.White,
    background = Color(0xFFF6FBF8), onBackground = Color(0xFF171D1B),
    surface = Color(0xFFF6FBF8), onSurface = Color(0xFF171D1B),
    surfaceVariant = Color(0xFFDBE5E1), onSurfaceVariant = Color(0xFF3F4946),
    outline = Color(0xFF6F7976),
)

private fun tealDark() = darkColorScheme(
    primary = Color(0xFF53DBBF), onPrimary = Color(0xFF00382F),
    primaryContainer = Color(0xFF005046), onPrimaryContainer = Color(0xFF74F8DB),
    secondary = Color(0xFFB1CCC6), onSecondary = Color(0xFF1C3531),
    background = Color(0xFF0F1513), onBackground = Color(0xFFDEE4E1),
    surface = Color(0xFF0F1513), onSurface = Color(0xFFDEE4E1),
    surfaceVariant = Color(0xFF3F4946), onSurfaceVariant = Color(0xFFBEC9C5),
    outline = Color(0xFF89938F),
)

private fun azulLight() = lightColorScheme(
    primary = Color(0xFF1565C0), onPrimary = Color.White,
    primaryContainer = Color(0xFFBBDEFB), onPrimaryContainer = Color(0xFF001A40),
    secondary = Color(0xFF546E7A), onSecondary = Color.White,
    background = Color(0xFFF7FAFD), onBackground = Color(0xFF181C1F),
    surface = Color(0xFFF7FAFD), onSurface = Color(0xFF181C1F),
    surfaceVariant = Color(0xFFDDE3EA), onSurfaceVariant = Color(0xFF41484D),
    outline = Color(0xFF71787D),
)

private fun azulDark() = darkColorScheme(
    primary = Color(0xFF9ACBFF), onPrimary = Color(0xFF00315F),
    primaryContainer = Color(0xFF0D4A8F), onPrimaryContainer = Color(0xFFC9E2FF),
    secondary = Color(0xFFB9C8D0), onSecondary = Color(0xFF243239),
    background = Color(0xFF101418), onBackground = Color(0xFFDFE3E7),
    surface = Color(0xFF101418), onSurface = Color(0xFFDFE3E7),
    surfaceVariant = Color(0xFF41484D), onSurfaceVariant = Color(0xFFC1C7CD),
    outline = Color(0xFF8B9197),
)

private fun indigoLight() = lightColorScheme(
    primary = Color(0xFF3949AB), onPrimary = Color.White,
    primaryContainer = Color(0xFFC5CAE9), onPrimaryContainer = Color(0xFF000F5C),
    secondary = Color(0xFF5C6470), onSecondary = Color.White,
    background = Color(0xFFF8F8FC), onBackground = Color(0xFF1A1B21),
    surface = Color(0xFFF8F8FC), onSurface = Color(0xFF1A1B21),
    surfaceVariant = Color(0xFFE2E1EC), onSurfaceVariant = Color(0xFF45464F),
    outline = Color(0xFF767680),
)

private fun indigoDark() = darkColorScheme(
    primary = Color(0xFFBAC3FF), onPrimary = Color(0xFF081878),
    primaryContainer = Color(0xFF283593), onPrimaryContainer = Color(0xFFDEE0FF),
    secondary = Color(0xFFC4C5D0), onSecondary = Color(0xFF2D2F39),
    background = Color(0xFF121218), onBackground = Color(0xFFE4E1E9),
    surface = Color(0xFF121218), onSurface = Color(0xFFE4E1E9),
    surfaceVariant = Color(0xFF45464F), onSurfaceVariant = Color(0xFFC6C5D0),
    outline = Color(0xFF90909A),
)

private fun verdeLight() = lightColorScheme(
    primary = Color(0xFF2E7D32), onPrimary = Color.White,
    primaryContainer = Color(0xFFC8E6C9), onPrimaryContainer = Color(0xFF00210A),
    secondary = Color(0xFF52634F), onSecondary = Color.White,
    background = Color(0xFFF7FBF3), onBackground = Color(0xFF181D18),
    surface = Color(0xFFF7FBF3), onSurface = Color(0xFF181D18),
    surfaceVariant = Color(0xFFDEE5D8), onSurfaceVariant = Color(0xFF424940),
    outline = Color(0xFF72796F),
)

private fun verdeDark() = darkColorScheme(
    primary = Color(0xFF81C784), onPrimary = Color(0xFF00390E),
    primaryContainer = Color(0xFF1B5E20), onPrimaryContainer = Color(0xFF9CD69E),
    secondary = Color(0xFFB8CCB4), onSecondary = Color(0xFF243424),
    background = Color(0xFF111511), onBackground = Color(0xFFDFE4DC),
    surface = Color(0xFF111511), onSurface = Color(0xFFDFE4DC),
    surfaceVariant = Color(0xFF424940), onSurfaceVariant = Color(0xFFC2C9BD),
    outline = Color(0xFF8C9389),
)

val PALETTES: List<PalettePair> = listOf(
    PalettePair("teal", "Teal (por defecto)", tealLight(), tealDark()),
    PalettePair("azul", "Azul clínico", azulLight(), azulDark()),
    PalettePair("indigo", "Índigo", indigoLight(), indigoDark()),
    PalettePair("verde", "Verde", verdeLight(), verdeDark()),
)

fun paletteFor(id: String): PalettePair = PALETTES.firstOrNull { it.name == id } ?: PALETTES[0]

fun parseHex(s: String): Color? = try {
    if (s.length in 6..9) {
        val hex = if (s.startsWith("#")) s.drop(1) else s
        if (hex.length == 6) Color(android.graphics.Color.parseColor("#$hex")) else null
    } else null
} catch (_: Exception) {
    null
}

// ---------- Escala de espaciado (densidad de la interfaz) ----------
@Immutable
data class Spacing(val xs: Dp, val s: Dp, val m: Dp, val l: Dp)

val LocalSpacing = staticCompositionLocalOf { Spacing(4.dp, 8.dp, 12.dp, 16.dp) }

private fun spacingFor(density: String): Spacing = when (density) {
    "compacta" -> Spacing(3.dp, 6.dp, 9.dp, 12.dp)
    "amplia" -> Spacing(6.dp, 11.dp, 17.dp, 23.dp)
    else -> Spacing(4.dp, 8.dp, 12.dp, 16.dp)
}

@Composable
fun CronosTheme(
    config: ThemeConfig,
    content: @Composable () -> Unit,
) {
    val systemDark = isSystemInDarkTheme()
    val dark = when (config.mode) {
        "claro" -> false
        "oscuro" -> true
        else -> systemDark
    }
    val base = paletteFor(config.palette).let { if (dark) it.dark else it.light }

    val customBg = if (dark) parseHex(config.bgOscuro) else parseHex(config.bgClaro)
    val scheme: ColorScheme = if (customBg != null) base.copy(background = customBg, surface = customBg) else base

    val density = LocalDensity.current
    CompositionLocalProvider(
        LocalSpacing provides spacingFor(config.density),
        LocalDensity provides Density(density.density, (density.fontScale * config.fontScale).coerceIn(0.5f, 3.0f)),
        LocalButtonStyle provides config.buttonStyle,
    ) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

val LocalButtonStyle = staticCompositionLocalOf { "solido" }

@Composable
fun cronosButtonColors(): ButtonColorsSpec {
    val style = LocalButtonStyle.current
    val c = MaterialTheme.colorScheme
    return when (style) {
        "contorno" -> ButtonColorsSpec(
            container = Color.Transparent,
            content = c.primary,
            border = androidx.compose.foundation.BorderStroke(1.dp, c.primary),
        )
        "suave" -> ButtonColorsSpec(container = c.primaryContainer, content = c.onPrimaryContainer, border = null)
        else -> ButtonColorsSpec(container = c.primary, content = c.onPrimary, border = null)
    }
}

@Immutable
data class ButtonColorsSpec(
    val container: Color,
    val content: Color,
    val border: androidx.compose.foundation.BorderStroke?,
)
