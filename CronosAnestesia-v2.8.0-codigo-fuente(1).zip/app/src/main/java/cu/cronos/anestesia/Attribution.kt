package cu.cronos.anestesia

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

// =====================================================================
//  ATRIBUCIÓN DE CÁLCULOS Y ESTUDIOS A UN PACIENTE (v2.5.0)
//  ----------------------------------------------------------------------------
//  Hasta v2.4 el botón «Guardar en expediente» enviaba el registro al
//  paciente ACTIVO sin preguntar. Con este módulo, cada calculadora,
//  escala, checklist o consentimiento ofrece además el botón
//  «Atribuir a paciente…» que abre un selector y fija el destinatario
//  exacto del registro (o crea un paciente nuevo al instante).
//  Todo es local (SharedPreferences + JSON): sin red (contrato R-01).
// =====================================================================

/**
 * Fila de dos botones de ancho idéntico:
 *  · «Guardar en expediente» → guarda en el paciente activo y avisa con el nombre.
 *  · «Atribuir a paciente…»  → abre el selector de paciente y guarda allí.
 */
@Composable
fun AttributionButtons(tag: String, text: String) {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    var showPicker by remember { mutableStateOf(false) }

    Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
        AppButton(
            stringResource(R.string.exp_save_calc),
            secondary = true,
            modifier = Modifier.weight(1f),
            onClick = {
                val savedTo = Expediente.saveCalc(ctx, tag, text)
                Toast.makeText(
                    ctx,
                    ctx.getString(
                        R.string.exp_saved_to,
                        savedTo.ifBlank { ctx.getString(R.string.exp_unnamed) }
                    ),
                    Toast.LENGTH_SHORT
                ).show()
            }
        )
        AppButton(
            stringResource(R.string.exp_attribute),
            modifier = Modifier.weight(1f),
            onClick = { showPicker = true }
        )
    }

    if (showPicker) {
        PatientPickerDialog(
            tag = tag,
            text = text,
            onDismiss = { showPicker = false }
        )
    }
}

/**
 * Botón único (secundario) que abre el selector de paciente, para pantallas
 * que ya tienen su propia fila de acciones (checklist, escalas…).
 */
@Composable
fun AttributeToPatientButton(tag: String, text: String, modifier: Modifier = Modifier) {
    var showPicker by remember { mutableStateOf(false) }
    AppButton(
        stringResource(R.string.exp_attribute),
        secondary = true,
        modifier = modifier,
        onClick = { showPicker = true }
    )
    if (showPicker) {
        PatientPickerDialog(tag = tag, text = text, onDismiss = { showPicker = false })
    }
}

/**
 * Selector de paciente: lista con búsqueda, «paciente nuevo» y aviso si no hay
 * ninguno. Al elegir, guarda el registro en ese paciente y lo deja activo.
 */
@Composable
fun PatientPickerDialog(tag: String, text: String, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    val patients = remember { Expediente.patients(ctx) }
    val q = query.trim().lowercase()
    val filtered = patients.filter {
        q.isBlank() || it.name.lowercase().contains(q) || it.ci.lowercase().contains(q)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.exp_pick_title)) },
        text = {
            Column {
                if (patients.isEmpty()) {
                    Text(
                        stringResource(R.string.exp_pick_empty),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = { Text(stringResource(R.string.exp_pick_search)) },
                        shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(modifier = Modifier.heightIn(max = 320.dp)) {
                        items(filtered.size) { i ->
                            val p = filtered[i]
                            TextButton(
                                onClick = {
                                    Expediente.saveEntryTo(ctx, p.id, tag, text)
                                    Toast.makeText(
                                        ctx,
                                        ctx.getString(
                                            R.string.exp_saved_to,
                                            p.name.ifBlank { ctx.getString(R.string.exp_unnamed) }
                                        ),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                    onDismiss()
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column {
                                    Text(
                                        p.name.ifBlank { ctx.getString(R.string.exp_unnamed) },
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    val meta = listOf(p.ci, p.age, p.sex)
                                        .filter { it.isNotBlank() }.joinToString(" · ")
                                    if (meta.isNotBlank()) {
                                        Text(
                                            meta,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                Expediente.saveCalc(ctx, tag, text) // sin activo → crea paciente nuevo
                Toast.makeText(
                    ctx,
                    ctx.getString(R.string.exp_pick_new_done),
                    Toast.LENGTH_SHORT
                ).show()
                onDismiss()
            }) { Text(stringResource(R.string.exp_pick_new)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) }
        }
    )
}
