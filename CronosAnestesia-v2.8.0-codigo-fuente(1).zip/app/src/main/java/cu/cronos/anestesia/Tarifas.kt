package cu.cronos.anestesia

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/*
 * ============================================================================
 *  TARIFAS Y FORMAS DE PAGO (v1.6.0)
 *  ----------------------------------------------------------------------------
 *  Diálogo comercial completo, visible desde Ajustes → Licencia, desde las
 *  secciones bloqueadas y desde Inicio. Reglas del negocio que refleja:
 *    · El cliente elige plan (Básica / Profesional / Institucional) y
 *      duración (Mensual / Trimestral / Anual / Perpetua) según su necesidad.
 *    · PAGA PRIMERO: Transfermóvil en CUP (importe = USD × tasa del día según
 *      elTOQUE), efectivo a conveniar o vía internacional negociada.
 *    · Luego confirma por WhatsApp con su TELÉFONO —la referencia que
 *      identifica quién hizo la transferencia— y recibe su clave.
 *    · Precios negociables; los internacionales se acuerdan por WhatsApp.
 *  Sin permiso INTERNET: solo intents implícitos (contrato R-01 intacto).
 * ============================================================================
 */

@Composable
private fun planNote(plan: Tariffs.Plan): String = when (plan.key) {
    "BAS" -> stringResource(R.string.tarifas_plan_bas_note)
    "INST" -> stringResource(R.string.tarifas_plan_inst_note)
    else -> stringResource(R.string.tarifas_plan_pro_note)
}

/** Diálogo a pantalla (casi) completa con tarifas, pasos de pago y contacto. */
@Composable
fun TarifasDialog(onDismiss: () -> Unit) {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    val devHash = remember { deviceHash(ctx) }
    val deviceFormatted = if (devHash.isBlank()) "—" else formatDeviceHash(devHash)
    val version = remember { LicenseContact.appVersion(ctx) }

    var duration by rememberSaveable { mutableStateOf(0) }
    var tierIdx by rememberSaveable { mutableStateOf(1) }
    var rateText by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }
    var paidUsd by rememberSaveable { mutableStateOf(false) }
    var showRequest by rememberSaveable { mutableStateOf(false) }
    var copiedAccountCup by rememberSaveable { mutableStateOf(false) }
    var copiedAccountUsd by rememberSaveable { mutableStateOf(false) }
    var copiedPay by rememberSaveable { mutableStateOf(false) }
    var payFallback by rememberSaveable { mutableStateOf(false) }

    val plan = Tariffs.PLANS[tierIdx]
    val price = Tariffs.priceUsd(plan, duration)
    val rate = Tariffs.parseRate(rateText)
    val cup = rate?.let { Tariffs.cupFor(price, it) }
    val phoneOk = Tariffs.isValidPaymentPhone(phone)
    val perMonth = Tariffs.perMonth(plan, duration)
    val savings = Tariffs.savingsPercent(plan, duration)

    val payMessage = remember(plan, duration, price, phone, cup, paidUsd, version, deviceFormatted) {
        Tariffs.buildPaymentMessage(
            versionName = version,
            deviceFormatted = deviceFormatted,
            planLabel = Tariffs.planLabel(plan, duration),
            priceUsd = price,
            phone = phone.trim().ifBlank { "(no indicado)" },
            cupText = if (paidUsd) "" else cup?.let {
                Tariffs.formatCup(it) + " CUP (tasa elTOQUE " +
                    rateText.trim().replace(',', '.') + ")"
            } ?: "",
            paidCurrency = if (paidUsd) "USD" else "CUP"
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(sp.m.dp),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                Modifier
                    .fillMaxHeight(0.92f)
                    .padding(sp.l.dp),
                verticalArrangement = Arrangement.spacedBy(sp.s.dp)
            ) {
                // ---- Encabezado ----
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        stringResource(R.string.tarifas_title),
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(48.dp)) {
                        Icon(
                            Icons.Filled.Close,
                            contentDescription = stringResource(R.string.tarifas_close),
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }

                // ---- Contenido desplazable ----
                Column(
                    Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(sp.s.dp)
                ) {
                    Text(
                        stringResource(R.string.tarifas_intro),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    // ---- Duración ----
                    Text(
                        stringResource(R.string.tarifas_duration),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Tariffs.DURATIONS.forEachIndexed { i, d ->
                            FilterChip(
                                selected = duration == i,
                                onClick = { duration = i },
                                label = { Text(d) }
                            )
                        }
                    }

                    // ---- Tarjetas de nivel ----
                    Tariffs.PLANS.forEachIndexed { i, p ->
                        val selected = i == tierIdx
                        val pPerMonth = Tariffs.perMonth(p, duration)
                        val pSavings = Tariffs.savingsPercent(p, duration)
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { tierIdx = i },
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (selected)
                                    MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.surface,
                                contentColor = if (selected)
                                    MaterialTheme.colorScheme.onPrimaryContainer
                                else MaterialTheme.colorScheme.onSurface
                            )
                        ) {
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(sp.m.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        p.display,
                                        style = MaterialTheme.typography.titleMedium,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            if (duration == 0)
                                                stringResource(R.string.tarifas_price_month, p.monthly)
                                            else
                                                stringResource(R.string.tarifas_price_usd, Tariffs.priceUsd(p, duration)),
                                            style = MaterialTheme.typography.titleMedium,
                                            color = if (selected)
                                                MaterialTheme.colorScheme.onPrimaryContainer
                                            else MaterialTheme.colorScheme.primary
                                        )
                                        if (duration == Tariffs.PERPETUAL_INDEX) {
                                            Text(
                                                stringResource(R.string.tarifas_perpetual_badge),
                                                style = MaterialTheme.typography.labelSmall
                                            )
                                        }
                                    }
                                }
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    planNote(p),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (selected && pPerMonth != null && pSavings != null) {
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        stringResource(
                                            R.string.tarifas_monthly_equiv,
                                            Tariffs.formatUsd2(pPerMonth),
                                            pSavings
                                        ),
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }

                    // ---- Resumen del plan elegido ----
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Text(
                            stringResource(
                                R.string.tarifas_selected_plan,
                                plan.display,
                                Tariffs.DURATIONS[duration],
                                "USD $price"
                            ),
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(sp.m.dp)
                        )
                    }

                    // ---- Pago en Cuba: CUP o USD, siempre primero ----
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .padding(sp.m.dp),
                            verticalArrangement = Arrangement.spacedBy(sp.s.dp)
                        ) {
                            Text(
                                stringResource(R.string.tarifas_pay_cup_title),
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                stringResource(R.string.tarifas_pay_first),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            // Opción A — CUP (Transfermóvil), importe según elTOQUE
                            Text(
                                stringResource(R.string.tarifas_pay_cup_opt),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                stringResource(R.string.tarifas_pay_step1),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            OutlinedTextField(
                                value = rateText,
                                onValueChange = { rateText = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                label = { Text(stringResource(R.string.tarifas_rate_label)) },
                                placeholder = { Text(stringResource(R.string.tarifas_rate_hint)) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                shape = RoundedCornerShape(12.dp)
                            )
                            when {
                                rate != null && cup != null -> Text(
                                    stringResource(R.string.tarifas_cup_result, Tariffs.formatCup(cup)),
                                    style = MaterialTheme.typography.titleSmall.copy(fontFamily = FontFamily.Monospace),
                                    color = MaterialTheme.colorScheme.primary
                                )
                                rateText.isNotBlank() -> Text(
                                    stringResource(R.string.tarifas_rate_invalid),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            ) {
                                Text(
                                    stringResource(R.string.tarifas_eltoque_note),
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(sp.s.dp)
                                )
                            }
                            Text(
                                Tariffs.TRANSFERMOVIL_ACCOUNT_DISPLAY,
                                style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Monospace),
                                color = MaterialTheme.colorScheme.primary
                            )
                            AppButton(
                                text = stringResource(R.string.tarifas_account_copy) + " (CUP)",
                                secondary = true,
                                modifier = Modifier.fillMaxWidth(),
                                onClick = {
                                    copiedAccountCup = LicenseContact.copyText(
                                        ctx,
                                        "Cronos Anestesia — cuenta CUP (Transfermóvil)",
                                        Tariffs.TRANSFERMOVIL_ACCOUNT
                                    )
                                }
                            )
                            if (copiedAccountCup) {
                                Text(
                                    stringResource(R.string.tarifas_account_copied),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            // Opción B — USD (Tarjeta Clásica), precio exacto sin conversión
                            Text(
                                stringResource(R.string.tarifas_pay_usd_opt),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                stringResource(R.string.tarifas_pay_usd_body),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                Tariffs.USD_ACCOUNT_DISPLAY,
                                style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Monospace),
                                color = MaterialTheme.colorScheme.primary
                            )
                            AppButton(
                                text = stringResource(R.string.tarifas_account_copy) + " (USD)",
                                secondary = true,
                                modifier = Modifier.fillMaxWidth(),
                                onClick = {
                                    copiedAccountUsd = LicenseContact.copyText(
                                        ctx,
                                        "Cronos Anestesia — tarjeta Clásica (USD)",
                                        Tariffs.USD_ACCOUNT
                                    )
                                }
                            )
                            if (copiedAccountUsd) {
                                Text(
                                    stringResource(R.string.tarifas_account_copied),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            // Confirmación del pago por WhatsApp
                            Text(
                                stringResource(R.string.tarifas_pay_step3),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                stringResource(R.string.tarifas_pay_currency),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = !paidUsd,
                                    onClick = { paidUsd = false },
                                    label = { Text(stringResource(R.string.tarifas_currency_cup)) }
                                )
                                FilterChip(
                                    selected = paidUsd,
                                    onClick = { paidUsd = true },
                                    label = { Text(stringResource(R.string.tarifas_currency_usd)) }
                                )
                            }
                            OutlinedTextField(
                                value = phone,
                                onValueChange = { phone = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                label = { Text(stringResource(R.string.tarifas_pay_phone_label)) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                shape = RoundedCornerShape(12.dp)
                            )
                            if (phone.isBlank()) {
                                Text(
                                    stringResource(R.string.tarifas_pay_phone_optional),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            } else if (!phoneOk) {
                                Text(
                                    stringResource(R.string.tarifas_pay_phone_needed),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                            AppButton(
                                text = stringResource(R.string.tarifas_pay_done_btn),
                                modifier = Modifier.fillMaxWidth(),
                                onClick = {
                                    copiedPay = false
                                    if (!LicenseContact.openWhatsApp(ctx, payMessage)) {
                                        LicenseContact.shareRequest(ctx, payMessage)
                                        payFallback = true
                                    }
                                }
                            )
                            AppButton(
                                text = stringResource(R.string.tarifas_pay_copy_btn),
                                secondary = true,
                                modifier = Modifier.fillMaxWidth(),
                                onClick = { copiedPay = LicenseContact.copyText(ctx, "Cronos Anestesia — confirmación de pago", payMessage) }
                            )
                            if (payFallback) {
                                Text(
                                    stringResource(R.string.lic_request_fallback),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                            if (copiedPay) {
                                Text(
                                    stringResource(R.string.tarifas_pay_done_copied),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Text(
                                stringResource(R.string.tarifas_cash_note),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // ---- Pagos internacionales ----
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .padding(sp.m.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Text(
                                stringResource(R.string.tarifas_intl_title),
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                stringResource(R.string.tarifas_intl_body),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // ---- Negociación ----
                    Text(
                        stringResource(R.string.tarifas_negotiation),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )

                    // ---- Acciones ----
                    AppButton(
                        text = stringResource(R.string.tarifas_request_btn),
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { showRequest = true }
                    )
                    AppButton(
                        text = stringResource(R.string.tarifas_close),
                        secondary = true,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = onDismiss
                    )
                    Text(
                        stringResource(R.string.settings_developer),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 2.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        }
    }

    if (showRequest) {
        RequestLicenseDialog(
            onDismiss = { showRequest = false },
            preTier = plan.display,
            preDuration = Tariffs.DURATIONS[duration],
            preMethod = Tariffs.PAYMENT_METHODS[0]
        )
    }
}
