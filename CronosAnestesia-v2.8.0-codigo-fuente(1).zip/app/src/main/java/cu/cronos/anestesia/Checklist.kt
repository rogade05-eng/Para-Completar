package cu.cronos.anestesia

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

// =====================================================================
//  CHECKLIST DE SEGURIDAD QUIRÚRGICA OMS (v2.2.0)
//  Lista OMS 2009 en su estructura de 3 fases: Sign In (antes de la
//  inducción), Time Out (antes de la incisión) y Sign Out (antes de que
//  el paciente salga del quirófano). Interactiva, offline, con progreso
//  por fase y guardado del resumen en el expediente.
// =====================================================================

data class ChecklistItem(val text: String, val critical: Boolean = false, val note: String = "")

data class ChecklistPhase(val id: String, val name: String, val moment: String, val items: List<ChecklistItem>)

/** Lista de verificación de seguridad quirúrgica de la OMS (adaptación en español). */
val WHO_CHECKLIST = listOf(
    ChecklistPhase(
        "signin", "Sign In", "Antes de la inducción de la anestesia",
        listOf(
            ChecklistItem("¿Ha confirmado el paciente su identidad, el sitio, el procedimiento y el consentimiento?", critical = true),
            ChecklistItem("¿Está marcado el sitio de la operación?", note = "O no es aplicable."),
            ChecklistItem("¿Funciona el monitor del oxímetro de pulso colocado en el paciente?", critical = true),
            ChecklistItem("¿Tiene el paciente alergias conocidas?"),
            ChecklistItem("¿Existe vía aérea difícil o riesgo de aspiración?", note = "Si SÍ: equipo de vía aérea difícil disponible y asistencia."),
            ChecklistItem("¿Existe riesgo de pérdida de sangre >500 mL (7 mL/kg en niños)?", note = "Si SÍ: acceso venoso y fluidos o sangre planificados.")
        )
    ),
    ChecklistPhase(
        "timeout", "Time Out", "Antes de la incisión cutánea",
        listOf(
            ChecklistItem("Todos los miembros del equipo se presentan por su nombre y función."),
            ChecklistItem("Se confirma verbalmente paciente, sitio y procedimiento.", critical = true),
            ChecklistItem("Se anticipan los eventos críticos: duración prevista, pérdida de sangre prevista y riesgos del paciente."),
            ChecklistItem("¿Se ha administrado la profilaxis antibiótica en los últimos 60 minutos?", critical = true),
            ChecklistItem("¿Se han mostrado las imágenes diagnósticas esenciales?"),
            ChecklistItem("Estertor/riesgo esterno confirmado: ¿equipo de reesternotomía disponible?", note = "Solo cirugía cardíaca con esternotomía: instrumental y circulación extracorpórea listos.")
        )
    ),
    ChecklistPhase(
        "signout", "Sign Out", "Antes de que el paciente salga del quirófano",
        listOf(
            ChecklistItem("La enfermera confirma verbalmente el nombre del procedimiento registrado."),
            ChecklistItem("Recuento completo de instrumental, gasas y agujas.", critical = true),
            ChecklistItem("Identificación correcta de las muestras (leer en voz alta, incluido el nombre del paciente)."),
            ChecklistItem("¿Hay problemas con el equipo que deban resolverse?"),
            ChecklistItem("¿Qué riesgos presenta el paciente para su recuperación y qué medidas debe tomar el equipo?", critical = true)
        )
    )
)

// ------------------------------ Pestaña ------------------------------

@Composable
fun ChecklistTab(onActivate: () -> Unit) {
    val sp = LocalSpacing.current
    val lic = LocalLicense.current
    if (!lic.features.checklist) {
        LockedSection(
            stringResource(R.string.tab_checklist),
            stringResource(R.string.lic_lock_checklist_msg),
            onActivate = onActivate
        )
        return
    }
    // v2.3.0: dos listas de verificación — OMS (v2.2.0) y Anestésica (v2.3.0)
    var whichSet by rememberSaveable { mutableStateOf(0) }
    Column(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = sp.screenHPad.dp)) {
            Spacer(Modifier.height(sp.s.dp))
            SegmentedRow(
                listOf("OMS", "Anestésica"),
                selected = whichSet,
                onSelect = { whichSet = it }
            )
        }
        if (whichSet == 0) WhoChecklistContent() else AnesthChecklistContent()
    }
}

@Composable
private fun WhoChecklistContent() {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    var which by rememberSaveable { mutableStateOf(0) }
    val phase = WHO_CHECKLIST[which.coerceIn(0, WHO_CHECKLIST.size - 1)]
    // estado de marcado por fase (no se retiene al salir: herramienta de quirófano)
    var checks by rememberSaveable(phase.id) {
        mutableStateOf(Array(phase.items.size) { false }.toList())
    }
    val done = checks.count { it }
    val allDone = done == phase.items.size

    Column(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = sp.screenHPad.dp)) {
            Spacer(Modifier.height(sp.s.dp))
            SegmentedRow(
                WHO_CHECKLIST.map { it.name },
                selected = which,
                onSelect = { which = it }
            )
        }
        ScreenColumn {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(Modifier.padding(sp.m.dp)) {
                    Text(
                        phase.name + " · " + phase.moment,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "OMS 2009 · verificación en voz alta con todo el equipo. Los ítems marcados como críticos no deben pasarse nunca.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            // progreso
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Progreso: $done de ${phase.items.size}",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    "${(done * 100) / phase.items.size} %",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            // Barra de progreso propia (sin depender de la versión de material3)
            Row(Modifier.fillMaxWidth().height(8.dp)) {
                Box(
                    Modifier.weight(done.toFloat().coerceAtLeast(0.001f)).height(8.dp)
                        .background(MaterialTheme.colorScheme.primary)
                )
                Box(
                    Modifier.weight((phase.items.size - done).toFloat().coerceAtLeast(0.001f))
                        .height(8.dp).background(MaterialTheme.colorScheme.surfaceVariant)
                )
            }

            if (allDone) {
                Spacer(Modifier.height(sp.xs.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                    )
                ) {
                    Text(
                        "Fase " + phase.name + " completada (" + done + "/" + phase.items.size + "). " +
                            "Anúnciela en voz alta al equipo antes de continuar.",
                        modifier = Modifier.padding(sp.m.dp),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
            }

            // ítems
            phase.items.forEachIndexed { i, item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (checks[i]) MaterialTheme.colorScheme.surfaceVariant
                        else MaterialTheme.colorScheme.surface
                    )
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = sp.xs.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = checks[i],
                            onCheckedChange = { v ->
                                val next = checks.toMutableList()
                                next[i] = v
                                checks = next
                            }
                        )
                        Column(Modifier.padding(vertical = sp.xs.dp)) {
                            Text(
                                item.text,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            if (item.note.isNotBlank()) {
                                Text(
                                    item.note,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (item.critical) {
                                Text(
                                    stringResource(R.string.checklist_critical),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
                AppButton(
                    stringResource(R.string.checklist_reset),
                    secondary = true,
                    modifier = Modifier.weight(1f),
                    onClick = { checks = Array(phase.items.size) { false }.toList() }
                )
                AppButton(
                    stringResource(R.string.checklist_save),
                    modifier = Modifier.weight(1f),
                    onClick = {
                        val criticalPending = phase.items.mapIndexed { i, it ->
                            if (it.critical && !checks[i]) it.text else null
                        }.filterNotNull()
                        val summary = buildString {
                            append("Checklist OMS · ").append(phase.name)
                            append(" (").append(phase.moment).append(")\n")
                            append("Marcados: ").append(done).append(" de ").append(phase.items.size)
                            if (criticalPending.isNotEmpty()) {
                                append("\nPENDIENTES CRÍTICOS:\n")
                                criticalPending.forEach { append("- ").append(it).append('\n') }
                            }
                        }
                        Expediente.saveCalc(ctx, "Checklist OMS", summary)
                        Toast.makeText(ctx, ctx.getString(R.string.exp_saved), Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }
    }
}
