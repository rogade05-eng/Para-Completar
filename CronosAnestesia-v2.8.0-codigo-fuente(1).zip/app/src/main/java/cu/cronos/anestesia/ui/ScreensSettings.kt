// Cronos Anestesia — Pantalla de ajustes: tema, fondo personalizado, letra, densidad y botones
package cu.cronos.anestesia.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight

@Composable
fun AjustesScreen(config: ThemeConfig, onConfig: (ThemeConfig) -> Unit) {
    val sp = LocalSpacing.current
    var bgClaroTmp by remember(config.bgClaro) { mutableStateOf(config.bgClaro) }
    var bgOscuroTmp by remember(config.bgOscuro) { mutableStateOf(config.bgOscuro) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(sp.m),
    ) {
        SectionCard("Modo de apariencia") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(sp.xs)) {
                CronosButton("Claro", { onConfig(config.copy(mode = "claro")) }, Modifier.weight(1f), enabled = config.mode != "claro")
                CronosButton("Oscuro", { onConfig(config.copy(mode = "oscuro")) }, Modifier.weight(1f), enabled = config.mode != "oscuro")
                CronosButton("Sistema", { onConfig(config.copy(mode = "sistema")) }, Modifier.weight(1f), enabled = config.mode != "sistema")
            }
        }

        SectionCard("Paleta de color") {
            PALETTES.forEach { p ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(sp.xs)) {
                    CronosButton(
                        p.label,
                        { onConfig(config.copy(palette = p.name)) },
                        Modifier.weight(1f),
                        enabled = config.palette != p.name,
                    )
                }
            }
        }

        SectionCard("Fondo personalizado (hex, por modo)") {
            Text(
                "Introduzca un color de 6 dígitos, con o sin # (ej.: F0F4F7). Vacíe el campo para usar el fondo de la paleta.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            LabeledField("Fondo modo claro", bgClaroTmp, { v ->
                bgClaroTmp = v.filter { c -> c.isLetterOrDigit() || c == '#' }.take(9)
                onConfig(config.copy(bgClaro = bgClaroTmp))
            })
            LabeledField("Fondo modo oscuro", bgOscuroTmp, { v ->
                bgOscuroTmp = v.filter { c -> c.isLetterOrDigit() || c == '#' }.take(9)
                onConfig(config.copy(bgOscuro = bgOscuroTmp))
            })
        }

        SectionCard("Tamaño de letra") {
            LabeledSlider(
                "Escala de letra",
                config.fontScale,
                { v -> onConfig(config.copy(fontScale = (v * 100).toInt() / 100f)) },
                0.85f..1.30f,
                8,
                "${(config.fontScale * 100).toInt()} %",
            )
        }

        SectionCard("Densidad de la interfaz") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(sp.xs)) {
                CronosButton("Compacta", { onConfig(config.copy(density = "compacta")) }, Modifier.weight(1f), enabled = config.density != "compacta")
                CronosButton("Normal", { onConfig(config.copy(density = "normal")) }, Modifier.weight(1f), enabled = config.density != "normal")
                CronosButton("Amplia", { onConfig(config.copy(density = "amplia")) }, Modifier.weight(1f), enabled = config.density != "amplia")
            }
        }

        SectionCard("Estilo de botones") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(sp.xs)) {
                CronosButton("Sólido", { onConfig(config.copy(buttonStyle = "solido")) }, Modifier.weight(1f), enabled = config.buttonStyle != "solido")
                CronosButton("Contorno", { onConfig(config.copy(buttonStyle = "contorno")) }, Modifier.weight(1f), enabled = config.buttonStyle != "contorno")
                CronosButton("Suave", { onConfig(config.copy(buttonStyle = "suave")) }, Modifier.weight(1f), enabled = config.buttonStyle != "suave")
            }
        }

        SectionCard("Acerca de") {
            Text(
                "Cronos Anestesia v1.0.4 — guía de bolsillo para anestesiología. Funciona 100 % sin conexión; sus preferencias se guardan cifradas en el dispositivo.",
                style = MaterialTheme.typography.bodySmall,
            )
            Text(
                "Herramienta educativa de apoyo: no sustituye el juicio clínico ni los protocolos institucionales. Verificar siempre dosis, diluciones y disponibilidad local.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
            )
            Text(
                "Fuentes: " + cu.cronos.anestesia.data.Sources.ALL.joinToString(" · ") { it.label },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
