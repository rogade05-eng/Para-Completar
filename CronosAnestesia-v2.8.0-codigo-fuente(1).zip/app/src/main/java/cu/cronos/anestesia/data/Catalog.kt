// Cronos Anestesia — Catálogo de fármacos (parte 1). Dosis según Morgan & Mikhail 7.ª,
// Miller 10.ª y Smith & Aitkenhead 8.ª; presentaciones habituales en Cuba (MINSAP/BioCubaFarma).
package cu.cronos.anestesia.data

val DRUGS_A = listOf(
    Drug(
        id = "propofol", name = "Propofol", aliases = listOf("diprivan"),
        category = "Hipnóticos",
        concentration = "Frasco 20 mL al 1 % (10 mg/mL)",
        mgPerMl = 10.0,
        doses = listOf(
            Dose("Inducción adulto", "EV lenta", "mgkg", 1.5, 2.5, source = "morgan"),
            Dose("Inducción > 65 años o ASA III-IV", "EV lenta", "mgkg", 1.0, 1.5, source = "morgan"),
            Dose("Inducción pediátrica", "EV lenta", "mgkg", 2.5, 3.5, source = "miller"),
            Dose("Sedación", "EV", "mcgkg", 25.0, 75.0, note = "en bolo de 0.5–1 mg (10–15 mg/kg no repetir)", source = "morgan"),
        ),
        warnings = listOf(
            "Hipotensión y depresión respiratoria dosis-dependientes",
            "Dolor a la inyección: lidocaína 0.5–1 mg/kg previa o mezclada",
            "Síndrome de infusión de propofol: evitar > 4 mg/kg/h por > 48 h",
            "Reduce el consumo cerebral de O2: útil en neuroanestesia",
        ),
    ),
    Drug(
        id = "tiopental", name = "Tiopental sódico", aliases = listOf("pentotal", "tiopentona"),
        category = "Hipnóticos",
        concentration = "Frasco 1 g (reconstituir a 25 mg/mL)",
        mgPerMl = 25.0,
        doses = listOf(
            Dose("Inducción adulto", "EV", "mgkg", 3.0, 5.0, source = "morgan"),
            Dose("Inducción pediátrica", "EV", "mgkg", 5.0, 6.0, source = "miller"),
            Dose("Control de crisis convulsivas", "EV", "mgkg", 1.0, 2.0, source = "morgan"),
        ),
        warnings = listOf(
            "Procaución en hipovolemia, asma y porfiria (contraindicado)",
            "Extravasación produce necrosis: usar vía segura",
            "Dosis única; acumulación con bolos repetidos",
        ),
    ),
    Drug(
        id = "etomidato", name = "Etomidato", aliases = listOf("hypnomidate"),
        category = "Hipnóticos",
        concentration = "Ampolla 10 mL (2 mg/mL)",
        mgPerMl = 2.0,
        doses = listOf(
            Dose("Inducción", "EV", "mgkg", 0.15, 0.3, source = "morgan"),
            Dose("Inducción en shock/sangrado", "EV", "mgkg", 0.1, 0.15, note = "estabilidad hemodinámica superior", source = "morgan"),
        ),
        warnings = listOf(
            "Mioclonías (10–60 %): premedicar con midazolam u opioide",
            "Inhibe la síntesis de cortisol (dosis única sin relevancia clínica)",
            "Dolor y flebitis en la vía",
            "Primera elección en paciente cardíaco inestable",
        ),
    ),
    Drug(
        id = "ketamina", name = "Ketamina", aliases = listOf("ketalar"),
        category = "Hipnóticos",
        concentration = "Ampolla 2 mL (50 mg/mL) o 10 mL (10 mg/mL)",
        mgPerMl = 50.0,
        doses = listOf(
            Dose("Inducción", "EV", "mgkg", 1.0, 2.0, source = "morgan"),
            Dose("Inducción IM", "IM", "mgkg", 4.0, 6.0, source = "morgan"),
            Dose("Analgosedación", "EV", "mgkg", 0.25, 0.5, note = "bolo lento para analgesia procedural", source = "morgan"),
            Dose("Analgesia subanestésica", "EV", "mgkg", 0.1, 0.2, source = "sedar"),
        ),
        warnings = listOf(
            "Aumenta la presión intracraneal e intraocular: cuidado en neurotrauma y glaucoma",
            "Mantener broncodilatación y estabilidad hemodinámica: útil en asma y shock",
            "Alucinaciones en el despertar: asociar benzodiacepina",
            "Hipertensión y taquicardia transitorias",
        ),
    ),
    Drug(
        id = "midazolam", name = "Midazolam", aliases = listOf("dormicum"),
        category = "Benzodiacepinas",
        concentration = "Ampolla 3 mL (1 mg/mL) o 5 mg/5 mL",
        mgPerMl = 1.0,
        doses = listOf(
            Dose("Premedicación ansiolítica", "IM", "mgkg", 0.03, 0.08, maxAbs = 5.0, source = "morgan"),
            Dose("Sedación consciente", "EV lenta", "mgkg", 0.02, 0.05, maxAbs = 2.5, note = "titular lentamente", source = "morgan"),
            Dose("Inducción coadyuvante", "EV", "mgkg", 0.05, 0.15, source = "morgan"),
            Dose("Crisis convulsivas", "EV/IN", "mgkg", 0.1, 0.2, maxAbs = 10.0, source = "sedar"),
        ),
        warnings = listOf(
            "Depresión respiratoria potenciada por opioides",
            "Dosis > 65 años: reducir 30–50 %",
            "Antagonista: flumazenil",
        ),
    ),
    Drug(
        id = "diazepam", name = "Diazepam", aliases = listOf("valium"),
        category = "Benzodiacepinas",
        concentration = "Ampolla 2 mL (5 mg/mL)",
        mgPerMl = 5.0,
        doses = listOf(
            Dose("Ansiolisis preoperatoria", "EV lenta", "mgkg", 0.05, 0.1, maxAbs = 5.0, source = "morgan"),
            Dose("Crisis convulsivas", "EV lenta", "mgkg", 0.1, 0.2, maxAbs = 10.0, note = "titular, repetir a los 5 min si precisa", source = "morgan"),
        ),
        warnings = listOf(
            "Vesicante: riesgo de flebitis y necrosis (usar vía gruesa)",
            "Semivida larga: sedación residual prolongada",
            "Antagonista: flumazenil",
        ),
    ),
    Drug(
        id = "fentanilo", name = "Fentanilo", aliases = listOf("fentanyl"),
        category = "Opioideos",
        concentration = "Ampolla 2 mL (0.05 mg/mL = 50 mcg/mL)",
        mgPerMl = 0.05,
        doses = listOf(
            Dose("Analgesia intraoperatoria", "EV", "mcgkg", 0.5, 2.0, source = "morgan"),
            Dose("Inducción (coadyuvante)", "EV", "mcgkg", 2.0, 5.0, source = "morgan"),
            Dose("Cardioanestesia", "EV", "mcgkg", 5.0, 15.0, note = "con infusión o bolos repetidos", source = "morgan"),
            Dose("Pediátrico (analgesia)", "EV", "mcgkg", 0.5, 1.0, source = "miller"),
        ),
        warnings = listOf(
            "Apnea y rigidez torácica con bolos altos (> 5 mcg/kg rápido)",
            "Acumulación con infusiones prolongadas (context-sensitive half-time)",
            "Antagonista: naloxona",
        ),
    ),
    Drug(
        id = "morfina", name = "Sulfato de morfina", aliases = listOf("morfine"),
        category = "Opioideos",
        concentration = "Ampolla 1 mL (10 mg/mL)",
        mgPerMl = 10.0,
        doses = listOf(
            Dose("Analgesia intraoperatoria", "EV", "mgkg", 0.05, 0.1, maxAbs = 10.0, note = "administrar 30–45 min antes del final", source = "morgan"),
            Dose("Analgesia postoperatoria", "EV/SC", "mgkg", 0.05, 0.08, maxAbs = 10.0, note = "cada 3–4 h", source = "morgan"),
            Dose("Pediátrico", "EV", "mgkg", 0.05, 0.1, maxAbs = 2.0, source = "miller"),
        ),
        warnings = listOf(
            "Histaminoliberación: hipotensión (evitar en asma activa)",
            "Metabolito morfina-6-glucurónido: acumular en insuficiencia renal",
            "Depresión respiratoria dosis-dependiente; antagonista: naloxona",
        ),
    ),
    Drug(
        id = "petidina", name = "Petidina (meperidina)", aliases = listOf("meperidina", "demerol", "remifentanil"),
        category = "Opioideos",
        concentration = "Ampolla 2 mL (50 mg/mL)",
        mgPerMl = 50.0,
        doses = listOf(
            Dose("Analgesia intraoperatoria", "EV", "mgkg", 0.5, 1.0, maxAbs = 100.0, source = "morgan"),
            Dose("Tremitor postoperatorio (shivering)", "EV", "mgkg", 0.25, 0.5, maxAbs = 50.0, source = "morgan"),
        ),
        warnings = listOf(
            "Metabolito normeperidina: convulsiones acumulativas",
            "CONTRAINDICADA en insuficiencia renal y en pacientes con IMAO",
            "Efecto vagolítico: taquicardia leve",
        ),
    ),
    Drug(
        id = "tramadol", name = "Tramadol", aliases = listOf("crontinal"),
        category = "Opioideos",
        concentration = "Ampolla 2 mL (50 mg/mL)",
        mgPerMl = 50.0,
        doses = listOf(
            Dose("Analgesia postoperatoria", "EV lenta", "mgkg", 1.0, 2.0, maxAbs = 100.0, note = "cada 6–8 h; dosis máx. 400 mg/día", source = "sedar"),
        ),
        warnings = listOf(
            "Náuseas y vómitos frecuentes: considerar profilaxis PONV",
            "Reduce el umbral convulsivo: cuidado en epilépticos",
            "Efecto serotoninérgico: cuidado con IMAO/ISRS",
        ),
    ),
    Drug(
        id = "succinilcolina", name = "Succinilcolina", aliases = listOf("cloruro de suxametonio", "anectine"),
        category = "Relajantes despolarizantes",
        concentration = "Ampolla 2 mL (100 mg/mL)",
        mgPerMl = 100.0,
        doses = listOf(
            Dose("Intubación de secuencia rápida", "EV", "mgkg", 1.0, 1.5, source = "morgan"),
            Dose("Pediátrico (intubación)", "EV", "mgkg", 1.5, 2.0, note = "en lactantes", source = "miller"),
            Dose("Laringoespasmo refractario", "EV", "mgkg", 0.5, 1.0, source = "sedar"),
        ),
        warnings = listOf(
            "CONTRAINDICADA: hipertermia maligna, quemados/graves > 24–72 h, hiperkalemia, parálisis prolongada, miopatías",
            "Predisposición a HM: tener dantrolene disponible",
            "Bradicardia con dosis repetidas (especialmente niños)",
            "Desencadena hiperkalemia letal en denervación",
        ),
    ),
    Drug(
        id = "rocuronio", name = "Rocuronio", aliases = listOf("esmeron"),
        category = "Relajantes no despolarizantes",
        concentration = "Ampolla 5 mL (10 mg/mL)",
        mgPerMl = 10.0,
        doses = listOf(
            Dose("Intubación (90 s)", "EV", "mgkg", 0.6, 0.9, note = "dosis calculada sobre peso ideal si IMC ≥ 35", source = "morgan"),
            Dose("Mantenimiento", "EV", "mgkg", 0.1, 0.2, note = "cada 20–30 min", source = "morgan"),
            Dose("Pediátrico", "EV", "mgkg", 0.6, 1.0, source = "miller"),
        ),
        warnings = listOf(
            "Duración 30–45 min (dosis intubación)",
            "Reversible con sugammadex (2–16 mg/kg según profundidad)",
            "Mínima liberación histamínica; cardiovascularmente neutro",
        ),
    ),
    Drug(
        id = "cisatracurio", name = "Cisatracurio", aliases = listOf("nimbex"),
        category = "Relajantes no despolarizantes",
        concentration = "Ampolla 5 mL (2 mg/mL) o 10 mg/mL",
        mgPerMl = 2.0,
        doses = listOf(
            Dose("Intubación", "EV", "mgkg", 0.15, 0.2, source = "morgan"),
            Dose("Mantenimiento", "EV", "mgkg", 0.03, 0.05, source = "morgan"),
            Dose("Infusión continua", "EV", "mcgkg", 1.0, 2.0, note = "por minuto (1–2 mcg/kg/min)", source = "morgan"),
        ),
        warnings = listOf(
            "Eliminación por degradación de Hofmann: ideal en insuficiencia hepática/renal",
            "Sin liberación histamínica (a diferencia del atracurio)",
            "Duración 40–60 min tras dosis intubación",
        ),
    ),
    Drug(
        id = "vecuronio", name = "Vecuronio", aliases = listOf("norcuron"),
        category = "Relajantes no despolarizantes",
        concentration = "Frasco 10 mg (reconstituir a 1 mg/mL)",
        mgPerMl = 1.0,
        doses = listOf(
            Dose("Intubación", "EV", "mgkg", 0.08, 0.1, source = "morgan"),
            Dose("Mantenimiento", "EV", "mgkg", 0.01, 0.02, source = "morgan"),
        ),
        warnings = listOf(
            "Acumulación de metabolito activo en insuficiencia renal (uso prolongado)",
            "Cardiovascularmente muy estable",
            "Reversible con neostigmina o sugammadex",
        ),
    ),
    Drug(
        id = "pancuronio", name = "Pancuronio", aliases = listOf("pavulon"),
        category = "Relajantes no despolarizantes",
        concentration = "Ampolla 2 mL (2 mg/mL)",
        mgPerMl = 2.0,
        doses = listOf(
            Dose("Intubación", "EV", "mgkg", 0.08, 0.1, source = "morgan"),
            Dose("Mantenimiento", "EV", "mgkg", 0.01, 0.02, source = "morgan"),
        ),
        warnings = listOf(
            "Vagolítico: taquicardia e hipertensión leve (útil con propranolol antes, evitar en cardiopatía isquémica)",
            "Duración prolongada 60–90 min",
            "Eliminación renal: prolongar en insuficiencia renal",
        ),
    ),
    Drug(
        id = "neostigmina", name = "Neostigmina (+ atropina)", aliases = listOf("prostigmine"),
        category = "Reversión",
        concentration = "Ampolla 2 mL (0.5 mg/mL)",
        mgPerMl = 0.5,
        doses = listOf(
            Dose("Reversión del bloqueo", "EV lenta", "mgkg", 0.04, 0.05, maxAbs = 5.0, note = "SIEMPRE con atropina 0.015–0.02 mg/kg o glicopirrolato", source = "morgan"),
            Dose("Pediátrico", "EV lenta", "mgkg", 0.04, 0.05, maxAbs = 2.5, source = "miller"),
        ),
        warnings = listOf(
            "Bradicardia profunda si no se asocia anticolinérgico",
            "Efecto techo: no revierte el bloqueo profundo (> PTC 2–3)",
            "Broncoespasmo: evitar en asmáticos si posible (o glicopirrolato)",
            "Dosis máxima 5 mg",
        ),
    ),
    Drug(
        id = "sugammadex", name = "Sugammadex", aliases = listOf("bridion"),
        category = "Reversión",
        concentration = "Frasco 2 mL (100 mg/mL) o 5 mL (100 mg/mL)",
        mgPerMl = 100.0,
        doses = listOf(
            Dose("Reversión superficial/moderada (T2 recuperado)", "EV", "mgkg", 2.0, 4.0, source = "morgan"),
            Dose("Reversión profunda (PTC 1–2)", "EV", "mgkg", 4.0, 8.0, source = "morgan"),
            Dose("Reversión inmediata tras rocuronio (RSR)", "EV", "mgkg", 16.0, 16.0, source = "morgan"),
        ),
        warnings = listOf(
            "SOLO funciona con rocuronio y vecuronio (encapsulación selectiva)",
            "Disponibilidad limitada en Cuba: confirmar existencia antes de planificar",
            "Recurrencia si se usa más rocuronio después: esperar 30 min",
            "Falla anticonceptivos hormonales (interacción)",
        ),
    ),
)
