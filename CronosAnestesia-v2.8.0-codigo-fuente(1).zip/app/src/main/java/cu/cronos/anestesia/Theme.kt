package cu.cronos.anestesia

import android.content.Context
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.sp
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "cronos_settings")

private val KEY_THEME = intPreferencesKey("theme")           // 0 sistema, 1 claro, 2 oscuro
private val KEY_FONT = floatPreferencesKey("font_scale")     // 0.85 .. 1.30
private val KEY_COMPACT = booleanPreferencesKey("compact")
private val KEY_BIG = booleanPreferencesKey("big_buttons")   // botones grandes (énfasis)

data class AppSettings(
    val themeMode: Int = 0,
    val fontScale: Float = 1f,
    val compact: Boolean = false,
    val bigButtons: Boolean = false
) {
    companion object { val DEFAULT = AppSettings() }
}

object SettingsRepo {
    fun flow(ctx: Context): Flow<AppSettings> = ctx.dataStore.data
        .catch { emit(androidx.datastore.preferences.core.emptyPreferences()) }
        .map { p ->
            AppSettings(
                themeMode = p[KEY_THEME] ?: 0,
                fontScale = (p[KEY_FONT] ?: 1f).coerceIn(0.85f, 1.30f),
                compact = p[KEY_COMPACT] ?: false,
                bigButtons = p[KEY_BIG] ?: false
            )
        }

    fun setTheme(ctx: Context, v: Int) = edit(ctx) { it[KEY_THEME] = v }
    fun setFont(ctx: Context, v: Float) = edit(ctx) { it[KEY_FONT] = v.coerceIn(0.85f, 1.30f) }
    fun setCompact(ctx: Context, v: Boolean) = edit(ctx) { it[KEY_COMPACT] = v }
    fun setBigButtons(ctx: Context, v: Boolean) = edit(ctx) { it[KEY_BIG] = v }

    private fun edit(ctx: Context, block: (androidx.datastore.preferences.core.MutablePreferences) -> Unit) {
        CoroutineScope(Dispatchers.IO).launch { ctx.dataStore.edit(block) }
    }
}

val LocalAppSettings = staticCompositionLocalOf { AppSettings.DEFAULT }

// ---------- Datos del paciente para la calculadora de dosis (peso + edad) ----------

private val KEY_PAT_WEIGHT = floatPreferencesKey("patient_weight_kg")
private val KEY_PAT_AGE = floatPreferencesKey("patient_age_value")
private val KEY_PAT_AGE_UNIT = intPreferencesKey("patient_age_unit") // 0 años, 1 meses

data class PatientDefaults(
    val weightKg: Float = 70f,
    val ageValue: Float = 35f,
    val ageUnit: Int = 0
) {
    companion object { val DEFAULT = PatientDefaults() }
}

/** Último peso/edad usados: la calculadora de dosis no los pide dos veces. */
object PatientRepo {
    fun flow(ctx: Context): Flow<PatientDefaults> = ctx.dataStore.data
        .catch { emit(androidx.datastore.preferences.core.emptyPreferences()) }
        .map { p ->
            PatientDefaults(
                weightKg = (p[KEY_PAT_WEIGHT] ?: 70f).coerceIn(1f, 300f),
                ageValue = (p[KEY_PAT_AGE] ?: 35f).coerceIn(0f, 120f),
                ageUnit = p[KEY_PAT_AGE_UNIT] ?: 0
            )
        }

    fun save(ctx: Context, weightKg: Float, ageValue: Float, ageUnit: Int) {
        CoroutineScope(Dispatchers.IO).launch {
            ctx.dataStore.edit {
                it[KEY_PAT_WEIGHT] = weightKg.coerceIn(1f, 300f)
                it[KEY_PAT_AGE] = ageValue.coerceIn(0f, 120f)
                it[KEY_PAT_AGE_UNIT] = if (ageUnit == 1) 1 else 0
            }
        }
    }
}

/** Espaciados coherentes en toda la app (afectados por el modo compacto). */
data class Spacing(val compact: Boolean) {
    val xs: Int get() = if (compact) 4 else 6
    val s: Int get() = if (compact) 8 else 10
    val m: Int get() = if (compact) 12 else 16
    val l: Int get() = if (compact) 16 else 22
    val screenHPad: Int get() = if (compact) 10 else 14
}

val LocalSpacing = staticCompositionLocalOf { Spacing(false) }

// Paleta quirúrgica
private val TealDeep = Color(0xFF0B5E5B)
private val TealMain = Color(0xFF0E6E69)
private val TealLight = Color(0xFF4FB3AB)
private val BgWarm = Color(0xFFFAF8F5)
private val SurfaceWarm = Color(0xFFFFFFFF)
private val InkBright = Color(0xFF1B2624)
private val InkSoft = Color(0xFF5A6A67)
private val DarkBg = Color(0xFF101614)
private val DarkSurface = Color(0xFF18201E)
private val DarkSurfaceHigh = Color(0xFF22302C)
private val DarkInk = Color(0xFFE4EEEB)
private val DarkInkSoft = Color(0xFFA9BCB7)
private val Coral = Color(0xFFB3473F)
private val CoralDark = Color(0xFFE0776F)

private val LightColors = lightColorScheme(
    primary = TealMain,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCDE9E6),
    onPrimaryContainer = Color(0xFF063F3C),
    secondary = Color(0xFF4A6360),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD6E8E5),
    onSecondaryContainer = Color(0xFF13201E),
    tertiary = Coral,
    onTertiary = Color.White,
    background = BgWarm,
    onBackground = InkBright,
    surface = SurfaceWarm,
    onSurface = InkBright,
    surfaceVariant = Color(0xFFEFF3F1),
    onSurfaceVariant = InkSoft,
    outline = Color(0xFFB9C4C1),
    error = Coral
)

private val DarkColors = darkColorScheme(
    primary = TealLight,
    onPrimary = Color(0xFF06302D),
    primaryContainer = Color(0xFF0E4A47),
    onPrimaryContainer = Color(0xFFBFE6E1),
    secondary = Color(0xFF9CC3BE),
    onSecondary = Color(0xFF0D2522),
    secondaryContainer = Color(0xFF27403C),
    onSecondaryContainer = Color(0xFFCBE3DF),
    tertiary = CoralDark,
    onTertiary = Color(0xFF2A0C09),
    background = DarkBg,
    onBackground = DarkInk,
    surface = DarkSurface,
    onSurface = DarkInk,
    surfaceVariant = DarkSurfaceHigh,
    onSurfaceVariant = DarkInkSoft,
    outline = Color(0xFF53655F),
    error = CoralDark
)

private fun scaledTypography(fontScale: Float): Typography {
    val s = fontScale
    val base = Typography()
    return base.copy(
        displaySmall = base.displaySmall.copy(fontSize = (34f * s).sp, lineHeight = (40f * s).sp, fontWeight = FontWeight.SemiBold),
        headlineSmall = base.headlineSmall.copy(fontSize = (23f * s).sp, lineHeight = (28f * s).sp, fontWeight = FontWeight.SemiBold),
        titleLarge = base.titleLarge.copy(fontSize = (20f * s).sp, lineHeight = (26f * s).sp, fontWeight = FontWeight.SemiBold),
        titleMedium = base.titleMedium.copy(fontSize = (16.5f * s).sp, lineHeight = (22f * s).sp, fontWeight = FontWeight.SemiBold),
        titleSmall = base.titleSmall.copy(fontSize = (14.5f * s).sp, lineHeight = (20f * s).sp, fontWeight = FontWeight.SemiBold),
        bodyLarge = base.bodyLarge.copy(fontSize = (16f * s).sp, lineHeight = (23f * s).sp),
        bodyMedium = base.bodyMedium.copy(fontSize = (14.5f * s).sp, lineHeight = (21f * s).sp),
        bodySmall = base.bodySmall.copy(fontSize = (12.5f * s).sp, lineHeight = (17f * s).sp),
        labelLarge = base.labelLarge.copy(fontSize = (14.5f * s).sp, lineHeight = (20f * s).sp, fontWeight = FontWeight.Medium),
        labelMedium = base.labelMedium.copy(fontSize = (12.5f * s).sp, lineHeight = (16f * s).sp, fontWeight = FontWeight.Medium),
        labelSmall = base.labelSmall.copy(fontSize = (11f * s).sp, lineHeight = (14f * s).sp, fontWeight = FontWeight.Medium)
    )
}

/** Ajusta el contraste de los iconos de las barras del sistema según el fondo. */
@Composable
fun SystemBarAppearance(darkIcons: Boolean) {
    val view = LocalView.current
    SideEffect {
        var ctx = view.context
        while (ctx is android.content.ContextWrapper && ctx !is android.app.Activity) {
            ctx = ctx.baseContext
        }
        if (ctx is android.app.Activity) {
            androidx.core.view.WindowCompat.getInsetsController(ctx.window, view)
                .isAppearanceLightStatusBars = darkIcons
        }
    }
}

@Composable
fun CronosTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val colors = if (dark) DarkColors else LightColors

    SystemBarAppearance(darkIcons = !dark)

    CompositionLocalProvider(
        LocalAppSettings provides settings,
        LocalSpacing provides Spacing(settings.compact)
    ) {
        val baseDensity = LocalDensity.current
        val adjusted = Density(
            density = baseDensity.density,
            fontScale = (baseDensity.fontScale * settings.fontScale).coerceIn(0.5f, 2.0f)
        )
        CompositionLocalProvider(LocalDensity provides adjusted) {
            MaterialTheme(
                colorScheme = colors,
                typography = scaledTypography(1f),
                content = content
            )
        }
    }
}
