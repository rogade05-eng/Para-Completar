package cu.cronos.anestesia

// =====================================================================
//  MÓDULO CLÍNICO (Fase 2) — Parte 2
//  Bloqueos regionales básicos, monitorización y planificador preop
//  (contrato 5.1). Contenido: v2 (octubre 2026).
// =====================================================================

val REGIONAL_BLOCKS_BASE = listOf(
    // ------------------------------------------------------------------
    ClinTopic(
        "Raquianestesia (subaracnoidea)",
        "Aguja fina, dosis hiperbárica, nivel objetivo",
        "Bloqueo",
        listOf(
            "Indicación" to "Cirugía por debajo del ombligo: urología, ginecológica, obstétrica (cesárea), traumatología de miembro inferior, hernias. Ventajas: despierto, vía aérea intacta, excelente analgesia, menos opioides. Contraindicaciones: rechazo del paciente, sepsis en el sitio de punción, coagulopatía, hipovolemia grave, hipertensión intracraneal.",
            "Técnica" to "Decúbito lateral (línea de espaldas al plano de la mesa) o sentado con apoyo. Palpar L3–L4 (línea intercristal) o L2–L3; antisepsia con clorhexidina y secado. Aguja balsa de 25–27 G con introductor: sentir la pérdida de resistencia ligaduras + ligamentos + dura y verificar salida de LCR. Inyectar sin aspirar de nuevo en exceso (riesgo de reaspiración de tejido). Marcar el nivel objetivo y comprobar el bloqueo con alcohol frío y dermatomas cada 2 min.",
            "Dosis y adyuvantes" to "Bupivacaína hiperbárica 0,5%: 12–15 mg para nivel T6–T8; cesárea 10–12 mg (objetivo T4–T6). Alternativa levobupivacaína isobárica o ropivacaína. Adyuvantes: fentanilo 15–25 µg (mejora la calidad) o morfina 0,1–0,2 mg en cesárea (analgesia prolongada: vigilar depresión respiratoria 12–24 h). Duración 2–3 h con bupivacaína.",
            "Hipotensión y bradicardia" to "Profilaxis: coloides 250–500 mL o cristaloides moderados + vasopresor. Fenilefrina 50–100 µg en bolos o infusión 0,25–1 µg/kg/min (efedrina 5–10 mg si bradicardia). Tratamiento: volumen, vasopresor, inclinación lateral, oxígeno. Bradicardia severa o bloqueo cardíaco: atropina 0,5–1 mg; si no responde: epinefrina. Bloqueo alto (>T2): soporte ventilatorio y vigilancia de la conciencia.",
            "Complicaciones" to "PDPH: <1% con aguja de 25–27 G balsa; tratamiento conservador → parche epidural de sangre si persiste >72 h. Retención urinaria (vigilar diuresis). Hematoma epidural (1:150 000): urgencia neuroquirúrgica <8 h si hay déficit motor. Radiculopatía transitoria: más frecuente con lidocaína 5% — evitar en lumbalgia. Absceso epidural: fiebre + dolor + déficit días después. Aspirar antes de inyectar siempre: la inyección intratecal de un vial no estéril o de dosis epidural puede ser catastrófica."
        )
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Epidural lumbar y torácica",
        "Catéter, dosis test y analgesia continua",
        "Bloqueo",
        listOf(
            "Indicación" to "Analgesia laboral, analgesia postoperatoria de cirugía torácica, abdominal mayor y ortopédica mayor, y anestesia quirúrgica combinada con raquídea (combinada). El catéter permite prolongar y titular el bloqueo.",
            "Técnica" to "Decúbito lateral o sentado. Espacio: T7–T10 para torácica (cirugía toracoabdominal), L2–L3/L3–L4 lumbar. Pérdida de resistencia con salina (evitar aire: riesgo de bloqueo incompleto y neumocéfalo). Catéter 4–5 cm en el espacio epidural. TEST de aspiración + dosis test: lidocaína 1,5% 3 mL con adrenalina 1:200 000 — descartar intratecal (bloqueo denso rápido) e intravascular (taquicardia). Dosis fraccionada: 5 mL cada 5 min hasta nivel objetivo.",
            "Dosis de anestesia quirúrgica" to "Lidocaína 1,5–2% o bupivacaína 0,5%: 15–25 mL fraccionados según nivel. Ropivacaína 0,75% para cirugía menor-moderada. Adyuvante: fentanilo 50–100 µg.",
            "Analgesia continua" to "Bupivacaína o ropivacaína 0,1–0,2% a 6–10 mL/h + fentanilo 2 µg/mL (o sufentanilo 0,3–0,5 µg/mL). Vigilar: nivel sensorial cada 4–6 h, pausas nocturnas si hipotensión, retirar cuando se moviliza y ya no hay demanda. Rotura del catéter: nunca retirar con tracción contra resistencia — consultar.",
            "Complicaciones y anticoagulantes" to "Hipotensión, retención urinaria, prurito (opioides), bloqueo motor excesivo (diluir), LAST por catéter venoso epidural (vigilar prurito/taquicardia al bolus), hematoma epidural y absceso. Tiempos ASRA: ACOD 24–72 h antes según riesgo y ClCr (reanudar 24 h después); enoxaparina profiláctica 12 h antes y 12 h después del catéter (terapéutica: 24 h); warfarina INR <1,5; clopidogrel 7 días antes; AAS solo no contraindica. Retirar el catéter con los mismos criterios de espera que para puncionar."
        )
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Bloqueo interescalénico",
        "Hombro y clavícula · C5–C6",
        "Bloqueo",
        listOf(
            "Indicación" to "Cirugía del hombro y de la clavícula (artroscopia, prótesis, fracturas): el más eficaz para hombro. Analgesia postoperatoria excelente con catéter.",
            "Técnica" to "Ecografía in-plane a nivel del cartílago cricoideo: identificar raíces C5–C7 entre los escalenos (visión \"trilobulada\"). Aguja 22 G 50 mm de lateral a medial SIN cruzar la pleura. Inyectar fraccionado alrededor de las raíces, no intraneural (no inyectar con alta resistencia ni parestesias persistentes).",
            "Dosis y adyuvantes" to "Ropivacaína 0,5%: 15–20 mL (analgesia 12–18 h). Levobupivacaína 0,5% similar. Adyuvantes: dexametasona 8 mg prolonga 2–4 h (evidencia moderada), dexmedetomidina 50 µg prolonga y acelera, buprenorfina controversial. Dosis máxima global: respetar el cálculo de anestésico local (Calculadoras → Anestésico local).",
            "Efectos colaterales esperables" to "Parálisis diafragmática ~100% (bloqueo C3–C5): cuidado en EPOC grave o contralateral; evitar bilateral. Síndrome de Horner (miosis, ptosis, anhidrosis). Disfonía por bloqueo del nervio laríngeo recurrente. Disgeusia/facial. Explicarlos ANTES al paciente: son previsibles, no complicaciones.",
            "Riesgos mayores" to "Inyección intratecal o epidural cervical (aspirar, fraccionar, test con 1 mL): apnea y paro — tener vía aérea y adrenalina listas. LAST por vascularización abundante. Neumotórax raro con US. Lesión radicular: no inyectar contra parestesias ni con alta presión de apertura (>15 psi). Arteria vertebral y espacio epidural cervical: no dirigir la aguja medialmente."
        )
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Bloqueo supraclavicular",
        "El \"espinal del brazo\": braquial distal",
        "Bloqueo",
        listOf(
            "Indicación" to "Cirugía del brazo, antebrazo, codo y mano (no cubre hombro ni axila: nervios cutáneos mediales viajan con C8–T1 subclavio). Bloqueo más completo del plexo con un solo volumen.",
            "Técnica" to "Ecografía supraclavicular: triángulo formado por arteria subclavia, primera costilla y pleura; el plexo se ve como \"racimo de monedas\" lateral y superficial a la arteria. Aguja in-plane de lateral a medial SIN atravesar el racimo ni acercarse a la pleura. Inyectar en el \"codo\" del racimo para difusión completa.",
            "Dosis" to "Ropivacaína 0,5%: 20–25 mL (12–16 h) o 0,375% 25–30 mL para mayor duración. Fraccionar en 2–3 depósitos alrededor de la arteria.",
            "Ventajas y limitaciones" to "Instalación rápida (10–20 min), alta tasa de éxito (>95% con US). No bloquea de forma fiable el intercostobraquial ni el supraclavicular medial (incisión axilar/cervical: bloquearlos de forma subcutánea).",
            "Riesgos" to "Neumotórax (1–2% sin US, <0,5% con US): vigilancia si disnea o dolor pleurítico. LAST (la arteria subclavia acompaña al plexo): aspirar, fraccionar, dosis global vigilada. Parálisis diafragmática 30–50% (menos que interescalénico pero relevante en EPOC). Síndrome de Horner. Lesión del plexo: no inyectar intraneural (expansión en el interior del racimo = alta presión: reubicar)."
        )
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Bloqueo axilar",
        "Mano y antebrazo · el más seguro del plexo",
        "Bloqueo",
        listOf(
            "Indicación" to "Cirugía de mano, muñeca y antebrazo distal. El más seguro del plexo braquial: lejos de pleura y de neuraxis; ideal en pacientes con riesgo respiratorio.",
            "Técnica" to "Ecografía en el pliegue axilar: arteria axilar rodeada por los nervios (mediano, ulnar, radial). Aguja in-plane; bloquear cada nervio en su posición. El NERVIO MUSCULOCUTÁNEO está FUERA de la vaina (dentro del coracobranquial): bloquearlo aparte con 5 mL (crítico para no fallar). Complementar con bloqueo subcutáneo del intercostobraquial si la incisión es medial.",
            "Dosis" to "Ropivacaína 0,5%: 25–40 mL totales distribuidos (5–10 mL por nervio). Duración 10–14 h.",
            "Instalación y manejo" to "Instalación lenta (20–30 min): planificar antes de la incisión. Isquemia por manguito prolongado: analgesia con sedación o perfusión de propofol; considerar bloqueo con catéter si cirugía larga.",
            "Riesgos" to "LAST por vascularización (la arteria acompaña): dosis global vigilada, aspirar y fraccionar. Parestesias prolongadas (2–3%): menor con US que con neuroestimulación. Hematoma. No hay riesgo de pleura ni de neuraxis: elección pediátrica y de pacientes de alto riesgo."
        )
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Bloqueo femoral y aductor",
        "Cadera, fémur y rodilla · preservar la marcha",
        "Bloqueo",
        listOf(
            "Bloqueo femoral" to "Indicación: cirugía de cadera, fémur y rodilla; analgesia postoperatoria. Técnica: US bajo el ligamento inguinal, inyectar alrededor de la arteria femoral bajo la fascia ilíaca (el bloqueo de la fascia ilíaca cubre femoral + obturador + cutáneo femoral lateral: el clásico \"3 en 1\"). Dosis: ropivacaína 0,375–0,5% 20–30 mL. Debilita el cuádriceps: RIESGO DE CAÍDAS — no deambular sin ayuda, planear apoyo.",
            "Bloqueo aductor (ACB)" to "Indicación: analgesia de rodilla (artroscopia, prótesis) PRESERVANDO el cuádriceps. Técnica: US en el canal aductor (tercio medio del muslo, entre el sartorio y el vasto medial); inyectar alrededor de la rama del nervio femoral y del nervio safeno. Dosis: ropivacaína 0,2% 15–20 mL. Menos analgesia femoral pero marcha más precoz y segura.",
            "Bloqueo del cutáneo femoral lateral" to "Para injertos de piel, injerto de hueso iliaco y dolor en el lateral del muslo: US bajo la espina ilíaca anterosuperior entre el sartorio y el tensor de la fascia lata; 10 mL de ropivacaína 0,375%.",
            "Bloqueo de la fascia ilíaca (FICB suprainguinal)" to "Cubre femoral + obturador + cutáneo femoral lateral + ramas ilioinguinales: útil en cadera (artroplastia) y analgesia hipogástrica. Dosis: 30–40 mL de ropivacaína 0,375% bajo la fascia ilíaca, desplazando el plano hacia el sacro. Cuidado: volumen grande, dosis máxima global.",
            "Riesgos comunes" to "LAST (volumen grande en zona vascular): calcular dosis global. Hematoma psoas si hay anticoagulantes terapéuticos: coordinar tiempos. Lesión nerviosa por inyección intraneural (US + fraccionamiento + presión baja). Caídas por debilidad del cuádriceps (femoral): informar, rehabilitar, usar ACB cuando sea posible."
        )
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Bloqueo TAP y de pared abdominal",
        "Pared abdominal: analgesia somática",
        "Bloqueo",
        listOf(
            "TAP (transverso del abdomen)" to "Indicación: analgesia de pared abdominal en hernias, cesárea, laparotomía menor; NO cubre el dolor visceral (el opioide sigue siendo necesario en laparoscopia). Técnica: US entre el oblicuo interno y el transverso en la línea axilar (triángulo de Ludwig); 15–20 mL por lado de ropivacaína 0,25–0,375%. Subcostal para epigastrio; ilioinguinal/iliohipogástrico para hernia inguinal (pediatría: 0,25–0,5 mL/kg de bupivacaína 0,25%).",
            "Recto del abdomen" to "Para hernia epigástrica y cirugía del ombligo: US en el borde lateral del recto, plano entre el recto y la vaina posterior; 10–15 mL por lado.",
            "ESP (erector de la columna)" to "Indicación: analgesia torácica (costillas, mastectomía, toracotomía) y abdominal superior; alternativa a la epidural torácica sin riesgo de PDPH ni neuraxis. Técnica: US a nivel T5 (o según dermatomas), plano entre el erector espinal y el proceso transverso; 20–30 mL de ropivacaína 0,25–0,375% por lado (difusión craneocaudal por el plano fascial); catéter posible para continua.",
            "Pecoral (PECS I/II) y serrato" to "PECS I: pectoral menor (cirugía de prótesis mamaria); PECS II: + serrato y costillas 2–5 (mastectomía con linfadenectomía). Serrato anterior: costillas 4–6 para toracotomía/drenaje. Dosis: 10–20 mL por plano.",
            "Precauciones" to "Cálculo de dosis máxima GLOBAL: sumar todos los depósitos de ambos lados (fácil superar 200–400 mL de diluciones). LAST: aspirar, fraccionar y vigilancia 30 min. Lesión hepática/esplénica si el plano es demasiado profundo. Peritoneo e intestino: no inyectar en la cavidad. No cubren el dolor visceral ni el de la vía biliar: combinar con opioides o analgesia multimodal."
        )
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Bloqueo del plano del erector (ESP) y espinal alta",
        "Torácico: alternativa segura a la epidural",
        "Bloqueo",
        listOf(
            "ESP torácico" to "El bloqueo fascial más versátil del tórax: mastectomía, costillas fracturadas, drenaje pleural, toracotomía (con catéter). Cubre ramas anteriores y laterales de los nervios intercostales de forma extensa. Nivel de referencia T5 para tórax medio; T2–T3 para mastectomía, T7–T9 para epigastrio.",
            "Técnica" to "US en eje parasagital: identificar el proceso transverso (sombra acústica), el erector espinal encima y la pleura profunda. Aguja hasta apoyarse en el transverso bajo el erector: inyectar en el plano fascial y ver la expansión que desplaza el músculo. 20–30 mL de ropivacaína 0,25–0,375% por lado; catéter para continua (5–10 mL/h de 0,2%).",
            "Paravertebral torácico" to "Alternativa clásica más específica (unilateral, dermatomas definidos): espacio entre los procesos transversos; riesgo de neumotórax y de inyección epidural/intratecal. Reservado a operadores expertos o guía US.",
            "Intercostal" to "Para fracturas costales y drenajes: 5 mL de anestésico local por espacio, cerca del ángulo costal bajo la costilla inferior. Múltiples inyecciones: dosis máxima global vigilada. Riesgo: neumotórax y LAST (vascularización intercostal muy rica).",
            "Elección y seguridad" to "ESP tiene el mejor perfil de seguridad (lejos de pleura, de neuraxis y de grandes vasos) y el PDPH es inexistente: primera opción para analgesia torácica cuando la epidural no es viable (anticoagulantes, sepsis local, paciente anticoagulado). Verificar siempre dosis máximas con la calculadora de anestésicos locales y vigilar al paciente 30 min después."
        )
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Bloqueo ciático y poplíteo",
        "Miembro inferior posterior: fosa, muslo y pie",
        "Bloqueo",
        listOf(
            "Indicación" to "Cirugía de pie, tobillo y pierna (combinado con femoral/safeno para cubrir la cara interna), retirada de cuerpos extraños, fasciotomía posterior, analgesia de trauma. El ciático inerva la cara posterior del muslo, toda la pierna posterior y el pie (excepto la cara medial del tobillo: safeno).",
            "Técnica subglúteo y poplíteo" to "Subglúteo ecoguiado (por debajo del pliegue glúteo, lateral al isquiotibial): fácil de aprender, catéter cómodo. Poplíteo posterior: pliegue poplíteo 7–9 cm proximal, entre las cabezas del bíceps femoral (lateral) y los isquiotibiales (medial); evita el inmovilismo del muslo. Poplíteo lateral: alternativa sin cambiar de posición. El nervio se identifica por su sección ovalada hiperecoica en el espacio entre vasos poplíteos y bíceps; a este nivel ya está bifurcado en tibial y peroneo común: inyectar entre ambas ramas para bloquearlas todas.",
            "Dosis y adyuvantes" to "Ropivacaína 0,5% 20–30 mL (o bupivacaína 0,375–0,5% 15–20 mL para bloqueo prolongado); nunca superar la dosis máxima global sumando otros bloqueos (calculadora de anestésicos locales). Inicio 20–35 min; acelerar con lidocaína 1–2% mezclada o adyuvantes (dexametasona 4–8 mg, clonidina 50–100 µg). Poplíteo: el levantamiento del pie no caído puede tardar; aviso al paciente antes de caminar.",
            "Seguridad" to "Vasos poplíteos y nervio comparten vaina: aspirar antes de cada inyección incremental, inyectar en fracciones de 5 mL, vigilar la expansión y evitar alta presión (riesgo de inyección intraneural). Bloquear el peroneo común causa pie caído transitorio: warn al paciente y férula si camina. Paresia residual tras 24–36 h: estudio electrofisiológico y seguimiento (neuropraxia por compresión posicional es la causa más frecuente).",
            "Combinación práctica" to "Para cirugía de tobillo y pie: ciático poplíteo + safeno (o bloqueo aductor alto con difusión distal) cubre todo el pie sin isquemia del miembro. Para rodilla: femoral + ciático poplíteo o esquema de analgesia multimodal con bloqueo aductor para preservar la marcha."
        )
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Bloqueo paravertebral e intercostal",
        "Torácico por dermatomas: clásico, efectivo y con reglas",
        "Bloqueo",
        listOf(
            "Indicación" to "Toracotomía, fracturas costales múltiples, drenaje torácico, cirugía mamaria unilateral: analgesia segmentaria unilateral con catéter para días. El paravertebral bloquea los nervios en su salida del foramen (somático + simpático del mismo dermatoma): el más parecido a una epidural unilateral.",
            "Técnica paravertebral" to "Nivel objetivo: dermatoma central de la incisión ±2 niveles. Proceso espinoso del nivel superior: avanzar 2,5 cm lateral y perpendicular hasta contacto con el transverso (5–7 cm), retirar 1 cm y pasar bajo su borde caudal 1–1,5 cm: pérdida de resistencia al entrar en el espacio. Ecoguiado: vistas transversa y parasagital, pleura y pleura parietal siempre en pantalla; inyectar 5 mL por nivel de bupivacaína/ropivacaína 0,25–0,5%, 3–5 niveles; catéter a 3–4 cm para infusión de 0,2% a 5–10 mL/h.",
            "Intercostal" to "Analgesia de fracturas costales y drenajes: subcostal al borde inferior de la costilla, 3–5 mL por espacio (vascularización rica: dosis máxima global vigilada). Usar US para ver la pleura y el espacio intercostal; catéter intercostal posible en UCI. Repetir cada 6–8 h o infusión continua en el espacio más doloroso.",
            "Riesgos y límites" to "Neumotórax (1–2% en manos expertas: menos con US), inyección epidural o intratecal (hipotensión y bloqueo total: dosis test fraccionada obligatoria), inyección intravascular (arteria intercostal), hipotensión simpática unilateral leve. NO en sepsis del sitio, coagulopatía significativa (tratar como neuraxial profundo para los criterios anticoagulantes), deformidad espinal grave o cirugía previa del nivel.",
            "Paravertebral vs. epidural vs. ESP" to "Epidural torácica: bilateral y más potente, pero hipotensión y retención urinaria; paravertebral: unilateral, estable, catéter cómodo para toracotomía; ESP: fascial, el más seguro, algo menos profundo en cobertura posterior. Decidir ANTES de la cirugía y escribir el plan: el bloqueo posoperatorio instituido tarde duele más y falla más."
        )
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Bloqueos Pecs y Serratus anterior",
        "Analgesia torácica fascial: mama y pared anterolateral",
        "Bloqueo",
        listOf(
            "Anatomía y variantes" to "PECS I: plano entre pectoral mayor y menor (nervios pectorales medial y lateral + ramas intercostales T2–T6): mastectomía simple, port-a-cath. PECS II: añade el plano entre pectoral menor y serrato (axilar: T2–T9, cubre axila y porción anterolateral del tórax): mastectomía con linfadenectomía, prótesis. Serratus anterior plane (SAP): más lateral y posterior (ramas intercostales T2–T9): toracotomía, drenajes, fracturas costales anterolaterales.",
            "Técnica" to "US lineal de alta frecuencia; PECS I/II con sonda entre la 3.ª y 4.ª costilla bajo la clavícula desplazada lateralmente; identificar los tres músculos en capas. Aguja in-plane hasta el plano diana: PECS I 10 mL, PECS II 10–15 mL más (bupivacaína/ropivacaína 0,25–0,375% por lado, respetando la dosis máxima). SAP: sonda en línea axilar media, inyectar sobre el serrato, 15–25 mL; difusión craneal/caudal según posición y volumen.",
            "Cuándo elegir cada uno" to "Mama simple: PECS I ± II. Mama con axila: PECS II. Drenaje torácico y fracturas: SAP (o ESP si se quiere cubrir posterior). Son bloqueos SOMÁTICOS: no cubren pleura ni tejido profundo: la mastectomía con prótesis puede requerir más (bloqueo parasternal para perforantes internas).",
            "Seguridad" to "Perfil excelente: lejos de pleura (verificar trayectoria en US), de neuraxis y de vasos. Inyectar fraccionado con aspiración; vigilar la dosis máxima global si se combinan con paravertebral o intercostal. Un fallo del bloqueo no debe retrasar la analgesia sistémica de rescate: plan B escrito antes de inducir.",
            "Integración multimodal" to "Bloqueo fascial + paracetamol + AINE (si no hay contraindicación) + ketamina en dosis subanalgésica si se prevé dolor intenso: reduce la morfina de rescate y sus efectos adversos. Documentar el bloqueo (nivel, volumen, concentración, hora) para el turno de recuperación y la valoración del siguiente bloqueo de catéter si existe."
        )
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Bloqueo ilioinguinal, iliohipogástrico y genitofemoral",
        "Pared baja y región inguinal: hernias y cirugía urológica",
        "Bloqueo",
        listOf(
            "Indicación" to "Herniorrafia inguinal (adulto y pediátrica), hidrocelectomía y orquidopexia, cirugía ginecológica por vía inguinal, analgesia postoperatoria de cesárea suprapúbica. Cubre la pared entre el ombligo y el muslo en su porción inguinal (L1) más la cara interna del muslo y el pubis (genitofemoral).",
            "Técnica ecoguiada" to "Sonda lineal oblicua sobre la espina ilíaca anterosuperior: los tres nervios corren entre oblicuo interno y transverso (iliohipogástrico e ilioinguinal) y bajo el inguinal hacia el canal (genitofemoral rama genital). Inyectar 10–15 mL de 0,25–0,375% en el plano fascial medial a la EIAS más 5–8 mL en el canal inguinal si la cirugía alcanza el escroto/labio. En pediátrico: volúmenes de 0,2–0,3 mL/kg por plano, concentraciones 0,2–0,25%.",
            "Alternativa por vía de referencia (sin US)" to "Punto clásico a 2 cm medial y 2 cm caudal a la EIAS con pérdida de resistencia en dos capas (oblicuo externo/interno y transverso). Menor precisión: mayor tasa de fallo y de inyección intraperitoneal o vascular: hoy preferir US siempre que esté disponible.",
            "Seguridad y fallos" to "Estructuras vecinas: vasos ilíacos (medial), intestino (profundo por debajo del transverso: mantener la aguja superficial al fascia), peritoneo (aspirar; si el paciente tose o hay dolor visceral, reevaluar). El fallo más común es no cubrir el genitofemoral: el dolor escrotal/labial postoperatorio se rescata con infiltración subcutánea del canal por el cirujano. La infiltración quirúrgica con anestésico local en la herida es complementaria y barata: coordinarla.",
            "Bloqueos combinados en hernia" to "Herniorrafia bajo raquídea o sedación: el bloqueo de pared reduce la analgesia de rescate. Cirugía ambulatoria pura: algunos equipos combinan ilioinguinal + TAP bajo con sedación ligera evitando la raquídea (sin retención urinaria ni cefalea pospunción): ideal para el alta a las 2 h."
        )
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "LAST: toxicidad sistémica por anestésicos locales",
        "Reconocimiento precoz y protocolo de lípidos 20%",
        "Bloqueo",
        listOf(
            "Mecanismo y factores de riesgo" to "Bloqueo de canales de sodio/cardíacos y cerebrales por anestésico local en sangre: inyección intravascular accidental o absorción excesiva de dosis correctas en tejido muy vascularizado (intercostal, paracervical, plexo). Riesgo creciente con bupivacaína (cardiotoxicidad > ropivacaína > lidocaína), dosis global sumada de varios bloqueos, hipoproteinemia, acidosis, edad extrema y embarazo. Siempre calcular y sumar la dosis de TODOS los bloqueos del mismo paciente (calculadora de anestésicos locales).",
            "Reconocimiento" to "Prodrómicos: acúfenos, sabor metálico, perioral, agitación, somnolencia, taquicardia/hipertensión (excitación). Después: convulsiones, bradicardia, arritmias (QRS ancho, Taq de puntiaguda — torsades, asistolia). El LAST puede presentarse DIRECTO como colapso cardíaco sin fase prodrómica (bupivacaína): sospecharlo ante arritmia refractaria en un paciente con bloqueo reciente. Latencia típica tras inyección: 1–5 min (intravascular) hasta 30 min (absorción).",
            "Manejo inmediato" to "PARAR la inyección y pedir ayuda; llamar al equipo de reanimación. Vía aérea con O2 al 100%; evitar parada circulatoria: manejo de convulsiones con benzodiacepina (evitar propofol en dosis altas si hay inestabilidad). Antiarritmias: SOLO lípidos (evitar amiodarona, betabloqueantes, calcioantagonistas y lidocaína adicional). Epinefrina en DOSES PEQUEÑAS (<1 µg/kg) si se necesita: los bolos grandes empeoran el rescate lipídico. Arritmias refractarias: bypass cardiopulmonar si está disponible. RCP prolongada (más de 1 h) puede ser necesaria: los lípidos necesitan tiempo.",
            "Protocolo de lípidos 20%" to "Bolo 1,5 mL/kg en 1 min (aprox. 100 mL en adulto de 70 kg); repetir cada 5 min si la inestabilidad persiste (máximo 3 bolos) e iniciar infusión 0,25 mL/kg/min (aprox. 18 mL/min en 70 kg); doblar la velocidad si la presión no responde; máximo total 10–12 mL/kg en las primeras 30 min. Tener el esquema impreso en la barra de emergencias y el vial de lípidos 20% EN LA SALA donde se hagan bloqueos.",
            "Prevención" to "Dosis máximas calculadas y registradas; aspiración antes de cada alícuota; inyección incremental (3–5 mL) marcando el tiempo entre fracciones; marcador de aguja ecogénica con visualización de la punta TODO el tiempo; dosis test intravascular (epinefrina 5–10 µg con monitorización: taquicardia/hipertensión = intravascular); monitorización estándar durante y 30 min después de todo bloqueo mayor."
        ),
        calcId = "lamax"
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Anticoagulación y bloqueos neuraxiales",
        "Cuándo puncionar, cuándo retirar el catéter (ASRA)",
        "Bloqueo",
        listOf(
            "Principio" to "El hematoma epidural/espinal es la complicación devastadora (0,03–0,1/1000 neuraxiales): la clave es el intervalo entre el último anticoagulante y la punción, y entre la punción y la siguiente dosis. Con punción traumática o sangre en la aguja: aplazar 24 h la siguiente dosis y vigilar el estado neurológico del paciente cada turno.",
            "Anticoagulantes clásicos" to "Heparina no fraccionada SC profiláctica (5000 U 2–3/día): sin retardo, punción ok; catéter ok. Heparina IV o dosis terapéuticas: esperar 4–6 h y APPT normal. HBPM profiláctica: punción 12 h tras la dosis; terapéutica (1 mg/kg/12 h o 1,5 mg/kg/día): 24 h. RETIRAR CATÉTER: 4–6 h tras la última dosis y reanudar no antes de 1 h después. Warfarina: INR normal (punción); catéter retirar con INR ≤1,5. Vigilar si se suman antiagregantes.",
            "Antiagregantes y nuevos orales" to "AAS y NSAID solos: no contraindican. Clopidogrel: 5–7 días de espera; ticagrelor 5–7 días; prasugrel 7–10 días; abciximab 24–48 h. DOAC: dabigatrán 72 h (48 h si ClCr alto y dosis profiláctica), rivaroxabán/apixabán/edoxabán 72 h para punción y para retirar catéter; reanudar 6 h tras punción/retiro. Fondaparinux: 36–42 h (evitar catéter). El sulfato de magnesio y el dextrán no contraindican.",
            "Trombolíticos y casos especiales" to "Trombolíticos/antifibrinolíticos: contraindicación absoluta para catéter (consultar). Paciente con neuroepitelio previo (estenoosis espinal, cirugía previa): mayor riesgo: valorar alternativa periférica. Embarazada con HBPM: en trabajo de parto documentar la última dosis y hora en la hoja: la pauta la decide el intervalo, no la indicación.",
            "Vigilancia del catéter" to "Mientras el catéter esté puesto y hasta 24 h tras retirarlo en pacientes anticoagulados: vigilar fuerza y sensibilidad de piernas, esfínteres y dolor dorsal nuevo. Ante un déficit que no coincide con el nivel del bloqueo esperado: RM urgente y descompresión <8 h: es la diferencia entre recuperar o no la marcha. Informar al equipo de planta del riesgo y del horario previsto de retirada."
        )
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Catéteres periféricos continuos",
        "Analgesia regional prolongada: técnicas y cuidados",
        "Bloqueo",
        listOf(
            "Indicación" to "Analgesia de 2–5 días: artroplastia mayor, cirugía oncológica de miembro, trauma con fracturas múltiples, síndrome doloroso complejo, amputación. Reducen la morfina de rescate, el delirio y permiten rehabilitación temprana. El catéter femoral/aductor es el más usado en rodilla; el interscalénico/supraclavicular en hombro; el ciático poplíteo en pie y tobillo.",
            "Técnica y fijación" to "Localizar el nervio con US y confirmar la difusión del volumen inicial; introducir el catéter 3–5 cm más allá de la punta de la aguja en el plano fascial correcto; fijar con apósito transparente + adhesivo en puente, marcar el punto de salida y etiquetar el catéter con el anestésico y la concentración. Confirmar con radiotransparencia o US si hay dudas de posición antes de la infusión continua.",
            "Infusión" to "Ropivacaína 0,2% o bupivacaína 0,125%: basal 4–8 mL/h (miembro superior 4–6; inferior 6–8) + bolos PCA de 5 mL con bloqueo de 30–60 min. La concentración alta (0,375–0,5%) solo en bolos, no en basal continua (riesgo de bloqueo motor y de dosis acumulada: vigilar máximo diario). Revisar la piel y el punto de inserción cada turno; el primer día el paciente debe poder mover los dedos con fuerza conservada: si hay bloqueo motor completo, reducir la velocidad o concentrar menos.",
            "Cuidados y retirada" to "Equipo de planta entrenado: qué observar (difusión del bloqueo, signos de infección, fugas), cuándo avisar al anestesiólogo (fiebre, dolor que se escapa, paresia no esperada). Retirada: quitar el apósito, tracción suave paralela a la trayectoria; comprobar la integridad de la punta; anotar la hora. Anticoagulados: los catéteres PERIFÉRICOS no exigen los intervalos de los neuraxiales (excepto en bloqueo profundo pectoral/paravertebral: tratar como profundo).",
            "Fallos frecuentes" to "Migración del catéter (el dolor reaparece a las horas: bolos de rescate + revisar con US), oclusión por coágulo (no aspirar con fuerza: intentar bolo suave o cambiar), desconexión accidental (rehacer el set con técnica estéril). Documentar cada día el nivel de bloqueo, la marcha y el dolor en escala 0–10: es la base para decidir retirar o continuar."
        )
    ),
    // ------------------------------------------------------------------
    ClinTopic(
        "Ecoguiado: principios de una punción segura",
        "Planos, aguja e hidrolocalización sin sorpresas",
        "Bloqueo",
        listOf(
            "Preparación" to "Sonda lineal de alta frecuencia para estructuras superficiales (plexo, muslo, pared abdominal); convexa para profundas (ciático subglúteo, neuraxial). Esterilidad: funda de sonda y gel estéril para catéteres y neuraxial; gel normal y antisepsia con clorhexidina para bloqueos simples. Preoxigenar no aplica: pero monitorizar (ASA estándar), acceso venoso y O2 nasal en sedados.",
            "Anatomía US y planos" to "Identificar siempre en este orden: estructura diana, vasos vecinos con Doppler (¡siempre!), pleura/peritoneo si están en el trayecto y punto de entrada de la aguja. Aguja IN-PLANE (se ve la trayectoria completa): preferir en casi todos los bloqueos fasciales y plexos; OUT-OF-PLANE solo con hidrolocalización continua y experience. La punta es lo que corta: si no ves la punta, no inyectes.",
            "Hidrolocalización e inyección segura" to "Alinear la aguja moviendo la SONDA, no la aguja. Bajar en pasos de 1 cm con 0,5–1 mL de D5W o anestésico: la expansión confirma dónde está la punta. Antes de inyectar la dosis real: aspirar (dos posiciones), inyectar 1 mL test y observar la difusión correcta; después inyectar en alícuotas de 5 mL con aspiración intermedia. Dolor creciente, resistencia alta o difusión anómala: retirar y reubicar.",
            "Errores que evitan incidentes" to "Sonda no perpendicular (el nervio se ve desplazado: corregir con inclinación), anisotropía (rotar la sonda para el brillo correcto del nervio), confundir tendón con nervio (cambiar el plano de corte: el tendón cambia con el movimiento), confiar en un solo plano. La visualización constante de la punta y la aspiración fraccionada evitan la mayoría de las inyecciones intravasculares e intraneurales.",
            "Dosis y documentación" to "Sumar SIEMPRE las dosis de los bloqueos combinados en la calculadora de anestésicos locales y anotar en la hoja: aguja, nivel, volumen, concentración, difusión, hora. Un registro claro es la mejor defensa ante una paresia transitoria y la base para aprender del propio caso."
        )
    )
)

// v2.4.0: bloqueos neuroaxiales ampliados (Neuraxial.kt) añadidos al final
val REGIONAL_BLOCKS_RAW = REGIONAL_BLOCKS_BASE + NEURAXIAL_TOPICS

// ---------------------------------------------------------------------
//  MONITORIZACIÓN (7 temas)
// ---------------------------------------------------------------------

val MONITORING_RAW = listOf(
    ClinTopic(
        "Monitorización estándar ASA",
        "El mínimo inexcusable en cada anestesia",
        "Monitorización",
        listOf(
            "Los cinco estándares" to "1) Oxímetro de pulso con alarma audible. 2) ECG continuo (derivación II + V5 para isquemia). 3) Presión arterial no invasiva cada 3–5 min. 4) Capnografía desde la inducción hasta el alta del quirófano (no solo al intubar). 5) Analizador de gases del circuito: FiO2 con alarma de bajo oxígeno, agente inspirado/espirado. Además: temperatura (obligatoria si se prevé cambio >30 min), volumen y presión ventilatoria, circuito con alarmas de desconexión.",
            "Accesos y vigilancia clínica" to "Vía intravenosa del calibre adecuado al sangrado esperado (20–22 G mínimo; 14–16 G si cirugía mayor). Vigilancia visual continua: color de la piel y mucosas, respiración del reservorio, sangrado en el campo, diuresis en cirugías largas. La monitorización NO sustituye la observación: el anestesiólogo está en la cabecera.",
            "Niveles añadidos según riesgo" to "PA invasiva (cirugía cardíaca, inestabilidad, comorbilidad mayor), PVC, gasto cardíaco, TEE, analgesia multimodal. Documentar cada 5–15 min: fármacos, eventos, signos. La excepción al estándar (urgencia extrema) debe documentarse en la hoja de anestesia.",
            "Antes de comenzar" to "Checklist de la máquina (calibración, absorbente, vaporizador, alarmas), desfibrilador disponible, drogas de emergencia preparadas (adrenalina, efedrina, fenilefrina, atropina, succinilcolina, lípidos), vía aérea de rescate y equipo de cricotiroidotomía accesibles, dantroleno identificado."
        )
    ),
    ClinTopic(
        "Capnografía",
        "La onda más informativa del quirófano",
        "Monitorización",
        listOf(
            "Valores normales" to "PETCO2 35–45 mmHg con onda rectangular de meseta clara. Gradiente arterial-espirado 2–5 mmHg (mayor en obesidad, hipotensión, embolia:↑ espacio muerto). El CO2 inspirado debe ser 0 (si sube: absorbente agotado, válvula expiratoria defectuosa o reinhalación).",
            "Formas de onda diagnósticas" to "\"Aleta de tiburón\" (pendiente descendente de la meseta): broncoespasmo, EPOC, obstrucción del tubo o del circuito. Caída brusca a cero: desconexión, embolia grande, paro. Escalones: fuga del manguito o del circuito (meseta bifida). Elevación progresiva: hipoventilación, absorción ↑ (febre, laparoscopia), absorbente saturado.",
            "Confirmación de la intubación" to "La onda capnográfica sostenida ≥3 ciclos es el mejor indicador de posición traqueal (más fiable que la auscultación). Un bolo de CO2 con esofágica (estómago) se agota en segundos: NO confundir con intubación correcta. En paro: el CO2 puede ser bajo y no descarta intubación correcta.",
            "En reanimación" to "EtCO2 ≥10 mmHg = compresiones eficaces; el que sube de golpe = RCE (retorno de circulación espontánea). EtCO2 <10 mmHg tras 20 min de RCP de calidad: pronóstico muy sombrío (revaluar en contexto). Usar el valor como retroalimentación de la calidad de las compresiones (fuente objetiva)."
        )
    ),
    ClinTopic(
        "Profundidad anestésica",
        "MAC, BIS y equilibrio hipnosis-analgesia",
        "Monitorización",
        listOf(
            "MAC (concentración alveolar mínima)" to "Previene movimiento al estímulo: 0,9–1,3 MAC para cirugía. Disminuye con opioides, B-bloqueantes, hipotermia (~7%/°C), embarazo, edad avanzada, hipotiroidismo; aumenta con consumo crónico de alcohol/cocaína. El MAC-despierto (0,3–0,5 MAC) marca el umbral de conciencia: tenerlo presente en parálisis neuromuscular.",
            "BIS y procesamiento EEG" to "Objetivo general 40–60 para hipnosis en anestesia general con parálisis. Riesgos fuera de rango: >60 en paciente relajado → riesgo de despertar intraoperatorio (recuerdo traumático); <40 sostenido → asociado a delirio y deterioro cognitivo postoperatorio en ancianos y a hipoperfusión. Bajos falsos con ketamina, dexmedetomidina, hipotermia profunda: no guiarse solo por el número.",
            "Otros monitores de profundidad" to "Entropía, índice Narcotrend, potencia espectral. Con propofol en TCI el efecto-site controla la hipnosis con concentración objetivo (2–4 µg/mL en el adulto sano). El despertar intraoperatorio es más probable con: parálisis + opioide alto + halogenado bajo + historia de abuso de alcohol/benzodiacepinas + cirugía obstétrica/trauma.",
            "Equilibrio hipnosis-analgesia" to "El dolor no aparece en el BIS: se manifiesta como taquicardia, hipertensión, sudoración, lagrimeo. Regla práctica: analgesia (opioides/bloqueos) para el estímulo, hipnosis para la conciencia, relajante solo cuando se necesita (TOF <2). El exceso de opioides para compensar hipnosis insuficiente causa bradicardia + hipotensión + depresión respiratoria al despertar."
        )
    ),
    ClinTopic(
        "Bloqueo neuromuscular (TOF)",
        "Monitorizar, dosificar y revertir con criterio",
        "Monitorización",
        listOf(
            "TOF (train of four)" to "4 estímulos a 2 Hz sobre el nervio cubital (aducción del pulgar) o facial. Ratio TOF = T4/T1: ≥0,9 requerido para una recuperación SEGURA (protectores de vía aérea y ventilación eficaces). Sin monitorizar se subestima el bloqueo residual: usar acelerómetro y CALIBRAR antes de bloquear (obtener 4/4 con el monitor activado).",
            "Interpretación" to "TOF 4/4 con ratio bajo = bloqueo ligero-moderado. 2–3 respuestas = bloqueo moderado (reversión con neostigmina posible). 0–1 = bloqueo profundo (reversión solo con sugammadex 4 mg/kg o esperar). Post-tetánico y PTC para bloqueo profundo. El fentanilo/propofol NO altera el TOF: confusión clásica con hipnosis insuficiente.",
            "Reversión" to "Sugammadex: 2 mg/kg si TOF ≥2 (recuperación ~3 min); 4 mg/kg si bloqueo profundo; 16 mg/kg para rescate tras rocuronio. Neostigmina 0,04–0,05 mg/kg con atropina/glicopirrolato: SOLO si TOF ≥3 (si no, recurre — recurarización) y recuperación más lenta (15–30 min). Extubar solo con TOF ≥0,9, elevación de cabeza, tos eficaz y patrón respiratorio estable.",
            "Bloqueo prolongado" to "Factores: hipotermia, acidosis respiratoria, hipopotasemia/hipermagnesemia, insuficiencia renal y hepática, miastenia, fármacos (aminoglucósidos, litio, B-bloqueantes). Rocuronio 0,6 mg/kg dura 45–60 min (con sugammadex de rescate); succinilcolina 6–10 min (repetir solo con TOF ≥3 y vigilancia: riesgo de bloqueo de fase II)."
        )
    ),
    ClinTopic(
        "Hemodinámica avanzada",
        "PA invasiva, gasto y fluidoterapia dirigida",
        "Monitorización",
        listOf(
            "PA invasiva" to "Indicaciones: cirugía mayor (cardíaca, torácica, vascular, hepática), inestabilidad, comorbilidad cardíaca/pulmonar, necesidad de gases seriados. Cero a nivel del aurículo derecho (4.º espacio intercostal medio). Onda: considerar el dicrotismo y la resonancia (manguito/tubo largo sobredimensionados amortiguan: subestima la presión sistólica).",
            "Gasto cardíaco y respuesta a volumen" to "Métodos: Doppler esofágico, análisis del pulso (PulseCO), TEE, termodilución. Objetivo: variación de la presión de pulso (PPV) <13% o del volumen sistólico (SVV) indica buena respuesta a volumen (condiciones: ventilación ≥8 mL/kg, ritmo sinusal, tórax cerrado). Fluido responsive ≠ necesidad de fluidos: correlacionar con el estado clínico y el sangrado.",
            "Fluidoterapia dirigida" to "Basal: cristaloides equilibrados 1–2 mL/kg/h. Déficit: corregir por ayuno y pérdidas. Tercer espacio en cirugía abierta mayor. Bolos de 250 mL con reevaluación (dinámico, no de rutina). Coloides en sangrado (preferir albúmina/viscoelásticos sobre HES). Transfusión: umbral Hb 7–8 g/dL (10 en isquemia activa); corregir coagulación con factores viscoelásticos guiados.",
            "Vasopresores e inotrópicos" to "Fenilefrina 0,25–1 µg/kg/min (↑ tono, ↓ FC — cuidado en bajo gasto). Noradrenalina 0,02–0,3 µg/kg/min (vasopresor de primera línea en sepsis e hipotensión refractaria). Efedrina 5–10 mg bolos (↑ FC y gasto: útil con bradicardia). Dobutamina 2–20 µg/kg/min (inotrópico; vasodilata). Adrenalina en dosis bajas 0,02–0,1 µg/kg/min para shock anafiláctico o bajo gasto severo. Vasopresina 0,03 U/min en catecolaminorresistencia."
        )
    ),
    ClinTopic(
        "Ecografía punto de cuidado (POCUS)",
        "FATE/FOCUS ante la hipotensión inexplicable",
        "Monitorización",
        listOf(
            "Protocolo de la hipotensión" to "4 ventanas rápidas: subxifoidea (4 cámaras), eje largo paraesternal, eje corto paraesternal y pleura/hepático (IVC). Pregunta: ¿hipovolemia, taponamiento, fallo derecho (embolia), fallo izquierdo, neumotórax? Menos de 5 min con un operador entrenado cambia la decisión clínica.",
            "Signos clave" to "Hipovolemia: VD pequeño y hiperdinámico, IVC <2 cm colapsable, ápex \"kissing\". Taponamiento: derrame pericárdico con colapso diastólico del VD y del AD. Embolia pulmonar: VD dilatado (relación VD/VI >1), tabique desviado, más el contexto clínico. Fallo VI: dilatación, hipocinesia global o regional. Neumotórax: ausencia de deslizamiento pleural + punto pulmonar + B-lines ausentes del lado afectado.",
            "Lung ultrasound" to "A-lines (normales/ventiladas), B-lines (edema intersticial: 3 o más por espacio = patología), consolidación (neumonía, atelectasia con broncograma aéreo), derrame. Útil en disnea postoperatoria para distinguir edema de atelectasia de derrame.",
            "Otros usos perioperatorios" to "Venas (acceso y catéteres: reducir complicaciones), estómago (contenido antes de una secuencia rápida en emergencias), nervios (bloqueos: ver sección Bloqueos), vía aérea (confirmar intubación con pleura bilateral). La curva de aprendizaje es corta para las 4 ventanas: es la habilidad de mayor impacto por hora de entrenamiento en anestesia."
        )
    ),
    ClinTopic(
        "Temperatura y normotermia",
        "Prevenir la hipotermia intraoperatoria",
        "Monitorización",
        listOf(
            "Por qué importa" to "La hipotermia (<36 °C) triplica las complicaciones: sangrado (alteración de la cascada), infección de herida, delirio, estancia prolongada, isquemia miocárdica. La anestesia general suprime la termorregulación: todos los pacientes se enfrían sin protección activa.",
            "Prevención activa" to "Precalentar 30 min antes de la inducción (manta de aire forzado en el preoperatorio). Temperatura del quirófano 21–23 °C hasta el drapeado. Manta de aire forzado en tórax/abdomen/miembros durante toda la cirugía. Fluidos: calentar TODO volumen >500 mL. Limitar exposición y lavados fríos. En laparoscopia: gas templado o flujo bajo.",
            "Medición" to "Esófago (intubado) y nasofaringe: centro. Vejiga en cirugías largas. Rectal alternativa. Axilar/pulso: no fiables para el núcleo. Registrar cada 15–30 min. Meta: mantener ≥36 °C hasta el alta del quirófano.",
            "Tembor postanestésico (shivering)" to "Tratamiento: calor activo + meperidina 12,5–25 mg IV (más eficaz que otros opioides) o clonidina 75–150 µg. CUIDADO: distinguir del temblor de la hipertermia maligna (rigidez + acidosis + hipercapnia → dantroleno, no meperidina). En el paciente con hipotermia grave (<34): recalentamiento lento y vigilado (arritmias)."
        )
    )
)

// ---------------------------------------------------------------------
//  PLAN PREOP (4 temas)
// ---------------------------------------------------------------------

val PREOP_TOPICS_RAW = listOf(
    ClinTopic(
        "Verificación de estudios preoperatorios",
        "Auditoría de validez, coherencia y pertinencia de las pruebas de otras especialidades",
        "Plan preop",
        listOf(
            "Validez temporal" to "Los estudios prequirúrgicos tienen vigencia limitada: como regla general, hasta 90 días si no ha habido cambio clínico significativo. La regla clínica manda: si el paciente cambió (nuevo síntoma, hospitalización, nueva medicación, cambio de peso o de condición funcional), se repite lo pertinente aunque el papel «no esté vencido». El ECG del día de la cirugía no es necesario en el sano asintomático de bajo riesgo; sí en el cardiovascular o cuando cambió algo. La auditoría es una obligación de seguridad: un estudio válido pero inadecuado para el riesgo real vale igual que uno vencido.",
            "Coherencia clínica" to "Los resultados deben leerse contra la historia y el examen físico, no en el vacío: un hallazgo incidental sin relevancia clínica no cambia el plan y no justifica estudios escalonados; un hallazgo incoherente con el examen obliga a repetir o a estudiar. Verifique que la prueba pedida sea la indicada para la pregunta (no pedir espirmetría cuando la pregunta es cardíaca, no pedir eco cuando la pregunta es funcional). Los estudios deben ser suficientes y suficientemente recientes para el riesgo del procedimiento.",
            "Cardiológicas (ECG y ecocardiograma)" to "ECG: busque lo que cambia el plan anestésico — bloqueo AV avanzado (considerar marcapasos antes de la cirugía), fibrilación auricular con respuesta rápida (controlar frecuencia antes), intervalo QT prolongado (evitar los fármacos que lo alargan, corregir K y Mg), isquemia nueva, hipertrofia con strain. Ecocardiograma: función ventricular sistólica (FE) y diastólica, gradiente valvular y áreas (estenosis aórtica severa cambia toda la estrategia de hemodinamia), válvula protésica y su anticoagulación. Compruebe que la indicación fue pertinente (no es cribado de rutina).",
            "Neumológicas (espirometría)" to "Revise VEF1, la relación VEF1/CVF y la respuesta broncodilatadora para valorar el riesgo de complicaciones pulmonares (ARISCAT de la app) y planificar la ventilación protectora. La indicación debe ser pertinente: cirugía torácica/abdominal alta con síntomas o deshabituación reciente, no «siempre». Un VEF1 muy bajo en cirugía de resección pulmonar obliga a cálculo de reserva (VPS). La espirometría no se pide de rutina en cirugía de bajo riesgo.",
            "De coagulación (TP/INR, TTPa)" to "Verificación crítica antes de técnicas neuraxiales (raqui/epidural) y en cirugía de alto riesgo hemorrágico: INR <1,5 y TTPa dentro del rango para puncionar o retirar catéter (cronograma ASRA completo en la pestaña Clínica → Bloqueos). Revise también el recuento de plaquetas y el contexto clínico (heparina previa: sospechar HIT). Un INR fuera de rango reprograma la cirugía o el plan de la técnica: no se improvisa.",
            "De laboratorio (hemograma y química)" to "Hemoglobina (anemia: causa y corrección antes de cirugía electiva; umbral transfusional en la calculadora de sangrado), plaquetas (trombocitopenia y neuraxial), creatinina (función renal: ajustar dosis con Cockcroft-Gault, evitar nefrotóxicos), electrolitos (K y Mg en pacientes con digoxina, diuréticos o arritmias), glucosa en diabéticos. El cribado amplio «porque sí» no mejora resultados: pida lo que la historia justifica.",
            "De imagen (radiografía de tórax)" to "La indicación debe ser pertinente: enfermedad cardíaca o pulmonar conocida, edad avanzada con síntomas, trauma o cirugía torácica. Revise lo que altera el manejo: cardiomegalia, edema pulmonar, derrame, neumopatía activa, desviaciones. Un hallazgo nuevo significativo se estudia ANTES de la cirugía electiva, no el día de.",
            "Cadena de información" to "Asegúrese de que TODOS los resultados de las pruebas solicitadas por otros especialistas (cirujano, cardiólogo, internista) hayan llegado a su conocimiento y que las conclusiones de las interconsultas estén claras e integradas en el plan perioperatorio. Un cardiólogo que recomendó optimización y un expediente sin esa nota es un accidente esperándonos: verifique la hoja de interconsulta, anote las conclusiones en la valoración preanestésica y documente cualquier discrepancia con el plan de la cirugía."
        )
    ),
    ClinTopic(
        "Evaluación preoperatoria estructurada",
        "Historia, vía aérea, estudios y optimización",
        "Plan preop",
        listOf(
            "Historia dirigida" to "Síntomas actuales; ALERGIAS (látex, antibióticos, AINE, contrastes) con tipo de reacción; medicación actual (ver Plan preop → Suspensión); antecedentes: cardíacos, respiratorios, renales, hepáticos, endocrinos, neuromusculares, VÍA AÉREA DIFÍCIL previa, HIPERTERMIA MALIGNA o muerte anestésica familiar, reacción anafiláctica previa; última comida y líquidos; tabaco y alcohol; embarazo posible (prueba en mujeres fértiles si procede); acceso venoso previo.",
            "Examen físico y vía aérea" to "Signos vitales basal y SpO2 en aire ambiente; auscultación cardiorrespiratoria; vía aérea: Mallampati (III–IV = riesgo), distancia tiromentoniana (<6 cm), apertura bucal (<3 cm), protrusión mandibular, barba, radioterapia de cuello, dentadura; screening de OSA (STOP-BANG ≥3); valoración ASA física (1–6) y estado funcional (MET).",
            "Estudios preoperatorios" to "Sin baterías de rutina: guiar por edad, comorbilidad y cirugía. Hb si sangrado esperado o anemia sospechada; creatinina y electrolitos si >60 años, HTA, diabetes, diuréticos o ERC; coagulación solo si antecedente de sangrado o anticoagulante; ECG si RCRI ≥2, edad >50–65 con riesgo, síntomas cardiovasculares; RxT si cardiopatía o EPOC grave; prueba de embarazo si procede; HbA1c en diabetes.",
            "Optimización" to "Dejar de fumar ≥4 semanas (aunque 24 h reduce COHb); alcohol: abstención y profilaxis de delirium; anemia: hierro/agentes estimulantes si hay tiempo; glucemia 140–180 mg/dL; HTA controlada (<160/100 electiva); IC euvolémica y compensada; asma sin sibilancias; CPAP si OSA; infecciones dentales o urinarias tratadas; consentimiento informado con riesgos específicos (anafilaxia, LAST, VAD, MTEV) y educación del paciente."
        )
    ),
    ClinTopic(
        "Suspensión y ajuste de fármacos",
        "Qué continúa, qué se suspende y cuándo",
        "Plan preop",
        listOf(
            "Antiagregantes y anticoagulantes orales directos (ACOD)" to "AAS: CONTINUAR si stent coronario o indicación fuerte; suspender 5–7 días en cirugía de alto sangrado sin stent. Clopidogrel: 5–7 días; prasugrel: 7 días; ticagrelor: 3–5 días (siempre con cardiólogo si stent <6–12 meses). Apixabán/rivaroxabán: 24 h (procedimiento menor), 48 h (moderado), 72 h (alto riesgo o ClCr <30). Dabigatrán: 24–72 h según CrCl. Reanudar 24 h postop si hay hemostasia; no usar heparina profiláctica terapéutica como puente en ACOD salvo riesgo trombótico extremo.",
            "Warfarina y puente" to "Suspender 5 días antes; INR <1,5 para cirugía mayor. Puente con enoxaparina/heparina de bajo peso molecular si riesgo trombótico muy alto: válvula mecánica, TEV <3 meses, accidente embólico reciente, trombofilia grave. Última dosis 24 h antes de la cirugía; reanudar la noche del postoperatorio si hay hemostasia.",
            "Cardiovasculares" to "IECA/ARA-II: OMITIR 24 h antes (hipotensión refractaria — si ocurre: vasopresina/noradrenalina, no solo volumen). B-bloqueantes: CONTINUAR (nunca iniciar de novo el día de la cirugía). Estatinas: continuar. Diuréticos: omitir si ayuno o sangrado previsto. Espironolactona: omitir (hiperpotasemia). Amiodarona: continuar. Digoxina: continuar con control de K y niveles.",
            "Diabetes y otros" to "Ver Clínica → Diabetes para el detalle (metformina día de, SGLT2i 3 días, insulina basal −20–25%). Corticoides crónicos (>5 mg/día de prednisolona ≥3 semanas): dosis de ESTRÉS hidrocortisona 50–100 mg IV cada 8 h. AINEs: 2–3 días (ketorolaco 1 día); COX-2 puede continuar. ISRS: continuar con vigilancia de sangrado; IMAO: 2 semanas idealmente (o plan de anestesia sin efedrina). Litio: 24–48 h. Anticonvulsivantes, antiparkinsonianos, levotiroxina: continuar. Anticonceptivos/THS: 4 semanas antes en cirugía de alto riesgo TEV. Tamoxifeno: 3–4 semanas. Bevacizumab: 6 semanas. Tocilizumab: 1–2 semanas.",
            "Fitoterapia y complementos" to "Suspender 7 días antes: ginkgo, ajo en cápsulas, ginseng (sangrado); efedra (arritmias); kava y valeriana (potencian sedación). No hay que suspender: multivitamínicos, calcio, probióticos. Registrar en la historia qué se suspendió y cuándo, para reanudar después."
        )
    ),
    ClinTopic(
        "Ayuno y profilaxis preoperatoria",
        "2-4-6-8, antibiótico, antiemético y MTEV",
        "Plan preop",
        listOf(
            "Ayuno (regla 2-4-6-8)" to "Líquidos claros (agua, café sin leche, jugo sin pulpa): 2 h. Leche materna: 4 h. Leche de fórmula, comida ligera (tostada, jugo con pulpa): 6 h. Comida pesada, frita o grasa, carnes: 8 h. Medicação del día: tomar con un sorbo de agua (≤50 mL) salvo las suspensiones de la tabla de fármacos. Chicles y caramelos: tratarlos como sólidos (6 h) por secreciones y riesgo de aspiración. Calcular con Calculadoras → Ayuno.",
            "Profilaxis antibiótica" to "Cefazolina 2 g IV en los 30–60 min previos a la incisión (3 g si >120 kg); redosis si cirugía >4 h o sangrado >1500 mL. Alergia a β-lactámicos: clindamicina 600 mg + gentamicina 5 mg/kg (o aztreonam/vancomicina según protocolo). Colorectal: añadir metronidazol. Prótesis articular e infección activa: coordinar con el equipo quirúrgico.",
            "Profilaxis antiemética" to "Estratificar por factores de riesgo Apfel (mujer, no fumador, historia de mareo/cinemosis, opioides postop): 0–1 factores = 1 fármaco; ≥2 = 2–3 fármacos de clases distintas. Primera línea: ondansetrón 4 mg IV + dexametasona 8 mg (al inicio); añadir droperidol 0,625 mg o escopolamina transdérmica la noche anterior. Rescate: cambiar de clase, NO repetir la misma; aprepitant 40 mg en alto riesgo. Profilaxis también reduce la estancia y el dolor.",
            "Tromboembolismo venoso (MTEV)" to "Estratificar (Caprini/Padua): alta = heparina de bajo peso molecular (enoxaparina 40 mg SC) + medias de compresión gradiente + compresión neumática intermitente desde el ingreso. Coordinar tiempos con la anestesia neuraxial (ver Epidural: 12 h profiláctica antes de punción/catéter; ACOD según ClCr y riesgo). Movilización precoz desde el postoperatorio inmediato: la medida más eficaz y barata.",
            "Preparación del paciente" to "Baño con jabón antiséptico la noche anterior; retirar prótesis dentales removibles, lentillas, joyas, piercing, esmalte de uñas (SpO2) y maquillaje; micción preoperatoria; ropa quirúrgica; identificar alergias con brazalete; asegurar acompañante y transporte al alta."
        )
    ),
    ClinTopic(
        "Checklist del día de la cirugía",
        "De la llegada del paciente al inicio de la anestesia",
        "Plan preop",
        listOf(
            "Verificación con el paciente" to "Identidad (nombre completo + fecha de nacimiento), procedimiento y LATERALIDAD (marca quirúrgica visible), consentimiento informado firmado, ayuno verificado con hora de la última ingesta, alergias confirmadas en voz alta, dentadura/lentillas/joyas/piercing retirados, micción reciente, embarazo posible descartado.",
            "Documentación y estudios" to "Historia completa, evaluación preanestésica, resultados de laboratorio/imágenes disponibles, plan de anestesia escrito, medicación del día tomada u omitida (¡verificar!), puerto/cánulas previas, órdenes de suspensión ejecutadas (anticoagulantes, IECA).",
            "Accesos y monitorización" to "Vía IV permeable del calibre adecuado; monitores conectados y valores BASALES registrados (PA, FC, SpO2, temperatura); monitorización añadida según plan (invasiva, TOF, BIS) calibrada ANTES de inducir.",
            "Preparación del equipo" to "Máquina de anestesia revisada (checklist del fabricante), vía aérea: laringoscopios con luz, tubos 2 tamaños + estilete, SGA, fibroscopio si riesgo, equipo de cricotiroidotomía ACCESIBLE; drogas: adrenalina, efedrina, fenilefrina, atropina, succinilcolina, lípidos 20% (LAST), dantroleno UBICADO; desfibrilador en el quirófano; succión y bolsa-ambo funcionando; calentador de fluidos si se prevé volumen.",
            "Justo antes de inducir" to "Antibiótico profiláctico administrado (30–60 min antes de la incisión), antiemético si indicado, sedación preoperatoria titulada, O2 100% preoxigenación 3–5 min (o CPAP en obesos), posición segura del paciente y presión de puntos, papel de la sala confirmado: cirujano, instrumentista, anestesista, enfermería — y \"time out\" del equipo quirúrgico completado."
        )
    )
)

// ---------------------------------------------------------------------
//  EQUIPAMIENTO (v2.1.0) — bombas de infusión, jeringas perfusoras y TCI
// ---------------------------------------------------------------------

val EQUIPMENT_TOPICS_RAW = listOf(
    ClinTopic(
        "Jeringas perfusoras",
        "Reglas prácticas de uso seguro de la jeringa en bomba de infusión",
        "Equipamiento",
        listOf(
            "Qué es y cuándo usarla" to "La jeringa perfusora (bomba de jeringa) empuja una jeringa de 20–50 mL con precisión de décimas de mL/h: es el equipo de elección para fármacos potentes en dosis pequeñas (noradrenalina, adrenalina, remifentanilo, dexmedetomidina, propofol, cisatracurio) en adulto y para casi todo en pediátrico y neonatal. La bomba volumétrica (derolling) es para volúmenes mayores (cristaloides, alimentación, sangre). Regla simple: si un error del 10 % del ritmo cambia la situación clínica, use jeringa perfusora; si el fármaco viaja diluido en 500 mL, bomba volumétrica.",
            "Preparación correcta" to "Etiquete SIEMPRE la jeringa con: fármaco, concentración final (µg/mL o mg/mL), diluyente, fecha/hora y velocidad. Use vías dedicadas cuando sea posible (o llave de tres pasos antirreflujo/valvulilla en cada rama) y rellene el espacio muerto de la vía con el fármaco a velocidad de purga antes de conectar. Prefiera diluciones estándar del servicio (evita errores de cálculo en los cambios de turno). Verifique la concentración programada en la bomba contra la etiqueta con doble chequeo. En fármacos lipídicos (propofol) cambie jeringa y vía cada 6–12 h (crecimiento bacteriano); en otros, según estabilidad documentada.",
            "Cambio de jeringa sin bolo accidental" to "El peligro clásico: al cambiar la jeringa, la bomba reanuda el empuje y libera el contenido del espacio muerto acumulado durante la oclusión (hasta 1–2 mL) = bolo inadvertido. Reglas: prepare la jeringa siguiente ANTES de que termine, cambie rápido (menos de 60 s) minimizando el tiempo de oclusión, reinicie la purga manual o use bombas con función de cambio automático, y tras reiniciar vigile PA/FC/respuesta 10–15 min. En vasopresores de pacientes frágiles, administre el cambio justo después de comprobar estabilidad y tenga el fármaco de rescate preparado.",
            "Alarmas de oclusión y retroceso" to "La oclusión aguas abajo (vía pellada, catéter obstruido, brazo flexionado) hace que la bomba acumule presión y se detenga con alarma: el tiempo hasta la alarma depende del límite de presión programado (bajo/medio/alto) — límites más altos = más retraso y más volumen de bolo al liberarse. NUNCA silencie la alarma de oclusión sin revisar toda la línea (desde la jeringa hasta el catéter). Al reanudar tras corregir la causa, espere el bolo de descarga o purgue manualmente. La oclusión aguas arriba (jeringa vacía, émbolo desenganchado) también dispara alarma: revisar el nivel real del émbolo, no confiar solo en el volumen restante mostrado.",
            "Errores frecuentes" to "Programar la concentración en la bomba distinta de la preparada (el error más grave: elegir la opción de calcular dosis sin verificar la concentración real). Confundir mL/h con mg/h o µg/kg/min. Conectar el propofol a la vía del vasopresor por una Y sin valvulilla (el fármaco refluye hacia la jeringa vecina: efecto rebote al reanudar). Dejar la vía del vasopresor sin purgar tras el cambio de jeringa (hipotensión súbita). Usar la misma vía para bolo de inducción y para perfusión sin purga. Asumir que «la bomba anda» sin ver girar el indicador de émbolo al inicio.",
            "Elastoméricas y PCA (mención)" to "Las bombas elastoméricas (bolsa de presión constante) se usan para analgesia regional ambulatoria (bloqueo de nervio periférico 0,2 % ropivacaína a 5–10 mL/h) y antibióticos domiciliarios: sin pilas, flujo aproximado (±10 %), sensible a la temperatura y a la altura de colocación. Las bombas PCA (analgesia controlada por el paciente) combinan demanda con bloqueo: morphine 1–2 mg/dosis, lockout 5–10 min, dosis basal solo en pacientes dependientes de opioides."
        )
    ),
    ClinTopic(
        "Bombas de infusión y TCI",
        "Volumétricas, de jeringa y diana controlada: tipos, modelos y seguridad",
        "Equipamiento",
        listOf(
            "Tipos de bomba y su nicho" to "Bomba volumétrica: 0,1–999 mL/h para volúmenes grandes (hidratación, sangre, nutrición, antibióticos) con sensor de aire y presión. Bomba de jeringa: precisión alta a bajos ritmos (0,1–300 mL/h) para fármacos potentes. Bomba TCI (diana controlada): jeringa de alta precisión con software de modelos farmacocinéticos que ajusta la velocidad sola para alcanzar y mantener una concentración deseada (propofol Marsh/Schnider, remifentanilo Minto). PCA: analgesia controlada por el paciente. Elastomérica: flujo fijo sin energía para ambulatorio.",
            "Cómo funciona una TCI" to "El anestesiólogo programa el modelo y una DIANA: de concentración plasmática (Cp) o de sitio efecto (Ce, biopaase con ke0). La bomba resuelve el esquema BET (Bolus-Elimination-Transfer): bolo inicial = diana×V1 para llenar el compartimento central, luego una velocidad que decae exponencialmente que cubre la eliminación (k10) y la transferencia a los compartimentos periféricos (k12, k13), recalculándose cada 10 s. La diana de efecto evita el overshoot plasmático: Cp puede superar la Ce objetivo brevemente para acelerar la inducción. Marsh usa solo el peso; Schnider añade edad (pacientes mayores: Acl1 menor); Minto usa edad y masa magra (LBM).",
            "TCI sin bomba TCI (jeringa manual)" to "Con una jeringa perfusora común se puede imitar la TCI con el esquema BET: bolo inicial + velocidad de inicio + reducciones programadas (la velocidad cae ~50 % en la primera media hora, luego se estabiliza hacia el valor de mantenimiento = diana×V1×k10 en unidades de masa/tiempo). La calculadora «Bomba TCI» de esta app genera la tabla completa de velocidades para propofol y remifentanilo. Ventajas frente a la infusión fija: menos hipotensión inicial, menos despertar intraoperatorio, recuperación más predecible. Límites: exige disciplina en los cambios de jeringa y no corrige variabilidad farmacogenética: titule con RASS/BIS y signos clínicos.",
            "Seguridad y doble chequeo" to "Antes de iniciar: verifique fármaco, concentración final, diluyente, vía, y la configuración de la bomba (concentración programada, unidades, límite de presión). Doble chequeo independiente en vasopresores, insulina, heparina, opioides y relajantes. Etiquete TODAS las líneas en el punto de conexión con el catéter. En bombas volumétricas, active el sensor de aire y ajuste la presión de oclusión al contexto (baja en neonatal y vías frágiles). Nunca conecte relajantes a vías de infusión rápida ni a la vía del bolo de rescate.",
            "Interacciones con la vía y espacio muerto" to "El espacio muerto de la vía (llaves, extensor, catéter) retiene fármaco: tras un bolo en la misma vía de la perfusión, parte del bolo queda atrapado y se libera al reanudar el flujo (efecto retardado o bolo doble). Reglas: bolos por vía dedicada o purgar después del bolo; en paros, la vía del vasopresor admite bolos de adrenalina solo si se sigue de flush rápido. Considere el volumen muerto al calcular el tiempo de llegada del fármaco (vías largas de 100 cm ≈ 1–2 mL).",
            "Fallas y respuestas" to "Sin bomba disponible: use goteo gravitacional con microgoteo (60 gotas/mL) para fármacos menos críticos y calcule gotas/min; para vasopresores improvisados valide la concentración con otra persona. Alarma de aire: detenga, purgue la línea, revise el reservorio. Batería agotada: conecte a red y reprogramue (anote velocidad y volumen infundido). Bomba golpeada o caída: revise el mecanismo de émbolo antes de confiar. Toda falla de bomba que pudo causar daño se documenta y reporta al servicio de equipamiento médico."
        )
    )
)
