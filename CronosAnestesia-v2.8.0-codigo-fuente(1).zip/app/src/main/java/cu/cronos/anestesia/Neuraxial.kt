package cu.cronos.anestesia

// =====================================================================
//  BLOQUEOS NEUROAXIALES AMPLIADOS (v2.4.0 — contrato §5.2)
//  Raquídea, epidural, combinada espinal-epidural, caudal y anatomía
//  neuroaxial aplicada, con esquemas vectoriales de la aplicación
//  (artId → Arte.kt). Complementan los 16 bloqueos existentes.
//  Dosis de referencia en adulto sano: ajustar por edad, talla, embarazo
//  y estado hemodinámico; vigilar anticoagulación (ASRA) siempre.
// =====================================================================

val NEURAXIAL_TOPICS = listOf(
    ClinTopic(
        "Anestesia raquídea (espinal)",
        "Puntura subaracnoidea: anatomía, técnica y dosis de referencia",
        "Bloqueos",
        listOf(
            "Anatomía puntual" to "La aguja atraviesa: piel, tejido subcutáneo, ligamento supraspinoso, interespinoso, amarillo (resistencia brusca), espacio epidural, dura-aracnoides (pérdida de resistencia + LCR) y llega al saco dural. El cono medular termina en L1 (adulto) y L3 (recién nacido): la puntuación segura es L3-L4 o más caudal, identificada por la línea intercristal (Tuffier) que cae en L4 o en el espacio L4-L5 — con desviaciones frecuentes: contar vértebras con la ecografía si hay duda, obesidad o escoliosis.",
            "Técnica" to "Posición sentado con apoyo o lateral estricta (flexionar: «nariz a las rodillas»); asepsia amplia (clorhexidina 2 %, que SEQUE antes de puntuar: la clorhexidina en el LCR es neurotóxica). Vía media con aguja fina de punta lápiz (25–27 G Whitacre/Sprotte) introducida en el hueco interespinoso con 10–15° cefales: LOR progresivo y «pop» del ligamento amarillo; confirmar LCR libre (aspiración suave; la punción de un vaso no refluye LCR claro). Vía paramediana (lateral al supraspinoso 1 cm, dirigida 15° media y cefalada) en escoliosis, calcificación o hernia discal.",
            "Dosis de referencia (adulto 60–80 kg)" to "Bupivacaína hiperbárica 0,5 %: 12–15 mg (2,4–3 mL) para cirugía de abdomen inferior y miembros; 8–10 mg para perineal. Bupivacaína isobárica 0,5 %: 12–18 mg según altura deseada. Levobupivacaína: dosis similar a bupivacaína. Ropivacaína isobárica 0,5–0,75 %: 15–25 mg. Lidocaína 5 % hiperbárica: 60–80 mg SOLO para procedimientos < 90 min (la 5 % continua se retiró: cauda equina). Mepivacaína 2 % isobárica: 40–60 mg. Adyuvantes: morfina 0,1–0,2 mg (analgesia prolongada: vigilar depresión respiratoria 12–24 h), fentanilo 10–25 µg, clonidina 15–30 µg.",
            "Nivel de bloqueo esperable" to "Con la dosis indicada y paciente sentado-bajado rápido: T6–T10 para abdomen inferior (cesárea: T4–T6), L1–T10 para miembros inferiores. Fijar el nivel barriendo con alcohol/frío: la altura depende de la dosis (principal), la baricidad y la posición en los primeros 10–15 min. El hipobárico/isobárico en decúbito lateral fija del lado operado; la tabla de «altura por mL» no existe: se titula con dosis y posición.",
            "Hipotensión y bradicardia" to "El bloqueo simpático (T1–L2) produce vasodilatación y una caída de la PAM proporcional a la altura del bloqueo; en obstetricia es casi universal: prevenir con fenilefrina en infusión profiláctica (0,25–0,5 µg/kg/min) o bolos titulados, inclinación lateral izquierda y volumen solo si hay hipovolemia (la precarga pasiva ya no se recomienda). La bradicardia severa (reflejo de Bezold-Jarisch con bajo retorno) es la señal de alarma del bloqueo alto: atropina, efedrina, elevar piernas y, si cae a paro, RCP con epinefrina inmediata y pensar en el rescate con lípidos solo si hay LAST.",
            "Complicaciones y seguimiento" to "Cefalea postpunción (pérdida de LCR por aguja cortante o grande): postural, tratar conservadora 24–48 h, tazas de cafeína o blood patch epidural si es incapacitante. Hematoma epidural (vigilar anticoagulación según ASRA: retorno del bloqueo o dolor lumbar insoportable = RM urgente < 8 h). Retención urinaria, prurito (opioides), bloqueo alto o total espinal (hipotensión profunda + apnea: oxígeno, intubar, vasopresores — soporte hasta que el bloqueo caiga). Infección: asepsia estricta, revisar el sitio al alta."
        ),
        artId = "columna_sagital"
    ),
    ClinTopic(
        "Epidural lumbar y torácica",
        "Pérdida de resistencia, catéter y dosificación fraccionada",
        "Bloqueos",
        listOf(
            "El espacio epidural" to "Triángulo de grasa, tejido conectivo, plexo venoso de Batson y raíces, del ligamento amarillo a la dura. Profundidad lumbar 4–6 cm (torácica 3–5, más cerca de la dura). El plexo venoso se llena con la Valsalva y el embarazo: la punción venosa es más fácil en cesárea — por eso la dosis de prueba y el aspirado repetido son obligatorios.",
            "Técnica de pérdida de resistencia" to "Aguja Tuohy 16–18 G con bisel cefalado. Identificar el ligamento amarillo con LOR: salino 2–3 mL en el émbolo (el aire tiene riesgo teórico de embolia y de bloqueo parcheado; el salino se mezcla con la anestesia local). Resistencia brusca que cede = epidural; confirmar con aspiración (sangre/LCR = reposicionar) y catéter 4–5 cm (más profundidad aumenta el catéter venoso y el pasaje a la dura). Test de dosis: 3 mL de lidocaína 1,5–2 % con epinefrina 1:200 000 (o 3 mL de la concentración de trabajo en obstetricia): taquicardia/buzz = intravenoso; bloqueo motor rápido/profundo = subaracnoideo: no seguir administrando y tratar como espinal total.",
            "Dosis de referencia" to "Epidural lumbar quirúrgica: bupivacaína/levobupivacaína 0,5 %, 8–12 mL en 3–4 dosis fraccionadas de 3–4 mL (nivel T6–T10 en 15–20 min); ropivacaína 0,5–0,75 %: 15–25 mL. Torácica (T5–T8, cirugía abdominal alta/torácica): 3–5 mL por segmento fraccionado, dosis total 6–10 mL. Peridural obstétrica de analgesia: ropivacaína 0,1–0,2 % + sufentanilo 0,3–0,5 µg/mL en infusión 8–12 mL/h o bolos programados; la cesárea de urgencia «sube» con lidocaína 2 % alcalinizada con bicarbonato (o cloroprocaina 3 % si está disponible). En el embarazo la dosis cae 25–30 %.",
            "Ventajas vs. espinal y manejo intraoperatorio" to "Titulable y prolongable (catéter): cirugías largas, analgesia postoperatoria (catéter torácico: el estándar de la analgesia de toracotomía y laparotomía mayor), menor hipotensión abrupta. Contras: instauración más lenta, riesgo de bloqueo unilateral/asimétrico (reposicionar el catéter 1–2 cm y lateralizar), fallo (5–10 %): tener plan B (espinal, general) escrito. Hipotensión: igual mecanismo que la espinal pero más gradual; el prurito y la retención urinaria dependen del opioide añadido.",
            "Cuidados y retirada del catéter" to "Retirar con la anticoagulación fuera de la ventana ASRA (misma regla que para puncionar); registrar el tiempo. Monitorizar el retorno del bloqueo y la fuerza: el catéter puede seguir en el espacio epidural horas después de la última dosis. Infección del sitio (revisar c/24 h), catéter cortado al retirar (no traccionar a la fuerza: neurocirugía si queda tramo), y el hematoma espontáneo del paciente anticoagulado: dolor lumbar + déficit progresivo = RM urgente."
        ),
        artId = "espacio_epidural"
    ),
    ClinTopic(
        "Combinada espinal-epidural (CSE)",
        "Aguja por aguja: lo rápido de la espinal con lo titulable de la epidural",
        "Bloqueos",
        listOf(
            "Indicaciones" to "Trabajo de parto con posibilidad de cesárea (la espinal da analgesia inmediata, la epidural la prolonga y «sube» para la operación), cirugía ortopédica prolongada de miembros inferiores, cesárea en paciente con riesgo de duración incierta. También como «rescate»: la epidural permite retirar el bloqueo a demanda cuando la espinal se queda corta a los 90–120 min.",
            "Técnica aguja-por-aguja" to "Tuohy en el espacio epidural (L2-L3 o caudal), localizar el epidural por LOR; introducir por dentro la aguja espinal fina (25–27 G lápiz) 1 cm más allá de la punta del Tuohy, confirmar LCR, inyectar la dosis espinal (p. ej. bupivacaína hiperbárica 10–12 mg + fentanilo 15 µg para parto), retirar la espinal y pasar el catéter epidural 4–5 cm. Probar SIEMPRE el catéter con dosis de prueba y aspirado: la CSE no lo exime de los errores de vía.",
            "Ventajas y riesgos propios" to "Ventajas: inicio de 3–5 min, menor dosis espinal (la epidural retoma el bloqueo cuando la espinal termina), el catéter ya está instalado si hay que convertir. Riesgos adicionales: la espinal puede no tocar LCR a través del Tuohy no centrado (fallo de la mitad de la técnica), el catéter puede migrar al hueco dejado por la espinal (dosis espinal inadvertida: alto riesgo de espinal total si se dosifica como epidural), y la «copa espinal tardía» (la epidural no arranca porque la espinal estaba mala): protocolo de rescate con lidocaína 2 % fraccionada.",
            "Dosis típica en obstetricia" to "Espinal: bupivacaína 2,5–3,75 mg (0,25 % de la dosis quirúrgica) + sufentanilo 2,5–5 µg o fentanilo 15–25 µg: analgesia 60–90 min. Luego epidural de mantenimiento: ropivacaína 0,1 % + sufentanilo 0,3 µg/mL a 8–12 mL/h (o bolos programados). Para cesárea urgente desde la epidural de parto: subir con lidocaína 2 % con epinefrina + bicarbonato 1 mEq/10 mL, 3–5 mL fraccionados cada 2–3 min hasta T4–T6, con vasopresor profiláctico.",
            "Fallo de la CSE: qué hacer" to "Si la espinal no dio LCR: repetir el intento con la espinal por el mismo Tuohy (1–2 veces) o pasar a espinal sola a otro espacio. Si el catéter no funciona: retirar a la profundidad teórica del hueco (el catéter puede haber salido por el orificio de la espinal) o reinsertar. Si hay analgesia espinal perfecta pero el catéter luego no «muerde»: reponer por el catéter con dosis de prueba e interpretar (el bloqueo residual de la espinal enmascara un catéter intravenoso o subaracnoideo: dosis de prueba obligatoria y fraccionada SIEMPRE)."
        ),
        artId = "columna_sagital"
    ),
    ClinTopic(
        "Bloqueo caudal",
        "Acceso epidural sacro: el clásico de la pediatría y la lumbociática",
        "Bloqueos",
        listOf(
            "Anatomía e indicaciones" to "El hiato sacro (ausencia de láminas y apófisis espinosa de S4–S5) está entre los cuernos sacrococcígeos, cubierto por el ligamento sacrococcígeo posterior. Indicaciones: analgesia postoperatoria pediátrica (hernia, orquidopexia, cirugía urológica baja), lumbociática aguda (infiltración), analgesia del primer período del parto cuando no hay otro acceso, cirugía perineal del adulto. El hiato se palpa con el paciente en decúbito lateral flexionado (o prono con cojín en la pelvis).",
            "Técnica" to "Aguja corta biselada (22–23 G, 2,5–3,5 cm; pediátrico 22 G) a 45° sobre el ligamento, con «pop» característico; avanzar 1–2 cm aplanando el ángulo (nunca > 2–3 cm en el adulto: el saco dural llega a S2–S3 en el adulto y hasta S4 en el recién nacido). Aspirar (sangre = vena sacra; LCR = demasiado alto: retirar). Inyectar con presión suave; la resistencia o el edema subcutáneo indican extravasación. Ecografía: ayuda a medir la profundidad y confirmar la difusión.",
            "Dosis de referencia" to "Pediátrico (bupivacaína 0,25 % o ropivacaína 0,2 %, con adyuvante opioide según edad y supervisión): lumbosacro (cirugía inguinal): 0,7–1 mL/kg; torácico bajo (cirugía umbilical): 1–1,2 mL/kg; máximo 1,5–2 mg/kg de bupivacaína total (dosis máxima por peso, no por volumen). Adulto analgésico: 15–25 mL de bupivacaína 0,25 % o ropivacaína 0,2 %; infiltración esteroidea de la lumbociática: 8–15 mL con corticoide según protocolo institucional.",
            "Ventajas y riesgos" to "Ventajas: fuera del canal a nivel lumbar (no punciona la dura en la zona del cono), técnica fácil en pediatría, buen bloqueo sacro (la epidural lumbar clásico lo cubre mal). Riesgos: punción del saco dural (posición alta o avance excesivo), inyección intravenosa (el plexo venoso sacro: dosis de prueba y aspirado), infección (asepsia: la zona está cerca del ano), retención urinaria y debilidad de piernas transitoria en el pediátrico (vigilar el apoyo y el sondaje: avisar a enfermería).",
            "Errores frecuentes" to "Confundir el hiato con el cóccix (buscar los cuernos, no la punta); «pop» ausente en el obeso (usar la ecografía o la vía epidural lumbar); volumen insuficiente para el nivel deseado (la tabla clásica de Armitage es orientativa); olvidar que el caudal NO cubre el dolor visceral (la analgesia multimodal sigue). En el adulto con cirugía mayor abdominal, el caudal no sustituye al catéter epidural torácico."
        ),
        artId = "espacio_epidural"
    ),
    ClinTopic(
        "Anatomía neuroaxial aplicada",
        "Niveles, ligamentos y dermatomas: el mapa mental de la punción",
        "Bloqueos",
        listOf(
            "Columna y niveles clave" to "7 cervicales, 12 torácicas, 5 lumbares, 5 sacras fusionadas. Referencias de punción: línea intercristal (Tuffier) ≈ L4 o L4-L5; ángulo de la escápula ≈ T7; fosa supraesternal ≈ T2; apéndice xifoides ≈ T9-T10. El cono medular: L1 adulto, L3 recién nacido/lactante (por eso en pediatría la punción lumbar es caudal y con más cuidado). El canal crece de cefálico a caudal y se estrecha de nuevo en el sacro.",
            "Ligamentos de la vía media" to "Supraspinoso (externo, elástico), interespinoso (fibroso, resistente), amarillo (el «grosor» que cede con pop; 5–10 mm de espesor lumbar y hasta 15 en el punto medio). En el anciano calcifican (aguja con resistencia y «crunch»: vía paramediana); en la escoliosis y las cifosis la línea media se desplaza: ecografía pre-punción (transversal para la línea media, paramediana oblicua para la profundidad y el ángulo).",
            "Dermatomas que hay que saber de memoria" to "C4: hombros/mangas; T4: pezón (cesárea: objetivo T4–T6); T6: xifoides; T8: reborde costal (colecistectomía, cirugía gástrica); T10: ombligo (apendicectomía, hernia); L1: ingle (hernia inguinal); S2-S4: perineo (silla de montar). El bloqueo motor se prueba con elevación de pierna y flexo-extensión de rodilla (Bromage 0–3); el simpático sube 2 segmentos más que el sensitivo, y el sensitivo 2 más que el motor: siempre evaluar los tres.",
            "Espacios y volúmenes" to "Epidural: negativo (gas) o cero (salino) en la espalda alta; contiene venas (Batson), grasa y raíces. Subaracnoideo: LCR (la punta de la aguja debe ver LCR claro y pulsátil). La distancia piel-dura crece con el IMC (~1 cm cada 5 puntos) y es menor en la torácica; el «espacio» se abre con la flexión (mejor LOR). El saco dural termina en S2 (adulto): el caudal seguro queda por debajo.",
            "Vascularización y ASRA en un párrafo" to "La médula se perfunde por la arteria de Adamkiewicz (T9-T12 izquierda, dominante): la inyección intraarterial de anestésico local o esteroide en ese territorio causa paraplejia — la razón de la asepsia técnica y de no forzar punciones repetidas a la izquierda torácica alta. Anticoagulantes: la ventana de ASRA manda (heparina profiláctica 4–6 h; Clexane 12 h profiláctica / 24 h terapéutica; clopidogrel 7 días; rivaroxaban/apixaban 72 h): si no se puede cumplir la ventana, se cambia de técnica anestésica, no se improvisa."
        ),
        artId = "dermatomas"
    )
)
