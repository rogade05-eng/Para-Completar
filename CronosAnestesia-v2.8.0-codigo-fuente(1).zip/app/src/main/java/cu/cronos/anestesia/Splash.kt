package cu.cronos.anestesia

/*
 * ============================================================================
 *  Splash — portada de 3 s solicitada por el usuario (v1.3.0).
 *  Motivo visual "tiempo y latido": reloj de Cronos cuya manecilla completa
 *  una vuelta en exactamente 3000 ms (la propia animación gobierna la
 *  duración de la portada), con un trazo de ECG que se dibuja en bucle.
 *  Tap en cualquier punto la salta. El degradado teal es la identidad de
 *  marca y es independiente del tema claro/oscuro.
 * ============================================================================
 */

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val SplashTop = Color(0xFF0E6E69)
private val SplashBottom = Color(0xFF05302D)
private val SplashInk = Color(0xFFE9F5F3)
private val SplashInkSoft = Color(0xFFBFE6E1)

@Composable
fun SplashScreen(appVersion: String, onDone: () -> Unit) {
    // Iconos claros de la barra de estado sobre el fondo teal oscuro.
    SystemBarAppearance(darkIcons = false)

    // Progreso maestro 0→1 en 3000 ms: gira la manecilla y decide el cierre.
    val progress = remember { Animatable(0f) }
    // Fundido de salida (al terminar o al tocar).
    val fade = remember { Animatable(1f) }
    // Entradas escalonadas.
    val appearLogo = remember { Animatable(0f) }
    val appearText = remember { Animatable(0f) }
    val appearFoot = remember { Animatable(0f) }

    // Trazo ECG en bucle (1,6 s por ciclo).
    val ecgTransition = rememberInfiniteTransition(label = "ecg")
    val ecgTrim by ecgTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1600, easing = LinearEasing)),
        label = "ecgTrim"
    )

    val scope = rememberCoroutineScope()
    var closed by remember { mutableStateOf(false) }
    fun close(exitMs: Int) {
        if (closed) return
        closed = true
        scope.launch {
            fade.animateTo(0f, tween(exitMs, easing = FastOutSlowInEasing))
            onDone()
        }
    }

    LaunchedEffect(Unit) {
        launch { delay(60); appearLogo.animateTo(1f, tween(650, easing = FastOutSlowInEasing)) }
        launch { delay(340); appearText.animateTo(1f, tween(520, easing = FastOutSlowInEasing)) }
        launch { delay(620); appearFoot.animateTo(1f, tween(520, easing = FastOutSlowInEasing)) }
        progress.animateTo(1f, tween(3000, easing = LinearEasing))
        close(380)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(SplashTop, SplashBottom)))
            .pointerInput(Unit) { detectTapGestures { close(240) } }
    ) {
        // Resplandor radial suave tras el logo.
        Box(
            Modifier
                .align(Alignment.Center)
                .size(320.dp)
                .background(
                    Brush.radialGradient(
                        listOf(Color.White.copy(alpha = 0.10f), Color.Transparent)
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 28.dp)
                .padding(bottom = 30.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.weight(1f))

            CronosMark(
                progress = progress.value,
                ecgTrim = ecgTrim,
                alpha = appearLogo.value,
                scale = 0.88f + 0.12f * appearLogo.value
            )

            Spacer(Modifier.height(26.dp))

            Text(
                stringResource(R.string.app_name),
                color = SplashInk,
                fontSize = 30.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.2.sp,
                modifier = Modifier
                    .alpha(appearText.value)
                    .offset { IntOffset(0, (14f * (1f - appearText.value)).toInt()) }
            )
            Spacer(Modifier.height(8.dp))
            Text(
                stringResource(R.string.splash_tagline),
                color = SplashInkSoft,
                fontSize = 14.sp,
                letterSpacing = 0.8.sp,
                modifier = Modifier.alpha(appearText.value)
            )

            Spacer(Modifier.weight(1f))

            // Barra fina de progreso (ancho = progreso del tiempo).
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.alpha(appearFoot.value)
            ) {
                Box(
                    Modifier
                        .width(150.dp)
                        .height(3.dp)
                        .background(Color.White.copy(alpha = 0.18f))
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth(progress.value.coerceIn(0.02f, 1f))
                            .height(3.dp)
                            .background(Color.White.copy(alpha = 0.85f))
                    )
                }
                Spacer(Modifier.height(16.dp))
                Text(
                    appVersion,
                    color = SplashInkSoft.copy(alpha = 0.85f),
                    style = MaterialTheme.typography.labelMedium
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    stringResource(R.string.splash_footer),
                    color = SplashInkSoft.copy(alpha = 0.7f),
                    style = MaterialTheme.typography.labelMedium
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    stringResource(R.string.splash_developer),
                    color = SplashInkSoft.copy(alpha = 0.6f),
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }
}

/**
 * Marca gráfica: anillo-reloj con 12 marcas, manecilla que gira con el
 * progreso y trazo ECG que se dibuja sobre el centro.
 */
@Composable
private fun CronosMark(progress: Float, ecgTrim: Float, alpha: Float, scale: Float) {
    Canvas(
        modifier = Modifier
            .size(190.dp)
            .alpha(alpha)
            .scale(scale)
    ) {
        val c = center
        val r = size.minDimension / 2f
        val white = SplashInk

        // Anillo exterior
        drawCircle(color = white, radius = r, center = c, style = Stroke(width = 5.dp.toPx()))

        // 12 marcas horarias
        for (i in 0 until 12) {
            val ang = Math.toRadians((i * 30.0) - 90.0)
            val cosA = cos(ang).toFloat()
            val sinA = sin(ang).toFloat()
            val r1 = r * 0.86f
            val r2 = r * 0.94f
            drawLine(
                color = white.copy(alpha = if (i % 3 == 0) 0.95f else 0.45f),
                start = Offset(c.x + r1 * cosA, c.y + r1 * sinA),
                end = Offset(c.x + r2 * cosA, c.y + r2 * sinA),
                strokeWidth = if (i % 3 == 0) 3.5.dp.toPx() else 2.dp.toPx(),
                cap = StrokeCap.Round
            )
        }

        // Manecilla de Cronos: una vuelta completa en 3 s
        val handAng = Math.toRadians(((progress * 360.0) - 90.0))
        val hx = c.x + (r * 0.52f) * cos(handAng).toFloat()
        val hy = c.y + (r * 0.52f) * sin(handAng).toFloat()
        drawLine(
            color = white,
            start = Offset(c.x - 0.10f * r * cos(handAng).toFloat(), c.y - 0.10f * r * sin(handAng).toFloat()),
            end = Offset(hx, hy),
            strokeWidth = 4.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawCircle(color = white, radius = 4.5.dp.toPx(), center = Offset(hx, hy))
        drawCircle(color = white, radius = 6.dp.toPx(), center = c)

        // Trazo ECG que se dibuja en bucle sobre el centro
        val ecg = Path().apply {
            moveTo(c.x - r * 0.72f, c.y + r * 0.10f)
            lineTo(c.x - r * 0.34f, c.y + r * 0.10f)
            lineTo(c.x - r * 0.22f, c.y - r * 0.14f)
            lineTo(c.x - r * 0.10f, c.y + r * 0.30f)
            lineTo(c.x + r * 0.04f, c.y - r * 0.34f)
            lineTo(c.x + r * 0.16f, c.y + r * 0.08f)
            lineTo(c.x + r * 0.28f, c.y + r * 0.08f)
            lineTo(c.x + r * 0.38f, c.y - r * 0.06f)
            lineTo(c.x + r * 0.72f, c.y - r * 0.06f)
        }
        val measure = PathMeasure()
        measure.setPath(ecg, false)
        val visible = Path()
        measure.getSegment(0f, measure.length * ecgTrim, visible, true)
        drawPath(
            visible,
            color = Color(0xFFFFD9CF), // rosa coral suave (latido)
            style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}
