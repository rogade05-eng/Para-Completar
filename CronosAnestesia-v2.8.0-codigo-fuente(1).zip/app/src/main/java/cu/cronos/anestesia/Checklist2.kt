package cu.cronos.anestesia

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

// =====================================================================
//  CHECKLIST ANESTÉSICA DE VERIFICACIÓN (v2.3.0 · contrato §5.2 v2.3.0)
//  Complementa la OMS (v2.2.0) con la verificación específica del acto
//  anestésico en 3 momentos: PRE-INDUCCIÓN (máquina + monitor + drogas
//  + vía aérea), DURANTE y DESPUÉS. Cada ítem se agrupa por ámbito.
//  Basada en la verificación preinducción internacional (ASFAR/EA
//  Recommendations for standards of monitoring, checklist de la
//  máquina) y en la práctica perioperatoria habitual.
// =====================================================================

data class AnesthItem(val text: String, val group: String, val critical: Boolean = false, val note: String = "")

data class AnesthPhase(val id: String, val name: String, val moment: String, val items: List<AnesthItem>)

val GROUP_MACHINE = "Máquina"
val GROUP_MONITOR = "Monitor"
val GROUP_DRUGS = "Drogas"
val GROUP_AIRWAY = "Vía aérea"
val GROUP_GENERAL = "General"

val ANESTH_CHECKLIST = listOf(
    AnesthPhase(
        "preinduccion", "Pre-inducción", "Antes de inducir al paciente",
        listOf(
            // ---------- máquina ----------
            AnesthItem("Prueba de fugas del circuito hecha (leak test) y circuito montado", GROUP_MACHINE, critical = true),
            AnesthItem("Absorbedor de CO2 con cal sodada fresca (no endurecida ni violeta)", GROUP_MACHINE),
            AnesthItem("O₂ de reserva en cilindro con carga y llaves revisadas", GROUP_MACHINE, critical = true, note = "Fuente de pared + cilindro de respaldo."),
            AnesthItem("Vaporizador cargado, cerrado y con el agente correcto", GROUP_MACHINE),
            AnesthItem("Ventilador probado con bolsa-pulmón y alarmas activadas", GROUP_MACHINE),
            AnesthItem("Succión de anestesia funcionando y al alcance de la mano", GROUP_MACHINE, critical = true),
            // ---------- monitor ----------
            AnesthItem("ECG conectado y con trazado limpio", GROUP_MONITOR),
            AnesthItem("Oxímetro de pulso con tono audible activado", GROUP_MONITOR, critical = true),
            AnesthItem("Presión arterial (no invasiva o cruenta) con ciclo configurado", GROUP_MONITOR),
            AnesthItem("Capnografía calibrada y lista (línea conectada al circuito)", GROUP_MONITOR, critical = true),
            AnesthItem("Analizador de agente anestésico y termómetro disponibles", GROUP_MONITOR),
            AnesthItem("Límites de alarmas fijados para este paciente", GROUP_MONITOR),
            // ---------- drogas ----------
            AnesthItem("Hipnótico de inducción y relajante preparados y etiquetados", GROUP_DRUGS, critical = true),
            AnesthItem("Hipnótico/opioide de reserva disponible", GROUP_DRUGS),
            AnesthItem("Vasopresores y atropina listos en dosis de rescate", GROUP_DRUGS, critical = true),
            AnesthItem("Adrenalina diluida disponible (anafilaxia/paro)", GROUP_DRUGS),
            AnesthItem("Reversor disponible (sugammadex o neostigmina + atropina)", GROUP_DRUGS),
            AnesthItem("Lípidos 20 % en el carro si hay bloqueos regionales (LAST)", GROUP_DRUGS),
            AnesthItem("Todo fármaco llevado a la mesa etiquetado con nombre y concentración", GROUP_DRUGS, critical = true),
            AnesthItem("Sangre y hemoderivados disponibles si se previeron", GROUP_DRUGS, note = "Verificar muestra cruzada y lugar de custodia."),
            // ---------- vía aérea ----------
            AnesthItem("Laringoscopio con luz y palas de tamaño adecuado", GROUP_AIRWAY),
            AnesthItem("Tubos endotraqueales (tamaño previsto ± 0,5) con estilete y globo probado", GROUP_AIRWAY),
            AnesthItem("Mascarilla laríngea de rescate del tamaño del paciente", GROUP_AIRWAY),
            AnesthItem("Guía rígida/semirrígida y equipo de vía aérea difícil accesible", GROUP_AIRWAY, critical = true, note = "Videolaringoscopio o kit de VA difícil si está anticipada."),
            AnesthItem("Aspirador de vía aérea conectado y con sonda a mano", GROUP_AIRWAY),
            AnesthItem("Preoxigenación con O₂ al 100 % ≥ 3 min o 8 capacidades vitales", GROUP_AIRWAY, critical = true),
            AnesthItem("Ayuno confirmado y factores de riesgo de aspiración evaluados", GROUP_AIRWAY, critical = true)
        )
    ),
    AnesthPhase(
        "durante", "Durante", "Mantenimiento del acto anestésico",
        listOf(
            AnesthItem("Capnografía continua en todo paciente anestesiado con vía aérea", GROUP_MONITOR, critical = true),
            AnesthItem("Trazados y alarmas audibles visibles para todo el equipo", GROUP_MONITOR),
            AnesthItem("Profundidad anestésica vigilada (signos clínicos; BIS/entropía si está disponible)", GROUP_GENERAL),
            AnesthItem("Relajación neuromuscular con monitorización TOF si se usan bloqueantes", GROUP_MONITOR),
            AnesthItem("Fluidoterapia según plan y gasto o presión venosa si está disponible", GROUP_GENERAL),
            AnesthItem("Temperatura vigilada y calentamiento activo en cirugía > 30 min", GROUP_GENERAL),
            AnesthItem("Posición quirúrgica revisada y puntos de presión protegidos", GROUP_GENERAL),
            AnesthItem("Sangrado y reposición reevaluados periódicamente", GROUP_GENERAL, note = "Conciliar pérdida estimada con campo, drenajes y Hb si procede."),
            AnesthItem("Concentraciones de agente/O₂ y ventilación ajustadas a la fase de la cirugía", GROUP_MACHINE),
            AnesthItem("Comunicación periódica con el cirujano sobre eventos críticos y tiempos", GROUP_GENERAL)
        )
    ),
    AnesthPhase(
        "despues", "Después", "Reversión, extubación y traspaso",
        listOf(
            AnesthItem("Reversión completada y TOF ≥ 0,9 confirmado si hubo bloqueantes", GROUP_DRUGS, critical = true),
            AnesthItem("Criterios de despertar y extubación presentes (respiración, obediencia, O₂)", GROUP_AIRWAY, critical = true),
            AnesthItem("Succión completa y O₂ de transporte disponible para el traslado", GROUP_GENERAL),
            AnesthItem("Traslado con monitorización y vía aérea segura hasta la sala de recuperación", GROUP_GENERAL),
            AnesthItem("Traspaso verbal estructurado al equipo receptor (técnica, drogas, eventos, sangrado)", GROUP_GENERAL, critical = true),
            AnesthItem("Analgesia y antieméticos prescritos y administrados", GROUP_GENERAL),
            AnesthItem("Anestesia documentada: fármacos, dosis, eventos y balances", GROUP_GENERAL),
            AnesthItem("Máquina y carro reordenados; drogas gastadas conciliadas", GROUP_MACHINE)
        )
    )
)

// ------------------------------ Pestaña ------------------------------

@Composable
fun AnesthChecklistContent() {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    var which by rememberSaveable { mutableStateOf(0) }
    val phase = ANESTH_CHECKLIST[which.coerceIn(0, ANESTH_CHECKLIST.size - 1)]
    var checks by rememberSaveable(phase.id) {
        mutableStateOf(Array(phase.items.size) { false }.toList())
    }
    val done = checks.count { it }
    val allDone = done == phase.items.size

    Column(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = sp.screenHPad.dp)) {
            Spacer(Modifier.height(sp.s.dp))
            SegmentedRow(
                ANESTH_CHECKLIST.map { it.name },
                selected = which,
                onSelect = { which = it }
            )
        }
        ScreenColumn {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(Modifier.padding(sp.m.dp)) {
                    Text(
                        phase.name + " · " + phase.moment,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Verificación del acto anestésico: máquina, monitor, drogas y vía aérea. Los ítems críticos no deben pasarse nunca.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Progreso: $done de ${phase.items.size}",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    "${(done * 100) / phase.items.size} %",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Row(Modifier.fillMaxWidth().height(8.dp)) {
                Box(
                    Modifier.weight(done.toFloat().coerceAtLeast(0.001f)).height(8.dp)
                        .background(MaterialTheme.colorScheme.primary)
                )
                Box(
                    Modifier.weight((phase.items.size - done).toFloat().coerceAtLeast(0.001f))
                        .height(8.dp).background(MaterialTheme.colorScheme.surfaceVariant)
                )
            }

            if (allDone) {
                Spacer(Modifier.height(sp.xs.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                    )
                ) {
                    Text(
                        "Fase " + phase.name + " completada (" + done + "/" + phase.items.size + "). " +
                            "Anúnciela en voz alta antes de continuar.",
                        modifier = Modifier.padding(sp.m.dp),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
            }

            // ítems agrupados por ámbito
            var lastGroup = ""
            phase.items.forEachIndexed { i, item ->
                if (item.group != lastGroup) {
                    lastGroup = item.group
                    Text(
                        item.group,
                        modifier = Modifier.padding(top = sp.xs.dp),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (checks[i]) MaterialTheme.colorScheme.surfaceVariant
                        else MaterialTheme.colorScheme.surface
                    )
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = sp.xs.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = checks[i],
                            onCheckedChange = { v ->
                                val next = checks.toMutableList()
                                next[i] = v
                                checks = next
                            }
                        )
                        Column(Modifier.padding(vertical = sp.xs.dp)) {
                            Text(
                                item.text,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            if (item.note.isNotBlank()) {
                                Text(
                                    item.note,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (item.critical) {
                                Text(
                                    "CRÍTICO",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
                AppButton(
                    "Reiniciar",
                    secondary = true,
                    modifier = Modifier.weight(1f),
                    onClick = { checks = Array(phase.items.size) { false }.toList() }
                )
                AppButton(
                    "Guardar en expediente",
                    modifier = Modifier.weight(1f),
                    onClick = {
                        val criticalPending = phase.items.mapIndexed { i, it ->
                            if (it.critical && !checks[i]) it.text else null
                        }.filterNotNull()
                        val summary = buildString {
                            append("Checklist anestésica · ").append(phase.name)
                            append(" (").append(phase.moment).append(")\n")
                            append("Marcados: ").append(done).append(" de ").append(phase.items.size)
                            if (criticalPending.isNotEmpty()) {
                                append("\nPENDIENTES CRÍTICOS:\n")
                                criticalPending.forEach { append("- ").append(it).append('\n') }
                            }
                        }
                        Expediente.saveCalc(ctx, "Checklist anestésica", summary)
                        Toast.makeText(ctx, "Guardado en el expediente", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }
    }
}
