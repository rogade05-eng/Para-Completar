package cu.cronos.anestesia

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

/*
 * ============================================================================
 *  DoseUI — calculadora de dosis POR FÁRMACO (petición del usuario):
 *  introduce peso y edad una vez y cada fármaco calcula sus bolos, infusiones
 *  y regímenes de sedación/analgesia. La lógica numérica vive en DoseEngine
 *  (pura y testeada); este archivo solo pinta resultados.
 *  El peso/edad se guardan en DataStore: no se reescriben entre fármacos.
 * ============================================================================
 */

private fun dParse(s: String): Double = CalcEngine.parseNum(s)
private fun dFmt(v: Double): String = CalcEngine.fmt(v)

private fun rangeText(min: Double, max: Double, unit: String): String =
    if (min == max) "${dFmt(min)} $unit" else "${dFmt(min)}–${dFmt(max)} $unit"

/** Chip de dilución (selector): altura uniforme dentro de su fila. */
@Composable
private fun DilChip(
    label: String,
    selected: Boolean,
    onSelect: () -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedButton(
        onClick = onSelect,
        modifier = modifier.heightIn(min = 40.dp),
        shape = RoundedCornerShape(10.dp),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = if (selected) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.onSurfaceVariant
        )
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/** Entrada numérica del paciente con teclado decimal. */
@Composable
private fun DoseNumField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    suffix: String,
    modifier: Modifier
) {
    OutlinedTextField(
        value = value,
        onValueChange = { raw ->
            val cleaned = raw.filter { it.isDigit() || it == ',' || it == '.' }
            if (cleaned.length <= 6) onChange(cleaned)
        },
        modifier = modifier,
        singleLine = true,
        label = { Text(label) },
        suffix = { Text(suffix) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.primary,
            cursorColor = MaterialTheme.colorScheme.primary
        )
    )
}

@Composable
fun DrugDoseCalc(drugName: String) {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    val profile = remember(drugName) { DoseEngine.profileFor(drugName) } ?: return

    val defaults by PatientRepo.flow(ctx).collectAsState(initial = PatientDefaults.DEFAULT)

    var weightText by rememberSaveable { mutableStateOf("") }
    var ageText by rememberSaveable { mutableStateOf("") }
    var ageMonths by rememberSaveable { mutableStateOf(false) }

    // Primer arranque: precarga el último peso/edad usados (o los valores por defecto).
    LaunchedEffect(defaults) {
        if (weightText.isEmpty()) {
            weightText = dFmt(defaults.weightKg.toDouble())
            ageText = dFmt(defaults.ageValue.toDouble())
            ageMonths = defaults.ageUnit == 1
        }
    }

    fun persist() {
        val w = dParse(weightText).toFloat()
        val a = dParse(ageText).toFloat()
        if (w > 0f) PatientRepo.save(ctx, w, a, if (ageMonths) 1 else 0)
    }

    val weight = dParse(weightText)
    val ageYears = dParse(ageText) / if (ageMonths) 12.0 else 1.0
    val hasWeight = weight > 0

    Column(verticalArrangement = Arrangement.spacedBy(sp.s.dp)) {

        // ---- Entradas del paciente: peso + edad (con unidad) ----
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            DoseNumField(
                weightText,
                { weightText = it; persist() },
                stringResource(R.string.dose_weight_label),
                "kg",
                Modifier.weight(1f)
            )
            DoseNumField(
                ageText,
                { ageText = it; persist() },
                stringResource(R.string.dose_age_label),
                if (ageMonths) "mes" else "año",
                Modifier.weight(1f)
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            AppButton(
                stringResource(R.string.dose_years),
                secondary = ageMonths,
                modifier = Modifier.weight(1f),
                onClick = {
                    if (ageMonths) {
                        val y = dParse(ageText) / 12.0
                        if (y > 0) ageText = dFmt(y)
                        ageMonths = false
                        persist()
                    }
                }
            )
            AppButton(
                stringResource(R.string.dose_months),
                secondary = !ageMonths,
                modifier = Modifier.weight(1f),
                onClick = {
                    if (!ageMonths) {
                        val m = dParse(ageText) * 12.0
                        if (m > 0) ageText = dFmt(m)
                        ageMonths = true
                        persist()
                    }
                }
            )
        }

        Text(
            profile.generalNote,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        if (!hasWeight) {
            Text(
                stringResource(R.string.dose_need_weight),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.error
            )
        } else if (ageYears <= 0.0) {
            Text(
                stringResource(R.string.dose_adult_note),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (ageYears > 0 && ageYears < 1.0) {
            Text(
                stringResource(R.string.dose_neonate_note),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error
            )
        }

        // ---- Regímenes calculados del fármaco ----
        if (hasWeight) {
            profile.regimens.forEach { r ->
                if (!DoseEngine.regimenVisible(r, ageYears)) return@forEach
                RegimenCard(r, weight, ageYears)
            }
        }

        Text(
            stringResource(R.string.dose_disclaimer),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

/** Tarjeta de un régimen: dosis total (bolo) o velocidad de bomba (infusión). */
@Composable
private fun RegimenCard(r: Regimen, weightKg: Double, ageYears: Double) {
    val sp = LocalSpacing.current
    var dilIdx by rememberSaveable(r.label) { mutableStateOf(0) }
    val dilution = r.dilutions.getOrNull(dilIdx) ?: r.dilutions.firstOrNull()
    val res = DoseEngine.regimenResult(r, weightKg, ageYears, dilution)

    val badge = when {
        res.pediatric -> stringResource(R.string.dose_badge_ped)
        r.infusion -> stringResource(R.string.dose_badge_infusion)
        else -> stringResource(R.string.dose_badge_bolus)
    }
    val noteText = when {
        res.pediatric && r.pedNote.isNotBlank() -> r.pedNote
        else -> r.note
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(sp.m.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    r.label,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    badge,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (res.pediatric) MaterialTheme.colorScheme.tertiary
                    else MaterialTheme.colorScheme.primary
                )
            }
            Spacer(Modifier.height(6.dp))

            if (r.infusion) {
                val (rateMin, rateMax) = DoseEngine.rangeFor(r, ageYears)
                Text(
                    stringResource(R.string.dose_range) + ": " +
                        rangeText(rateMin, rateMax, r.unit.label),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                val hourly = rangeText(res.amountMin, res.amountMax, res.amountLabel) +
                    if (r.unit.isMicro) " ≈ " + rangeText(
                        res.amountMin / 1000.0, res.amountMax / 1000.0, "mg/h"
                    ) else ""
                Text(
                    stringResource(R.string.dose_hourly) + ": " + hourly,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    stringResource(R.string.dose_pump) + ": " +
                        rangeText(res.mlMin, res.mlMax, "mL/h"),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
            } else {
                val isFixed = r.unit == DoseUnit.MG || r.unit == DoseUnit.UG || r.unit == DoseUnit.U
                val label = if (isFixed) stringResource(R.string.dose_fixed)
                else stringResource(R.string.dose_range) + " (" + r.unit.label + ")"
                Text(
                    label + ": " + rangeText(res.amountMin, res.amountMax, res.amountLabel),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
            }

            if (noteText.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    noteText,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Selector de dilución (solo infusiones con más de una preparación)
            if (r.infusion && r.dilutions.size > 1) {
                Spacer(Modifier.height(6.dp))
                Text(
                    stringResource(R.string.dose_dilution),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(4.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(sp.xs.dp)
                ) {
                    r.dilutions.forEachIndexed { i, d ->
                        DilChip(
                            label = d.label,
                            selected = i == dilIdx,
                            onSelect = { dilIdx = i }
                        )
                    }
                }
            }
        }
    }
}
