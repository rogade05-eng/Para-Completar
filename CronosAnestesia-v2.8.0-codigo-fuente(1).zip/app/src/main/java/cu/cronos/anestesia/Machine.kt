package cu.cronos.anestesia

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.min

// =====================================================================
//  MÁQUINA DE ANESTESIA (v2.2.0)
//  Apartado educativo: partes y funciones, materiales de uso en
//  anestesia, verificación preoperatoria y esquemas dinámicos del
//  sistema circular y del flujo de gases (Compose Canvas, 100 % offline:
//  los diagramas se dibujan en pantalla, no son imágenes descargadas).
// =====================================================================

data class MachinePart(val name: String, val role: String, val detail: String)

data class MachineMaterial(val name: String, val detail: String)

/** Partes de la máquina de anestesia y su función. */
val MACHINE_PARTS = listOf(
    MachinePart(
        "Suministro de gases (tomas murales y balones)",
        "Aporta O2, aire y N2O a la máquina",
        "La máquina recibe O2 por toma mural (4 bar ≈ 400 kPa) o balón con regulador, y aire y N2O opcionales por toma mural. Cada entrada tiene manómetro (gas residual del balón), filtro anti-partículas y válvula unidireccional. Verifique la fuente antes de cada lista: O2 mural abierto, balón de reserva conectado y con presión suficiente. El fallo de O2 es la emergencia de la máquina: toda máquina normativa corta los demás gases (fail-safe) y dispara la alarma sonora cuando la presión de O2 cae por debajo del umbral."
    ),
    MachinePart(
        "Reguladores de presión",
        "Reducen 400 kPa → ~2 bar para el circuito neumático",
        "La presión de suministro (≈400 kPa) se reduce en dos etapas: primera a ~2 bar (200 kPa) para el circuito de baja presión y la llamada de O2 proporcional; el O2 también alimenta el conmutador de balón/ mural y el flush de O2 (35–75 L/min directo al circuito). Un regulador defectuoso produce fluctuaciones de flujo y presión que se notan como rotámetros oscilantes o alarmas de presión intermitentes: si ocurre, cambiar de fuente y no iniciar la anestesia."
    ),
    MachinePart(
        "Rotámetros (flowmeters)",
        "Fijan el flujo de cada gas en L/min",
        "Tubos verticales cónicos con flotador: la altura del flotador indica el flujo. Son la interfaz principal para programar gas fresco (p. ej. 2 L/min O2 + 1 L/min N2O). Riesgos clásicos: lectura errónea al mirar de lado (paralaje, mirar a la altura del centro del flotador), flotador pegado por suciedad y error de tubo cruzado en máquinas viejas. El O2 suele estar al final de la cadena (a la derecha): una fuga aguas arriba no puede dejar al paciente sin O2. Con flujos bajos (<1 L/min) la precisión es menor: confirme con el analizador de gases."
    ),
    MachinePart(
        "Vaporizadores",
        "Añaden anestésico halogenado al gas fresco",
        "Vaporizadores de bypass variable y compensados por temperatura y flujo (isoflurano, sevoflurano, desflurano: este último a presión, calentado a 39 °C). Concentración en % de volumen (MAC: sevoflurano ~2, desflurano ~6, isoflurano ~1,15). Reglas de seguridad: solo un vaporizador abierto a la vez (mecanismo interlock), llenar con el vaporizador cerrado y apagado, verificar el líquido correcto en la ventana de color (un agente equivocado da una MAC impredecible), no inclinarlo (fuga de líquido al bypass → sobredosis), cerrarlo antes de vaciar el circuito. El consumo aproximado con FGF 1 L/min y 1 MAC de sevoflurano ronda 15–20 mL/h."
    ),
    MachinePart(
        "Barra posterior y salida de gas común (CGO)",
        "Mezcla final y entrega al circuito",
        "La barra posterior conecta los vaporizadores en serie con mecanismo selectivo: solo el vaporizador activo recibe gas. La mezcla (gas fresco + agente) sale por la salida de gas común (CGO) hacia el circuito paciente. En esta zona viven el analizador de agente (si está integrado) y la alarma de O2/N2O proporcional. Verifique el sellado del vaporizador en su asiento: una fuga aquí produce hipoxemia insidiosa y desaparece al cerrar el vaporizador (prueba de exclusión)."
    ),
    MachinePart(
        "Absorbedor de CO2 (cal sodada o hidróxido de bario)",
        "Elimina el CO2 exhalado del circuito",
        "Dos cámaras con granulado (cal sodada: NaOH/KOH sobre Ca(OH)2; o hidróxido de bario). El granulado fresco cambia de color al agotarse (violeta/blanco según marca). Cambiar cuando: el color está agotado en la cámara en uso al final del caso, el paciente presenta hipercapnia inexplicada o el granulado está duro/polvorienta. Precauciones: NO usar con desflurano granulado seco extremo (compuesto A y CO monóxido al reanudar; flush antes de usar tras un fin de semana), evitar contacto con agentes volátiles derramados y con agua (barro cáustico). Capacidad típica: 2–4 L de granulado por cambio."
    ),
    MachinePart(
        "Sistema circular y válvulas unidireccionales",
        "Circuito con rebreathing: economiza gas y conserva calor y humedad",
        "Dos manguitas (inspiratoria y espiratoria) con válvulas unidireccionales que impiden la recirculación del gas exhalado hacia el paciente sin pasar por el absorbedor. Ventajas: FGF bajo (0,3–1 L/min en mantenimiento), humidifica y calienta el gas, permite PEEP y ventilación mecánica. Riesgos: válvula pegada (inspiratoria: esfuerzo inspiratorio y auto-PEEP; espiratoria: hipercapnia), espacio muerto (el volumen entre el paciente y la bifurcación en Y no se ventila: mantenerlo mínimo, crítico en pediatría), fugas del circuito (test de fuga antes de cada lista)."
    ),
    MachinePart(
        "Bolsa reservorio",
        "Amortigua el gas y permite la ventilación manual",
        "Bolsa de látex (2–3 L en adulto) que almacena el gas fresco durante la espiración y permite ventilar a mano en apnea (sacar 300–500 mL por compresión en el adulto). Su tamaño se elige 2–3 veces el volumen tidal. La bolsa también sirve de diagnóstico: un paciente con esfuerzo espontáneo contra el circuito se ve como contracciones irregulares. En modo ventilador la bolsa queda aislada por la válvula de 3 vías: si hay que ventilar a mano, conmutar primero."
    ),
    MachinePart(
        "Válvula APL (limitadora de presión ajustable)",
        "Regula la presión del circuito y libera el gas excedente",
        "Válvula de resorte ajustable (completamente abierta en espontáneo para no añadir trabajo; semicerrada en ventilación manual para generar presión positiva). El gas excedente sale por ella a la extracción de gases (SCVO). Errores frecuentes: dejarla cerrada con paciente espontáneo (barotrauma), abrirla del todo durante la insuflación gástrica de la máscara y olvidarla en semicerrada al desconectar (el circuito se vacía y pierde gas). Compruebe su posición antes de cada fase."
    ),
    MachinePart(
        "Ventilador de anestesia",
        "Ventila al paciente durante la anestesia general",
        "Ventilador de campana o pistón con modo volumen-controlado (VT, frecuencia, PEEP, relación I:E) y modos de presión (PCV, PSV/CPAP con prueba de espontáneo). Los ventiladores de anesthesia aplican el VT DENTRO del circuito: el volumen real al paciente es menor que el programado (distensibilidad del circuito): calibrar o compensar. Alarmas esenciales: presión de vía aérea alta/baja, desconexión, apnea, volumen exhalado. Desconexión es la alarma más importante: pruébela ocluyendo la Y. Vigilar la onda de presión y el EtCO2: la capnografía es el estándar de confirmación de la ventilación."
    ),
    MachinePart(
        "Analizador de O2 (célula galvánica o paramagnético)",
        "Mide la FiO2 del circuito",
        "El analizador de O2 en la vía inspiratoria o espiratoria confirma que el paciente recibe la FiO2 programada: es la única defensa contra un error de montaje de gas (N2O sin O2, tubo cruzado). La célula galvánica se agota (1–2 años): verificar su calibración al 100 % en la preoxigenación. Alarmar por debajo de la FiO2 mínima elegida (habitualmente <25 %). En pediatría y en cesárea confirme siempre el O2 analizado antes de inducir."
    ),
    MachinePart(
        "Extracción de gases anestésicos (SCVO)",
        "Conduce el gas excedente fuera del quirófano",
        "Sistema de evacuación conectado a la válvula APL y al alivio del ventilador: elimina los gases residuales del personal (límites NIOSH: halogenados <2 ppm, N2O <25 ppm). Componentes: interfaz de succión, reservorio de succión pasiva o activa y tubería. Un SCVO ocluido eleva la presión del circuito (barotrauma); uno con succión excesiva colapsa la bolsa. Verifique que el circuito de extracción está abierto antes de conectar el paciente y que no hay ruidos de succión constante sobre la bolsa."
    ),
    MachinePart(
        "Alarmas y monitores integrados",
        "Vigilancia continua del circuito y del paciente",
        "La máquina vigila: presión de O2 de suministro, presión de vía aérea (PIC/PAM, alta/baja), volumen exhalado, FiO2, agente y EtCO2 (con el monitor integrado o aparte). Regla de oro: NUNCA silenciar una alarma sin identificar su causa; una alarma repetida y apagada es la letra pequeña de casi todo incidente grave. Antes de cada lista: prueba de fuga del circuito, calibración de O2, comprobar la alarma de desconexión y el nivel de granulado."
    )
)

/** Materiales de uso habitual en anestesia. */
val MACHINE_MATERIALS = listOf(
    MachineMaterial(
        "Laringoscopio y palas (Macintosh, Miller)",
        "El mango aloja pilas y la pala emite luz. Macintosh (curva): adulto, se apoya en la base de la lengua; Miller (recta): neonato/lactante o epiglotis móvil, levanta la epiglotis. Verificar luz y batería antes de cada lista; tener palas 2 y 3 (adulto), 1 y 0 (pediatría) disponibles. Alternativas de video-laringoscopio cuando se prevé vía aérea difícil."
    ),
    MachineMaterial(
        "Tubos endotraqueales",
        "Tubo con balón de adulto 7,0–8,5 (mujer 7,0–7,5; hombre 7,5–8,5); sin balón en neonato (2,5–3,5). Marcar la profundidad (cm en la punta: ~21 cm mujer, ~23 cm hombre en la comisura). Probar el balón antes de usar; presionar solo hasta sellar (20–30 cmH2O) para evitar isquemia de mucosa. Diámetro interno menor en edema/quemadura de vía aérea."
    ),
    MachineMaterial(
        "Mascarilla laríngea (LMA y dispositivos supraglóticos)",
        "Canal de aire con manguito periglótico que se asienta en la hipofaringe. Talla 4 para mujer, 5 para hombre (regla del peso). Ventaja: intubación no invasiva, menos respuesta a la inserción, útil en vía aérea difícil como plan B. Contra: no protege de la aspiración, presión de fuga ~20 cmH2O: no para laparoscopía de alta presión ni obesidad mórbida. Insertar con el borde dorsal lubrificado y deslizar contra el paladar duro."
    ),
    MachineMaterial(
        "Cánulas orofaríngeas (Guedel) y nasofaríngeas",
        "Guedel: tamaño = distancia comisura labial a ángulo de la mandíbula; insertar en el adulto con convexidad hacia el paladar y rotar 180° (o insertar directa en el niño). Nasofaríngea: más tolerada en despertar, contraindicada en trauma facial/fractura de base de cráneo y coagulopatía. Ambas mantienen la vía aérea en sedación y recuperación."
    ),
    MachineMaterial(
        "Mascarillas faciales y sistemas de preoxigenación",
        "Mascarilla anatómica con balón para preoxigenar (3–5 min o 8 capacidad vital) y ventilar en apnea. Tamaños pediátricos sellan nariz-puente sin presión en los ojos. La preoxigenación correcta (EtO2 >85 %) es la principal medida que retrasa la desaturación en la secuencia rápida."
    ),
    MachineMaterial(
        "Circuitos y filtros HME",
        "Circuito corrugado del sistema circular con bolsas y válvulas; en cada paciente cambiar o interponer filtro intercambiador de calor y humedad (HME). El HME conserva ~30 g/h de agua; su volumen muerto (5–10 mL) importa en lactantes. Ojo con HME saturado de secreciones: añade resistencia y obstruye. Cambiar entre pacientes siempre: es la barrera de infección."
    ),
    MachineMaterial(
        "Cal sodada / absorbente de CO2",
        "Granulado de 4–8 mesh en cámaras de 1–2 L. Fresco: blanco o violeta según indicador; agotado: el color correspondiente. Nunca rellenar por encima de la línea y asentar sin compactar; cambiar AMBAS cámaras o solo la primera según el modelo, y registrar la fecha de cambio. Polvo residual: aspirar antes de cerrar."
    ),
    MachineMaterial(
        "Vías venosas y equipos de perfusión",
        "Catéter periférico 16–20 G (20–18 G en adulto sano; 14–16 G si se prevé sangrado masivo), llave de tres pasos o válvula antirretorno, equipo de goteo con filtro de 15 µm (sangre: filtro específico), bomba de jeringa y volumétrica con línea de precisión en pediatría. Etiquetar cada línea y bomba con el fármaco: los errores de línea son la primera causa de evento de medicación en anestesia."
    ),
    MachineMaterial(
        "Equipos de vía aérea de rescate",
        "Bolsa-válvula-mascarilla (Ambu) con reservorio y PEEP, cánula de intubación oral/ nasal, guía rígida (Gum Elastic Bougie), video-laringoscopio, mascarilla laríngea de rescate (talla grande para adulto), kit de cricotiroidotomía y O2 de alto flujo. La regla es tenerlos al lado de TODO paciente anestesiado, no solo del difícil: CICO puede ocurrir en cualquiera."
    ),
    MachineMaterial(
        "Sondas, aspiración y accesorios",
        "Sonda de aspiración rígida (Yankauer) y flexible de succión con presión regulada (–150 a –200 mmHg adulto; menor en pediatría), guías de intercambio de tubo, pinza de Magill, lubricante, anestésico local en spray (lidocaína 10 %), jeringa para balón y clip de tubo. La succión potente y probada antes de inducir es parte de la protección de vía aérea."
    )
)

/** Verificación preoperatoria de la máquina (leak test y comprobaciones). */
val MACHINE_CHECK = listOf(
    "Fuente de gases y presión" to "O2 mural abierto (o balón con presión suficiente), manómetros de la máquina en verde, N2O/aire si se usarán. Escuchar la alarma de O2: desconectar momentáneamente y confirmar que suena antes de reconectar (simulación de fallo controlada).",
    "Analizador de O2 calibrado" to "Calibrar al 100 % con flush de O2 y alarmar FiO2 mínima (p. ej. <25 %). La célula galvánica vieja marca falso alto: si no alcanza el 100 %, cambiarla.",
    "Prueba de fuga del circuito (leak test)" to "Cerrar la válvula APL, ocluir la pieza en Y y presurizar con flush a 30–40 cmH2O: la presión debe mantenerse (caída <5 cmH2O en 10 s con sistema sin fugas). Si cae: revisar bolsa, manguitas, absorbedor, vaporizador asentado y cubetas cerradas. Repetir con el vaporizador abierto si la fuga persiste (fuga interna del vaporizador).",
    "Vaporizador" to "Nivel correcto, líquido del color correcto en la ventana, cerrado antes de empezar. Un solo vaporizador activo (interlock). Cero en el dial antes de la prueba de fuga.",
    "Circuito y absorbedor" to "Válvulas unidireccionales sueltas y orientadas (soplar por la Y: solo debe salir por la rama espiratoria), granulado de CO2 con color fresco y sin polvo, bolsa de tamaño adecuado, HME/filtro nuevo por paciente, condensadores (húmedos = sobrehumidificación o fuga).",
    "Ventilador y alarmas" to "Modo y parámetros programados (VT 6–8 mL/kg peso ideal, FR, PEEP), alarmas de presión y desconexión activas: probar la de desconexión ocluyendo la Y con el ventilador en marcha y escuchar la alarma de presión baja.",
    "Succión y extracción de gases" to "Aspiración quirúrgica potente y a mano antes de inducir (protección de vía aérea); SCVO conectado y sin ocluir (la bolsa no debe colapsar ni vibrar con la succión).",
    "Accesos y drogas de emergencia en la máquina" to "Barra de emergencias accesible: adrenalina, atropina, succinilcolina, efedrina/fenilefrina, propofol, vía venosa de carga y Ambu funcional junto a la máquina. Comprobar que el circuito de O2 de rescate (Ambu + balón) alcanza el paciente sin depender de la máquina."
)

// ------------------------------ Esquemas dinámicos ------------------------------

/** Zona táctil del esquema del sistema circular. */
private data class CircuitZone(
    val title: String,
    val text: String,
    val x1: Float, val y1: Float, val x2: Float, val y2: Float // coordenadas normalizadas 0..1
)

private val CIRCUIT_ZONES = listOf(
    CircuitZone(
        "Paciente y pieza en Y",
        "El gas fresco entra al paciente por la rama inspiratoria y sale por la espiratoria; la pieza en Y une ambas. El espacio muerto (Y, filtro, tubo entre Y y paciente) es volumen NO ventilado: manténgalo mínimo, sobre todo en lactantes.",
        0.36f, 0.02f, 0.64f, 0.18f
    ),
    CircuitZone(
        "Manguita inspiratoria",
        "Conduce el gas ya absorbedido y humidificado hacia el paciente. Su válvula unidireccional (verde) impide que el gas exhalado vuelva por esta rama; si se pega, el paciente trabaja para inspirar y aparece auto-PEEP.",
        0.14f, 0.20f, 0.36f, 0.66f
    ),
    CircuitZone(
        "Manguita espiratoria",
        "Recoge el gas exhalado y lo lleva al absorbedor a través de la válvula espiratoria (azul). Si esa válvula se pega cerrada, el CO2 se acumula (hipercapnia con onda de capnografía elevada).",
        0.64f, 0.20f, 0.86f, 0.66f
    ),
    CircuitZone(
        "Absorbedor de CO2",
        "Dos cámaras con cal sodada eliminan el CO2 del gas exhalado: el color del granulado indica su agotamiento. Es el corazón del rebreathing: sin él, la hipercapnia aparece en minutos.",
        0.20f, 0.68f, 0.52f, 0.90f
    ),
    CircuitZone(
        "Bolsa reservorio",
        "Almacena gas entre ciclos y permite ventilar a mano. Su distensión informa del estado del circuito (rígida = APL cerrada o obstrucción; vacía = fuga o desconexión).",
        0.04f, 0.52f, 0.22f, 0.74f
    ),
    CircuitZone(
        "Válvula APL y extracción",
        "La válvula ajustable libera el exceso de gas hacia el sistema de extracción (SCVO). Abierta en espontáneo, semicerrada para ventilar a mano; el gas que sale se evacúa fuera del quirófano.",
        0.78f, 0.52f, 0.96f, 0.74f
    ),
    CircuitZone(
        "Gas fresco (FGF)",
        "El gas fresco (O2 ± N2O/aire ± agente) entra al circuito cerca del absorbedor. En FGF bajo (0,3–1 L/min) el circuito conserva calor y humedad, pero los errores de composición se acumulan: confíe en el analizador de O2 y de agente.",
        0.04f, 0.76f, 0.30f, 0.98f
    )
)

/** Punto en una polilínea normalizada 0..1 según t (0..1) con longitudes de segmento. */
private fun pointOn(pts: List<Offset>, t: Float): Offset? {
    if (pts.size < 2) return null
    val lens = ArrayList<Float>(pts.size - 1)
    var total = 0f
    for (i in 0 until pts.size - 1) {
        val d = pts[i + 1] - pts[i]
        val l = d.getDistance()
        lens.add(l); total += l
    }
    if (total <= 0f) return null
    var d2 = (t - kotlin.math.floor(t)) * total
    for (i in 0 until pts.size - 1) {
        if (d2 <= lens[i]) {
            val f = if (lens[i] <= 0f) 0f else d2 / lens[i]
            return Offset(
                pts[i].x + (pts[i + 1].x - pts[i].x) * f,
                pts[i].y + (pts[i + 1].y - pts[i].y) * f
            )
        }
        d2 -= lens[i]
    }
    return pts.last()
}

private fun moveToPts(pts: List<Offset>, w: Float, h: Float): List<Offset> =
    pts.map { Offset(it.x * w, it.y * h) }

@Composable
private fun CircleSystemCanvas() {
    val sp = LocalSpacing.current
    var selected by rememberSaveable { mutableStateOf(-1) }
    val phase = rememberInfiniteTransition(label = "flow")
        .animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Restart), label = "ph")
    val dotPhase = phase.value
    val primary = MaterialTheme.colorScheme.primary
    val onSurface = MaterialTheme.colorScheme.onSurface
    val density = LocalDensity.current
    val labelPx = with(density) { 11.dp.toPx() }

    Column {
        Canvas(
            Modifier
                .fillMaxWidth()
                .height(320.dp)
                .pointerInput(Unit) {
                    detectTapGestures { pos ->
                        val w = size.width.toFloat(); val h = size.height.toFloat()
                        var hit = -1
                        CIRCUIT_ZONES.forEachIndexed { i, z ->
                            val nx = pos.x / w; val ny = pos.y / h
                            if (nx in z.x1..z.x2 && ny in z.y1..z.y2) hit = i
                        }
                        selected = if (hit == selected) -1 else hit
                    }
                }
        ) {
            val w = size.width; val h = size.height
            // contenedor
            drawRoundRect(
                color = primary.copy(alpha = 0.06f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(24f, 24f)
            )

            // manguitas (tubos)
            val insp = moveToPts(listOf(Offset(0.30f, 0.74f), Offset(0.25f, 0.40f), Offset(0.30f, 0.24f), Offset(0.45f, 0.15f)), w, h)
            val exp = moveToPts(listOf(Offset(0.55f, 0.15f), Offset(0.70f, 0.24f), Offset(0.75f, 0.40f), Offset(0.70f, 0.74f)), w, h)
            drawPath(androidx.compose.ui.graphics.Path().apply {
                moveTo(insp[0].x, insp[0].y); insp.drop(1).forEach { lineTo(it.x, it.y) }
            }, color = Color(0xFF2E7D32).copy(alpha = 0.9f), style = Stroke(10f, cap = StrokeCap.Round))
            drawPath(androidx.compose.ui.graphics.Path().apply {
                moveTo(exp[0].x, exp[0].y); exp.drop(1).forEach { lineTo(it.x, it.y) }
            }, color = Color(0xFF1565C0).copy(alpha = 0.9f), style = Stroke(10f, cap = StrokeCap.Round))

            // absorbedor (dos cámaras)
            drawRoundRect(
                color = Color(0xFF7B1FA2).copy(alpha = 0.25f), topLeft = Offset(0.20f * w, 0.70f * h),
                size = androidx.compose.ui.geometry.Size(0.17f * w, 0.20f * h),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f)
            )
            drawRoundRect(
                color = Color(0xFF7B1FA2).copy(alpha = 0.40f), topLeft = Offset(0.39f * w, 0.70f * h),
                size = androidx.compose.ui.geometry.Size(0.17f * w, 0.20f * h),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f)
            )

            // bolsa reservorio
            drawCircle(Color(0xFF00838F).copy(alpha = 0.55f), radius = 0.075f * min(w, h), center = Offset(0.12f * w, 0.62f * h))
            // válvula APL
            drawCircle(Color(0xFFEF6C00).copy(alpha = 0.85f), radius = 0.035f * min(w, h), center = Offset(0.86f * w, 0.62f * h))

            // válvulas unidireccionales
            drawCircle(Color(0xFF2E7D32), radius = 0.030f * min(w, h), center = Offset(0.27f * w, 0.42f * h))
            drawCircle(Color(0xFF1565C0), radius = 0.030f * min(w, h), center = Offset(0.73f * w, 0.42f * h))

            // pieza en Y + paciente
            drawRoundRect(
                color = Color(0xFF455A64), topLeft = Offset(0.44f * w, 0.06f * h),
                size = androidx.compose.ui.geometry.Size(0.12f * w, 0.10f * h),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f)
            )
            drawCircle(Color(0xFF455A64).copy(alpha = 0.85f), radius = 0.055f * min(w, h), center = Offset(0.50f * w, 0.045f * h))

            // gas fresco: flecha entrante
            drawLine(Color(0xFF6D4C41), Offset(0.05f * w, 0.92f * h), Offset(0.20f * w, 0.92f * h), strokeWidth = 8f, cap = StrokeCap.Round)
            drawLine(Color(0xFF6D4C41), Offset(0.16f * w, 0.88f * h), Offset(0.20f * w, 0.92f * h), strokeWidth = 8f, cap = StrokeCap.Round)
            drawLine(Color(0xFF6D4C41), Offset(0.16f * w, 0.96f * h), Offset(0.20f * w, 0.92f * h), strokeWidth = 8f, cap = StrokeCap.Round)

            // puntos animados: flujo inspiratorio (absorbedor → Y) y espiratorio (Y → absorbedor)
            val inspFlow = moveToPts(listOf(Offset(0.34f, 0.78f), Offset(0.28f, 0.42f), Offset(0.33f, 0.22f), Offset(0.50f, 0.12f)), w, h)
            val expFlow = moveToPts(listOf(Offset(0.50f, 0.16f), Offset(0.72f, 0.26f), Offset(0.71f, 0.50f), Offset(0.62f, 0.78f)), w, h)
            for (k in 0..2) {
                val t = (dotPhase + k / 3f)
                pointOn(inspFlow, t)?.let { drawCircle(Color(0xFFFFB300), radius = 5.5f, center = it) }
                pointOn(expFlow, t + 0.5f)?.let { drawCircle(Color(0xFFEC407A), radius = 5.5f, center = it) }
            }

            // zona resaltada
            selected.takeIf { it in CIRCUIT_ZONES.indices }?.let { zi ->
                val z = CIRCUIT_ZONES[zi]
                drawRoundRect(
                    color = Color(0xFFFFB300).copy(alpha = 0.55f),
                    topLeft = Offset(z.x1 * w, z.y1 * h),
                    size = androidx.compose.ui.geometry.Size((z.x2 - z.x1) * w, (z.y2 - z.y1) * h),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(14f, 14f),
                    style = Stroke(4f)
                )
            }

            // etiquetas
            val paint = android.graphics.Paint().apply {
                color = onSurface.toArgb(); textSize = labelPx; isAntiAlias = true
                textAlign = android.graphics.Paint.Align.CENTER
            }
            fun label(txt: String, x: Float, y: Float) =
                drawContext.canvas.nativeCanvas.drawText(txt, x, y, paint)
            label("Paciente", 0.50f * w, 0.035f * h + labelPx * 0.6f)
            label("Insp.", 0.27f * w, 0.46f * h)
            label("Esp.", 0.79f * w, 0.46f * h)
            label("Absorbedor CO2", 0.38f * w, 0.95f * h)
            label("Bolsa", 0.12f * w, 0.63f * h + labelPx * 0.4f)
            label("APL", 0.86f * w, 0.63f * h + labelPx * 0.4f)
            label("Gas fresco", 0.10f * w, 0.90f * h - labelPx * 0.3f)
        }

        Spacer(Modifier.height(sp.xs.dp))
        Text(
            if (selected in CIRCUIT_ZONES.indices) {
                val z = CIRCUIT_ZONES[selected]
                z.title + " — " + z.text
            } else {
                "Esquema del sistema circular con flujo animado. Toque una zona (paciente, manguitas, válvulas, absorbedor, bolsa, APL, gas fresco) para ver su función."
            },
            style = MaterialTheme.typography.bodySmall,
            color = if (selected in CIRCUIT_ZONES.indices) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

/** Caja del esquema de flujo de gases. */
private data class FlowBox(val title: String, val sub: String, val x: Float, val y: Float)

/** Cadena de flujo de gases de la máquina: fuente → rotámetros → vaporizador → CGO → circuito. */
@Composable
private fun GasFlowCanvas() {
    val phase = rememberInfiniteTransition(label = "chain")
        .animateFloat(0f, 1f, infiniteRepeatable(tween(1600, easing = LinearEasing), RepeatMode.Restart), label = "ph")
    val pulse = phase.value
    val primary = MaterialTheme.colorScheme.primary
    val onSurface = MaterialTheme.colorScheme.onSurface
    val density = LocalDensity.current
    val labelPx = with(density) { 10.dp.toPx() }

    Canvas(Modifier.fillMaxWidth().height(230.dp)) {
        val w = size.width; val h = size.height
        val boxes = listOf(
            FlowBox("O2 / Aire / N2O", "Fuente 400 kPa", 0.02f, 0.10f),
            FlowBox("Reguladores", "a 2 bar", 0.27f, 0.10f),
            FlowBox("Rotámetros", "L/min", 0.52f, 0.10f),
            FlowBox("Vaporizador", "agente %", 0.74f, 0.10f),
            FlowBox("Barra posterior", "mix + interlock", 0.74f, 0.55f),
            FlowBox("Salida común", "CGO", 0.52f, 0.55f),
            FlowBox("Sistema circular", "absorbedor", 0.27f, 0.55f),
            FlowBox("Paciente", "vía aérea", 0.02f, 0.55f)
        )
        val bw = 0.20f * w; val bh = 0.26f * h
        boxes.forEach { b ->
            drawRoundRect(
                color = primary.copy(alpha = 0.14f),
                topLeft = Offset(b.x * w, b.y * h),
                size = androidx.compose.ui.geometry.Size(bw, bh),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f)
            )
            drawRoundRect(
                color = primary.copy(alpha = 0.5f),
                topLeft = Offset(b.x * w, b.y * h),
                size = androidx.compose.ui.geometry.Size(bw, bh),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f),
                style = Stroke(2.5f)
            )
        }
        val paint = android.graphics.Paint().apply {
            color = onSurface.toArgb(); textSize = labelPx; isAntiAlias = true
            textAlign = android.graphics.Paint.Align.CENTER
        }
        fun labelBox(b: FlowBox) {
            drawContext.canvas.nativeCanvas.drawText(b.title, (b.x + 0.10f) * w, (b.y + 0.105f) * h, paint)
            drawContext.canvas.nativeCanvas.drawText(b.sub, (b.x + 0.10f) * w, (b.y + 0.185f) * h, paint)
        }
        boxes.forEach { labelBox(it) }

        // flechas horizontales (fila superior →) y (fila inferior ←)
        val alphaTop = 0.25f + 0.75f * abs(pulse - 0.5f) * 2f
        for (i in 0..2) {
            val x1 = (0.23f + i * 0.25f) * w
            drawLine(Color(0xFF2E7D32).copy(alpha = alphaTop), Offset(x1, 0.23f * h), Offset(x1 + 0.03f * w, 0.23f * h), strokeWidth = 7f, cap = StrokeCap.Round)
        }
        for (i in 0..2) {
            val x1 = (0.49f - i * 0.25f) * w
            drawLine(Color(0xFF1565C0).copy(alpha = alphaTop), Offset(x1, 0.68f * h), Offset(x1 - 0.03f * w, 0.68f * h), strokeWidth = 7f, cap = StrokeCap.Round)
        }
        // conexión vertical vaporizador → barra posterior
        drawLine(Color(0xFF2E7D32).copy(alpha = alphaTop), Offset(0.84f * w, 0.36f * h), Offset(0.84f * w, 0.55f * h), strokeWidth = 7f, cap = StrokeCap.Round)
    }
    Text(
        "Flujo de gases: fuente de alta presión → reguladores → rotámetros → vaporizador → barra posterior → salida común → sistema circular → paciente. " +
            "La presión y la composición se verifican con el analizador de O2 y la alarma de suministro.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

// ------------------------------ Pestaña ------------------------------

@Composable
fun MachineTab(onActivate: () -> Unit) {
    val sp = LocalSpacing.current
    val lic = LocalLicense.current
    if (!lic.features.machine) {
        LockedSection(
            stringResource(R.string.tab_maquina),
            stringResource(R.string.lic_lock_machine_msg),
            onActivate = onActivate
        )
        return
    }
    var which by rememberSaveable { mutableStateOf(0) }
    val segs = listOf(
        stringResource(R.string.machine_seg_scheme), stringResource(R.string.machine_seg_parts),
        stringResource(R.string.machine_seg_materials), stringResource(R.string.machine_seg_check)
    )
    Column(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = sp.screenHPad.dp)) {
            Spacer(Modifier.height(sp.s.dp))
            SegmentedRow(segs, selected = which, onSelect = { which = it })
        }
        ScreenColumn {
            when (which) {
                0 -> {
                    SectionLabel(stringResource(R.string.machine_scheme_circle))
                    CircleSystemCanvas()
                    Spacer(Modifier.height(sp.s.dp))
                    SectionLabel(stringResource(R.string.machine_scheme_flow))
                    GasFlowCanvas()
                }
                1 -> {
                    Text(
                        stringResource(R.string.machine_parts_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    MACHINE_PARTS.forEachIndexed { i, p ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(Modifier.padding(sp.m.dp)) {
                                Text(
                                    "${i + 1}. ${p.name}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(Modifier.height(3.dp))
                                Text(
                                    p.role,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    p.detail,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
                2 -> {
                    MACHINE_MATERIALS.forEach { m ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(Modifier.padding(sp.m.dp)) {
                                Text(
                                    m.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    m.detail,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
                else -> {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    ) {
                        Text(
                            stringResource(R.string.machine_check_intro),
                            modifier = Modifier.padding(sp.m.dp),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                    MACHINE_CHECK.forEachIndexed { i, (t, b) ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(Modifier.padding(sp.m.dp)) {
                                Text(
                                    "${i + 1}. $t",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(Modifier.height(5.dp))
                                Text(
                                    b,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
