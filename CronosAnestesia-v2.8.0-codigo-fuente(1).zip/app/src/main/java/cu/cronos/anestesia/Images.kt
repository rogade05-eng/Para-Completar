package cu.cronos.anestesia

// =====================================================================
//  ILUSTRACIONES REFERENCIALES (v2.1.0, solicitud del usuario: «agrega
//  imágenes referenciales a cada tema, módulo, sección... al igual que
//  íconos según sea necesario»). Imágenes propias generadas por Cronos
//  Anestesia (ilustración médica esquemática, sin derechos de terceros),
//  empaquetadas en drawable-nodpi como WebP — 100 % offline.
//  Mapeo explícito por título con reserva por categoría (sin reflexión:
//  compatible con R8/shrinkResources).
// =====================================================================

object TopicImages {

    private val byTitle: Map<String, Int> = mapOf(
        // ---- Temas quirúrgicos PRO+ ----
        "Paciente neuroquirúrgico" to R.drawable.img_brain,
        "Traumatismo craneoencefálico (TCE)" to R.drawable.img_brain,
        "Tumores supratentoriales" to R.drawable.img_brain,
        "Tumores infratentoriales" to R.drawable.img_brain,
        "Hemodilución" to R.drawable.img_ivbag,
        "Trasplante" to R.drawable.img_transplant,
        "Embarazo crítico" to R.drawable.img_preg,
        "Cardiopatía congénita adulta" to R.drawable.img_heart,
        "Fisiología respiratoria aplicada" to R.drawable.img_lungs,
        "Fisiología cardiovascular aplicada" to R.drawable.img_heart,
        "Cirugía cardíaca con CEC" to R.drawable.img_hlm,
        "Trauma en masa" to R.drawable.img_trauma,
        "Ventilación unipulmonar (OLV)" to R.drawable.img_lungs,
        "Videocirugía (laparoscopía)" to R.drawable.img_lap,
        // ---- Bloqueos regionales ----
        "Raquianestesia (subaracnoidea)" to R.drawable.img_spine,
        "Epidural lumbar y torácica" to R.drawable.img_epidural,
        "Bloqueo interescalénico" to R.drawable.img_block_arm,
        "Bloqueo supraclavicular" to R.drawable.img_block_arm,
        "Bloqueo axilar" to R.drawable.img_block_arm,
        "Bloqueo femoral y aductor" to R.drawable.img_block_arm,
        "Bloqueo TAP y de pared abdominal" to R.drawable.img_block_arm,
        "Bloqueo del plano del erector (ESP) y espinal alta" to R.drawable.img_spine,
        // ---- Tecnología de infusión ----
        "Bombas de infusión y jeringas perfusoras" to R.drawable.img_pump,
        "Anestesia TCI (infusión objetivo-controlada)" to R.drawable.img_pump,
        // ---- Monitorización ----
        "Monitorización estándar ASA" to R.drawable.img_monitor,
        "Capnografía" to R.drawable.img_monitor,
        "Profundidad anestésica" to R.drawable.img_monitor,
        "Bloqueo neuromuscular (TOF)" to R.drawable.img_monitor,
        "Hemodinámica avanzada" to R.drawable.img_monitor,
        "Ecografía punto de cuidado (POCUS)" to R.drawable.img_monitor,
        "Temperatura y normotermia" to R.drawable.img_monitor,
        // ---- Comorbilidades ----
        "Insuficiencia renal" to R.drawable.img_ivbag,
        "Insuficiencia hepática" to R.drawable.img_transplant,
        "Embarazo" to R.drawable.img_preg,
        "Obesidad" to R.drawable.img_lungs,
        "Asma y EPOC" to R.drawable.img_lungs,
        "Cardiopatía isquémica e insuficiencia cardíaca" to R.drawable.img_heart,
        "Diabetes" to R.drawable.img_ivbag,
        "Enfermedades neuromusculares" to R.drawable.img_monitor,
        // ---- Plan preop ----
        "Evaluación preoperatoria estructurada" to R.drawable.img_consent,
        "Suspensión y ajuste de fármacos" to R.drawable.img_ivbag,
        "Ayuno y profilaxis preoperatoria" to R.drawable.img_ivbag,
        "Checklist del día de la cirugía" to R.drawable.img_checklist
    )

    private val byCategory: Map<String, Int> = mapOf(
        "Comorbilidad" to R.drawable.img_ivbag,
        "Bloqueo" to R.drawable.img_block_arm,
        "Monitorización" to R.drawable.img_monitor,
        "Plan preop" to R.drawable.img_checklist,
        "Quirúrgico" to R.drawable.img_lap,
        "Tecnología" to R.drawable.img_pump
    )

    /** Imagen de un tema clínico (por título exacto, con reserva por categoría). */
    fun forTopic(title: String, category: String): Int? =
        byTitle[title] ?: byCategory[category]

    /** Imagen de un protocolo de emergencia (paro/RCP y vía aérea, lo pedido). */
    fun forEmergency(name: String): Int? = when {
        name.startsWith("Paro cardíaco") -> R.drawable.img_cpr
        name.startsWith("Vía aérea") -> R.drawable.img_airway
        name.startsWith("Laringoespasmo") || name.startsWith("Broncoaspiración") -> R.drawable.img_airway
        else -> null
    }

    /** Imagen de cabecera de un módulo/función (estadísticas, checklist…). */
    fun forModule(key: String): Int? = when (key) {
        "stats" -> R.drawable.img_stats
        "checklist" -> R.drawable.img_checklist
        "consent" -> R.drawable.img_consent
        "patients" -> R.drawable.img_patients
        "perlas" -> R.drawable.img_monitor
        "expediente" -> R.drawable.img_patients
        else -> null
    }
}
