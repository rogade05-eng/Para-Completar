package cu.cronos.anestesia

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp

// =====================================================================
//  PANTALLAS DE EMERGENCIAS, CLÍNICA Y MANUAL (Fases 1 y 2)
//  Mismas reglas de alineación que el resto de la app: LazyColumn con
//  paddings estándar, ItemCard uniforme y DetailTopBar centrado.
// =====================================================================

// ============================== EMERGENCIAS ==============================

@Composable
fun EmergencyTab(onOpen: (Int) -> Unit) {
    val sp = LocalSpacing.current
    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = sp.screenHPad.dp, vertical = sp.s.dp),
        verticalArrangement = Arrangement.spacedBy(sp.xs.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.12f)
                )
            ) {
                Text(
                    "Protocolos de acción inmediata · 2 toques desde Inicio. " +
                        "En una emergencia real, priorice su protocolo institucional y el equipo de reanimación.",
                    modifier = Modifier.padding(sp.m.dp),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
        }
        items(EMERGENCIES.size) { i ->
            val e = EMERGENCIES[i]
            ItemCard(
                title = e.name,
                subtitle = e.subtitle,
                badge = e.category,
                onClick = { onOpen(i) }
            )
        }
    }
}

@Composable
fun EmergencyDetail(index: Int, onBack: () -> Unit) {
    val sp = LocalSpacing.current
    val e = EMERGENCIES[index]
    DetailTopBar(e.name, e.subtitle, onBack)
    ScreenColumn {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(sp.m.dp)) {
                Text(
                    stringResource(R.string.sec_reconocimiento).uppercase(),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    e.recognize,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        SectionLabel(stringResource(R.string.sec_pasos))
        e.steps.forEachIndexed { i, s ->
            Text(
                "${i + 1}. $s",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        SectionLabel(stringResource(R.string.sec_dosis_clave))
        e.doses.forEach { d ->
            Text(
                "•  $d",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        SectionLabel(stringResource(R.string.sec_advertencias))
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.10f)
            )
        ) {
            Text(
                e.warnings,
                modifier = Modifier.padding(sp.m.dp),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        SectionLabel(stringResource(R.string.sec_referencias))
        BodyText(e.refs)
    }
}

// ============================== CLÍNICA ==============================

private fun clinList(section: Int): List<ClinTopic> = when (section) {
    0 -> COMORBIDITIES
    1 -> REGIONAL_BLOCKS
    2 -> MONITORING
    3 -> PREOP_TOPICS
    4 -> SURGICAL_TOPICS
    5 -> EQUIPMENT_TOPICS
    else -> FISIOLOGY
}

@Composable
fun ClinTab(onOpen: (Int) -> Unit) {
    val sp = LocalSpacing.current
    var which by rememberSaveable { mutableStateOf(0) }
    Column(Modifier.fillMaxWidth()) {
        // Selector 2 × 2 con anchos idénticos
        Column(Modifier.padding(horizontal = sp.screenHPad.dp)) {
            Spacer(Modifier.height(sp.s.dp))
            for (start in CLIN_SECTIONS.indices step 2) {
                Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
                    val count = minOf(2, CLIN_SECTIONS.size - start)
                    for (c in 0 until count) {
                        val idx = start + c
                        AppButton(
                            CLIN_SECTIONS[idx],
                            secondary = which != idx,
                            modifier = Modifier.weight(1f),
                            onClick = { which = idx }
                        )
                    }
                }
                Spacer(Modifier.height(sp.xs.dp))
            }
        }
        val topics = clinList(which)
        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = sp.screenHPad.dp, vertical = sp.s.dp),
            verticalArrangement = Arrangement.spacedBy(sp.xs.dp)
        ) {
            items(topics.size) { i ->
                val t = topics[i]
                ItemCard(
                    title = t.title,
                    subtitle = t.subtitle,
                    badge = t.category,
                    onClick = { onOpen(which * 100 + i) }
                )
            }
        }
    }
}

@Composable
fun ClinDetail(index: Int, onBack: () -> Unit) {
    val sp = LocalSpacing.current
    val sec = index / 100
    val idx = index % 100
    val safe = clinList(sec).let { if (idx < it.size) it[idx] else it[0] }
    DetailTopBar(safe.title, safe.subtitle, onBack)
    ScreenColumn {
        // Esquema de la aplicación asociado al tema (v2.4.0)
        if (safe.artId.isNotBlank()) {
            ArtHost(safe.artId)
            Spacer(Modifier.height(sp.s.dp))
        }
        safe.sections.forEach { (label, body) ->
            SectionLabel(label)
            BodyText(body)
        }
        // Calculadora asociada al tema (v2.0.0: temas quirúrgicos PRO+)
        if (safe.calcId.isNotBlank()) {
            SectionLabel(stringResource(R.string.clin_calc_title))
            ClinCalcHost(safe.calcId)
        }
    }
}

// ============================== MANUAL ==============================

@Composable
fun ManualDetail(onBack: () -> Unit) {
    DetailTopBar(stringResource(R.string.manual_title), stringResource(R.string.manual_subtitle), onBack)
    ScreenColumn {
        BodyText(MANUAL_INTRO)
        MANUAL_SECTIONS.forEach { (label, body) ->
            SectionLabel(label)
            BodyText(body)
        }
    }
}
