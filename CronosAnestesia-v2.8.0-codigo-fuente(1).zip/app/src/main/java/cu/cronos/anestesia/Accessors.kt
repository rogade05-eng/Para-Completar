package cu.cronos.anestesia

/*
 * ============================================================================
 *  Accessors (v2.7.0) — Nombres públicos estables del contenido clínico.
 *
 *  Los datos originales en español viven en constantes *_RAW (Data*, Clinical*,
 *  Emergency, Pearls, Farmacos, DoseProfiles). L10nData define los accesores
 *  dinámicos (drugs(), scales(), …) que traducen AL VUELO según el idioma
 *  activo. Estos `val get()` conservan los nombres históricos (DRUGS, SCALES…)
 *  para que las pantallas no cambien: cada lectura reevalúa el idioma activo.
 * ============================================================================
 */

val DRUGS get() = drugs()
val GASES get() = gases()
val DRUG_PREP get() = drugPrep()
val DRUG_DOSE_PROFILES get() = drugDoseProfiles()
val SCALES get() = scales()
val COMPLICATIONS get() = complications()
val PREMED_TOPICS get() = premedTopics()
val SOLUTIONS get() = solutions()
val CLIN_SECTIONS get() = clinSections()
val COMORBIDITIES get() = comorbidities()
val REGIONAL_BLOCKS get() = regionalBlocks()
val MONITORING get() = monitoring()
val PREOP_TOPICS get() = preopTopics()
val EQUIPMENT_TOPICS get() = equipmentTopics()
val SURGICAL_TOPICS get() = surgicalTopics()
val EMERGENCIES get() = emergencies()
val PEARLS get() = pearls()
