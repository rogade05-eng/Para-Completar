package cu.cronos.anestesia

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri

/*
 * ============================================================================
 *  SOLICITUD DE LICENCIA POR WHATSAPP (v1.5.2)
 *  ----------------------------------------------------------------------------
 *  La app sigue SIN permiso INTERNET (contrato R-01): este módulo no abre
 *  ningún socket. Solo lanza intents implícitos hacia WhatsApp (wa.me) o el
 *  selector «Compartir» de Android; la red la maneja la app externa elegida
 *  por el usuario.
 *
 *  Flujo de compra: el cliente completa el diálogo (nombre, organismo y nivel
 *  deseado), la app arma el mensaje con el ID de su dispositivo y lo abre en
 *  el chat del desarrollador. Con el ID en mano, el desarrollador emite la
 *  clave CRONOS1.… atada al equipo con CronosLicencias.exe y la devuelve por
 *  WhatsApp; el cliente la pega en Ajustes → Licencia y activación.
 * ============================================================================
 */
object LicenseContact {

    /**
     * WhatsApp del desarrollador: código de país + número, sin «+», espacios
     * ni guiones. Único lugar donde vive el número (cámbielo aquí).
     */
    const val WHATSAPP_PHONE = "5355301268"

    /** Nombre del desarrollador mostrado en Ajustes y en la portada. */
    const val DEVELOPER_NAME = "Ronald García Deroncele"

    /**
     * Créditos de equipo (v2.6.2): ambos integrantes con separador neutro «·».
     * Único punto del código con los dos nombres; los nombres propios no se
     * traducen (EN: «Developed by…», PT: «Desenvolvido por…»). El contacto de
     * WhatsApp y la emisión de licencias siguen canalizados por DEVELOPER_NAME.
     */
    const val DEVELOPER_CREDITS = "Ronald García Deroncele · Dr. Romay Díaz Deroncele"

    private const val WA_BASE = "https://wa.me/"

    /** Deja solo dígitos: «+53 5530 1268» → «5355301268». */
    fun normalizePhone(s: String): String = s.filter { it.isDigit() }

    /**
     * Mensaje pre-armado de solicitud. Función pura (sin Android) para poder
     * probarla en JVM: versionName, ID formateado, nivel, duración y datos del
     * titular. Desde v1.6.0 viaja también el teléfono del cliente (referencia
     * para identificar su transferencia) y la forma de pago prevista; el flujo
     * es «pague primero, reciba la clave después».
     */
    fun buildRequestMessage(
        versionName: String,
        deviceFormatted: String,
        tier: String,
        holder: String = "",
        org: String = "",
        phone: String = "",
        duration: String = "",
        method: String = ""
    ): String = buildString {
        append("Solicitud de licencia — Cronos Anestesia\n")
        append("App: ").append(versionName).append('\n')
        append("ID del dispositivo: ").append(deviceFormatted).append('\n')
        append("Nivel deseado: ").append(tier)
        if (duration.isNotBlank()) append("\nDuración deseada: ").append(duration.trim())
        if (holder.isNotBlank()) append("\nTitular: ").append(holder.trim())
        if (org.isNotBlank()) append("\nOrganismo: ").append(org.trim())
        if (phone.isNotBlank()) append("\nTeléfono de contacto: ").append(phone.trim())
        if (method.isNotBlank()) append("\nForma de pago: ").append(method.trim())
    }

    /** Mensaje de contacto directo con el desarrollador (sin datos aún). */
    fun contactMessage(appVersion: String): String =
        "Hola, escribo desde la app Cronos Anestesia $appVersion."

    /** URI wa.me con texto pre-cargado. Requiere android.net.Uri (no JVM-test). */
    fun waUri(message: String): Uri =
        Uri.parse(WA_BASE + WHATSAPP_PHONE + "?text=" + Uri.encode(message))

    /** true si se pudo lanzar WhatsApp (o navegador); false si no hay manejador. */
    fun openWhatsApp(ctx: Context, message: String): Boolean = try {
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW, waUri(message))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        true
    } catch (_: ActivityNotFoundException) {
        false
    } catch (_: Exception) {
        false
    }

    /** Selector «Compartir» de Android (Telegram, SMS, correo…) con el texto listo. */
    fun shareRequest(ctx: Context, message: String) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, message)
        }
        ctx.startActivity(
            Intent.createChooser(send, null)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    /** Copia cualquier texto al portapapeles; true si se copió. */
    fun copyText(ctx: Context, label: String, text: String): Boolean = try {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, text))
        true
    } catch (_: Exception) {
        false
    }

    /** Copia la solicitud al portapapeles; true si se copió. */
    fun copyRequest(ctx: Context, message: String): Boolean =
        copyText(ctx, "Cronos Anestesia — solicitud de licencia", message)

    /** Nombre de versión de la app (p. ej. «1.5.2»); «?» si no se puede leer. */
    fun appVersion(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "?"
    } catch (_: Exception) {
        "?"
    }
}
