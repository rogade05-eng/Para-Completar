package cu.cronos.anestesia

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

// =====================================================================
//  INFUSIÓN POR FÁRMACO (v2.0.0) — calculador de los 45 fármacos con:
//   · BUSCADOR por nombre/alias/clase/indicación
//   · Ficha de PREPARACIÓN (solvente, dilución, concentración, estabilidad)
//   · Modos de ADMINISTRACIÓN (bolo IV / perfusión continua / jeringa perfusora)
//   · Cálculo dosis ↔ velocidad de bomba con la concentración del usuario
//   · Guardado en el expediente del paciente activo
// =====================================================================

private data class InfusionSpec(
    val doseUgKgMin: Double,   // dosis típica de infusión µg/kg/min
    val concDefaultUgMl: Double // concentración habitual de la jeringa µg/mL
)

/** Dosis de infusión típica y concentración habitual por fármaco (para el cálculo mL/h). */
private val INF_SPEC: Map<String, InfusionSpec> = mapOf(
    "Propofol" to InfusionSpec(4000.0, 10000.0),        // 4 mg/kg/h = 66,7 µg/kg/min aprox → trabajamos en mg/kg/h aparte
    "Dexmedetomidina" to InfusionSpec(0.4, 4.0),
    "Fentanilo" to InfusionSpec(1.4, 10.0),
    "Remifentanilo" to InfusionSpec(0.15, 50.0),
    "Morfina" to InfusionSpec(16.0, 1000.0),            // 1 mg/h en 70 kg ≈ 0,24 µg/kg/min → uso mg/h directo
    "Ketamina" to InfusionSpec(200.0, 1000.0),          // 0,2 mg/kg/min → µg/kg/min
    "Midazolam" to InfusionSpec(33.0, 100.0),
    "Rocuronio" to InfusionSpec(10.0, 1000.0),
    "Vecuronio" to InfusionSpec(1.2, 1000.0),
    "Atracurio" to InfusionSpec(8.0, 1000.0),
    "Cisatracurio" to InfusionSpec(2.0, 2000.0),
    "Noradrenalina (Norepinefrina)" to InfusionSpec(0.1, 80.0),
    "Dopamina" to InfusionSpec(5.0, 4000.0),
    "Dobutamina" to InfusionSpec(5.0, 5000.0),
    "Milrinona" to InfusionSpec(0.5, 200.0),
    "Vasopresina" to InfusionSpec(0.02, 20.0),          // UI/h ≈ µg/kg/min equivalente no aplica: usamos la fórmula igual
    "Nitroglicerina (Trinitrato de glicerilo)" to InfusionSpec(1.0, 1000.0),
    "Adrenalina (Epinefrina)" to InfusionSpec(0.05, 10.0),
    "Fenilefrina" to InfusionSpec(0.5, 40.0),
    "Suxametonio (Succinilcolina)" to InfusionSpec(80.0, 1000.0)
)

/** Presentación legible de la dosis de mantenimiento según el fármaco. */
private fun infusionDoseText(name: String): String {
    val d = DRUGS.firstOrNull { it.name == name } ?: return ""
    val dose = d.dose
    val inf = dose.substringAfter("Infusión:", "").substringBefore(".").trim()
    val cont = dose.substringAfter("Sedación:", "").substringBefore(".").trim()
    return inf.ifBlank { cont.ifBlank { dose } }
}

@Composable
fun DrugInfusionCalc() {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    var query by rememberSaveable { mutableStateOf("") }
    var sel by rememberSaveable { mutableStateOf(-1) }
    var weight by rememberSaveable { mutableStateOf("70") }
    var conc by rememberSaveable { mutableStateOf("") } // µg/mL editada por el usuario

    val q = query.trim().lowercase()
    val filtered = remember(q) {
        if (q.isBlank()) DRUGS.indices.toList()
        else DRUGS.withIndex().filter { (_, d) ->
            val p = DRUG_PREP[d.name]
            d.name.lowercase().contains(q) || d.cls.lowercase().contains(q) ||
                d.dose.lowercase().contains(q) ||
                (p?.alias?.lowercase()?.contains(q) == true)
        }.map { it.index }
    }

    Column(Modifier.fillMaxWidth()) {
        // --- BUSCADOR ---
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text(stringResource(R.string.inf_search_hint)) },
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                cursorColor = MaterialTheme.colorScheme.primary
            )
        )
        Spacer(Modifier.height(sp.s.dp))

        if (sel < 0 || sel >= DRUGS.size) {
            // Lista de selección
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(320.dp),
                verticalArrangement = Arrangement.spacedBy(sp.xs.dp)
            ) {
                items(filtered, key = { it }) { i ->
                    val d = DRUGS[i]
                    val alias = DRUG_PREP[d.name]?.alias.orEmpty()
                    ItemCard(
                        title = d.name,
                        subtitle = if (alias.isBlank()) d.cls else "$d.cls · alias: $alias",
                        onClick = {
                            sel = i
                            conc = INF_SPEC[d.name]?.concDefaultUgMl?.let { CalcEngine.fmt(it) } ?: ""
                        }
                    )
                }
                if (filtered.isEmpty()) {
                    item {
                        Text(
                            stringResource(R.string.no_results, query),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(sp.m.dp)
                        )
                    }
                }
            }
        } else {
            val d = DRUGS[sel]
            val prep = DRUG_PREP[d.name]
            val w = CalcEngine.parseNum(weight)
            val spec = INF_SPEC[d.name]
            val concUgMl = CalcEngine.parseNum(conc)
            val mlh = if (spec != null && w > 0 && concUgMl > 0)
                CalcEngine.infusionMlH(spec.doseUgKgMin, w, concUgMl) else 0.0
            val mgH = if (spec != null && w > 0) CalcEngine.infusionMgH(spec.doseUgKgMin, w) else 0.0

            // Cabecera de ficha
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(sp.m.dp)) {
                    Text(
                        d.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (!prep?.alias.isNullOrBlank()) {
                        Text(
                            stringResource(R.string.inf_alias, prep!!.alias),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        d.cls,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(sp.xs.dp))
                    Text(
                        stringResource(R.string.inf_dose_base),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(d.dose, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
                }
            }
            Spacer(Modifier.height(sp.s.dp))

            // --- PREPARACIÓN (el «plus») ---
            if (prep != null) {
                SectionLabel(stringResource(R.string.inf_prep_title))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f))
                ) {
                    Column(Modifier.padding(sp.m.dp)) {
                        Text(
                            stringResource(R.string.inf_prep_how),
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(prep.prep, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Spacer(Modifier.height(sp.s.dp))
                        Text(
                            stringResource(R.string.inf_admin_how),
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(Modifier.height(2.dp))
                        // Modos de administración separados por segmentos BOLO | CONT | JERINGA
                        prep.admin.split(" | ").forEach { seg ->
                            val mode = seg.substringBefore(":").trim()
                            val body = seg.substringAfter(":").trim()
                            Text(
                                mode.uppercase(),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Spacer(Modifier.height(sp.xs.dp))
                        }
                    }
                }
                Spacer(Modifier.height(sp.s.dp))
            }

            // --- Cálculo de bomba ---
            if (spec != null) {
                SectionLabel(stringResource(R.string.inf_calc_title))
                Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
                    OutlinedTextField(
                        value = weight,
                        onValueChange = { weight = it },
                        modifier = Modifier.weight(1f),
                        label = { Text(stringResource(R.string.inf_weight)) },
                        suffix = { Text("kg") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                    OutlinedTextField(
                        value = conc,
                        onValueChange = { conc = it },
                        modifier = Modifier.weight(1f),
                        label = { Text(stringResource(R.string.inf_conc)) },
                        suffix = { Text("µg/mL") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                }
                Spacer(Modifier.height(sp.s.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(Modifier.padding(sp.m.dp)) {
                        Text(
                            stringResource(R.string.inf_result_ml_h),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            if (mlh > 0) "${CalcEngine.fmt(mlh)} mL/h" else "—",
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            stringResource(R.string.inf_result_mg_h, if (mgH > 0) CalcEngine.fmt(mgH) else "—"),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            stringResource(R.string.inf_formula),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(sp.xs.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
                            AppButton(
                                stringResource(R.string.exp_save_calc),
                                secondary = true,
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    Expediente.saveCalc(
                                        ctx,
                                        "Infusión: ${d.name}",
                                        "Peso ${CalcEngine.fmt(w)} kg · conc ${conc} µg/mL → ${if (mlh > 0) CalcEngine.fmt(mlh) + " mL/h" else "—"} (${if (mgH > 0) CalcEngine.fmt(mgH) + " mg/h" else "—"})"
                                    )
                                    Toast.makeText(ctx, ctx.getString(R.string.exp_saved), Toast.LENGTH_SHORT).show()
                                }
                            )
                            AppButton(
                                stringResource(R.string.inf_back),
                                secondary = true,
                                modifier = Modifier.weight(1f),
                                onClick = { sel = -1 }
                            )
                        }
                    }
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
                    AppButton(
                        stringResource(R.string.inf_back),
                        secondary = true,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { sel = -1 }
                    )
                }
            }
        }
    }
}
