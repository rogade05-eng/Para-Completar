package cu.cronos.anestesia

/*
 * ============================================================================
 *  ConsentDoc (v2.5) — Consentimiento informado anestésico, documento oficial.
 *  Modelo nuevo de la pestaña Consentimiento (ConsentUI.kt) y del exportador
 *  PDF (PdfExporter.writeConsent). Convive con el objeto Consent (v2.0.0),
 *  cuyos textos legales y listas de riesgos reutiliza.
 * ============================================================================
 */

/** Datos del formulario de consentimiento (todos los campos son texto libre). */
data class ConsentData(
    val institution: String = "",
    val service: String = "",
    val physician: String = "",
    val physicianLicense: String = "",
    val patientName: String = "",
    val patientId: String = "",
    val patientAge: String = "",
    val patientSex: String = "",
    val representative: String = "",
    val representativeRelation: String = "",
    val diagnosis: String = "",
    val procedure: String = "",
    val anesthesiaType: Int = 0,
    val technique: String = "",
    val asaClass: String = "",
    val consentTransfusion: Boolean = false,
    val consentTeaching: Boolean = false,
    val place: String = "",
    val dateText: String = "",
    val timeText: String = "",
    val witness: String = ""
) {
    val anesthesiaTypeText: String
        get() = ConsentAnesthesia.TYPES[anesthesiaType.coerceIn(0, ConsentAnesthesia.TYPES.size - 1)]

    val title: String
        get() = "Consentimiento informado para anestesia"
}

/** Tipos de anestesia seleccionables (mismos del documento clásico). */
object ConsentAnesthesia {
    val TYPES = Consent.TYPES
}

/** Bloque tipado del documento. */
sealed class ConsentBlock {
    data class Header(val text: String) : ConsentBlock()
    data class Para(val text: String) : ConsentBlock()
    data class KeyValue(val key: String, val value: String) : ConsentBlock()
    data class Check(val checked: Boolean, val label: String) : ConsentBlock()
    data class Signature(val label: String) : ConsentBlock()
    object Divider : ConsentBlock()
}

object ConsentDoc {

    private fun blank(v: String) = v.ifBlank { "___________" }

    /** Construye el documento completo como bloques tipados. */
    fun buildBlocks(d: ConsentData, appVersion: String): List<ConsentBlock> = buildList {
        add(ConsentBlock.Header("CONSENTIMIENTO INFORMADO PARA ANESTESIA"))
        add(ConsentBlock.Para(
            "Marco legal y ético. Yo, como paciente (o su representante legal), ejerzo mi derecho a recibir " +
                "información veraz, completa y comprensible sobre el procedimiento anestésico propuesto, y a otorgar o " +
                "negar mi consentimiento de forma libre y voluntaria, conforme a la Ley No. 156 «De la Salud Pública» " +
                "de la República de Cuba, el Código de Ética Médica y los principios de la Declaración de Helsinki de la " +
                "Asociación Médica Mundial. Ningún procedimiento anestésico se realizará sin mi consentimiento informado, " +
                "salvo emergencia que comprometa la vida y me sea imposible expresar mi voluntad, situación que se " +
                "documentará en la historia clínica."
        ))
        add(ConsentBlock.Divider)

        add(ConsentBlock.Header("1. IDENTIFICACIÓN DEL PACIENTE"))
        add(ConsentBlock.KeyValue("Nombre y apellidos", blank(d.patientName)))
        add(ConsentBlock.KeyValue("Carné de identidad", blank(d.patientId)))
        add(ConsentBlock.KeyValue("Edad / Sexo", blank(d.patientAge) + " años · " + blank(d.patientSex)))
        if (d.representative.isNotBlank() || d.representativeRelation.isNotBlank()) {
            add(ConsentBlock.KeyValue("Representante legal", blank(d.representative) + " (" + d.representativeRelation + ")"))
        }
        add(ConsentBlock.KeyValue("Clasificación física ASA", d.asaClass.ifBlank { "____" }))

        add(ConsentBlock.Header("2. IDENTIFICACIÓN DEL PROFESIONAL Y DE LA INSTITUCIÓN"))
        add(ConsentBlock.KeyValue("Institución", blank(d.institution)))
        add(ConsentBlock.KeyValue("Servicio", blank(d.service)))
        add(ConsentBlock.KeyValue("Anestesiólogo responsable", blank(d.physician)))
        add(ConsentBlock.KeyValue("Licencia / Registro", blank(d.physicianLicense)))
        add(ConsentBlock.KeyValue("Lugar, fecha y hora", blank(d.place) + " · " + d.dateText.ifBlank { "____" } + " · " + d.timeText.ifBlank { "____" }))

        add(ConsentBlock.Header("3. DESCRIPCIÓN DEL PROCEDIMIENTO PROPUESTO"))
        add(ConsentBlock.KeyValue("Diagnóstico", blank(d.diagnosis)))
        add(ConsentBlock.KeyValue("Intervención quirúrgica", blank(d.procedure)))
        add(ConsentBlock.KeyValue("Técnica anestésica propuesta", d.anesthesiaTypeText + (if (d.technique.isNotBlank()) " — " + d.technique else "")))
        add(ConsentBlock.Para(
            "La anestesia es un acto médico que mediante fármacos y técnicas específicas suprime o bloquea la " +
                "sensibilidad y la conciencia (según la técnica) para permitir la cirugía de forma segura e indolora. " +
                "Incluye la vigilancia continua con monitorización de la actividad eléctrica del corazón, la presión " +
                "arterial, la oxigenación de la sangre (SpO2) y la concentración de CO2 espirado (capnografía), así como " +
                "la atención de la vía aérea, la administración de fluidos y medicamentos, y el cuidado en la " +
                "recuperación posanestésica hasta el alta de la sala de recuperación."
        ))

        add(ConsentBlock.Header("4. RIESGOS Y COMPLICACIONES POSIBLES"))
        add(ConsentBlock.Para(
            "A pesar de que la anestesia moderna es muy segura gracias a la monitorización continua y a los " +
                "protocolos de seguridad, ningún acto anestésico está exento de riesgos. Declaro haber sido informado(a), " +
                "en lenguaje claro, de los riesgos generales y de los específicos de la técnica propuesta, descritos a " +
                "continuación."
        ))
        add(ConsentBlock.Para("4.1 Riesgos generales (cualquier técnica anestésica)"))
        add(ConsentBlock.Para(Consent.RISKS_COMMON.joinToString("\n") { "•  $it" }))
        val t = d.anesthesiaType.coerceIn(0, ConsentAnesthesia.TYPES.size - 1)
        val specific: List<String> = when (t) {
            0, 1 -> Consent.RISKS_GENERAL
            2, 3 -> Consent.RISKS_NEURAXIAL
            4 -> Consent.RISKS_SEDATION
            else -> Consent.RISKS_REGIONAL
        }
        val title = when (t) {
            0, 1 -> "4.2 Riesgos específicos de la anestesia general"
            2, 3 -> "4.2 Riesgos específicos de la técnica neuraxial (raquídea/epidural)"
            4 -> "4.2 Riesgos específicos de la sedación"
            else -> "4.2 Riesgos específicos del bloqueo regional periférico"
        }
        add(ConsentBlock.Para(title))
        add(ConsentBlock.Para(specific.joinToString("\n") { "•  $it" }))
        add(ConsentBlock.Para("4.3 Riesgos graves excepcionales"))
        add(ConsentBlock.Para(
            "•  Reacción anafiláctica grave a fármacos (aproximadamente 1 de cada 10 000–20 000 anestesias), con equipo de reanimación disponible de inmediato.\n" +
                "•  Paro cardíaco o daño cerebral por hipoxia (extremadamente raro).\n" +
                "•  Muerte atribuible exclusivamente a la anestesia (menos de 1 de cada 100 000–200 000 anestesias según las series internacionales).\n" +
                "•  Complicaciones derivadas de condiciones previas del paciente (enfermedad cardíaca, pulmonar, renal, diabetes, obesidad, vía aérea difícil) que aumentan individualmente los riesgos anteriores."
        ))

        add(ConsentBlock.Header("5. BENEFICIOS ESPERADOS"))
        add(ConsentBlock.Para(
            "Realizar el procedimiento quirúrgico o diagnóstico de forma indolora y segura, con la mayor comodidad " +
                "posible, control de las funciones vitales durante toda la intervención y tratamiento del dolor " +
                "postoperatorio mediante técnicas y fármacos específicos."
        ))

        add(ConsentBlock.Header("6. ALTERNATIVAS DISPONIBLES"))
        add(ConsentBlock.Para(
            "Se me ha explicado que existen, cuando el procedimiento lo permite, técnicas anestésicas alternativas " +
                "(por ejemplo: anestesia regional en lugar de general, o viceversa) y sus ventajas e inconvenientes. " +
                "También se me ha explicado la alternativa de NO realizarme el procedimiento anestésico, que implica " +
                "renunciar a la cirugía o al diagnóstico propuesto, con las consecuencias que el especialista tratante " +
                "me ha informado sobre mi salud."
        ))

        add(ConsentBlock.Header("7. DERECHOS DEL PACIENTE"))
        add(ConsentBlock.Para(
            "•  Recibir toda la información que solicite y hacer las preguntas que considere necesarias antes de firmar.\n" +
                "•  Revocar este consentimiento en cualquier momento antes del procedimiento, sin que ello afecte la calidad de la atención que recibiré.\n" +
                "•  Solicitar una segunda opinión sobre el plan anestésico.\n" +
                "•  Que un familiar o acompañante esté informado, si así lo deseo.\n" +
                "•  Recibir el tratamiento del dolor postoperatorio y comunicar cualquier molestia durante la recuperación."
        ))

        add(ConsentBlock.Header("8. DECLARACIÓN Y AUTORIZACIÓN"))
        add(ConsentBlock.Para(
            "Declaro que he leído (o me ha sido leído) este documento, que comprendo su contenido, que se me ha " +
                "explicado la naturaleza del procedimiento anestésico, sus riesgos, beneficios y alternativas, y que se " +
                "han respondido todas mis preguntas de forma satisfactoria. Autorizo de forma libre y expresa al equipo " +
                "anestésico a realizar la técnica descrita y las medidas concomitantes que el procedimiento requiera " +
                "(vía aérea, canalización venosa, monitorización, transfusión de hemoderivados si fuese estrictamente " +
                "necesaria para la vida)."
        ))
        add(ConsentBlock.Check(d.consentTransfusion, "Autorizo la transfusión de hemoderivados si el equipo la considera estrictamente necesaria."))
        add(ConsentBlock.Check(d.consentTeaching, "Autorizo el uso docente y académico de los datos e imágenes de este procedimiento, manteniendo la confidencialidad."))

        add(ConsentBlock.Header("9. FIRMAS"))
        add(ConsentBlock.Signature("Paciente (o representante legal): " + blank(d.patientName)))
        if (d.representative.isNotBlank()) add(ConsentBlock.Signature("Representante legal: " + d.representative))
        add(ConsentBlock.Signature("Anestesiólogo responsable: " + blank(d.physician)))
        add(ConsentBlock.Signature("Testigo: " + blank(d.witness)))
        add(ConsentBlock.Divider)
        add(ConsentBlock.Para(
            "El original se archiva en la historia clínica y se entrega copia al paciente. Documento generado por " +
                "Cronos Anestesia" + (if (appVersion.isNotBlank()) " v" + appVersion else "") +
                " como apoyo a la práctica clínica; su validez formal se ajusta a la normativa vigente de la institución."
        ))
    }

    /** Documento plano (vista previa y copia al portapapeles). */
    fun buildText(d: ConsentData, appVersion: String): String =
        buildBlocks(d, appVersion).joinToString("\n\n") { b ->
            when (b) {
                is ConsentBlock.Header -> b.text
                is ConsentBlock.Para -> b.text
                is ConsentBlock.KeyValue -> "${b.key}: ${b.value}"
                is ConsentBlock.Check -> (if (b.checked) "[X] " else "[ ] ") + b.label
                is ConsentBlock.Signature -> "______________________  ${b.label}"
                ConsentBlock.Divider -> "— — — — — — — — — — — — — — — — — —"
            }
        }

    /** Líneas de resumen (etiqueta → valor) para guardar en el expediente. */
    fun summaryLines(d: ConsentData): List<Pair<String, String>> = buildList {
        add("Documento" to "Consentimiento informado para anestesia")
        add("Paciente" to blank(d.patientName) + " · CI: " + blank(d.patientId))
        if (d.diagnosis.isNotBlank()) add("Diagnóstico" to d.diagnosis)
        add("Intervención" to blank(d.procedure))
        add("Técnica" to d.anesthesiaTypeText + (if (d.technique.isNotBlank()) " — " + d.technique else ""))
        add("ASA" to d.asaClass.ifBlank { "—" })
        add("Lugar y fecha" to blank(d.place) + " · " + d.dateText.ifBlank { "—" } + " " + d.timeText.ifBlank { "" })
        add("Anestesiólogo" to blank(d.physician) + (if (d.physicianLicense.isNotBlank()) " (Lic. " + d.physicianLicense + ")" else ""))
        add("Transfusión" to if (d.consentTransfusion) "autorizada" else "no autorizada")
        add("Docencia" to if (d.consentTeaching) "autorizada" else "no autorizada")
    }
}
