package cu.cronos.anestesia

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashGuard.install(this)
        enableEdgeToEdge()
        setContent {
            var crashLog by remember { mutableStateOf(CrashGuard.readLog(this)) }
            val settings by SettingsRepo.flow(this).collectAsState(initial = AppSettings.DEFAULT)
            val licState by LicenseRepo.stateFlow(applicationContext)
                .collectAsState(initial = LicenseRepo.initial())

            CronosTheme(settings) {
                CompositionLocalProvider(LocalLicense provides licState) {
                val log = crashLog
                if (log != null) {
                    SafeModeScreen(
                        log = log,
                        onDismiss = {
                            CrashGuard.clearLog(this)
                            crashLog = null
                        },
                        onReset = {
                            CrashGuard.clearLog(this)
                            crashLog = null
                        }
                    )
                } else {
                    // Portada de 3 s (tap para saltar) y deep link inicial (cronos://sección).
                    val version = remember { appVersionText() }
                    val initialTab = remember { DeepLinks.tabFor(intent?.data?.host) ?: 0 }
                    var showSplash by remember { mutableStateOf(true) }
                    if (showSplash) {
                        SplashScreen(appVersion = version, onDone = { showSplash = false })
                    } else {
                        CronosApp(appVersion = version, initialTab = initialTab)
                    }
                }
                }
            }
        }
    }

    private fun appVersionText(): String = try {
        val pi = packageManager.getPackageInfo(packageName, 0)
        val code = if (android.os.Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
        "v${pi.versionName} (versionCode $code)"
    } catch (_: Throwable) {
        "versión desconocida"
    }
}
