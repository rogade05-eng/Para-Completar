package cu.cronos.anestesia

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * CrashGuard: captura cualquier caída no controlada y guarda el reporte
 * en almacenamiento persistente antes de que el proceso muera. Al reabrir
 * la app se muestra el Modo Seguro con el reporte y acciones de recuperación.
 */
object CrashGuard {

    private const val LOG_NAME = "cronos_crash_log.txt"
    private const val DATASTORE_DIR = "datastore"

    fun install(ctx: Context) {
        val systemHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try { write(ctx, throwable) } catch (_: Throwable) { }
            try { systemHandler?.uncaughtException(thread, throwable) } catch (_: Throwable) { }
            Runtime.getRuntime().exit(2)
        }
    }

    private fun write(ctx: Context, t: Throwable) {
        val sw = StringWriter()
        t.printStackTrace(PrintWriter(sw))
        val sb = StringBuilder()
        sb.append("=== REPORTE DE FALLA — Cronos Anestesia ===\n")
        sb.append("Fecha: ").append(SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())).append('\n')
        sb.append("Dispositivo: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
            .append(" (Android ").append(Build.VERSION.RELEASE).append(", SDK ").append(Build.VERSION.SDK_INT).append(")\n")
        sb.append("App: ").append(appVersion(ctx)).append("\n\n")
        sb.append(sw.toString())
        val text = sb.toString()
        try { File(ctx.filesDir, LOG_NAME).writeText(text) } catch (_: Throwable) { }
        try {
            ctx.getExternalFilesDir(null)?.let { ext ->
                val f = File(ext, LOG_NAME)
                f.writeText(text)
            }
        } catch (_: Throwable) { }
    }

    private fun appVersion(ctx: Context): String = try {
        val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        val code = if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
        "v${pi.versionName} (versionCode $code)"
    } catch (_: Throwable) { "versión desconocida" }

    fun readLog(ctx: Context): String? {
        val candidates = listOfNotNull(
            File(ctx.filesDir, LOG_NAME),
            ctx.getExternalFilesDir(null)?.let { File(it, LOG_NAME) }
        )
        for (f in candidates) {
            try {
                if (f.exists() && f.length() > 0) return f.readText()
            } catch (_: Throwable) { }
        }
        return null
    }

    fun clearLog(ctx: Context) {
        try { File(ctx.filesDir, LOG_NAME).delete() } catch (_: Throwable) { }
        try { ctx.getExternalFilesDir(null)?.let { File(it, LOG_NAME).delete() } } catch (_: Throwable) { }
    }

    /** Borra las preferencias (DataStore) para restaurar la configuración por defecto. */
    fun resetSettings(ctx: Context) {
        try {
            val dir = File(ctx.filesDir, DATASTORE_DIR)
            dir.listFiles()?.forEach { it.delete() }
            dir.delete()
        } catch (_: Throwable) { }
        try {
            ctx.getSharedPreferences("cronos_settings", Context.MODE_PRIVATE).edit().clear().apply()
        } catch (_: Throwable) { }
    }
}

@Composable
fun SafeModeScreen(
    log: String,
    onDismiss: () -> Unit,
    onReset: () -> Unit
) {
    val ctx = LocalContext.current
    var showResetDialog by remember { mutableStateOf(false) }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                "Modo seguro",
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                "La aplicación se cerró inesperadamente la última vez. " +
                    "Puedes compartir el reporte técnico para diagnóstico o restablecer los ajustes " +
                    "a los valores por defecto. El contenido clínico no se ve afectado.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Text(
                    log,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // --- Botones emparejados: anchos iguales garantizados ---
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = { shareLog(ctx, log) },
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                ) { Text("Compartir") }
                OutlinedButton(
                    onClick = { copyLog(ctx, log) },
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                ) { Text("Copiar") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                ) { Text("Abrir la aplicación") }
                OutlinedButton(
                    onClick = { showResetDialog = true },
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                ) { Text("Restablecer ajustes") }
            }
            Spacer(Modifier.heightIn(min = 12.dp))
        }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("Restablecer ajustes") },
            text = { Text("Se borrarán tema, tamaño de letra, densidad y botones grandes. ¿Continuar?") },
            confirmButton = {
                TextButton(onClick = {
                    CrashGuard.resetSettings(ctx)
                    CrashGuard.clearLog(ctx)
                    Toast.makeText(ctx, "Ajustes restablecidos", Toast.LENGTH_SHORT).show()
                    showResetDialog = false
                    onReset()
                }) { Text("Restablecer") }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) { Text("Cancelar") }
            }
        )
    }
}

private fun shareLog(ctx: Context, log: String) {
    try {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Reporte de falla — Cronos Anestesia")
            putExtra(Intent.EXTRA_TEXT, log)
        }
        ctx.startActivity(Intent.createChooser(intent, "Compartir reporte"))
    } catch (_: Throwable) { }
}

private fun copyLog(ctx: Context, log: String) {
    try {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("cronos_crash", log))
        Toast.makeText(ctx, "Reporte copiado", Toast.LENGTH_SHORT).show()
    } catch (_: Throwable) { }
}
