package cu.cronos.anestesia

// =====================================================================
//  PERLAS CLÍNICAS (v2.0.0) — contenido educativo estructurado inspirado
//  en los videos del canal Medik Brain (Cristian González, médico general;
//  educación médica en Facebook/YouTube). Cada perla fue elaborada y
//  adaptada al perioperatorio por Cronos Anestesia y verificada contra
//  la bibliografía de la app: no reproducimos el video, destilamos su
//  lección clínica para uso offline en guardia y quirófano.
// =====================================================================

data class Pearl(
    val titulo: String,
    val video: String,        // video que inspira la perla (canal Medik Brain)
    val resumen: String,
    val claves: List<String>, // pasos/claves accionables
    val errores: String,      // errores comunes
    val alarma: String,       // señales de alarma / cuando escalar
    val aplicacion: String    // aplicación específica en anestesia
)

const val PEARLS_CANAL = "Medik Brain"

val PEARLS_RAW = listOf(
    Pearl(
        "Colapso hemodinámico post-intubación",
        "«¡Intubación exitosa… pero 5 minutos después el paciente hace paro cardíaco!»",
        "Una intubación técnicamente perfecta puede terminar en catástrofe hemodinámica: la intubación NO termina cuando el tubo pasa las cuerdas vocales. En el paciente crítico, la sedación, la pérdida del tono simpático y el inicio de la ventilación con presión positiva precipitan hipotensión grave y paro cardíaco en los minutos siguientes.",
        listOf(
            "1. Evaluar y optimizar la hemodinamia ANTES de administrar los inductores (volumen, vasopresor listo, PAM objetivo).",
            "2. Preoxigenar adecuadamente y evitar la hipoxemia (O2 al 100 %, apneica nasal durante la laringoscopia).",
            "3. Maximizar el éxito al primer intento: plan A/B definidos, operador mejor entrenado al frente.",
            "4. Ajustar los fármacos de inducción al estado hemodinámico: dosis reducida y titulada (etomidato 0,15–0,2 mg/kg o ketamina 0,5–1 mg/kg en shock; propofol a dosis plena está contraindicado en hipovolemia).",
            "5. Cargar el paciente: vasopresor profiláctico (fenilefrina/noradrenalina) o infusión baja iniciada antes del inductor en el crítico."
        ),
        "Usar la dosis estándar de propofol en el paciente séptico o hipovolémico; interpretar la caída de la PA como «normal de la anestesia» y reaccionar tarde; intubar con la única meta de «pasar el tubo» sin plan hemodinámico; olvidar que la presión positiva reduce el retorno venoso.",
        "PAM <65 mmHg tras la inducción, caída súbita del EtCO2, SpO2 descendente persistente, bradicardia con hipotensión (paro inminente): anunciarlo en voz alta, detener fármacos, volumen + vasopresor, y si avanza iniciar RCP sin demora.",
        "Antes de intubar al paciente con neumonía grave (SpO2 84 %, PA 85/50): optimizar volumen, preparar noradrenalina diluida, elegir etomidato/ketamina en dosis reducida, tener adrenalina lista. En la sala: la secuencia «inducción segura» vale más que la rapidez."
    ),
    Pearl(
        "Desaturación post-intubación",
        "«Post-Intubation Desaturation»",
        "La SpO2 que baja después de una intubación correcta es un problema de OXIGENACIÓN, no de posición del tubo en la mayoría de los casos: atelectasias, hipoxemia por shunt, hipovolemia y bajo gasto. El enfoque es sistemático: DOPE para excluir causa mecánica y luego reclutar, optimizar la hemodinamia y revisar el ventilador.",
        listOf(
            "1. DOPE: tubo desplazado (D), obstruido (O), neumotórax (P), equipo/falla (E) — auscultar y verificar capnografía.",
            "2. FiO2 al 100 % y manual con bolsa: ¿mejora? el problema era la programación.",
            "3. Maniobra de reclutamiento + PEEP 5–10 cmH2O (cuidado en hipovolemia y TCE).",
            "4. Revisar la hemodinamia: el shunt empeora con el bajo gasto — volumen/vasopresor.",
            "5. Posicionamiento: decúbito prono o lateral si hay atelectasias masivas; succión de secreciones.",
            "6. En OLV: CPAP al pulmón no dependiente y PEEP al dependiente (ver tema quirúrgico)."
        ),
        "Aumentar la FiO2 y esperar; olvidar el neumotórax a tensión; hiperventilar con presiones altas (barotrauma); descartar la causa mecánica solo con la «visión» del tubo.",
        "Desaturación que no responde a FiO2 100 % + reclutamiento, asimetría de ruidos, hipotensión asociada (sospechar neumotórax a tensión: descompresión inmediata), caída brusca del EtCO2 (embolia).",
        "En el paciente obeso o con FRC baja la desaturación ocurre en segundos: preoxigenación prolongada + posición rampa + O2 nasal apneico son obligatorios. Tras la intubación, ventilación con VT 6–8 mL/kg IBW y PEEP moderada previene la atelectasia."
    ),
    Pearl(
        "Cómo programar un ventilador mecánico",
        "«How to Program a Mechanical Ventilator»",
        "La ventilación protectora es el estándar en TODO paciente anestesiado, no solo en el SDRA: volumen tidal 6–8 mL/kg del PESO IDEAL (nunca del real), presión de meseta <30 cmH2O, driving pressure <15 cmH2O y PEEP suficiente para evitar el colapso alveolar cíclico.",
        listOf(
            "1. Calcular el peso ideal (Devine) y fijar VT 6–8 mL/kg IBW.",
            "2. Frecuencia respiratoria inicial 12–14/min (ajustar al EtCO2 35–40 mmHg).",
            "3. PEEP 5 cmH2O basal; 8–12 en obesidad, laparoscopía y Trendelenburg.",
            "4. FiO2 mínima que mantenga SpO2 92–96 % (evitar atelectasia por absorción y oxidativos).",
            "5. Verificar la MESETA cada cambio de posición o de insuflación (<30 cmH2O) y el driving pressure (<15).",
            "6. I:E 1:2 (1:3 en obstructivos); flujo insuficiente suficiente para no alargar la espiración."
        ),
        "Programar el VT por peso total en el obeso (sobreinsuflación); dejar FiO2 100 % «por seguridad»; ignorar la presión de meseta; olvidar la PEEP en Trendelenburg y neumoperitoneo; hiperventilar por rutina.",
        "Presión de meseta >30, driving >15, EtCO2 >50 en no neurológico, SpO2 <90 % sostenida, asimetría de ruidos, sub-elevación del tórax: parar y reevaluar el circuito completo.",
        "En la sala el ajuste mínimo diario: IBW calculada, VT 6–8, PEEP 5–10, RR al EtCO2, FiO2 al SpO2. Regla práctica: ante hipoxemia → reclutar + PEEP; ante hipercapnia → subir FR, no el VT."
    ),
    Pearl(
        "Embolismo pulmonar agudo",
        "«Acute Pulmonary Embolism 2026»",
        "El TEP perioperatorio es la gran imitadora: hipoxemia + hipotensión + EtCO2 que cae, sin ruidos anormales. La sospecha intraoperatoria se basa en el cuadro capnográfico y la ecografía: el tratamiento anticoagulante en el paciente operado exige balance entre sangrado y muerte.",
        listOf(
            "1. Sospechar ante caída súbita del EtCO2 + hipoxia + taquicardia + hipotensión (especialmente postoperatorio, inmovilizados, oncológicos, obstétricas).",
            "2. Ecografía a la cabecera: VD dilatado y septo paradójico confirman el impacto hemodinámico.",
            "3. Hipoxemia: FiO2 100 %; hipotensión: noradrenalina (evitar volumen excesivo: el VD está fallando).",
            "4. Anticoagulación: heparina no fraccionada en bolo 80 UI/kg + infusión 18 UI/kg/h (reversible y monitorizable).",
            "5. Trombólisis si hay paro o inestabilidad refractaria: en el quirófano la decisión se coordina con el equipo quirúrgico.",
            "6. Prevenir: profilaxis mecánica/farmacológica según riesgo, movilización precoz, evaluar el momento de suspender/reiniciar anticoagulantes."
        ),
        "Atribuir la hipoxemia del postoperatorio a «atelectasia» sin revisar la PA y el EtCO2; dar volumen masivo a un VD ya distendido; demorar la anticoagulación por miedo al lecho quirúrgico sin evaluar el riesgo real.",
        "EtCO2 <20 con hipoxia, VD dilatado en eco, PVD sin causa, shock + taquicardia + hipoxia: activar el protocolo de TEP masivo (trombólisis o embolectomía según centro).",
        "En obstetricia el TEP es causa principal de muerte materna: sospecharlo en toda posparto con disnea súbita; en cesárea con hipoxemia e hipotensión, descartar embolia amniótica (coagulopatía asociada)."
    ),
    Pearl(
        "Taponamiento cardíaco",
        "«Taponamiento Cardiaco: Lo que todo Médico General…»",
        "Triada de Beck (hipotensión + ruidos apagados + ingurgitación yugular), pulso paradójico y shock con corazón «vacío» en la eco: la pericardiocentesis salva vidas en minutos. En el perioperatorio aparece post-CEC, tras trauma torácico, en neoplasias y en pericarditis uremica/viral.",
        listOf(
            "1. Reconocer el patrón: hipotensión + turgencia + pulso paradójico >10 mmHg.",
            "2. Eco a la cabecera: derrame + colapso diastólico del VD/AD, VCI dilatada sin colapso, variación del flujo transmitral.",
            "3. Soporte: volumen (aumenta la precarga), noradrenalina; INOTRÓPICOS evitables (taquicardia es compensadora: no usar β-bloqueantes).",
            "4. Pericardiocentesis: subxifoidea con guía eco si es posible; en post-CEC reesternotomía del equipo quirúrgico.",
            "5. Anestesia para drenaje: SOLO cuando el paciente esté estable; inducción con ketamina/etomidato a dosis reducidas — cualquier vasodilatación puede causar paro.",
            "6. Corregir el coagulograma y tener sangre disponible antes del drenaje quirúrgico."
        ),
        "Tratar la hipotensión con vasodilatadores o PEEP alta; usar propofol en dosis estándar para inducir (paro garantizado); demorar la pericardiocentesis esperando «estudios»; confundirlo con shock séptico o hipovolemia.",
        "Pulso paradójico en PA invasiva (variación >10 mmHg con la respiración), EtCO2 que cae, PA con variación respiratoria extrema: taponamiento hasta que se demuestre lo contrario.",
        "Tras cirugía cardíaca: todo paciente con bajo gasto y VCI dilatada que no responde a inotrópicos merece eco inmediato (coágulo en el pericardio). En trauma penetrante precordial: pericardiocentesis en la reanimación."
    ),
    Pearl(
        "Disección aórtica aguda",
        "«Disección Aórtica»",
        "El objetivo terapéutico es REDUCIR LA FUERZA DE EXPULSIÓN ventricular (dP/dt): primero β-bloqueo (esmolol) y solo después vasodilatador. Controlar la PA antes de mover al paciente, hacer eco (aorta raíz, pericardio, insuficiencia aórtica) y diferir el quirófano solo si la vida del paciente depende de estabilizar otro problema.",
        listOf(
            "1. Controlar el dolor y la PA: objetivo FC <60 lpm y PAS 100–120 mmHg.",
            "2. β-bloqueante ANTES del vasodilatador (esmolol 500 µg/kg carga + 50–200 µg/kg/min) — el vasodilatador solo aumenta el reflejo y el dP/dt.",
            "3. Después: nitroprusiato o nitroglicerina para bajar la PA (si hay insuficiencia aórtica: evitar volumen).",
            "4. Ecocardiograma: raíz aórtica, pericardio, function del VI (tipo A: quirófano urgente).",
            "5. Analgesia profunda: el dolor dispara la PA y puede propagar la disección.",
            "6. Monitorización en ambas extremidades (la disección puede comprometer un subclavio: la PA «falsa baja» engaña)."
        ),
        "Bajar la PA solo con vasodilatadores sin β-bloqueo previo; aceptar taquicardia «por el dolor»; intubar con hipertensión no controlada; medir la PA solo en un brazo; usar volumen masivo si hay insuficiencia aórtica.",
        "Dolor desgarrante migratorio + déficit neurológico o isquemia de un miembro + hipotensión súbita (rotura a pericardio): toracotomía/cirugía inmediata.",
        "Inducción: etomidato + esmolol + fentanilo a dosis plenas para suprimir la laringoscopia; PA invasiva antes de inducir; en CEC el equipo debe conocer la estrategia de perfusión (femoral vs axilar)."
    ),
    Pearl(
        "Hemorragia posparto",
        "«Hemorragia Posparto»",
        "La HPP es la principal causa de muerte materna evitable: pérdida >500 mL tras el parto vaginal o >1000 mL en cesárea. La respuesta es un PROTOCOLO con roles definidos: uterotónicos escalonados, reposición guiada, transfusión masiva 1:1:1 y ácido tranexámico temprano.",
        listOf(
            "1. Prevenir: riesgo identificado (atonia previa, macerosoma, corioamnionitis, acreta) → acceso venoso grande + tipificación cruzada.",
            "2. Detectar temprano: cuantificar la pérdida real (pesar el paño, no estimar) y vigilar signos de shock (taquicardia PRIMERO, hipotensión TARDÍA en la parturienta).",
            "3. Tratar las 4 T: Tono (masaje + oxitocina 2–5 UI bolo lento + 20–40 UI/500 mL infusión → carbetocina 100 µg → metilergonovina 0,2 mg → misoprostol 800 µg SL → prostaglandina F2α), Tejido (placenta retenida), Trauma (revisión canal/sutura), Trombina (coagulopatía).",
            "4. Ácido tranexámico 1 g IV en 10 min dentro de la primera hora (estudio WOMAN: reduce la muerte por sangrado).",
            "5. Protocolo transfusión masiva: CGR:PFP:PLT 1:1:1; fibrinógeno (crioprecipitado) si hay hipofibrinogenemia; corregir hipotermia, acidosis e hipocalcemia.",
            "6. Escalado: balón de tamponamiento uterino → laparotomía (compresión aórtica, B-Lynch, hysterectomía) si no hay respuesta."
        ),
        "Subestimar la pérdida visualmente (siempre 30–50 % menos que la real); esperar a que la PA caiga (la parturienta compensa hasta perder 30–40 % del volumen); dar oxitocina en bolo rápido (hipotensión); demorar el ácido tranexámico.",
        "Taquicardia + paño empapado, coagulograma con fibrinógeno <200 mg/dL (sangrado activo), shock que no responde a 2 L de cristaloide, sangrado difuso por los sitios de punción (CID): activar protocolo de hemorragia masiva.",
        "Anestesia: mientras la parturienta esté estable mantener el bloqueo neuraxial; ante shock pasar a anestesia general con inducción ajustada al volumen (ketamina/etomidato, dosis reducidas); NO limitar el acceso vascular: dos vías gruesas desde el inicio en toda cesárea de riesgo."
    ),
    Pearl(
        "Hipertensión intracraneal",
        "«Intracranial Hypertension»",
        "La PIC >20 mmHg sostenida amenaza la perfusión cerebral: el objetivo es CPP >60 mmHg (PAM − PIC). El manejo es escalonado y MIDE: cabeza a 30°, control del dolor/temblor, osmoterapia y, solo temporal, hiperventilación.",
        listOf(
            "1. Posición: cabeza elevada 30° y cuello neutro (mejora el drenaje venoso).",
            "2. Analgesia/sedación suficientes; evitar la tos y la tensión en el tubo (lidocaína antes de succión).",
            "3. Osmoterapia: manitol 0,25–1 g/kg IV (vigilar osmolalidad <320 y diuresis) o NaCl 3 % 250 mL/2–3 mL/kg; el objetivo es la osmolalidad, no la repetición ciega.",
            "4. Hiperventilación TRANSITORIA (PaCO2 30–35 mmHg) solo en herniación inminente: la vasoconstricción empeora la isquemia si se mantiene.",
            "5. Evitar hiponatremia, hipovolemia e hipoxia; glucemia 140–180 mg/dL; fiebre = enemigo (paracetamol, enfriamiento).",
            "6. Neuromuscular si hay tensión/temblor; PIC monitorizada en todo GCS ≤8."
        ),
        "Usar cristaloides hipotónicos o SG5 % (edema cerebral); hiperventilar de rutina «por costumbre»; aceptar la fiebre postoperatoria; dar bajas la PIC con PEEP excesiva o presión de meseta alta; olvidar la glucemia.",
        "Anisocoria pupilar, postura de descerebración, Cushing (HTA + bradicardia + respiración irregular), GCS que cae 2 puntos: herniación — osmoterapia YA y alerta al cirujano.",
        "Anestesia neuroquirúrgica: inducción sin hipertensión ni tos (fentanilo/lidocaína/esmolol), PEEP la mínima eficaz, Trendelenburg evitado, NaCl 0,9 % como fluido de elección, extubación suave (remifentanilo, lidocaína, evitar la tensión)."
    ),
    Pearl(
        "Hemorragia subaracnoidea",
        "«Hemorragia Subaracnoidea»",
        "La HSA aneurismática tiene dos ventanas de muerte: el rebleeding (primeras horas) y el vasoespasmo retardado (días 3–14). El anestesiólogo controla la PA en la inducción (evitar el rebleeding), mantiene el CPP y participa en el manejo del vasoespasmo y las complicaciones cardíacas.",
        listOf(
            "1. Control estricto de la PA: ni hipertensión (rebleeding) ni hipotensión (isquemia): objetivo individualizado, «mediana» de la PA del paciente.",
            "2. Nimodipino 60 mg VO c/4 h durante 21 días (prevención del vasoespasmo; vigilar hipotensión).",
            "3. Hipervolemia moderna: euvolemia + CPP >60; la «hipervolemia agresiva» clásica ya no se recomienda.",
            "4. Vigilar complicaciones cardíacas: troponinas elevadas, síndrome de Takotsubo, edema neurogénico pulmonar.",
            "5. Hidrocefalia aguda: drenaje ventricular externo antes de la cirugía si hay deterioro.",
            "6. Electrolitos: hiponatremia por SIADH/cerebral salt wasting — medir y tratar según el diagnóstico."
        ),
        "Inducir con hipertensión de la laringoscopia (rebleeding); bajar la PA «por protocolo» y causar isquemia; ignorar las troponinas; dar volumen masivo indiscriminado.",
        "Cefalea súbita «el peor dolor de mi vida» + rigidez + deterioro del nivel de conciencia + hidrocefalia en CT: derivación urgente; nueva caída focal en días 4–10 = sospechar vasoespasmo.",
        "Inducción para clipaje: PA invasiva antes de inducir, esmolol/lidocaína para la laringoscopia, TIVA con propofol, manitol preparado, PA objetivo 20–30 % por debajo del basal tras el clip (coordina con el cirujano)."
    ),
    Pearl(
        "Hiperkalemia en urgencias",
        "«Hyperkalemia in the Emergency Room»",
        "La hiperkalemia mata por arritmia: el ECG manda sobre el número. El tratamiento tiene tres pilares que no deben mezclarse: ESTABILIZAR la membrana (calcio), DESPLAZAR el K a la célula (insulina + glucosa, β2-agonista) y ELIMINAR el K (resina, diálisis). En el perioperatorio, la succinilcolina y la acidosis respiratoria son desencadenantes clásicos.",
        listOf(
            "1. ECG primero: ondas T picadas → QRS ancho → onda sine (paro inminente).",
            "2. Estabilizar la membrana: gluconato de calcio 1 g (o cloruro de calcio por vía central) IV en 2–3 min; repetir si el ECG no mejora en 5 min.",
            "3. Desplazar: insulina regular 10 UI + glucosa 25–50 g IV (vigilar glucemia 1–2 h); salbutamol nebulizado 10–20 mg en hiperkalemia grave.",
            "4. Bicarbonato SOLO si hay acidosis metabólica documentada (ya no se usa de rutina).",
            "5. Eliminar: furosemida + SF si hay diuresis; resina de intercambio (patriomero/ciclosulfato) o diálisis si hay insuficiencia renal.",
            "6. Prevenir en el perioperatorio: NO succinilcolina si K >5,5 mmol/L; monitorizar K en trauma, quemados, parálisis y ERC."
        ),
        "Tratar el número sin mirar el ECG; dar calcio sin plan de desplazamiento/eliminación (el efecto es corto); usar insulina sin glucosa (hipoglucemia retardada); olvidar que la hiperventilación empeora la K vía pH.",
        "K >6,5 mmol/L aunque el ECG sea «normal», cualquier cambio ECG, K >5,5 con suxametonía prevista, parálisis ascendente: tratamiento inmediato y monitoreo continuo.",
        "Antes de dar succinilcolina en ERC, trauma masivo, quemados >48 h o parálisis: medir K o usar rocuronio. En la CEC la hiperkalemia del cardioplejía y de la hemólisis requiere vigilancia en gasometrías seriadas."
    ),
    Pearl(
        "Tormenta tiroidea (crisis tirotoxica)",
        "«Tirotoxicosis y Tormenta Tiroidea»",
        "La tormenta tiroidea es una emergencia con mortalidad alta (Burch-Wartofsky >45 = alta probabilidad): fiebre, taquicardia desproporcionada, agitación/delirio y descompensación de un órgano. La anestesia en un tirotoxico no controlado puede desencadenarla: la regla es EUITIROIDEO antes de cirugía electiva.",
        listOf(
            "1. Reconocer: fiebre >38,5 °C, taquicardia >130, delirio, ictericia, falla cardíaca/digestiva en un hipertiroideo.",
            "2. β-bloqueo: propranolol 1 mg IV lento cada 5–10 min (o esmolol en infusión) — precaución en falla cardíaca.",
            "3. Bloquear la síntesis: propiltiouracilo 500–1000 mg VO c/6 h o metimazol 20–40 mg VO c/6 h.",
            "4. YODO una hora DESPUÉS del antitiroideo (bloquear la liberación; yodo antes = «combustible»).",
            "5. Corticoide: hidrocortisona 100 mg IV c/8 h (bloquea la conversión T4→T3 y cubre la insuficiencia suprarrenal).",
            "6. Soporte: enfriamiento (evitar aspirina: desplaza T4), paracetamol, volumen, O2, buscar el desencadenante (infección, parto, cirugía)."
        ),
        "Operar a un hipertiroideo no controlado; dar yodo antes del antitiroideo; usar aspirina para la fiebre; interpretar la taquicardia como «ansiedad» y no tratarla.",
        "Taquicardia >130 con fiebre en hipertiroideo, delirio postoperatorio inexplicado, falla cardíaca de nueva aparición: tratar como tormenta (no esperar el laboratorio).",
        "Preoperatorio: eutiroidismo documentado (T4/T3 normales) antes de cirugía electiva; β-bloqueo continuado hasta el quirófano; evitar atropina, ketamina y anticolinérgicos; en la cirugía de tiroides vigilar laringoscopía (nervio laríngeo recurrente) y hemorragia compresiva."
    ),
    Pearl(
        "Choque cardiogénico",
        "«Choque Cardiogénico» / «Cardiogenic Shock 2026»",
        "Bajo gasto + congestión + hipoperfusión: la clave es identificar la CAUSA (SCA, miocarditis, descompensación, arritmia) y apoyar con inotrópicos/vasopresores mientras se ataca el origen. El volumen debe ser cauteloso: el corazón fallado no tolera la precarga excesiva.",
        listOf(
            "1. Eco inmediata: función del VI, VD, válvulas, derrame (excluir taponamiento y TEP masivo).",
            "2. Noradrenalina como vasopresor de base (PAM ≥65); inotrópico: dobutamina 2–20 µg/kg/min (o milrinona 0,375–0,75 µg/kg/min si hay HTAP o β-bloqueo).",
            "3. Revascularización URGENTE si hay SCA como causa (el pronóstico depende de abrir la arteria).",
            "4. Volumen: bolos de 200–250 mL solo si hay signos de hipovolemia; los congestivos (crépitos, VCI dilatada) reciben diurético, no volumen.",
            "5. Escalar si no responde: combinación inotrópico+vasopresor, dispositivo de asistencia (balón contrapulsante, ECMO) según disponibilidad.",
            "6. Vigilar arritmias: cardioversión eléctrica temprana en cualquier inestabilidad."
        ),
        "Dar volumen masivo a un paciente edémico; usar dopamina «renal» (no mejora nada y aumenta la arritmia); demorar la eco; esperar la troponina antes de revascularizar; mantener al paciente en taquicardia «para mantener el gasto».",
        "PAM <65 + frío + oliguria + crepitantes + VCI dilatada en eco: choque cardiogénico establecido; lactato que sube a pesar del tratamiento = mal pronóstico: escalar.",
        "En el quirófano: inducción con etomidato + fentanilo en dosis reducidas y tituladas, evitar PEEP alta (↓ retorno) y la hipercapnia (↑ RVP), monitorización invasiva desde el inicio; al postoperatorio: UCI con inotrópicos programados."
    ),
    Pearl(
        "Cetoacidosis (y la euglucémica de los SGLT2)",
        "«Euglycemic Ketoacidosis»",
        "La cetoacidosis diabética clásica (hiperglucemia + cetonas + acidosis) y la variante EUGLUCÉMICA de los inhibidores de SGLT2 (glucemia <250 con acidosis grave) son trampas perioperatorias: el paciente «con azúcar normal» puede estar en CAD. Prevenir: suspender los SGLT2i 3 días antes de la cirugía.",
        listOf(
            "1. Sospechar: pacientes con SGLT2i (dapagliflozina, empagliflozina, canagliflozina), cirugía urgente, ayuno prolongado, vómitos.",
            "2. Confirmar con CETONAS (β-hidroxibutirato capilar o en orina) — la glucemia puede ser normal.",
            "3. Rehidratación: SF 0,9 % 15–20 mL/kg en la primera hora (la deshidratación es el mayor problema).",
            "4. Insulina IV regular 0,1 UI/kg/h (en euglucémica añadir dextrosa 5–10 % desde el inicio para poder insulinar sin hipoglucemia).",
            "5. Potasio: medir y reponer (la insulina lo baja); NO insulinar si K <3,3 mmol/L.",
            "6. El bicarbonato solo en pH <6,9; buscar el desencadenante (infección, IAM, omisión de insulina)."
        ),
        "Operar a un paciente con SGLT2i sin suspenderlo; confiar en la glucemia capilar «normal»; dar bicarbonato de rutina; ignorar el potasio; usar insulina SC en la fase aguda (absorción impredecible).",
        "Náuseas/vómitos + dolor abdominal + respiración de Kussmaul + anion gap alto en cualquier diabético (o en paciente con SGLT2i): cetoacidosis hasta que se demuestre lo contrario; diferir electivas.",
        "Regla de la sala: SGLT2i suspendidos 3 días antes (hoy es estándar en toda consulta preanestésica); en cirugía urgente medir cetonas; en la CAD en curso, la cirugía no electiva se hace con insulina IV en infusión y vigilancia horaria."
    )
)
