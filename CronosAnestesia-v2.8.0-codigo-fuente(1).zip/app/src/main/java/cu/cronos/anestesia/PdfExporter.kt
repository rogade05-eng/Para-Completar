// Exportador PDF de expedientes (v1.7.0) con android.graphics.pdf.PdfDocument.
// 100% offline, sin permisos; tamaños Carta y A4 seleccionables para impresión.
package cu.cronos.anestesia

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import java.io.OutputStream

object PdfExporter {

    const val SIZE_A4 = 0
    const val SIZE_LETTER = 1

    private const val MARGIN = 40f
    private val GREEN = 0xFF0B5E5B.toInt()

    fun pageSize(code: Int): Pair<Int, Int> =
        if (code == SIZE_LETTER) 612 to 792 else 595 to 842 // puntos (1/72")

    /** Etiqueta legible del tamaño elegido. */
    fun sizeLabel(code: Int): String = if (code == SIZE_LETTER) "Carta" else "A4"

    /**
     * Escribe el expediente del paciente en Carta o A4: cabecera con los datos
     * del paciente y una tarjeta por entrada (tipo, título, pares etiqueta→valor
     * y nota del profesional), con paginación manual y número de página.
     */
    fun writeExpediente(
        ctx: Context,
        out: OutputStream,
        sizeCode: Int,
        patient: RecPatient,
        entries: List<RecEntry>,
        appVersion: String,
        exportedAtText: String
    ) {
        val (pw, ph) = pageSize(sizeCode)
        val contentW = pw - 2 * MARGIN

        val headBarPaint = Paint().apply { color = GREEN }
        val headTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textSize = 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = GREEN; textSize = 15f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF5B7480.toInt(); textSize = 9f }
        val h2Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF17323B.toInt(); textSize = 11f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val keyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF155E75.toInt(); textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val valPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF17323B.toInt(); textSize = 9.5f }
        val cardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFF7FAFB.toInt() }
        val linePaint = Paint().apply { color = 0xFFDBE4E8.toInt(); strokeWidth = 0.8f; isAntiAlias = true }
        val footPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF5B7480.toInt(); textSize = 8.5f }

        val doc = PdfDocument()
        var pageNo = 0
        var page: PdfDocument.Page? = null
        var canvas: Canvas? = null
        var y = 0f

        fun stampFooter() {
            val p = page ?: return
            val c = canvas ?: return
            val label = "Página $pageNo"
            c.drawLine(MARGIN, ph - MARGIN + 10f, pw - MARGIN, ph - MARGIN + 10f, linePaint)
            c.drawText(label, pw - MARGIN - footPaint.measureText(label), ph - MARGIN + 24f, footPaint)
            c.drawText("Cronos Anestesia — expediente generado sin conexión", MARGIN, ph - MARGIN + 24f, footPaint)
        }

        fun closePage() {
            val p = page ?: return
            stampFooter()
            doc.finishPage(p)
            page = null
            canvas = null
        }

        fun newPage() {
            closePage()
            val info = PdfDocument.PageInfo.Builder(pw, ph, ++pageNo).create()
            page = doc.startPage(info)
            canvas = page!!.canvas
            y = MARGIN
            // Cabecera verde en cada página
            canvas!!.drawRect(0f, 0f, pw.toFloat(), 26f, headBarPaint)
            canvas!!.drawText("Cronos Anestesia — Expediente de paciente", MARGIN, 17.5f, headTextPaint)
            val tw = subPaint.measureText(appVersion)
            canvas!!.drawText(appVersion, pw - MARGIN - tw, 17.5f, subPaint)
            y = 40f
        }

        fun ensure(h: Float) {
            if (page == null || y + h > ph - MARGIN - 10f) newPage()
        }

        fun wrap(text: String, paint: Paint, indent: Float = 0f): List<String> {
            val maxW = contentW - indent
            val result = mutableListOf<String>()
            for (raw in text.split('\n')) {
                if (raw.isEmpty()) { result.add(""); continue }
                var line = ""
                for (word in raw.split(' ')) {
                    val cand = if (line.isEmpty()) word else "$line $word"
                    if (paint.measureText(cand) <= maxW || line.isEmpty()) line = cand
                    else { result.add(line); line = word }
                }
                result.add(line)
            }
            return result
        }

        fun drawWrapped(text: String, paint: Paint, indent: Float = 0f, lh: Float = paint.textSize * 1.35f) {
            for (ln in wrap(text, paint, indent)) {
                ensure(lh)
                canvas!!.drawText(ln, MARGIN + indent, y, paint)
                y += lh
            }
        }

        // ================= Primera página: datos del paciente =================
        newPage()
        drawWrapped(patient.name, titlePaint)
        val demo = listOf(
            if (patient.historyId.isNotBlank()) "Historia: ${patient.historyId}" else null,
            if (patient.ageText.isNotBlank()) "Edad: ${patient.ageText}" else null,
            if (patient.weightText.isNotBlank()) "Peso: ${patient.weightText}" else null,
            if (patient.sex.isNotBlank()) "Sexo: ${patient.sex}" else null
        ).filterNotNull().joinToString("   ·   ")
        if (demo.isNotEmpty()) drawWrapped(demo, subPaint, lh = 13f)
        if (patient.allergies.isNotBlank()) drawWrapped("Alergias: ${patient.allergies}", keyPaint, lh = 13f)
        if (patient.notes.isNotBlank()) drawWrapped("Notas: ${patient.notes}", subPaint, lh = 13f)
        drawWrapped("Exportado: $exportedAtText · ${entries.size} registro(s)", subPaint, lh = 13f)
        y += 6f

        // ================= Tarjetas de entradas =================
        entries.sortedBy { it.createdAt }.forEach { e ->
            val titleLines = wrap("${e.kind} · ${e.title}", h2Paint, 8f)
            val subLines = if (e.subtitle.isNotBlank()) wrap(e.subtitle, subPaint, 8f) else emptyList()
            val kv = mutableListOf<Pair<String, String>>()
            kv.add("Fecha del registro" to RecFmt.ts(e.createdAt))
            kv.addAll(e.lines)
            val kvRows = kv.map { (k, v) ->
                Triple(keyPaint.measureText("$k: "), k, wrap(v, valPaint, 8f + keyPaint.measureText("$k: ")))
            }
            val kvLineCount = kvRows.sumOf { it.third.size }
            val noteLines = if (e.note.isNotBlank()) wrap(e.note, valPaint, 8f) else emptyList()
            val cardH = 6f + titleLines.size * 14f + subLines.size * 12f + 4f +
                (if (kvLineCount > 0) kvLineCount * 12.5f + 4f else 0f) +
                (if (noteLines.isNotEmpty()) noteLines.size * 12f + 4f else 0f) + 8f

            // Tarjetas que no caben completas pasan a página nueva
            ensure(cardH)
            val top = y
            val bottom = (top + cardH).coerceAtMost(ph - MARGIN - 10f)
            canvas!!.drawRoundRect(RectF(MARGIN, top, pw - MARGIN, bottom), 6f, 6f, cardPaint)
            y += 6f
            titleLines.forEach { ln -> canvas!!.drawText(ln, MARGIN + 8f, y + 10f, h2Paint); y += 14f }
            subLines.forEach { ln -> canvas!!.drawText(ln, MARGIN + 8f, y + 9f, subPaint); y += 12f }
            if (kvLineCount > 0) y += 4f
            kvRows.forEach { (keyW, key, vLines) ->
                vLines.forEachIndexed { idx, ln ->
                    if (idx == 0) canvas!!.drawText("$key:", MARGIN + 8f, y + 9f, keyPaint)
                    canvas!!.drawText(ln, MARGIN + 8f + keyW, y + 9f, valPaint)
                    y += 12.5f
                }
            }
            if (noteLines.isNotEmpty()) { y += 2f; canvas!!.drawText("Nota:", MARGIN + 8f, y + 9f, keyPaint); y += 12f }
            noteLines.forEach { ln -> canvas!!.drawText(ln, MARGIN + 8f, y + 9f, valPaint); y += 12f }
            y += 6f
        }

        closePage()
        doc.writeTo(out)
        out.flush()
        out.close()
        doc.close()
    }

    /**
     * Consentimiento informado (v2.0.0): documento formal en Carta o A4 a
     * partir de los bloques de ConsentDoc — encabezados, párrafos, pares
     * etiqueta→valor, casillas de autorización y líneas de firma.
     */
    fun writeConsent(
        ctx: Context,
        out: OutputStream,
        sizeCode: Int,
        data: ConsentData,
        appVersion: String
    ) {
        val (pw, ph) = pageSize(sizeCode)
        val contentW = pw - 2 * MARGIN

        val headBarPaint = Paint().apply { color = GREEN }
        val headTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textSize = 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = GREEN; textSize = 13.5f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF5B7480.toInt(); textSize = 9f }
        val h2Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF17323B.toInt(); textSize = 10.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val keyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF155E75.toInt(); textSize = 9f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val valPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF17323B.toInt(); textSize = 9f }
        val linePaint = Paint().apply { color = 0xFF9AAAB2.toInt(); strokeWidth = 0.9f; isAntiAlias = true }
        val footPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF5B7480.toInt(); textSize = 8.5f }

        val doc = PdfDocument()
        var pageNo = 0
        var page: PdfDocument.Page? = null
        var canvas: Canvas? = null
        var y = 0f

        fun newPage() {
            page?.let {
                val c = canvas
                if (c != null) {
                    c.drawLine(MARGIN, ph - MARGIN + 10f, pw - MARGIN, ph - MARGIN + 10f, linePaint)
                    val label = "Página $pageNo"
                    c.drawText(label, pw - MARGIN - footPaint.measureText(label), ph - MARGIN + 24f, footPaint)
                    c.drawText("Cronos Anestesia — consentimiento informado generado sin conexión", MARGIN, ph - MARGIN + 24f, footPaint)
                }
                doc.finishPage(it)
            }
            val info = PdfDocument.PageInfo.Builder(pw, ph, ++pageNo).create()
            page = doc.startPage(info)
            canvas = page!!.canvas
            canvas!!.drawRect(0f, 0f, pw.toFloat(), 26f, headBarPaint)
            canvas!!.drawText("Cronos Anestesia — Consentimiento Informado", MARGIN, 17.5f, headTextPaint)
            val tw = subPaint.measureText(appVersion)
            canvas!!.drawText(appVersion, pw - MARGIN - tw, 17.5f, subPaint)
            y = 40f
        }

        fun ensure(h: Float) {
            if (page == null || y + h > ph - MARGIN - 10f) newPage()
        }

        fun wrap(text: String, paint: Paint, indent: Float = 0f): List<String> {
            val maxW = contentW - indent
            val result = mutableListOf<String>()
            for (raw in text.split('\n')) {
                if (raw.isEmpty()) { result.add(""); continue }
                var line = ""
                for (word in raw.split(' ')) {
                    val cand = if (line.isEmpty()) word else "$line $word"
                    if (paint.measureText(cand) <= maxW || line.isEmpty()) line = cand
                    else { result.add(line); line = word }
                }
                result.add(line)
            }
            return result
        }

        fun drawWrapped(text: String, paint: Paint, indent: Float = 0f, lh: Float = paint.textSize * 1.32f) {
            for (ln in wrap(text, paint, indent)) {
                ensure(lh)
                canvas!!.drawText(ln, MARGIN + indent, y, paint)
                y += lh
            }
        }

        newPage()
        y = MARGIN

        ConsentDoc.buildBlocks(data, appVersion).forEach { b ->
            when (b) {
                is ConsentBlock.Header -> {
                    y += 6f
                    drawWrapped(b.text, h2Paint)
                    y += 3f
                }
                is ConsentBlock.Para -> { drawWrapped(b.text, valPaint, 4f); y += 3.5f }
                is ConsentBlock.KeyValue -> {
                    ensure(13f)
                    val keyW = keyPaint.measureText("${b.key}: ")
                    val vLines = wrap(b.value, valPaint, 4f + keyW)
                    canvas!!.drawText("${b.key}:", MARGIN + 4f, y, keyPaint)
                    vLines.forEachIndexed { idx, ln ->
                        if (idx > 0) ensure(12f)
                        canvas!!.drawText(ln, MARGIN + 4f + keyW, y, valPaint)
                        y += 12f
                    }
                    y += 2f
                }
                is ConsentBlock.Check -> {
                    val mark = if (b.checked) "[X]" else "[ ]"
                    drawWrapped("$mark ${b.label}", valPaint, 4f)
                    y += 3.5f
                }
                is ConsentBlock.Signature -> {
                    ensure(40f)
                    y += 16f
                    canvas!!.drawLine(MARGIN + 16f, y, pw - MARGIN - 16f, y, linePaint)
                    y += 13f
                    val lbl = b.label
                    canvas!!.drawText(
                        lbl, (pw - keyPaint.measureText(lbl)) / 2f, y, keyPaint
                    )
                    y += 14f
                }
                ConsentBlock.Divider -> { y += 8f }
            }
        }

        page?.let {
            val c = canvas
            if (c != null) {
                c.drawLine(MARGIN, ph - MARGIN + 10f, pw - MARGIN, ph - MARGIN + 10f, linePaint)
                val label = "Página $pageNo"
                c.drawText(label, pw - MARGIN - footPaint.measureText(label), ph - MARGIN + 24f, footPaint)
                c.drawText("Cronos Anestesia — consentimiento informado generado sin conexión", MARGIN, ph - MARGIN + 24f, footPaint)
            }
            doc.finishPage(it)
        }
        doc.writeTo(out)
        out.flush()
        out.close()
        doc.close()
    }
}
