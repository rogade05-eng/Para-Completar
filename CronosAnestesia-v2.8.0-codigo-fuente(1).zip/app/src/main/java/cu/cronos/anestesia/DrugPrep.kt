package cu.cronos.anestesia

/*
 * ============================================================================
 *  DrugPrep (v2.6) — Utilidades de normalización de texto para buscadores.
 *  La preparación y administración de los 45 fármacos vive en Data3.kt
 *  (DRUG_PREP_RAW) y las presentaciones en Farmacos.kt (DRUG_PRESENTATIONS).
 * ============================================================================
 */

/** Normaliza texto para el buscador: minúsculas y sin acentos. */
fun normText(s: String): String = buildString {
    for (c in s.lowercase()) append(
        when (c) {
            'á' -> 'a'; 'é' -> 'e'; 'í' -> 'i'; 'ó' -> 'o'; 'ú' -> 'u'
            'ü' -> 'u'; 'ñ' -> 'n'
            else -> c
        }
    )
}

/** ¿Coincide la consulta con el texto normalizado? */
fun textMatches(target: String, query: String): Boolean {
    val q = normText(query.trim())
    return q.isEmpty() || normText(target).contains(q)
}
