package cu.cronos.anestesia

/*
 * ============================================================================
 *  SIMULADOR DE CRISIS v2.8.0 — Cronos Anestesia
 *  · RoGaDe Software · contenido clínico del Dr. Romay Díaz Deroncele ·
 *  100 % offline: escenarios, decisiones y puntuación viven en la app.
 *
 *  Simulación de decisión clínica en tiempo real: cada escenario presenta una
 *  crisis perioperatoria como viñeta + monitor, avanza por puntos de decisión
 *  (4 opciones cada uno) y califica la elección: 3 = correcta, 2 = aceptable,
 *  1 = subóptima, 0 = peligrosa. Al cierre: puntaje, tiempo, informe
 *  (debriefing) con puntos clave, dosis críticas y referencias.
 *
 *  Formación de apoyo: no sustituye la simulación in situ ni los protocolos
 *  institucionales. El tutor lo usa con el catálogo de métodos docentes
 *  (Módulo del Tutor, v2.7.0).
 * ============================================================================
 */

import android.content.Context

/** Opción de decisión. [grade] 3=correcta · 2=aceptable · 1=subóptima · 0=peligrosa. */
data class CrisisOption(
    val text: String,
    val grade: Int,
    val feedback: String
)

/** Punto de decisión: situación + monitor + 4 opciones. */
data class CrisisStep(
    val situation: String,
    val monitor: String,   // "FC 148 · PA 85/50 · SpO2 96% · EtCO2 31 · T° 36,8"
    val options: List<CrisisOption>
)

/** Escenario completo de crisis. */
data class CrisisScenario(
    val id: String,
    val title: String,
    val subtitle: String,
    val category: String,   // Vía aérea · Circulación · Alérgico · Metabólico · Tóxico · Respiratorio · Obstétrico
    val level: String,      // nivel sugerido R1–R4
    val intro: String,      // viñeta inicial
    val monitor: String,    // monitor inicial
    val steps: List<CrisisStep>,
    val debrief: List<String>,
    val doses: List<String>,
    val refs: String
) {
    val maxScore: Int get() = steps.size * 3
}

// ------------------------------ MOTOR ------------------------------

object CrisisEngine {

    /** Calificaciones posibles (de mayor a menor). */
    const val GRADE_CORRECT = 3
    const val GRADE_ACCEPTABLE = 2
    const val GRADE_SUBOPT = 1
    const val GRADE_DANGEROUS = 0

    /** Desempeño final por porcentaje del puntaje máximo. */
    fun rating(pct: Int): Int = when {
        pct >= 85 -> 3   // experto
        pct >= 65 -> 2   // seguro con demoras
        pct >= 40 -> 1   // riesgos evitables
        else -> 0        // repaso urgente
    }

    /** Mejor resultado guardado (porcentaje, segundos) o null si nunca se corrió. */
    fun bestScore(ctx: Context, scenarioId: String): Pair<Int, Int>? {
        val v = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getInt("best_$scenarioId", -1)
        return if (v < 0) null else (v / 1000) to (v % 1000)
    }

    /** Guarda el mejor porcentaje y el mejor tiempo (menor es mejor). */
    fun saveProgress(ctx: Context, scenarioId: String, pct: Int, seconds: Int) {
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val cur = pct * 1000 + (3600 - seconds.coerceIn(0, 3599))
        val best = sp.getInt("best_$scenarioId", -1)
        if (cur > best) sp.edit().putInt("best_$scenarioId", cur).apply()
        sp.edit().putLong("last_$scenarioId", System.currentTimeMillis()).apply()
    }

    fun lastTs(ctx: Context, scenarioId: String): Long =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong("last_$scenarioId", 0L)

    fun scenariosAttempted(ctx: Context): Int =
        CRISIS_SCENARIOS.count { bestScore(ctx, it.id) != null }

    private const val PREFS = "crisis_progreso"
}

// ------------------------------ DATOS: ESCENARIOS ------------------------------

val CRISIS_SCENARIOS: List<CrisisScenario> = listOf(

    // ------------------------------------------------------------------
    // 1. Laringoespasmo
    // ------------------------------------------------------------------
    CrisisScenario(
        id = "laringoespasmo",
        title = "Laringoespasmo en inducción",
        subtitle = "Niño de 4 años · ventilación dificultosa post-inducción",
        category = "Vía aérea",
        level = "R1–R2",
        intro = "Niño de 4 años, 18 kg, ASA I, catarro de vías respiratorias altas hace 5 días " +
            "pero auscultación libre, programado para herniorrafia inguinal. " +
            "Inducción con sevoflurano en O2/N2O; al retirar la mascarilla laríngea al final de la " +
            "cirugía el paciente hace un esfuerzo inspiratorio con tiraje, estridor agudo y no " +
            "respira pese a ventilación con bolsa.",
        monitor = "FC 138 · SpO2 91% ↓ · EtCO2 onda plana · esfuerzo inspiratorio paradójico",
        steps = listOf(
            CrisisStep(
                situation = "Estridor inspiratorio agudo, tiraje subcostal, SpO2 91% y cayendo. " +
                    "La bolsa ofrece resistencia y el EtCO2 no muestra onda.",
                monitor = "FC 138 · SpO2 88% ↓ · EtCO2 plano · tiraje marcado",
                options = listOf(
                    CrisisOption(
                        "CPAP con O2 al 100%: mascarilla bien sellada, presión de la vía aérea " +
                            "continua y elevación de la mandíbula (tracción mandibular)",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: es la primera maniobra. La CPAP con O2 al 100% + tracción " +
                            "mandibular resuelve la mayoría de los laringoespasmos en 30–60 s sin " +
                            "necesidad de fármacos."
                    ),
                    CrisisOption(
                        "Intubación de secuencia rápida inmediata con rocuronio",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: intubar agrava el espasmo y no es necesaria en la mayoría de " +
                            "los casos. Reserva para hipoxia refractaria o aspiración asociada."
                    ),
                    CrisisOption(
                        "Esperar y observar 2 minutos mientras aumenta la FiO2",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: el laringoespasmo no cede solo mientras la SpO2 cae; la " +
                            "espera activa con desaturación lleva a bradicardia e hipoxia grave."
                    ),
                    CrisisOption(
                        "Punción cricotiroidea con aguja",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: indicación no existe aquí; la vía aérea quirúrgica es el " +
                            "último recurso cuando fallan todas las maniobras y no hay acceso a " +
                            "la vía aérea."
                    )
                )
            ),
            CrisisStep(
                situation = "A los 30 s de CPAP y tracción mandibular el espasmo persiste: SpO2 84%, " +
                    "esfuerzo cada vez más débil, FC 120.",
                monitor = "FC 120 ↓ · SpO2 84% ↓ · espasmo persistente",
                options = listOf(
                    CrisisOption(
                        "Maniobra de Larson: presión firme bilateral en la apófisis mastoides " +
                            "hacia dentro y arriba, con CPAP sostenida",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: la maniobra de Larson (presión bilateral en " +
                            "las apófisis mastoides) es el escalón siguiente y resuelve la mayoría de los " +
                            "espasmos que no ceden a CPAP sola."
                    ),
                    CrisisOption(
                        "Succionar la faringe con catéter rígido a la vez que se mantiene CPAP",
                        CrisisEngine.GRADE_ACCEPTABLE,
                        "Aceptable: si hay secreciones o sangre como causa, la succión ayuda; " +
                            "pero si no hay material visible, demora la maniobra de Larson que es " +
                            "la clave aquí."
                    ),
                    CrisisOption(
                        "Despertar al paciente y aplazar la maniobra de recuperación",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: despertar con espasmo activo e hipoxia empeora la obstrucción; " +
                            "primero se rompe el espasmo, luego se decide la conducta."
                    ),
                    CrisisOption(
                        "Ventilar a presión más alta sin cambiar de maniobra",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: subir presión infla el estómago, agrava la distensión y no " +
                            "abre las cuerdas; la clave es la maniobra de Larson + profundidad."
                    )
                )
            ),
            CrisisStep(
                situation = "El espasmo sigue tras 30 s de Larson: SpO2 78%, FC 108, el niño se " +
                    "cianosis. Hay vía IV funcional.",
                monitor = "FC 108 · SpO2 78% ↓↓ · cianosis",
                options = listOf(
                    CrisisOption(
                        "Propofol 1–2 mg/kg IV en bolo (18–36 mg) y continuar CPAP/Larson",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: el propofol en bolo relaja las cuerdas vocales y rompe el " +
                            "espasmo en la mayoría de los casos refractarios a maniobras, sin " +
                            "necesidad de succinilcolina."
                    ),
                    CrisisOption(
                        "Succinilcolina 1–2 mg/kg IV (20–36 mg) de inmediato",
                        CrisisEngine.GRADE_ACCEPTABLE,
                        "Aceptable y a menudo necesario si el propofol falla o la hipoxia es " +
                            "grave: succinilcolina IV 1–2 mg/kg (o IM 3–4 mg/kg si no hay vía) " +
                            "relaja al paciente. En niños administrar atropina 0,02 mg/kg con " +
                            "ella por riesgo de bradicardia."
                    ),
                    CrisisOption(
                        "Dexmedetomidina 1 µg/kg en 10 min",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: bradicardia e hipotensión en un paciente hipoxémico y no " +
                            "resuelve el espasmo con la rapidez necesaria."
                    ),
                    CrisisOption(
                        "Atraconio 0,5 mg/kg IV",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: el bloqueante no despolarizante NO relaja las cuerdas " +
                            "vocales de forma confiable y retrasa el tratamiento correcto."
                    )
                )
            ),
            CrisisStep(
                situation = "Tras el propofol cede el espasmo: ventilación eficaz, SpO2 96%, " +
                    "onda de EtCO2 normal. Es el momento de decidir la conducta final.",
                monitor = "FC 126 · SpO2 96% ↑ · EtCO2 38 onda normal",
                options = listOf(
                    CrisisOption(
                        "Continuar anestesia con profundidad adecuada, extubar despierto con " +
                            "ambos seguros (pandereta estrecha) y O2 al 100% hasta despertar",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: tras un laringoespasmo se completa el caso con anestesia " +
                            "profunda, se extuba despierto (no en plano II) y se vigila en " +
                            "recuperación por riesgo de recurrencia en 15–30 min."
                    ),
                    CrisisOption(
                        "Extubar en plano II de anestesia para evitar tos",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: el plano II es el de máxima reactividad laríngea; la " +
                            "recurrencia del espasmo es más probable. Despierto o profundo, " +
                            "pero no en plano II."
                    ),
                    CrisisOption(
                        "Terminar el acto quirúrgico y trasladar sin monitorización extra",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: el laringoespasmo recidiva en la sala de recuperación; el " +
                            "traslado sin O2 ni monitor niega la vigilancia que exige el caso."
                    ),
                    CrisisOption(
                        "Administrar dexametasona 0,15 mg/kg IV y vigilar",
                        CrisisEngine.GRADE_ACCEPTABLE,
                        "Aceptable como coadyuvante si hubo edema o traumatismo laríngeo, pero " +
                            "no sustituye la conducta principal: extubar despierto y vigilar."
                    )
                )
            ),
            CrisisStep(
                situation = "En recuperación, 20 min después, el niño presenta estridor leve en " +
                    "inspiración sin desaturación, SpO2 95% en aire.",
                monitor = "FC 122 · SpO2 95% · estridor leve en aire ambiente",
                options = listOf(
                    CrisisOption(
                        "Estridor leve estable: O2 humedecido, dexametasona ya dada, vigilancia " +
                            "estrecha y descarga solo si evoluciona a obstrucción",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: el estridor leve estable post-extubación se trata con O2 " +
                            "humedecido, observación y esteroides ya administrados; la mayoría " +
                            "cede en 30–60 min."
                    ),
                    CrisisOption(
                        "Reintubar de inmediato por profilaxis",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: reintubar agrava el edema y la reactividad; solo si hay " +
                            "obstrucción progresiva con trabajo respiratorio creciente e hipoxia."
                    ),
                    CrisisOption(
                        "Nebulizar epinefrina racémica 0,05 mL/kg (máx. 0,5 mL) al 2,25%",
                        CrisisEngine.GRADE_ACCEPTABLE,
                        "Aceptable y útil si el estridor aumenta o hay retracciones: la " +
                            "epinefrina nebulizada reduce el edema; obliga a vigilar 2–3 h por " +
                            "efecto rebote."
                    ),
                    CrisisOption(
                        "Dar alta a la sala de recuperación con estridor presente",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: con estridor activo no hay alta; el paciente queda en " +
                            "observación hasta que ceda y esté estable en aire."
                    )
                )
            )
        ),
        debrief = listOf(
            "El laringoespasmo se resuelve en escalera: CPAP O2 100% + tracción mandibular → " +
                "maniobra de Larson → propofol 1–2 mg/kg IV → succinilcolina 1–2 mg/kg IV " +
                "(3–4 mg/kg IM si no hay vía) con atropina 0,02 mg/kg en niños.",
            "Factores de riesgo: vías respiratorias altas catarras, anestesia en plano II, " +
                "sangre o secreciones en la faringe, edad 1–5 años, ex-fumadores pasivos.",
            "Prevenir: extubar despierto o muy profundo, nunca en plano II; succión faríngea " +
                "bajo visión antes de extubar.",
            "Tras el episodio: vigilancia en recuperación ≥30–60 min por recurrencia.",
            "La hipoxia mantenida lleva a bradicardia y paro: no esperar con SpO2 cayendo."
        ),
        doses = listOf(
            "Propofol: 1–2 mg/kg IV en bolo (rompe el espasmo)",
            "Succinilcolina: 1–2 mg/kg IV · 3–4 mg/kg IM (niños)",
            "Atropina: 0,02 mg/kg IV con succinilcolina en pediatría",
            "Epinefrina racémica nebulizada: 0,05 mL/kg de solución al 2,25% (máx. 0,5 mL)",
            "Dexametasona: 0,15–0,5 mg/kg IV si edema/trauma laríngeo"
        ),
        refs = "DAS guía de manejo de vía aérea · PALS/AHA 2020 · Morgan & Mikhail 7.ª ed."
    ),

    // ------------------------------------------------------------------
    // 2. Hipotensión en cesárea espinal
    // ------------------------------------------------------------------
    CrisisScenario(
        id = "hipotension_cesarea",
        title = "Hipotensión arterial en cesárea",
        subtitle = "Espinal para cesárea urgente · hipotensión tras bloqueto",
        category = "Circulación",
        level = "R1–R2",
        intro = "Gestante de 29 años, 78 kg, ASA II (preeclampsia leve), cesárea urgente por " +
            "sufrimiento fetal. Espinal en L3-L4 con bupivacaína hiperbara 0,5% 12 mg. " +
            "Nivel sensitivo T4. A los 6 min del bloqueto la paciente refiere náusea y la " +
            "presión cae.",
        monitor = "FC 96 · PA 82/45 (PAM 57) · SpO2 98% · FCF 96/min",
        steps = listOf(
            CrisisStep(
                situation = "PA 82/45 con náusea, nivel T4, feto con bradicardia relativa " +
                    "(FCF 96). El tiempo al nacimiento importa: hay que actuar ya.",
                monitor = "FC 96 · PA 80/44 ↓ · SpO2 98% · FCF 92/min ↓",
                options = listOf(
                    CrisisOption(
                        "Desplazamiento uterino a la izquierda + fenilefrina 100 µg IV en bolo " +
                            "y/o perfusión 0,25–1 µg/kg/min, O2 y vigilancia continua",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: el desplazamiento uterino elimina la compresión aortocava y " +
                            "la fenilefrina es el vasopresor de primera línea en obstetricia " +
                            "(mejor FCF fetal que la efedrina a dosis equivalentes)."
                    ),
                    CrisisOption(
                        "Efedrina 5–10 mg IV en bolo repetible",
                        CrisisEngine.GRADE_ACCEPTABLE,
                        "Aceptable: sigue siendo útil sobre todo con bradicardia materna " +
                            "(FC <60) o en zonas sin fenilefrina; produce más acidosis fetal " +
                            "que la fenilefrina en dosis equivalentes."
                    ),
                    CrisisOption(
                        "Líquidos en bolo rápido 1000 mL y esperar respuesta",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo como única medida: el co-load ayuda pero solo no corrige la " +
                            "vasoplejía simpática del bloqueto alto; el vasopresor no se puede " +
                            "demorar con sufrimiento fetal."
                    ),
                    CrisisOption(
                        "Convertir a anestesia general de inmediato",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: convertir a GA con hipotensión activa añade riesgo de " +
                            "aspiración y demora el nacimiento; el bloqueto funciona y el problema " +
                            "se trata médicamente."
                    )
                )
            ),
            CrisisStep(
                situation = "Tras fenilefrina la PA sube a 95/50, pero reaparece caída a 78/40 " +
                    "con FC 56 (bradicardia) y náusea de nuevo.",
                monitor = "FC 56 ↓ · PA 78/40 ↓ · náusea",
                options = listOf(
                    CrisisOption(
                        "Efedrina 5–10 mg IV (vasopresor con acción cronotropa) + repetir " +
                            "desplazamiento uterino y valorar atropina si FC <50",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: con bradicardia la efedrina (o combinada con fenilefrina) es " +
                            "preferible; si la FC cae <50, atropina 0,4–0,6 mg IV."
                    ),
                    CrisisOption(
                        "Fenilefrina en bolo repetido 100 µg",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: la fenilefrina pura agrava la bradicardia refleja; con " +
                            "FC 56 conviene efedrina o combinación."
                    ),
                    CrisisOption(
                        "Aumentar O2 y esperar sin vasopresor",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: PA 78/40 sostenida hipoperfunde útero y madre; la espera " +
                            "empeora la acidosis fetal."
                    ),
                    CrisisOption(
                        "Lidocaína IV 1,5 mg/kg para tratar la náusea",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: no trata la hipotensión y confunde el diagnóstico; la náusea " +
                            "es señal de hipoperfusión, no de dolor."
                    )
                )
            ),
            CrisisStep(
                situation = "PA estabilizada 100/60, FCF 128. Comienza la cirugía. A los 4 min " +
                    "la paciente tose y refiere dificultad para respirar «no puedo respirar».",
                monitor = "FC 88 · PA 100/60 · SpO2 95% · FCF 128",
                options = listOf(
                    CrisisOption(
                        "Valorar nivel motor/sensitivo y hablar con la paciente: disnea por " +
                            "bloqueto alto (perdida de intercostales) es frecuente; tranquilizar, " +
                            "O2, elevar cabecera si tolera",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: la incapacidad de toser y la disnea por bloqueto T1–T4 son " +
                            "frecuentes; mientras haya voz y pueda toser, la vía aérea está " +
                            "segura. Tranquilizar + O2 + monitorizar el ascenso."
                    ),
                    CrisisOption(
                        "Inducir anestesia general inmediata por disnea",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: la disnea por bloqueto alto sin parálisis diafragmática no " +
                            "exige GA; inducir sin indicación expone a vía aérea difícil y " +
                            "aspiración."
                    ),
                    CrisisOption(
                        "Pedir que respire en bolsa de reanimación a flujo alto",
                        CrisisEngine.GRADE_ACCEPTABLE,
                        "Aceptable como apoyo mientras se valora: la hiperventilación voluntaria " +
                            "calma la sensación de falta de aire y corrige hipocapnia por " +
                            "taquipnea; no sustituye la valoración del nivel."
                    ),
                    CrisisOption(
                        "Administrar midazolam 2 mg IV para la ansiedad",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: sedar una paciente con disnea y bloqueto alto deprime la " +
                            "respiración y elimina su colaboración; primero valorar y tranquilizar."
                    )
                )
            ),
            CrisisStep(
                situation = "Nace el bebé, Apgar 7/9. Tras la extracción la paciente presenta " +
                    "PA 85/50 y la cirujana informa atonía uterina con sangrado abundante.",
                monitor = "FC 110 ↑ · PA 85/50 ↓ · sangrado activo",
                options = listOf(
                    CrisisOption(
                        "Oxitocina 5 UI IV lenta + perfusión 30–40 UI/h, masaje uterino, " +
                            "cristaloides y avisar a banco de sangre",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: la atonía se trata con uterotónicos (oxitocina en bolo lento " +
                            "para evitar hipotensión + perfusión), masaje, volumen y preparación " +
                            "de hemoterapia si no cede."
                    ),
                    CrisisOption(
                        "Carbetocina 100 µg IV en bolo rápido",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo aquí: la carbetocina es útil en cesárea electiva; en " +
                            "hemorragia activa con hipotensión el bolo rápido agrava la " +
                            "vasoplejía — oxitocina en perfusión es más controlable."
                    ),
                    CrisisOption(
                        "Ergometrina 0,5 mg IV en bolo",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso en preeclampsia: la ergometrina sube mucho la PA y puede " +
                            "provocar crisis hipertensiva/convulsión; contraindicada aquí."
                    ),
                    CrisisOption(
                        "Pedir hemograma y esperar resultados antes de actuar",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: en hemorragia obstétrica se actúa primero (uterotónicos, " +
                            "masaje, volumen); el laboratorio llega tarde por definición."
                    )
                )
            ),
            CrisisStep(
                situation = "El sangrado persiste, PA 88/52, FC 118, HF ~21% estimado. La " +
                    "cirujana pregunta por conducta anestésica.",
                monitor = "FC 118 ↑ · PA 88/52 · SpO2 97%",
                options = listOf(
                    CrisisOption(
                        "Mantener bloqueto si la paciente colabora y tolera; iniciar hemoterapia " +
                            "con glóbulos y protocolo de hemorragia masiva si el sangrado " +
                            "continúa, ácido tranexámico 1 g IV en 10 min, vigilancia de " +
                            "coagulación",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: el bloqueto se mantiene si hay estabilidad y colaboración; " +
                            "TXA precoz (<3 h), soporte transfusional y comunicación con el " +
                            "equipo son la base del protocolo."
                    ),
                    CrisisOption(
                        "Convertir a anestesia general preventivamente",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: convertir solo si hay inestabilidad con pérdida de " +
                            "conciencia/cooperación, vía aérea en riesgo o necesidad de " +
                            "ventilación; la conversión no detiene el sangrado."
                    ),
                    CrisisOption(
                        "Vasopresina para sostener la PA",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: no es vasopresor de primera línea en hemorragia; lo que " +
                            "sostiene la PA es volumen + hemoterapia + control de la causa."
                    ),
                    CrisisOption(
                        "Solicitar plaquetas y plasma fresco desde el inicio en 1:1:1",
                        CrisisEngine.GRADE_ACCEPTABLE,
                        "Aceptable: en sangrado masivo activo (≥1 volemía o evidencia de " +
                            "coagulopatía) el protocolo masivo con 1:1:1 es correcto; si el " +
                            "sangrado es moderado, primero glóbulos + TXA y guiar por laboratorio."
                    )
                )
            )
        ),
        debrief = listOf(
            "La hipotensión del bloqueto espinal obstétrico se trata con desplazamiento " +
                "uterino a la izquierda + vasopresor precoz: fenilefrina es de primera línea; " +
                "efedrina si hay bradicardia.",
            "La náusea súbita en cesárea espinal es hipotensión hasta que se demuestre lo " +
                "contrario: mide la PA antes de dar antieméticos.",
            "La disnea con bloqueto alto no es indicación de GA si hay voz y tos: valora " +
                "nivel motor, tranquiliza y vigila el ascenso.",
            "En preeclampsia la ergometrina está contraindicada (crisis hipertensiva).",
            "Hemorragia post-extracción: uterotónicos escalonados, TXA 1 g precoz y protocolo " +
                "de hemorragia masiva; el bloqueto se mantiene si la paciente colabora."
        ),
        doses = listOf(
            "Fenilefrina: 50–100 µg IV en bolo · perfusión 0,25–1 µg/kg/min",
            "Efedrina: 5–10 mg IV en bolo repetible (bradicardia)",
            "Atropina: 0,4–0,6 mg IV si FC <50",
            "Oxitocina: 5 UI IV lenta + perfusión 30–40 UI/h (diluir)",
            "Ácido tranexámico: 1 g IV en 10 min (precoz, <3 h)",
            "Carbetocina 100 µg solo en cesárea electiva sin hipotensión"
        ),
        refs = "OMS/FIGO hemorragia obstétrica · Guías obstétricas NICE/ACOG · Morgan & Mikhail 7.ª ed."
    ),
    // ------------------------------------------------------------------
    // 3. Anafilaxia perioperatoria
    // ------------------------------------------------------------------
    CrisisScenario(
        id = "anafilaxia",
        title = "Anafilaxia perioperatoria",
        subtitle = "Paciente adulto · colapso cardiovascular tras inducción",
        category = "Alérgico",
        level = "R2–R3",
        intro = "Mujer de 45 años, ASA II, colecistectomía laparoscópica electiva. Historia de " +
            "«alergia a medicamentos no precisada». Inducción con propofol, rocuronio, " +
            "fentanilo; mantenimiento con sevoflurano. A los 8 min de la inducción, tras " +
            "comenzar la infusión de cefazolina, la PA cae de forma brusca y aparece " +
            "eritema facial y del tórax.",
        monitor = "FC 132 ↑ · PA 62/38 ↓↓ · SpO2 89% ↓ · EtCO2 18 ↓↓ · PVP 4",
        steps = listOf(
            CrisisStep(
                situation = "Hipotensión súbita + taquicardia + caída del EtCO2 + eritema " +
                    "cutáneo tras la administración de antibiótico. Circulación con dificultad.",
                monitor = "FC 132 · PA 62/38 ↓↓ · EtCO2 18 ↓↓ · eritema generalizado",
                options = listOf(
                    CrisisOption(
                        "Suspender todos los fármacos y líquidos sospechosos, llamar a ayuda, " +
                            "adrenalina IM 0,5 mg y cristaloides en bolo",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: la anafilaxia se trata con adrenalina IM 0,5 mg (0,5 mL de " +
                            "1 mg/mL en el cuadrante lateral del muslo) + detención del " +
                            "desencadenante + volumen. La IM es la vía de elección inicial."
                    ),
                    CrisisOption(
                        "Adrenalina IV en bolo de 1 mg (dosis de paro)",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: 1 mg IV en paciente con pulso puede provocar arritmia, " +
                            "isquemia y edema agudo; la dosis IV inicial es 50–100 µg (0,05–0,1 mg) " +
                            "titulada, o 1 mg solo en paro."
                    ),
                    CrisisOption(
                        "Hidrocortisona 200 mg IV como primer fármaco",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: el esteroide no actúa en minutos (no es tratamiento de " +
                            "rescate); la adrenalina es lo primero. El esteroide y el " +
                            "antihistamínico son adyuvantes."
                    ),
                    CrisisOption(
                        "Cambiar de antibiótico y continuar sin más",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: la reacción está en marcha; suspender el fármaco no " +
                            "detiene la anafilaxia instalada. Sin adrenalina evoluciona a paro."
                    )
                )
            ),
            CrisisStep(
                situation = "Adrenalina IM administrada. PA 70/42, SpO2 91% con FiO2 60%, " +
                    "broncoespasmo audible. La presión sigue baja.",
                monitor = "FC 128 · PA 70/42 · SpO2 91% · broncoespasmo",
                options = listOf(
                    CrisisOption(
                        "Repetir adrenalina IM 0,5 mg a los 5 min si persiste, iniciar " +
                            "perfusión IV 0,05–0,1 µg/kg/min y cristaloides 20–30 mL/kg",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: en anafilaxia puede repetirse cada 5 min y la perfusión " +
                            "IV (0,05–0,1 µg/kg/min) mantiene el efecto; el volumen es " +
                            "prioridad: hay extravasación de hasta el 40% de la volemia."
                    ),
                    CrisisOption(
                        "Líquidos solos sin más adrenalina",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: el volumen solo no corrige la vasoplejía ni el " +
                            "broncoespasmo; la adrenalina es el tratamiento que salva."
                    ),
                    CrisisOption(
                        "Noradrenalina 0,5 µg/kg/min como primer vasopresor",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: la noradrenalina puede ayudar como adyuvante en " +
                            "hipotensión refractaria, pero la adrenalina sigue siendo el " +
                            "medicamento clave (alfa+beta, broncodilatación)."
                    ),
                    CrisisOption(
                        "Glucagón 1–2 mg IV por si hay bloqueo beta",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo como primera medida: el glucagón es para pacientes en " +
                            "tratamiento con bloqueadores beta refractarios a adrenalina; no " +
                            "sustituye a la adrenalina en el caso general."
                    )
                )
            ),
            CrisisStep(
                situation = "PA se recupera a 95/55 con perfusión de adrenalina. Surge la " +
                    "pregunta de cómo continuar la cirugía.",
                monitor = "FC 112 · PA 95/55 · SpO2 96% · perfusión adrenalina activa",
                options = listOf(
                    CrisisOption(
                        "Suspender la cirugía si es electiva, mantener la perfusión, vigilar " +
                            "6–12 h (segunda fase) y planificar estudio alergológico",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: la anafilaxia electiva termina el procedimiento; la fase " +
                            "bifásica (hasta el 20% reaparece en 1–72 h) obliga a vigilancia " +
                            "prolongada y el caso queda para estudio de alergia."
                    ),
                    CrisisOption(
                        "Continuar la cirugía programada si el cirujano la considera corta",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: continuar una electiva tras anafilaxia grave expone a " +
                            "recurrencia intraoperatoria con el paciente ya inestable; la " +
                            "excepción es urgencia vital con beneficio claro."
                    ),
                    CrisisOption(
                        "Retirar la perfusión de adrenalina en cuanto la PA se normaliza",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: la retirada brusca reproduce el shock; se retira " +
                            "gradualmente tras estabilidad clínica prolongada."
                    ),
                    CrisisOption(
                        "Extubar en quirófano de inmediato",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: con edema de vía aérea y broncoespasmo reciente se " +
                            "extuba solo tras valoración de fuga y estabilidad; algunos " +
                            "pacientes requieren ventilación prolongada."
                    )
                )
            ),
            CrisisStep(
                situation = "En la sala de recuperación el equipo discute qué fármaco fue el " +
                    "desencadenante y cómo documentarlo.",
                monitor = "FC 96 · PA 105/65 · SpO2 97% · en aire",
                options = listOf(
                    CrisisOption(
                        "Trazar el cuadro: cefazolina como sospechosa principal (occurrencia " +
                            "en 8 min tras infusión), rocuronio y látex como alternativas; " +
                            "anotar en historia, notificar y remitir a alergia con muestras",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: la cronología orienta (antibiótico betalactámico y " +
                            "bloqueantes neuromusculares son los más frecuentes); la " +
                            "documentación + triptasa sérica en 1–3 h y estudio alergológico " +
                            "cierran el caso."
                    ),
                    CrisisOption(
                        "Culpar al propofol por ser el primer fármaco administrado",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: la cronología apunta al antibiótico (8 min después); " +
                            "culpar sin análisis cronológico confunde el diagnóstico futuro."
                    ),
                    CrisisOption(
                        "No documentar en detalle para evitar responsabilidad",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: sin registro preciso, la próxima exposición puede matar " +
                            "al paciente; la documentación es parte del tratamiento."
                    ),
                    CrisisOption(
                        "Etiquetar «alergia a todos los anestésicos» en la historia",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: la etiqueta genérica limita toda la anestesia futura; " +
                            "lo correcto es precisar el sospechoso y remitir a estudio."
                    )
                )
            ),
            CrisisStep(
                situation = "Antes del alta, el residente pregunta qué pruebas y con qué " +
                    "seguimiento debe salir la paciente.",
                monitor = "FC 84 · PA 115/70 · SpO2 98% en aire",
                options = listOf(
                    CrisisOption(
                        "Triptasa sérica 1–3 h tras el episodio (y muestra basal a las 24 h), " +
                            "informe escrito del evento, brazaletes de alerta y consulta de " +
                            "alergia en 4–6 semanas",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: la triptasa en ventana 1–3 h confirma activación " +
                            "mastocítica; el informe escrito + alerta médica + estudio " +
                            "alergológico formal completan el manejo."
                    ),
                    CrisisOption(
                        "Pruebas cutáneas el mismo día del alta",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: las pruebas cutáneas son inválidas (falsos negativos) " +
                            "en las 4–6 semanas posteriores por agotamiento de mastocitos."
                    ),
                    CrisisOption(
                        "IgE total y prueba de provocación ambulatoria sin especialista",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: la IgE total no diagnostica anafilaxia y la provocación " +
                            "sin protocolo de alergia es riesgosa."
                    ),
                    CrisisOption(
                        "Solo antihistamínico oral 7 días y alta definitiva",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: el antihistamínico no previene la recurrencia ni " +
                            "identifica la causa; el paciente queda expuesto a una " +
                            "reexposición potencialmente mortal."
                    )
                )
            )
        ),
        debrief = listOf(
            "En anafilaxia perioperatoria: SUSPENDER el desencadenante, AYUDA, ADRENALINA " +
                "IM 0,5 mg (repetir cada 5 min si hace falta) y VOLUMEN 20–30 mL/kg.",
            "La vía IV de adrenalina (50–100 µg titulados) es para reacciones graves " +
                "monitorizadas con acceso IV experto; 1 mg IV es dosis de paro.",
            "Triada típica: hipotensión + broncoespasmo + caída del EtCO2 (hasta un 40% de " +
                "la volemia se extravasa).",
            "Adyuvantes (antihistamínico, esteroide) nunca reemplazan a la adrenalina.",
            "Vigilancia 6–12 h por fase bifásica; triptasa en 1–3 h y estudio alergológico " +
                "en 4–6 semanas completan el diagnóstico.",
            "Betablqueados refractarios: glucagón 1–2 mg IV."
        ),
        doses = listOf(
            "Adrenalina IM: 0,5 mg (0,5 mL de 1 mg/mL) cuadrante lateral del muslo, c/5 min",
            "Adrenalina IV titulada: 50–100 µg (0,05–0,1 mg) si vía IV experta; perfusión 0,05–0,1 µg/kg/min",
            "Cristaloides: 20–30 mL/kg en bolo, repetir según respuesta",
            "Glucagón: 1–2 mg IV (pacientes con betabloqueo refractario)",
            "Hidrocortisona 200 mg IV + difenhidramina como adyuvantes",
            "Triptasa sérica: en 1–3 h + basal a las 24 h"
        ),
        refs = "NAP6 · Guía EAACI anafilaxia 2021 · Asociación Americana de Anestesia (ASA) práctica de anafilaxia"
    ),

    // ------------------------------------------------------------------
    // 4. Hipertermia maligna
    // ------------------------------------------------------------------
    CrisisScenario(
        id = "hipertermia_maligna",
        title = "Hipertermia maligna",
        subtitle = "Adulto joven · hipermetabolismo tras halogenado",
        category = "Metabólico",
        level = "R3–R4",
        intro = "Varón de 22 años, ASA I, 78 kg, artroscopia de rodilla. Anestesia general con " +
            "propofol, suxametonio para intubación y mantenimiento con isoflurano. A los " +
            "40 min de anestesia el equipo nota taquicardia y que la absorvedora está " +
            "excepcionalmente caliente; el EtCO2 asciende pese a aumentar la ventilación.",
        monitor = "FC 142 ↑ · PA 95/55 · EtCO2 68 ↑↑ · T° 38,9 ↑ · taquipnea",
        steps = listOf(
            CrisisStep(
                situation = "Taquicardia + EtCO2 68 que sube pese a ventilar + T° que asciende " +
                    "rápidamente + absorvedor caliente. Sospecha de hipermetabolismo.",
                monitor = "FC 142 · EtCO2 68 ↑↑ · T° 39,2 ↑↑ · rígido?",
                options = listOf(
                    CrisisOption(
                        "Detener halogenados y succinilcolina, hiperventilar con O2 100% " +
                            "flujo alto, llamar ayuda + dantroleno y preparar carrito",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: el primer movimiento es detener los desencadenantes " +
                            "(halogenados/suxa), lavar la máquina con O2 100% a flujo 10 L/min, " +
                            "hiperventilar (2–3× Vc minuto) y LLAMAR por dantroleno ya."
                    ),
                    CrisisOption(
                        "Subir la ventilación minuto y esperar 10 min para reevaluar",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: la HM progresa a rabdomiólisis, arritmia y paro en " +
                            "minutos; cada minuto sin dantroleno aumenta la mortalidad."
                    ),
                    CrisisOption(
                        "Cambiar a anestesia total intravenosa y continuar cirugía con " +
                            "vigilancia",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: suspender halogenados es necesario pero INSUFICIENTE: la " +
                            "crisis en marcha exige dantroleno + refrescar la máquina + manejo " +
                            "de acidosis e hipertermia."
                    ),
                    CrisisOption(
                        "Antipiréticos (paracetamol IV) y enfriar con aire forzado",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: el paracetamol no toca la causa (contracción descontrolada " +
                            "del músculo); el enfriamiento es adyuvante, no el tratamiento."
                    )
                )
            ),
            CrisisStep(
                situation = "Confirmada la sospecha (T° 39,6, rigidez del masetero, EtCO2 72). " +
                    "El dantroleno no está en el quirófano: hay que traerlo de farmacia (15 min) o tenerlo en el carrito de emergencias.",
                monitor = "FC 146 · EtCO2 72 · T° 39,6 · rigidez",
                options = listOf(
                    CrisisOption(
                        "Dantroleno 2,5 mg/kg IV en bolo rápido, repetir cada 5–10 min hasta " +
                            "controlar la crisis (hasta 10 mg/kg si es preciso)",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: el dantroleno 2,5 mg/kg IV en bolo rápido es LA dosis; se " +
                            "repite hasta que el EtCO2 y la rigidez cedan. Para 78 kg: ~195 mg " +
                            "de inicio (3–4 frascos de 20 mg con 60 mL de agua cada uno)."
                    ),
                    CrisisOption(
                        "Dantroleno 0,5 mg/kg y titular lento",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: dosis insuficiente en crisis establecida; retrasar la " +
                            "dosis correcta cuesta músculo y vida."
                    ),
                    CrisisOption(
                        "Diltiazem IV para la taquicardia",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: los bloqueantes de calcio con dantroleno provocan " +
                            "hipercalcemia e hiperpotasemia potencialmente fatales."
                    ),
                    CrisisOption(
                        "Bicarbonato 2 mEq/kg primero y dantroleno después",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: la corrección de la acidosis es adyuvante simultáneo, no " +
                            "prioridad por delante del dantroleno."
                    )
                )
            ),
            CrisisStep(
                situation = "El dantroleno se está preparando. Aparece hiperpotasemia en la " +
                    "gasometría: K+ 6,8 mEq/L con picos T en el ECG.",
                monitor = "FC 150 · K+ 6,8 · T° 39,8 · picos T",
                options = listOf(
                    CrisisOption(
                        "Tratar la hiperpotasemia: calcio cloruro 10% 10 mL IV, insulina " +
                            "regular 10 UI + glucosa 25–50 g IV, bicarbonato 1–2 mEq/kg",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: K+ >6 con alteraciones ECG se trata YA (calcio estabiliza, " +
                            "insulina+glucosa desplaza, bicarbonato ayuda a la acidosis); la " +
                            "hiperpotasemia es la primera causa de muerte en la crisis."
                    ),
                    CrisisOption(
                        "Solo esperar el efecto del dantroleno sobre el metabolismo",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: aunque el dantroleno corta la liberación de K+, la " +
                            "hiperpotasemia instalada puede parar el corazón antes; se trata " +
                            "en paralelo."
                    ),
                    CrisisOption(
                        "Salbutamol nebulizado 5 mg",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: útil como adyuvante en hiperpotasemia, pero insuficiente " +
                            "solo ante K+ 6,8 con picos T; calcio + insulina/glucosa primero."
                    ),
                    CrisisOption(
                        "Kayexalate por sonda",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: actúa en horas; en HM la hiperpotasemia mata en minutos."
                    )
                )
            ),
            CrisisStep(
                situation = "Crisis controlada (EtCO2 45, T° 37,8, rigidez cede). El paciente " +
                    "sigue intubado. Plan de cuidados posteriores.",
                monitor = "FC 108 · EtCO2 45 · T° 37,8 · diuresis en curso",
                options = listOf(
                    CrisisOption(
                        "Continuar dantroleno 1 mg/kg cada 4–6 h (o perfusión 0,25 mg/kg/h) " +
                            "24 h, ICU, vigilar K+/CK/mioglobinuria (diuresis >2 mL/kg/h) y " +
                            "arritmias",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: la recrudescencia ocurre hasta en el 25% (dantroleno se " +
                            "mantiene 24 h); ICU con vigilancia de K+, CK, mioglobinuria y " +
                            "diuresis protegida es estándar."
                    ),
                    CrisisOption(
                        "Alta del ICU a las 4 h si el paciente despierta bien",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: la recrudescencia mata; el alta precoz tras una HM es " +
                            "un error clásico."
                    ),
                    CrisisOption(
                        "Furosemida profiláctica sin vigilancia de diuresis",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: la diuresis objetivo (>2 mL/kg/h) se logra con volumen; " +
                            "la furosemida solo ante sobrecarga, con vigilancia."
                    ),
                    CrisisOption(
                        "Retirar la monitorización de EtCO2 al extubar",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: el paciente queda en ICU con monitorización completa; " +
                            "el EtCO2 y la T° se siguen hasta la estabilidad."
                    )
                )
            ),
            CrisisStep(
                situation = "Estable en ICU. La familia pregunta qué hacer con el paciente y " +
                    "sus parientes respecto a la susceptibilidad a HM.",
                monitor = "FC 92 · T° 37,0 · CK en descenso",
                options = listOf(
                    CrisisOption(
                        "Notificar como sospecha de HM, remitir a consulta de neurología/" +
                            "genética (prueba de contracción cafeína-halotano o genética " +
                            "RYR1/CACNA1S) y emitir alerta médica para el paciente y familiares " +
                            "de primer grado",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: la HM es autosómica dominante; el paciente y familiares " +
                            "de primer grado requieren estudio y alerta. Anestesia futura: " +
                            "TOTIVA con preparación de máquina o bloqueo regional."
                    ),
                    CrisisOption(
                        "Suspender anestesias futuras con halogenados y suxa solo en este " +
                            "paciente",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: correcto para el paciente, incompleto: faltan el estudio " +
                            "formal y la alerta familiar (los parientes de primer grado tienen " +
                            "50% de riesgo)."
                    ),
                    CrisisOption(
                        "No notificar si el episodio se resolvió sin secuelas",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: la no notificación deja a la familia expuesta a un " +
                            "episodio mortal en una próxima anestesia."
                    ),
                    CrisisOption(
                        "Probar halogenado en dosis baja en la próxima cirugía",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: no hay dosis segura de desencadenante en un paciente " +
                            "sospechoso de HM; la prueba de provocación no se hace en " +
                            "quirófano."
                    )
                )
            )
        ),
        debrief = listOf(
            "Crisis HM: DETENER halogenados/suxa → O2 100% flujo 10 L/min (lavar máquina) → " +
                "hiperventilar 2–3× → DANTROLENO 2,5 mg/kg IV bolo rápido, repetir hasta " +
                "10 mg/kg → refrescar activamente (36–37 °C).",
            "El EtCO2 que sube pese a buena ventilación + taquicardia + rigidez es la " +
                "tríada más precoz: la T° tarda en subir.",
            "La hiperpotasemia mata primero: calcio + insulina/glucosa + bicarbonato en " +
                "paralelo con el dantroleno.",
            "Contraindicado con dantroleno: bloqueantes de calcio (diltiazem, verapamilo).",
            "Mantener dantroleno 24 h (1 mg/kg c/4–6 h) por recrudescencia hasta en 25%; " +
                "ICU con K+, CK, mioglobinuria, diuresis >2 mL/kg/h.",
            "Todo hospital con quirófano debe tener dantroleno accesible en <30 min " +
                "(protocolo MHAUS/ERHM)."
        ),
        doses = listOf(
            "Dantroleno: 2,5 mg/kg IV bolo rápido → repetir c/5–10 min (máx. 10 mg/kg)",
            "Mantenimiento: 1 mg/kg IV c/4–6 h (o 0,25 mg/kg/h) durante 24 h",
            "Dilución: cada frasco 20 mg con 60 mL de agua estéril (sin conservantes)",
            "Calcio cloruro 10%: 10 mL IV · insulina regular 10 UI + glucosa 25–50 g IV",
            "Bicarbonato 8,4%: 1–2 mEq/kg IV según gasometría",
            "Refrigeración activa: objetivo 36–37 °C; parar a los 38 °C en descenso"
        ),
        refs = "MHAUS 2020 · ERHM (European Malignant Hyperthermia Group) · Morgan & Mikhail 7.ª ed."
    ),
    // ------------------------------------------------------------------
    // 5. Hipoxemia súbita intraoperatoria (enfoque DOPE)
    // ------------------------------------------------------------------
    CrisisScenario(
        id = "hipoxemia_subita",
        title = "Hipoxemia súbita intraoperatoria",
        subtitle = "Adulto intubado · SpO2 que cae sin aviso",
        category = "Respiratorio",
        level = "R1–R2",
        intro = "Mujer de 58 años, ASA II, obesidad grado I (IMC 33), colecistectomía abierta " +
            "en anestesia general con intubación y ventilación mecánica (Vc 400 mL, FR 14, " +
            "PEEP 5). A 35 min de la cirugía, con el paciente en Trendelenburg leve y " +
            "neumoperitoneo no aplicable, la SpO2 cae de 98% a 84% en 3 min.",
        monitor = "FC 98 · PA 110/65 · SpO2 84% ↓↓ · EtCO2 32 · Ppico 26 ↑",
        steps = listOf(
            CrisisStep(
                situation = "SpO2 84% y bajando. La primera regla: O2 al 100% y volver a " +
                    "ventilación manual para sentir el pulmón mientras se evalúa.",
                monitor = "FC 98 · SpO2 84% ↓ · Ppico 26 ↑ · EtCO2 32",
                options = listOf(
                    CrisisOption(
                        "FiO2 al 100%, desconectar del ventilador y ventilar con bolsa " +
                            "(percibir compliance y resistencia), auscultar bilaterales",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: el paso 1 del enfoque DOPE es FiO2 100% + bolsa manual: " +
                            "sentir el pulmón (compliance), auscultar y estabiliza mientras " +
                            "diagnostica. No desatiende la causa pero gana tiempo."
                    ),
                    CrisisOption(
                        "Subir el Vc a 500 mL y la PEEP a 10 en el ventilador",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: subir parámetros en una máquina con problema de " +
                            "equipamiento o desplazamiento del tubo puede empeorar " +
                            "(barotrauma, sobreinflación); primero ventilación manual y " +
                            "evaluación."
                    ),
                    CrisisOption(
                        "Llamar a radiología para una radiografía de tórax en la cama",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso como primer paso: con SpO2 84% la paciente no espera una " +
                            "radiografía; el diagnóstico bedside (bolsa + auscultación + " +
                            "EtCO2 + fibrobroncoscopio si hay) va primero."
                    ),
                    CrisisOption(
                        "Aumentar la sedación para mejorar la compliance",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: la sedación no corrige hipoxemia mecánica ni " +
                            "desplazamiento del tubo; retrasa el diagnóstico correcto."
                    )
                )
            ),
            CrisisStep(
                situation = "Con la bolsa: resistencia alta, murmullo pulmonar ausente en el " +
                    "lado derecho, EtCO2 32 con onda conservada. Ppico 28.",
                monitor = "FC 102 · SpO2 82% · Ppico 28 ↑ · silencio en lado derecho",
                options = listOf(
                    CrisisOption(
                        "Sospechar desplazamiento del tubo (bronquio principal derecho) o " +
                            "obstrucción: fibrobroncoscopio/laringoscopio para ver posición y " +
                            "patencia del tubo, aspirar si hay secreciones",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: la D de DOPE (desplazamiento) y la O (obstrucción) son las " +
                            "causas más frecuentes de hipoxemia súbita con un pulmón silente; " +
                            "la visualización directa confirma y corrige en segundos."
                    ),
                    CrisisOption(
                        "Desconectar el tubo y ventilar con mascarilla facial",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: en un paciente intubado con estómago potencialmente lleno " +
                            "y cirugía abierta, desconectar e intubar de nuevo añade riesgo de " +
                            "aspiración; primero se verifica el tubo in situ."
                    ),
                    CrisisOption(
                        "Retroceder el tubo 2 cm a ciegas y reevaluar",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: el ajuste a ciegas puede extraer el tubo (extubación " +
                            "accidental); con fibrobroncoscopio o laringoscopio se corrige con " +
                            "certeza."
                    ),
                    CrisisOption(
                        "Sospechar neumotórax y descomprimir el lado derecho de inmediato",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: el neumotórax es la P de DOPE y debe sospecharse, pero " +
                            "descomprimir sin confirmar (ausencia de onda EtCO2 + hipotensión + " +
                            "distensión cervical) con este cuadro puede retrasar la causa real " +
                            "(tubo). Valorar ultrasonido/estetoscopio + diagnóstico rápido."
                    )
                )
            ),
            CrisisStep(
                situation = "La visualización muestra el tubo a 26 cm en boca (profundidad " +
                    "adecuada 21 cm) — entró en el bronquio derecho. Se recoloca a 22 cm. " +
                    "SpO2 sube a 96%.",
                monitor = "FC 96 · SpO2 96% ↑ · Ppico 21 · bilaterales presentes",
                options = listOf(
                    CrisisOption(
                        "Fijar el tubo en la profundidad correcta, volver al ventilador con " +
                            "parámetros previos y documentar el episodio",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: corregido el desplazamiento, fijación firme + retorno al " +
                            "ventilador + registro del evento completan el manejo; revisar " +
                            "causa (movilización cervical, Trendelenburg, flexión)."
                    ),
                    CrisisOption(
                        "Volver a ventilador sin cambiar nada más",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: sin fijación firme y sin investigar la causa, el tubo " +
                            "vuelve a desplazarse en la siguiente movilización."
                    ),
                    CrisisOption(
                        "Extubar y continuar con mascarilla laríngea",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: cambiar de vía aérea a mitad de cirugía abierta en " +
                            "obesa sin indicación es riesgo de aspiración y pérdida de la vía."
                    ),
                    CrisisOption(
                        "Aumentar PEEP profiláctica a 10",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: la PEEP alta no previene el desplazamiento del tubo y " +
                            "afecta la hemodinamia; los parámetros previos eran adecuados."
                    )
                )
            ),
            CrisisStep(
                situation = "20 min después la SpO2 cae de nuevo (88%) con Ppico 18 (normal), " +
                    "bilaterales presentes, EtCO2 30, PA 90/55 y FC 118.",
                monitor = "FC 118 ↑ · PA 90/55 ↓ · SpO2 88% · Ppico 18 · EtCO2 30",
                options = listOf(
                    CrisisOption(
                        "Enfoque E de DOPE (embolia/hipoperfusión): evaluar PE, embolia de " +
                            "gas, posiciones quirúrgicas; verificar EtCO2/PA/FC y pedir " +
                            "ecografía bedside",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: con Ppico NORMAL y caída del EtCO2 + hipotensión + " +
                            "taquicardia, el problema ya no es mecánico de la vía: es " +
                            "hipoperfusión/embolia (PE, gas, hemorragia). La ecografía " +
                            "bedside orienta."
                    ),
                    CrisisOption(
                        "Repetir la maniobra del tubo por si acaso",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: el patrón (Ppico normal + EtCO2 bajo + hemodinamia " +
                        "afectada) ya no apunta a vía aérea; repetir maniobras retrasa el " +
                            "diagnóstico real."
                    ),
                    CrisisOption(
                        "Aumentar PEEP a 15",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: con hipotensión, la PEEP alta comprime el retorno " +
                            "venoso y empeora el gasto cardíaco y la oxigenación."
                    ),
                    CrisisOption(
                        "Subir el flujo de O2 fresco del aparato",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: el problema no está en el suministro (FiO2 ya al 100% " +
                            "desde el primer episodio); es hemodinámico."
                    )
                )
            ),
            CrisisStep(
                situation = "La ecografía bedside muestra dilatación del ventrículo derecho con " +
                    "tabique que desvía a la izquierda: sospecha de embolia pulmonar. " +
                    "La cirugía está por terminar.",
                monitor = "FC 122 · PA 85/50 · SpO2 86% · EtCO2 26",
                options = listOf(
                    CrisisOption(
                        "Soporte hemodinámico (noradrenalina 0,05–0,3 µg/kg/min, volumen " +
                            "cauteloso), tratar de terminar pronto, comunicar a ICU y valorar " +
                            "anticoagulación/TC tras el cierre",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: en PE intraoperatoria el manejo es soporte (noradrenalina " +
                            "sostiene la PA sin sobrecargar el VD), cerrar la cirugía cuanto " +
                            "antes, trasladar a ICU y confirmar + anticoagular según protocolo."
                    ),
                    CrisisOption(
                        "Trombolisis intravenosa en quirófano de inmediato",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: la trombolisis es para PE con paro o colapso " +
                            "irreversible; en cirugía abierta activa provoca hemorragia " +
                            "catastrófica sin confirmación diagnóstica."
                    ),
                    CrisisOption(
                        "Nitroprusiato para reducir poscarga del VD",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: el vasodilatador colapsa la PA del paciente hipotenso; " +
                            "el soporte vasopresor es lo que mantiene la perfusión coronaria " +
                            "del VD."
                    ),
                    CrisisOption(
                        "Suspender el volumen y dar solo vasopresores",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: en PE se dosifican fluidos CON cuidado (500 mL y " +
                            "reevaluar): ni volumen agresivo ni volumen cero."
                    )
                )
            )
        ),
        debrief = listOf(
            "DOPE ordena el diagnóstico de la hipoxemia súbita: Desplazamiento del tubo, " +
                "Obstrucción, Neumotórax, Equipamiento — más E de Embolia/hipoperfusión.",
            "Primero siempre: FiO2 100% + ventilación manual con bolsa (siente el pulmón) " +
                "+ auscultación bilateral + mirar el EtCO2.",
            "Ppico ALTO + un pulmón silente = tubo o neumotórax. Ppico NORMAL + EtCO2 bajo " +
                "+ hipotensión = embolia/hipoperfusión.",
            "La visualización directa (fibrobroncoscopio/laringoscopio) corrige el tubo con " +
                "certeza; no se recoloca a ciegas.",
            "PE intraoperatoria: soporte con noradrenalina, cerrar la cirugía, ICU; " +
                "trombolisis solo en colapso irreversible.",
            "Obesa + Trendelenburg + neumoperitoneo = factores que desplazan el tubo: " +
                "fijación y re-verificación en cada cambio de posición."
        ),
        doses = listOf(
            "FiO2: 100% ante toda hipoxemia intraoperatoria",
            "PEEP: 5 cmH2O basal; subir solo tras descartar causa mecánica y con PA estable",
            "Noradrenalina: 0,05–0,3 µg/kg/min (soporte de PE intraoperatoria)",
            "Volumen en PE: 250–500 mL en bolo y reevaluar (cauteloso)",
            "Vt protector: 6–8 mL/kg PBW en obesos + PEEP ajustada"
        ),
        refs = "Enfoque DOPE (DAS/ASA) · Guía ESC embolia pulmonar 2019 · Morgan & Mikhail 7.ª ed."
    ),

    // ------------------------------------------------------------------
    // 6. Toxicidad por anestésicos locales (LAST)
    // ------------------------------------------------------------------
    CrisisScenario(
        id = "last_toxicidad",
        title = "Toxicidad por anestésicos locales (LAST)",
        subtitle = "Adulto · convulsión y arritmia tras bloqueo",
        category = "Tóxico",
        level = "R2–R3",
        intro = "Varón de 70 kg, ASA II, bloqueo de plexo braquial supraclavicular guiado por " +
            "ecografía con ropivacaína 0,5% 40 mL (dosis calculada 3 mg/kg). A los 12 min " +
            "del bloqueo presenta movimiento anormal de los labios, temblor, y luego " +
            "convulsión tónico-clónica generalizada; el monitor muestra taquicardia " +
            "ventricular irregular.",
        monitor = "FC 138 irregular · PA 85/50 · SpO2 90% · TV polimórfica en monitor",
        steps = listOf(
            CrisisStep(
                situation = "Convulsión en curso + arritmia ventricular tras un bloqueo " +
                    "regional con gran volumen de anestésico local.",
                monitor = "FC 138 irregular · SpO2 90% · convulsión activa",
                options = listOf(
                    CrisisOption(
                        "Llamar ayuda, pedir el carrito de LÍPIDOS (Emulsión lipídica 20%), " +
                            "hiperventilar con O2 100% y benzodiacepina para la convulsión",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: ante LAST convulsivo + cardíaco se anuncia el protocolo " +
                            "lipídico desde el primer minuto; mientras llega, vía aérea con " +
                            "O2 100% y midazolam 2–5 mg IV para la convulsión."
                    ),
                    CrisisOption(
                        "Propofol 2 mg/kg IV para cortar la convulsión",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: el propofol a dosis altas deprime el miocardio ya " +
                            "toxicado; en LAST la benzodiacepina es el anticonvulsivo " +
                            "preferente y a dosis menores."
                    ),
                    CrisisOption(
                        "Desfibrilar de inmediato a 150 J",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: si hay TV sin pulso/paro, desfibrilar; con pulso y " +
                            "arritmia el tratamiento es lípidos + soporte, no choque " +
                            "electivo."
                    ),
                    CrisisOption(
                        "Esperar a que la convulsión ceda sola (son autolimitadas)",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: la convulsión aumenta la acidosis, que agrava la " +
                            "cardiotoxicidad; además puede haber paro en minutos."
                    )
                )
            ),
            CrisisStep(
                situation = "La convulsión cede con midazolam, pero persiste arritmia ventricular " +
                    "con PA 70/40. El carrito de lípidos está en la mesa.",
                monitor = "FC 128 irregular · PA 70/40 · SpO2 93% · TV no sostenida",
                options = listOf(
                    CrisisOption(
                        "Emulsión lipídica 20%: bolo 1,5 mL/kg (105 mL) en >1 min, luego " +
                            "perfusión 0,25 mL/kg/min; repetir bolo ×2 c/5 min si persiste",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: la fórmula ASRA: bolo 1,5 mL/kg + perfusión 0,25 mL/kg/min " +
                            "(duplicar si la PA no responde; máx. ~12 mL/kg en la primera " +
                            "hora; cesa la perfusión a los 30 min de estabilidad)."
                    ),
                    CrisisOption(
                        "Lidocaína IV 1,5 mg/kg como antiarrítmico",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: ¡otro anestésico local! En LAST la lidocaína está " +
                            "contraindicada; el antiarrítmico permitido es solo " +
                            "amiodarona si es necesaria."
                    ),
                    CrisisOption(
                        "Amiodarona 300 mg IV como primera medida",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: la amiodarona es segunda línea tras los lípidos en " +
                            "arritmia maligna por LAST; no la sustituye."
                    ),
                    CrisisOption(
                        "Bloqueante de calcio (verapamilo) para control de frecuencia",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: los bloqueantes de calcio agravan la depresión " +
                            "miocárdica del LAST; contraindicados."
                    )
                )
            ),
            CrisisStep(
                situation = "Tras lípidos + perfusión, la arritmia cede y la PA sube a 100/60. " +
                    "Se debate el manejo de la vía aérea y la ventilación.",
                monitor = "FC 102 · PA 100/60 · SpO2 96% · ritmo sinusal",
                options = listOf(
                    CrisisOption(
                        "O2 100% e hiperventilación moderada (corregir acidosis), evitar " +
                            "hipoventilación y apnea; vigilar en ICU 12–24 h",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: la acidosis empeora el LAST: hiperventilación moderada + " +
                            "O2 100% + vigilancia ICU (la toxicidad puede recrudecer horas " +
                            "después por redistribución del anestésico)."
                    ),
                    CrisisOption(
                        "PEEP alta y Vc pequeños para «proteger el pulmón»",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: la PEEP alta reduce el retorno venoso y la PA; en LAST " +
                            "se prioriza la perfusión coronaria con hiperventilación " +
                            "moderada."
                    ),
                    CrisisOption(
                        "Extubar en quirófano y alta a sala común a las 2 h",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: tras un LAST con arritmia, el paciente pasa por ICU " +
                            "(12–24 h) por recrudecimiento; alta precoz = riesgo de muerte " +
                            "diferida."
                    ),
                    CrisisOption(
                        "Repetir bolo de lípidos profiláctico cada 15 min",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: los bolos se repiten solo si la inestabilidad " +
                            "persiste (máx. 3); luego es perfusión, no bolos " +
                            "profilácticos."
                    )
                )
            ),
            CrisisStep(
                situation = "Estable en ICU. El equipo revisa por qué ocurrió: bloqueo con " +
                    "aspiración negativa en 3 de 4 planos y ecografía adecuada.",
                monitor = "FC 88 · PA 118/70 · SpO2 97% en aire",
                options = listOf(
                    CrisisOption(
                        "La aspiración NO excluye intravascular (solo detecta ~2%): la dosis " +
                            "máxima y la inyección fraccionada (5 mL c/15–30 s con vigilancia) " +
                            "son la prevención real; notificar el evento",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: la prueba de aspiración tiene sensibilidad bajísima; la " +
                            "prevención es dosis máxima calculada + inyección fraccionada con " +
                            "testigos de neurotoxicidad + ecografía. Aun así ocurre: notificar."
                    ),
                    CrisisOption(
                        "El fallo fue no usar bromuro de rocuronio como test",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: el test de bloqueante neuromuscular (epinefrina o " +
                            "rocuronio) no se usa de rutina y en este contexto no habría " +
                            "prevenido nada; confunde el análisis."
                    ),
                    CrisisOption(
                        "Reducir la dosis a la mitad en todos los bloqueos futuros",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: la mitad puede ser insuficiente para el bloqueo; la " +
                            "prevención es dosis máxima correcta + técnica fraccionada, no " +
                            "subdosis sistemática."
                    ),
                    CrisisOption(
                        "No ocurre nada más: el evento fue idiosincrático",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: toda LAST es prevenible en su mayoría con técnica y " +
                            "protocolo; no notificar ni revisar el proceso repite el error."
                    )
                )
            ),
            CrisisStep(
                situation = "Antes del alta de ICU, el residente pide el resumen de qué debe " +
                    "estar en el carrito de LAST del servicio.",
                monitor = "FC 84 · PA 122/74 · SpO2 98% en aire",
                options = listOf(
                    CrisisOption(
                        "Emulsión lipídica 20% ≥2 frascos de 500 mL (o 1000 mL), jeringas " +
                            "grandes, protocolo impreso con fórmula por peso y teléfono de " +
                            "contacto",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: el carrito debe tener al menos 1000 mL de emulsión " +
                            "lipídica 20%, equipo de perfusión y el protocolo impreso con " +
                            "las dosis por peso — accesible donde se hacen bloqueos."
                    ),
                    CrisisOption(
                        "Solo el antídoto: un frasco de 100 mL alcanza",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: la dosis inicial + perfusión puede necesitar 500–1000 mL; " +
                            "un frasco de 100 mL se agota en el primer bolo de un adulto de 70 kg."
                    ),
                    CrisisOption(
                        "Adrenalina prefabricada en perfusión alta como sustituto de lípidos",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: la adrenalina en LAST se usa a dosis BAJAS (<1 µg/kg en " +
                            "bolos) y no sustituye los lípidos; las dosis altas agravan la " +
                            "arritmia."
                    ),
                    CrisisOption(
                        "El carrito solo es necesario para bloqueos plexulares grandes",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: el LAST ocurre también con infiltración, peri-bulbar, " +
                            "hematoma bloqueante; el carrito debe estar donde se inyecte " +
                            "anestésico local en volumen."
                    )
                )
            )
        ),
        debrief = listOf(
            "LAST = síntomas prodrómicos (periorales, agitación) → convulsión → arritmia. " +
                "El tratamiento clave: EMULSIÓN LIPÍDICA 20% desde el primer minuto.",
            "Fórmula ASRA: bolo 1,5 mL/kg en >1 min (repetir ×2 c/5 min si persiste) + " +
                "perfusion 0,25 mL/kg/min (duplicar si no responde; máx. ~12 mL/kg la " +
                "primera hora).",
            "Contraindicados en LAST: lidocaína (¡es un anestésico local!), bloqueantes de " +
                "calcio, betabloqueantes; adrenalina solo a dosis bajas (<1 µg/kg).",
            "La aspiración negativa NO excluye inyección intravascular: dosis máxima " +
                "calculada + inyección fraccionada (5 mL c/15–30 s) con vigilancia verbal.",
            "Vigilancia en ICU 12–24 h: la toxicidad puede recrudecer por redistribución.",
            "Todo servicio de bloqueos necesita carrito de LAST con ≥1000 mL de lípidos y " +
                "protocolo impreso."
        ),
        doses = listOf(
            "Emulsión lipídica 20%: bolo 1,5 mL/kg en >1 min, ×2 c/5 min si persiste",
            "Perfusión: 0,25 mL/kg/min (duplicar a 0,5 si PA no responde)",
            "Máximos: ~12 mL/kg en la primera hora; cesar a los 30 min de estabilidad",
            "Midazolam: 2–5 mg IV para convulsión (evitar propofol a dosis altas)",
            "Adrenalina (si shock): bolos ≤1 µg/kg; perfusión según respuesta",
            "Ropivacaína: dosis máxima ~3 mg/kg (70 kg → 210 mg; se administraron 200 mg " +
                "correctos: el evento fue intravascular, no por sobredosis)"
        ),
        refs = "ASRA checklist LAST 2021 · Morgan & Mikhail 7.ª ed. · Guía práctica de bloqueos regionales"
    ),
    // ------------------------------------------------------------------
    // 7. Broncoespasmo intraoperatorio
    // ------------------------------------------------------------------
    CrisisScenario(
        id = "broncoespasmo",
        title = "Broncoespasmo intraoperatorio",
        subtitle = "Asmático · sibilancias tras intubación",
        category = "Respiratorio",
        level = "R1–R2",
        intro = "Varón de 32 años, ASA II, asma leve intermitente (salbutamol de rescate), " +
            "tabaquismo activo. Cirugía laparoscópica electiva. Inducción con propofol y " +
            "fentanilo, intubación con rocuronio sin profundización previa, mantenimiento " +
            "con sevoflurano. A los 5 min de la intubación aparecen sibilancias " +
            "espiratorias difusas con aumento de la presión de pico.",
        monitor = "FC 112 · PA 125/70 · SpO2 93% ↓ · Ppico 34 ↑ · EtCO2 40",
        steps = listOf(
            CrisisStep(
                situation = "Sibilancias difusas + Ppico 34 tras intubación. Diagnóstico " +
                    "probable, pero hay que descartar las causas mecánicas primero.",
                monitor = "FC 112 · SpO2 93% · Ppico 34 ↑ · sibilancias difusas",
                options = listOf(
                    CrisisOption(
                        "Profundizar anestesia (propofol bolo 1 mg/kg + subir halogenado), " +
                            "O2 100%, descartar tubo obstruido/desplazado (auscultar, " +
                            "pasar aspirador)",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: el broncoespasmo reflejo por tubo en vía aérea poco " +
                            "profunda se trata PROFUNDIZANDO. Y siempre se descarta " +
                            "obstrucción/desplazamiento del tubo antes de etiquetar " +
                            "broncoespasmo."
                    ),
                    CrisisOption(
                        "Salbutamol nebulizado inmediato sin profundizar",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo como único primer paso: el desencadenante es el reflejo " +
                            "del tubo en anestesia superficial; sin profundidad el " +
                            "broncoespasmo persiste pese al salbutamol."
                    ),
                    CrisisOption(
                        "Ketamina 1 mg/kg IV de inmediato",
                        CrisisEngine.GRADE_ACCEPTABLE,
                        "Aceptable: la ketamina es broncodilatadora y útil en asma, pero el " +
                            "problema agudo aquí es profundidad insuficiente: propofol/" +
                            "halogenado primero, ketamina si no responde o hay que retirar " +
                            "el halogenado."
                    ),
                    CrisisOption(
                        "Aumentar la frecuencia respiratoria para mejorar la oxigenación",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: FR alta en broncoespasmo atrapa aire y empeora la " +
                            "hiperinflación dinámica; FR baja + tiempo espiratorio largo."
                    )
                )
            ),
            CrisisStep(
                situation = "Profundizada la anestesia persisten sibilancias y Ppico 32. " +
                    "SpO2 92%. Decisión de fármacos específicos.",
                monitor = "FC 116 · SpO2 92% · Ppico 32 · sibilancias persistentes",
                options = listOf(
                    CrisisOption(
                        "Salbutamol 4–8 pulsaciones por el tubo con cámara (o nebulizado " +
                            "2,5–5 mg) repetible cada 10–20 min",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: el salbutamol por el tubo con cámara es la base: 4–8 " +
                            "pulsaciones equivalentes a nebulización; repetible. Añade " +
                            "tiempo espiratorio (FR 6–8/min, I:E 1:3–1:4)."
                    ),
                    CrisisOption(
                        "Aminofilina 250 mg IV en 20 min",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: la aminofilina tiene ventana terapéutica estrecha, " +
                            "arritmias y interacciones; el beta-2 agonista es de primera " +
                            "línea intraoperatoria."
                    ),
                    CrisisOption(
                        "Ipratropio como único broncodilatador",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: el ipratropio es adyuvante (lento, 15–30 min); no " +
                            "sustituye al salbutamol en la crisis aguda."
                    ),
                    CrisisOption(
                        "Hidrocortisona 200 mg IV y esperar su efecto",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: el esteroide actúa en horas (4–6 h); se administra " +
                            "temprano por su papel en la fase tardía, pero NO espera el " +
                            "alivio del salbutamol."
                    )
                )
            ),
            CrisisStep(
                situation = "Mejora parcial, pero la SpO2 cae a 88% con EtCO2 55 y onda " +
                    "espiculada (reinhalación): atrapamiento de aire grave.",
                monitor = "FC 120 · SpO2 88% ↓ · EtCO2 55 ↑ · onda espiculada",
                options = listOf(
                    CrisisOption(
                        "Permitir hipercapnia permisiva: FR 6–8, tiempo espiratorio largo, " +
                            "vigilar hipotensión por atrapamiento (pausas de apnea de " +
                            "comprobación si hay duda)",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: en atrapamiento grave se acepta hipercapnia permisiva " +
                            "(pH >7,2) con FR baja y espirio largo; las pausas de apnea " +
                            "detectan sobrecarga circulatoria por atrapamiento."
                    ),
                    CrisisOption(
                        "Forzar ventilación normal con Vc alto y FR 14",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: con broncoobstrucción el Vc alto aumenta la presión " +
                            "de plateau (barotrauma) y el FR alto agrava el atrapamiento " +
                            "hasta el shock obstructivo."
                    ),
                    CrisisOption(
                        "Desconectar el circuito 30 s para liberar el aire atrapado si hay " +
                            "hipotensión",
                        CrisisEngine.GRADE_ACCEPTABLE,
                        "Aceptable y a veces vital: en hipotensión por atrapamiento, la " +
                            "desconexión breve descarga el pulmón y recupera el retorno " +
                            "venoso; después, ajustar la ventilación para evitar que " +
                            "se repita."
                    ),
                    CrisisOption(
                        "Bicarbonato 1 mEq/kg por la hipercapnia",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: el bicarbonato genera CO2 adicional; con pH >7,2 la " +
                            "hipercapnia permisiva no se corrige químicamente."
                    )
                )
            ),
            CrisisStep(
                situation = "Estabilizado con salbutamol repetido + hipercapnia permisiva " +
                    "(EtCO2 48, SpO2 95%). La cirugía continúa. ¿Cuándo se considera " +
                    "ingresar en ICU?",
                monitor = "FC 104 · SpO2 95% · EtCO2 48 · Ppico 26",
                options = listOf(
                    CrisisOption(
                        "ICU si persiste broncoespasmo con requerimiento alto de " +
                            "broncodilatadores, hipercapnia progresiva o compromiso " +
                            "hemodinámico; si se estabiliza, vigilancia en " +
                            "recuperación prolongada",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: los criterios son clínicos: necesidad de broncodilatador " +
                            "continuo, acidosis progresiva o inestabilidad → ICU; " +
                            "estabilidad con dosis decrecientes → recuperación vigilada."
                    ),
                    CrisisOption(
                        "Toda crisis intraoperatoria de asma exige ICU",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: no toda: la crisis leve-moderada que se estabiliza con " +
                            "1–2 dosis de salbutamol se vigila en recuperación; ICU según " +
                            "criterios."
                    ),
                    CrisisOption(
                        "Extubar profundamente para evitar tos y retirada del tubo",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: en asmáticos se extuba DESPIERTO o con profilaxis " +
                            "adecuada (lidocaína IV 1,5 mg/kg), valorando el riesgo " +
                            "individual; la extubación profunda se decide por caso."
                    ),
                    CrisisOption(
                        "Retirar todos los halogenados siempre en asmáticos",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: los halogenados son broncodilatadores; salvo " +
                            "sospecha de reacción alérgica o hipercapnia grave que exija " +
                            "TOTIVA, no hay que retirarlos sistemáticamente."
                    )
                )
            ),
            CrisisStep(
                situation = "Al planificar el alta, el equipo revisa la profilaxis futura del " +
                    "paciente asmático.",
                monitor = "FC 88 · SpO2 97% en aire · sibilancias escasas",
                options = listOf(
                    CrisisOption(
                        "Preoperatorio: confirmar asma controlada (síntomas, FEV1 si hay, " +
                            "continuar broncodilatador el día de la cirugía, " +
                            "corticoides orales 3–5 días si crisis reciente o esteroide " +
                            "previo)",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: la mejor «terapia» del broncoespasmo intraoperatorio es " +
                            "la optimización preoperatoria: asma controlada, " +
                            "broncodilatador el día de la cirugía y esteroides si hay " +
                            "inestabilidad reciente."
                    ),
                    CrisisOption(
                        "Suspender el inhalador 48 h antes para evitar " +
                            "interacciones",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: los broncodilatadores inhalados se CONTINUAN el día de " +
                            "la cirugía; suspenderlos desprotege la vía aérea."
                    ),
                    CrisisOption(
                        "Aplazar cirugía electiva solo si hay infección respiratoria " +
                            "activa o asma descompensada",
                        CrisisEngine.GRADE_ACCEPTABLE,
                        "Aceptable y correcto en general: cirugía electiva con asma " +
                            "inestable o infección activa se difiere; asma estable " +
                            "controlada no contraindica."
                    ),
                    CrisisOption(
                        "Evitar siempre intubación y usar mascarilla laríngea en todos " +
                            "los asmáticos",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: la mascarilla laríngea reduce el reflejo del tubo, " +
                            "pero la elección depende del procedimiento (reflujo, " +
                            "posición, duración); no es regla universal."
                    )
                )
            )
        ),
        debrief = listOf(
            "Sibilancias intraoperatorias: primero descartar causa mecánica (tubo " +
                "obstruido, desplazado, neumotórax, edema) y PROFUNDIZAR anestesia.",
            "Broncoespasmo establecido: salbutamol 4–8 pulsaciones por el tubo con " +
                "cámara (repetible c/10–20 min) + tiempo espiratorio largo.",
            "Atrapamiento grave: hipercapnia permisiva (pH >7,2), FR 6–8, I:E 1:3; " +
                "desconexión breve del circuito si hay hipotensión por atrapamiento.",
            "Esteroide temprano (actúa en 4–6 h) como soporte de la fase tardía; " +
                "aminofilina no es de primera línea intraoperatoria.",
            "Prevenir: asma optimizada, broncodilatador el día de la cirugía, " +
                "esteroides si crisis reciente, profundidad adecuada antes de " +
                "instrumentar la vía aérea."
        ),
        doses = listOf(
            "Salbutamol: 4–8 pulsaciones por el tubo con cámara (o 2,5–5 mg nebulizado) c/10–20 min",
            "Propofol: 0,5–1 mg/kg IV en bolo para profundizar",
            "Ketamina: 0,5–1 mg/kg IV (broncodilatador, alternativa si se retira halogenado)",
            "Hidrocortisona: 200 mg IV (o metilprednisolona 80–125 mg) al inicio",
            "Hipercapnia permisiva: pH objetivo >7,2 · FR 6–8 · I:E 1:3–1:4",
            "Lidocaína IV 1,5 mg/kg antes de extubación en asmáticos reactivos"
        ),
        refs = "GINA 2023 · Morgan & Mikhail 7.ª ed. · Guías de anestesia en asma (ESAIC)"
    ),

    // ------------------------------------------------------------------
    // 8. Neumotórax a tensión intraoperatorio
    // ------------------------------------------------------------------
    CrisisScenario(
        id = "neumotorax_tension",
        title = "Neumotórax a tensión intraoperatorio",
        subtitle = "Adulto · colapso tras ventilación con presión alta",
        category = "Circulación",
        level = "R2–R4",
        intro = "Varón de 61 años, ASA III (EPOC grave, enfisema), esofagectomía en curso en " +
            "posición lateral izquierda, ventilación mecánica con Vc 450 mL, PEEP 8. " +
            "Tras 2 h de cirugía la SpO2 cae a 85%, la presión de pico sube a 40 cmH2O " +
            "y la PA cae a 75/40 con FC 128. Las venas del cuello están distendidas.",
        monitor = "FC 128 · PA 75/40 ↓↓ · SpO2 85% ↓ · Ppico 40 ↑↑ · EtCO2 21 ↓",
        steps = listOf(
            CrisisStep(
                situation = "Hipoxemia + hipotensión + Ppico 40 + EtCO2 bajo + yugulares " +
                    "llenas en un paciente en ventilación con presión alta. Cuadro muy " +
                    "sugestivo de una emergencia obstructiva.",
                monitor = "FC 128 · PA 75/40 · SpO2 85% · Ppico 40 · EtCO2 21",
                options = listOf(
                    CrisisOption(
                        "Sospechar neumotórax a tensión: O2 100%, ventilación manual con " +
                            "presión mínima y descompresión inmediata con aguja 14–16 G en " +
                            "2.º espacio intercostal línea medioclavicular del lado " +
                            "afecto",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: el neumotórax a tensión es un diagnóstico CLÍNICO: no se " +
                            "espera radiografía. Aguja en 2.º EIC línea medioclavicular (o 4.º " +
                            "EIC línea axilar anterior en adultos) salva la vida en " +
                            "segundos."
                    ),
                    CrisisOption(
                        "Pedir radiografía de tórax portátil y esperar",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: en tensión el paciente muere en minutos; la " +
                            "descompresión con aguja es clínica, antes de cualquier imagen."
                    ),
                    CrisisOption(
                        "Techo diagnóstico: embolia pulmonar; dar bolos de volumen",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: la PE puede coexistir, pero Ppico 40 + yugulares llenas " +
                            "+ un pulmón que no ventila apunta a tensión; el volumen en " +
                            "obstrucción agravará la hipotensión."
                    ),
                    CrisisOption(
                        "Aumentar PEEP a 15 para reclutar",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: en enfisema con fuga pleural, la PEEP alta acelera el " +
                            "neumotórax a tensión; es la causa que agrava el cuadro."
                    )
                )
            ),
            CrisisStep(
                situation = "Descompresión con aguja: salida de aire a presión y mejora " +
                    "inmediata (PA 100/60, SpO2 93%, Ppico 28). El cirujano pregunta por " +
                    "el paso siguiente.",
                monitor = "FC 112 · PA 100/60 · SpO2 93% · Ppico 28",
                options = listOf(
                    CrisisOption(
                        "Drenaje torácico definitivo (tubo 28–32 Fr) en 4.º–5.º EIC línea " +
                            "axilar media del lado afecto, conectado a sello de agua",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: la aguja es un puente: el neumotórax a tensión exige " +
                            "drenaje torácico definitivo; en cirugía lateral el acceso " +
                            "axilar ya está preparado por el propio cirujano."
                    ),
                    CrisisOption(
                        "Retirar la aguja y observar",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: retirar la aguja sin drenaje reproduce la tensión en " +
                            "minutos; la aguja se deja mientras se coloca el drenaje."
                    ),
                    CrisisOption(
                        "Colocar drenaje solo si la radiografía confirma",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: esperar imagen tras un neumotórax a tensión " +
                            "descomprimido es esperar la recurrencia; el drenaje es " +
                            "clínico."
                    ),
                    CrisisOption(
                        "Punción repetida con la misma aguja cada vez que empeore",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: el drenaje permanente es el tratamiento; la punción " +
                            "repetida es una solución transitoria en tránsito o traslado."
                    )
                )
            ),
            CrisisStep(
                situation = "Drenaje colocado: mejora franca. Surge la pregunta de cómo " +
                    "ventilar a este paciente EPOC de ahora en adelante.",
                monitor = "FC 98 · PA 110/65 · SpO2 96% · Ppico 22 · drenaje burbujeando",
                options = listOf(
                    CrisisOption(
                        "Ventilación protectora: Vc 6 mL/kg PBW, PEEP mínima eficaz, " +
                            "hipercapnia permisiva, I:E 1:3–1:4, plateau <30 cmH2O",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: en EPOC con fuga, la estrategia protectora (Vc 6, " +
                            "espirio largo, plateau bajo) evita la recidiva y el " +
                            "barotrauma; la hipercapnia permisiva es aceptable sin " +
                            "contraindicación."
                    ),
                    CrisisOption(
                        "Volver a los parámetros previos (Vc 450, PEEP 8) que funcionaban",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: esos parámetros fueron los que provocaron la " +
                            "sobreinsuflación y el neumotórax; volver a ellos garantiza " +
                            "la recidiva."
                    ),
                    CrisisOption(
                        "Aumentar PEEP para mejorar oxigenación",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: con fuga activa (drenaje burbujeando), la PEEP alta " +
                            "aumenta la fístula aérea y retrasa la reexpansión."
                    ),
                    CrisisOption(
                        "PEEP cero estricto y FiO2 100% permanentemente",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: la PEEP cero colapsa alveolos y empeora la " +
                            "oxigenación en EPOC; se usa PEEP mínima eficaz con FiO2 " +
                            "ajustada al objetivo (92–96% en EPOC con reserva " +
                            "respiratoria)."
                    )
                )
            ),
            CrisisStep(
                situation = "Cirugía terminada. El paciente se traslada con drenaje. El " +
                    "residente pregunta qué vigilancia exige en ICU.",
                monitor = "FC 92 · PA 118/70 · SpO2 95% · drenaje con burbujeo espiratorio",
                options = listOf(
                    CrisisOption(
                        "ICU con vigilancia de drenaje (oscilación, burbujeo, fuga), " +
                            "gasometría, radiografía de control y protocolo si hay " +
                            "fuga persistente >48 h",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: el drenaje se vigila (oscilación con la respiración, " +
                            "burbujeo continuo = fuga activa), con imagen de control y " +
                            "actitud quirúrgica si la fuga persiste."
                    ),
                    CrisisOption(
                        "Pinzar el drenaje durante el traslado para evitar pérdida de " +
                            "volumen",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: NUNCA se pinza un drenaje con fuga: recrea el " +
                            "neumotórax a tensión; el traslado es con el sistema abierto " +
                            "por debajo del tórax."
                    ),
                    CrisisOption(
                        "Retirar el drenaje en 24 h si mejora la radiografía",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: la retirada exige drenaje sin fuga (burbujeo cero) " +
                            "y pulmon re-expandido, no solo mejora radiológica."
                    ),
                    CrisisOption(
                        "Sello de agua en altura fija por encima del tórax y " +
                            "clampear si se tumba el paciente",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: el sello va SIEMPRE por debajo del tórax; " +
                            "clampear por posición es la causa clásica de tensión " +
                            "iatrogénica."
                    )
                )
            ),
            CrisisStep(
                situation = "Revisión de seguridad: qué debe hacer el servicio para que esto " +
                    "no vuelva a ocurrir en pacientes EPOC/enfisema.",
                monitor = "FC 84 · PA 120/72 · SpO2 96% · drenaje sin fuga",
                options = listOf(
                    CrisisOption(
                        "Protocolo de ventilación protectora en EPOC (Vc 6, plateau <30, " +
                            "PEEP mínima, vigilancia de plateau y gradientes), alerta en " +
                            "la hoja anestésica y simulación periódica del equipo",
                        CrisisEngine.GRADE_CORRECT,
                        "Correcto: la prevención es institucional: protocolo de " +
                            "ventilación protectora, alertas en la historia y " +
                            "entrenamiento (el Módulo del Tutor permite programar la " +
                            "sesión de simulación)."
                    ),
                    CrisisOption(
                        "Evitar ventilación mecánica en todos los EPOC",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: inviable; el EPOC exige ventilación CON técnica " +
                            "protectora, no su omisión."
                    ),
                    CrisisOption(
                        "Sustituir la vigilancia del plateau por la del Ppico",
                        CrisisEngine.GRADE_SUBOPT,
                        "Subóptimo: el Ppico incluye resistencia del tubo; el plateau " +
                            "refleja la presión alveolar y es el que hay que mantener " +
                            "<30 cmH2O."
                    ),
                    CrisisOption(
                        "Solo dar más volumen de cristaloides en los próximos casos",
                        CrisisEngine.GRADE_DANGEROUS,
                        "Peligroso: confunde la prevención hemodinámica con la " +
                            "respiratoria; el problema era mecánico-ventilatorio."
                    )
                )
            )
        ),
        debrief = listOf(
            "Neumotórax a tensión es diagnóstico CLÍNICO: hipoxemia + hipotensión + " +
                "Ppico alto + EtCO2 bajo + yugulares llenas → aguja YA, sin esperar " +
                "radiografía.",
            "Punción: 2.º EIC línea medioclavicular (o 4.º EIC línea axilar anterior) " +
                "14–16 G; luego DRENAJE torácico definitivo 28–32 Fr.",
            "En EPOC/enfisema: ventilación protectora (Vc 6 mL/kg PBW, plateau <30, " +
                "PEEP mínima eficaz, I:E 1:3) previene la recidiva.",
            "NUNCA pinzar un drenaje con fuga; sello de agua siempre por debajo del " +
                "tórax.",
            "La PEEP alta sobre un pulmón con fuga agrava la tensión: PEEP mínima " +
                "eficaz mientras burbujee el drenaje.",
            "El cuadro obstructivo (tensión) comparte patrón con embolia: Ppico alto " +
                "y yugulares llenas orientan a tensión; EtCO2 muy bajo con Ppico " +
                "normal orientan a embolia."
        ),
        doses = listOf(
            "Aguja de descompresión: 14–16 G · 2.º EIC línea medioclavicular o 4.º EIC axilar anterior",
            "Drenaje torácico: 28–32 Fr · 4.º–5.º EIC línea axilar media · sello de agua",
            "Vc protector: 6 mL/kg PBW · plateau <30 cmH2O · I:E 1:3–1:4",
            "Hipercapnia permisiva: pH >7,2",
            "FiO2 objetivo: SpO2 92–96% en EPOC con retención de CO2"
        ),
        refs = "ATLS 10.ª ed. · ERC/AHA 2021 · Guía ARDSnet ventilación protectora"
    ),
)
