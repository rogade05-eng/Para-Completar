package cu.cronos.anestesia

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri

// =====================================================================
//  ENLACES EXTERNOS (v2.5.0) — única fuente de verdad para las URLs.
//  La app NO tiene permiso INTERNET (contrato R-01): todo enlace se
//  delega con ACTION_VIEW a la aplicación externa que corresponda
//  (navegador, YouTube, Facebook). Si el dispositivo no tiene ninguna
//  app capaz de abrirlo, se ignora en silencio (sin bloqueo ni error).
// =====================================================================

object ExternalLinks {

    /** Video de presentación de Cronos Anestesia (Facebook). */
    const val CRONOS_VIDEO_FB = "https://www.facebook.com/share/v/19FTQBahTb/"

    /** Canal de YouTube del colaborador clínico (perlas clínicas). */
    const val MEDIK_BRAIN_YT = "https://www.youtube.com/@MedikBrain"

    /** Página de Facebook del colaborador clínico (perlas clínicas). */
    const val MEDIK_BRAIN_FB = "https://www.facebook.com/MedikBrain"

    /**
     * Abre una URL con una app externa. Devuelve false si no existe ninguna
     * app que pueda manejarla (ActivityNotFoundException) — comportamiento
     * silencioso exigido por la política offline de la app.
     */
    fun open(ctx: Context, url: String): Boolean {
        return try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            true
        } catch (_: ActivityNotFoundException) {
            false
        } catch (_: Exception) {
            false
        }
    }
}
