package cu.cronos.anestesia

/*
 * Ola 3 (v2.6.0): contenido clínico funcional — checklist OMS. Las olas
 * siguientes (fichas de fármacos, temas clínicos, escalas, protocolos,
 * perlas, premedicación y máquina) se añaden aquí en v2.6.1 con la misma
 * mecánica: clave = texto original español, falta → degradación a ES.
 */
object I18nClinical {

    private val EN = mapOf(
        "Antes de la inducción de la anestesia" to "Before induction of anesthesia",
        "¿Ha confirmado el paciente su identidad, el sitio, el procedimiento y el consentimiento?" to "Has the patient confirmed identity, site, procedure and consent?",
        "¿Está marcado el sitio de la operación?" to "Is the operation site marked?",
        "O no es aplicable." to "Or not applicable.",
        "¿Funciona el monitor del oxímetro de pulso colocado en el paciente?" to "Is the pulse oximeter monitor on the patient working?",
        "¿Tiene el paciente alergias conocidas?" to "Does the patient have known allergies?",
        "¿Existe vía aérea difícil o riesgo de aspiración?" to "Is there a difficult airway or aspiration risk?",
        "Si SÍ: equipo de vía aérea difícil disponible y asistencia." to "If YES: difficult airway equipment and assistance available.",
        "¿Existe riesgo de pérdida de sangre >500 mL (7 mL/kg en niños)?" to "Is there a risk of blood loss >500 mL (7 mL/kg in children)?",
        "Si SÍ: acceso venoso y fluidos o sangre planificados." to "If YES: IV access and fluids or blood planned.",
        "Antes de la incisión cutánea" to "Before skin incision",
        "Todos los miembros del equipo se presentan por su nombre y función." to "All team members introduce themselves by name and role.",
        "Se confirma verbalmente paciente, sitio y procedimiento." to "Patient, site and procedure are verbally confirmed.",
        "Se anticipan los eventos críticos: duración prevista, pérdida de sangre prevista y riesgos del paciente." to "Critical events are anticipated: expected duration, expected blood loss and patient risks.",
        "¿Se ha administrado la profilaxis antibiótica en los últimos 60 minutos?" to "Has antibiotic prophylaxis been given within the last 60 minutes?",
        "¿Se han mostrado las imágenes diagnósticas esenciales?" to "Have the essential diagnostic images been displayed?",
        "Estertor/riesgo esterno confirmado: ¿equipo de reesternotomía disponible?" to "Confirmed sternotomy risk: is the re-sternotomy team available?",
        "Solo cirugía cardíaca con esternotomía: instrumental y circulación extracorpórea listos." to "Cardiac surgery with sternotomy only: instruments and cardiopulmonary bypass ready.",
        "Antes de que el paciente salga del quirófano" to "Before the patient leaves the operating room",
        "La enfermera confirma verbalmente el nombre del procedimiento registrado." to "The nurse verbally confirms the name of the recorded procedure.",
        "Recuento completo de instrumental, gasas y agujas." to "Instrument, sponge and needle counts are complete.",
        "Identificación correcta de las muestras (leer en voz alta, incluido el nombre del paciente)." to "Specimens correctly labelled (read aloud, including the patient's name).",
        "¿Hay problemas con el equipo que deban resolverse?" to "Are there equipment problems to be addressed?",
        "¿Qué riesgos presenta el paciente para su recuperación y qué medidas debe tomar el equipo?" to "What are the patient's risks for recovery and what should the team do about them?",
        "OMS 2009 · verificación en voz alta con todo el equipo. Los ítems marcados como críticos no deben pasarse nunca." to "WHO 2009 · verification aloud with the whole team. Items marked as critical must never be skipped.",
        "Progreso: " to "Progress: ",
        "Fase " to "Phase ",
        " completada (" to " completed (",
        "Anúnciela en voz alta al equipo antes de continuar." to "Announce it aloud to the team before continuing.",
        "Checklist OMS · " to "WHO checklist · ",
        "Marcados: " to "Checked: ",
        " de " to " of ",
        "\nPENDIENTES CRÍTICOS:\n" to "\nPENDING CRITICAL ITEMS:\n",
        "Checklist OMS" to "WHO checklist"
    )

    private val PT = mapOf(
        "Antes de la inducción de la anestesia" to "Antes da indução da anestesia",
        "¿Ha confirmado el paciente su identidad, el sitio, el procedimiento y el consentimiento?" to "O paciente confirmou identidade, local, procedimento e consentimento?",
        "¿Está marcado el sitio de la operación?" to "O local da operação está marcado?",
        "O no es aplicable." to "Ou não se aplica.",
        "¿Funciona el monitor del oxímetro de pulso colocado en el paciente?" to "O monitor do oxímetro de pulso no paciente está funcionando?",
        "¿Tiene el paciente alergias conocidas?" to "O paciente tem alergias conhecidas?",
        "¿Existe vía aérea difícil o riesgo de aspiración?" to "Há via aérea difícil ou risco de aspiração?",
        "Si SÍ: equipo de vía aérea difícil disponible y asistencia." to "Se SIM: equipamento de via aérea difícil disponível e assistência.",
        "¿Existe riesgo de pérdida de sangre >500 mL (7 mL/kg en niños)?" to "Há risco de perda de sangue >500 mL (7 mL/kg em crianças)?",
        "Si SÍ: acceso venoso y fluidos o sangre planificados." to "Se SIM: acesso venoso e fluidos ou sangue planejados.",
        "Antes de la incisión cutánea" to "Antes da incisão da pele",
        "Todos los miembros del equipo se presentan por su nombre y función." to "Todos os membros da equipe se apresentam pelo nome e função.",
        "Se confirma verbalmente paciente, sitio y procedimiento." to "Paciente, local e procedimento são confirmados verbalmente.",
        "Se anticipan los eventos críticos: duración prevista, pérdida de sangre prevista y riesgos del paciente." to "Os eventos críticos são antecipados: duração prevista, perda de sangue prevista e riscos do paciente.",
        "¿Se ha administrado la profilaxis antibiótica en los últimos 60 minutos?" to "A profilaxia antibiótica foi administrada nos últimos 60 minutos?",
        "¿Se han mostrado las imágenes diagnósticas esenciales?" to "As imagens diagnósticas essenciais foram exibidas?",
        "Estertor/riesgo esterno confirmado: ¿equipo de reesternotomía disponible?" to "Risco de esternotomia confirmado: há equipe de reesternotomia disponível?",
        "Solo cirugía cardíaca con esternotomía: instrumental y circulación extracorpórea listos." to "Apenas cirurgia cardíaca com esternotomia: instrumental e circulação extracorpórea prontos.",
        "Antes de que el paciente salga del quirófano" to "Antes de o paciente sair da sala cirúrgica",
        "La enfermera confirma verbalmente el nombre del procedimiento registrado." to "O enfermeiro confirma verbalmente o nome do procedimento registrado.",
        "Recuento completo de instrumental, gasas y agujas." to "Contagem completa de instrumental, compressas e agulhas.",
        "Identificación correcta de las muestras (leer en voz alta, incluido el nombre del paciente)." to "Identificação correta das amostras (ler em voz alta, incluindo o nome do paciente).",
        "¿Hay problemas con el equipo que deban resolverse?" to "Há problemas com o equipamento que devam ser resolvidos?",
        "¿Qué riesgos presenta el paciente para su recuperación y qué medidas debe tomar el equipo?" to "Quais são os riscos do paciente para a recuperação e o que a equipe deve fazer?",
        "OMS 2009 · verificación en voz alta con todo el equipo. Los ítems marcados como críticos no deben pasarse nunca." to "OMS 2009 · verificação em voz alta com toda a equipe. Os itens marcados como críticos nunca devem ser pulados.",
        "Progreso: " to "Progresso: ",
        "Fase " to "Fase ",
        " completada (" to " concluída (",
        "Anúnciela en voz alta al equipo antes de continuar." to "Anuncie em voz alta à equipe antes de continuar.",
        "Checklist OMS · " to "Checklist OMS · ",
        "Marcados: " to "Marcados: ",
        " de " to " de ",
        "\nPENDIENTES CRÍTICOS:\n" to "\nCRÍTICOS PENDENTES:\n",
        "Checklist OMS" to "Checklist OMS"
    )

    fun register() {
        L10n.register(Lang.EN, EN)
        L10n.register(Lang.PT, PT)
    }
}
