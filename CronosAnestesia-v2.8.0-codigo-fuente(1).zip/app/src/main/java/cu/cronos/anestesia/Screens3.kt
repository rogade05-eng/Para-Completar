package cu.cronos.anestesia

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// =====================================================================
//  PANTALLAS v2.0.0: PERLAS CLÍNICAS + EXPEDIENTE + CONSENTIMIENTO
//  Mismas reglas de alineación (ItemCard, DetailTopBar, ScreenColumn).
// =====================================================================

// ============================== PERLAS CLÍNICAS ==============================

@Composable
fun PearlsTab(onOpen: (Int) -> Unit) {
    val sp = LocalSpacing.current
    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = sp.screenHPad.dp, vertical = sp.s.dp),
        verticalArrangement = Arrangement.spacedBy(sp.xs.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                )
            ) {
                Text(
                    stringResource(R.string.pearls_intro),
                    modifier = Modifier.padding(sp.m.dp),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }
        items(PEARLS.size) { i ->
            val p = PEARLS[i]
            ItemCard(
                title = p.titulo,
                subtitle = p.video,
                badge = PEARLS_CANAL,
                onClick = { onOpen(i) }
            )
        }
    }
}

@Composable
fun PearlDetail(index: Int, onBack: () -> Unit) {
    val sp = LocalSpacing.current
    val p = PEARLS[index.coerceIn(0, PEARLS.size - 1)]
    DetailTopBar(p.titulo, stringResource(R.string.pearls_subtitle), onBack)
    ScreenColumn {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(sp.m.dp)) {
                Text(
                    stringResource(R.string.pearls_video),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    p.video,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(sp.xs.dp))
                Text(
                    p.resumen,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        SectionLabel(stringResource(R.string.pearls_claves))
        p.claves.forEachIndexed { i, c ->
            Text(
                c,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        SectionLabel(stringResource(R.string.pearls_errores))
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.10f)
            )
        ) {
            Text(
                p.errores,
                modifier = Modifier.padding(sp.m.dp),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        SectionLabel(stringResource(R.string.pearls_alarma))
        BodyText(p.alarma)

        SectionLabel(stringResource(R.string.pearls_aplicacion))
        BodyText(p.aplicacion)

        SectionLabel(stringResource(R.string.sec_referencias))
        Text(
            stringResource(R.string.pearls_fuente, PEARLS_CANAL),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// ============================== EXPEDIENTE ==============================

private val DATE_FMT = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())

@Composable
fun ExpedienteTab(onActivate: () -> Unit) {
    val sp = LocalSpacing.current
    val lic = LocalLicense.current
    if (!lic.features.expediente) {
        LockedSection(
            stringResource(R.string.tab_expediente),
            stringResource(R.string.lic_lock_exp_msg),
            onActivate = onActivate
        )
        return
    }
    var which by rememberSaveable { mutableStateOf(0) }
    Column(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = sp.screenHPad.dp)) {
            Spacer(Modifier.height(sp.s.dp))
            SegmentedRow(
                listOf(
                    stringResource(R.string.exp_seg_record),
                    stringResource(R.string.exp_seg_consent),
                    stringResource(R.string.exp_seg_analysis)
                ),
                selected = which,
                onSelect = { which = it }
            )
        }
        when (which) {
            0 -> RecordSection()
            1 -> ConsentSection()
            else -> AnalysisSection()
        }
    }
}

@Composable
private fun RecordSection() {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    var patients by remember { mutableStateOf(Expediente.patients(ctx)) }
    var activeId by remember { mutableStateOf(Expediente.activeId(ctx)) }
    var draft by remember(activeId) {
        mutableStateOf(
            patients.firstOrNull { it.id == activeId } ?: Expediente.newPatient()
        )
    }
    val entries = remember(activeId) {
        if (activeId.isBlank()) emptyList() else Expediente.entries(ctx, activeId)
    }
    val isNew = patients.none { it.id == draft.id }

    ScreenColumn {
        // Selector de paciente
        SectionLabel(stringResource(R.string.exp_patients))
        if (patients.isEmpty()) {
            Text(
                stringResource(R.string.exp_no_patients),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            patients.chunked(2).forEach { pair ->
                Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
                    pair.forEach { p ->
                        AppButton(
                            p.name.ifBlank { stringResource(R.string.exp_unnamed) },
                            secondary = p.id != activeId,
                            modifier = Modifier.weight(1f),
                            onClick = {
                                activeId = p.id
                                Expediente.setActive(ctx, p.id)
                                draft = p
                            }
                        )
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }

        // Datos del paciente
        SectionLabel(stringResource(R.string.exp_data))
        OutlinedTextField(
            value = draft.name, onValueChange = { draft = draft.copy(name = it) },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            label = { Text(stringResource(R.string.exp_name)) },
            shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            OutlinedTextField(
                value = draft.ci, onValueChange = { draft = draft.copy(ci = it) },
                modifier = Modifier.weight(1f), singleLine = true,
                label = { Text(stringResource(R.string.exp_ci)) },
                shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
            )
            OutlinedTextField(
                value = draft.age, onValueChange = { draft = draft.copy(age = it) },
                modifier = Modifier.weight(0.6f), singleLine = true,
                label = { Text(stringResource(R.string.exp_age)) },
                shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            OutlinedTextField(
                value = draft.sex, onValueChange = { draft = draft.copy(sex = it) },
                modifier = Modifier.weight(0.6f), singleLine = true,
                label = { Text(stringResource(R.string.exp_sex)) },
                shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
            )
            OutlinedTextField(
                value = draft.weightKg, onValueChange = { draft = draft.copy(weightKg = it) },
                modifier = Modifier.weight(1f), singleLine = true,
                label = { Text(stringResource(R.string.exp_weight)) },
                shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
            )
            OutlinedTextField(
                value = draft.heightCm, onValueChange = { draft = draft.copy(heightCm = it) },
                modifier = Modifier.weight(1f), singleLine = true,
                label = { Text(stringResource(R.string.exp_height)) },
                shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
            )
        }
        OutlinedTextField(
            value = draft.hx, onValueChange = { draft = draft.copy(hx = it) },
            modifier = Modifier.fillMaxWidth(),
            label = { Text(stringResource(R.string.exp_hx)) },
            shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            AppButton(
                stringResource(if (isNew) R.string.exp_new else R.string.exp_save),
                modifier = Modifier.weight(1f),
                onClick = {
                    val toSave = draft.copy(id = draft.id)
                    Expediente.savePatient(ctx, toSave)
                    activeId = toSave.id
                    patients = Expediente.patients(ctx)
                    draft = toSave
                }
            )
            AppButton(
                stringResource(R.string.exp_new_btn),
                secondary = true,
                modifier = Modifier.weight(1f),
                onClick = {
                    draft = Expediente.newPatient()
                    activeId = ""
                }
            )
        }
        if (!isNew) {
            AppButton(
                stringResource(R.string.exp_delete),
                secondary = true,
                danger = true,
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    Expediente.deletePatient(ctx, draft.id)
                    patients = Expediente.patients(ctx)
                    activeId = Expediente.activeId(ctx)
                    draft = patients.firstOrNull { it.id == activeId } ?: Expediente.newPatient()
                }
            )
        }

        // Entradas guardadas
        SectionLabel(stringResource(R.string.exp_entries, entries.size))
        if (entries.isEmpty()) {
            Text(
                stringResource(R.string.exp_no_entries),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        entries.forEach { e ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(sp.m.dp)) {
                    Text(
                        e.tag,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        DATE_FMT.format(Date(e.ts)),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        e.text,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(sp.xs.dp))
                    AppButton(
                        stringResource(R.string.exp_delete_entry),
                        secondary = true,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            Expediente.deleteEntry(ctx, e.patientId, e.ts)
                            patients = Expediente.patients(ctx)
                        }
                    )
                }
            }
        }

        // Exportación
        SectionLabel(stringResource(R.string.exp_export))
        val current = patients.firstOrNull { it.id == (if (isNew) activeId else draft.id) }
            ?: patients.firstOrNull()
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            AppButton(
                stringResource(R.string.exp_export_pdf),
                secondary = true,
                modifier = Modifier.weight(1f),
                enabled = current != null,
                onClick = {
                    current?.let {
                        val f = Expediente.exportPdf(ctx, it, Expediente.entries(ctx, it.id))
                        Expediente.share(ctx, f, "application/pdf")
                    }
                }
            )
            AppButton(
                stringResource(R.string.exp_export_csv),
                secondary = true,
                modifier = Modifier.weight(1f),
                enabled = current != null,
                onClick = {
                    current?.let {
                        val f = Expediente.exportCsv(ctx, it, Expediente.entries(ctx, it.id))
                        Expediente.share(ctx, f, "text/csv")
                    }
                }
            )
        }
        Text(
            stringResource(R.string.exp_export_note),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// ============================== CONSENTIMIENTO ==============================

@Composable
private fun ConsentSection() {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    // Paciente con autocompletado (v2.4.0): se elige entre los guardados
    // en el expediente y sus datos rellenan el documento.
    val savedPatients = remember { Expediente.patients(ctx) }
    var patientId by rememberSaveable { mutableStateOf(Expediente.activeId(ctx)) }
    val patient = savedPatients.firstOrNull { it.id == patientId }
        ?: savedPatients.firstOrNull()
        ?: Expediente.newPatient()
    var showPatientPicker by remember { mutableStateOf(false) }
    var template by rememberSaveable { mutableStateOf(ConsentTemplates.ANESTESIA) }
    // anestesia (plantilla original)
    var tech by rememberSaveable { mutableStateOf(0) }
    // datos comunes (precargados con los valores guardados del profesional)
    val stored = remember(template) { ConsentEditStore.load(ctx, template) }
    var anesth by rememberSaveable(template) { mutableStateOf(stored.anesthesiologist) }
    var institution by rememberSaveable(template) { mutableStateOf(stored.institution) }
    var service by rememberSaveable(template) { mutableStateOf(stored.service) }
    var procedure by rememberSaveable { mutableStateOf("") }
    var asa by rememberSaveable { mutableStateOf("II") }
    var risksExtra by rememberSaveable { mutableStateOf("") }
    // transfusión
    var components by rememberSaveable { mutableStateOf("") }
    var reason by rememberSaveable { mutableStateOf("") }
    // parto
    var partoTech by rememberSaveable { mutableStateOf(0) }
    val PARTO_TYPES = listOf(
        "Analgesia epidural continua",
        "Combinada espinal-epidural",
        "Analgesia espinal única"
    )
    val date = remember { SimpleDateFormat("d 'de' MMMM 'de' yyyy, HH:mm", Locale("es")).format(Date()) }
    val technique = Consent.TYPES[tech]

    // diálogos
    var showRead by remember { mutableStateOf(false) }
    var showEdit by remember { mutableStateOf(false) }
    var edit by remember(template) { mutableStateOf(ConsentEditStore.load(ctx, template)) }

    fun buildBlocksFor(templateId: String): List<Triple<String, Int, String>> {
        val p = patient ?: Expediente.newPatient()
        return when (templateId) {
            ConsentTemplates.TRANSFUSION -> ConsentTemplates.buildTransfusion(
                edit = edit, patient = p, anesthesiologist = anesth,
                institution = institution, service = service,
                procedure = procedure, components = components, reason = reason, date = date
            )
            ConsentTemplates.PARTO -> ConsentTemplates.buildParto(
                edit = edit, patient = p, anesthesiologist = anesth,
                institution = institution, service = service,
                technique = PARTO_TYPES[partoTech], risksExtra = risksExtra, date = date
            )
            ConsentTemplates.SEDACION -> ConsentTemplates.buildSedacion(
                edit = edit, patient = p, anesthesiologist = anesth,
                institution = institution, service = service,
                procedure = procedure, risksExtra = risksExtra, date = date
            )
            else -> Consent.buildBlocks(
                patient = p, anesthesiologist = anesth, institution = institution,
                service = service, technique = technique, procedure = procedure,
                risksExtra = risksExtra, date = date, asa = asa
            )
        }
    }

    ScreenColumn {
        SectionLabel("Paciente (autocompletado del expediente)")
        AppButton(
            if (patient.name.isBlank()) "Sin paciente — toque para elegir del expediente"
            else "${patient.name} · ${patient.age.ifBlank { "?" }} años · ${patient.weightKg.ifBlank { "?" }} kg · ${patient.heightCm.ifBlank { "?" }} cm",
            secondary = true,
            modifier = Modifier.fillMaxWidth(),
            onClick = { showPatientPicker = true }
        )
        Spacer(Modifier.height(sp.s.dp))
        SectionLabel("Plantilla de consentimiento")
        ConsentTemplates.ALL.chunked(2).forEachIndexed { rowIdx, pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
                pair.forEachIndexed { c, t ->
                    AppButton(
                        ConsentTemplates.title(t),
                        secondary = template != t,
                        modifier = Modifier.weight(1f),
                        onClick = { template = t }
                    )
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }

        SectionLabel(stringResource(R.string.consent_patient))
        Text(
            patient?.name?.ifBlank { null } ?: stringResource(R.string.consent_no_patient),
            style = MaterialTheme.typography.bodyMedium,
            color = if (patient?.name.isNullOrBlank()) MaterialTheme.colorScheme.error
            else MaterialTheme.colorScheme.onSurface
        )

        if (template == ConsentTemplates.ANESTESIA) {
            SectionLabel(stringResource(R.string.consent_technique))
            Consent.TYPES.chunked(2).forEachIndexed { rowIdx, pair ->
                Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
                    pair.forEachIndexed { c, t ->
                        AppButton(
                            t,
                            secondary = tech != rowIdx * 2 + c,
                            modifier = Modifier.weight(1f),
                            onClick = { tech = rowIdx * 2 + c }
                        )
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }

        if (template == ConsentTemplates.PARTO) {
            SectionLabel("Técnica obstétrica")
            PARTO_TYPES.forEachIndexed { i, t ->
                AppButton(
                    t,
                    secondary = partoTech != i,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { partoTech = i }
                )
            }
        }

        OutlinedTextField(
            value = anesth, onValueChange = { anesth = it },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            label = { Text(stringResource(R.string.consent_anesth)) },
            shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            OutlinedTextField(
                value = institution, onValueChange = { institution = it },
                modifier = Modifier.weight(1f), singleLine = true,
                label = { Text(stringResource(R.string.consent_institution)) },
                shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
            )
            OutlinedTextField(
                value = service, onValueChange = { service = it },
                modifier = Modifier.weight(1f), singleLine = true,
                label = { Text(stringResource(R.string.consent_service)) },
                shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
            )
        }
        if (template == ConsentTemplates.TRANSFUSION) {
            OutlinedTextField(
                value = reason, onValueChange = { reason = it },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("Motivo clínico (cirugía, hemorragia, anemia)") },
                shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
            )
            OutlinedTextField(
                value = components, onValueChange = { components = it },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("Hemocomponentes (p. ej.: 2 CGC + 1 PFC)") },
                shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
            )
        }
        if (template != ConsentTemplates.TRANSFUSION) {
            OutlinedTextField(
                value = procedure, onValueChange = { procedure = it },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                label = {
                    Text(
                        if (template == ConsentTemplates.SEDACION) "Procedimiento a realizar"
                        else stringResource(R.string.consent_procedure)
                    )
                },
                shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
            )
        }
        if (template == ConsentTemplates.ANESTESIA) {
            Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
                OutlinedTextField(
                    value = asa, onValueChange = { asa = it },
                    modifier = Modifier.weight(0.5f), singleLine = true,
                    label = { Text("ASA") },
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
                )
                OutlinedTextField(
                    value = risksExtra, onValueChange = { risksExtra = it },
                    modifier = Modifier.weight(1.5f), singleLine = true,
                    label = { Text(stringResource(R.string.consent_extra_risks)) },
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
                )
            }
        }

        if (edit.risks.isNotEmpty() || edit.clauses.isNotBlank()) {
            SectionLabel("Ediciones guardadas en esta plantilla")
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
                )
            ) {
                Column(Modifier.padding(sp.m.dp)) {
                    if (edit.risks.isNotEmpty())
                        Text("Riesgos añadidos: ${edit.risks.size}", style = MaterialTheme.typography.bodySmall)
                    if (edit.clauses.isNotBlank())
                        Text("Cláusulas adicionales: ${edit.clauses.take(60)}${if (edit.clauses.length > 60) "…" else ""}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            AppButton(
                "Modo lectura",
                secondary = true,
                modifier = Modifier.weight(1f),
                onClick = { showRead = true }
            )
            AppButton(
                "Editar plantilla",
                secondary = true,
                modifier = Modifier.weight(1f),
                onClick = { showEdit = true }
            )
        }
        AppButton(
            stringResource(R.string.consent_save_defaults),
            secondary = true,
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                val d = edit.copy(institution = institution, service = service, anesthesiologist = anesth)
                edit = d
                ConsentEditStore.save(ctx, template, d)
            }
        )
        AppButton(
            stringResource(R.string.consent_export_pdf),
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                val blocks = buildBlocksFor(template)
                val pdfBlocks = blocks.map { (t, s) -> t to s }
                val f = Expediente.exportConsentPdf(ctx, pdfBlocks)
                Expediente.share(ctx, f, "application/pdf")
            }
        )
        Text(
            stringResource(R.string.consent_note),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }

    // ---------------- selector de paciente (v2.4.0) ----------------
    if (showPatientPicker) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showPatientPicker = false },
            confirmButton = {
                AppButton("Cerrar", onClick = { showPatientPicker = false })
            },
            title = {
                Text("Paciente del expediente", style = MaterialTheme.typography.titleMedium)
            },
            text = {
                Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
                    if (savedPatients.isEmpty()) {
                        Text(
                            "No hay pacientes guardados. Regístrelos en la pestaña Expediente y aparecerán aquí para rellenar automáticamente el consentimiento.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    savedPatients.forEach { p ->
                        ItemCard(
                            title = p.name.ifBlank { "(sin nombre)" },
                            subtitle = "CI ${p.ci.ifBlank { "—" }} · ${p.age.ifBlank { "?" }} años · ${p.weightKg.ifBlank { "?" }} kg · ${p.heightCm.ifBlank { "?" }} cm",
                            badge = if (p.id == patientId) "ACTIVO" else null,
                            onClick = {
                                patientId = p.id
                                Expediente.setActive(ctx, p.id)
                                showPatientPicker = false
                            }
                        )
                        Spacer(Modifier.height(8.dp))
                    }
                }
            }
        )
    }

    // ---------------- modo lectura ----------------
    if (showRead) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showRead = false },
            confirmButton = {
                AppButton("Cerrar", onClick = { showRead = false })
            },
            title = { Text("Vista previa · ${ConsentTemplates.title(template)}", style = MaterialTheme.typography.titleMedium) },
            text = {
                Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
                    buildBlocksFor(template).forEach { (t, s) ->
                        when (s) {
                            0 -> Text(
                                t,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            1 -> Text(
                                t,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            else -> Text(
                                t,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                }
            }
        )
    }

    // ---------------- editar plantilla ----------------
    if (showEdit) {
        var risksText by remember(showEdit) { mutableStateOf(edit.risks.joinToString("\n")) }
        var clausesText by remember(showEdit) { mutableStateOf(edit.clauses) }
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showEdit = false },
            confirmButton = {
                AppButton("Guardar cambios", onClick = {
                    val d = edit.copy(
                        risks = risksText.split("\n").map { it.trim() }.filter { it.isNotBlank() },
                        clauses = clausesText.trim()
                    )
                    edit = d
                    ConsentEditStore.save(ctx, template, d)
                    showEdit = false
                })
            },
            dismissButton = {
                AppButton("Restablecer", secondary = true, onClick = {
                    ConsentEditStore.clear(ctx, template)
                    edit = ConsentEditData()
                    showEdit = false
                })
            },
            title = { Text("Editar · ${ConsentTemplates.title(template)}", style = MaterialTheme.typography.titleMedium) },
            text = {
                Column(Modifier.fillMaxWidth()) {
                    Text(
                        "Los cambios se guardan en este teléfono y se aplican al documento. «Restablecer» devuelve la plantilla oficial.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = risksText, onValueChange = { risksText = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Riesgos particulares (uno por línea)") },
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = clausesText, onValueChange = { clausesText = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Cláusulas adicionales (texto libre)") },
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
                    )
                }
            }
        )
    }
}
