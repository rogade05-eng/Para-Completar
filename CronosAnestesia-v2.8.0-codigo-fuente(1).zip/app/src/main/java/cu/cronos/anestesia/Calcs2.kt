package cu.cronos.anestesia

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

// =====================================================================
//  CALCULADORAS DE TEMAS QUIRÚRGICOS (v2.0.0)
//  Mismos componentes y estilo que Calcs.kt (NumField/ResultCard).
//  Cada calculadora: campos → fórmulas de CalcEngine (testeables) →
//  ResultCard + botón «Guardar en expediente».
// =====================================================================

@Composable
private fun NumField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    suffix: String,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = modifier,
        label = { Text(label) },
        suffix = { Text(suffix) },
        singleLine = true,
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.primary,
            cursorColor = MaterialTheme.colorScheme.primary
        )
    )
}

/** ResultCard con guardado en el expediente del paciente activo (v2.0.0). */
@Composable
private fun ResultCard(title: String, lines: List<Pair<String, String>>, tag: String) {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(sp.m.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.height(sp.xs.dp))
            lines.forEach { (k, v) ->
                Text(
                    k,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    v,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(sp.xs.dp))
            }
            AppButton(
                stringResource(R.string.exp_save_calc),
                secondary = true,
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    Expediente.saveCalc(ctx, title, tag)
                    Toast.makeText(ctx, ctx.getString(R.string.exp_saved), Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}

@Composable
fun ClinCalcHost(calcId: String) {
    when (calcId) {
        "cpp" -> CppCalc()
        "anh" -> AnhCalc()
        "meld" -> MeldCalc()
        "mgso4" -> Mgso4Calc()
        "qpqs" -> QpQsCalc()
        "resp" -> RespPhysCalc()
        "cardio" -> CardioPhysCalc()
        "cec" -> CecCalc()
        "trauma" -> TraumaCalc()
        "olv" -> OlvCalc()
        "lap" -> LapCalc()
        "lamax" -> LocalAnestCalc()
        else -> {}
    }
}

// ---- CPP (neuroquirúrgico / TCE) ----

@Composable
fun CppCalc() {
    val sp = LocalSpacing.current
    var ps by rememberSaveable { mutableStateOf("120") }
    var pd by rememberSaveable { mutableStateOf("70") }
    var icp by rememberSaveable { mutableStateOf("15") }
    val map = CalcEngine.meanArterial(CalcEngine.parseNum(ps), CalcEngine.parseNum(pd))
    val cpp = CalcEngine.cpp(map, CalcEngine.parseNum(icp))
    val verdict = when {
        cpp >= 70 -> "Óptimo: CPP ≥70 mmHg"
        cpp >= 60 -> "Objetivo alcanzado: 60–70 mmHg"
        cpp >= 50 -> "Hipoperfusión: acción YA (volumen, vasopresor, revisar PIC)"
        else -> "Grave: CPP <50 mmHg — protocolo de PIC inmediato"
    }
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            NumField(ps, { ps = it }, "PAS", "mmHg", Modifier.weight(1f))
            NumField(pd, { pd = it }, "PAD", "mmHg", Modifier.weight(1f))
            NumField(icp, { icp = it }, "PIC", "mmHg", Modifier.weight(1f))
        }
        ResultCard(
            "Presión de perfusión cerebral",
            listOf(
                "PAM" to "${CalcEngine.fmt(map)} mmHg",
                "CPP = PAM − PIC" to "${CalcEngine.fmt(cpp)} mmHg",
                "Objetivo" to "60–70 mmHg (TCE grave: protocolo)",
                "Interpretación" to verdict
            ),
            tag = "CPP: ${CalcEngine.fmt(cpp)} mmHg (PAM ${CalcEngine.fmt(map)}, PIC ${CalcEngine.fmt(CalcEngine.parseNum(icp))})"
        )
    }
}

// ---- ANH (hemodilución) ----

@Composable
fun AnhCalc() {
    val sp = LocalSpacing.current
    var weight by rememberSaveable { mutableStateOf("70") }
    var cat by rememberSaveable { mutableStateOf(0) }
    var hct0 by rememberSaveable { mutableStateOf("42") }
    var hctT by rememberSaveable { mutableStateOf("28") }
    var hctMin by rememberSaveable { mutableStateOf("24") }
    val ebv = CalcEngine.estimatedBloodVolume(CalcEngine.parseNum(weight), cat)
    val r = CalcEngine.anh(
        ebv, CalcEngine.parseNum(hct0), CalcEngine.parseNum(hctT), CalcEngine.parseNum(hctMin)
    )
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            NumField(weight, { weight = it }, "Peso", "kg", Modifier.weight(1f))
            NumField(hct0, { hct0 = it }, "Hct inicial", "%", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            NumField(hctT, { hctT = it }, "Hct objetivo", "%", Modifier.weight(1f))
            NumField(hctMin, { hctMin = it }, "Hct mínimo", "%", Modifier.weight(1f))
        }
        SegmentedRow(
            listOf("Hombre", "Mujer", "Niño", "Lactante"),
            selected = cat,
            onSelect = { cat = it }
        )
        ResultCard(
            "Hemodilución aguda normovolémica",
            listOf(
                "Volemia estimada" to "${CalcEngine.fmt(ebv)} mL",
                "Volumen extraíble (ANH)" to "${CalcEngine.fmt(r.anhVolumeMl)} mL",
                "Sangrado permitido tras ANH" to "${CalcEngine.fmt(r.ablAfterMl)} mL",
                "Reposición" to "Cristaloide 3:1 o coloide 1:1 del volumen extraído; reinfundir la sangre al final (última bolsa primero)"
            ),
            tag = "ANH ${CalcEngine.fmt(r.anhVolumeMl)} mL · Hct ${CalcEngine.fmt(CalcEngine.parseNum(hct0))}→${CalcEngine.fmt(CalcEngine.parseNum(hctT))} %"
        )
    }
}

// ---- MELD-Na (trasplante hepático) ----

@Composable
fun MeldCalc() {
    val sp = LocalSpacing.current
    var bili by rememberSaveable { mutableStateOf("2.0") }
    var inr by rememberSaveable { mutableStateOf("1.5") }
    var creat by rememberSaveable { mutableStateOf("1.5") }
    var na by rememberSaveable { mutableStateOf("135") }
    var dialysis by rememberSaveable { mutableStateOf(false) }
    val r = CalcEngine.meldNa(
        CalcEngine.parseNum(bili), CalcEngine.parseNum(inr),
        CalcEngine.parseNum(creat), CalcEngine.parseNum(na), dialysis
    )
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            NumField(bili, { bili = it }, "Bilirrubina", "mg/dL", Modifier.weight(1f))
            NumField(inr, { inr = it }, "INR", "", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            NumField(creat, { creat = it }, "Creatinina", "mg/dL", Modifier.weight(1f))
            NumField(na, { na = it }, "Na", "mmol/L", Modifier.weight(1f))
        }
        SettingSwitchRow(
            "¿Diálisis 2 veces por semana (o CVVH)?",
            "Fija la creatinina en 4 mg/dL para el cálculo",
            dialysis,
            { dialysis = it }
        )
        ResultCard(
            "MELD-Na (trasplante hepático)",
            listOf(
                "MELD" to "${CalcEngine.fmt(r.meld)}",
                "MELD-Na" to "${CalcEngine.fmt(r.meldNa)}",
                "Riesgo" to r.mortality90d,
                "Rango" to "6–40 (≥30: prioridad alta de trasplante)"
            ),
            tag = "MELD-Na ${CalcEngine.fmt(r.meldNa)}"
        )
    }
}

// ---- MgSO4 (embarazo crítico) ----

@Composable
fun Mgso4Calc() {
    val sp = LocalSpacing.current
    var gph by rememberSaveable { mutableStateOf("1.0") }
    val mlh = CalcEngine.mgso4InfusionMlH(CalcEngine.parseNum(gph))
    Column {
        NumField(gph, { gph = it }, "Mantenimiento", "g/h")
        ResultCard(
            "Sulfato de magnesio (preeclampsia/eclampsia)",
            listOf(
                "Carga" to "4 g IV en 20–30 min (16–20 mL de la ampolla 20 %)",
                "Mantenimiento" to "${CalcEngine.fmt(CalcEngine.parseNum(gph))} g/h = ${CalcEngine.fmt(mlh)} mL/h (ampolla 2 g/10 mL)",
                "Recurrencia de eclampsia" to "2 g IV en bolo",
                "Antídoto" to "Gluconato de calcio 1 g IV lento",
                "Vigilancia" to "Reflejo patelar, FR >12/min, diuresis >0,5 mL/kg/h; potencial el bloqueo neuromuscular (TOF)"
            ),
            tag = "MgSO4 ${CalcEngine.fmt(CalcEngine.parseNum(gph))} g/h (${CalcEngine.fmt(mlh)} mL/h)"
        )
    }
}

// ---- Qp/Qs (cardiopatía congénita adulta) ----

@Composable
fun QpQsCalc() {
    val sp = LocalSpacing.current
    var sao by rememberSaveable { mutableStateOf("98") }
    var svo by rememberSaveable { mutableStateOf("70") }
    var spv by rememberSaveable { mutableStateOf("97") }
    var spa by rememberSaveable { mutableStateOf("80") }
    val ratio = CalcEngine.qpQs(
        CalcEngine.parseNum(sao), CalcEngine.parseNum(svo),
        CalcEngine.parseNum(spv), CalcEngine.parseNum(spa)
    )
    val verdict = when {
        ratio > 1.5 -> "Shunt L→R significativo (Qp/Qs >1,5): valorar cierre/interconsulta"
        ratio >= 1.0 -> "Sin shunt significativo o equilibrio"
        ratio > 0.0 -> "Shunt R→L dominante (Qp/Qs <1): fisiología cianótica"
        else -> "Datos incompletos (SpvO2 debe ser > SpaO2 en L→R)"
    }
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            NumField(sao, { sao = it }, "SaO2 aórtica", "%", Modifier.weight(1f))
            NumField(svo, { svo = it }, "SvO2 (VC/AD)", "%", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            NumField(spv, { spv = it }, "SpvO2 (vena pulm.)", "%", Modifier.weight(1f))
            NumField(spa, { spa = it }, "SpaO2 (art. pulm.)", "%", Modifier.weight(1f))
        }
        ResultCard(
            "Cociente de flujos pulmonar/sistémico",
            listOf(
                "Qp/Qs = (SaO2 − SvO2)/(SpvO2 − SpaO2)" to "${CalcEngine.fmt(ratio)}",
                "Interpretación" to verdict,
                "Umbrales" to ">1,5 L→R significativo · 1,5–2,0 cierre frecuente · <0,8 R→L significativo"
            ),
            tag = "Qp/Qs ${CalcEngine.fmt(ratio)}"
        )
    }
}

// ---- Fisiología respiratoria ----

@Composable
fun RespPhysCalc() {
    val sp = LocalSpacing.current
    var hb by rememberSaveable { mutableStateOf("14") }
    var sao by rememberSaveable { mutableStateOf("97") }
    var pao by rememberSaveable { mutableStateOf("95") }
    var paco by rememberSaveable { mutableStateOf("40") }
    var fio by rememberSaveable { mutableStateOf("21") }
    var age by rememberSaveable { mutableStateOf("40") }
    var co by rememberSaveable { mutableStateOf("5.0") }
    val fio2 = CalcEngine.parseNum(fio)
    val sao2 = (CalcEngine.parseNum(sao) / 100.0).coerceIn(0.0, 1.0)
    val cao2 = CalcEngine.caO2(CalcEngine.parseNum(hb), sao2, CalcEngine.parseNum(pao))
    val aa = CalcEngine.aaGradient(CalcEngine.parseNum(pao), fio2, CalcEngine.parseNum(paco))
    val aaLimit = CalcEngine.aaNormalLimit(CalcEngine.parseNum(age))
    val pf = CalcEngine.pfiIndex(CalcEngine.parseNum(pao), fio2)
    val do2 = CalcEngine.do2(CalcEngine.parseNum(co), cao2)
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            NumField(hb, { hb = it }, "Hb", "g/dL", Modifier.weight(1f))
            NumField(sao, { sao = it }, "SaO2", "%", Modifier.weight(1f))
            NumField(pao, { pao = it }, "PaO2", "mmHg", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            NumField(paco, { paco = it }, "PaCO2", "mmHg", Modifier.weight(1f))
            NumField(fio, { fio = it }, "FiO2", "%", Modifier.weight(1f))
            NumField(age, { age = it }, "Edad", "años", Modifier.weight(1f))
        }
        NumField(co, { co = it }, "Gasto cardíaco (CO)", "L/min")
        ResultCard(
            "Perfil de oxigenación",
            listOf(
                "CaO2 = 1,34×Hb×SaO2 + 0,0031×PaO2" to "${CalcEngine.fmt(cao2)} mL/dL",
                "Gradiente A–a" to "${CalcEngine.fmt(aa)} mmHg (límite por edad: ${CalcEngine.fmt(aaLimit)})",
                "Índice P/F (PaO2/FiO2)" to "${CalcEngine.fmt(pf)} (${when (CalcEngine.berlinClass(pf)) {
                    CalcEngine.Berlin.NONE -> "sin SDRA"
                    CalcEngine.Berlin.MILD -> "SDRA leve"
                    CalcEngine.Berlin.MODERATE -> "SDRA moderado"
                    CalcEngine.Berlin.SEVERE -> "SDRA grave"
                }})",
                "DO2 = CO × CaO2 × 10" to "${CalcEngine.fmt(do2)} mL/min (objetivo >400–600)",
                "Nota" to "La anemia reduce la CaO2 más que la PaO2: corregir Hb antes de «subir FiO2»"
            ),
            tag = "CaO2 ${CalcEngine.fmt(cao2)} · A–a ${CalcEngine.fmt(aa)} · DO2 ${CalcEngine.fmt(do2)}"
        )
    }
}

// ---- Fisiología cardiovascular ----

@Composable
fun CardioPhysCalc() {
    val sp = LocalSpacing.current
    var hr by rememberSaveable { mutableStateOf("70") }
    var sv by rememberSaveable { mutableStateOf("70") }
    var map by rememberSaveable { mutableStateOf("90") }
    var cvp by rememberSaveable { mutableStateOf("8") }
    var mpap by rememberSaveable { mutableStateOf("15") }
    var pawp by rememberSaveable { mutableStateOf("10") }
    val co = CalcEngine.parseNum(hr) * CalcEngine.parseNum(sv) / 1000.0
    val svr = CalcEngine.svr(CalcEngine.parseNum(map), CalcEngine.parseNum(cvp), co)
    val pvr = CalcEngine.pvr(CalcEngine.parseNum(mpap), CalcEngine.parseNum(pawp), co)
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            NumField(hr, { hr = it }, "FC", "lpm", Modifier.weight(1f))
            NumField(sv, { sv = it }, "VS", "mL", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            NumField(map, { map = it }, "PAM", "mmHg", Modifier.weight(1f))
            NumField(cvp, { cvp = it }, "PVC", "mmHg", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            NumField(mpap, { mpap = it }, "PAP media", "mmHg", Modifier.weight(1f))
            NumField(pawp, { pawp = it }, "PAWP/PCP", "mmHg", Modifier.weight(1f))
        }
        ResultCard(
            "Hemodinamia (CO · SVR · PVR)",
            listOf(
                "CO = FC × VS" to "${CalcEngine.fmt(co)} L/min",
                "SVR = (PAM − PVC) × 80/CO" to "${CalcEngine.fmt(svr)} dyn·s/cm5 (normal 800–1200)",
                "PVR = (PAPm − PAWP) × 80/CO" to "${CalcEngine.fmt(pvr)} dyn·s/cm5 (normal 100–250)",
                "Lectura rápida" to when {
                    svr < 800 && co > 6 -> "Vasoplejía: vasopresor (noradrenalina)"
                    svr > 1200 && co < 5 -> "Vasoconstricción con bajo gasto: valorar inodilatador"
                    co < 5 && svr in 800.0..1200.0 -> "Bajo gasto con tono conservado: inotrópico (dobutamina)"
                    else -> "Dentro de rangos: seguir el perfil clínico (frío/cálido, húmedo/seco)"
                }
            ),
            tag = "CO ${CalcEngine.fmt(co)} · SVR ${CalcEngine.fmt(svr)} · PVR ${CalcEngine.fmt(pvr)}"
        )
    }
}

// ---- CEC ----

@Composable
fun CecCalc() {
    val sp = LocalSpacing.current
    var height by rememberSaveable { mutableStateOf("170") }
    var weight by rememberSaveable { mutableStateOf("70") }
    var ci by rememberSaveable { mutableStateOf("2.4") }
    val bsa = CalcEngine.bsa(CalcEngine.parseNum(height), CalcEngine.parseNum(weight))
    val flow = CalcEngine.pumpFlow(bsa, CalcEngine.parseNum(ci))
    val hepU = CalcEngine.heparinUnits(3.5, CalcEngine.parseNum(weight))
    val prot = hepU / 100.0 * 1.2 // 1,2 mg por 100 UI
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            NumField(height, { height = it }, "Altura", "cm", Modifier.weight(1f))
            NumField(weight, { weight = it }, "Peso", "kg", Modifier.weight(1f))
        }
        NumField(ci, { ci = it }, "Índice cardíaco de bomba", "L/min/m²")
        ResultCard(
            "Cirugía cardíaca con CEC",
            listOf(
                "BSA (Mosteller)" to "${CalcEngine.fmt(bsa)} m²",
                "Flujo de bomba = BSA × IC" to "${CalcEngine.fmt(flow)} L/min",
                "Heparina (350 UI/kg)" to "${CalcEngine.fmt(hepU)} UI (${CalcEngine.fmt(hepU / 100.0)} mg) — ACT >480 s antes de canalizar",
                "Protamina (≈1,2 mg/100 UI)" to "${CalcEngine.fmt(prot)} mg IV lento en 10–15 min",
                "Vigilancia" to "ACT cada 30 min · Hct del circuito 20–25 % · PAM 50–70"
            ),
            tag = "CEC: flujo ${CalcEngine.fmt(flow)} L/min · heparina ${CalcEngine.fmt(hepU)} UI"
        )
    }
}

// ---- Trauma ----

@Composable
fun TraumaCalc() {
    val sp = LocalSpacing.current
    var weight by rememberSaveable { mutableStateOf("70") }
    var hbNow by rememberSaveable { mutableStateOf("9") }
    var hbTgt by rememberSaveable { mutableStateOf("10") }
    val units = CalcEngine.rbcUnits(CalcEngine.parseNum(weight), CalcEngine.parseNum(hbNow), CalcEngine.parseNum(hbTgt))
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            NumField(weight, { weight = it }, "Peso", "kg", Modifier.weight(1f))
            NumField(hbNow, { hbNow = it }, "Hb actual", "g/dL", Modifier.weight(1f))
            NumField(hbTgt, { hbTgt = it }, "Hb objetivo", "g/dL", Modifier.weight(1f))
        }
        ResultCard(
            "Transfusión en trauma",
            listOf(
                "CGR estimadas (ΔHb × peso/70)" to "${CalcEngine.fmt(kotlin.math.ceil(units))} unidades",
                "Protocolo MTP" to "CGR : PFP : PLT = 1 : 1 : 1 · fibrinógeno >200 mg/dL (crioprecipitado)",
                "Ácido tranexámico" to "1 g IV en 10 min + 1 g/8 h (solo si <3 h del trauma)",
                "Calcio" to "CaCl2 0,5–1 g/h con transfusión masiva (citrato): vigilar Ca iónico",
                "Recuerda" to "Triada letal: hipotermia + acidosis + coagulopatía — calentar SIEMPRE"
            ),
            tag = "CGR ≈ ${CalcEngine.fmt(kotlin.math.ceil(units))} U (Hb ${CalcEngine.fmt(CalcEngine.parseNum(hbNow))}→${CalcEngine.fmt(CalcEngine.parseNum(hbTgt))})"
        )
    }
}

// ---- OLV (ventilación unipulmonar) ----

@Composable
fun OlvCalc() {
    val sp = LocalSpacing.current
    var male by rememberSaveable { mutableStateOf(true) }
    var height by rememberSaveable { mutableStateOf("170") }
    var etco2meas by rememberSaveable { mutableStateOf("50") }
    var etco2tgt by rememberSaveable { mutableStateOf("40") }
    val ibw = CalcEngine.idealWeight(male, CalcEngine.parseNum(height))
    val vt = 6.0 * ibw
    val mvTarget = 100.0 * ibw // mL/min IBW
    val rr = CalcEngine.suggestedRr(mvTarget, vt)
    val rrNew = CalcEngine.rrForEtco2(rr, CalcEngine.parseNum(etco2meas), CalcEngine.parseNum(etco2tgt))
    Column {
        SegmentedRow(listOf("Hombre", "Mujer"), selected = if (male) 0 else 1, onSelect = { male = it == 0 })
        NumField(height, { height = it }, "Altura", "cm")
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            NumField(etco2meas, { etco2meas = it }, "EtCO2 medida", "mmHg", Modifier.weight(1f))
            NumField(etco2tgt, { etco2tgt = it }, "EtCO2 deseada", "mmHg", Modifier.weight(1f))
        }
        ResultCard(
            "Ventilación unipulmonar (pulmón dependiente)",
            listOf(
                "Peso ideal (Devine)" to "${CalcEngine.fmt(ibw)} kg",
                "VT = 6 mL/kg IBW" to "${CalcEngine.fmt(vt)} mL",
                "FR sugerida (MV ≈ 100 mL/kg IBW/min)" to "${CalcEngine.fmt(rr)} /min",
                "FR corregida por EtCO2" to "${CalcEngine.fmt(rrNew)} /min (medida ${CalcEngine.fmt(CalcEngine.parseNum(etco2meas))} → deseada ${CalcEngine.fmt(CalcEngine.parseNum(etco2tgt))})",
                "Base" to "PEEP 5–10 · FiO2 100 % inicial · hipoxemia: CPAP 2–5 al pulmón no dependiente (algoritmo del tema)"
            ),
            tag = "OLV: VT ${CalcEngine.fmt(vt)} mL · FR ${CalcEngine.fmt(rrNew)}"
        )
    }
}

// ---- Videocirugía (laparoscopía) ----

@Composable
fun LapCalc() {
    val sp = LocalSpacing.current
    var rr by rememberSaveable { mutableStateOf("14") }
    var etco2meas by rememberSaveable { mutableStateOf("48") }
    var etco2tgt by rememberSaveable { mutableStateOf("38") }
    var iap by rememberSaveable { mutableStateOf("14") }
    val rrNew = CalcEngine.rrForEtco2(CalcEngine.parseNum(rr), CalcEngine.parseNum(etco2meas), CalcEngine.parseNum(etco2tgt))
    val iapHigh = CalcEngine.parseNum(iap) > 15.0
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            NumField(rr, { rr = it }, "FR actual", "/min", Modifier.weight(1f))
            NumField(iap, { iap = it }, "Presión insuflación", "mmHg", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            NumField(etco2meas, { etco2meas = it }, "EtCO2 medida", "mmHg", Modifier.weight(1f))
            NumField(etco2tgt, { etco2tgt = it }, "EtCO2 deseada", "mmHg", Modifier.weight(1f))
        }
        ResultCard(
            "Videocirugía: ajuste ventilatorio",
            listOf(
                "FR nueva = FR × EtCO2 medida/EtCO2 deseada" to "${CalcEngine.fmt(rrNew)} /min",
                "Presión de insuflación" to if (iapHigh) "${CalcEngine.fmt(CalcEngine.parseNum(iap))} mmHg — ALTA: >15 mmHg ↑ riesgo (pedir al cirujano bajarla)" else "${CalcEngine.fmt(CalcEngine.parseNum(iap))} mmHg — aceptable (12–15)",
                "Ventilación" to "VT 6–8 mL/kg IBW (no subir VT para corregir el CO2) · PEEP 8–10 · reclutar en Trendelenburg",
                "Alerta" to "EtCO2 que CAE de golpe = embolia de CO2: detener insuflación y reanimar"
            ),
            tag = "LAP: FR ${CalcEngine.fmt(rrNew)} · IAP ${CalcEngine.fmt(CalcEngine.parseNum(iap))} mmHg"
        )
    }
}
