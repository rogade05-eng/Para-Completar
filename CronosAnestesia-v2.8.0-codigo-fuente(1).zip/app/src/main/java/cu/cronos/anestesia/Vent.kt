package cu.cronos.anestesia

// =====================================================================
//  MOTOR DE VENTILACIÓN (v2.4.0 — contrato §5.2 «cálculos ventilatorios»)
//  Matemática pura (sin Compose ni Android) para pruebas JVM con
//  vectores dorados, igual que CalcEngine. Referencias: ecuación alveolar,
//  Berlín 2012 (P/F), RSBI (Yang & Tobin), Bohr, constante de tiempo τ,
//  contenido arterial de O2 (CaO2).
//  Uso educativo: interpretar siempre con el cuadro clínico.
// =====================================================================

object Vent {

    const val PATM_MMHG = 760.0   // presión atmosférica a nivel del mar
    const val PH2O_MMHG = 47.0    // presión de vapor de agua a 37 °C
    const val RQ = 0.8            // cociente respiratorio habitual

    private fun r1(v: Double): Double = Math.round(v * 10.0) / 10.0

    // ------------------------- Volumen corriente -------------------------

    /** Peso predicho (PBW, Devine ajustado) en kg. Altura en cm. */
    fun pbwKg(male: Boolean, heightCm: Double): Double {
        if (heightCm <= 0) return 0.0
        val base = if (male) 50.0 else 45.5
        return r1(base + 0.91 * (heightCm - 152.4))
    }

    /** Volumen corriente protector: PBW × mL/kg (6 mL/kg objetivo clásico). */
    fun tidalVolumeMl(pbwKg: Double, mlPerKg: Double): Double =
        r1(pbwKg * mlPerKg)

    /** Rango de seguridad 4–8 mL/kg de PBW (mL). */
    fun tidalRangeMl(pbwKg: Double): Pair<Double, Double> =
        r1(pbwKg * 4.0) to r1(pbwKg * 8.0)

    // ------------------------- Ventilación minuto -------------------------

    /** Ventilación minuto en L/min (Vt en mL × FR). */
    fun minuteVentilationL(vtMl: Double, rate: Double): Double =
        r1(vtMl * rate / 1000.0)

    /** FR necesaria para una VM objetivo (L/min) con el Vt indicado. */
    fun rateForMinuteVentilation(targetVmL: Double, vtMl: Double): Double {
        if (vtMl <= 0.0) return 0.0
        return r1(targetVmL * 1000.0 / vtMl)
    }

    /** Espacio muerto anatómico estimado: 2,2 mL/kg de PBW (adulto). */
    fun deadSpaceMl(pbwKg: Double): Double = r1(pbwKg * 2.2)

    /** Ventilación alveolar: (Vt − Vd) × FR, en L/min. */
    fun alveolarVentilationL(vtMl: Double, rate: Double, deadSpaceMl: Double): Double =
        r1((vtMl - deadSpaceMl) * rate / 1000.0)

    /** Regla práctica: VM × factor ⇒ PaCO2 ÷ factor (≈ constante de CO2). */
    fun correctedPaco2(currentPaco2: Double, vmFactor: Double): Double {
        if (vmFactor <= 0.0) return 0.0
        return r1(currentPaco2 / vmFactor)
    }

    // ------------------------- Mecánica respiratoria -------------------------

    /** Distensibilidad estática: Vt / (Pplat − PEEP), mL/cmH2O (normal 50–100). */
    fun staticCompliance(vtMl: Double, pplat: Double, peep: Double): Double {
        val drive = pplat - peep
        if (drive <= 0.0) return 0.0
        return r1(vtMl / drive)
    }

    /** Presión motriz (driving pressure): Pplat − PEEP; meta < 15 cmH2O. */
    fun drivingPressure(pplat: Double, peep: Double): Double =
        r1(pplat - peep)

    /** Resistencia de la vía aérea: (Ppico − Pplat) / flujo (L/s), cmH2O·s/L. */
    fun airwayResistance(peak: Double, pplat: Double, flowLMin: Double): Double {
        if (flowLMin <= 0.0) return 0.0
        return r1((peak - pplat) / (flowLMin / 60.0))
    }

    /** Constante de tiempo τ = R × C (s): 3τ ≈ 95 % del volumen entregado. */
    fun timeConstantSeconds(resistanceCmH2OLs: Double, complianceMlCmH2O: Double): Double =
        r1(resistanceCmH2OLs * (complianceMlCmH2O / 1000.0))

    /** Índice de respiración rápida y superficial: FR / Vt(L); < 105 favorece extubar. */
    fun rsbi(rate: Double, vtMl: Double): Double {
        if (vtMl <= 0.0) return 0.0
        return r1(rate / (vtMl / 1000.0))
    }

    // ------------------------- Oxigenación -------------------------

    /** Presión alveolar de O2 (ecuación alveolar simplificada): FiO2·(Patm−PH2O) − PaCO2/R. */
    fun alveolarPo2(fio2: Double, paco2: Double, rq: Double = RQ,
                    patm: Double = PATM_MMHG, ph2o: Double = PH2O_MMHG): Double =
        r1(fio2 * (patm - ph2o) - paco2 / rq)

    /** Gradiente alveolo-arterial de O2. Normal ≈ (edad/4) + 4 mmHg. */
    fun aAGradient(fio2: Double, pao2: Double, paco2: Double, rq: Double = RQ): Double =
        r1(alveolarPo2(fio2, paco2, rq) - pao2)

    /** Gradiente esperado por la edad: (edad/4) + 4 mmHg. */
    fun expectedAAgradient(age: Int): Double =
        r1(age / 4.0 + 4.0)

    /** Relación PaO2/FiO2 (Berlín 2012). */
    fun pfratio(pao2: Double, fio2: Double): Double {
        if (fio2 <= 0.0) return 0.0
        return r1(pao2 / fio2)
    }

    /** Categoría P/F con prudentes matices (solo orientativa; el SDRA exige PEEP ≥ 5, bilateralidad y origen no cardiogénico). */
    fun pfCategory(pfratio: Double): String = when {
        pfratio <= 0.0 -> "Datos insuficientes"
        pfratio >= 400.0 -> "Oxigenación normal (P/F ≥ 400)"
        pfratio >= 300.0 -> "Alteración leve (P/F 300–399)"
        pfratio >= 200.0 -> "SDRA leve según Berlín (P/F 200–299)"
        pfratio >= 100.0 -> "SDRA moderado según Berlín (P/F 100–199)"
        else -> "SDRA grave según Berlín (P/F < 100)"
    }

    /** Índice de oxigenación de Horowitz: (PAM × FiO2 × 100) / PaO2; < 5 aceptable, > 20 crítico. */
    fun oxygenationIndex(meanAirwayPressure: Double, fio2: Double, pao2: Double): Double {
        if (pao2 <= 0.0) return 0.0
        return r1(meanAirwayPressure * fio2 * 100.0 / pao2)
    }

    // ------------------------- Espacio muerto y contenido -------------------------

    /** Fracción de espacio muerto de Bohr: (PaCO2 − ETCO2) / PaCO2 (normal 0,2–0,35). */
    fun bohrDeadSpaceFraction(paco2: Double, etco2: Double): Double {
        if (paco2 <= 0.0) return 0.0
        return Math.round(((paco2 - etco2) / paco2) * 100.0) / 100.0
    }

    /** Contenido arterial de O2: (1,34 × Hb × SaO2) + (0,003 × PaO2), mL/dL. */
    fun arterialO2Content(hbGdl: Double, sao2Fraction: Double, pao2: Double): Double =
        r1(1.34 * hbGdl * sao2Fraction + 0.003 * pao2)

    /** Entrega de O2: DO2 = GC(L/min) × CaO2(mL/dL) × 10, mL/min. */
    fun oxygenDelivery(cardiacOutputL: Double, arterialO2ContentMlDl: Double): Double =
        r1(cardiacOutputL * arterialO2ContentMlDl * 10.0)
}
