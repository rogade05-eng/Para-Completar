package cu.cronos.anestesia

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// =====================================================================
//  EXPEDIENTE DEL PACIENTE (v2.0.0)
//  Datos locales (SharedPreferences + org.json), 100 % offline:
//   · Pacientes: nombre, CI, edad, sexo, peso, altura, antecedentes
//   · Entradas: cálculos guardados (CPP, ANH, infusiones…) por paciente
//   · Exportación: PDF (PdfDocument nativo) y CSV/Excel vía FileProvider
//  Sin permiso INTERNET: solo intents de compartir (contrato R-01).
// =====================================================================

data class Patient(
    val id: String,
    val name: String,
    val ci: String,
    val age: String,
    val sex: String,
    val weightKg: String,
    val heightCm: String,
    val hx: String,
    val asa: String = ""
)

data class ExpEntry(
    val ts: Long,
    val patientId: String,
    val tag: String,
    val text: String
)

object Expediente {

    private const val PREFS = "expediente"
    private const val KEY_PATIENTS = "patients"
    private const val KEY_ENTRIES = "entries"
    private const val KEY_ACTIVE = "active"

    // ---------------- pacientes ----------------

    fun patients(ctx: Context): List<Patient> {
        val arr = JSONArray(prefs(ctx).getString(KEY_PATIENTS, "[]") ?: "[]")
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Patient(
                id = o.optString("id"),
                name = o.optString("name"),
                ci = o.optString("ci"),
                age = o.optString("age"),
                sex = o.optString("sex"),
                weightKg = o.optString("weight"),
                heightCm = o.optString("height"),
                hx = o.optString("hx"),
                asa = o.optString("asa")
            )
        }
    }

    fun savePatient(ctx: Context, p: Patient) {
        val prefs = prefs(ctx)
        val arr = JSONArray(prefs.getString(KEY_PATIENTS, "[]") ?: "[]")
        val out = JSONArray()
        var replaced = false
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("id") == p.id) {
                out.put(toJson(p)); replaced = true
            } else out.put(o)
        }
        if (!replaced) out.put(toJson(p))
        prefs.edit().putString(KEY_PATIENTS, out.toString()).apply()
        setActive(ctx, p.id)
    }

    fun deletePatient(ctx: Context, id: String) {
        val prefs = prefs(ctx)
        val arr = JSONArray(prefs.getString(KEY_PATIENTS, "[]") ?: "[]")
        val out = JSONArray()
        for (i in 0 until arr.length()) {
            if (arr.getJSONObject(i).optString("id") != id) out.put(arr.getJSONObject(i))
        }
        prefs.edit().putString(KEY_PATIENTS, out.toString()).apply()
        deleteEntries(ctx, id)
        if (activeId(ctx) == id) prefs.edit().remove(KEY_ACTIVE).apply()
    }

    fun newPatient(): Patient = Patient(
        id = "p" + System.currentTimeMillis(),
        name = "", ci = "", age = "", sex = "",
        weightKg = "", heightCm = "", hx = ""
    )

    private fun toJson(p: Patient): JSONObject = JSONObject()
        .put("id", p.id).put("name", p.name).put("ci", p.ci).put("age", p.age)
        .put("sex", p.sex).put("weight", p.weightKg).put("height", p.heightCm).put("hx", p.hx)
        .put("asa", p.asa)

    fun activeId(ctx: Context): String = prefs(ctx).getString(KEY_ACTIVE, "") ?: ""

    fun setActive(ctx: Context, id: String) {
        prefs(ctx).edit().putString(KEY_ACTIVE, id).apply()
    }

    fun activePatient(ctx: Context): Patient? =
        patients(ctx).firstOrNull { it.id == activeId(ctx) }

    // ---------------- entradas ----------------

    fun entries(ctx: Context, patientId: String): List<ExpEntry> {
        val arr = JSONArray(prefs(ctx).getString(KEY_ENTRIES, "[]") ?: "[]")
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ExpEntry(o.optLong("ts"), o.optString("pid"), o.optString("tag"), o.optString("text"))
        }.filter { it.patientId == patientId }.sortedByDescending { it.ts }
    }

    fun saveEntry(ctx: Context, patientId: String, tag: String, text: String) {
        val prefs = prefs(ctx)
        val arr = JSONArray(prefs.getString(KEY_ENTRIES, "[]") ?: "[]")
        arr.put(JSONObject().put("ts", System.currentTimeMillis())
            .put("pid", patientId).put("tag", tag).put("text", text))
        prefs.edit().putString(KEY_ENTRIES, arr.toString()).apply()
    }

    /** Guarda un registro en el paciente indicado y lo deja activo; devuelve el nombre. */
    fun saveEntryTo(ctx: Context, patientId: String, tag: String, text: String): String {
        saveEntry(ctx, patientId, tag, text)
        setActive(ctx, patientId)
        return patients(ctx).firstOrNull { it.id == patientId }?.name ?: ""
    }

    /**
     * Normaliza la clase ASA escrita por el usuario para estadísticas:
     * romano I–VI en mayúscula + sufijo -E si hay emergencia.
     */
    fun asaNormalized(raw: String): String {
        val norm = raw.uppercase().trim()
        val roman = Regex("\\b(I|II|III|IV|V|VI)\\b").find(norm)?.groupValues?.get(1)
            ?: return "Sin dato"
        val emergencia = norm.contains("EMERGENCIA") || Regex("-\\s*E\\b|\\bE\\b").containsMatchIn(norm)
        return if (emergencia) roman + "-E" else roman
    }

    /** Guarda un cálculo en el paciente activo (o crea uno temporal); devuelve el nombre. */
    fun saveCalc(ctx: Context, tag: String, text: String): String {
        var pid = activeId(ctx)
        if (pid.isBlank() || patients(ctx).none { it.id == pid }) {
            val p = newPatient()
            savePatient(ctx, p)
            pid = p.id
        }
        saveEntry(ctx, pid, tag, text)
        return patients(ctx).firstOrNull { it.id == pid }?.name ?: ""
    }

    fun deleteEntry(ctx: Context, patientId: String, ts: Long) {
        val prefs = prefs(ctx)
        val arr = JSONArray(prefs.getString(KEY_ENTRIES, "[]") ?: "[]")
        val out = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (!(o.optLong("ts") == ts && o.optString("pid") == patientId)) out.put(o)
        }
        prefs.edit().putString(KEY_ENTRIES, out.toString()).apply()
    }

    private fun deleteEntries(ctx: Context, patientId: String) {
        val prefs = prefs(ctx)
        val arr = JSONArray(prefs.getString(KEY_ENTRIES, "[]") ?: "[]")
        val out = JSONArray()
        for (i in 0 until arr.length()) {
            if (arr.getJSONObject(i).optString("pid") != patientId) out.put(arr.getJSONObject(i))
        }
        prefs.edit().putString(KEY_ENTRIES, out.toString()).apply()
    }

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---------------- exportación ----------------

    private fun exportDir(ctx: Context): File {
        val d = File(ctx.cacheDir, "exports").apply { mkdirs() }
        return d
    }

    /** Exporta el expediente (paciente + entradas) a PDF A4 y devuelve el archivo. */
    fun exportPdf(ctx: Context, patient: Patient, entries: List<ExpEntry>): File {
        val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val blocks = mutableListOf<Pair<String, Int>>() // (texto, estilo: 0 título, 1 encabezado, 2 cuerpo)
        blocks.add("Cronos Anestesia — Expediente clínico" to 0)
        blocks.add("Paciente" to 1)
        blocks.add(
            "Nombre: ${patient.name.ifBlank { "—" }}\n" +
                "Carné de identidad: ${patient.ci.ifBlank { "—" }}\n" +
                "Edad: ${patient.age.ifBlank { "—" }}    Sexo: ${patient.sex.ifBlank { "—" }}\n" +
                "Peso: ${patient.weightKg.ifBlank { "—" }} kg    Altura: ${patient.heightCm.ifBlank { "—" }} cm\n" +
                "Antecedentes / notas: ${patient.hx.ifBlank { "—" }}" to 2
        )
        blocks.add("Cálculos y registros guardados (${entries.size})" to 1)
        if (entries.isEmpty()) {
            blocks.add("Sin registros guardados para este paciente." to 2)
        } else {
            entries.forEach { e ->
                blocks.add("${fmt.format(Date(e.ts))} · ${e.tag}" to 1)
                blocks.add(e.text to 2)
            }
        }
        blocks.add("Documento generado offline por Cronos Anestesia. Uso clínico responsable; verificar antes de archivar." to 2)
        val f = File(exportDir(ctx), "expediente_${sanitize(patient.name.ifBlank { patient.id })}_${stamp()}.pdf")
        writePdf(f, blocks)
        return f
    }

    /** Exporta el expediente a CSV (compatible con Excel) y devuelve el archivo. */
    fun exportCsv(ctx: Context, patient: Patient, entries: List<ExpEntry>): File {
        val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val sb = StringBuilder("\uFEFF") // BOM para Excel
        sb.append("Cronos Anestesia - Expediente\n")
        sb.append("Paciente;CI;Edad;Sexo;Peso (kg);Altura (cm);Antecedentes\n")
        sb.append("${csv(patient.name)};${csv(patient.ci)};${csv(patient.age)};${csv(patient.sex)};${csv(patient.weightKg)};${csv(patient.heightCm)};${csv(patient.hx)}\n")
        sb.append("\nFecha;Sección;Registro\n")
        entries.forEach { e ->
            sb.append("${fmt.format(Date(e.ts))};${csv(e.tag)};${csv(e.text)}\n")
        }
        val f = File(exportDir(ctx), "expediente_${sanitize(patient.name.ifBlank { patient.id })}_${stamp()}.csv")
        f.writeText(sb.toString(), Charsets.UTF_8)
        return f
    }

    /** Genera el PDF del consentimiento informado y devuelve el archivo. */
    fun exportConsentPdf(ctx: Context, blocks: List<Pair<String, Int>>): File {
        val f = File(exportDir(ctx), "consentimiento_${stamp()}.pdf")
        writePdf(f, blocks)
        return f
    }

    /** Escribe bloques (estilo 0 título / 1 encabezado / 2 cuerpo) en un PDF ya nombrado (v2.2.0). */
    fun exportPdfBlocks(f: File, blocks: List<Pair<String, Int>>) = writePdf(f, blocks)

    /** Comparte un archivo generado (chooser sin INTERNET). */
    fun share(ctx: Context, f: File, mime: String) {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
        val intent = Intent(Intent.ACTION_SEND)
            .setType(mime)
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(intent, "Compartir " + f.name))
    }

    private fun writePdf(f: File, blocks: List<Pair<String, Int>>) {
        val doc = PdfDocument()
        val pageW = 595; val pageH = 842; val margin = 48f
        val bodyPaint = TextPaint().apply {
            textSize = 11f; color = 0xFF1A1A1A.toInt(); isAntiAlias = true
        }
        val headPaint = TextPaint(bodyPaint).apply {
            textSize = 13f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD); color = 0xFF00425A.toInt()
        }
        val titlePaint = TextPaint(headPaint).apply { textSize = 18f }
        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
        var canvas = page.canvas
        var y = margin

        fun newPage() {
            doc.finishPage(page)
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
            canvas = page.canvas
            y = margin
        }

        fun ensureSpace(needed: Float) {
            if (y + needed > pageH - margin) newPage()
        }

        fun draw(text: String, paint: TextPaint) {
            val width = pageW - 2 * margin
            val layout = StaticLayout.Builder
                .obtain(text, 0, text.length, paint, width.toInt())
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(2f, 1f)
                .build()
            ensureSpace(layout.height.toFloat() + 8f)
            canvas.save()
            canvas.translate(margin, y)
            layout.draw(canvas)
            canvas.restore()
            y += layout.height + 10f
        }

        blocks.forEach { (text, style) ->
            when (style) {
                0 -> draw(text, titlePaint)
                1 -> draw(text, headPaint)
                else -> draw(text, bodyPaint)
            }
        }
        // pie: número de página
        val foot = Paint(bodyPaint).apply { textSize = 9f; color = 0xFF888888.toInt() }
        canvas.drawText("Página $pageNo", margin, pageH - 24f, foot)
        doc.finishPage(page)
        f.outputStream().use { doc.writeTo(it) }
        doc.close()
    }

    private fun csv(v: String): String =
        "\"" + v.replace("\"", "\"\"").replace("\n", " ") + "\""

    private fun sanitize(s: String): String =
        s.trim().lowercase().map { c -> if (c.isLetterOrDigit()) c else '_' }.joinToString("").take(40)

    private fun stamp(): String =
        SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())
}
