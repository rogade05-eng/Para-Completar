// Escritor XLSX minimalista (v1.7.0): genera un .xlsx válido (OOXML en ZIP)
// con Kotlin puro y java.util.zip — SIN dependencias externas, sin INTERNET.
// Compatible con Excel, LibreOffice y Google Sheets.
package cu.cronos.anestesia

import java.io.ByteArrayOutputStream
import java.nio.charset.StandardCharsets
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object XlsxWriter {

    fun esc(s: String): String = buildString {
        for (c in s) when {
            c == '&' -> append("&amp;")
            c == '<' -> append("&lt;")
            c == '>' -> append("&gt;")
            c == '"' -> append("&quot;")
            c == '\'' -> append("&apos;")
            c == '\t' -> append("&#9;")
            c == '\n' -> append("&#10;")
            c == '\r' -> append("&#13;")
            c.code < 0x20 -> { /* control: omitir */ }
            else -> append(c)
        }
    }

    /** Convierte a referencia de columna: 0→A, 25→Z, 26→AA. */
    fun colRef(i: Int): String {
        var n = i
        val sb = StringBuilder()
        while (n >= 0) {
            sb.insert(0, ('A' + n % 26))
            n = n / 26 - 1
        }
        return sb.toString()
    }

    private fun sheetXml(header: List<String>, rows: List<List<String>>): String = buildString {
        append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
        append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">")
        append("<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews>")
        append("<cols>")
        header.indices.forEach { i ->
            append("<col min=\"").append(i + 1).append("\" max=\"").append(i + 1).append("\" width=\"26\" customWidth=\"1\"/>")
        }
        append("</cols><sheetData>")
        fun cell(r: Int, c: Int, v: String, style: Int) {
            append("<c r=\"").append(colRef(c)).append(r + 1).append('"')
            if (style > 0) append(" s=\"").append(style).append('"')
            append(" t=\"inlineStr\"><is><t xml:space=\"preserve\">").append(esc(v)).append("</t></is></c>")
        }
        // Fila 1: encabezado en negrita (estilo 1)
        append("<row r=\"1\">")
        header.forEachIndexed { c, h -> cell(0, c, h, 1) }
        append("</row>")
        rows.forEachIndexed { r, row ->
            append("<row r=\"").append(r + 2).append("\">")
            row.forEachIndexed { c, v -> cell(r, c, v, 0) }
            append("</row>")
        }
        append("</sheetData></worksheet>")
    }

    private val CONTENT_TYPES = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
        "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
        "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
        "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
        "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
        "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>" +
        "</Types>"

    private val ROOT_RELS = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
        "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>" +
        "</Relationships>"

    private val WORKBOOK = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" " +
        "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
        "<sheets><sheet name=\"Expediente\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>"

    private val WORKBOOK_RELS = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
        "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>" +
        "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>" +
        "</Relationships>"

    private val STYLES = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
        "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font>" +
        "<font><b/><sz val=\"11\"/><color rgb=\"FFFFFFFF\"/><name val=\"Calibri\"/></font></fonts>" +
        "<fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill>" +
        "<fill><patternFill patternType=\"gray125\"/></fill>" +
        "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF0B5E5B\"/><bgColor indexed=\"64\"/></patternFill></fill></fills>" +
        "<borders count=\"1\"><border/></borders>" +
        "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
        "<cellXfs count=\"2\">" +
        "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyAlignment=\"1\"><alignment vertical=\"top\" wrapText=\"1\"/></xf>" +
        "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyAlignment=\"1\"><alignment vertical=\"center\" wrapText=\"1\"/></xf>" +
        "</cellXfs></styleSheet>"

    /**
     * Genera el .xlsx con una hoja: encabezado verde en negrita + filas de datos.
     * Todas las celdas como texto inline (los expedientes no requieren fórmulas).
     */
    fun xlsx(header: List<String>, rows: List<List<String>>): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            fun put(name: String, content: String) {
                zip.putNextEntry(ZipEntry(name))
                zip.write(content.toByteArray(StandardCharsets.UTF_8))
                zip.closeEntry()
            }
            put("[Content_Types].xml", CONTENT_TYPES)
            put("_rels/.rels", ROOT_RELS)
            put("xl/workbook.xml", WORKBOOK)
            put("xl/_rels/workbook.xml.rels", WORKBOOK_RELS)
            put("xl/styles.xml", STYLES)
            put("xl/worksheets/sheet1.xml", sheetXml(header, rows))
        }
        return out.toByteArray()
    }

    /** Filas de expediente → hoja plana: una fila por entrada. */
    fun expedienteRows(
        patient: RecPatient,
        entries: List<RecEntry>
    ): Pair<List<String>, List<List<String>>> {
        val header = listOf(
            "Fecha", "Tipo", "Concepto", "Contexto", "Detalle", "Nota del profesional"
        )
        val rows = mutableListOf<List<String>>()
        entries.sortedBy { it.createdAt }.forEach { e ->
            val detail = e.lines.joinToString(" | ") { (k, v) -> "$k: $v" }
            rows.add(listOf(RecFmt.ts(e.createdAt), e.kind, e.title, e.subtitle, detail, e.note))
        }
        return header to rows
    }
}
