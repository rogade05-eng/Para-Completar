package cu.cronos.anestesia

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

// =====================================================================
//  CALCULADORAS DE VENTILACIÓN Y CONVERSOR DE PRESENTACIONES (v2.4.0)
//  1) Ventilación: Vt y VM — volumen corriente por peso predicho,
//     ventilación minuto, frecuencia necesaria y ventilación alveolar.
//     La altura se autocompleta desde el paciente activo del expediente
//     (contrato §5.2 «pacientes con autocompletado»).
//  2) Ventilación mecánica — distensibilidad, presión motriz,
//     resistencia, RSBI, espacio muerto (Bohr) e índice de oxigenación.
//  3) Conversor mg → mL del catálogo de presentaciones.
// =====================================================================

private fun vParseNum(s: String): Double = CalcEngine.parseNum(s)
private fun vFmt(v: Double): String = CalcEngine.fmt(v)

@Composable
private fun VentField(value: String, onChange: (String) -> Unit, label: String, suffix: String) {
    val sp = LocalSpacing.current
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        label = { Text(label) },
        trailingIcon = { if (suffix.isNotBlank()) Text(suffix) },
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.primary,
            cursorColor = MaterialTheme.colorScheme.primary
        )
    )
}

@Composable
private fun VentResult(title: String, lines: List<Pair<String, String>>, tag: String) {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(sp.m.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.height(sp.xs.dp))
            lines.forEach { (k, v) ->
                Text(k, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Text(v, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
                Spacer(Modifier.height(sp.xs.dp))
            }
            AppButton(
                stringResource(R.string.exp_save_calc),
                secondary = true,
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    Expediente.saveCalc(ctx, title, tag)
                    android.widget.Toast.makeText(ctx, ctx.getString(R.string.exp_saved), android.widget.Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}

@Composable
private fun VentNote(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

// ---------------- 1. Ventilación: Vt y VM ----------------

@Composable
fun VentTidalCalc() {
    val sp = LocalSpacing.current
    val ctx = LocalContext.current
    // Autocompletado (v2.4.0): altura del paciente activo del expediente
    var height by rememberSaveable {
        mutableStateOf(Expediente.activePatient(ctx)?.heightCm ?: "")
    }
    var male by rememberSaveable { mutableStateOf(true) }
    var mlKg by rememberSaveable { mutableStateOf(1) } // 0=4, 1=6, 2=8
    var rate by rememberSaveable { mutableStateOf("12") }
    var targetVm by rememberSaveable { mutableStateOf("") }

    val h = vParseNum(height)
    val pbw = Vent.pbwKg(male, h)
    val mlPerKg = when (mlKg) { 0 -> 4.0; 2 -> 8.0; else -> 6.0 }
    val vt = Vent.tidalVolumeMl(pbw, mlPerKg)
    val range = Vent.tidalRangeMl(pbw)
    val fr = vParseNum(rate)
    val vm = Vent.minuteVentilationL(vt, fr)
    val vd = Vent.deadSpaceMl(pbw)
    val vAlv = Vent.alveolarVentilationL(vt, fr, vd)
    val tv = vParseNum(targetVm)
    val frNeeded = if (tv > 0) Vent.rateForMinuteVentilation(tv, vt) else 0.0

    Column(verticalArrangement = Arrangement.spacedBy(sp.s.dp)) {
        VentNote(
            "Volumen corriente sobre el PESO PREDICHO (no el real): 6 mL/kg es el objetivo " +
                "protector estándar; 4–8 mL/kg es el rango de seguridad. En obesidad use siempre el peso predicho."
        )
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            AppButton("Hombre", secondary = !male, modifier = Modifier.weight(1f), onClick = { male = true })
            AppButton("Mujer", secondary = male, modifier = Modifier.weight(1f), onClick = { male = false })
        }
        VentField(height, { height = it }, "Altura (autocompletada del paciente activo)", "cm")
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            AppButton("4 mL/kg", secondary = mlKg != 0, modifier = Modifier.weight(1f), onClick = { mlKg = 0 })
            AppButton("6 mL/kg", secondary = mlKg != 1, modifier = Modifier.weight(1f), onClick = { mlKg = 1 })
            AppButton("8 mL/kg", secondary = mlKg != 2, modifier = Modifier.weight(1f), onClick = { mlKg = 2 })
        }
        VentField(rate, { rate = it }, "Frecuencia respiratoria programada", "/min")
        VentField(targetVm, { targetVm = it }, "Ventilación minuto deseada (opcional)", "L/min")

        if (h > 0) {
            VentResult(
                "Ventilación del paciente",
                listOf(
                    "Peso predicho (PBW)" to "${vFmt(pbw)} kg",
                    "Volumen corriente (${vFmt(mlPerKg)} mL/kg)" to "${vFmt(vt)} mL",
                    "Rango de seguridad 4–8 mL/kg" to "${vFmt(range.first)}–${vFmt(range.second)} mL",
                    "Ventilación minuto (Vt × FR)" to "${vFmt(vm)} L/min",
                    "Espacio muerto estimado (2,2 mL/kg)" to "${vFmt(vd)} mL",
                    "Ventilación alveolar (Vt − Vd) × FR" to "${vFmt(vAlv)} L/min"
                ) + if (tv > 0) listOf(
                    "FR para VM ${vFmt(tv)} L/min" to "${vFmt(frNeeded)} resp/min",
                    "Corrección de PaCO2 (regla VM × factor ⇒ PaCO2 ÷ factor)" to
                        if (tv > 0 && vm > 0) "factor ${vFmt(tv / vm)} ⇒ PaCO2 ≈ ${vFmt(Vent.correctedPaco2(40.0, tv / vm))} mmHg (desde 40 de referencia)"
                        else "—"
                ) else emptyList(),
                tag = "Vt ${vFmt(vt)} mL · VM ${vFmt(vm)} L/min · PBW ${vFmt(pbw)} kg · ${vFmt(mlPerKg)} mL/kg"
            )
        }
        VentNote(
            "En obesidad el peso real sobreestima el Vt y produce barotrauma; en el embarazo " +
                "el mismo principio (peso predicho pregestacional). Confirme con capnografía: PaCO2 objetivo 35–45 mmHg " +
                "(35–38 en neurocirugía, 30–34 en el trauma craneal con riesgo de herniación, según protocolo)."
        )
    }
}

// ---------------- 2. Ventilación mecánica ----------------

@Composable
fun VentMechCalc() {
    val sp = LocalSpacing.current
    var vt by rememberSaveable { mutableStateOf("450") }
    var peak by rememberSaveable { mutableStateOf("") }
    var pplat by rememberSaveable { mutableStateOf("") }
    var peep by rememberSaveable { mutableStateOf("5") }
    var flow by rememberSaveable { mutableStateOf("30") }
    var rate by rememberSaveable { mutableStateOf("14") }
    var paco2 by rememberSaveable { mutableStateOf("") }
    var etco2 by rememberSaveable { mutableStateOf("") }
    var pao2 by rememberSaveable { mutableStateOf("") }
    var fio2 by rememberSaveable { mutableStateOf("") }
    var map by rememberSaveable { mutableStateOf("") }

    val vtV = vParseNum(vt)
    val peakV = vParseNum(peak)
    val pplatV = vParseNum(pplat)
    val peepV = vParseNum(peep)
    val flowV = vParseNum(flow)
    val rateV = vParseNum(rate)

    val cst = Vent.staticCompliance(vtV, pplatV, peepV)
    val drive = Vent.drivingPressure(pplatV, peepV)
    val raw = Vent.airwayResistance(peakV, pplatV, flowV)
    val rsbi = Vent.rsbi(rateV, vtV)
    val paco2V = vParseNum(paco2)
    val etco2V = vParseNum(etco2)
    val bohr = Vent.bohrDeadSpaceFraction(paco2V, etco2V)
    val pao2V = vParseNum(pao2)
    val fio2V = vParseNum(fio2)
    val pf = Vent.pfratio(pao2V, fio2V)
    val mapV = vParseNum(map)
    val oi = Vent.oxygenationIndex(mapV, fio2V, pao2V)

    Column(verticalArrangement = Arrangement.spacedBy(sp.s.dp)) {
        VentNote(
            "Con el Vt, las presiones del monitor y la gasometría: distensibilidad, " +
                "presión motriz, resistencia, índice de respiración rápida y superficial, espacio muerto " +
                "de Bohr e índice de oxigenación. Complete solo los campos que tenga: el resto queda «—»."
        )
        VentField(vt, { vt = it }, "Volumen corriente medido", "mL")
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            VentField(peak, { peak = it }, "Pico de presión", "cmH2O")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            VentField(pplat, { pplat = it }, "Presión de meseta", "cmH2O")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            VentField(peep, { peep = it }, "PEEP", "cmH2O")
            VentField(flow, { flow = it }, "Flujo inspiratorio", "L/min")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            VentField(rate, { rate = it }, "Frecuencia", "/min")
            VentField(etco2, { etco2 = it }, "ETCO2", "mmHg")
        }
        VentField(paco2, { paco2 = it }, "PaCO2 (gasometría)", "mmHg")
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            VentField(pao2, { pao2 = it }, "PaO2", "mmHg")
            VentField(fio2, { fio2 = it }, "FiO2", "0–1")
        }
        VentField(map, { map = it }, "Presión media de la vía aérea (PAM)", "cmH2O")

        val hasMech = peakV > 0 && pplatV > 0
        val hasGas = paco2V > 0 && etco2V > 0
        val hasOxy = pao2V > 0 && fio2V > 0
        if (hasMech || hasGas || hasOxy) {
            val lines = mutableListOf<Pair<String, String>>()
            if (hasMech) {
                lines.add("Distensibilidad estática (Cst)" to "${vFmt(cst)} mL/cmH2O ${cstZone(cst)}")
                lines.add("Presión motriz (Pplat − PEEP)" to "${vFmt(drive)} cmH2O ${if (drive > 15) "· alta: objetivo < 15" else "· en meta"}")
                lines.add("Resistencia de la vía aérea" to "${vFmt(raw)} cmH2O·s/L ${rawZone(raw)}")
                lines.add("RSBI (FR / Vt en L)" to "${vFmt(rsbi)} ${if (rsbi in 0.01..104.9) "· < 105: favorable para extubar" else "· ≥ 105: aún no"}")
            }
            if (hasGas) {
                lines.add("Espacio muerto de Bohr (Vd/Vt)" to "${vFmt(bohr * 100)} % ${bohrZone(bohr)}")
            }
            if (hasOxy) {
                lines.add("Relación P/F" to "${vFmt(pf)} · ${Vent.pfCategory(pf)}")
                if (mapV > 0) lines.add("Índice de oxigenación (Horowitz)" to "${vFmt(oi)} ${oiZone(oi)}")
            }
            VentResult(
                "Mecánica y oxigenación",
                lines,
                tag = "Cst ${vFmt(cst)} · Raw ${vFmt(raw)} · RSBI ${vFmt(rsbi)} · P/F ${vFmt(pf)} · Vd/Vt ${vFmt(bohr)} · IO ${vFmt(oi)}"
            )
        }
        VentNote(
            "Claves: sube el pico con la meseta estable = vía o tubo (secreciones, broncoespasmo, " +
                "mordida); suben ambas = parénquima o pared (atelectasia, neumotórax, abdomen, edema). " +
                "Cst < 30 mL/cmH2O con Vt protector exige revisar posición, derrame y neumotórax antes de «ajustar el ventilador». " +
                "El P/F orienta, no diagnostica solo: el SDRA exige PEEP ≥ 5, infiltrados bilaterales y origen no cardiogénico."
        )
    }
}

private fun cstZone(c: Double): String = when {
    c <= 0.0 -> ""
    c < 30.0 -> "· reducida (parénquima/pared)"
    c > 100.0 -> "· alta (sobredistensión o enfisema)"
    else -> "· rango habitual"
}

private fun rawZone(r: Double): String = when {
    r <= 0.0 -> ""
    r > 15.0 -> "· alta: revisar vía, tubo y secreciones"
    else -> "· habitual"
}

private fun bohrZone(b: Double): String = when {
    b <= 0.0 -> ""
    b > 0.45 -> "· muy alta (shunt/embolia): revisar"
    b > 0.35 -> "· alta"
    else -> "· normal (0,20–0,35)"
}

private fun oiZone(i: Double): String = when {
    i <= 0.0 -> ""
    i > 20.0 -> "· crítico (> 20)"
    i > 10.0 -> "· comprometido (10–20)"
    else -> "· aceptable (< 5 idóneo)"
}

// ---------------- 3. Conversor mg → mL (presentaciones) ----------------

@Composable
fun PresConvertCalc(drugName: String) {
    val sp = LocalSpacing.current
    var dose by rememberSaveable { mutableStateOf("") }
    var conc by rememberSaveable { mutableStateOf("") }
    val d = vParseNum(dose)
    val c = vParseNum(conc)
    val ml = volumeForMg(d, c)

    Column(verticalArrangement = Arrangement.spacedBy(sp.s.dp)) {
        VentNote("Extraiga el volumen correspondiente a la dosis indicada según la concentración del vial.")
        Row(horizontalArrangement = Arrangement.spacedBy(sp.s.dp)) {
            VentField(dose, { dose = it }, "Dosis", "mg")
            VentField(conc, { conc = it }, "Concentración del vial", "mg/mL")
        }
        if (d > 0 && c > 0) {
            VentResult(
                "Volumen a extraer",
                listOf(
                    "$drugName: dosis" to "${vFmt(d)} mg",
                    "Concentración" to "${vFmt(c)} mg/mL",
                    "Volumen" to "${vFmt(ml)} mL"
                ),
                tag = "$drugName: ${vFmt(d)} mg = ${vFmt(ml)} mL de ${vFmt(c)} mg/mL"
            )
        }
        VentNote("Compruebe la concentración REAL del vial (varía por fabricante) y etiquete la jeringa.")
    }
}
