// Cronos Anestesia — Catálogo: fármacos (parte 2), infusiones, gases, soluciones y asistente
package cu.cronos.anestesia.data

val DRUGS_B = listOf(
    Drug(
        id = "atropina", name = "Atropina", aliases = listOf("atropine"),
        category = "Anticolinérgicos",
        concentration = "Ampolla 1 mL (1 mg/mL)",
        mgPerMl = 1.0,
        doses = listOf(
            Dose("Bradicardia sintomática", "EV", "mgkg", 0.01, 0.02, minAbs = 0.5, maxAbs = 3.0, note = "mínimo 0.5 mg en adulto (bradicardia refleja)", source = "morgan"),
            Dose("Coadyuvante de reversión", "EV", "mgkg", 0.015, 0.02, maxAbs = 1.0, source = "morgan"),
            Dose("Pediátrico (bradicardia)", "EV", "mgkg", 0.02, 0.02, maxAbs = 0.5, note = "dosis única mínima 0.1 mg", source = "miller"),
        ),
        warnings = listOf(
            "Dosis muy bajas pueden causar bradicardia paradójica",
            "Taquicardia, midriasis, boca seca",
            "Evitar en estenosis mitral y glaucoma de ángulo cerrado",
        ),
    ),
    Drug(
        id = "glicopirrolato", name = "Glicopirrolato", aliases = listOf("glicopirrolate", "robinul"),
        category = "Anticolinérgicos",
        concentration = "Ampolla 1 mL (0.2 mg/mL)",
        mgPerMl = 0.2,
        doses = listOf(
            Dose("Antisialagogo / coadyuvante de reversión", "EV", "mcgkg", 4.0, 8.0, maxAbs = 0.6, note = "4–8 mcg/kg equivale a 0.004–0.008 mg/kg", source = "morgan"),
        ),
        warnings = listOf(
            "No atraviesa la barrera hematoencefálica: sin sedación central",
            "Cuarto de elección con neostigmina en asmáticos",
        ),
    ),
    Drug(
        id = "metoclopramida", name = "Metoclopramida", aliases = listOf("maxolon", "primperan"),
        category = "Antiémeticos y gastroprofilaxis",
        concentration = "Ampolla 2 mL (10 mg/2 mL)",
        mgPerMl = 5.0,
        doses = listOf(
            Dose("Antiémético", "EV lenta", "mgkg", 0.1, 0.15, maxAbs = 10.0, note = "10 mg adulto estándar", source = "morgan"),
            Dose("Pediátrico", "EV lenta", "mgkg", 0.1, 0.15, maxAbs = 10.0, source = "miller"),
        ),
        warnings = listOf(
            "Reacciones extrapiramidales (distonía aguda): biperideno si ocurren",
            "EV lenta en > 2 min para evitar acatisia aguda",
            "Eficacia PONV moderada: combinar con dexametasona u ondansetrón",
        ),
    ),
    Drug(
        id = "ondansetron", name = "Ondansetrón", aliases = listOf("zofran", "vetrol"),
        category = "Antiémeticos y gastroprofilaxis",
        concentration = "Ampolla 4 mL (2 mg/mL)",
        mgPerMl = 2.0,
        doses = listOf(
            Dose("Profilaxis PONV", "EV lenta", "mcgkg", 50.0, 100.0, note = "equivalente a 0.05–0.1 mg/kg al final de la cirugía", source = "morgan"),
            Dose("Pediátrico", "EV lenta", "mgkg", 0.05, 0.1, maxAbs = 4.0, source = "miller"),
        ),
        warnings = listOf(
            "Prolonga el intervalo QT a dosis altas",
            "Cefalea y estreñimiento frecuentes",
        ),
    ),
    Drug(
        id = "ranitidina", name = "Ranitidina", aliases = listOf("zantac"),
        category = "Antiémeticos y gastroprofilaxis",
        concentration = "Ampolla 2 mL (25 mg/mL)",
        mgPerMl = 25.0,
        doses = listOf(
            Dose("Gastroprofilaxis", "EV lenta", "mgkg", 1.0, 1.0, maxAbs = 50.0, note = "50 mg adulto, 1 h antes o al inducir", source = "morgan"),
            Dose("Pediátrico", "EV lenta", "mgkg", 1.0, 1.0, maxAbs = 50.0, source = "miller"),
        ),
        warnings = listOf(
            "Retirada en muchos países por NDMA (impureza): aún en uso hospitalario en Cuba; valorar sustitutos",
            "Alternativas: omeprazol/pantoprazol EV o citrato de magnesio oral",
        ),
    ),
    Drug(
        id = "cimetidina", name = "Cimetidina", aliases = listOf("tagamet"),
        category = "Antiémeticos y gastroprofilaxis",
        concentration = "Ampolla 2 mL (300 mg/2 mL)",
        mgPerMl = 150.0,
        doses = listOf(
            Dose("Gastroprofilaxis", "EV lenta", "mgkg", 4.0, 6.0, maxAbs = 300.0, note = "300 mg EV adulto 30–60 min antes", source = "morgan"),
        ),
        warnings = listOf(
            "Interacciones múltiples (inhibidor CYP450): warfarina, benzodiacepinas",
            "Confusión en ancianos y en insuficiencia renal",
        ),
    ),
    Drug(
        id = "difenhidramina", name = "Difenhidramina", aliases = listOf("benadryl", "benadrylina"),
        category = "Antiémeticos y gastroprofilaxis",
        concentration = "Ampolla 1 mL (50 mg/mL)",
        mgPerMl = 50.0,
        doses = listOf(
            Dose("Reacción alérgica leve / profilaxis", "EV/IM", "mgkg", 0.5, 1.0, maxAbs = 50.0, note = "máximo 50 mg por dosis", source = "morgan"),
            Dose("Pediátrico", "EV/IM", "mgkg", 0.5, 1.0, maxAbs = 50.0, source = "miller"),
        ),
        warnings = listOf(
            "Sedación y boca seca (anticolinérgico central)",
            "Coadyuvante de anafilaxia: NUNCA sustituye adrenalina",
        ),
    ),
    Drug(
        id = "dexametasona", name = "Dexametasona", aliases = listOf("decadron"),
        category = "Corticoides",
        concentration = "Ampolla 1 mL (4 mg/mL) o 8 mg/mL",
        mgPerMl = 4.0,
        doses = listOf(
            Dose("Profilaxis PONV", "EV", "mgkg", 0.1, 0.15, maxAbs = 8.0, note = "al inicio de la cirugía", source = "morgan"),
            Dose("Edema cerebral (tumor)", "EV", "mgkg", 0.1, 0.3, maxAbs = 16.0, source = "morgan"),
            Dose("Coadyuvante antiinflamatorio", "EV", "mgkg", 0.1, 0.2, maxAbs = 10.0, source = "sedar"),
        ),
        warnings = listOf(
            "Hiperglucemia transitoria: vigilancia en diabéticos",
            "Efecto PONV máximo entre 6–12 h",
            "Evitar en infección activa no cubierta",
        ),
    ),
    Drug(
        id = "hidrocortisona", name = "Hidrocortisona", aliases = listOf("hydrocortisone"),
        category = "Corticoides",
        concentration = "Frasco 100 mg (polvo)",
        mgPerMl = 50.0,
        doses = listOf(
            Dose("Sustitución en paciente en corticoides crónicos", "EV", "mgkg", 1.0, 2.0, maxAbs = 200.0, note = "inducción + cada 8 h las primeras 24 h", source = "morgan"),
            Dose("Estado de shock resistente", "EV", "mgkg", 1.0, 2.0, maxAbs = 300.0, note = "200–300 mg/día en perfusión", source = "sedar"),
        ),
        warnings = listOf(
            "Indicado si uso de > 5 mg prednisona/día o > 3 semanas en el último año",
            "Hiperglucemia e hipernatremia a dosis altas",
        ),
    ),
    Drug(
        id = "metamizol", name = "Metamizol (dipirona)", aliases = listOf("dipirona", "analgin", "novalgina"),
        category = "Analgésicos no opioides",
        concentration = "Ampolla 2 mL (500 mg/mL = 1 g/2 mL)",
        mgPerMl = 500.0,
        doses = listOf(
            Dose("Analgesia multimodal", "EV lenta", "mgkg", 15.0, 25.0, maxAbs = 2500.0, note = "EV lenta > 5 min; máx. 2.5 g por dosis", source = "sedar"),
            Dose("Pediátrico", "EV lenta", "mgkg", 15.0, 25.0, maxAbs = 1000.0, source = "sedar"),
        ),
        warnings = listOf(
            "Riesgo raro pero grave de agranulocitosis",
            "Hipotensión si EV rápida",
            "Contraindicado en porfiria y déficit de G6PD",
        ),
    ),
    Drug(
        id = "paracetamol", name = "Paracetamol", aliases = listOf("acetaminofén", "panadol"),
        category = "Analgésicos no opioides",
        concentration = "Frasco 100 mL (10 mg/mL)",
        mgPerMl = 10.0,
        doses = listOf(
            Dose("Analgesia adulto", "EV", "mgkg", 15.0, 15.0, maxAbs = 1000.0, note = "cada 6 h; máximo 60 mg/kg/día (adulto 4 g)", source = "morgan"),
            Dose("Pediátrico", "EV", "mgkg", 15.0, 15.0, maxAbs = 1000.0, note = "cada 6 h; máx. 60 mg/kg/día", source = "miller"),
        ),
        warnings = listOf(
            "Hepatotoxicidad por exceso: contar TODAS las fuentes (oral + EV)",
            "Reducir dosis en insuficiencia hepática y alcoholismo",
        ),
    ),
    Drug(
        id = "diclofenaco", name = "Diclofenaco", aliases = listOf("voltaren"),
        category = "Analgésicos no opioides",
        concentration = "Ampolla 3 mL (25 mg/mL)",
        mgPerMl = 25.0,
        doses = listOf(
            Dose("Analgesia (adulto)", "IM profunda", "fixed", 75.0, 75.0, note = "1 ampolla cada 12 h; máx. 150 mg/día", source = "sedar"),
        ),
        warnings = listOf(
            "Evitar en insuficiencia renal, úlcera péptica activa y cirugía con riesgo de sangrado",
            "No usar en trasplante, cirugía cardíaca ni pediatría menor de 12 años",
            "AINE: reducir opioideos en analgesia multimodal",
        ),
    ),
    Drug(
        id = "efedrina", name = "Efedrina", aliases = listOf("ephedrine"),
        category = "Vasopresores (bolus)",
        concentration = "Ampolla 1 mL (30 mg/mL)",
        mgPerMl = 30.0,
        doses = listOf(
            Dose("Hipotensión anestésica", "EV", "fixed", 5.0, 10.0, note = "bolos titulados cada 2–3 min; diluir a 3 mg/mL", source = "morgan"),
            Dose("Pediátrico", "EV", "mgkg", 0.2, 0.5, maxAbs = 15.0, source = "miller"),
        ),
        warnings = listOf(
            "Agente de primera línea clásico en hipotensión espinal (mixed α+β)",
            "Taquifilaxia con dosis repetidas",
            "Taquicardia: cuidado en cardiopatía isquémica (preferir fenilefrina)",
        ),
    ),
    Drug(
        id = "fenilefrina", name = "Fenilefrina", aliases = listOf("phenylephrine", "neosinefrina"),
        category = "Vasopresores (bolus)",
        concentration = "Ampolla 1 mL (10 mg/mL)",
        mgPerMl = 10.0,
        doses = listOf(
            Dose("Bolus hipotensión", "EV", "mcgkg", 0.5, 2.0, note = "diluir 0.1 mg/mL (1 mg en 10 mL)", source = "morgan"),
            Dose("Infusión", "EV", "mcgkgmin", 0.25, 3.0, source = "morgan"),
        ),
        warnings = listOf(
            "Puro α1: bradicardia refleja (ideal en taquiarritmia/esténnosis aórtica)",
            "Reduce el flujo uteroplacentario: titulación cuidadosa en cesárea",
            "Extravasación: necrosis (usar vía segura)",
        ),
    ),
    Drug(
        id = "labetalol", name = "Labetalol", aliases = listOf("trandate", "normodyne"),
        category = "Betabloqueadores / antihipertensivos",
        concentration = "Ampolla 10 mL (5 mg/mL)",
        mgPerMl = 5.0,
        doses = listOf(
            Dose("Crisis hipertensiva intraoperatoria", "EV lenta", "fixed", 5.0, 10.0, note = "bolos fraccionados cada 5–10 min; máx. 100 mg", source = "morgan"),
            Dose("Infusión", "EV", "mgkgmin", 0.5, 2.0, note = "0.5–2 mg/min con bomba", source = "morgan"),
        ),
        warnings = listOf(
            "α1 + β bloqueo mixto (β/α 7:1 IV)",
            "Contraindicado: asma, bloqueo AV, bradicardia, insuficiencia cardíaca descompensada",
            "Hipotensión prolongada posible",
        ),
    ),
    Drug(
        id = "amiodarona", name = "Amiodarona", aliases = listOf("atlansil"),
        category = "Antiarrítmicos",
        concentration = "Ampolla 3 mL (50 mg/mL)",
        mgPerMl = 50.0,
        doses = listOf(
            Dose("Taquiarritmia estable (TV/SVT)", "EV lenta", "fixed", 150.0, 300.0, note = "150 mg en 10 min; luego infusión 1 mg/min × 6 h", source = "morgan"),
            Dose("Paro (FV/TV sin pulso)", "EV", "fixed", 300.0, 300.0, note = "bolus tras el 3.er choque; repetir 150 mg", source = "morgan"),
            Dose("Pediátrico (paro)", "EV", "mgkg", 5.0, 5.0, maxAbs = 300.0, source = "miller"),
        ),
        warnings = listOf(
            "Hipotensión y bradicardia con carga EV rápida",
            "Incompatible con salino (usar SG5 %)",
            "Fosfolipidosis pulmonar/tiroides con uso crónico",
        ),
    ),
    Drug(
        id = "naloxona", name = "Naloxona", aliases = listOf("naloxone"),
        category = "Antagonistas",
        concentration = "Ampolla 1 mL (0.4 mg/mL)",
        mgPerMl = 0.4,
        doses = listOf(
            Dose("Reversión opioide (respiración deprimida)", "EV", "fixed", 0.04, 0.4, note = "titular en alícuotas de 40–80 mcg", source = "morgan"),
            Dose("Paro por sobredosis", "EV", "fixed", 0.4, 2.0, note = "repetir cada 2–3 min", source = "morgan"),
            Dose("Pediátrico", "EV", "mgkg", 0.01, 0.1, maxAbs = 2.0, source = "miller"),
        ),
        warnings = listOf(
            "Semivida corta: puede recurrir la depresión (infusión 2/3 de dosis eficaz/hora si precisa)",
            "Revierte también la analgesia: dolor, agitación, taquicardia",
            "Hipertensión pulmonar aguda y edema pulmonar con bolos altos",
        ),
    ),
    Drug(
        id = "flumazenil", name = "Flumazenil", aliases = listOf("anexate"),
        category = "Antagonistas",
        concentration = "Ampolla 5 mL (0.1 mg/mL)",
        mgPerMl = 0.1,
        doses = listOf(
            Dose("Reversión benzodiacepinas", "EV", "fixed", 0.2, 0.2, maxAbs = 3.0, note = "0.2 mg, luego 0.1 mg/min hasta despertar; máx. 3 mg", source = "morgan"),
        ),
        warnings = listOf(
            "Convulsiones en dependientes a benzodiacepinas o tricíclicos: USE CON CAUTELA",
            "Resedación (semivida más corta que las BDZ): vigilar 2 h",
        ),
    ),
)

// ---------- Infusiones (diluciones estándar de quirófano) ----------
val INFUSIONS = listOf(
    Infusion("noradrenalina", "Noradrenalina (norepinefrina)", 0.064, "4 mg en 60 mL SG5 % → 64 mcg/mL", 0.01, 0.5, 0.16, "Vasoconstrictor de primera línea en shock séptico y anafilaxia", "morgan"),
    Infusion("adrenalina", "Adrenalina (epinefrina)", 0.016, "1 mg en 60 mL SSN → 16 mcg/mL", 0.01, 0.3, 0.05, "Shock anafiláctico, bradicardia-shock; titulación estricta", "morgan"),
    Infusion("dopamina", "Dopamina", 1.6, "200 mg en 125 mL → 1.6 mg/mL", 2.0, 20.0, 5.0, "Dosis renal 2–5, inotrópica 5–10, vasoconstrictora > 10 mcg/kg/min", "morgan"),
    Infusion("dobutamina", "Dobutamina", 1.0, "250 mg en 250 mL → 1 mg/mL", 2.0, 20.0, 5.0, "Inotrópico en insuficiencia cardíaca baja salida", "morgan"),
    Infusion("nitroglicerina", "Nitroglicerina", 0.1, "10 mg en 100 mL → 100 mcg/mL", 0.1, 2.0, 0.5, "Venodilatador: IAM, isquemia, hipertensión pulmonar", "morgan"),
    Infusion("nitroprusiato", "Nitroprusiato de sodio", 0.1, "50 mg en 500 mL → 100 mcg/mL", 0.2, 3.0, 1.0, "Vasodilatador arterio-venoso; proteger de la luz; < 10 mcg/kg/min", "morgan"),
    Infusion("propofol-sedacion", "Propofol (sedación)", 10.0, "Frasco 1 % sin diluir", 25.0, 100.0, 50.0, "Sedación quirúrgica; evitar > 4 mg/kg/h prolongado", "morgan"),
    Infusion("midazolam-inf", "Midazolam (sedación)", 1.0, "50 mg en 50 mL → 1 mg/mL", 0.02, 0.1, 0.05, "Unidad 0.02–0.1 mg/kg/h aquí expresada en mcg/kg/min equivalente", "morgan"),
    Infusion("fentanilo-inf", "Fentanilo (analgesia)", 0.01, "1 mg en 100 mL → 10 mcg/mL", 0.01, 0.1, 0.03, "Analgesia intraoperatoria y postoperatoria", "morgan"),
    Infusion("remifentanilo", "Remifentanilo", 0.02, "1 mg en 50 mL → 20 mcg/mL", 0.05, 0.3, 0.15, "Semivida ultra corta; apnea frecuente; solo con vía aérea controlada", "morgan"),
    Infusion("ketamina-inf", "Ketamina (analgosedación)", 1.0, "500 mg en 500 mL → 1 mg/mL", 0.1, 0.5, 0.2, "Analgesia sin depresión respiratoria significativa", "morgan"),
    Infusion("dexmedetomidina", "Dexmedetomidina", 0.004, "200 mcg en 50 mL → 4 mcg/mL", 0.002, 0.014, 0.007, "Sedación cooperativa; bradicardia; sin carga en shock", "morgan"),
    Infusion("lidocaina-inf", "Lidocaína (analgésica)", 10.0, "1 g en 100 mL → 10 mg/mL", 0.5, 2.0, 1.0, "1–2 mg/kg/h máx. 5 mg/kg; antinociceptiva y antiinflamatoria", "sedar"),
    Infusion("esmolol", "Esmolol", 10.0, "2.5 g en 250 mL → 10 mg/mL", 25.0, 300.0, 100.0, "Beta-bloqueo ultracorto: taquicardia/hipertensión transoperatoria", "morgan"),
    Infusion("vasopresina", "Vasopresina", 0.4, "20 U en 50 mL → 0.4 U/mL", 0.01, 0.04, 0.03, "Shock vasopléjico resistente; aquí en U/kg/h (dosis 0.01–0.04)", "miller"),
)

// ---------- Gases anestésicos ----------
val GASES = listOf(
    Gas("halotano", "Halotano", 0.75, "Aún en uso en Cuba con vaporizador específico; hepatotoxicidad rara pero grave", "miller"),
    Gas("isoflurano", "Isoflurano", 1.15, "Coste-efectivo; irritante de la vía aérea (poco útil en inducción pediátrica)", "miller"),
    Gas("sevoflurano", "Sevoflurano", 2.0, "Gas de inducción pediátrica por excelencia; compuesto A en flujos bajos prolongados", "miller"),
    Gas("desflurano", "Desflurano", 6.0, "Saliencia rápida; taquicardia al aumentar bruscamente; requiere vaporizador presurizado", "miller"),
    Gas("n2o", "Óxido nitroso", 104.0, "MAC > 1 atm: nunca es anestésico único; expande bolsas de aire (neumotórax, obstrucción intestinal)", "miller"),
)

// ---------- Soluciones parenterales ----------
val SOLUTIONS = listOf(
    Solution("Solución salina 0.9 % (SSN)", "Isotónica · 154 mmol/L Na+", "Volumen inicial, diluciones de fármacos, vía de medicamentos", "Acidosis hiperclorémica con volúmenes grandes"),
    Solution("Glucosado 5 % (SG5 %)", "Hipotónica libre de electrolitos · 252 mOsm/L", "Vehículo de drogas (amiodarona), mantenimiento neonatal", "NO expande volumen eficaz; hiponatremia"),
    Solution("Ringer lactato (Hartmann)", "Isotónica balanceada · Na+, K+, Ca2+, lactato", "Reposición de pérdidas, cirugía abdominal, quemados", "Contraindicada con insuficiencia hepática severa (lactato)"),
    Solution("Glucosado-salina 5 % + 0.45 %", "Isotónica mixta", "Mantenimiento pediátrico con aporte calórico", "Vigilar glucemia"),
    Solution("Manitol 20 %", "Hipertónica osmótica", "Reducción de PIC, protección renal puntual", "Diuresis osmótica: reponer electrolitos; evitar en anuria"),
)

// ---------- Asistente: 10 escenarios ----------
val SCENARIOS = listOf(
    Scenario("hipotension", "Hipotensión transoperatoria (PAM ↓ > 20 %)", listOf(
        "1. Verifique dosis/profundidad anestésica y sangrado activo",
        "2. Liquid boost 250–500 mL (cristaloide) y ANULE los vapores/gases en exceso",
        "3. Efedrina 5–10 mg EV o fenilefrina 0.5–2 mcg/kg EV (titular)",
        "4. Si refractaria: noradrenalina en infusión 0.01–0.5 mcg/kg/min",
        "5. Evalúe posiciones (compresión aortocava), anafilaxia y neumotórax si persiste",
    ), "efedrina"),
    Scenario("hipertension", "Hipertensión transoperatoria (PAM ↑ > 20 %)", listOf(
        "1. Profundice la anestesia (opioide o hipnótico) antes de medicar",
        "2. Descarte hipercapnia, hipoxia, distensión vesical, torniquete",
        "3. Labetalol 5–10 mg EV fraccionado o esmolol en infusión",
        "4. Nitroglicerina 0.1–2 mcg/kg/min si isquemia/edema pulmonar",
        "5. En preeclampsia: labetalol/hidralazina; evitar IECA",
    ), "labetalol"),
    Scenario("bradicardia", "Bradicardia (< 50 lpm o con hipoperfusión)", listOf(
        "1. Confirme lectura (ECG real, pulso palpable) y oxigenación",
        "2. Atropina 0.5–1 mg EV (pediátrico 0.02 mg/kg, mín. 0.1 mg)",
        "3. Si refractaria: adrenalina 5–20 mcg bolos o infusión",
        "4. Marcapasos transcutáneo si bloqueo AV completo",
        "5. Busque causas vagales: tracción mesentérica, oculocardíaco, hipoxia",
    ), "atropina"),
    Scenario("taquicardia", "Taquicardia (> 120 lpm con signos)", listOf(
        "1. Descarte hipovolemia, dolor, fiebre, anemia, hipercapnia, sepsis",
        "2. Profundice anestesia/analgesia",
        "3. Esmolol 0.5 mg/kg bolus o 50–200 mcg/kg/min",
        "4. SVT inestable: cardioversión sincronizada 50–100 J",
        "5. Amiodarona 150 mg/10 min si TV estable",
    ), "esmolol"),
    Scenario("hipoxemia", "Desaturación (SpO2 < 90 %)", listOf(
        "1. FO2 al 100 % y verifique la máquina/vía aérea (PUSH-PULL-LOOK)",
        "2. Ambú manual: confirme expansión torácica y CAPNOMETRÍA",
        "3. Ausculte bilateral: intubación selectiva, broncoespasmo, edema",
        "4. Aspire secreciones; PEEP 5–10 cmH2O; reclutamiento si atelectasia",
        "5. Pense en embolia, neumotórax, anafilaxia (FIOP bajo = shunt)",
    )),
    Scenario("laringoespasmo", "Laringoespasmo", listOf(
        "1. Retire el estímulo (secreciones, dispositivo) y CPAP al 100 % con presión",
        "2. Propofol 0.5–1 mg/kg EV si persiste",
        "3. Succinilcolina 0.5–1 mg/kg EV (o 2–4 mg/kg IM) si hipoxia progresiva",
        "4. Intube si no recupera o ante regurgitación",
        "5. Posteriormente vigilar edema y estridor",
    ), "succinilcolina"),
    Scenario("broncoespasmo", "Broncoespasmo intraoperatorio", listOf(
        "1. FO2 100 % y profundice la anestesia (sevoflurano/isoflurano o ketamina)",
        "2. Salbutamol 4–10 puffs por el tubo (cámara)",
        "3. Hidrocortisona 1–2 mg/kg EV",
        "4. Adrenalina 0.01–0.05 mcg/kg/min si grave",
        "5. Descarte neumotórax, aspiración, kink del tubo, secreciones",
    ), "hidrocortisona"),
    Scenario("anafilaxia", "Reacción anafiláctica", listOf(
        "1. RETIRE el sospechoso (antibiótico, relajante, látex, coloide)",
        "2. ADRENALINA 50 mcg EV (0.5–1 mcg/kg) y repetir cada 1–2 min; luego infusión 0.05–0.3 mcg/kg/min",
        "3. Liquide agresivamente 20–30 mL/kg cristaloide",
        "4. FO2 100 %, broncodilatación, posición declive si hipotensión",
        "5. Hidrocortisona 200 mg + difenhidramina 50 mg (coadyuvantes, no sustituyen adrenalina)",
    ), "adrenalina"),
    Scenario("hipoglucemia", "Hipoglucemia (< 70 mg/dL o sospechada)", listOf(
        "1. Dextrosa 50 %: 1–2 mL/kg EV (adulto 25–50 mL)",
        "2. Pediátrico: dextrosa 10 % 2–4 mL/kg",
        "3. Repita la glucemia a los 15 min; luego mantenimiento glucosado",
        "4. Vigile hipokalemia tras la corrección",
    )),
    Scenario("shivering", "Tremitor postoperatorio (shivering)", listOf(
        "1. Calentamiento activo (manta de aire forzado) y fluidos calientes",
        "2. Petidina 0.25–0.5 mg/kg EV (efecto κ específico)",
        "3. Alternativas: tramadol 1 mg/kg o clonidina 1–2 mcg/kg",
        "4. Descarte hipoxemia e hipovolemia como causa",
    ), "petidina"),
)

val CATEGORIES = listOf(
    "Hipnóticos", "Benzodiacepinas", "Opioideos",
    "Relajantes despolarizantes", "Relajantes no despolarizantes", "Reversión",
    "Anticolinérgicos", "Antiémeticos y gastroprofilaxis", "Corticoides",
    "Analgésicos no opioides", "Vasopresores (bolus)",
    "Betabloqueadores / antihipertensivos", "Antiarrítmicos", "Antagonistas",
)

fun allDrugs(): List<Drug> = DRUGS_A + DRUGS_B

fun findDrug(id: String): Drug? = allDrugs().firstOrNull { it.id == id }
