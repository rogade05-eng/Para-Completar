package cu.cronos.anestesia

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.time.LocalDate

/**
 * Vectores dorados del verificador de licencias offline (v1.5.0).
 * Genera un par EC P-256 efímero para firmar y verifica con LicenseVerifier,
 * inyectando la clave pública por parámetro (el flujo de producción usa la
 * clave incrustada de la app).
 */
class LicenseVerifierTest {

    private val keys: KeyPair = KeyPairGenerator.getInstance("EC").apply {
        initialize(ECGenParameterSpec("secp256r1"))
    }.generateKeyPair()

    private val otherKeys: KeyPair = KeyPairGenerator.getInstance("EC").apply {
        initialize(ECGenParameterSpec("secp256r1"))
    }.generateKeyPair()

    private val today: Long = LocalDate.of(2026, 10, 21).toEpochDay()
    private val pubB64Url: String = B64Url.encode(keys.public.encoded)

    private fun buildKey(
        serial: String = "CRN-2026-TEST",
        holder: String = "Dra. Prueba Áéíóú",
        org: String = "",
        tier: String = "PRO",
        issued: Long = today - 30,
        expires: Long = today + 335,
        device: String = "",
        signWith: KeyPair = keys
    ): String {
        val payload = (
            "s=" + percentEncode(serial) +
                "&h=" + percentEncode(holder) +
                "&o=" + percentEncode(org) +
                "&t=" + percentEncode(tier) +
                "&i=" + issued +
                "&e=" + expires +
                "&d=" + percentEncode(device)
            ).toByteArray(Charsets.UTF_8)
        val sig = Signature.getInstance("SHA256withECDSA").apply {
            initSign(signWith.private)
            update(payload)
        }.sign()
        return "CRONOS1." + B64Url.encode(payload) + "." + B64Url.encode(sig)
    }

    // 1. Licencia PRO válida → Ok, clínica desbloqueada
    @Test
    fun licenciaProValida() {
        val r = LicenseVerifier.verify(buildKey(), null, pubB64Url, today)
        assertTrue(r is LicenseResult.Ok)
        val ok = r as LicenseResult.Ok
        assertEquals(LicenseTier.PRO, ok.info.tier)
        assertEquals("Dra. Prueba Áéíóú", ok.info.holder)
        assertTrue(ok.info.features.clinic)
        assertTrue(ok.info.features.doseCalc)
        assertEquals(335L, ok.info.daysLeft(today))
        assertFalse(ok.info.perpetual)
    }

    // 2. Básica: todo el uso diario, clínica bloqueada
    @Test
    fun licenciaBasicaSinClinica() {
        val r = LicenseVerifier.verify(buildKey(tier = "BAS"), null, pubB64Url, today)
        assertTrue(r is LicenseResult.Ok)
        val f = (r as LicenseResult.Ok).info.features
        assertTrue(f.drugsAll && f.doseCalc && f.calcsAll && f.scalesAll)
        assertTrue(f.complAll && f.premedAll && f.solAll && f.refsAll)
        assertFalse(f.clinic)
    }

    // 3. Alias de nivel y valor desconocido
    @Test
    fun aliasDeNivel() {
        assertEquals(LicenseTier.PRO, LicenseTier.parse("PROFESIONAL"))
        assertEquals(LicenseTier.INST, LicenseTier.parse("institucional"))
        assertEquals(LicenseTier.BAS, LicenseTier.parse("Básica"))
        assertEquals(LicenseTier.DEMO, LicenseTier.parse("cualquier_otra_cosa"))
        val r = LicenseVerifier.verify(buildKey(tier = "PROFESIONAL"), null, pubB64Url, today)
        assertTrue((r as LicenseResult.Ok).info.tier == LicenseTier.PRO)
    }

    // 4. Perpetua: e = 0
    @Test
    fun licenciaPerpetua() {
        val r = LicenseVerifier.verify(buildKey(expires = 0), null, pubB64Url, today)
        assertTrue(r is LicenseResult.Ok)
        assertTrue((r as LicenseResult.Ok).info.perpetual)
    }

    // 5. Caducada → Expired (la firma era válida)
    @Test
    fun licenciaCaducada() {
        val r = LicenseVerifier.verify(buildKey(expires = today - 1), null, pubB64Url, today)
        assertTrue(r is LicenseResult.Expired)
        assertEquals(LicenseTier.PRO, (r as LicenseResult.Expired).info.tier)
    }

    // 6. Vinculación a dispositivo: distinta → WrongDevice; igual → Ok
    @Test
    fun vinculacionDispositivo() {
        val dev = "AABBCCDD11223344"
        val wrong = LicenseVerifier.verify(buildKey(device = dev), "FFEEDDCC00112233", pubB64Url, today)
        assertTrue(wrong is LicenseResult.WrongDevice)
        val right = LicenseVerifier.verify(buildKey(device = dev), dev, pubB64Url, today)
        assertTrue(right is LicenseResult.Ok)
    }

    // 7. Normalización del hash de dispositivo (minúsculas y guiones)
    @Test
    fun hashDispositivoNormalizado() {
        val r = LicenseVerifier.verify(
            buildKey(device = "aabb-ccdd-1122-3344"),
            "AABBCCDD11223344",
            pubB64Url,
            today
        )
        assertTrue(r is LicenseResult.Ok)
    }

    // 8. Carga manipulada (mismo largo, otra letra) → firma inválida
    @Test
    fun cargaManipulada() {
        val key = buildKey()
        val parts = key.removePrefix("CRONOS1.").split('.')
        val payload = B64Url.decode(parts[0])
        val sig = B64Url.decode(parts[1])
        val idx = payload.indexOfBytes("t=PRO".toByteArray(Charsets.UTF_8))
        assertTrue(idx >= 0)
        payload[idx + 2] = 'X'.code.toByte() // t=PXO
        val forged = "CRONOS1." + B64Url.encode(payload) + "." + B64Url.encode(sig)
        val r = LicenseVerifier.verify(forged, null, pubB64Url, today)
        assertTrue(r is LicenseResult.Invalid)
    }

    // 9. Firmada con otra clave privada → firma inválida
    @Test
    fun firmaAjena() {
        val r = LicenseVerifier.verify(buildKey(signWith = otherKeys), null, pubB64Url, today)
        assertTrue(r is LicenseResult.Invalid)
    }

    // 10. Claves malformadas
    @Test
    fun malformadas() {
        assertTrue(LicenseVerifier.verify("hola mundo", null, pubB64Url, today) is LicenseResult.Invalid)
        assertTrue(LicenseVerifier.verify("CRONOS1.soloCarga", null, pubB64Url, today) is LicenseResult.Invalid)
        assertTrue(LicenseVerifier.verify("CRONOS1.@@@.###", null, pubB64Url, today) is LicenseResult.Invalid)
        assertTrue(LicenseVerifier.verify("", null, pubB64Url, today) is LicenseResult.Invalid)
    }

    // 11. Tolerancia a saltos de línea/espacios al pegar (WhatsApp/correo)
    @Test
    fun pegadoConSaltosDeLinea() {
        val key = buildKey()
        val wrapped = key.chunked(40).joinToString("\n")
        assertTrue(LicenseVerifier.verify(wrapped, null, pubB64Url, today) is LicenseResult.Ok)
        val spaced = key.chunked(64).joinToString(" \r\n ")
        assertTrue(LicenseVerifier.verify(spaced, null, pubB64Url, today) is LicenseResult.Ok)
    }

    // 12. Caracteres especiales en el titular (percent-encoding ida y vuelta)
    @Test
    fun titularConCaracteresEspeciales() {
        val holder = "Dra. María & José (Área #3)"
        val r = LicenseVerifier.verify(buildKey(holder = holder), null, pubB64Url, today)
        assertTrue(r is LicenseResult.Ok)
        assertEquals(holder, (r as LicenseResult.Ok).info.holder)
    }

    // 13. Funcionalidades por nivel
    @Test
    fun funcionalidadesPorNivel() {
        val demo = LicenseFeatures.forTier(LicenseTier.DEMO)
        assertFalse(demo.drugsAll || demo.doseCalc || demo.calcsAll || demo.clinic)
        val pro = LicenseFeatures.forTier(LicenseTier.INST)
        assertTrue(pro.drugsAll && pro.doseCalc && pro.calcsAll && pro.clinic && pro.refsAll)
    }

    // 14. Formato del hash de dispositivo para mostrar
    @Test
    fun formatoHashDispositivo() {
        assertEquals("A1B2-C3D4-E5F6-0718", formatDeviceHash("a1b2c3d4e5f60718"))
        assertEquals("XY", formatDeviceHash("xy"))
    }

    // 15. Base64url ida y vuelta + compatibilidad con base64 estándar
    @Test
    fun base64UrlIdaYVuelta() {
        val data = ByteArray(97) { it.toByte() }
        val enc = B64Url.encode(data)
        assertTrue('+' !in enc && '/' !in enc && '=' !in enc)
        assertTrue(B64Url.decode(enc).contentEquals(data))
        // base64 estándar con + / y padding también se acepta
        val std = androidBase64LikeStd(data)
        assertTrue(B64Url.decode(std).contentEquals(data))
    }

    private fun ByteArray.indexOfBytes(pat: ByteArray): Int {
        outer@ for (i in 0..size - pat.size) {
            for (j in pat.indices) {
                if (this[i + j] != pat[j]) continue@outer
            }
            return i
        }
        return -1
    }

    private fun androidBase64LikeStd(data: ByteArray): String {
        val b64url = B64Url.encode(data)
        val sb = StringBuilder()
        for (c in b64url) {
            sb.append(
                when (c) {
                    '-' -> '+'
                    '_' -> '/'
                    else -> c
                }
            )
        }
        sb.append("=".repeat((4 - sb.length % 4) % 4))
        return sb.toString()
    }
}
