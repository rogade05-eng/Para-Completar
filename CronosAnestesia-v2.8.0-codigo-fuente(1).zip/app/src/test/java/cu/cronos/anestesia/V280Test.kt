package cu.cronos.anestesia

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * v2.8.0 — Traducción completa: cobertura de la ola I18nV280.
 * Verifica que TODOS los literales de la Escuela de Residentes, el Módulo
 * del Tutor, el Temario R1–R4, el Simulador de crisis, el tema «Verificación
 * de estudios preoperatorios», las escalas/complicaciones/temas clínicos y
 * los literales de UI de los módulos nuevos estén registrados en EN y PT,
 * con preservación de cifras y degradación elegante en español.
 */
class V280Test {

    private val NUM = Regex("\\d+")

    private fun digits(s: String) = NUM.findAll(s).map { it.value }.sorted().toList()

    private fun withLang(lang: Lang, block: () -> Unit) {
        val prev = L10n.current
        I18n.init()
        L10n.current = lang
        try {
            block()
        } finally {
            L10n.current = prev
        }
    }

    /** Mismo recorrido que TranslationDumpTest (fuente de la ola I18nV280). */
    private fun collectKeys(): LinkedHashSet<String> {
        val keys = LinkedHashSet<String>()
        fun add(s: String?) { if (!s.isNullOrBlank()) keys.add(s) }
        STUDY_AREAS.forEach { a ->
            add(a.name); add(a.desc)
            a.cards.forEach { c ->
                add(c.title); add(c.definition); add(c.express)
                c.keyPoints.forEach(::add); c.figures.forEach(::add); c.mistakes.forEach(::add)
            }
            a.questions.forEach { q -> add(q.q); add(q.explanation); q.options.forEach(::add) }
        }
        TEACHING_METHODS.forEach { m ->
            add(m.name); add(m.whenToUse); add(m.evaluation); m.how.forEach(::add)
        }
        RESIDENCY.forEach { y ->
            add(y.objetivo)
            y.areas.forEach { a -> add(a.title); a.topics.forEach(::add) }
        }
        CRISIS_SCENARIOS.forEach { sc ->
            add(sc.title); add(sc.subtitle); add(sc.category); add(sc.level)
            add(sc.intro); add(sc.monitor); add(sc.refs)
            sc.steps.forEach { st ->
                add(st.situation); add(st.monitor)
                st.options.forEach { o -> add(o.text); add(o.feedback) }
            }
            sc.debrief.forEach(::add); sc.doses.forEach(::add)
        }
        val srcDir = File("src/main/java/cu/cronos/anestesia")
        listOf("Estudio.kt", "Temario.kt", "CrisisUI.kt").forEach { name ->
            val f = File(srcDir, name)
            if (f.exists()) {
                val rx = Regex("\"([^\"\\\\]*(?:\\\\.[^\"\\\\]*)*)\"\\.tr\\(\\)")
                rx.findAll(f.readText()).forEach { m ->
                    val raw = m.groupValues[1]
                    val sb = StringBuilder(); var i = 0
                    while (i < raw.length) {
                        val c = raw[i]
                        if (c == '\\' && i + 1 < raw.length) {
                            when (val n = raw[i + 1]) {
                                'n' -> { sb.append('\n'); i += 2 }
                                't' -> { sb.append('\t'); i += 2 }
                                'r' -> { sb.append('\r'); i += 2 }
                                '"' -> { sb.append('"'); i += 2 }
                                '\\' -> { sb.append('\\'); i += 2 }
                                '$' -> { sb.append('$'); i += 2 }
                                'u' -> { sb.append(raw.substring(i + 2, i + 6).toInt(16).toChar()); i += 6 }
                                else -> { sb.append(n); i += 2 }
                            }
                        } else { sb.append(c); i++ }
                    }
                    add(sb.toString())
                }
            }
        }
        SCALES_RAW.forEach { s ->
            add(s.name); add(s.desc); add(s.interpretation); add(s.category)
            s.groups.forEach { g -> add(g.title); g.options.forEach { add(it.label) } }
            s.fixedOptions.forEach { add(it.label) }
        }
        COMPLICATIONS_RAW.forEach { add(it.name); add(it.recognition); add(it.management) }
        PREMED_TOPICS_RAW.forEach { add(it.title); add(it.body) }
        SOLUTIONS_RAW.forEach { add(it.title); add(it.body) }
        listOf(COMORBIDITIES_RAW, REGIONAL_BLOCKS_RAW, MONITORING_RAW, PREOP_TOPICS_RAW, EQUIPMENT_TOPICS_RAW, SURGICAL_TOPICS_RAW).forEach { list ->
            list.forEach { t ->
                add(t.title); add(t.subtitle); add(t.category)
                t.sections.forEach { add(it.first); add(it.second) }
            }
        }
        EMERGENCIES_RAW.forEach { e ->
            add(e.name); add(e.subtitle); add(e.category); add(e.recognize); add(e.warnings); add(e.refs)
            e.steps.forEach(::add); e.doses.forEach(::add)
        }
        CLIN_SECTIONS_RAW.forEach(::add)
        return keys
    }

    // ---------------------- 1. Cobertura total ----------------------

    @Test
    fun `v280_todos_los_literales_registrados_en_y_pt`() {
        I18n.init()
        val keys = collectKeys()
        assertTrue("recorrido mínimo esperado (>3400): ${keys.size}", keys.size >= 3400)
        val en = L10n.table(Lang.EN)!!
        val pt = L10n.table(Lang.PT)!!
        val faltanEn = keys.filter { it !in en }
        val faltanPt = keys.filter { it !in pt }
        assertTrue("faltan ${faltanEn.size} en EN: ${faltanEn.take(3)}", faltanEn.isEmpty())
        assertTrue("faltan ${faltanPt.size} en PT: ${faltanPt.take(3)}", faltanPt.isEmpty())
        // cobertura numérica de la app completa
        assertTrue("EN total debe superar 4400: ${L10n.registered(Lang.EN)}", L10n.registered(Lang.EN) >= 4400)
        assertTrue("PT total debe superar 4300: ${L10n.registered(Lang.PT)}", L10n.registered(Lang.PT) >= 4300)
    }

    @Test
    fun `v280_init_idempotente`() {
        I18n.init()
        val en = L10n.registered(Lang.EN)
        I18n.init()
        assertEquals(en, L10n.registered(Lang.EN))
    }

    // ---------------------- 2. Traducción real del simulador ----------------------

    @Test
    fun `crisis_traduce_y_preserva_cifras`() {
        I18n.init()
        val sc = CRISIS_SCENARIOS.first { it.id == "anafilaxia" }
        val esTitle = sc.title
        withLang(Lang.EN) {
            assertTrue("el título debe traducirse", sc.title.tr() != esTitle)
            val translated = sc.steps[0].options[0].feedback.tr()
            assertTrue("feedback debe traducirse", translated != sc.steps[0].options[0].feedback)
            assertEquals(
                "cifras preservadas", digits(sc.steps[0].options[0].feedback), digits(translated)
            )
        }
        withLang(Lang.PT) {
            assertTrue("título PT debe traducirse", sc.title.tr() != esTitle)
        }
    }

    @Test
    fun `escuela_traduce_fichas_y_preguntas`() {
        I18n.init()
        val area = STUDY_AREAS.first()
        withLang(Lang.EN) {
            val t = studyArea(area)
            assertTrue("nombre de área debe traducirse", t.name != area.name)
            assertTrue("definición debe traducirse", t.cards[0].definition != area.cards[0].definition)
            assertTrue("pregunta debe traducirse", t.questions[0].q != area.questions[0].q)
            assertEquals("bibliografía en idioma original", area.bibliography, t.bibliography)
        }
        withLang(Lang.PT) {
            val t = studyArea(area)
            assertTrue("nombre de área PT", t.name != area.name)
        }
    }

    @Test
    fun `temario_traduce_objetivos_y_temas`() {
        I18n.init()
        val y = RESIDENCY.first()
        withLang(Lang.EN) {
            val t = residencyL10n().first()
            assertTrue("objetivo R1 debe traducirse", t.objetivo != y.objetivo)
            assertTrue("tema debe traducirse", t.areas[0].topics[0] != y.areas[0].topics[0])
        }
    }

    // ---------------------- 3. Degradación elegante ----------------------

    @Test
    fun `es_retorna_original_y_faltantes_degradan`() {
        withLang(Lang.ES) {
            assertEquals("Crisis".tr(), "Crisis")
            assertEquals(STUDY_AREAS.first().name, STUDY_AREAS.first().name.tr())
        }
        // clave inexistente en tablas → español
        withLang(Lang.EN) {
            assertEquals("ClaveInexistenteV280 XYZ", "ClaveInexistenteV280 XYZ".tr())
        }
    }

    // ---------------------- 4. Placeholders preservados ----------------------

    @Test
    fun `plantillas_de_formato_mantienen_placeholders`() {
        I18n.init()
        val en = L10n.table(Lang.EN)!!
        val pt = L10n.table(Lang.PT)!!
        val rx = Regex("%\\d+\\\$[sdf]")
        var revisadas = 0
        for ((k, v) in en) {
            if (rx.containsMatchIn(k)) {
                assertEquals(
                    "placeholders EN distintos en: $k",
                    rx.findAll(k).map { it.value }.sorted().toList(),
                    rx.findAll(v).map { it.value }.sorted().toList()
                )
                revisadas++
            }
        }
        for ((k, v) in pt) {
            if (rx.containsMatchIn(k)) {
                assertEquals(
                    "placeholders PT distintos en: $k",
                    rx.findAll(k).map { it.value }.sorted().toList(),
                    rx.findAll(v).map { it.value }.sorted().toList()
                )
            }
        }
        assertTrue("debe haber plantillas con placeholders", revisadas >= 10)
    }
}
