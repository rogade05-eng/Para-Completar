// Pruebas JVM de Expedientes (v1.7.0): JSON, modelos y escritor XLSX.
package cu.cronos.anestesia

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory

class RecordsTest {

    private fun samplePatient(id: Long = 1L) = RecPatient(
        id = id, name = "Dra. María Pérez Gómez", historyId = "HC-2026-014",
        ageText = "45 a", weightText = "70 kg", sex = "F",
        allergies = "Penicilina, látex", notes = "Hipertensa controlada",
        createdAt = 1761000000000L
    )

    private fun sampleEntry(pid: Long = 1L) = RecEntry(
        id = 100L, patientId = pid, kind = "Dosis", title = "Propofol",
        subtitle = "Bolo · Peso 70 kg · Edad 45 años",
        lines = listOf(
            "Régimen" to "Bolo de inducción",
            "Dosis" to "140–210 mg",
            "Bomba" to "28–56 mL/h",
            "Dilución" to "10 mg/mL · 500 mg / 50 mL"
        ),
        note = "Infusión de mantenimiento 4–8 mg/kg/h",
        createdAt = 1761000100000L
    )

    // ---------------- RecJson ----------------

    @Test
    fun `escape cubre comillas barra salto y control`() {
        assertEquals("a\\\"b", RecJson.esc("a\"b"))
        assertEquals("a\\\\b", RecJson.esc("a\\b"))
        assertEquals("l\\nl2", RecJson.esc("l\nl2"))
        assertEquals("t\\tt", RecJson.esc("t\tt"))
        // carácter de control < 0x20 → \uXXXX
        assertTrue(RecJson.esc("x" + 1.toChar() + "y").contains("\\u0001"))
    }

    @Test
    fun `json ida y vuelta pacientes y entradas`() {
        val patients = listOf(samplePatient(1), samplePatient(2).copy(sex = "M", allergies = ""))
        val entries = listOf(
            sampleEntry(1),
            sampleEntry(2).copy(
                id = 200L, kind = "Cálculo", title = "Ayuno preoperatorio",
                lines = listOf("Horas" to "8 h", "Líquidos" to "Solo claros"),
                note = "Con comillas \"dobles\" y \\barra\\\ny salto"
            )
        )
        val text = RecJson.serialize(patients, entries)
        val (ps, es) = RecJson.deserialize(text)
        assertEquals(2, ps.size)
        assertEquals(patients, ps)
        assertEquals(2, es.size)
        assertEquals(entries, es)
    }

    @Test
    fun `json con acentos eñes y simbolos`() {
        val p = samplePatient().copy(name = "José Ñúñez & Cía < Hospital \"San Juan\">")
        val e = sampleEntry().copy(note = "Dosis ≥ 2 mg · µg/kg · ‘comillas’")
        val text = RecJson.serialize(listOf(p), listOf(e))
        val (ps, es) = RecJson.deserialize(text)
        assertEquals(p, ps[0])
        assertEquals(e, es[0])
    }

    @Test
    fun `json corrupto no lanza`() {
        val (ps, es) = RecJson.deserialize("esto no es json")
        assertTrue(ps.isEmpty() && es.isEmpty())
    }

    // ---------------- Modelos ----------------

    @Test
    fun `summaryLine junta solo campos presentes`() {
        assertEquals("45 a · 70 kg · F", samplePatient().summaryLine())
        assertEquals("45 a", samplePatient().copy(weightText = "", sex = "").summaryLine())
        assertEquals("", RecPatient(1, "X", "", "", "", "", "", "", 0).summaryLine())
    }

    @Test
    fun `exportName sanea para nombre de archivo`() {
        assertEquals("HC-2026-014".replace('-', '_'), samplePatient().exportName())
        assertEquals("María_Pérez", samplePatient().copy(historyId = "", name = "María Pérez?").exportName())
        assertTrue(samplePatient().copy(historyId = "a".repeat(60)).exportName().length <= 40)
    }

    // ---------------- XlsxWriter ----------------

    @Test
    fun `colRef convierte indices a letras`() {
        assertEquals("A", XlsxWriter.colRef(0))
        assertEquals("Z", XlsxWriter.colRef(25))
        assertEquals("AA", XlsxWriter.colRef(26))
        assertEquals("BA", XlsxWriter.colRef(52))
    }

    @Test
    fun `escXML neutraliza caracteres peligrosos`() {
        assertEquals("&lt;b&gt; &amp; &quot;q&quot;", XlsxWriter.esc("<b> & \"q\""))
        assertFalse(XlsxWriter.esc("a<b").contains("<"))
    }

    @Test
    fun `xlsx generado es un zip con partes OOXML validas`() {
        val (header, rows) = XlsxWriter.expedienteRows(
            samplePatient(),
            listOf(sampleEntry(), sampleEntry().copy(id = 101, title = "Glasgow"))
        )
        assertEquals(6, header.size)
        assertEquals(2, rows.size)

        val bytes = XlsxWriter.xlsx(header, rows)
        val names = mutableListOf<String>()
        var sheetXml: String? = null
        ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
            var e = z.nextEntry
            while (e != null) {
                names.add(e.name)
                if (e.name == "xl/worksheets/sheet1.xml") sheetXml = z.readBytes().decodeToString()
                z.closeEntry()
                e = z.nextEntry
            }
        }
        listOf(
            "[Content_Types].xml", "_rels/.rels", "xl/workbook.xml",
            "xl/_rels/workbook.xml.rels", "xl/styles.xml", "xl/worksheets/sheet1.xml"
        ).forEach { assertTrue("falta $it", names.contains(it)) }

        // El XML de la hoja debe parsear y contener los textos inline
        val xml = sheetXml!!
        val doc = DocumentBuilderFactory.newInstance()
            .run { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true); newDocumentBuilder() }
            .parse(ByteArrayInputStream(xml.toByteArray()))
        assertEquals("worksheet", doc.documentElement.tagName)
        assertTrue(xml.contains("Propofol"))
        assertTrue(xml.contains("Glasgow"))
        assertTrue(xml.contains("Fecha del registro") || xml.contains("Fecha"))
        // fila de encabezado con estilo 1 (negrita verde)
        assertTrue(xml.contains("s=\"1\""))
        assertTrue(xml.contains("t=\"inlineStr\""))
        // escape correcto dentro de la celda
        assertTrue(!xml.contains("\u0001"))
    }

    @Test
    fun `expedienteRows ordena cronologicamente y une detalle`() {
        val e1 = sampleEntry().copy(createdAt = 2000L)
        val e2 = sampleEntry().copy(id = 9, createdAt = 1000L, title = "Primero")
        val (_, rows) = XlsxWriter.expedienteRows(samplePatient(), listOf(e1, e2))
        assertEquals(2, rows.size)
        assertTrue(rows[0][2].contains("Primero")) // más antiguo primero
        assertTrue(rows[0][4].contains("Régimen: ")) // detalle unido con pares
    }
}
