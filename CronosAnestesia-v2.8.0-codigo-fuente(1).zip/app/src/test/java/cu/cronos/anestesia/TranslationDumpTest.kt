package cu.cronos.anestesia

import org.junit.Test
import java.io.File

/**
 * v2.8.0 — Volcado de literales de contenido para la ola de traducción
 * completa (Escuela de Residentes, Módulo del Tutor, Temario, Simulador de
 * crisis y verificación de huecos del contenido clínico). Escribe
 * /tmp/cronos_l10n_dump.json con {"k": literal, "en": bool, "pt": bool}
 * (true = ya registrado en la tabla del idioma). No es una prueba de
 * aserción: es la fuente de verdad de la cobertura.
 */
class TranslationDumpTest {

    private fun jsonEsc(s: String): String {
        val sb = StringBuilder()
        for (ch in s) when (ch) {
            '"' -> sb.append("\\\"")
            '\\' -> sb.append("\\\\")
            '\n' -> sb.append("\\n")
            '\r' -> sb.append("\\r")
            '\t' -> sb.append("\\t")
            else -> if (ch < ' ') sb.append("\\u%04x".format(ch.code)) else sb.append(ch)
        }
        return sb.toString()
    }

    /** Des-escapa literales Kotlin extraídos del código fuente. */
    private fun unescape(s: String): String {
        val sb = StringBuilder(); var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '\\' && i + 1 < s.length) {
                when (val n = s[i + 1]) {
                    'n' -> { sb.append('\n'); i += 2 }
                    't' -> { sb.append('\t'); i += 2 }
                    'r' -> { sb.append('\r'); i += 2 }
                    '"' -> { sb.append('"'); i += 2 }
                    '\\' -> { sb.append('\\'); i += 2 }
                    '$' -> { sb.append('$'); i += 2 }
                    'u' -> { sb.append(s.substring(i + 2, i + 6).toInt(16).toChar()); i += 6 }
                    else -> { sb.append(n); i += 2 }
                }
            } else { sb.append(c); i++ }
        }
        return sb.toString()
    }

    @Test
    fun dumpAll() {
        I18n.init()
        val en = L10n.table(Lang.EN)
        val pt = L10n.table(Lang.PT)
        val keys = LinkedHashSet<String>()

        fun add(s: String?) { if (!s.isNullOrBlank()) keys.add(s) }

        // ---- Escuela de Residentes + Tutor (bibliografía: idioma original) ----
        STUDY_AREAS.forEach { a ->
            add(a.name); add(a.desc)
            a.cards.forEach { c ->
                add(c.title); add(c.definition); add(c.express)
                c.keyPoints.forEach(::add); c.figures.forEach(::add); c.mistakes.forEach(::add)
            }
            a.questions.forEach { q ->
                add(q.q); add(q.explanation); q.options.forEach(::add)
            }
        }
        TEACHING_METHODS.forEach { m ->
            add(m.name); add(m.whenToUse); add(m.evaluation); m.how.forEach(::add)
        }

        // ---- Temario R1–R4 ----
        RESIDENCY.forEach { y ->
            add(y.objetivo)
            y.areas.forEach { a -> add(a.title); a.topics.forEach(::add) }
        }

        // ---- Simulador de crisis ----
        CRISIS_SCENARIOS.forEach { sc ->
            add(sc.title); add(sc.subtitle); add(sc.category); add(sc.level)
            add(sc.intro); add(sc.monitor); add(sc.refs)
            sc.steps.forEach { st ->
                add(st.situation); add(st.monitor)
                st.options.forEach { o -> add(o.text); add(o.feedback) }
            }
            sc.debrief.forEach(::add); sc.doses.forEach(::add)
        }

        // ---- Literales .tr() del código fuente (Estudio, Temario, CrisisUI) ----
        val srcDir = File("src/main/java/cu/cronos/anestesia")
        listOf("Estudio.kt", "Temario.kt", "CrisisUI.kt").forEach { name ->
            val f = File(srcDir, name)
            if (f.exists()) {
                val text = f.readText()
                val rx = Regex("\"([^\"\\\\]*(?:\\\\.[^\"\\\\]*)*)\"\\.tr\\(\\)")
                rx.findAll(text).forEach { m -> add(unescape(m.groupValues[1])) }
            }
        }

        // ---- Contenido clínico: huecos previos (marcados por la tabla) ----
        SCALES_RAW.forEach { s ->
            add(s.name); add(s.desc); add(s.interpretation); add(s.category)
            s.groups.forEach { g -> add(g.title); g.options.forEach { add(it.label) } }
            s.fixedOptions.forEach { add(it.label) }
        }
        COMPLICATIONS_RAW.forEach { add(it.name); add(it.recognition); add(it.management) }
        PREMED_TOPICS_RAW.forEach { add(it.title); add(it.body) }
        SOLUTIONS_RAW.forEach { add(it.title); add(it.body) }
        COMORBIDITIES_RAW.forEach { t ->
            add(t.title); add(t.subtitle); add(t.category); t.sections.forEach { add(it.first); add(it.second) }
        }
        REGIONAL_BLOCKS_RAW.forEach { t ->
            add(t.title); add(t.subtitle); add(t.category); t.sections.forEach { add(it.first); add(it.second) }
        }
        MONITORING_RAW.forEach { t ->
            add(t.title); add(t.subtitle); add(t.category); t.sections.forEach { add(it.first); add(it.second) }
        }
        PREOP_TOPICS_RAW.forEach { t ->
            add(t.title); add(t.subtitle); add(t.category); t.sections.forEach { add(it.first); add(it.second) }
        }
        EQUIPMENT_TOPICS_RAW.forEach { t ->
            add(t.title); add(t.subtitle); add(t.category); t.sections.forEach { add(it.first); add(it.second) }
        }
        SURGICAL_TOPICS_RAW.forEach { t ->
            add(t.title); add(t.subtitle); add(t.category); t.sections.forEach { add(it.first); add(it.second) }
        }
        EMERGENCIES_RAW.forEach { e ->
            add(e.name); add(e.subtitle); add(e.category); add(e.recognize); add(e.warnings); add(e.refs)
            e.steps.forEach(::add); e.doses.forEach(::add)
        }
        CLIN_SECTIONS_RAW.forEach(::add)

        val entries = keys.map { k ->
            "{\"k\":\"${jsonEsc(k)}\",\"en\":${en?.containsKey(k) == true},\"pt\":${pt?.containsKey(k) == true}}"
        }
        File("/tmp/cronos_l10n_dump.json").writeText("[\n" + entries.joinToString(",\n") + "\n]")
        println("DUMPED ${keys.size} claves · sin EN: ${entries.count { "\"en\":false" in it }} · sin PT: ${entries.count { "\"pt\":false" in it }}")
    }
}
