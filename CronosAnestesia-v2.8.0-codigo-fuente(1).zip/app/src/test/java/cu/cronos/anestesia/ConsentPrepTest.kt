package cu.cronos.anestesia

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Pruebas del módulo de preparación de fármacos (Data3: DRUG_PREP_RAW +
 * DRUG_PRESENTATION_RAW) y del Consentimiento Informado anestésico
 * (Consent.buildBlocks, Ley No. 156/2022 + Helsinki). Actualizado a la
 * arquitectura v2.6.x: el mapa clave→DrugPrep(prep, admin, alias) y el
 * documento legal por bloques (texto, estilo, id).
 */
class ConsentPrepTest {

    // ---------- Preparación y presentación de los 45 fármacos ----------

    @Test
    fun `los 45 fármacos tienen preparación y presentación`() {
        assertEquals(45, DRUG_PREP_RAW.size)
        assertEquals(45, DRUG_PRESENTATION_RAW.size)
        assertEquals(DRUG_PREP_RAW.keys, DRUG_PRESENTATION_RAW.keys)
    }

    @Test
    fun `toda preparación tiene datos y modos de administración`() {
        DRUG_PREP_RAW.forEach { (name, p) ->
            assertTrue("Sin preparación: $name", p.prep.length > 40)
            assertTrue("Sin administración: $name", p.admin.length > 20)
            assertTrue("Sin modo BOLO/JERINGA/CONT: $name",
                listOf("BOLO", "JERINGA", "CONT", "IM", "SC", "ORAL").any { p.admin.contains(it) })
        }
    }

    @Test
    fun `la preparación encuentra por alias comercial`() {
        // Clave canónica con alias comercial en el campo alias
        val sux = DRUG_PREP_RAW.entries.first { it.key.contains("Succinilcolina") }
        assertTrue(sux.value.prep.contains("50 mg/mL"))
        assertTrue(sux.value.admin.contains("BOLO"))
        assertTrue(sux.value.alias.contains("Escolina"))
        // Tiopental documentado incompatible con fármacos ácidos (seguridad)
        val tio = DRUG_PREP_RAW.getValue("Tiopental")
        assertTrue(tio.prep.contains("alcalina") || tio.prep.contains("pH 10"))
        // Remifentanilo: solo jeringa perfusora, nunca bolo de mantenimiento
        val remi = DRUG_PREP_RAW.getValue("Remifentanilo")
        assertTrue(remi.admin.contains("JERINGA"))
        assertFalse(remi.admin.contains("BOLO: inducción"))
        // Adrenalina: IM de anafilaxia documentado
        val adr = DRUG_PREP_RAW.entries.first { it.key.startsWith("Adrenalina") }
        assertTrue(adr.value.admin.contains("IM") || adr.value.prep.contains("IM"))
    }

    @Test
    fun `presentaciones documentan concentración o envase`() {
        DRUG_PRESENTATION_RAW.forEach { (name, pres) ->
            assertTrue("Presentación corta: $name", pres.length > 15)
            assertTrue("Sin cifra: $name", pres.any { it.isDigit() })
        }
    }

    @Test
    fun `claves de preparación coinciden con los nombres de fármacos`() {
        // Los nombres INN son claves estables (no se traducen): permiten
        // localizar la preparación desde el buscador en cualquier idioma.
        val claves = DRUG_PREP_RAW.keys
        listOf("Propofol", "Ketamina", "Midazolam", "Rocuronio", "Noradrenalina (Norepinefrina)")
            .forEach { k -> assertTrue("Falta clave $k", claves.contains(k)) }
    }

    // ---------- Consentimiento informado anestésico ----------

    private val patient = Patient(
        id = "P1", name = "Ana Pérez", ci = "91050612345",
        age = "35", sex = "F", weightKg = "62", heightCm = "165",
        hx = "Ninguna de interés", asa = "II"
    )

    private fun blocks(technique: String, risksExtra: String = "") =
        Consent.buildBlocks(
            patient = patient,
            anesthesiologist = "Dr. Ejemplo",
            institution = "Hospital General",
            service = "Quirófano 2",
            technique = technique,
            procedure = "Colecistectomía laparoscópica",
            risksExtra = risksExtra,
            date = "2026-10-29 08:30",
            asa = "II"
        )

    @Test
    fun `seis técnicas seleccionables`() {
        assertEquals(6, Consent.TYPES.size)
        assertTrue(Consent.TYPES[0].startsWith("Anestesia general"))
    }

    @Test
    fun `el documento abre con título y marco legal cubano`() {
        val b = blocks(Consent.TYPES[0])
        assertTrue(b.first().second == 0)
        val texto = b.joinToString("\n") { it.first }
        assertTrue(texto.contains("CONSENTIMIENTO INFORMADO PARA ANESTESIA"))
        assertTrue(texto.contains("Ley No. 156"))
        assertTrue(texto.contains("Helsinki"))
        assertTrue(texto.contains("emergencia"))
    }

    @Test
    fun `las nueve secciones oficiales están presentes`() {
        val b = blocks(Consent.TYPES[0])
        val headers = b.filter { it.second == 1 }.map { it.first }
        assertEquals(9, headers.size)
        listOf(
            "IDENTIFICACIÓN DEL PACIENTE",
            "IDENTIFICACIÓN DEL PROFESIONAL",
            "DESCRIPCIÓN DEL PROCEDIMIENTO",
            "RIESGOS Y COMPLICACIONES",
            "BENEFICIOS ESPERADOS",
            "ALTERNATIVAS DISPONIBLES",
            "DERECHOS DEL PACIENTE",
            "DECLARACIÓN Y AUTORIZACIÓN",
            "FIRMAS"
        ).forEach { s -> assertTrue("Falta sección: $s", headers.any { it.contains(s) }) }
    }

    @Test
    fun `los datos del paciente se insertan y los vacíos se marcan`() {
        val texto = blocks(Consent.TYPES[0]).joinToString("\n") { it.first }
        assertTrue(texto.contains("Ana Pérez"))
        assertTrue(texto.contains("91050612345"))
        assertTrue(texto.contains("Colecistectomía laparoscópica"))
        assertTrue(texto.contains("Dr. Ejemplo"))
        assertTrue(texto.contains("2026-10-29 08:30"))
        // Paciente sin datos → líneas de puntos
        val vacio = Consent.buildBlocks(
            Patient("P2", "", "", "", "", "", "", ""),
            "", "", "", Consent.TYPES[0], "", "", "", ""
        ).joinToString("\n") { it.first }
        assertTrue(vacio.contains("___________"))
    }

    @Test
    fun `los riesgos cambian según la técnica de anestesia`() {
        val general = blocks(Consent.TYPES[0]).joinToString("\n") { it.first }
        val neuraxial = blocks(Consent.TYPES[2]).joinToString("\n") { it.first }
        val sedacion = blocks(Consent.TYPES[4]).joinToString("\n") { it.first }
        val regional = blocks(Consent.TYPES[5]).joinToString("\n") { it.first }
        assertTrue(general.contains("Hipertermia maligna"))
        assertTrue(neuraxial.contains("Cefalea postpunción"))
        assertTrue(sedacion.contains("Depresión respiratoria"))
        assertTrue(regional.contains("Neumotórax"))
    }

    @Test
    fun `los riesgos particulares del anestesiólogo se incluyen`() {
        val con = blocks(Consent.TYPES[1], risksExtra = "Alergia al látex documentada")
            .joinToString("\n") { it.first }
        assertTrue(con.contains("4.4"))
        assertTrue(con.contains("Alergia al látex"))
        val sin = blocks(Consent.TYPES[1]).joinToString("\n") { it.first }
        assertFalse(sin.contains("4.4"))
    }

    @Test
    fun `resumen de riesgos por técnica para la vista previa`() {
        val base = Consent.RISKS_COMMON.size
        Consent.TYPES.forEach { t ->
            assertTrue("riskSummary vacío para $t", Consent.riskSummary(t).size > base)
        }
        assertEquals(base, Consent.RISKS_COMMON.size)
        assertTrue(Consent.RISKS_COMMON.first().contains("Náuseas"))
    }

    @Test
    fun `los firmantes son paciente, anestesiólogo y testigo`() {
        val texto = blocks(Consent.TYPES[0]).joinToString("\n") { it.first }
        assertTrue(texto.contains("Paciente (o representante legal)"))
        assertTrue(texto.contains("Anestesiólogo responsable"))
        assertTrue(texto.contains("Testigo"))
        assertTrue(texto.contains("historia clínica"))
    }
}
