package cu.cronos.anestesia

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Vectores dorados del módulo de solicitud de licencia por WhatsApp (v1.5.2).
 * Solo cubre las funciones puras (sin android.net.Uri ni Context).
 */
class LicenseContactTest {

    @Test
    fun normalizePhone_stripsNonDigits() {
        assertEquals("5355301268", LicenseContact.normalizePhone("+53 5530 1268"))
        assertEquals("5355301268", LicenseContact.normalizePhone("+53-5530-1268"))
        assertEquals("5355301268", LicenseContact.normalizePhone("(+53) 55 30 1268"))
        assertEquals("", LicenseContact.normalizePhone("abc"))
    }

    @Test
    fun phoneConstant_isCleanAndComplete() {
        assertEquals("5355301268", LicenseContact.WHATSAPP_PHONE)
        assertTrue(LicenseContact.WHATSAPP_PHONE.all { it.isDigit() })
        assertEquals(10, LicenseContact.WHATSAPP_PHONE.length) // 53 + 8 dígitos del móvil
    }

    @Test
    fun developerName_constant() {
        assertEquals("Ronald García Deroncele", LicenseContact.DEVELOPER_NAME)
    }

    @Test
    fun requestMessage_containsVersionDeviceTierAndData() {
        val m = LicenseContact.buildRequestMessage(
            versionName = "1.5.2",
            deviceFormatted = "1234-5678-9ABC-DEF0",
            tier = "Profesional",
            holder = "Dr. Juan Pérez",
            org = "Hospital Universitario"
        )
        assertTrue(m.contains("Solicitud de licencia — Cronos Anestesia"))
        assertTrue(m.contains("App: 1.5.2"))
        assertTrue(m.contains("ID del dispositivo: 1234-5678-9ABC-DEF0"))
        assertTrue(m.contains("Nivel deseado: Profesional"))
        assertTrue(m.contains("Titular: Dr. Juan Pérez"))
        assertTrue(m.contains("Organismo: Hospital Universitario"))
    }

    @Test
    fun requestMessage_omitsEmptyHolderAndOrg() {
        val m = LicenseContact.buildRequestMessage("1.5.2", "A1B2-C3D4", "Básica")
        assertFalse(m.contains("Titular:"))
        assertFalse(m.contains("Organismo:"))
    }

    @Test
    fun requestMessage_trimsHolderAndOrg() {
        val m = LicenseContact.buildRequestMessage(
            "1.5.2", "X", "Institucional", "  Juan  ", "  Hospital  "
        )
        assertTrue(m.contains("Titular: Juan"))
        assertTrue(m.contains("Organismo: Hospital"))
    }

    @Test
    fun requestMessage_v160_includesPhoneDurationAndMethod() {
        val m = LicenseContact.buildRequestMessage(
            "1.6.0", "1234-5678", "Profesional",
            holder = "Juan", org = "", phone = "55301268",
            duration = "Anual", method = "Tarjeta Clásica (USD)"
        )
        assertTrue(m.contains("Duración deseada: Anual"))
        assertTrue(m.contains("Teléfono de contacto: 55301268"))
        assertTrue(m.contains("Forma de pago: Tarjeta Clásica (USD)"))
        // Sin teléfono/duración/método no viajan esas líneas
        val sin = LicenseContact.buildRequestMessage("1.6.0", "X", "Básica")
        assertFalse(sin.contains("Teléfono de contacto:"))
        assertFalse(sin.contains("Duración deseada:"))
        assertFalse(sin.contains("Forma de pago:"))
    }

    @Test
    fun contactMessage_mentionsAppVersion() {
        val m = LicenseContact.contactMessage("1.5.2")
        assertTrue(m.contains("Cronos Anestesia 1.5.2"))
    }
}
