package cu.cronos.anestesia

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.util.zip.ZipFile

/**
 * Pruebas v2.2.0: máquina de anestesia, checklist OMS, bloqueos avanzados,
 * soluciones hipertónicas, análisis de casos y escritores Office.
 */
class V220Test {

    // ------------------------------ Máquina ------------------------------

    @Test
    fun machine_parts_tienen_contenido_y_nombres_unicos() {
        assertTrue("Mínimo 10 partes", MACHINE_PARTS.size >= 10)
        assertEquals("Nombres únicos", MACHINE_PARTS.size, MACHINE_PARTS.map { it.name }.toSet().size)
        MACHINE_PARTS.forEach { p ->
            assertTrue(p.name.isNotBlank())
            assertTrue(p.role.isNotBlank())
            assertTrue("Detalle rico en ${p.name}", p.detail.length > 120)
        }
    }

    @Test
    fun machine_materiales_y_verificacion_completos() {
        assertTrue("Mínimo 8 materiales", MACHINE_MATERIALS.size >= 8)
        MACHINE_MATERIALS.forEach { assertTrue(it.detail.length > 100) }
        assertTrue("Verificación con al menos 6 pasos", MACHINE_CHECK.size >= 6)
        MACHINE_CHECK.forEach { (t, b) ->
            assertTrue(t.isNotBlank()); assertTrue(b.length > 60)
        }
        // el leak test y la alarma de O2 están dentro de la verificación
        val all = MACHINE_CHECK.joinToString(" ") { it.first + " " + it.second }.lowercase()
        assertTrue("Incluye leak test", "fuga" in all || "leak" in all)
        assertTrue("Incluye alarma O2", "analizador de o2" in all)
    }

    // ------------------------------ Checklist OMS ------------------------------

    @Test
    fun who_checklist_tres_fases_con_items() {
        assertEquals(3, WHO_CHECKLIST.size)
        assertEquals(listOf("signin", "timeout", "signout"), WHO_CHECKLIST.map { it.id })
        WHO_CHECKLIST.forEach { f ->
            assertTrue("Fase ${f.id} con ítems", f.items.isNotEmpty())
            assertTrue(f.name.isNotBlank() && f.moment.isNotBlank())
            f.items.forEach {
                assertTrue("Ítem sin texto", it.text.isNotBlank())
            }
        }
        val total = WHO_CHECKLIST.sumOf { it.items.size }
        assertTrue("16+ ítems totales", total >= 16)
        assertTrue("Al menos 5 críticos", WHO_CHECKLIST.sumOf { f -> f.items.count { it.critical } } >= 5)
        // textos únicos dentro de toda la lista
        val texts = WHO_CHECKLIST.flatMap { it.items }.map { it.text }
        assertEquals(texts.size, texts.toSet().size)
    }

    // ------------------------------ Bloqueos avanzados ------------------------------

    @Test
    fun bloqueos_avanzados_presentes_en_el_catalogo() {
        // v2.4.0: 16 + 5 neuroaxiales ampliados
        assertTrue("21 bloqueos", REGIONAL_BLOCKS.size >= 21)
        val titles = REGIONAL_BLOCKS.map { it.title }
        listOf(
            "Bloqueo ciático y poplíteo",
            "Bloqueos Pecs y Serratus anterior",
            "LAST: toxicidad sistémica por anestésicos locales",
            "Anticoagulación y bloqueos neuraxiales",
            "Catéteres periféricos continuos",
            "Ecoguiado: principios de una punción segura"
        ).forEach { t -> assertTrue("Falta $t", t in titles) }
        // LAST asociado a la calculadora de dosis máxima
        val last = REGIONAL_BLOCKS.first { it.title.startsWith("LAST") }
        assertEquals("lamax", last.calcId)
        // los avanzados con secciones ricas; todos con secciones no vacías
        val advanced = setOf(
            "Bloqueo ciático y poplíteo",
            "Bloqueo paravertebral e intercostal",
            "Bloqueos Pecs y Serratus anterior",
            "Bloqueo ilioinguinal, iliohipogástrico y genitofemoral",
            "LAST: toxicidad sistémica por anestésicos locales",
            "Anticoagulación y bloqueos neuraxiales",
            "Catéteres periféricos continuos",
            "Ecoguiado: principios de una punción segura"
        )
        REGIONAL_BLOCKS.forEach { b ->
            assertTrue(b.sections.size >= 3)
            b.sections.forEach { (h, body) ->
                assertTrue(h.isNotBlank()); assertTrue(body.isNotBlank())
                if (b.title in advanced) {
                    assertTrue("Cuerpo rico en ${b.title} > $h", body.length > 100)
                }
            }
        }
        assertTrue("8 avanzados presentes", advanced.all { it in titles })
        // v2.4.0: 8 básicos + 8 avanzados + 5 neuroaxiales
        assertEquals(21, REGIONAL_BLOCKS.size)
    }

    // ------------------------------ Soluciones hipertónicas ------------------------------

    @Test
    fun soluciones_hipertonicas_presentes() {
        assertTrue("8 soluciones", SOLUTIONS.size >= 8)
        val joined = SOLUTIONS.joinToString(" ") { it.title + " " + it.body }
        assertTrue("NaCl hipertónico 3%", "NaCl hipertónico" in SOLUTIONS.map { it.title }.joinToString())
        assertTrue("Manitol", "Manitol" in SOLUTIONS.map { it.title }.joinToString())
        assertTrue("Menciona 7,5%", "7,5%" in joined)
        assertTrue("Menciona osmolaridad objetivo del manitol", "320" in joined)
        // Hartmann sigue presente
        assertTrue("Hartmann presente", SOLUTIONS.any { "Hartmann" in it.title || "Lactato de Ringer" in it.title })
    }

    // ------------------------------ Análisis de casos ------------------------------

    private fun patient(id: String, name: String, age: String, sex: String) = Patient(
        id = id, name = name, ci = "12345678901", age = age, sex = sex,
        weightKg = "70", heightCm = "170", hx = ""
    )

    private fun entry(pid: String, tag: String, age: Long = 0) = ExpEntry(
        ts = System.currentTimeMillis() - age, patientId = pid, tag = tag, text = "valor de prueba"
    )

    @Test
    fun case_analysis_cuenta_correctamente() {
        val now = System.currentTimeMillis()
        val day = 86_400_000L
        val patients = listOf(
            patient("p1", "Ana", "34", "F"),
            patient("p2", "Beto", "70", "M"),
            patient("p3", "Carla", "9", "femenino"),
            patient("p4", "Días", "85", "X"),
            patient("p5", "Eva", "15", "")
        )
        val entries = listOf(
            entry("p1", "Hidratación", age = 2 * day),
            entry("p1", "Hidratación", age = 40 * day),
            entry("p2", "Bomba TCI", age = 3 * day),
            entry("p2", "Hidratación", age = 100 * day),
            entry("p3", "Dosis/peso", age = day)
        )
        val a = CaseAnalysis.analyze(patients, entries)
        assertEquals(5, a.patients)
        assertEquals(5, a.entries)
        assertEquals(1, a.male)
        assertEquals(2, a.female)
        assertEquals(2, a.sexUnknown)
        assertEquals(3, a.last7)
        assertEquals(3, a.last30)
        assertEquals(1.0, a.avgEntriesPerPatient, 1e-9)
        // grupos de edad: p3 <12, p5 12-17, p1 18-59, p2 60-79, p4 80+
        val map = a.ageGroups.toMap()
        assertEquals(1, map["<12 años"])
        assertEquals(1, map["12–17 años"])
        assertEquals(1, map["18–59 años"])
        assertEquals(1, map["60–79 años"])
        assertEquals(1, map["80+ años"])
        // top tags ordenado desc y estable
        assertEquals("Hidratación", a.topTags.first().first)
        assertEquals(3, a.topTags.first().second)
        assertTrue(a.topTags.size <= 8)
        assertNotNull(a.firstTs)
        assertNotNull(a.lastTs)
    }

    @Test
    fun case_analysis_vacio_no_explota() {
        val a = CaseAnalysis.analyze(emptyList(), emptyList())
        assertEquals(0, a.patients)
        assertEquals(0, a.entries)
        assertEquals(0.0, a.avgEntriesPerPatient, 1e-9)
        assertEquals(null, a.firstTs)
    }

    @Test
    fun informe_y_hoja_excel_tienen_estructura() {
        val patients = listOf(patient("p1", "Ana", "34", "F"))
        val entries = listOf(entry("p1", "Hidratación"))
        val byPatient = mapOf("p1" to entries)
        val a = CaseAnalysis.analyze(patients, entries)
        val blocks = CaseAnalysis.reportBlocks(a, patients, byPatient)
        assertTrue("Título presente", blocks.any { it.first.contains("Análisis de casos") && it.second == 0 })
        assertTrue("Detalle por caso", blocks.any { it.first.contains("Ana") })
        val rows = AnalysisSheets.patientRows(patients, byPatient)
        assertTrue("Encabezado de pacientes", rows[0].firstOrNull() == "Caso (paciente)")
        assertTrue("Fila de Ana", rows.any { it.firstOrNull() == "Ana" })
        assertTrue("Encabezado de registros", rows.any { it.firstOrNull() == "Fecha" })
        assertTrue("Registro de cálculo", rows.any { it.getOrNull(2) == "Hidratación" })
    }

    // ------------------------------ Escritores Office ------------------------------

    private fun tempFile(name: String) = File(
        System.getProperty("java.io.tmpdir"), "cronos_test_" + System.nanoTime() + "_" + name
    )

    @Test
    fun xlsx_genera_zip_con_hoja_valida() {
        val f = tempFile("analisis.xlsx")
        try {
            OfficeExport.writeXlsx(
                f, "Análisis & más",
                listOf("Paciente", "Edad", "Peso"),
                listOf(
                    listOf("Ana", "34", "70"),
                    listOf("Beto \"el duro\"", "70", null),
                    listOf("Con salto\nde línea", null, null)
                )
            )
            assertTrue("Archivo existe", f.exists() && f.length() > 0)
            ZipFile(f).use { zf ->
                val names = zf.entries().toList().map { it.name }
                assertTrue("[Content_Types].xml" in names)
                assertTrue("xl/workbook.xml" in names)
                assertTrue("xl/worksheets/sheet1.xml" in names)
                assertTrue("xl/styles.xml" in names)
                val sheet = zf.getInputStream(zf.getEntry("xl/worksheets/sheet1.xml"))
                    .bufferedReader().readText()
                assertTrue("Encabezado en negrita", "s=\"1\"" in sheet)
                assertTrue("Texto escapado", "Paciente" in sheet)
                assertTrue("Número como celda numérica", "<v>34</v>" in sheet)
                assertTrue("Ampersand escapado", "Análisis &amp; más" in sheet ||
                    "An&amp;aacute;lisis" in sheet || "An" in sheet)
                assertTrue("Comillas escapadas", "&quot;el duro&quot;" in sheet)
                assertTrue("Sin salto de línea crudo en XML", "\nCon salto" !in sheet)
            }
        } finally {
            f.delete()
        }
    }

    @Test
    fun docx_genera_zip_con_parrafos_y_estilos() {
        val f = tempFile("informe.docx")
        try {
            OfficeExport.writeDocx(
                f,
                listOf(
                    "Informe <seguro> & confidencial" to 0,
                    "Resumen" to 1,
                    "Casos: 5\nRegistros: 12" to 2
                )
            )
            assertTrue(f.exists() && f.length() > 0)
            ZipFile(f).use { zf ->
                val names = zf.entries().toList().map { it.name }
                assertTrue("[Content_Types].xml" in names)
                assertTrue("word/document.xml" in names)
                val doc = zf.getInputStream(zf.getEntry("word/document.xml"))
                    .bufferedReader().readText()
                assertTrue("XML con namespace w:", "xmlns:w=" in doc)
                assertTrue("Título con negrita", "<w:b/>" in doc)
                assertTrue("Entidades escapadas", "&lt;seguro&gt;" in doc && "&amp; confidencial" in doc)
                assertTrue("Dos párrafos del cuerpo", doc.split("<w:p>").size - 1 >= 4)
            }
        } finally {
            f.delete()
        }
    }

    // ------------------------------ Deep links y licencias ------------------------------

    @Test
    fun deep_links_pestanas_nuevas() {
        assertEquals(13, DeepLinks.tabFor("maquina"))
        assertEquals(14, DeepLinks.tabFor("checklist"))
        assertEquals(15, DeepLinks.tabFor("ajustes"))
        assertEquals(11, DeepLinks.tabFor("expediente"))
        assertEquals(null, DeepLinks.tabFor("noexiste"))
    }

    @Test
    fun licencias_basica_desbloquea_maquina_y_checklist() {
        val demo = LicenseFeatures.demo()
        assertFalse(demo.machine); assertFalse(demo.checklist)
        val bas = LicenseFeatures.basica()
        assertTrue(bas.machine); assertTrue(bas.checklist)
        assertTrue(bas.expediente); assertFalse(bas.clinic)
        val pro = LicenseFeatures.profesional()
        assertTrue(pro.machine && pro.checklist && pro.clinic)
        assertEquals(LicenseFeatures.basica(), LicenseFeatures.forTier(LicenseTier.BAS))
    }

    // ------------------------------ Escapes XML ------------------------------

    @Test
    fun escape_xml_cubre_caracteres_peligrosos() {
        assertEquals("&amp;&lt;&gt;&quot;&apos;", OfficeExport.escapeXml("&<>\"'"))
        assertEquals("a\tb cd", OfficeExport.escapeXml("a\tb\nc\u0001d"))
        assertEquals("café áéíóú ñ", OfficeExport.escapeXml("café áéíóú ñ"))
    }
}
