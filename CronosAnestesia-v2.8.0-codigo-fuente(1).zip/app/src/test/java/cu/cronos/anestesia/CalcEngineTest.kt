package cu.cronos.anestesia

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Vectores dorados de las nueve calculadoras (contrato §14: 100 % de
 * cobertura de dosificación crítica; Fase 3 del plan de adecuación).
 * Valores verificados a mano contra las fórmulas de referencia.
 */
class CalcEngineTest {

    private val EPS = 1e-9
    private fun eq(expected: Double, actual: Double, delta: Double = EPS) =
        assertEquals(expected, actual, delta)

    // ---------- Utilidades ----------

    @Test
    fun `parseNum acepta coma decimal y devuelva 0 ante basura`() {
        eq(70.5, CalcEngine.parseNum("70,5"))
        eq(12.0, CalcEngine.parseNum(" 12 "))
        eq(0.0, CalcEngine.parseNum("abc"))
        eq(0.0, CalcEngine.parseNum(""))
    }

    @Test
    fun `fmt formatea por rangos`() {
        assertEquals("140", CalcEngine.fmt(140.0))
        assertEquals("26.3", CalcEngine.fmt(26.25))
        assertEquals("66.0", CalcEngine.fmt(66.016))
        assertEquals("4.13", CalcEngine.fmt(4.125))
        assertEquals("476", CalcEngine.fmt(476.1904761904762))
    }

    // ---------- 1. Ayuno 2-4-6-8 ----------

    @Test
    fun `ayuno requerido 2-4-6-8`() {
        assertEquals(listOf(2.0, 4.0, 6.0, 8.0), CalcEngine.FASTING_REQUIRED_HOURS)
    }

    // ---------- 2. Holliday-Segar ----------

    @Test
    fun `mantenimiento 4-2-1 por tramos`() {
        eq(32.0, CalcEngine.maintenanceMlH(8.0))    // 8×4
        eq(60.0, CalcEngine.maintenanceMlH(20.0))   // 40 + 20
        eq(65.0, CalcEngine.maintenanceMlH(25.0))   // 40 + 20 + 5
        eq(110.0, CalcEngine.maintenanceMlH(70.0))  // 40 + 20 + 50
    }

    @Test
    fun `plan de hidratación 20 kg con 8 h de ayuno`() {
        val p = CalcEngine.hydrationPlan(20.0, 8.0)
        eq(60.0, p.maintenanceMlH)
        eq(480.0, p.deficitMl)
        eq(300.0, p.hour1Ml)   // 60 + 240
        eq(180.0, p.hour2Ml)   // 60 + 120
        eq(180.0, p.hour3Ml)
        eq(660.0, p.total3hMl)
    }

    // ---------- 3. Dosis por peso ----------

    @Test
    fun `propofol 2 mg por kg a 70 kg`() {
        eq(140.0, CalcEngine.weightDose(2.0, 70.0))
    }

    // ---------- 4. Infusión ----------

    @Test
    fun `noradrenalina 0,1 µg-kg-min con dilución de 16 µg-mL a 70 kg`() {
        eq(26.25, CalcEngine.infusionMlH(0.1, 70.0, 16.0))
        eq(0.42, CalcEngine.infusionMgH(0.1, 70.0))
    }

    @Test
    fun `dopamina 4 µg-kg-min con dilución de 1600 µg-mL a 70 kg`() {
        eq(10.5, CalcEngine.infusionMlH(4.0, 70.0, 1600.0))
    }

    // ---------- 5. Peso ideal Devine ----------

    @Test
    fun `peso ideal hombre 170 cm y mujer 160 cm`() {
        eq(66.016, CalcEngine.idealWeight(true, 170.0), 1e-6)
        eq(52.416, CalcEngine.idealWeight(false, 160.0), 1e-6)
    }

    @Test
    fun `peso ajustado con 0,4 de factor`() {
        eq(75.6096, CalcEngine.adjustedWeight(66.016, 90.0), 1e-6)
    }

    // ---------- 6. Tubo pediátrico ----------

    @Test
    fun `tubo a los 4 años`() {
        eq(5.0, CalcEngine.tubeUncuffedMm(4.0))
        eq(4.5, CalcEngine.tubeCuffedMm(4.0))
        eq(14.0, CalcEngine.tubeDepthCm(4.0))
    }

    @Test
    fun `tubo a los 6 meses redondea a medio punto`() {
        eq(4.0, CalcEngine.tubeUncuffedMm(0.5))   // 4,125 → 4,0
        eq(3.5, CalcEngine.tubeCuffedMm(0.5))     // 3,625 → 3,5
    }

    @Test
    fun `tubo a los 6 años y profundidad`() {
        eq(5.5, CalcEngine.tubeUncuffedMm(6.0))
        eq(5.0, CalcEngine.tubeCuffedMm(6.0))
        eq(15.0, CalcEngine.tubeDepthCm(6.0))
        eq(12.5, CalcEngine.tubeDepthCm(1.0))
    }

    // ---------- 7. Volemia y sangrado ----------

    @Test
    fun `volemia por categoría`() {
        eq(4900.0, CalcEngine.estimatedBloodVolume(70.0, 0))   // hombre
        eq(4550.0, CalcEngine.estimatedBloodVolume(70.0, 1))   // mujer
        eq(800.0, CalcEngine.estimatedBloodVolume(10.0, 2))    // niño
        eq(900.0, CalcEngine.estimatedBloodVolume(10.0, 3))    // lactante
    }

    @Test
    fun `pérdida máxima permitida 40 a 30 con 4900 mL`() {
        eq(1400.0, CalcEngine.allowableBloodLoss(4900.0, 40.0, 30.0))
    }

    // ---------- 8. Gasometría ----------

    @Test
    fun `índice P-F con aire ambiente`() {
        eq(476.1904761904762, CalcEngine.pfiIndex(100.0, 21.0))
    }

    @Test
    fun `clasificación de Berlín`() {
        assertEquals(CalcEngine.Berlin.NONE, CalcEngine.berlinClass(300.0))
        assertEquals(CalcEngine.Berlin.NONE, CalcEngine.berlinClass(476.19))
        assertEquals(CalcEngine.Berlin.MILD, CalcEngine.berlinClass(250.0))
        assertEquals(CalcEngine.Berlin.MODERATE, CalcEngine.berlinClass(150.0))
        assertEquals(CalcEngine.Berlin.SEVERE, CalcEngine.berlinClass(60.0))
    }

    @Test
    fun `gradiente A-a a nivel del mar`() {
        eq(99.73, CalcEngine.alveolarPao2(21.0, 40.0), 1e-6)
        eq(9.73, CalcEngine.aaGradient(90.0, 21.0, 40.0), 1e-6)
    }

    @Test
    fun `límite del gradiente por edad`() {
        eq(19.0, CalcEngine.aaNormalLimit(60.0))
        eq(25.0, CalcEngine.aaNormalLimit(0.0))
    }

    // ---------- 9. Anestésicos locales ----------

    private fun spec(name: String) =
        CalcEngine.LA_SPECS.first { it.name == name }

    @Test
    fun `la tabla incluye los 8 fármacos con concentraciones positivas`() {
        assertEquals(8, CalcEngine.LA_SPECS.size)
        assertTrue(CalcEngine.LA_SPECS.all { it.typicalConcMgMl > 0 && it.plainMgKg > 0 })
    }

    @Test
    fun `lidocaína con adrenalina 70 kg respeta mg-kg antes del tope`() {
        val m = CalcEngine.localAnestheticMax(spec("Lidocaína"), 70.0, true, false, 10.0)
        eq(7.0, m.mgPerKg)
        eq(490.0, m.maxMg)     // 7 × 70 < 500
        eq(49.0, m.maxMl)      // / 10 mg/mL
    }

    @Test
    fun `lidocaína sin adrenalina aplica el tope absoluto`() {
        val m = CalcEngine.localAnestheticMax(spec("Lidocaína"), 70.0, false, false, 10.0)
        eq(300.0, m.maxMg)     // 4,5 × 70 = 315 → tope 300
        eq(30.0, m.maxMl)
    }

    @Test
    fun `bupivacaína 70 kg alcanza justo el límite`() {
        val m = CalcEngine.localAnestheticMax(spec("Bupivacaína"), 70.0, false, false, 5.0)
        eq(175.0, m.maxMg)
        eq(35.0, m.maxMl)
    }

    @Test
    fun `ropivacaína con 100 kg y adrenalina usa el tope absoluto`() {
        val m = CalcEngine.localAnestheticMax(spec("Ropivacaína"), 100.0, true, false, 7.5)
        eq(225.0, m.maxMg)     // 3 × 100 = 300 → tope 225
    }

    @Test
    fun `bupivacaína pediátrica 20 kg`() {
        val plain = CalcEngine.localAnestheticMax(spec("Bupivacaína"), 20.0, false, true, 5.0)
        eq(2.0, plain.mgPerKg)
        eq(40.0, plain.maxMg)  // 2 × 20 < 100
        val epi = CalcEngine.localAnestheticMax(spec("Bupivacaína"), 20.0, true, true, 5.0)
        eq(50.0, epi.maxMg)    // 2,5 × 20 < 175
    }

    @Test
    fun `peso cero o concentración cero devuelven cero`() {
        val m0 = CalcEngine.localAnestheticMax(spec("Lidocaína"), 0.0, false, false, 10.0)
        eq(0.0, m0.maxMg)
        eq(0.0, m0.maxMl)
        val m1 = CalcEngine.localAnestheticMax(spec("Lidocaína"), 70.0, false, false, 0.0)
        eq(300.0, m1.maxMg)    // dosis sí se calcula
        eq(0.0, m1.maxMl)      // volumen no, sin concentración
    }

    // ---------- Deep links ----------

    @Test
    fun `deep links mapean secciones a pestañas`() {
        assertEquals(0, DeepLinks.tabFor("inicio"))
        assertEquals(1, DeepLinks.tabFor("emergencias"))
        assertEquals(1, DeepLinks.tabFor("EMERGENCIAS"))
        assertEquals(4, DeepLinks.tabFor("calculadoras"))
        assertEquals(9, DeepLinks.tabFor("clinica"))
        assertEquals(10, DeepLinks.tabFor("bibliografia"))
        assertEquals(11, DeepLinks.tabFor("expediente"))
        assertEquals(12, DeepLinks.tabFor("perlas"))
        assertEquals(13, DeepLinks.tabFor("maquina"))
        assertEquals(14, DeepLinks.tabFor("checklist"))
        assertEquals(15, DeepLinks.tabFor("ajustes"))
    }

    @Test
    fun `deep links desconocidos devuelven null`() {
        assertNull(DeepLinks.tabFor("desconocido"))
        assertNull(DeepLinks.tabFor(null))
    }

    // ---------- DoseEngine: calculadora de dosis por fármaco (peso + edad) ----------

    private fun regimenOf(drug: String, label: String): Regimen =
        DoseEngine.profileFor(drug)!!.regimens.first { it.label == label }

    @Test
    fun `todos los fármacos tienen perfil calculable`() {
        assertEquals(45, DRUGS.size)
        DRUGS.forEach { d ->
            assertNotNull("Sin perfil: ${d.name}", DoseEngine.profileFor(d.name))
        }
    }

    @Test
    fun `noradrenalina 0,1 µg-kg-min a 70 kg con 16 µg-mL da 26,25 mL-h`() {
        val r = regimenOf("Noradrenalina (Norepinefrina)", "Infusión vasopresora")
        val dil = r.dilutions.first()
        eq(16.0, dil.concPerMl)
        val res = DoseEngine.regimenResult(r, 70.0, 35.0, dil)
        eq(84.0, res.amountMin)        // 0,02 × 70 × 60
        eq(2100.0, res.amountMax)      // 0,5 × 70 × 60
        assertEquals("µg/h", res.amountLabel)
        eq(5.25, res.mlMin)            // 84 / 16
        eq(131.25, res.mlMax)          // 2100 / 16
        // Valor medio de referencia: 0,1 µg/kg/min → 26,25 mL/h
        eq(26.25, DoseEngine.mlPerHour(DoseEngine.perHour(0.1, 70.0, DoseUnit.UG_KG_MIN), 16.0))
    }

    @Test
    fun `dopamina 5 µg-kg-min a 70 kg con 1600 µg-mL da 13,125 mL-h`() {
        eq(13.125, DoseEngine.mlPerHour(DoseEngine.perHour(5.0, 70.0, DoseUnit.UG_KG_MIN), 1600.0))
    }

    @Test
    fun `dobutamina 10 µg-kg-min a 20 kg con 1000 µg-mL da 12 mL-h`() {
        eq(12.0, DoseEngine.mlPerHour(DoseEngine.perHour(10.0, 20.0, DoseUnit.UG_KG_MIN), 1000.0))
    }

    @Test
    fun `propofol TIVA 6 mg-kg-h a 70 kg con 10 mg-mL da 42 mL-h`() {
        val r = regimenOf("Propofol", "TIVA mantenimiento")
        val res = DoseEngine.regimenResult(r, 70.0, 35.0, r.dilutions.first())
        eq(280.0, res.amountMin)       // 4 × 70
        eq(560.0, res.amountMax)       // 8 × 70
        assertEquals("mg/h", res.amountLabel)
        eq(28.0, res.mlMin)
        eq(56.0, res.mlMax)
    }

    @Test
    fun `remifentanilo 0,15 µg-kg-min a 20 kg con 40 µg-mL da 4,5 mL-h`() {
        eq(4.5, DoseEngine.mlPerHour(DoseEngine.perHour(0.15, 20.0, DoseUnit.UG_KG_MIN), 40.0))
    }

    @Test
    fun `adrenalina anafilaxia IM calcula 0,2 mg en 20 kg y topa en 0,5 al adulto`() {
        val r = regimenOf("Adrenalina (Epinefrina)", "Anafilaxia IM")
        eq(0.2, DoseEngine.regimenResult(r, 20.0, 8.0, null).amountMax)
        eq(0.5, DoseEngine.regimenResult(r, 70.0, 35.0, null).amountMax)  // tope absoluto
    }

    @Test
    fun `vasopresina no es ponderal en el adulto`() {
        val r = regimenOf("Vasopresina", "Infusión shock vasopléjico")
        val a = DoseEngine.regimenResult(r, 70.0, 35.0, r.dilutions.first())
        val b = DoseEngine.regimenResult(r, 100.0, 35.0, r.dilutions.first())
        eq(0.6, a.amountMin)           // 0,01 × 60 U/h
        eq(2.4, a.amountMax)           // 0,04 × 60
        eq(a.amountMax, b.amountMax)   // independiente del peso
        eq(1.5, a.mlMin)               // 0,6 / 0,4
        eq(6.0, a.mlMax)
    }

    @Test
    fun `heparina pre-CEX a 70 kg da 21000-28000 U`() {
        val r = regimenOf("Heparina sódica no fraccionada", "Pre-CEX")
        val res = DoseEngine.regimenResult(r, 70.0, 35.0, null)
        eq(21000.0, res.amountMin)
        eq(28000.0, res.amountMax)
        assertEquals("U", res.amountLabel)
    }

    @Test
    fun `sugammadex 2 mg-kg a 80 kg da 160 mg`() {
        val r = regimenOf("Sugammadex", "Reversión rutinaria (T2 visible)")
        eq(160.0, DoseEngine.regimenResult(r, 80.0, 35.0, null).amountMax)
    }

    @Test
    fun `midazolam pediátrico usa el tope pediátrico`() {
        val r = regimenOf("Midazolam", "Sedación IV titulada")
        val nino = DoseEngine.regimenResult(r, 10.0, 6.0, null)
        assertTrue(nino.pediatric)
        eq(0.5, nino.amountMax)        // 0,05 × 10 < tope 2
        val ninoGrande = DoseEngine.regimenResult(r, 70.0, 6.0, null)
        eq(2.0, ninoGrande.amountMax)  // 3,5 → tope pediátrico 2
        val adulto = DoseEngine.regimenResult(r, 70.0, 35.0, null)
        eq(3.5, adulto.amountMax)      // tope adulto 5 no alcanzado
        assertTrue(!adulto.pediatric)
    }

    @Test
    fun `sin peso no calcula`() {
        val r = regimenOf("Dopamina", "Infusión inotrópica/vasopresora")
        val res = DoseEngine.regimenResult(r, 0.0, 35.0, r.dilutions.first())
        assertTrue(res.needsWeight)
        eq(0.0, res.mlMax)
    }

    @Test
    fun `regímenes por edad se filtran correctamente`() {
        // Naloxona: adulto µg fijos vs pediátrico µg/kg
        val nalox = DoseEngine.profileFor("Naloxona")!!
        val adultoR = nalox.regimens.first { it.label.startsWith("IV titulada") }
        val pedR = nalox.regimens.first { it.label == "Pediátrico" }
        assertTrue(DoseEngine.regimenVisible(adultoR, 35.0))
        assertTrue(!DoseEngine.regimenVisible(adultoR, 6.0))
        assertTrue(!DoseEngine.regimenVisible(pedR, 35.0))
        assertTrue(DoseEngine.regimenVisible(pedR, 6.0))
        // Pediátrico: 1–5 µg/kg × 20 kg = 0,02–0,1 mg
        val resPed = DoseEngine.regimenResult(pedR, 20.0, 6.0, null)
        eq(0.02, resPed.amountMin)
        eq(0.1, resPed.amountMax)
    }
}
