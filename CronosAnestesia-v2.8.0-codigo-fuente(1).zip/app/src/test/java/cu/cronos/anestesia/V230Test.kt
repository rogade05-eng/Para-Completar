package cu.cronos.anestesia

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Pruebas v2.3.0: consentimientos editables multiplantilla, checklist
 * anestésica de verificación, albúmina 5 % en el catálogo de soluciones
 * y el tema «Anemia y terapia transfusional».
 */
class V230Test {

    private fun demoPatient() = Patient(
        id = "t1", name = "Prueba CI", ci = "00000000000", age = "45",
        sex = "M", weightKg = "70", heightCm = "170", hx = "Ninguno"
    )

    // ------------------------- Consentimientos -------------------------

    @Test
    fun consentimientos_hay_4_plantillas_con_titulos() {
        assertEquals(4, ConsentTemplates.ALL.size)
        assertEquals(setOf("anestesia", "transfusion", "parto", "sedacion"), ConsentTemplates.ALL.toSet())
        ConsentTemplates.ALL.forEach {
            assertTrue(ConsentTemplates.title(it).isNotBlank())
            assertFalse(ConsentTemplates.title(it) == "Consentimiento")
        }
    }

    @Test
    fun transfusion_bloques_completos_con_riesgos_y_firmas() {
        val blocks = ConsentTemplates.buildTransfusion(
            edit = ConsentEditData(),
            patient = demoPatient(), anesthesiologist = "Dr. T",
            institution = "H. Clínico", service = "Anestesiología",
            procedure = "Colecistectomía", components = "2 CGC", reason = "Anemia sintomática",
            date = "31 de octubre de 2026"
        )
        assertTrue("Suficientes bloques", blocks.size >= 15)
        assertTrue(blocks[0].first.contains("TRANSFUSIÓN DE HEMODERIVADOS"))
        val all = blocks.joinToString("\n") { it.first }
        assertTrue("Menciona TRALI", all.contains("TRALI"))
        assertTrue("Menciona TACO", all.contains("TACO"))
        assertTrue("Menciona alternatives", all.contains("ácido tranexámico"))
        assertTrue("Sección de firmas", all.contains("FIRMAS"))
        assertTrue("Marco legal cubano", all.contains("Ley No. 156"))
    }

    @Test
    fun parto_bloques_con_riesgos_neuraxiales_y_alternativas() {
        val blocks = ConsentTemplates.buildParto(
            edit = ConsentEditData(),
            patient = demoPatient().copy(sex = "F", age = "28"),
            anesthesiologist = "Dra. T", institution = "Gineco", service = "Obstetricia",
            technique = "Analgesia epidural continua", risksExtra = "", date = "hoy"
        )
        val all = blocks.joinToString("\n") { it.first }
        assertTrue(blocks[0].first.contains("ANALGESIA DEL PARTO"))
        assertTrue("Cefalea postpunción", all.contains("postpunción"))
        assertTrue("Hematoma epidural", all.contains("Hematoma o absceso epidural"))
        assertTrue("Alternativa con gas", all.contains("óxido nitroso"))
        assertTrue("Efecto sobre el bebé descrito", all.contains("registro cardíaco fetal"))
        assertTrue("Firmas", all.contains("FIRMAS"))
    }

    @Test
    fun sedacion_bloques_con_instrucciones_de_alta() {
        val blocks = ConsentTemplates.buildSedacion(
            edit = ConsentEditData(),
            patient = demoPatient(), anesthesiologist = "Dr. T",
            institution = "H. Provincial", service = "Endoscopia",
            procedure = "Gastroscopía", risksExtra = "", date = "hoy"
        )
        val all = blocks.joinToString("\n") { it.first }
        assertTrue(blocks[0].first.contains("SEDACIÓN"))
        assertTrue("Instrucciones de alta", all.contains("24 horas"))
        assertTrue("Ayuno", all.contains("ayuno"))
        assertTrue("Grados de sedación", all.contains("profunda"))
        assertTrue("Firmas", all.contains("FIRMAS"))
    }

    @Test
    fun plantilla_anestesia_original_intacta() {
        val blocks = Consent.buildBlocks(
            patient = demoPatient(), anesthesiologist = "Dr. T", institution = "I",
            service = "S", technique = Consent.TYPES[0], procedure = "P",
            risksExtra = "", date = "hoy", asa = "II"
        )
        assertTrue(blocks.size >= 20)
        assertTrue(blocks.joinToString("\n") { it.first }.contains("CONSENTIMIENTO INFORMADO PARA ANESTESIA"))
    }

    @Test
    fun ediciones_se_aplican_a_las_plantillas_nuevas() {
        val edit = ConsentEditData(
            risks = listOf("Riesgo particular por técnica modificada"),
            clauses = "Cláusula acordada con el paciente."
        )
        val blocks = ConsentTemplates.buildSedacion(
            edit = edit, patient = demoPatient(), anesthesiologist = "Dr. T",
            institution = "I", service = "S", procedure = "P", risksExtra = "", date = "hoy"
        )
        val all = blocks.joinToString("\n") { it.first }
        assertTrue(all.contains("Riesgos particulares añadidos por el anestesiólogo"))
        assertTrue(all.contains("Riesgo particular por técnica modificada"))
        assertTrue(all.contains("Cláusulas adicionales acordadas con el paciente"))
        assertTrue(all.contains("Cláusula acordada con el paciente."))
    }

    @Test
    fun ediciones_vacias_no_anaden_bloques() {
        val base = ConsentTemplates.buildTransfusion(
            edit = ConsentEditData(), patient = demoPatient(), anesthesiologist = "A",
            institution = "I", service = "S", procedure = "P", components = "C", reason = "R", date = "d"
        )
        val conEdit = ConsentTemplates.buildTransfusion(
            edit = ConsentEditData(risks = emptyList(), clauses = "   "),
            patient = demoPatient(), anesthesiologist = "A",
            institution = "I", service = "S", procedure = "P", components = "C", reason = "R", date = "d"
        )
        assertEquals(base.size, conEdit.size)
    }

    @Test
    fun almacen_de_ediciones_json_ida_y_vuelta() {
        val d = ConsentEditData(
            risks = listOf("a", "b"), clauses = "texto",
            institution = "H", service = "S", anesthesiologist = "D"
        )
        val back = ConsentEditStore.fromJson(ConsentEditStore.toJson(d))
        assertEquals(d, back)
        // sin riesgos
        val empty = ConsentEditData()
        assertEquals(empty, ConsentEditStore.fromJson(ConsentEditStore.toJson(empty)))
        // JSON sin campos completos: se carga como plantilla vacía
        val blank = ConsentEditStore.fromJson("{\"risks\":[]}")
        assertEquals(ConsentEditData(), blank)
    }

    // ------------------------- Checklist anestésica -------------------------

    @Test
    fun checklist_anestesica_tres_fases_ordenadas() {
        assertEquals(3, ANESTH_CHECKLIST.size)
        assertEquals(listOf("Pre-inducción", "Durante", "Después"), ANESTH_CHECKLIST.map { it.name })
        ANESTH_CHECKLIST.forEach { p ->
            assertTrue("Fase ${p.name} con ítems", p.items.isNotEmpty())
            assertTrue("Fase ${p.name} con críticos", p.items.any { it.critical })
            p.items.forEach { assertTrue("Texto de ítem no vacío", it.text.isNotBlank()) }
        }
    }

    @Test
    fun preinduccion_cubre_maquina_monitor_drogas_via_aerea() {
        val pre = ANESTH_CHECKLIST.first()
        val grupos = pre.items.map { it.group }.toSet()
        assertEquals(
            setOf(GROUP_MACHINE, GROUP_MONITOR, GROUP_DRUGS, GROUP_AIRWAY),
            grupos
        )
        // críticos clave del pre-inducción
        val criticals = pre.items.filter { it.critical }.map { it.text }
        assertTrue(criticals.any { it.contains("leak test") || it.contains("fugas") })
        assertTrue(criticals.any { it.contains("Preoxigenación") })
        assertTrue(criticals.any { it.contains("Ayuno") })
        assertTrue(criticals.any { it.contains("etiquetado") })
    }

    @Test
    fun preinduccion_minimo_25_items_y_durante_con_capnografia() {
        val pre = ANESTH_CHECKLIST.first()
        assertTrue("Pre-inducción completa", pre.items.size >= 25)
        val durante = ANESTH_CHECKLIST[1]
        assertTrue(
            "Capnografía continua crítica durante",
            durante.items.any { it.critical && it.text.contains("Capnografía") }
        )
        val despues = ANESTH_CHECKLIST[2]
        assertTrue(
            "Traspaso verbal crítico al final",
            despues.items.any { it.critical && it.text.contains("Traspaso") }
        )
    }

    // ------------------------- Contenidos nuevos -------------------------

    @Test
    fun soluciones_total_9_con_albumina() {
        assertEquals(9, SOLUTIONS.size)
        val alb = SOLUTIONS.firstOrNull { it.title.contains("Albúmina humana 5%") }
        assertNotNull("Falta albúmina 5 %", alb)
        alb!!.let {
            assertTrue("Composición", it.body.contains("5 g/100 mL"))
            assertTrue("Paracentesis", it.body.contains("paracentesis"))
            assertTrue("SAFE", it.body.contains("SAFE"))
            assertTrue("TCE contraindicada", it.body.contains("TCE"))
        }
    }

    @Test
    fun total_temas_clinicos_57_con_anemia_transfusional() {
        // v2.4.0: 52 + 5 neuroaxiales (la FISIOLOGY se valida en V240Test)
        val total = COMORBIDITIES.size + REGIONAL_BLOCKS.size + MONITORING.size +
            PREOP_TOPICS.size + SURGICAL_TOPICS.size + EQUIPMENT_TOPICS.size
        assertEquals(58, total)
        val anemia = COMORBIDITIES.firstOrNull { it.title == "Anemia y terapia transfusional" }
        assertNotNull("Falta el tema de anemia", anemia)
        anemia!!.let {
            assertTrue("Mínimo 6 secciones", it.sections.size >= 6)
            val all = it.sections.joinToString("\n") { s -> s.second }
            assertTrue("Umbral restrictivo Hb 7", all.contains("Hb <7 g/dL"))
            assertTrue("MTP 1:1:1", all.contains("1:1:1"))
            assertTrue("Ácido tranexámico", all.contains("tranexámico"))
            assertTrue("TRICS III citado", all.contains("TRICS III"))
            assertTrue("Testigos de Jehová", all.contains("Testigos de Jehová"))
        }
    }
}
