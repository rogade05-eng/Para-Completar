package cu.cronos.anestesia

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v2.8.0 — Pruebas del Simulador de crisis: integridad estructural de los
 * 8 escenarios (pasos, opciones, calificaciones, informe) y matemática del
 * motor de puntuación. Contenido: v2.8.0 — verificar contra protocolo
 * institucional.
 */
class CrisisContentTest {

    @Test
    fun `ocho_escenarios_con_ids_unicos`() {
        assertEquals(8, CRISIS_SCENARIOS.size)
        assertEquals(CRISIS_SCENARIOS.size, CRISIS_SCENARIOS.map { it.id }.distinct().size)
        CRISIS_SCENARIOS.forEach { sc ->
            assertTrue("título vacío en ${sc.id}", sc.title.isNotBlank())
            assertTrue("subtítulo vacío en ${sc.id}", sc.subtitle.isNotBlank())
            assertTrue("categoría vacía en ${sc.id}", sc.category.isNotBlank())
            assertTrue("viñeta corta en ${sc.id}", sc.intro.length > 120)
            assertTrue("monitor vacío en ${sc.id}", sc.monitor.isNotBlank())
            assertTrue("refs vacío en ${sc.id}", sc.refs.isNotBlank())
        }
    }

    @Test
    fun `cinco_pasos_con_cuatro_opciones_y_una_correcta`() {
        CRISIS_SCENARIOS.forEach { sc ->
            assertEquals("escenario ${sc.id} debe tener 5 pasos", 5, sc.steps.size)
            assertTrue("maxScore = 15", sc.maxScore == 15)
            sc.steps.forEachIndexed { i, st ->
                assertEquals("paso $i de ${sc.id} debe tener 4 opciones", 4, st.options.size)
                assertTrue("situación corta en ${sc.id}/$i", st.situation.length > 60)
                assertTrue("monitor vacío en ${sc.id}/$i", st.monitor.isNotBlank())
                assertEquals(
                    "exactamente una opción correcta en ${sc.id}/$i",
                    1, st.options.count { it.grade == CrisisEngine.GRADE_CORRECT }
                )
                st.options.forEachIndexed { j, o ->
                    assertTrue("grado inválido en ${sc.id}/$i/$j", o.grade in 0..3)
                    assertTrue("texto vacío en ${sc.id}/$i/$j", o.text.isNotBlank())
                    assertTrue("feedback corto en ${sc.id}/$i/$j", o.feedback.length > 40)
                }
            }
        }
    }

    @Test
    fun `informe_y_dosis_presentes`() {
        CRISIS_SCENARIOS.forEach { sc ->
            assertTrue("debrief corto en ${sc.id}", sc.debrief.size >= 4)
            assertTrue("dosis insuficientes en ${sc.id}", sc.doses.size >= 5)
            sc.doses.forEach { d -> assertTrue("dosis sin números en ${sc.id}", Regex("\\d").containsMatchIn(d)) }
        }
    }

    @Test
    fun `categorias_cubren_las_crisis_perioperatorias`() {
        val cats = CRISIS_SCENARIOS.map { it.category }.distinct()
        assertTrue(cats.size >= 6)
        // las 8 crisis acordadas
        val ids = CRISIS_SCENARIOS.map { it.id }.toSet()
        assertEquals(
            setOf(
                "laringoespasmo", "hipotension_cesarea", "anafilaxia", "hipertermia_maligna",
                "hipoxemia_subita", "last_toxicidad", "broncoespasmo", "neumotorax_tension"
            ), ids
        )
    }

    @Test
    fun `motor_de_puntuacion_ratings`() {
        assertEquals(3, CrisisEngine.rating(85))
        assertEquals(3, CrisisEngine.rating(100))
        assertEquals(2, CrisisEngine.rating(84))
        assertEquals(2, CrisisEngine.rating(65))
        assertEquals(1, CrisisEngine.rating(64))
        assertEquals(1, CrisisEngine.rating(40))
        assertEquals(0, CrisisEngine.rating(39))
        assertEquals(0, CrisisEngine.rating(0))
    }

    @Test
    fun `cada_escenario_tiene_nivel_r1_r4_valido`() {
        val rx = Regex("R[1-4]")
        CRISIS_SCENARIOS.forEach { sc ->
            assertTrue("nivel inválido en ${sc.id}: ${sc.level}", rx.containsMatchIn(sc.level))
        }
    }
}
