package cu.cronos.anestesia

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.assertFalse
import org.junit.Test

/**
 * v2.7.0 — Contenido de la Escuela de Residentes y del Módulo Pedagógico del
 * Tutor: 12 áreas, 60 fichas, 72 preguntas con niveles válidos, bibliografías
 * y las 2 calculadoras nuevas del motor (Cockcroft-Gault y Perlas).
 */
class StudyContentTest {

    private fun eq(expected: Double, actual: Double, tol: Double = 1e-9) =
        assertEquals(expected, actual, tol)

    // ---------------- Escuela: catálogo ----------------

    @Test
    fun `doce areas con fichas y preguntas suficientes`() {
        assertEquals(12, STUDY_AREAS.size)
        assertTrue("60 fichas como mínimo", STUDY_AREAS.sumOf { it.cardCount } >= 60)
        assertTrue("72 preguntas como mínimo", STUDY_AREAS.sumOf { it.questionCount } >= 72)
        STUDY_AREAS.forEach { a ->
            assertTrue("desc vacía en ${a.id}", a.desc.isNotBlank())
            assertTrue("bibliografía vacía en ${a.id}", a.bibliography.isNotEmpty())
            a.cards.forEach { c ->
                assertTrue("definición corta en ${c.title}", c.definition.length > 40)
                assertTrue("puntos clave en ${c.title}", c.keyPoints.size >= 3)
                assertTrue("cifras en ${c.title}", c.figures.size >= 2)
                assertTrue("errores en ${c.title}", c.mistakes.size >= 2)
                assertTrue("repaso exprés vacío en ${c.title}", c.express.isNotBlank())
            }
        }
        assertEquals("ids únicos", STUDY_AREAS.size, STUDY_AREAS.map { it.id }.toSet().size)
    }

    @Test
    fun `preguntas con 4 opciones, una correcta y niveles R válidos`() {
        STUDY_AREAS.forEach { a ->
            a.questions.forEach { q ->
                assertEquals("opciones de ${a.id}", 4, q.options.size)
                assertTrue("correcta fuera de rango en ${a.id}", q.correct in 0..3)
                assertTrue("explicación corta en ${a.id}", q.explanation.length > 30)
                assertTrue("niveles vacíos en ${a.id}", q.levels.isNotEmpty())
                assertTrue("niveles inválidos en ${a.id}: ${q.levels}", q.levels.all { it in StudyEngine.LEVELS })
            }
        }
        // distribución por nivel: debe haber preguntas para cada R
        val all = STUDY_AREAS.flatMap { it.questions }
        StudyEngine.LEVELS.forEach { lv ->
            assertTrue("sin preguntas para $lv", all.any { lv in it.levels })
        }
        // cada área debe tener preguntas en al menos 2 niveles distintos
        STUDY_AREAS.forEach { a ->
            assertTrue("área ${a.id} con niveles pobres", a.questions.flatMap { it.levels }.toSet().size >= 2)
        }
    }

    // ---------------- Tutor: motor de examen y guías ----------------

    @Test
    fun `banco de examen filtra por nivel y sin duplicados`() {
        val poolAll = StudyEngine.examPool(STUDY_AREAS, StudyEngine.LEVELS)
        assertEquals(72, poolAll.size)
        val poolR1 = StudyEngine.examPool(STUDY_AREAS, listOf("R1"))
        assertTrue(poolR1.isNotEmpty() && poolR1.size < poolAll.size)
        assertTrue(poolR1.all { "R1" in it.levels })
        // selección determinista con la misma semilla
        val a = StudyEngine.pickQuestions(poolAll, 10, 42L)
        val b = StudyEngine.pickQuestions(poolAll, 10, 42L)
        assertEquals(a, b)
        assertEquals(10, a.size)
        // no pide más de lo que hay
        assertEquals(poolR1.size, StudyEngine.pickQuestions(poolR1, 500, 1L).size)
        assertEquals(0, StudyEngine.pickQuestions(poolAll, 0, 1L).size)
    }

    @Test
    fun `bloques de examen y clave son consistentes`() {
        val pool = StudyEngine.examPool(listOf(STUDY_AREAS[0]), StudyEngine.LEVELS)
        val picked = StudyEngine.pickQuestions(pool, 5, 7L)
        val ex = StudyEngine.examBlocks("T", "H", picked, false)
        assertTrue("sin respuestas en el examen del residente", ex.none { it.first.startsWith("Respuesta correcta") })
        assertEquals(5, ex.count { it.first.matches(Regex("\\d+\\..*")) && !it.first.startsWith("   ") })
        val key = StudyEngine.examBlocks("T", "H", picked, true)
        assertEquals(5, key.count { it.first.startsWith("Respuesta correcta") })
    }

    @Test
    fun `guia de estudio incluye secciones obligatorias`() {
        val blocks = StudyEngine.guideBlocks(STUDY_AREAS[5], listOf("R2"), 2, "Dr. Romay")
        val all = blocks.joinToString("\n") { it.first }
        listOf("1. Objetivos", "2. Contenidos", "3. Material", "4. Método docente", "5. Autoevaluación", "6. Bibliografía")
            .forEach { s -> assertTrue("falta $s", s in all) }
        assertTrue("tutor en la guía", "Dr. Romay" in all)
        assertTrue("niveles en la guía", "R2" in all)
    }

    @Test
    fun `metodos docentes del tutor completos`() {
        assertTrue(TEACHING_METHODS.size >= 10)
        TEACHING_METHODS.forEach { m ->
            assertTrue(m.whenToUse.isNotBlank())
            assertTrue(m.how.isNotEmpty())
            assertTrue(m.evaluation.isNotBlank())
        }
        assertTrue(TUTOR_CORE_BIBLIO.size >= 6)
    }

    @Test
    fun `progreso de la escuela persiste el mejor resultado`() {
        // motor sin contexto Android: solo el contrato de cálculo (aciertos*1000+total)
        val a = 7 * 1000 + 10
        val b = 9 * 1000 + 10
        assertTrue(b > a)
    }

    // ---------------- Motor v2.7.0: Cockcroft-Gault y Perlas ----------------

    @Test
    fun `cockcroft_gault_exacto`() {
        // Hombre 40 años, 70 kg, Cr 1,0 → (100 × 70)/(72) = 97,222…
        eq(97.2222, CalcEngine.cockcroftGault(40.0, 70.0, 1.0, false), 1e-3)
        // Mujer: × 0,85
        eq(97.2222 * 0.85, CalcEngine.cockcroftGault(40.0, 70.0, 1.0, true), 1e-3)
        // Anciano con insuficiencia: 80 años, 60 kg, Cr 2,0 → (60 × 60)/144 = 25,0
        eq(25.0, CalcEngine.cockcroftGault(80.0, 60.0, 2.0, false), 1e-9)
        // Datos inválidos → 0
        eq(0.0, CalcEngine.cockcroftGault(0.0, 70.0, 1.0, false))
        // clases
        assertTrue(CalcEngine.cockcroftGaultClass(25.0).contains("grave"))
        assertTrue(CalcEngine.cockcroftGaultClass(95.0).contains("normal"))
    }

    @Test
    fun `perlas_volumen_gastrico_exacto`() {
        // V = 27 + 14,6 × 5 − 1,28 × 40 = 27 + 73 − 51,2 = 48,8 mL
        eq(48.8, CalcEngine.gastricVolumePerlas(5.0, 40.0), 1e-9)
        // riesgo por peso: 48,8 mL en 70 kg = 0,697 mL/kg → bajo
        assertTrue(CalcEngine.gastricRiskClass(48.8, 70.0).contains("bajo"))
        // antro grande: V = 27 + 14,6×12 − 1,28×40 = 27 + 175,2 − 51,2 = 151 mL → 2,16 mL/kg → alto
        eq(151.0, CalcEngine.gastricVolumePerlas(12.0, 40.0), 1e-9)
        assertTrue(CalcEngine.gastricRiskClass(151.0, 70.0).contains("alto"))
        // peso inválido
        assertTrue(CalcEngine.gastricRiskClass(100.0, 0.0).contains("Sin datos"))
    }

    @Test
    fun `app sin INTERNET y sin cambios de contrato`() {
        // Sanity: las 20 escalas siguen en 6 grupos contiguos
        val cats = SCALES_RAW.map { it.category }
        val seen = mutableListOf<String>()
        cats.forEach { if (seen.lastOrNull() != it) seen.add(it) }
        assertEquals(seen.size, seen.toSet().size)
        assertEquals(20, SCALES_RAW.size)
        // 15 calculadoras
        assertTrue("EVA con slider", SCALES_RAW.first { it.name.startsWith("EVA") }.sliderMax == 10)
    }
}
