package cu.cronos.anestesia

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Vectores dorados de tarifas y formas de pago (v1.6.0): precios por duración,
 * cuentas receptoras (CUP/Transfermóvil y USD/Tarjeta Clásica), conversión con
 * la tasa elTOQUE que introduce el usuario y mensajes «Ya pagué».
 * Solo cubre funciones puras (sin android.net.Uri ni Context).
 */
class TariffsTest {

    private val pro = Tariffs.PLANS.first { it.key == "PRO" }

    @Test
    fun accounts_areValidAndCorrect() {
        assertEquals("9234069992511687", Tariffs.TRANSFERMOVIL_ACCOUNT)
        assertEquals("9760039003567228", Tariffs.USD_ACCOUNT)
        assertTrue(Tariffs.TRANSFERMOVIL_ACCOUNT.all { it.isDigit() })
        assertTrue(Tariffs.USD_ACCOUNT.all { it.isDigit() })
        assertEquals(16, Tariffs.TRANSFERMOVIL_ACCOUNT.length)
        assertEquals(16, Tariffs.USD_ACCOUNT.length)
        assertEquals("9234 0699 9251 1687", Tariffs.TRANSFERMOVIL_ACCOUNT_DISPLAY)
        assertEquals("9760 0390 0356 7228", Tariffs.USD_ACCOUNT_DISPLAY)
    }

    @Test
    fun plans_threeTiersWithCoherentPrices() {
        assertEquals(3, Tariffs.PLANS.size)
        assertEquals(listOf("BAS", "PRO", "INST"), Tariffs.PLANS.map { it.key })
        Tariffs.PLANS.forEach { p ->
            assertTrue(p.monthly > 0)
            assertTrue(p.monthly < p.quarterly)
            assertTrue(p.quarterly < p.annual)
            assertTrue(p.annual < p.perpetual)
        }
        assertEquals(listOf(4, 10, 35, 60), listOf(pro.monthly, pro.quarterly, pro.annual, pro.perpetual))
        val inst = Tariffs.PLANS.first { it.key == "INST" }
        Tariffs.DURATIONS.indices.forEach { i ->
            assertTrue(Tariffs.priceUsd(inst, i) > Tariffs.priceUsd(pro, i))
        }
    }

    @Test
    fun durations_matchVigenciaDeLaClave() {
        assertEquals(listOf("Mensual", "Trimestral", "Anual", "Perpetua"), Tariffs.DURATIONS)
        assertEquals(listOf(30, 90, 365, 0), Tariffs.DURATION_DAYS)
        assertEquals(Tariffs.DURATIONS.size, Tariffs.DURATION_DAYS.size)
        assertEquals(3, Tariffs.PERPETUAL_INDEX)
    }

    @Test
    fun priceUsd_mapsEachDuration() {
        assertEquals(pro.monthly, Tariffs.priceUsd(pro, 0))
        assertEquals(pro.quarterly, Tariffs.priceUsd(pro, 1))
        assertEquals(pro.annual, Tariffs.priceUsd(pro, 2))
        assertEquals(pro.perpetual, Tariffs.priceUsd(pro, 3))
        assertEquals("Profesional · Anual", Tariffs.planLabel(pro, 2))
    }

    @Test
    fun perMonth_andSavings_onlyForMultiMonth() {
        assertNull(Tariffs.perMonth(pro, 0))
        assertNull(Tariffs.perMonth(pro, 3))
        assertEquals(10.0 / 3.0, Tariffs.perMonth(pro, 1)!!, 1e-9)
        assertEquals(35.0 / 12.0, Tariffs.perMonth(pro, 2)!!, 1e-9)
        assertNull(Tariffs.savingsPercent(pro, 0))
        assertNull(Tariffs.savingsPercent(pro, 3))
        assertEquals(17, Tariffs.savingsPercent(pro, 1)) // 12 → 10
        assertEquals(27, Tariffs.savingsPercent(pro, 2)) // 48 → 35
    }

    @Test
    fun cupFor_usesRateProvidedByUser() {
        assertEquals(15400L, Tariffs.cupFor(35, 440.0))
        assertEquals(875L, Tariffs.cupFor(2, 437.5))
        assertEquals(0L, Tariffs.cupFor(35, 0.0))
    }

    @Test
    fun parseRate_acceptsCommaAndSpaces_rejectsInvalid() {
        assertEquals(440.0, Tariffs.parseRate("440")!!, 1e-9)
        assertEquals(440.5, Tariffs.parseRate(" 440,5 ")!!, 1e-9)
        assertNull(Tariffs.parseRate("abc"))
        assertNull(Tariffs.parseRate(""))
        assertNull(Tariffs.parseRate("0"))
        assertNull(Tariffs.parseRate("-3"))
    }

    @Test
    fun formatters_useSpanishConventions() {
        assertEquals("15 400", Tariffs.formatCup(15400))
        assertEquals("875", Tariffs.formatCup(875))
        assertEquals("1 234 567", Tariffs.formatCup(1234567))
        assertEquals("3,33", Tariffs.formatUsd2(10.0 / 3.0))
        assertEquals("2,92", Tariffs.formatUsd2(35.0 / 12.0))
        assertEquals("4", Tariffs.formatUsd2(4.0))
    }

    @Test
    fun paymentPhone_8to15Digits() {
        assertTrue(Tariffs.isValidPaymentPhone("+53 5530 1268"))
        assertTrue(Tariffs.isValidPaymentPhone("55301268"))
        assertFalse(Tariffs.isValidPaymentPhone("5530126")) // 7 dígitos
        assertFalse(Tariffs.isValidPaymentPhone(""))
        assertFalse(Tariffs.isValidPaymentPhone("abc"))
    }

    @Test
    fun paymentMessage_cupVariant_includesPhoneAndAccounts() {
        val m = Tariffs.buildPaymentMessage(
            versionName = "1.6.0",
            deviceFormatted = "1234-5678-9ABC-DEF0",
            planLabel = "Profesional · Anual",
            priceUsd = 35,
            phone = "55301268",
            holder = "Dr. Juan Pérez",
            cupText = "15 400 CUP (tasa elTOQUE 440)"
        )
        assertTrue(m.contains("Confirmación de pago — Cronos Anestesia"))
        assertTrue(m.contains("App: 1.6.0"))
        assertTrue(m.contains("Plan contratado: Profesional · Anual (USD 35)"))
        assertTrue(m.contains("Titular: Dr. Juan Pérez"))
        assertTrue(m.contains("Teléfono de la transferencia: 55301268"))
        assertTrue(m.contains("ID del dispositivo: 1234-5678-9ABC-DEF0"))
        assertTrue(m.contains("Moneda pagada: CUP"))
        assertTrue(m.contains("Monto en CUP: 15 400 CUP (tasa elTOQUE 440)"))
        assertTrue(m.contains("Comprobante: pegue aquí la captura o el número de operación"))
        assertTrue(m.contains("Cuenta CUP (Transfermóvil): 9234069992511687"))
        assertTrue(m.contains("Cuenta USD (Tarjeta Clásica): 9760039003567228"))
        assertFalse(m.contains("exactos"))
    }

    @Test
    fun paymentMessage_usdVariant_exactPriceAndNoCupLine() {
        val m = Tariffs.buildPaymentMessage(
            "1.6.0", "X", "Básica · Mensual", 2, "55301268",
            paidCurrency = "USD"
        )
        assertTrue(m.contains("Moneda pagada: USD"))
        assertTrue(m.contains("Monto: USD 2 exactos (sin conversión)"))
        assertFalse(m.contains("Monto en CUP"))
        assertFalse(m.contains("Titular:"))
        assertFalse(m.contains("____"))
        // En la variante CUP sin tasa calculada viaja el hueco para llenarla
        val cup = Tariffs.buildPaymentMessage("1.6.0", "X", "Básica · Mensual", 2, "55301268")
        assertTrue(cup.contains("Monto en CUP: ____ (tasa del día según elTOQUE)"))
    }
}
