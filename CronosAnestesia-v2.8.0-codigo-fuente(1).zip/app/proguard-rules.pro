# Cronos Anestesia — reglas R8
-keepattributes SourceFile, LineNumberTable
-dontwarn org.bouncycastle.**
-dontwarn org.conscrypt.**
-dontwarn org.openjsse.**

# DataStore
-keep class androidx.datastore.** { *; }

# Mantener SafeMode (usado tras caídas del proceso)
-keep class cu.cronos.anestesia.SafeModeKt { *; }

# SQLCipher (almacén cifrado de contenido, Fase 4)
-keep class net.zetetic.database.** { *; }
-dontwarn net.zetetic.database.**
