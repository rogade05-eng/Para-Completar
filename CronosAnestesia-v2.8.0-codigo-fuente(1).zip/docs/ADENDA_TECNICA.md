# Adenda técnica — Cronos Anestesia v1.3.0

Fecha: 19/10/2026 · Sustituye como referencia de alcance a las «desviaciones
arquitectónicas» del informe de auditoría (Auditoria_Contrato_Tecnico
_CronosAnestesia_v1.0.5.docx, Tabla 12).

## 1. Estado de las fases del plan

| Fase | Contenido del plan | Estado en v1.3.0 |
|---|---|---|
| Fase 1 | Emergencias ≤2 toques, maxLocalAnesthetic, manual embebido | **Cumplida** (v1.2.0) |
| Fase 2 | Comorbilidades, bloqueos regionales, monitorización, plan preop | **Cumplida** (v1.2.0) |
| Fase 3 (formal) | Git; mapping.txt y SHA256SUMS.txt; cadenas a recursos; pruebas de calculadoras con vectores dorados; CHANGELOG; corrección de `detail!!` | **Cumplida** (esta versión) |
| Fase 4 (si escala) | Room+SQLCipher; `.acupkg`; multi-módulo; suite completa; SBOM; C4; deep links; bloqueo del registro clínico | **Parcial**: Room+SQLCipher ✔, SBOM ✔, C4 ✔, deep links ✔; `.acupkg` y multi-módulo **diferidos a v2.0** (§3) |

## 2. Lo que la v1.3.0 añade respecto al contrato

- **§6 (Room + SQLCipher)**: implementado como almacén cifrado del *registro
  de contenido* (`content_meta`, `content_history`) con clave aleatoria
  protegida por AndroidKeyStore. El contenido clínico sigue compilado porque
  el mecanismo de distribución de datos (`.acupkg`) se difiere (§3); la base
  queda lista como almacén de destino.
- **§9.2**: motor de cálculo puro `CalcEngine` (sin Compose/Android) con 28
  pruebas unitarias de vectores dorados; capa de navegación sin cadenas
  hardcodeadas (recursos `values/strings.xml`, español por defecto).
- **§10.1 (contentVersion)**: visible en Ajustes y registrado con historial en
  la base cifrada.
- **§11.3 (deep links)**: esquema `cronos://` con las 12 secciones.
- **§13 (entregables)**: SBOM CycloneDX 1.5, `mapping.txt`, `SHA256SUMS.txt`,
  documentación C4, `CHANGELOG.md`, manual embebido (desde 1.2.0).
- **§14 (pruebas)**: JUnit 4 con `testReleaseUnitTest` en verde; 100 % de los
  cálculos de dosificación crítica cubiertos por vectores dorados.
- **Portada de 3 s** solicitada por el usuario, con salto por toque.

## 3. Desviaciones vigentes y decisiones que se someten a adenda

1. **Arquitectura multi-módulo (§4)** — diferido a v2.0. La app es un único
   módulo `:app` con separación por capas a nivel de archivo (UI / engine /
   datos / seguridad). Migrar a `:core:*` + `:feature:*` exige una rebase
   completa del build; no aporta valor clínico por sí sola.
2. **Paquetes de contenido `.acupkg` (§7)** — diferido a v2.0. El esquema
   `content_meta` + `content_history` ya existe en la base cifrada; falta el
   importador Ed25519 con los 6 pasos de validación y la transacción Room con
   reversión. Mientras tanto, las actualizaciones de contenido se entregan
   como APK completo (mismo certificado, instalación directa).
3. **Contenido clínico compilado** — los 39+5+9+6+14+14+6+27+6 elementos viven
   en Kotlin; la migración de cadenas a recursos cubrió la capa de navegación
   (pestañas, inicio, ajustes, secciones), no el texto clínico, que migrará a
   la base cifrada junto con `.acupkg`.
4. **minSdk 24 frente a 26 del contrato (R-02)** — desviación formalizada en
   la auditoría; mantiene cobertura de dispositivos en uso en Cuba.
5. **Ajustes de UI en DataStore sin cifrar (S-02)** — los ajustes no contienen
   datos personales; todo dato de contenido versionado sí reside en base
   SQLCipher. Si se añade un registro clínico de pacientes, se hará cifrado
   (bloqueo con PIN/biometría incluido) según §11.
6. **Tamaño del APK (R-03)** — 23,3 MB (<50 MB) por incluir `libsqlcipher.so`
   para 4 ABIs; se puede recortar a ~15 MB con `abiFilters` ARM si se decide.
7. **i18n** — la interfaz es español por defecto (`values/`); la traducción al
   inglés (recursos `values-en/`) queda pendiente y es compatible con el
   `resourceConfigurations es,en` vigente.

## 4. Reproducibilidad del build

- Gradle 8.9 + AGP 8.5.2 + Kotlin 2.0.20 + KSP 2.0.20-1.0.25, JDK 17
  (Temurin, fijado en `gradle.properties`).
- `gradle assembleRelease` → `zipalign -f 4` → `apksigner sign` con
  `cronos-release.keystore` (alias `cronos`). El certificado no cambia desde
  v1.0.4 (SHA-256 `628592a3…35ba8`), lo que permite instalación directa sobre
  cualquier versión previa.
- El almacén de claves **no** se versiona en Git (`.gitignore`); copia
  respaldada junto a cada release.
