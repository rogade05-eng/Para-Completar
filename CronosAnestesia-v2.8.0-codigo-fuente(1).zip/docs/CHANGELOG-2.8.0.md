# CHANGELOG 2.8.0 — Simulador de crisis + traducción completa

Fecha: 2026-11-06 · versionCode 31 · firma sin cambios
(SHA-256 cert: 628592a3…35ba8 · actualiza sobre v2.7.0 sin desinstalar)

## Simulador de crisis (pestaña Crisis)
- 8 escenarios × 5 puntos de decisión × 4 opciones calificadas
  (3 correcta · 2 aceptable · 1 subóptima · 0 peligrosa).
- Viñeta inicial + monitor por paso; puntaje %, tiempo y rating
  (experto ≥85 · seguro ≥65 · riesgos evitables ≥40 · repaso urgente <40).
- Debriefing: puntos clave, dosis críticas, referencias.
- Progreso local: SharedPreferences `crisis_progreso` (mejor % y mejor tiempo).
- Escenarios: laringoespasmo · hipotensión en cesárea · anafilaxia ·
  hipertermia maligna · hipoxemia (DOPE) · LAST · broncoespasmo ·
  neumotórax a tensión. Contenido: Dr. Romay Díaz Deroncele.

## Traducción completa (ola I18nV280)
- 2.324 literales × EN + PT = 4.648 pares, generados y validados
  (claves byte-exactas, placeholders %N$x intactos, ceros vacíos: 0).
- Cubre Escuela (fichas/preguntas), Tutor (métodos/exámenes/guías incluidos
  los exportables PDF/Word), Temario R1–R4, Simulador completo, tema
  «Verificación de estudios preoperatorios» y UI de los módulos.
- Cobertura garantizada por `V280Test` (≥4.400 EN / ≥4.300 claves PT).

## Correcciones sobre v2.7.0
1. Pestañas Escuela/Tutor en blanco: el despacho `when(tab)` terminaba en 17.
2. values-pt eliminado del APK por `resourceConfigurations("es","en")`.

## Técnico
- Crisis.kt (datos+motor), CrisisUI.kt (UI), I18nV280.kt (ola generada),
  accesores studyAreas/teachingMethods/residencyL10n en L10nData.kt.
- lintVitalRelease desactivado (memoria del entorno); suite: 253 tests.
