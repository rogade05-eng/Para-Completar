# Cronos Anestesia v2.2.0 (versionCode 21) — 24 de octubre de 2026

## Novedades (5 módulos nuevos)

### 1. Máquina de anestesia (pestaña «Máquina»)
- 13 partes de la máquina con función, fallos típicos y cómo verificarlas
  (suministro de gases, reguladores, rotámetros, vaporizadores, barra posterior,
  absorbedor de CO2, sistema circular y válvulas, bolsa reservorio, válvula APL,
  ventilador, analizador de O2, extracción de gases y alarmas).
- 10 materiales de uso habitual: laringoscopios y palas, tubos endotraqueales,
  mascarilla laríngea, Guedel, mascarillas y preoxigenación, circuitos y HME,
  cal sodada, vías y equipos de perfusión, rescate de vía aérea, succión.
- Verificación preoperatoria en 8 pasos (leak test, calibración de O2, simulación
  de alarma de O2 y de desconexión, vaporizador, circuito, ventilador, succión/SCVO
  y drogas de emergencia en la barra).
- **Esquemas dinámicos** dibujados por la app (Compose Canvas, 100 % offline):
  sistema circular con flujo animado y zonas táctiles (paciente, manguitas, válvulas,
  absorbedor, bolsa, APL, gas fresco) y cadena de flujo de gases de la fuente al paciente.
- Requiere licencia Básica o superior.

### 2. Checklist OMS de seguridad quirúrgica (pestaña «Checklist»)
- Lista OMS 2009 en 3 fases: Sign In (6), Time Out (6) y Sign Out (5).
- Interactiva: casillas, barra de progreso, ítems CRÍTICOS destacados y aviso al
  completar la fase («anúnciela en voz alta al equipo»).
- «Guardar en expediente» registra fase, avance y críticos pendientes si los hay.
- El estado se limpia al salir: herramienta de quirófano.
- Requiere licencia Básica o superior.

### 3. Bloqueos regionales avanzados (Clínica → Bloqueos: 8 → 16 temas)
8 temas nuevos PRO+: ciático y poplíteo, paravertebral e intercostal,
Pecs/Serratus anterior, ilioinguinal/iliohipogástrico/genitofemoral,
LAST con protocolo de lípidos 20 % (asociado a la calculadora de dosis máxima),
anticoagulación y bloqueos neuraxiales (intervalos ASRA), catéteres periféricos
continuos y principios del ecoguiado seguro.
La Clínica pasa de 43 a **51 temas**.

### 4. Cristaloides: hipertónicas (Soluciones: 6 → 8)
- NaCl hipertónico 3 % y 7,5 %: osmoterapia en TCE/herniación, objetivos de Na
  sérico, vías y precauciones.
- Manitol 20 %: dosis, indicaciones, contraindicaciones, osmolaridad objetivo
  (<320 mOsm/L) y reposición de la diuresis osmótica.

### 5. Análisis de casos (Expediente → sub-pestaña «Análisis»)
- Estadísticas agregadas de todos los casos: pacientes, registros, actividad
  de 7 y 30 días, promedio por caso, distribución por sexo y grupo de edad,
  y secciones (cálculos) más registradas.
- **Exportación a Excel (.xlsx) y Word (.docx) reales** — escritores OOXML propios
  (sin librerías), 100 % offline — más PDF y la hoja de registros por caso.
  Se comparten con cualquier app (correo, WhatsApp, archivos) vía FileProvider.

## Técnico
- versionCode 21, versionName 2.2.0; sin permiso INTERNET (contrato R-01).
- Pestañas: 13 = Máquina, 14 = Checklist, 15 = Ajustes; deep links cronos://maquina
  y cronos://checklist añadidos. El Manual de usuario embebido se actualizó.
- Corregido: el botón «Manual de usuario» de Ajustes ahora abre el manual
  (pestaña de detalle registrada).
- Pruebas: 118/118 en verde (13 nuevas: máquina, checklist OMS, bloqueos,
  hipertónicas, análisis de casos, xlsx/docx, deep links, licencias y escapes XML).
- Certificado de firma idéntico (SHA-256 628592a3…35ba8): actualización directa
  sin desinstalar.
