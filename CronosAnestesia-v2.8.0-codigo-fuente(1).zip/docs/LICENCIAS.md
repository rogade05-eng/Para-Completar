# Licencias offline — Cronos Anestesia (v1.5.0)

Guía del desarrollador para emitir, verificar y auditar las licencias que
desbloquean la aplicación. La activación es **100 % offline**: no hay servidores,
no hay permiso INTERNET y no viaja ningún dato del cliente.

---

## 1. Cómo funciona

| Pieza | Dónde vive | Función |
|---|---|---|
| Clave **privada** EC P-256 | `license-keys/cronos_license_private.pem` (SOLO usted) | Firma las licencias. Sin ella nadie puede forjar una clave válida. |
| Clave **pública** | Incrustada en la app (`License.kt`) | La app verifica la firma de cada clave al activar y en cada arranque. |
| Herramienta emisora | `scripts/cronos_license_tool.py` | `keygen`, `issue`, `verify`, `show`, `list`. |
| Licencia | Texto `CRONOS1.carga.firma` (~300 caracteres) | Se envía por WhatsApp/correo; el cliente la pega en Ajustes. |
| Auditoría | `license-keys/issued_licenses.csv` | Registro de todo lo emitido (serial, titular, nivel, expiración). |

Cada licencia codifica: **serial · titular · institución · nivel · emisión ·
expiración (o perpetua) · hash de dispositivo (opcional)**. La app la verifica
con criptografía ECDSA (SHA256withECDSA) y **no acepta claves firmadas por otra
persona**: modificar un solo byte de la clave la invalida.

## 2. Niveles y qué desbloquean

| Contenido | Demo (sin licencia) | Básica | Profesional | Institucional |
|---|---|---|---|---|
| Emergencias (6 protocolos ACLS/PALS/MH/LAST…) | ✔ | ✔ | ✔ | ✔ |
| Gases anestésicos (5) | ✔ | ✔ | ✔ | ✔ |
| Fármacos (45) | muestra de 10 | ✔ | ✔ | ✔ |
| Dosis calculada por peso y edad | ✘ | ✔ | ✔ | ✔ |
| Calculadoras (9) | 3 | ✔ | ✔ | ✔ |
| Escalas (6) | 2 | ✔ | ✔ | ✔ |
| Complicaciones (14) | 4 | ✔ | ✔ | ✔ |
| Premedicación (14 temas) | ✘ | ✔ | ✔ | ✔ |
| Soluciones (6) | 2 | ✔ | ✔ | ✔ |
| Clínica avanzada (41 temas: comorbilidades, bloqueos, monitorización, preop + 14 temas quirúrgicos) | ✘ | ✘ | ✔ | ✔ |
| Calculadora «Infusión por fármaco» (45 fármacos: buscador, preparación y modos de administración) | ✘ | ✔ | ✔ | ✔ |
| Perlas clínicas (13, inspiradas en el canal educativo Medik Brain) | ✔ | ✔ | ✔ | ✔ |
| Expediente del paciente + consentimiento informado + exportación PDF/Excel | ✘ | ✔ | ✔ | ✔ |
| Bibliografía (24) | 3 | ✔ | ✔ | ✔ |

**Criterio clínico deliberado**: Emergencias y Perlas clínicas nunca se
bloquean (seguridad del paciente y mejor escaparate comercial). La
**Básica** cubre el uso diario personal y añade el expediente con
consentimiento informado; la **Profesional** añade el módulo clínico
avanzado con los 14 temas quirúrgicos y sus 11 calculadoras; la
**Institucional** es Profesional perpetua con nombre de institución.

> Nota v2.0.0: la tabla de precios y cuentas sigue siendo única en
> `Tariffs.kt`; las nuevas funcionalidades no cambian el mapa de licencias
> (licgen 1.1.0 no requiere cambios).

## 3. Flujo de una venta (4 pasos)

1. **El cliente instala el APK** y ve el modo demostración. En *Ajustes →
   Licencia y activación* encuentra su **ID de dispositivo** (p. ej.
   `A1B2-C3D4-E5F6-0718`) y se lo envía (si quiere licencia atada al equipo).
2. **Usted emite la licencia** desde el servidor o su PC:

   ```bash
   python3 scripts/cronos_license_tool.py issue \
       --holder "Dra. María Pérez" \
       --org "Hospital Arnaldo Milián" \
       --tier pro --days 365 \
       --device A1B2-C3D4-E5F6-0718 \
       --serial CRN-2026-0007
   ```

   Opciones: `--tier bas|pro|inst` · `--days N` (365 por defecto) ·
   `--perpetual` · `--device` (opcional, ata la licencia a ese equipo) ·
   `--serial` (opcional, si no se indica se genera uno).
3. **Envía la clave** `CRONOS1.…` por WhatsApp/correo. Puede comprobarla antes:
   `python3 scripts/cronos_license_tool.py verify "CRONOS1.…"`
4. **El cliente la pega** en Ajustes → «Activar licencia». La app verifica la
   firma, la fecha y el dispositivo, y desbloquea el contenido al instante.

## 4. Recomendación anti-piratería

- **Atar al dispositivo** (`--device`) siempre que el cliente lo permita: la
  clave pegada en otro teléfono da «Licencia de otro dispositivo». Es la
  medida más eficaz contra la reventa de una misma clave.
- **Caducidad anual**: fuerza renovación y le da contacto anual con cada
  cliente (use `--days 365`; las perpetuas solo para instituciones de confianza).
- **Anti-reempaquetado**: la app compara el SHA-256 del certificado con el
  original (`628592A3…35BA8`); si alguien descompila, modifica y re-firma el
  APK, la app lo detecta y se queda en modo demostración con aviso rojo.
- **Ofuscación R8** activada en las compilaciones release.

### Límites honestos (¿qué NO puede evitar?)
- Un usuario técnico con el teléfono rooteado podría extraer la clave de
  DataStore — por eso la vinculación por dispositivo es la defensa real.
- No existe licenciamiento imposible de eludir sin servidor (Play Billing,
  etc.); ese modelo exigiría permiso INTERNET y contradice el contrato (R-01).
  Este esquema ofrece la mejor relación esfuerzo/protección para venta directa.

## 5. Protección de la clave privada

- `cronos_license_private.pem` **NO está en la carpeta pública de descargas**;
  está en `license-keys/` con permisos 600. Si lo descarga del servidor,
  **bórrelo del servidor** y guárdelo en su PC personal (y una copia cifrada).
- Quien tenga la privada puede emitir licencias válidas. Trátela como la
  llave de su casa.
- Si sospecha fuga → **rotación**: `keygen` nuevo en otra carpeta, compile una
  versión nueva con la clave pública nueva (constante `PUBLIC_KEY_B64URL` en
  `License.kt`) y re-emita licencias a sus clientes legítimos. Las claves
  viejas dejarán de verificarse.

## 6. Auditoría y consulta

```bash
python3 scripts/cronos_license_tool.py list                 # todo lo emitido
python3 scripts/cronos_license_tool.py show "CRONOS1.…"     # campos sin verificar
python3 scripts/cronos_license_tool.py verify "CRONOS1.…" --device A1B2-…  # como la app
```

## 7. Licencias de ejemplo incluidas

Emitidas durante la implementación (útiles para probar la activación):

- `CRN-2026-0001` — Profesional, 1 año, cualquier dispositivo (portable).
- `CRN-2026-0002` — Institucional perpetua (Hospital Universitario Ejemplo).
- `CRN-2026-0003` — Básica, 1 año, **atada** al hash de demostración
  `A1B2-C3D4-E5F6-0718` (en un teléfono real dará «otro dispositivo»:
  sirve para probar el mensaje de error).

Las tres están en `license-keys/issued_licenses.csv` y su verificación quedó
cubierta por las pruebas unitarias de `LicenseVerifierTest` (15 vectores).

## 8. Tarifas y pagos (v1.6.0)

La APK muestra las tarifas al cliente (diálogo «Tarifas y formas de pago»,
visible en Inicio, secciones bloqueadas y Ajustes → Licencia). El flujo es
**pague primero, reciba después**: transferencia → confirmación por WhatsApp
con el teléfono del cliente y el comprobante → clave CRONOS1.… → activación.

### Tabla de precios (USD, negociables)

| Plan          | Mensual | Trimestral | Anual | Perpetua |
|---------------|--------:|-----------:|------:|---------:|
| Básica        |   $2    |     $5     |  $15  |   $25    |
| Profesional   |   $4    |    $10     |  $35  |   $60    |
| Institucional |   $20   |    $50     | $180  |  $300    |

- Trimestral ≈ 17 % de ahorro, anual ≈ 27 % frente al mes suelto (la app lo
  muestra con el equivalente «≈ USD x al mes»).
- Emitir: mensual `--dias 30`, trimestral `--dias 90`, anual `--dias 365`,
  perpetua `--perpetua` (CronosLicencias.exe o cronos_license_tool.py).
- Negociación abierta: estudiantes, residentes e instituciones con varios
  equipos; los internacionales acuerdan la vía por WhatsApp.

### Cuentas receptoras (constantes en `Tariffs.kt`)

- **CUP (Transfermóvil):** `9234069992511687`. El importe = precio USD ×
  **tasa del día según elTOQUE (eltoque.com)**. La app NO aplica ninguna tasa:
  incluye una calculadora donde el cliente escribe la tasa publicada ese día.
- **USD (Tarjeta Clásica):** `9760039003567228`. Precio exacto del plan, sin
  conversión ni dependencia de elTOQUE.
- **Efectivo:** a conveniar directamente con el desarrollador.

### Reglas operativas

1. Verificar en las app bancarias que la transferencia entró (monto + teléfono
   del remitente que viaja en el mensaje de confirmación) ANTES de emitir.
2. Los mensajes «Solicitud» y «Confirmación de pago» incluyen: plan, precio
   USD, moneda (CUP/USD), teléfono del cliente, ID del dispositivo y ambas
   cuentas. Emitir la clave atada a ese ID.
3. Para cambiar precios, cuentas o número de WhatsApp: editar solo
   `Tariffs.kt` (tarifas y cuentas) y `LicenseContact.kt` (WhatsApp/nombre).
